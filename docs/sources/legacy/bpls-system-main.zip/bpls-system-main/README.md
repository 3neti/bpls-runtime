# Business Permit & Licensing System (BPLS)

A platform for Philippine Local Government Units (LGUs) to run the full business‑permit lifecycle — from taxpayer registration and fee assessment through payment collection, clearances, permit issuance, and statutory reporting.

This document is the **codebase turn‑over / architecture guide**. It describes the system as it exists today (a Turborepo monorepo of three Next.js apps on a shared Convex backend, plus a ClickHouse reporting warehouse). If something here disagrees with older docs, this file is the current source of truth.

> **Heads‑up for readers of the old docs:** the historical `OVERVIEW.md` and prior README described a *single* root‑level Next.js app (`app/`, `components/`, `convex/`) and named **better‑auth** as the auth layer. Both are stale. The code is now a **monorepo**, and auth is **Convex Auth** (`@convex-dev/auth`). Treat `OVERVIEW.md` as background on the fee/domain model only.

---

## Table of contents

- [1. What the system does](#1-what-the-system-does)
- [2. Repository layout](#2-repository-layout)
- [3. Architecture at a glance](#3-architecture-at-a-glance)
- [4. Tech stack](#4-tech-stack)
- [5. The three applications](#5-the-three-applications)
- [6. The Convex backend](#6-the-convex-backend)
- [7. Reporting & analytics pipeline](#7-reporting--analytics-pipeline)
- [8. Getting started](#8-getting-started)
- [9. Development workflow](#9-development-workflow)
- [10. Build, deploy & CI](#10-build-deploy--ci)
- [11. Environment variables](#11-environment-variables)
- [12. Conventions & gotchas](#12-conventions--gotchas-read-this)
- [13. Further reading](#13-further-reading)

---

## 1. What the system does

The BPLS digitizes a municipal Business Permits & Licensing Office (BPLO):

- **Taxpayer & business registry** — business owners, their businesses, and each business's *Lines of Business* (LOB).
- **Configurable tax/fee schedule** — a `Major → Division → Group (Line of Business)` hierarchy of fees, with inheritance and per‑scope overrides, supporting fixed, range‑based, and formula‑based fees.
- **Permit application workflow** — intake, fee assessment, approval, payment (with installment schedules, surcharges and penalties), department clearances, and permit issuance with QR‑verifiable PDFs.
- **General LGU billing ("Billing Groups")** — a configurable, non‑permit revenue module (market fees, cemetery fees, etc.) with custom fields, fee libraries, and its own receipts.
- **Citizen self‑service portal** — public registration, application submission/tracking, and (mock) payment.
- **Reporting** — both an ad‑hoc report builder over live Convex data and a suite of statutory/analytical reports over a ClickHouse warehouse (CMCI, PLDS, BSP, ANNEX‑C DNFBP, masterlists, etc.).
- **Administration** — granular role‑based access control, activity/audit logging, platform branding, and print‑layout templating.

---

## 2. Repository layout

Turborepo monorepo managed with **Bun** workspaces (`apps/*`, `packages/*`).

```
bpls-system/
├── apps/
│   ├── admin/      @repo/admin    — LGU staff back‑office            (Next.js, port 3000)
│   ├── web/        @repo/web      — Citizen self‑service portal      (Next.js, port 3001)
│   └── ad-hoc/     @repo/ad-hoc   — Analytical/statutory reporting   (Next.js, port 3002)
├── packages/
│   ├── backend/    @repo/backend  — Convex backend (schema + functions) — the shared source of truth
│   ├── ui/         @repo/ui       — shadcn/ui component library (Radix + Tailwind v4)
│   ├── shared/     @repo/shared   — shared TS types (derived from Convex) + Zod form schemas
│   └── clickhouse/ @repo/clickhouse — ClickHouse client + report SQL builders
├── docs/           — specs & incident notes
├── scripts/        — standalone one‑off scripts (e.g. export-permit-report.ts)
├── turbo.json      — task pipeline
├── package.json    — workspaces, dependency `catalog`, dev/prod scripts
└── OVERVIEW.md / CHANGELOG.md
```

### Apps & packages

| Workspace | Name | Role | Port |
|---|---|---|---|
| `apps/admin` | `@repo/admin` | Staff back‑office: permits, fees, payments, billing groups, reports, admin | **3000** |
| `apps/web` | `@repo/web` | Citizen portal: register, apply, track, pay | **3001** |
| `apps/ad-hoc` | `@repo/ad-hoc` | Statutory/analytical reports over ClickHouse | **3002** |
| `packages/backend` | `@repo/backend` | Convex schema + all queries/mutations/actions; auth; fee engine | — (Convex cloud) |
| `packages/ui` | `@repo/ui` | Shared shadcn/ui primitives, global CSS/design tokens | — |
| `packages/shared` | `@repo/shared` | Convex‑derived types + Zod schemas + formatting utils | — |
| `packages/clickhouse` | `@repo/clickhouse` | `@clickhouse/client` wrapper + per‑report query builders | — |

Dependency direction: **backend is the hub.** `ui`, `shared`, `clickhouse` and all three apps depend on `@repo/backend` (for generated API types / the fee engine). Apps never talk to each other.

---

## 3. Architecture at a glance

```
   ┌───────────────┐   ┌───────────────┐   ┌────────────────────┐
   │  admin (3000) │   │   web (3001)  │   │   ad-hoc (3002)    │
   │  staff back-  │   │  citizen      │   │  reporting         │
   │  office       │   │  portal       │   │  dashboard         │
   └───────┬───────┘   └───────┬───────┘   └─────────┬──────────┘
           │ useQuery /        │ citizenQuery /       │ fetchAction (hybrid reports)
           │ useMutation       │ citizenMutation      │
           ▼                   ▼                      │
   ┌───────────────────────────────────────────────┐ │
   │              CONVEX  (@repo/backend)           │ │  ClickHouse SQL
   │  ~49 function modules · 45 tables · Convex Auth│◄┘  (@repo/clickhouse)
   │  RBAC · fee engine · workflows · search        │        │
   └───────────────────────┬────────────────────────┘        │
                           │ Airbyte sync (ReplacingMergeTree)│
                           ▼                                  ▼
                 ┌───────────────────┐            ┌────────────────────────┐
                 │   Convex database │───────────►│  ClickHouse warehouse  │
                 │  (source of truth)│  (mirror)  │  (read‑only analytics) │
                 └───────────────────┘            └────────────────────────┘
```

- **Convex is the system of record.** Every write goes through Convex functions; the frontends subscribe reactively (`useQuery`) so state stays live.
- **ClickHouse is a read‑only mirror**, populated from Convex by **Airbyte** (configured externally — no Airbyte config lives in this repo). The `ad-hoc` app queries it for heavy analytical reports.
- **Hybrid reports:** some reports need per‑LOB / formula‑fee math that cannot be expressed in SQL. Those `ad-hoc` reports first narrow the dataset in ClickHouse, then call back into Convex *actions* (the fee engine) to compute amounts, and merge the results. See [§7](#7-reporting--analytics-pipeline).

---

## 4. Tech stack

| Layer | Choice |
|---|---|
| Monorepo / build | Turborepo, Bun (`bun@1.2.0`), dependency `catalog` in root `package.json` |
| Framework | Next.js 15 (App Router, Turbopack), React 19.2 |
| Language | TypeScript 5 (strict) |
| Backend / DB | Convex (reactive DB + serverless functions), `convex-helpers` |
| Auth | **Convex Auth** (`@convex-dev/auth`) — Password provider, JWT |
| Convex components | `@convex-dev/workflow` (durable exports), `@convex-dev/migrations` (registered, see gotchas) |
| Analytics warehouse | ClickHouse (`@clickhouse/client`), fed by Airbyte |
| UI | shadcn/ui (Radix primitives), Tailwind CSS v4, `lucide-react`, `recharts`, `sonner` |
| Forms | `react-hook-form` + `zod` (schemas in `@repo/shared/schemas`) |
| Tables | `@tanstack/react-table`, `@tanstack/react-virtual` (reporting) |
| Rich text → PDF | TipTap editor (`{{macro}}` templates) → `@react-pdf/renderer` |
| Client state | Zustand (admin: report builder, column visibility) |
| Misc | `qrcode` (permit verification), `react-webcam` (owner photos), `@dnd-kit` (field reordering) |

---

## 5. The three applications

### 5.1 `admin` — staff back‑office (port 3000)

The operational heart of the system, used by BPLO/Treasury staff. Server components use Convex's Next.js helpers (`fetchQuery`/`preloadQuery` with `convexAuthNextjsToken()`) and hand a `Preloaded<…>` down to a `"use client"` sibling (`usePreloadedQuery`) — the SSR‑then‑reactive pattern used almost everywhere.

**Route map (dashboard):**

| Route | Purpose |
|---|---|
| `/dashboard` | Home: stat cards, activity/weekly charts, recent transactions |
| `/dashboard/business-owners`, `/businesses` | Taxpayer & business registry (list/search/detail/create); blacklist‑aware |
| `/dashboard/business-categories` | 2‑level Category → Sub‑Category taxonomy (a stat dimension, separate from the fee hierarchy) |
| `/dashboard/taxes-and-fees/{major,division,line-of-business,fees,surcharge-penalty}` | The fee schedule config: `Major → Division → Group/LOB`, the Fee Names catalog, and surcharge/penalty rules |
| `/dashboard/permit-applications` | All applications + the pipeline stages: `new` (wizard), `assessment`, `approval`, `payment`, `released` |
| `/dashboard/permits` | Issued permits (QR, PDF, reprint) |
| `/dashboard/clearances` | Clearance types required before release (Sanitary, Fire, MPDC…) |
| `/dashboard/payments-billing` | Unified view of permit payments, manual transactions & billing‑group records |
| `/dashboard/billing-groups`, `/[id]` | Configurable non‑permit billing: Records / Fee Library / Custom Fields / Print tabs |
| `/dashboard/reports`, `/new`, `/[id]` | Convex‑native ad‑hoc report builder (saveable) |
| `/dashboard/locations` | Province / City / Barangay reference data |
| `/dashboard/user-management`, `/roles` | Users, and the role × `resource:action` permission matrix |
| `/dashboard/activity` | System‑wide audit log with filters/histogram |
| `/dashboard/account` | Current user's own profile & password |
| `/dashboard/settings/{branding,municipality,officials,permit-layout,receipting,platform-configuration}` | Tenant config + TipTap PDF layout editors |
| `/admin/onboarding` | First‑run setup wizard (admin user → branding → municipality → officials) |
| `/login` | Staff sign‑in |
| `/permits/verify/[id]` | **Public** QR permit‑authenticity page (unauthenticated) |

**Route protection is layered:** `middleware.ts` (`convexAuthNextjsMiddleware`, public‑route allowlist) → the `dashboard/layout.tsx` server component re‑verifies the token, checks onboarding, and loads the current user → per‑UI permission gating via `usePermissions()` (`hooks/use-permissions.ts`, a `Set<"resource:action">`) and `<PermissionGuard>`. **Real enforcement lives in Convex** — pages catch `ConvexError` with `code: "PERMISSION_DENIED"`/`"UNAUTHENTICATED"` and render friendly error states.

### 5.2 `web` — citizen portal (port 3001)

Public self‑service site for business owners. Same Convex backend and same `@convex-dev/auth` Password provider as staff, but sign‑in passes `userType: "citizen"`, and **all** data access goes through the `convex/citizen/*` namespace (`citizenQuery`/`citizenMutation`), which authenticate and then **block `userType === "admin"`** (the opposite gate to staff functions). Ownership is enforced per‑row via `user.linkedBusinessOwnerId`; admin‑only fields are stripped from responses.

| Route | Purpose |
|---|---|
| `/register`, `/login` | Citizen sign‑up / sign‑in |
| `/portal/applications` (+ `/new`, `/[id]`) | The citizen's own applications: list, submit, track |
| `/portal/payments/[id]` | Per‑schedule payment detail; **mock** payment (no live gateway) |
| `/portal/profile` | Account info + link/create a `business_owner` record + list linked businesses |

### 5.3 `ad-hoc` — reporting dashboard (port 3002)

Staff‑only analytical app over the ClickHouse warehouse. Same staff auth/middleware as `admin`. Reports render through a shared **`VirtualTable`** (`@tanstack/react-virtual`, row‑ + column‑virtualized, sticky pinned columns, server‑computed footer totals) and a shared **`ReportToolbar`** (date/OR#/year/month/rank/fee‑scope filters + a generic filter slot). On‑screen rows are capped (`DISPLAY_ROW_CAP = 25,000`) but totals always reflect the full set. **Exports are 100% server‑side** — `"use server"` actions re‑fetch the complete dataset and build CSV (`buildTableCsv`) or PDF (`@react-pdf/renderer`'s `renderToBuffer`, in `serverExternalPackages`), so only the finished file crosses the wire.

Reports include: All Abstract, Abstract by Billing Group (`/abstract/[billingGroupId]`), Masterlist (Paid / Unpaid), Breakdown of Collectibles, Business Tax on Major Type, Top 100 Establishments (Tax Due), Taxpayer's Account Card, Total Capital & Gross Summary, **CMCI LDCS**, **PLDS**, **BSP**, and **ANNEX‑C DNFBP**.

---

## 6. The Convex backend

`packages/backend/convex/` — ~49 top‑level modules, 45 tables (`schema.ts`, ~1,377 lines). This is the shared brain of the system.

### 6.1 Auth & RBAC

- **Convex Auth**, single **Password** provider (`auth.ts`, `auth.config.ts`). The provider's `profile()` callback branches on a `userType` param: `"citizen"` → `role: "Citizen"`; anything else → `userType: "admin"` with a staff‑assigned role.
- **Current user** is resolved on every request: `getAuthUserId(ctx)` → identity email → app‑level `users` row (`by_email`). Deliberately *not* cached, so role changes take effect without re‑login.
- **Custom function wrappers** (via `convex-helpers`):
  - `authenticatedQuery` / `authenticatedMutation` (`auth.ts`) — resolve the user, run `enforcePermission()`, inject `ctx.user`. Used by all staff functions.
  - `citizenQuery` / `citizenMutation` (`citizen/auth.ts`) — authenticate and block admins; **no** granular RBAC.
- **RBAC model:** `roles`, `permissions` (`resource` + `action`, with hierarchical sub‑resources like `taxes_and_fees:major`), `role_permissions` (junction). Seeded system roles: **Admin**, **BPLO**, **Treasury**. Custom roles are supported.

> ⚠️ **Admin short‑circuit gotcha:** the *server* enforcer `enforcePermission()` has **no** Admin bypass — it is a pure `role_permissions` lookup (with a hierarchical fallback). The *client‑side* helpers (`permissions.getUserPermissions`/`hasPermission`) **do** hard‑code `role === "Admin" → true`. If someone unchecks boxes on the Admin role in the UI, Admin silently loses real backend access while the UI still shows full access. `restoreAllPermissionsToAdmin` repairs it; custom "super admin" roles need explicit rows via `assignAllPermissionsToRole`. See the comments in `permissions.ts` (around the `hasPermission` / `enforcePermission` split).

### 6.2 Data model by domain

| Domain | Tables | Notes |
|---|---|---|
| **Owners & businesses** | `business_owners`, `businesses`, `permits`, `business_nature_categories` (legacy) | `businesses.linesOfBusiness[]` / `.feeOverrides[]` are **deprecated embedded arrays**; `.documents[]` is active |
| **Fee hierarchy** | `majors`, `divisions`, `groups` (= Lines of Business), `division_groups` (junction), `fees`, `fee_overrides`, `fee_names` | ⚠️ `groups` here means *fee groups / LOB*, **not** RBAC groups |
| **Permit applications & clearances** | `business_permit_applications`, `clearance_types`, `permit_clearances`, `departments` | Application embeds `linesOfBusiness[]`, each with nested `feeOverrides[]`/`excludedFees[]`/`feeVariableMappings[]` |
| **RBAC** | `users`, `roles`, `permissions`, `role_permissions` | |
| **Locations** | `provinces`, `cities`, `barangays` | Two CRUD surfaces exist (`locations.ts` consolidated + per‑table) |
| **Business categories** (stat dimension) | `business_categories`, `business_subcategories` | Separate from fee `groups` |
| **Units of measurement** | `unitsOfMeasurement` | Per‑application named quantities (e.g. `numberOfHorses`) that feed formula fees |
| **Payments & billing** | `payment_schedules` (embeds `fees[]`), `payments`, `payment_schedule_config`, `surcharge_penalty_config` (singleton), `manual_transactions` | |
| **Billing Groups** | `billing_groups`, `billing_group_fields`, `billing_group_records` (embeds `fieldValues[]`), `billing_group_fees`, `billing_group_fee_fields`, `billing_group_line_items`, `billing_group_print_layouts` | The configurable non‑permit billing module |
| **Print layouts** | `permit_layouts` (singleton `key:"default"`), `receipt_layouts` | TipTap `{{macro}}` templates (billing groups have their own) |
| **Reporting** | `saved_reports`, `report_exports`, `report_export_chunks` | |
| **Infra** | `counters`, `activity_logs`, `platform_settings` (singleton) | Plus `...authTables` from Convex Auth |

### 6.3 Fee engine

The most intricate part of the backend.

- **Fee types:** **Constant** (fixed `amount`), **Range** (bucket‑match a `rangeField` — e.g. `grossSales`, `capitalInvestment`, `numberOfEmployees`, `floorArea` — against `ranges[]`; the open top bucket may itself be a formula), **Formula** (evaluate a `formula` string over business/LOB variables and Units‑of‑Measurement quantities).
- **Inheritance:** `Major → Division → Group`. A `fees` row attaches to a `divisionId` (inherited by every Group that applies that Division via `division_groups`) or directly to a `groupId` (custom). Overrides live in `fee_overrides`, keyed by `(divisionGroupId, feeId)`, and require a `reason`.
- **Override precedence** (during assessment): per‑LOB override → application‑global override → inherited/calculated default.
- **Where it lives:** `fees.ts` (definitions + `calculateFee`/`calculateAllFees*`), `groups.ts` (gated inherited‑fee + override API — the current path), `feeInheritance.ts` (an older *ungated* duplicate of the resolution logic — be aware both exist), and the per‑LOB reporting bridge in `reports.ts` (`computePerLobFees`, `getTaxpayerCardData`, `computeMasterlistLines`, `computeUomAssetsByApplication`).

> ⚠️ **Three separate formula evaluators exist** (not one shared lib): `fees.ts` uses the JS `Function` constructor (full semantics, live assessment); `reports.ts` uses a hand‑written recursive‑descent parser (no `Math.*`); `surchargeConfig.ts` uses yet another parser (supports `Math.min/max/floor/ceil/round`, plus upfront `validateFormula`). If you touch formula behavior, check all three.

### 6.4 Permit application lifecycle

```
Draft ──submit──► Assessment ──► Approval ──► Pending Payment ──► Released
 (saved)        (LOB + fees)   (review)     (fees finalized)    (1st period paid,
                                                                 permit issuable — terminal)
```

Each stage is a queue + detail view in `admin`; all four post‑draft stages share one `permit-detail-view.tsx` composed of LOB configuration, Units of Measurement, Schedule of Payments, and a Clearances checklist (permit issuance is gated until required clearances are checked off). Recording the **first** payment period auto‑transitions the application to `Released`, auto‑assigns active clearance types, and marks fully‑waived sections paid.

### 6.5 Payments, schedules & billing groups

- **`payment_schedules`** — one row per due‑date *section* of an application (1 / 2 / 4 sections for Annually / Semi‑Annually / Quarterly), each embedding its own `fees[]` snapshot, `surcharge`, `penalty`, `totalAmount`, `paidAmount`, `status`. **Fee‑distribution rule** (`paymentSchedules.generate`): **non‑Tax** fees (Regulatory / Other Charges / Special) are billed in full **upfront in Section 1**; **Tax** fees are **split equally** across all sections. `payments.ts` pays **one section at a time** against its remaining balance (no cross‑section waterfall); paying Section 1 in full transitions the application to `Released`.
- **`surcharge_penalty_config`** — singleton with `surchargeFormula` / `penaltyFormula` strings over named variables (`periodFee`, `Tax`, `monthsMissed`, `quartersMissed`, `daysDiff`, …) plus per‑mode due dates; 0 if no active config or not past due.
- **`manual_transactions`** — an ad‑hoc debit/credit ledger for entries outside the permit flow.
- **Billing Groups** — a "build‑your‑own billing type" module independent of the permit fee engine: define a group, arbitrary custom fields (text/number/currency/date/dropdown/checkbox, one flagged as the *amount* field), an optional fee library for multi‑line items, and a PDF receipt layout. Records surface alongside permit payments on the Payments & Billing page.

### 6.6 PDF / print‑layout system

Permit certificates, official receipts, and billing‑group receipts all use the same mechanism: a **TipTap** rich‑text editor stores header/body/footer as TipTap JSON (auto‑migrated from legacy plain text); `{{macroName}}` placeholders bind data, and special macros (`QR_CODE`, `MUNICIPAL_SEAL`, `LOGO`, `LINES_OF_BUSINESS`) become `[[MARKER]]` tokens. A renderer walks the TipTap tree and emits `@react-pdf/renderer` nodes, mapping bold/italic/font to explicit react‑pdf font variants (e.g. `Helvetica-Bold`) and swapping markers for the right PDF component.

### 6.7 Reporting backend

Two independent report systems:

1. **Ad‑hoc builder** (`reports.ts`, `savedReports.ts`) — 100% Convex‑native, for 7 resource types (permit applications, billing groups, payments, permits, businesses, business owners, manual transactions). Users pick dimensions/metrics/filters; configs are saved (not output) to `saved_reports`.
2. **Warehouse reports** — the `ad-hoc` app's statutory reports, computed in ClickHouse, some calling back into the `reports.ts` per‑LOB fee actions (see [§7](#7-reporting--analytics-pipeline)).

**Server‑side CSV export** uses the durable **`@convex-dev/workflow`** component (`reportExportWorkflow.ts`): `startExport` creates a `report_exports` row and runs a workflow that batches rows and stores the result in file storage (48h expiry, `report_export_chunks` for large files). ⚠️ Currently only `permit_applications` is fully wired; other resource types return a placeholder "coming soon" CSV (Phase‑2 TODO).

### 6.8 Cross‑cutting infra

- **HTTP** (`http.ts`) — only mounts Convex Auth routes; there are **no** custom REST/webhook endpoints. All access is Convex RPC.
- **Search** (`search.ts`) — Convex native search indexes over denormalized `searchText` fields; `globalSearch` powers the command palette across owners/businesses/applications/permits/users/payments.
- **Activity log** (`activityLogs.ts` + `lib/activityLogger.ts`) — mutations call `logCrudActivity`/`logStatusChange`; reads are permission‑gated & paginated with histogram/facets.
- **Migrations** — ⚠️ despite `@convex-dev/migrations` being registered in `convex.config.ts`, it is **not** used as a runner. Migrations are **hand‑written idempotent `internalMutation`s** (`migrations.ts` + ~15 scripts under `migrations/`), each run manually per deployment via `npx convex run migrations/<file>:<fn>` and usually paired with a verify/status query.
- **`citizen/`** (7 files) & **`unitsOfMeasurement/`** (5 files) — the citizen portal backend and per‑application formula variables, respectively.

---

## 7. Reporting & analytics pipeline

```
Convex (source of truth)  ──Airbyte──►  ClickHouse (ReplacingMergeTree mirror)
                                              │
                       ┌──────────────────────┴───────────────────────┐
                       │  ad-hoc app  "use server" action              │
                       │   1. query ClickHouse (@repo/clickhouse)      │
                       │   2. (hybrid only) fetchAction → Convex fee   │
                       │      engine for per‑LOB / formula amounts     │
                       │   3. merge → VirtualTable / CSV / PDF         │
                       └───────────────────────────────────────────────┘
```

- **`@repo/clickhouse`** exports `./client` (a memoized `getClickHouseClient()` over `@clickhouse/client`, reading `CLICKHOUSE_*` env vars) and `./queries/*` (one SQL/query‑builder module per report + shared `_address.ts` / `_category.ts` / `_permit.ts` helpers).
- **ReplacingMergeTree + `FINAL`:** Airbyte lands tables in append/dedup mode, so raw `SELECT`s can see un‑merged duplicate `_id` versions. The client sets `clickhouse_settings: { final: 1 }` **globally**, so every query is implicitly deduped (latest `_ts` wins) — you do **not** add `FINAL` per query.
- **Pure vs hybrid reports:** most reports (all‑abstract, collectibles, BSP, business‑tax‑by‑major, CMCI LDCS, top‑establishments, capital/gross) are pure ClickHouse. Four are **hybrid** (masterlist paid/unpaid, taxpayer account card, PLDS, ANNEX‑C DNFBP): they select/aggregate in ClickHouse, then `fetchAction` into Convex (`computeMasterlistLines`, `getTaxpayerCardData`, `computeUomAssetsByApplication`, DNFBP data) because formula‑driven per‑LOB fees can't be evaluated in SQL — the warehouse has no `fees` table.

> New warehouse columns "self‑activate" once Airbyte has synced them; verify a table/column exists in ClickHouse before relying on it. Airbyte itself is configured outside this repo.

---

## 8. Getting started

### Prerequisites

- [**Bun**](https://bun.sh) `1.2.x`
- A [**Convex**](https://convex.dev) account/project (for the backend)
- (Reporting only) access to a **ClickHouse** instance + the Airbyte sync

### Install & run

```bash
bun install                 # install all workspaces

# First‑time backend setup (creates a Convex dev deployment, writes .env.local)
bun run --cwd packages/backend dev:setup

# Then run everything (backend + all 3 apps) with Turborepo:
bun dev
```

Or run a single app against the backend (lighter):

```bash
bun run dev:admin     # backend + admin  → http://localhost:3000
bun run dev:web       # backend + web    → http://localhost:3001
bun run dev:ad-hoc    # backend + ad-hoc → http://localhost:3002
bun run dev:convex    # backend only (Convex file‑watcher)
```

> There is **no committed `.env.example`.** You will need to create `.env.local` files (Convex writes `NEXT_PUBLIC_CONVEX_URL` for you during `dev:setup`); the reporting app additionally needs `CLICKHOUSE_*` vars. See [§11](#11-environment-variables).

---

## 9. Development workflow

**Ports:** admin `3000`, web `3001`, ad‑hoc `3002`. The Convex backend has no local port — it connects to a Convex cloud dev deployment and watches `packages/backend/convex/` for changes.

**Root scripts (`package.json`):**

| Script | What it does |
|---|---|
| `bun dev` | `turbo dev` — backend + all apps in parallel |
| `bun run dev:{admin,web,ad-hoc}` | Backend + that one app |
| `bun run dev:convex` | Backend only |
| `bun run prod`, `prod:{admin,web,ad-hoc}` | ⚠️ Run the **local UI against PRODUCTION Convex data** — bypasses Turbo, runs `convex dev --prod`, and pins `NEXT_PUBLIC_CONVEX_URL` to the prod cloud URL. Use with care. |
| `bun run build`, `build:{admin,web}` | `turbo build` |
| `bun run lint` | `turbo lint` |
| `bun run deploy:convex` | `cd packages/backend && npx convex deploy` |

**Convex from the backend package:**

```bash
cd packages/backend
bun run dev        # convex dev  (dev deployment)
bun run dev:prod   # convex dev --prod (local app ↔ prod data)
bun run deploy     # convex deploy (push functions/schema to prod)
```

**Migrations** are run manually after deploying schema/functions, e.g.:

```bash
cd packages/backend
npx convex run migrations/populateSearchText:populateSearchText
```

Each migration is idempotent and typically has a companion verify/status query. For breaking schema changes use the **widen → migrate → narrow** approach — legacy data that no longer matches a narrowed validator will otherwise block the entire deploy.

**Type‑checking:** there is **no repo‑wide `typecheck` script.** Apps typecheck implicitly via `next build`, but `admin` and `ad-hoc` set `typescript.ignoreBuildErrors` / `eslint.ignoreDuringBuilds` in `next.config.mjs` (only `web` builds strictly). To typecheck a package/app deliberately, run `bunx tsc -p <path> --noEmit`.

---

## 10. Build, deploy & CI

- **Containerization:** only `apps/admin/Dockerfile` exists (a 3‑stage `oven/bun:1-alpine` build → Next.js `output: standalone`, non‑root user, `EXPOSE 3000`, `HEALTHCHECK` on `/api/health`). `web` and `ad-hoc` are not containerized.
- **CI:** `.github/workflows/deploy.yml` ("Deploy to Multiple Environments") runs on push/PR to `main` + manual dispatch. It uses a **tenant matrix** (currently one entry: `IPIL`) and, per tenant, runs `bunx convex deploy` from `packages/backend` with that tenant's `CONVEX_DEPLOY_KEY` secret. The matrix shape anticipates **multi‑tenant** expansion. Note: this workflow deploys **only the Convex backend** — frontend hosting is handled by **Vercel**'s own Git integration (no Vercel step in the workflow, no `vercel.json`).
- **`turbo.json`:** `build` (`dependsOn: ["^build"]`, passes `CONVEX_DEPLOY_KEY`, caches `.next/**`), `dev` (uncached, persistent), `lint`.

---

## 11. Environment variables

| Variable | Used by | Notes |
|---|---|---|
| `NEXT_PUBLIC_CONVEX_URL` | all 3 apps | Convex deployment URL (client). Written by `convex dev`. |
| `CONVEX_DEPLOY_KEY` | Convex CLI / CI | Deploy‑time only (per tenant in CI). |
| `CONVEX_SITE_URL` | `auth.config.ts` | Convex Auth JWT issuer (auto‑provided by Convex). |
| `NEXT_PUBLIC_APP_URL` | admin | Base URL for absolute links / QR codes (has a fallback). |
| `CLICKHOUSE_HOST` / `_USER` / `_PASSWORD` / `_DATABASE` / `_PORT` | ad‑hoc + `@repo/clickhouse` | Reporting warehouse creds. (Legacy misspelled fallback `CLICKHOUSE_PASSOWORD` is also read.) |
| `CONVEX_URL` | `scripts/export-permit-report.ts` | Standalone script only. |

`.env` files are gitignored and there is no `.env.example` — obtain values from the deployment owner when onboarding.

---

## 12. Conventions & gotchas (read this)

A maintainer taking over should internalize these:

- **Auth is Convex Auth, not better‑auth** (old docs are wrong). Staff functions use `authenticatedQuery`/`authenticatedMutation`; citizen functions use `citizenQuery`/`citizenMutation` and hard‑block admins.
- **`groups` = Lines of Business (fees), not RBAC groups.** Naming collision — watch context.
- **The Admin RBAC short‑circuit is UI‑only** ([§6.1](#61-auth--rbac)). Server enforcement is pure row lookup; don't assume Admin can do everything server‑side just because the UI says so.
- **Never use `(api as any)`.** Convex generates types from the directory structure. Because `authenticatedQuery` return types don't flow through `useQuery` on the client, the codebase‑wide convention is to **annotate callback params at call sites**, e.g. `.map((c: { _id: string; name: string }) => …)`.
- **Fee logic is duplicated** — `groups.ts` (current, gated) vs `feeInheritance.ts` (older, ungated), plus three formula evaluators ([§6.3](#63-fee-engine)). Change carefully and in sync.
- **Migrations are hand‑rolled**, run manually via `npx convex run`; the `@convex-dev/migrations` component is registered but unused.
- **ClickHouse queries need dedup** — it's handled globally via `final: 1` on the client; all warehouse tables are ReplacingMergeTree.
- **`payment_schedules.totalAmount` is the billed amount** for reports — `businesses`/`applications` `totalFees` diverges and should not be used for billed/outstanding math.
- **`prod:*` scripts point your local UI at production data.** Prefer read‑only intent; prod Convex is largely read‑only via tooling.
- **Package manager is Bun** (`bun.lock`) — don't introduce `npm`/`pnpm` lockfiles.
- **Known dead weight:** `apps/admin` still lists `styled-components` and an empty local `components/ui/` (vestigial shadcn/v0 scaffold — real components come from `@repo/ui`), and imports nothing from `@repo/shared` despite depending on it.

---

## 13. Further reading

| Doc | Contents |
|---|---|
| [`OVERVIEW.md`](./OVERVIEW.md) | Deep dive on the fee/domain model (⚠️ partly stale on structure & the single‑app layout — trust this README for architecture) |
| [`CHANGELOG.md`](./CHANGELOG.md) | Release history |
| [`docs/`](./docs) | Feature specs (e.g. per‑LOB paid allocation, billing‑records permission) and incident notes |
| `packages/backend/convex/schema.ts` | The authoritative data model |

**First files to read** when picking up the backend: `schema.ts` (data model), `auth.ts` + `permissions.ts` (auth/RBAC and the Admin gotcha), `fees.ts` / `groups.ts` / `feeInheritance.ts` (fee engine), `reports.ts` (report + per‑LOB fee bridge), `reportExportWorkflow.ts` (export pipeline).
