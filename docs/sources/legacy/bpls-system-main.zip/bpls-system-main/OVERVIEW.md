# BPLS System Overview

## System Architecture

The BPLS (Business Permit and Licensing System) is a Next.js application with a Convex backend. The system manages business registrations, permit applications, fee calculations, and department clearances.

```
┌─────────────────────────────────────────────────────────────────┐
│                        FRONTEND (Next.js)                       │
│  app/dashboard/  │  components/  │  hooks/  │  lib/types/       │
└────────────────────────────┬────────────────────────────────────┘
                             │ useQuery() / useMutation()
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                      BACKEND (Convex)                           │
│  convex/*.ts (queries & mutations)  │  convex/schema.ts        │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                     DATABASE (Convex DB)                        │
│  22 tables with relationships and indexes                       │
└─────────────────────────────────────────────────────────────────┘
```

---

## Core Entity Relationships

### 1. Business Owner → Business Relationship

```
business_owners (1)
      │
      │ ownerId (FK)
      ▼
businesses (many)
      │
      ├── linesOfBusiness[] (embedded array)
      │       ├── businessCategory
      │       ├── groupId → groups table
      │       ├── capitalInvestment / grossSales
      │       ├── feeOverrides[] (per-LOB)
      │       └── excludedFees[]
      │
      ├── feeOverrides[] (global business-level)
      │
      └── documents[] (ownership documents)
```

**Key Points:**
- A `business_owner` can own multiple `businesses`
- Each business has an embedded `linesOfBusiness[]` array containing business categories
- Each Line of Business (LOB) links to a `group` (industry classification)
- Fee overrides can be applied at both per-LOB and global levels

### 2. Fee Hierarchy (Major → Division → Group)

```
majors (e.g., "Dealer", "Retailer", "Manufacturer")
    │
    │ majorId (FK)
    ▼
divisions (e.g., "DNEC", "ETC")
    │
    │ divisionId (FK)
    ├───────────────────────────┐
    │                           │
    ▼                           ▼
fees (inherited)          division_groups (junction)
                                │
                                │ groupId (FK)
                                ▼
                          groups (Lines of Business)
                                │
                                ├── Inherited Fees (from divisions)
                                ├── Custom Fees (created on group)
                                └── Fee Overrides (per division-group)
```

**Key Points:**
- **Majors**: Top-level industry classification (e.g., "Dealer")
- **Divisions**: Sub-categories under majors (e.g., "DNEC", "ETC")
- **Groups**: Lines of Business/business categories (e.g., "Retail Trade", "Food & Beverage")
- **division_groups**: Junction table enabling many-to-many relationships
- **Fees** are attached to divisions and inherited by groups
- Groups can have **custom fees** created directly on them
- Groups can **override** inherited division fees via `fee_overrides` table

---

## Fee System Deep Dive

### Fee Types

| Type | Description | Configuration |
|------|-------------|---------------|
| **Constant** | Fixed amount | `amount` field |
| **Range** | Amount based on business field value | `rangeField` + `ranges[]` array |
| **Formula** | Calculated using business metrics | `formula` field (e.g., `numberOfEmployees * 100`) |

### Fee Categories

- Tax
- Regulatory Fee
- Other Charges
- Special Fee

### Fee Calculation Variables

The fee calculator supports these standard variables:

| Variable | Source |
|----------|--------|
| `numberOfEmployees` | Business table (calculated) |
| `maleEmployeeCount` | Business table |
| `femaleEmployeeCount` | Business table |
| `businessArea` / `floorArea` | Business table (sq.m) |
| `capitalInvestment` | Line of Business |
| `grossSales` | Line of Business |
| `businessAnnualRevenue` | Line of Business |

Additionally, **dynamic category variables** from `unitsOfMeasurement` table:
- Custom variables like `numberOfHorses`, `numberOfTables`, etc.
- Mapped via `feeVariableMappings` in the LOB configuration

### Fee Override Priority

When calculating fees, the system uses this priority order:

1. **Per-LOB feeOverrides** (business.linesOfBusiness[].feeOverrides) - Highest priority
2. **Global feeOverrides** (business.feeOverrides)
3. **Inherited from division/group** (calculated) - Default

### Range-Based Fee Example

```javascript
// Range configuration for "Business Tax"
rangeField: "grossSales"
ranges: [
  { min: 0, max: 50000, fee: 200 },
  { min: 50001, max: 100000, fee: 400 },
  { min: 100001, max: 500000, fee: 800 },
  { min: 500001, max: Infinity, formula: "grossSales * 0.0075" }
]
```

---

## Database Schema (Key Tables)

### business_owners
```typescript
{
  firstName, middleName, lastName: string
  birthDate, civilStatus, gender, citizenship: string
  tin?: string  // Optional TIN
  mobile, email, address: string
  provinceId, cityId, barangayId: Id  // Location FKs
  ownerType: "Single" | "Group"
  groupName?: string  // For Group type
  isBlacklisted?: boolean
  blacklistReason?, blacklistedAt?, blacklistedBy?: string
}
```

### businesses
```typescript
{
  name: string
  ownerId: Id<"business_owners">
  businessScale, annualRevenue: string
  establishedDate, dateStarted: string
  registrationDate?, registrationNumber?: string  // DTI/SEC/CDA
  address, buildingName?: string
  provinceId, cityId, barangayId: Id  // Location FKs
  ownershipType: string  // "Sole Proprietorship" | "Partnership" | "Corporation" | "Cooperative"
  groupName?: string  // Company name for non-sole proprietorship
  occupancy, permitPaymentCadence: string
  numberOfEmployees, maleEmployeeCount, femaleEmployeeCount: number
  businessArea?: number  // sq.m
  contactNumber, email: string

  // Embedded arrays
  linesOfBusiness?: LineOfBusiness[]
  feeOverrides?: FeeOverride[]
  documents?: Document[]

  // Blacklist fields
  isBlacklisted?, blacklistReason?, blacklistedAt?, blacklistedBy?
}
```

### groups (Lines of Business)
```typescript
{
  name: string  // e.g., "Retail Trade", "Food & Beverage"
  description?: string
  createdAt: string
}
// Note: Fees are linked via division_groups junction table
```

### fees
```typescript
{
  name: string
  amount: number
  applicationType: string[]  // ["New", "Renewal"]
  feeType: "Constant" | "Range" | "Formula"
  feeCategory?: "Tax" | "Regulatory Fee" | "Other Charges" | "Special Fee"

  // For inherited fees
  divisionId?: Id<"divisions">

  // For custom fees
  groupId?: Id<"groups">
  status?: "Inherited" | "Custom" | "Override"

  // Range configuration
  rangeField?: string  // e.g., "grossSales"
  ranges?: { min, max, fee?, formula? }[]

  // Formula configuration
  formula?: string  // e.g., "numberOfEmployees * 100"
}
```

### business_permit_applications
```typescript
{
  businessOwnerId: Id<"business_owners">
  businessId: Id<"businesses">
  status: "Draft" | "Assessment" | "Awaiting Clearances" | "Rejected" | "Approved"
  applicationNumber: string  // e.g., "BPA-2025-001"
  modeOfPayment?: "Annually" | "Semi-Annually" | "Quarterly"
  submittedAt: string
  assessedAt?, assessedBy?, assessmentRemarks?: string
  totalFees?: number
  rejectionReason?, rejectedAt?, rejectedBy?: string

  // Embedded LOB for assessment
  linesOfBusiness: PermitLineOfBusiness[]
  feeOverrides?: FeeOverride[]
}
```

---

## Frontend-to-Backend Data Flow

### 1. Reading Data (Queries)

```typescript
// Component (e.g., business-detail-client.tsx)
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";

function BusinessDetail({ businessId }) {
  // Calls convex/businesses.ts → get()
  const business = useQuery(api.businesses.get, { id: businessId });

  // Calls convex/groups.ts → getAllGroupFees()
  const fees = useQuery(api.groups.getAllGroupFees, {
    groupId: business?.linesOfBusiness?.[0]?.groupId
  });

  return <div>{/* render data */}</div>;
}
```

### 2. Writing Data (Mutations)

```typescript
// Component
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";

function CreateBusiness() {
  // Calls convex/businesses.ts → create()
  const createBusiness = useMutation(api.businesses.create);

  const handleSubmit = async (data) => {
    await createBusiness({
      name: data.name,
      ownerId: data.ownerId,
      businessScale: data.businessScale,
      // ... other fields
    });
  };
}
```

### 3. Fee Calculation Flow

```
User selects Line of Business (Group)
            │
            ▼
Frontend calls: api.groups.getAllGroupFees({ groupId })
            │
            ▼
Backend collects:
  1. Inherited fees from applied divisions
  2. Custom fees created on group
  3. Applies fee_overrides if any
            │
            ▼
Frontend receives fee list
            │
            ▼
Frontend calculates amounts using:
  lib/utils/fee-calculator.ts → calculateFeeAmount()
  with businessData: { numberOfEmployees, grossSales, etc. }
            │
            ▼
Display fee breakdown to user
```

---

## Permit Application Workflow

### Status Flow

```
┌────────┐    Submit    ┌────────────┐   Configure LOBs   ┌─────────────────────┐
│ Draft  │ ──────────▶  │ Assessment │ ────────────────▶  │ Awaiting Clearances │
└────────┘              └────────────┘                    └──────────┬──────────┘
                              │                                      │
                         Reject                              All Clearances
                              │                                 Approved
                              ▼                                      │
                        ┌──────────┐                                 ▼
                        │ Rejected │                          ┌──────────┐
                        └──────────┘                          │ Approved │
                                                              └──────────┘
```

### Workflow Steps

1. **Draft**: Application created, linked to business owner and business
2. **Assessment**:
   - Configure Lines of Business
   - Calculate fees based on LOB configurations
   - Apply fee overrides if needed
   - Submit for clearances
3. **Awaiting Clearances**: Department reviews (Sanitary, Fire, Engineering, etc.)
4. **Approved**: All clearances passed, permit issued
5. **Rejected**: Failed at any stage with reason

### Key UI Components

| Component | Purpose |
|-----------|---------|
| `lob-configuration-card.tsx` | Configure Lines of Business for assessment |
| `fees-summary-card.tsx` | Display calculated fees with breakdown |
| `department-clearances-card.tsx` | Track clearance status by department |
| `fee-management-modal.tsx` | Override/disable fees |

---

## Key Convex Functions by Feature

### Business Owner Management
| Function | Type | Description |
|----------|------|-------------|
| `businessOwners.list` | Query | List all owners |
| `businessOwners.get` | Query | Get single owner by ID |
| `businessOwners.create` | Mutation | Create new owner |
| `businessOwners.update` | Mutation | Update owner |
| `businessOwners.blacklist` | Mutation | Blacklist owner |

### Business Management
| Function | Type | Description |
|----------|------|-------------|
| `businesses.list` | Query | List all businesses with owner info |
| `businesses.get` | Query | Get business by ID with owner |
| `businesses.getByOwner` | Query | Get businesses for specific owner |
| `businesses.create` | Mutation | Create business |
| `businesses.update` | Mutation | Update business |
| `businesses.updateLinesOfBusiness` | Mutation | Update LOB array |
| `businesses.addDocument` | Mutation | Add ownership document |

### Fee Management
| Function | Type | Description |
|----------|------|-------------|
| `fees.getByDivision` | Query | Get fees for a division |
| `fees.getByGroup` | Query | Get all fees for a group |
| `fees.calculateFee` | Query | Calculate single fee amount |
| `fees.calculateAllFeesForGroup` | Query | Calculate all fees for a group |
| `groups.getAllGroupFees` | Query | Get inherited + custom fees |
| `groups.setFeeOverride` | Mutation | Create/update fee override |
| `groups.createCustomFee` | Mutation | Create custom fee on group |

### Permit Applications
| Function | Type | Description |
|----------|------|-------------|
| `businessPermitApplications.list` | Query | List applications |
| `businessPermitApplications.getByStatus` | Query | Filter by status |
| `businessPermitApplications.create` | Mutation | Create application |
| `businessPermitApplications.updateStatus` | Mutation | Update status |

---

## Directory Structure Summary

```
bpls-system/
├── app/dashboard/
│   ├── businesses/           # Business CRUD
│   ├── business-owners/      # Owner CRUD
│   ├── permits/              # Permit workflow
│   │   ├── new/             # Create permit
│   │   ├── assessment/      # LOB config & fees
│   │   └── awaiting-clearances/
│   └── taxes-and-fees/       # Fee configuration
│       ├── major/           # Industry types
│       ├── division/        # Sub-categories
│       └── line-of-business/ # Groups/LOB
│
├── components/
│   ├── businesses/          # Business list components
│   ├── business/            # Business detail components
│   ├── business-owners/     # Owner components
│   ├── permit/              # Permit workflow (20+ components)
│   ├── fees/                # Fee management
│   └── ui/                  # shadcn/ui components
│
├── convex/
│   ├── schema.ts            # Database schema (22 tables)
│   ├── businessOwners.ts    # Owner queries/mutations
│   ├── businesses.ts        # Business queries/mutations
│   ├── fees.ts              # Fee queries/mutations
│   ├── groups.ts            # LOB queries/mutations
│   ├── majors.ts            # Major queries/mutations
│   ├── divisions.ts         # Division queries/mutations
│   └── businessPermitApplications.ts
│
├── lib/
│   ├── types/               # TypeScript type definitions
│   ├── schemas/             # Zod validation schemas
│   └── utils/
│       └── fee-calculator.ts # Fee calculation utilities
│
└── hooks/                   # Custom React hooks
```

---

## Technical Patterns

1. **Type Safety**: All Convex functions use validators; frontend uses TypeScript with Zod
2. **Embedded Arrays**: Businesses store LOBs, documents, and fee overrides as embedded arrays
3. **Junction Tables**: `division_groups` enables many-to-many Major→Division→Group relationships
4. **Formula Evaluation**: Safe formula eval using `Function` constructor with whitelisted variables
5. **Owner Enrichment**: Business queries automatically fetch and include owner information
6. **Status Tracking**: Applications track workflow status with timestamps and user IDs
7. **Hierarchical Locations**: Province → City → Barangay with foreign key validation

---

## Common Operations

### Creating a Business with LOBs
1. Create/select business owner
2. Create business with basic info
3. Add Lines of Business (each linked to a Group)
4. Upload ownership documents (DTI/SEC/CDA based on ownership type)

### Calculating Fees for a Business
1. For each LOB, fetch fees from linked Group
2. Apply fee calculation based on type (Constant/Range/Formula)
3. Check for per-LOB overrides, then global overrides
4. Filter out excluded fees
5. Sum total

### Processing a Permit Application
1. Select existing business owner and business
2. Application enters "Assessment" status
3. Configure LOBs with capital investment, gross sales
4. System calculates fees
5. Assessor can override/disable fees as needed
6. Submit to "Awaiting Clearances"
7. Departments review and approve/reject
8. All approved → Permit issued

---

## Improvements

### 1. Lines of Business as Standalone Table with Dual Binding

**Current Issue**: Lines of Business are embedded as an array within the `businesses` table. This creates coupling issues and makes fee override isolation difficult.

**Proposed Change**: Create a dedicated `lines_of_business` Convex table that can be linked to both:
- A **business** (master record)
- A **permit application** (when in assessment phase)

```
┌───────────────────────────────────────────────────────────────────────────┐
│                         NEW: lines_of_business TABLE                       │
├───────────────────────────────────────────────────────────────────────────┤
│  id: Id<"lines_of_business">                                               │
│  businessId: Id<"businesses">           // Link to parent business         │
│  permitApplicationId?: Id<"business_permit_applications">  // Assessment   │
│  groupId: Id<"groups">                  // The LOB category (template)     │
│  businessCategory: string                                                  │
│  capitalInvestment: number                                                 │
│  grossSales: number                                                        │
│  feeVariableMappings?: object           // Dynamic variables               │
│  excludedFees?: Id<"fees">[]                                               │
│  createdAt: string                                                         │
│  updatedAt: string                                                         │
└───────────────────────────────────────────────────────────────────────────┘
```

**Key Behavior**:
- When a permit application enters **Assessment**, the LOB record gets linked to both the business AND the permit application
- Updates to the LOB during assessment should sync bidirectionally (updating one updates the other)
- The `groups` table remains the **template** for fee definitions

### 2. Fee Override Isolation Architecture

**Current Issue**: Fee overrides can be applied at group level (LOB template) or business level, but there's no clear isolation between them.

**Proposed Change**: Create a dedicated `fee_overrides` table with explicit scope classification:

```
┌───────────────────────────────────────────────────────────────────────────┐
│                         NEW: fee_overrides TABLE                           │
├───────────────────────────────────────────────────────────────────────────┤
│  id: Id<"fee_overrides">                                                   │
│  feeId: Id<"fees">                      // The fee being overridden        │
│  scope: "group" | "business" | "lob"    // Where override applies          │
│                                                                            │
│  // Scope-specific foreign keys (only one should be set based on scope)   │
│  groupId?: Id<"groups">                 // For scope="group" (template)    │
│  businessId?: Id<"businesses">          // For scope="business"            │
│  lineOfBusinessId?: Id<"lines_of_business">  // For scope="lob"            │
│                                                                            │
│  // Override configuration                                                 │
│  overrideType: "amount" | "formula" | "range" | "disabled"                 │
│  overrideValue?: number | string | object                                  │
│  reason?: string                        // Audit trail                     │
│  createdAt: string                                                         │
│  createdBy?: string                                                        │
└───────────────────────────────────────────────────────────────────────────┘
```

**Override Scope Rules**:

| Scope | Applies To | Isolation Rule |
|-------|------------|----------------|
| `group` | Template (all businesses using this LOB category) | Changes here do NOT affect existing business-level overrides |
| `business` | Specific business (all its LOBs) | Changes here do NOT flow back to the group template |
| `lob` | Specific Line of Business instance | Most granular; applies only to this LOB on this business |

### 3. Fee Override Priority (Revised)

When calculating fees, the system should use this priority order:

```
1. LOB-level override (fee_overrides where scope="lob")
      ↓ (if not found)
2. Business-level override (fee_overrides where scope="business")
      ↓ (if not found)
3. Group template override (fee_overrides where scope="group")
      ↓ (if not found)
4. Base fee from division/group inheritance (default)
```

**Critical Isolation Principle**:
- Overriding a fee on a **business** MUST NOT modify the group template
- Overriding a fee on the **group** template MUST NOT modify existing business-level overrides
- Each scope operates independently; they never cross-contaminate

### 4. Bidirectional Sync During Assessment

When a permit application is in the **Assessment** phase:

```
┌─────────────────┐         Sync         ┌─────────────────────────┐
│    Business     │◄─────────────────────►│  Permit Application     │
│  (Master LOB)   │                       │  (Assessment LOB)       │
└─────────────────┘                       └─────────────────────────┘
        │                                           │
        │                                           │
        ▼                                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                   lines_of_business TABLE                        │
│  (Single record linked to both via businessId + permitAppId)    │
└─────────────────────────────────────────────────────────────────┘
```

**Sync Behavior**:
- The `lines_of_business` record serves as the single source of truth
- Changes made in the business detail view update the same record
- Changes made in the permit assessment view update the same record
- Both views always reflect the current state

### 5. Entity Relationship (Revised)

```
groups (Template - Fee Definitions)
    │
    │ groupId (FK)
    ▼
lines_of_business (Instance - Per Business)
    │
    ├── businessId → businesses table
    ├── permitApplicationId? → business_permit_applications (during assessment)
    │
    └── fee_overrides (scope="lob")
            │
            └── Isolated from group-level and business-level overrides

fee_overrides
    │
    ├── scope="group" → groupId (template-level, affects all new usages)
    ├── scope="business" → businessId (business-wide, all its LOBs)
    └── scope="lob" → lineOfBusinessId (specific LOB instance)
```

### 6. Migration Considerations

To implement this change:

1. Create `lines_of_business` table
2. Create `fee_overrides` table with scope field
3. Migrate existing embedded `linesOfBusiness[]` from businesses to new table
4. Migrate existing embedded `feeOverrides[]` to new table with appropriate scope
5. Update queries/mutations to use new tables
6. Update frontend components to handle bidirectional sync
7. Add validation to ensure override scope isolation
