import {
    convexAuthNextjsMiddleware, createRouteMatcher, nextjsMiddlewareRedirect
} from '@convex-dev/auth/nextjs/server';

const isPublicRoute = createRouteMatcher(["/", "/login"]);
const isProtectedRoute = createRouteMatcher(["/dashboard", "/dashboard/(.*)"]);

export default convexAuthNextjsMiddleware(async (request, { convexAuth }) => {
  const isAuthenticated = await convexAuth.isAuthenticated();

  if (isProtectedRoute(request) && !isAuthenticated) {
    return nextjsMiddlewareRedirect(request, "/login");
  }

  if (
    (request.nextUrl.pathname === "/login" ||
      request.nextUrl.pathname === "/") &&
    isAuthenticated
  ) {
    return nextjsMiddlewareRedirect(request, "/dashboard");
  }
});

export const config = {
  matcher: ["/((?!.*\\..*|_next).*)", "/", "/(api|trpc)(.*)"],
};
