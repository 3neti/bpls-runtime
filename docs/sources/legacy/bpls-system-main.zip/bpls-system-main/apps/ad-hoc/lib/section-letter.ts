/**
 * Excel-style section letter for lettered report sections:
 * 0 → "A", 1 → "B", … 25 → "Z", 26 → "AA", 27 → "AB", …
 * Shared by the on-screen ANNEX-C report and its PDF document (kept free of
 * client/server-only imports so both can use it).
 */
export function sectionLetter(index: number): string {
  let n = index;
  let s = "";
  do {
    s = String.fromCharCode(65 + (n % 26)) + s;
    n = Math.floor(n / 26) - 1;
  } while (n >= 0);
  return s;
}
