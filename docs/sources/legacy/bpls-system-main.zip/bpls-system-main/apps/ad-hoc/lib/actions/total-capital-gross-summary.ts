"use server";

import { generateTotalCapitalGrossSummary } from "@repo/clickhouse/queries/total-capital-gross-summary";
import type { ReportRow } from "@/components/reports/data-table";
import { capRows, sumNumericColumns } from "@/lib/exports/cap";
import { buildTableExport, type TableExportMeta } from "@/lib/exports/table-export";
import {
  DISPLAY_ROW_CAP,
  type ExportFormat,
  type ExportResult,
} from "@/lib/exports/types";

interface CapitalGrossSummaryParams {
  dateFrom?: string;
  dateTo?: string;
}

/**
 * One row per establishment with a completed payment in the range: owner,
 * business, per-establishment CAPITAL/GROSS totals, latest OR#/date, lifetime
 * PAYMENT AMOUNT, REMAINING BALANCE, and status. Returns the FULL (uncapped) set.
 */
async function buildCapitalGrossSummaryRows(
  params: CapitalGrossSummaryParams
): Promise<ReportRow[]> {
  const { rows } = await generateTotalCapitalGrossSummary(params);
  return rows.map((r) => ({ ...r }));
}

/** On-screen data: rows capped for the browser; totals over the full set. */
export async function fetchTotalCapitalGrossSummary(
  params: CapitalGrossSummaryParams
): Promise<{
  rows: ReportRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}> {
  const all = await buildCapitalGrossSummaryRows(params);
  const columnTotals = sumNumericColumns(all);
  const { rows, truncated, totalCount } = capRows(all, DISPLAY_ROW_CAP);
  return { rows, truncated, totalCount, columnTotals };
}

/** Full-dataset export (never capped), rendered server-side. */
export async function exportTotalCapitalGrossSummary(
  params: CapitalGrossSummaryParams,
  meta: TableExportMeta,
  format: ExportFormat
): Promise<ExportResult> {
  const rows = await buildCapitalGrossSummaryRows(params);
  return buildTableExport(meta, rows, format);
}
