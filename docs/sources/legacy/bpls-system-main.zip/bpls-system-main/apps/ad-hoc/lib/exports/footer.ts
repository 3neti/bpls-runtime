/**
 * Footer/totals row spec, shared by on-screen display (built from the server's
 * full-data column totals) and exports (built from the full rows server-side).
 * Isomorphic (no directive) so both client components and server code import it.
 */

import type { ReportRow } from "@/components/reports/data-table";

export interface FooterSpec {
  /** Column key that holds the "TOTAL" label. */
  labelKey: string;
  /** The label text (e.g. "TOTAL"). */
  label: string;
  /** Column keys to fill from the numeric totals. */
  sumKeys: string[];
}

/** Build a footer ReportRow from a spec and a full-data column-totals map. */
export function buildFooterRow(
  spec: FooterSpec,
  totals: Record<string, number>
): ReportRow {
  const row: ReportRow = { [spec.labelKey]: spec.label };
  for (const key of spec.sumKeys) row[key] = totals[key] ?? 0;
  return row;
}
