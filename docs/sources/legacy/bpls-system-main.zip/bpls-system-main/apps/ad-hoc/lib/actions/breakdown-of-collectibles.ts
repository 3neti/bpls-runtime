"use server";

import { generateBreakdownOfCollectibles } from "@repo/clickhouse/queries/breakdown-of-collectibles";
import type { ReportRow } from "@/components/reports/data-table";
import { capRows, sumNumericColumns } from "@/lib/exports/cap";
import { buildTableExport, type TableExportMeta } from "@/lib/exports/table-export";
import {
  DISPLAY_ROW_CAP,
  type ExportFormat,
  type ExportResult,
} from "@/lib/exports/types";

interface BreakdownParams {
  year: number;
}

/**
 * Full (uncapped) rows — one per establishment that still owes money for the
 * selected year. Exactly the row set the client used to build on the browser.
 */
async function buildBreakdownOfCollectiblesRows(
  params: BreakdownParams
): Promise<ReportRow[]> {
  const result = await generateBreakdownOfCollectibles(params);
  return result.rows.map((r) => ({ ...r }));
}

/** On-screen data: rows capped for the browser; totals over the full set. */
export async function fetchBreakdownOfCollectibles(params: BreakdownParams): Promise<{
  rows: ReportRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}> {
  const all = await buildBreakdownOfCollectiblesRows(params);
  const columnTotals = sumNumericColumns(all);
  const { rows, truncated, totalCount } = capRows(all, DISPLAY_ROW_CAP);
  return { rows, truncated, totalCount, columnTotals };
}

/** Full-dataset export (never capped), rendered server-side. */
export async function exportBreakdownOfCollectibles(
  params: BreakdownParams,
  meta: TableExportMeta,
  format: ExportFormat
): Promise<ExportResult> {
  const rows = await buildBreakdownOfCollectiblesRows(params);
  return buildTableExport(meta, rows, format);
}
