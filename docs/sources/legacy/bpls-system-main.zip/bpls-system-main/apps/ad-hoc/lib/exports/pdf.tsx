/**
 * Server-side PDF rendering. Runs @react-pdf/renderer's Node API
 * (`renderToBuffer`) so the entire (uncapped) report is rendered on the server
 * and only the finished file is sent to the browser — the browser never
 * materializes every row (which is what crashed the client-side PDF path).
 *
 * @react-pdf/renderer is declared in `serverExternalPackages` (next.config.mjs),
 * so it is required at runtime in Node rather than bundled.
 */

import { renderToBuffer } from "@react-pdf/renderer";
import {
  GenericTablePdfDocument,
  type GenericTablePdfProps,
} from "@/components/reports/generic-table-pdf";
import { TaxpayerAccountCardDocument } from "@/components/reports/taxpayer-account-card-pdf";
import { AnnexCDnfbpDocument } from "@/components/reports/annex-c-dnfbp-pdf";
import type { DnfbpReportData, TaxpayerCardData } from "@repo/backend/convex/reports";

/** Render the generic report table to a base64 PDF string. */
export async function renderTablePdfBase64(
  props: GenericTablePdfProps
): Promise<string> {
  const buffer = await renderToBuffer(<GenericTablePdfDocument {...props} />);
  return buffer.toString("base64");
}

/** Render the taxpayer account card to a base64 PDF string. */
export async function renderAccountCardPdfBase64(
  data: TaxpayerCardData
): Promise<string> {
  const buffer = await renderToBuffer(<TaxpayerAccountCardDocument data={data} />);
  return buffer.toString("base64");
}

/** Render the ANNEX-C DNFBP report to a base64 PDF string. */
export async function renderDnfbpPdfBase64(
  data: DnfbpReportData
): Promise<string> {
  const buffer = await renderToBuffer(<AnnexCDnfbpDocument data={data} />);
  return buffer.toString("base64");
}
