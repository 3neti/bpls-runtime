"use server";

import { generateBusinessTaxByMajor } from "@repo/clickhouse/queries/business-tax-by-major";
import type { ReportRow } from "@/components/reports/data-table";
import { capRows, sumNumericColumns } from "@/lib/exports/cap";
import { buildTableExport, type TableExportMeta } from "@/lib/exports/table-export";
import {
  DISPLAY_ROW_CAP,
  type ExportFormat,
  type ExportResult,
} from "@/lib/exports/types";

interface BusinessTaxByMajorParams {
  dateFrom?: string;
  dateTo?: string;
  orNumberFrom?: string;
  orNumberTo?: string;
}

/**
 * Full (uncapped) data rows — one per major business type. The query's trailing
 * `isTotal` grand-total row is dropped here; the totals footer is derived from
 * the summed columns (matching the former client-side behavior).
 */
async function buildBusinessTaxByMajorRows(
  params: BusinessTaxByMajorParams
): Promise<ReportRow[]> {
  const result = await generateBusinessTaxByMajor(params);
  return result.rows
    .filter((r) => !r.isTotal)
    .map((r) => ({
      majorType: r.majorType,
      amount: r.amount,
    }));
}

/** On-screen data: rows capped for the browser; totals over the full set. */
export async function fetchBusinessTaxByMajor(params: BusinessTaxByMajorParams): Promise<{
  rows: ReportRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}> {
  const all = await buildBusinessTaxByMajorRows(params);
  const columnTotals = sumNumericColumns(all);
  const { rows, truncated, totalCount } = capRows(all, DISPLAY_ROW_CAP);
  return { rows, truncated, totalCount, columnTotals };
}

/** Full-dataset export (never capped), rendered server-side. */
export async function exportBusinessTaxByMajor(
  params: BusinessTaxByMajorParams,
  meta: TableExportMeta,
  format: ExportFormat
): Promise<ExportResult> {
  const rows = await buildBusinessTaxByMajorRows(params);
  return buildTableExport(meta, rows, format);
}
