/**
 * Shared export/cap types used by both server (report actions, builders) and
 * client (download trigger, buttons). No runtime dependencies so it is safe to
 * import from either environment.
 */

export type ExportFormat = "csv" | "pdf";

export interface ExportResult {
  /** CSV text, or base64-encoded bytes when `base64` is true (PDF). */
  content: string;
  base64: boolean;
  filename: string;
  mimeType: string;
}

/**
 * On-screen row cap. The full dataset is always used for totals and for
 * downloads; only what is rendered/held in the browser is limited.
 */
export const DISPLAY_ROW_CAP = 25_000;

export interface CapMeta {
  /** True when the on-screen rows were limited to the cap. */
  truncated: boolean;
  /** Total number of rows in the full (uncapped) result. */
  totalCount: number;
}
