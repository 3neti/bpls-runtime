"use server";

import { fetchAction } from "convex/nextjs";
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import type { DnfbpReportData } from "@repo/backend/convex/reports";
import { buildTableCsv } from "@/lib/exports/csv";
import { renderDnfbpPdfBase64 } from "@/lib/exports/pdf";
import type { ExportFormat, ExportResult } from "@/lib/exports/types";
import type { ReportColumn, ReportRow } from "@/components/reports/data-table";

export interface DnfbpParams {
  categoryIds: string[];
  subCategoryIds: string[];
}

/**
 * ANNEX-C DNFBP report data. Sourced fully from Convex (businesses + permits
 * are the system of record and the classification columns are not synced to
 * ClickHouse), so newly classified businesses appear immediately.
 */
export async function fetchDnfbpReport(
  params: DnfbpParams
): Promise<DnfbpReportData> {
  const token = await convexAuthNextjsToken();
  return fetchAction(
    api.reports.getDnfbpReportData,
    {
      categoryIds: params.categoryIds as Id<"business_categories">[],
      subCategoryIds: params.subCategoryIds as Id<"business_subcategories">[],
    },
    { token: token ?? undefined }
  );
}

// CSV flattens the lettered sections into one sheet with the classification
// repeated per row; the PDF keeps the sectioned ANNEX C form layout.
const CSV_COLUMNS: ReportColumn[] = [
  { key: "category", label: "CATEGORY" },
  { key: "subCategory", label: "SUB-CATEGORY" },
  { key: "seqNo", label: "NO." },
  { key: "businessName", label: "BUSINESS NAME" },
  { key: "address", label: "ADDRESS" },
  { key: "email", label: "E-MAIL" },
  { key: "contactDetails", label: "CONTACT DETAILS" },
  { key: "permitNumber", label: "MAYOR'S PERMIT/LICENSE NO." },
  { key: "issuedOn", label: "ISSUED ON" },
];

/** Full-dataset export (CSV flat, PDF in the ANNEX C layout), server-rendered. */
export async function exportDnfbpReport(
  params: DnfbpParams,
  format: ExportFormat
): Promise<ExportResult> {
  const data = await fetchDnfbpReport(params);

  if (format === "pdf") {
    return {
      content: await renderDnfbpPdfBase64(data),
      base64: true,
      filename: "annex-c-dnfbp.pdf",
      mimeType: "application/pdf",
    };
  }

  const rows: ReportRow[] = data.sections.flatMap((section) =>
    section.rows.map((r, i) => ({
      category: section.categoryName,
      subCategory: section.subCategoryName ?? "",
      seqNo: i + 1,
      businessName: r.businessName,
      address: r.address,
      email: r.email,
      contactDetails: r.contactDetails,
      permitNumber: r.permitNumber,
      issuedOn: r.issuedOn,
    }))
  );
  return {
    content: buildTableCsv({ columns: CSV_COLUMNS, rows }),
    base64: false,
    filename: "annex-c-dnfbp.csv",
    mimeType: "text/csv;charset=utf-8;",
  };
}
