/**
 * Generic server-side export for the DataTable-based reports. A per-report
 * export action fetches the FULL (uncapped) rows and hands them here with the
 * report's column config / title / footer spec (all serializable metadata that
 * travels from the client). Produces the same CSV/PDF output the client used to
 * generate, but over the complete dataset and rendered on the server.
 */

import type { ReportColumn, ReportRow } from "@/components/reports/data-table";
import { buildTableCsv } from "./csv";
import { renderTablePdfBase64 } from "./pdf";
import { sumNumericColumns } from "./cap";
import { buildFooterRow, type FooterSpec } from "./footer";
import type { ExportFormat, ExportResult } from "./types";

export interface TableExportMeta {
  columns: ReportColumn[];
  title: string;
  orientation?: "portrait" | "landscape";
  /** When set, a totals footer row is appended (summed over the full rows). */
  footer?: FooterSpec;
  /** Filename without extension. */
  filenameBase: string;
}

export async function buildTableExport(
  meta: TableExportMeta,
  rows: ReportRow[],
  format: ExportFormat
): Promise<ExportResult> {
  const footerRow = meta.footer
    ? buildFooterRow(meta.footer, sumNumericColumns(rows))
    : undefined;

  if (format === "csv") {
    return {
      content: buildTableCsv({ columns: meta.columns, rows, footerRow }),
      base64: false,
      filename: `${meta.filenameBase}.csv`,
      mimeType: "text/csv;charset=utf-8;",
    };
  }

  const content = await renderTablePdfBase64({
    title: meta.title,
    columns: meta.columns,
    rows,
    footerRow,
    orientation: meta.orientation,
  });
  return {
    content,
    base64: true,
    filename: `${meta.filenameBase}.pdf`,
    mimeType: "application/pdf",
  };
}
