"use server";

import { generateAllAbstractReport } from "@repo/clickhouse/queries/all-abstract-report";
import { capRows } from "@/lib/exports/cap";
import { buildAbstractCsv } from "@/lib/exports/csv";
import { renderTablePdfBase64 } from "@/lib/exports/pdf";
import { abstractToTablePdf } from "@/components/reports/abstract-pdf-adapter";
import {
  DISPLAY_ROW_CAP,
  type ExportFormat,
  type ExportResult,
} from "@/lib/exports/types";

interface AbstractParams {
  dateFrom?: string;
  dateTo?: string;
  orNumberFrom?: string;
  orNumberTo?: string;
}

/**
 * On-screen data: full totals/columns (SQL-aggregated) with the row list capped
 * for the browser. `truncated`/`totalCount` drive the on-screen notice.
 */
export async function fetchAllAbstractReport(params: AbstractParams) {
  const result = await generateAllAbstractReport(params);
  const { rows, truncated, totalCount } = capRows(result.rows, DISPLAY_ROW_CAP);
  return { ...result, rows, truncated, totalCount };
}

/** Full-dataset export (never capped) rendered server-side. */
export async function exportAllAbstractReport(
  params: AbstractParams,
  format: ExportFormat
): Promise<ExportResult> {
  const result = await generateAllAbstractReport(params);
  const stamp = `${params.dateFrom || "all"}-to-${params.dateTo || "all"}`;

  if (format === "csv") {
    return {
      content: buildAbstractCsv(result),
      base64: false,
      filename: `all-abstract-report-${stamp}.csv`,
      mimeType: "text/csv;charset=utf-8;",
    };
  }

  const { columns, rows, footerRow } = abstractToTablePdf(result);
  const content = await renderTablePdfBase64({
    title: "ALL ABSTRACT REPORT",
    columns,
    rows,
    footerRow,
    orientation: "landscape",
  });
  return {
    content,
    base64: true,
    filename: `all-abstract-report-${stamp}.pdf`,
    mimeType: "application/pdf",
  };
}
