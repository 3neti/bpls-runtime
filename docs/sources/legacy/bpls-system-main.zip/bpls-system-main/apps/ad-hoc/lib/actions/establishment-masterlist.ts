"use server";

import { fetchAction } from "convex/nextjs";
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import { generateEstablishmentMasterlist } from "@repo/clickhouse/queries/establishment-masterlist";
import { capRows, sumNumericColumns } from "@/lib/exports/cap";
import {
  PERIOD_KEYS,
  allocateAcrossLines,
  mapSectionTaxToPeriods,
  periodPlanFor,
  type PeriodKey,
} from "@/lib/reports/masterlist-allocation";
import { buildTableExport, type TableExportMeta } from "@/lib/exports/table-export";
import {
  DISPLAY_ROW_CAP,
  type ExportFormat,
  type ExportResult,
} from "@/lib/exports/types";

/**
 * One row per LINE OF BUSINESS. SEQ. NO. and OR NUMBER repeat across an
 * application's lines; CAPITAL / GROSS / BUSINESS TAX / REGULATORY FEES are
 * per line. AMOUNT = BUSINESS TAX + REGULATORY FEES. In paid mode the amounts
 * are the fees-only portion of the cash received — surcharge/interest embedded
 * in late payments are excluded — with the BUSINESS TAX cash additionally
 * broken out by installment period (paidQ1..paidAnnual). Period columns that
 * don't exist for the row's mode of payment hold the literal string "N/A".
 */
export interface MasterlistLineRow {
  // Index signature so a row is consumable as the generic table's ReportRow.
  [key: string]: string | number;
  applicationId: string;
  seqNo: number;
  ownerName: string;
  businessName: string;
  lineOfBusiness: string;
  businessAddress: string;
  capitalInvestment: number;
  grossSales: number;
  /** Full assessed BUSINESS TAX for this line (not scaled to cash). */
  computedBusinessTax: number;
  modeOfPayment: string;
  orNumber: string;
  businessTax: number;
  regulatoryFees: number;
  amount: number;
  /** PAID BUSINESS TAX by period — number, or "N/A" when the period doesn't apply to the mode. */
  paidQ1: number | string;
  paidQ2: number | string;
  paidQ3: number | string;
  paidQ4: number | string;
  paidSem1: number | string;
  paidSem2: number | string;
  paidAnnual: number | string;
}

interface MasterlistParams {
  mode: "paid" | "unpaid";
  dateFrom?: string;
  dateTo?: string;
  orNumberFrom?: string;
  orNumberTo?: string;
}

/**
 * Hybrid masterlist: ClickHouse selects which applications are paid/unpaid in
 * the date/OR# range (owner, business, complete address, mode, OR#), then the
 * Convex fee engine recomputes per-line BUSINESS TAX and REGULATORY FEES (which
 * ClickHouse can't derive). Each qualifying application is expanded into one row
 * per line of business. Returns the FULL (uncapped) set.
 */
async function buildMasterlistRows(
  params: MasterlistParams
): Promise<MasterlistLineRow[]> {
  const { rows: apps } = await generateEstablishmentMasterlist(params);
  if (apps.length === 0) return [];

  // Recompute per-line fees in Convex, chunked to bound each action call.
  const token = await convexAuthNextjsToken();
  const appIds = apps.map(
    (a) => a.applicationId as Id<"business_permit_applications">
  );
  const linesByApp = new Map<
    string,
    Array<{
      lineOfBusiness: string;
      capitalInvestment: number;
      grossSales: number;
      businessTax: number;
      regulatoryFees: number;
    }>
  >();
  const CHUNK = 300;
  for (let i = 0; i < appIds.length; i += CHUNK) {
    const chunk = appIds.slice(i, i + CHUNK);
    const { lines } = await fetchAction(
      api.reports.computeMasterlistLines,
      { applicationIds: chunk },
      { token: token ?? undefined }
    );
    for (const line of lines) {
      const list = linesByApp.get(line.applicationId);
      if (list) list.push(line);
      else linesByApp.set(line.applicationId, [line]);
    }
  }

  // Expand to one row per line, assigning a per-application SEQ. NO. in the
  // ClickHouse order. Applications with no resolvable lines keep a single row.
  //
  // PAID list: payments are recorded at the application level (one consolidated
  // OR#), never per line of business, so we ALLOCATE each application's paid
  // cash across its lines. ClickHouse splits the fees-only cash (surcharge/
  // interest excluded — penalty charges, not fees) into its BUSINESS TAX part
  // per schedule section and its regulatory remainder; the tax cash of each
  // period is allocated across lines in proportion to assessed BUSINESS TAX,
  // the regulatory cash in proportion to assessed REGULATORY FEES. Period
  // columns that don't exist for the mode of payment read "N/A". UNPAID list
  // is unchanged (assessed fees = total due).
  const round2 = (n: number) => Math.round(n * 100) / 100;
  const isPaid = params.mode === "paid";

  const rows: MasterlistLineRow[] = [];
  let seqNo = 0;
  for (const app of apps) {
    seqNo += 1;
    const base = {
      applicationId: app.applicationId,
      seqNo,
      ownerName: app.ownerName,
      businessName: app.businessName,
      businessAddress: app.businessAddress,
      modeOfPayment: app.modeOfPayment,
      orNumber: app.orNumber,
    };
    const paidAmount = isPaid ? Number(app.feesPaid) || 0 : 0;
    const lines = linesByApp.get(app.applicationId) ?? [];

    // Period layout for this application's mode of payment, and the tax cash
    // received per period (zeroed for the unpaid list, where nothing is paid).
    const plan = periodPlanFor(app.modeOfPayment, Number(app.schedCount) || 0);
    const periodTax = mapSectionTaxToPeriods(plan, [
      isPaid ? Number(app.taxPaidS1) || 0 : 0,
      isPaid ? Number(app.taxPaidS2) || 0 : 0,
      isPaid ? Number(app.taxPaidS3) || 0 : 0,
      isPaid ? Number(app.taxPaidS4) || 0 : 0,
    ]);
    const regPaid = isPaid ? Number(app.regPaid) || 0 : 0;
    // A row's period cells: cash for applicable periods, "N/A" otherwise.
    const periodCells = (valueOf: (p: PeriodKey) => number) => {
      const cells = {} as Record<PeriodKey, number | string>;
      for (const p of PERIOD_KEYS) {
        cells[p] = plan.applicable.has(p) ? round2(valueOf(p)) : "N/A";
      }
      return cells;
    };

    if (lines.length === 0) {
      // No resolvable lines: keep one row carrying the application-level cash
      // so it isn't dropped from the period / AMOUNT columns and totals.
      const periodTaxTotal = PERIOD_KEYS.reduce((s, p) => s + periodTax[p], 0);
      rows.push({
        ...base,
        lineOfBusiness: "",
        capitalInvestment: app.capitalInvestment,
        grossSales: app.grossSales,
        computedBusinessTax: 0,
        businessTax: round2(periodTaxTotal),
        regulatoryFees: round2(regPaid),
        amount: isPaid ? round2(paidAmount) : 0,
        ...periodCells((p) => periodTax[p]),
      });
      continue;
    }

    // Allocation bases: assessed BUSINESS TAX drives the period tax cash,
    // assessed REGULATORY FEES drives the regulatory cash (each falls back to
    // an even split when nothing is assessed — see allocateAcrossLines).
    const taxWeights = lines.map((l) => l.businessTax);
    const regWeights = lines.map((l) => l.regulatoryFees);
    const taxShares = {} as Record<PeriodKey, number[]>;
    for (const p of PERIOD_KEYS) {
      taxShares[p] = allocateAcrossLines(periodTax[p], taxWeights);
    }
    const regShares = allocateAcrossLines(regPaid, regWeights);

    const appRows: MasterlistLineRow[] = lines.map((line, i) => {
      // Paid list: cash figures. Unpaid list: assessed figures (total due).
      const businessTax = isPaid
        ? round2(PERIOD_KEYS.reduce((s, p) => s + taxShares[p][i], 0))
        : round2(line.businessTax);
      const regulatoryFees = isPaid
        ? regShares[i]
        : round2(line.regulatoryFees);
      return {
        ...base,
        lineOfBusiness: line.lineOfBusiness,
        capitalInvestment: line.capitalInvestment,
        grossSales: line.grossSales,
        computedBusinessTax: round2(line.businessTax),
        businessTax,
        regulatoryFees,
        amount: round2(businessTax + regulatoryFees),
        ...periodCells((p) => taxShares[p][i]),
      };
    });

    // Penny reconciliation: per-period and regulatory shares already tie to
    // their own totals, but summing the rounded parts can still drift a cent
    // from the fees-only paid total — put the residual on the last line
    // (bumping REGULATORY FEES too so AMOUNT = TAX + REG keeps holding).
    if (isPaid && appRows.length > 0) {
      const summed = appRows.reduce((s, r) => s + r.amount, 0);
      const residual = round2(paidAmount - summed);
      if (residual !== 0) {
        const last = appRows[appRows.length - 1];
        last.amount = round2(last.amount + residual);
        last.regulatoryFees = round2(last.regulatoryFees + residual);
      }
    }

    rows.push(...appRows);
  }
  return rows;
}

/** On-screen data: rows capped for the browser; totals over the full set. */
export async function fetchEstablishmentMasterlist(params: MasterlistParams): Promise<{
  rows: MasterlistLineRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}> {
  const all = await buildMasterlistRows(params);
  const columnTotals = sumNumericColumns(all);
  const { rows, truncated, totalCount } = capRows(all, DISPLAY_ROW_CAP);
  return { rows, truncated, totalCount, columnTotals };
}

/** Full-dataset export (never capped), rendered server-side. */
export async function exportEstablishmentMasterlist(
  params: MasterlistParams,
  meta: TableExportMeta,
  format: ExportFormat
): Promise<ExportResult> {
  const rows = await buildMasterlistRows(params);
  return buildTableExport(meta, rows, format);
}
