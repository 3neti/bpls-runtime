/**
 * Pure period-mapping and per-line allocation math for the Paid Masterlist.
 * Kept out of the "use server" action module (whose exports must be async
 * server actions) so the logic stays plain, importable, and testable.
 */

/** Row keys of the PAID BUSINESS TAX period columns, in display order. */
export const PERIOD_KEYS = [
  "paidQ1",
  "paidQ2",
  "paidQ3",
  "paidQ4",
  "paidSem1",
  "paidSem2",
  "paidAnnual",
] as const;

export type PeriodKey = (typeof PERIOD_KEYS)[number];

export interface PeriodPlan {
  /** Period columns that exist for this mode of payment. */
  applicable: ReadonlySet<PeriodKey>;
  /** Column that each schedule section's (1-4) tax cash lands in. */
  sectionKey: readonly [PeriodKey, PeriodKey, PeriodKey, PeriodKey];
}

const QUARTERLY_PLAN: PeriodPlan = {
  applicable: new Set(["paidQ1", "paidQ2", "paidQ3", "paidQ4"]),
  sectionKey: ["paidQ1", "paidQ2", "paidQ3", "paidQ4"],
};

// Sections beyond the mode's period count collapse into the last period so no
// cash is dropped (e.g. a stray section 3 on a semi-annual application).
const SEMI_ANNUAL_PLAN: PeriodPlan = {
  applicable: new Set(["paidSem1", "paidSem2"]),
  sectionKey: ["paidSem1", "paidSem2", "paidSem2", "paidSem2"],
};

const ANNUAL_PLAN: PeriodPlan = {
  applicable: new Set(["paidAnnual"]),
  sectionKey: ["paidAnnual", "paidAnnual", "paidAnnual", "paidAnnual"],
};

/**
 * Which period columns apply to a mode of payment ("Quarterly",
 * "Semi-Annually", "Annually"). Unrecognized/blank modes fall back to the
 * schedule count (4 sections = quarterly, 2 = semi-annual, 1 = annual).
 */
export function periodPlanFor(
  modeOfPayment: string,
  schedCount: number
): PeriodPlan {
  const mode = (modeOfPayment || "").toLowerCase();
  if (mode.includes("quarter")) return QUARTERLY_PLAN;
  if (mode.includes("semi")) return SEMI_ANNUAL_PLAN;
  if (mode.includes("annu")) return ANNUAL_PLAN;
  if (schedCount >= 3) return QUARTERLY_PLAN;
  if (schedCount === 2) return SEMI_ANNUAL_PLAN;
  return ANNUAL_PLAN;
}

/** Tax cash per period column: schedule sections folded in via the plan. */
export function mapSectionTaxToPeriods(
  plan: PeriodPlan,
  taxPaidBySection: readonly [number, number, number, number]
): Record<PeriodKey, number> {
  const byPeriod = {} as Record<PeriodKey, number>;
  for (const key of PERIOD_KEYS) byPeriod[key] = 0;
  taxPaidBySection.forEach((paid, i) => {
    byPeriod[plan.sectionKey[i]] += paid;
  });
  return byPeriod;
}

const round2 = (n: number) => Math.round(n * 100) / 100;

/**
 * Split `total` across lines in proportion to `weights` (assessed fees), each
 * share rounded to centavos with the rounding residual folded into the LAST
 * line so the shares sum exactly to round2(total). Zero/negative total weight
 * (cash but nothing assessed) falls back to an even split.
 */
export function allocateAcrossLines(
  total: number,
  weights: readonly number[]
): number[] {
  if (weights.length === 0) return [];
  const basis = weights.reduce((s, w) => s + w, 0);
  const shares = weights.map((w) =>
    round2(total * (basis > 0 ? w / basis : 1 / weights.length))
  );
  const summed = shares.reduce((s, v) => s + v, 0);
  const residual = round2(round2(total) - round2(summed));
  if (residual !== 0) {
    shares[shares.length - 1] = round2(shares[shares.length - 1] + residual);
  }
  return shares;
}
