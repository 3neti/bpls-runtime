"use server";

import { fetchAction } from "convex/nextjs";
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import {
  generatePlds,
  type PldsRow,
  type PldsParams,
} from "@repo/clickhouse/queries/plds";
import { categoryColumnsReady } from "@repo/clickhouse/queries/_category";
import { capRows, sumNumericColumns } from "@/lib/exports/cap";
import {
  buildTableExport,
  type TableExportMeta,
} from "@/lib/exports/table-export";
import {
  DISPLAY_ROW_CAP,
  type ExportFormat,
  type ExportResult,
} from "@/lib/exports/types";

export type { PldsRow };

/**
 * Build the FULL (uncapped) PLDS Template rows directly from ClickHouse.
 * No Convex enrichment needed — all columns resolve from ClickHouse tables.
 *
 * The mainEconomicActivity and majorProductServices columns are blank until
 * `businesses.categoryId/subCategoryId` and the `business_categories` /
 * `business_subcategories` tables sync to ClickHouse (Airbyte, after Part B
 * deploy). Once all four schema objects are present, they self-activate with
 * live values — no code changes required. The readiness gate below is
 * preserved unchanged: it is evaluated on every build so both the on-screen
 * fetch and the export honor the same schema state.
 */
async function buildPldsRows(params: PldsParams): Promise<PldsRow[]> {
  const categoriesAvailable = await categoryColumnsReady();
  const { rows } = await generatePlds(params, categoriesAvailable);
  if (rows.length === 0) return rows;

  // ASSETS = billed amount of the Unit-of-Measurement-driven line-of-business
  // fee. ClickHouse can't resolve feeVariableMappings.feeId → fee name → billed
  // amount, so Convex fills it (chunked to bound each action call).
  const token = await convexAuthNextjsToken();
  const appIds = rows.map(
    (r) => r.applicationId as Id<"business_permit_applications">
  );
  const assetsByApp = new Map<string, number>();
  const CHUNK = 300;
  for (let i = 0; i < appIds.length; i += CHUNK) {
    const chunk = appIds.slice(i, i + CHUNK);
    const { results } = await fetchAction(
      api.reports.computeUomAssetsByApplication,
      { applicationIds: chunk },
      { token: token ?? undefined }
    );
    for (const r of results) assetsByApp.set(r.applicationId, r.assets);
  }
  for (const row of rows) {
    row.assets = assetsByApp.get(row.applicationId) ?? 0;
  }
  return rows;
}

/** On-screen data: rows capped for the browser; totals over the full set. */
export async function fetchPlds(params: PldsParams): Promise<{
  rows: PldsRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}> {
  const all = await buildPldsRows(params);
  const columnTotals = sumNumericColumns(all);
  const { rows, truncated, totalCount } = capRows(all, DISPLAY_ROW_CAP);
  return { rows, truncated, totalCount, columnTotals };
}

/** Full-dataset export (never capped), rendered server-side. */
export async function exportPlds(
  params: PldsParams,
  meta: TableExportMeta,
  format: ExportFormat
): Promise<ExportResult> {
  const rows = await buildPldsRows(params);
  return buildTableExport(meta, rows, format);
}
