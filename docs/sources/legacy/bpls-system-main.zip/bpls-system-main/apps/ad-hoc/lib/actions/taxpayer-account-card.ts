"use server";

import { fetchAction } from "convex/nextjs";
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import {
  listTaxpayerBusinesses,
  type TaxpayerBusinessListParams,
} from "@repo/clickhouse/queries/taxpayer-account-card";
import type { TaxpayerCardYearRow } from "@repo/backend/convex/reports";
import { capRows } from "@/lib/exports/cap";
import { buildTableCsv } from "@/lib/exports/csv";
import { renderAccountCardPdfBase64 } from "@/lib/exports/pdf";
import {
  DISPLAY_ROW_CAP,
  type ExportFormat,
  type ExportResult,
} from "@/lib/exports/types";
import type { ReportColumn, ReportRow } from "@/components/reports/data-table";

export async function fetchTaxpayerBusinesses(
  params: TaxpayerBusinessListParams = {}
) {
  const { rows } = await listTaxpayerBusinesses(params);
  return capRows(rows, DISPLAY_ROW_CAP);
}

/**
 * The account card now sources per-Kind-of-Business figures from the Convex fee
 * engine (ClickHouse can't recompute per-line tax/regulatory fees). Returns one
 * card per Kind of Business for the given business.
 */
export async function fetchTaxpayerAccountCard(params: { businessId: string }) {
  const token = await convexAuthNextjsToken();
  return fetchAction(
    api.reports.getTaxpayerCardData,
    { businessId: params.businessId as Id<"businesses"> },
    { token: token ?? undefined }
  );
}

const ACCOUNT_CARD_CSV_COLUMNS: ReportColumn[] = [
  { key: "kindOfBusiness", label: "KIND OF BUSINESS" },
  { key: "year", label: "YEAR" },
  { key: "annualTax", label: "ANNUAL TAX", currency: true },
  { key: "q1Receipt", label: "1ST QTR OR#" },
  { key: "q1Amount", label: "1ST QTR AMOUNT", currency: true },
  { key: "q2Receipt", label: "2ND QTR OR#" },
  { key: "q2Amount", label: "2ND QTR AMOUNT", currency: true },
  { key: "q3Receipt", label: "3RD QTR OR#" },
  { key: "q3Amount", label: "3RD QTR AMOUNT", currency: true },
  { key: "q4Receipt", label: "4TH QTR OR#" },
  { key: "q4Amount", label: "4TH QTR AMOUNT", currency: true },
  { key: "finesPenalties", label: "FINES/PENALTIES", currency: true },
  { key: "regulatoryFees", label: "REGULATORY FEES", currency: true },
  { key: "total", label: "TOTAL", currency: true },
  { key: "dateLicenseIssued", label: "DATE LICENSE ISSUED" },
];

function toAccountCardCsvRow(
  kindOfBusiness: string,
  r: TaxpayerCardYearRow
): ReportRow {
  return {
    kindOfBusiness,
    year: r.year,
    annualTax: r.annualTax,
    q1Receipt: r.q1.receipt,
    q1Amount: r.q1.amount,
    q2Receipt: r.q2.receipt,
    q2Amount: r.q2.amount,
    q3Receipt: r.q3.receipt,
    q3Amount: r.q3.amount,
    q4Receipt: r.q4.receipt,
    q4Amount: r.q4.amount,
    finesPenalties: r.finesPenalties,
    regulatoryFees: r.regulatoryFees,
    total: r.total,
    dateLicenseIssued: r.dateLicenseIssued,
  };
}

/**
 * Full account-card export rendered server-side. CSV flattens every card's
 * year rows; PDF renders the multi-card account-card document via react-pdf on
 * the server (removing the former client-side @react-pdf/renderer path).
 */
export async function exportTaxpayerAccountCard(
  businessId: string,
  format: ExportFormat
): Promise<ExportResult> {
  const data = await fetchTaxpayerAccountCard({ businessId });
  const safeName =
    data.businessName.replace(/[^a-z0-9]+/gi, "-").replace(/^-+|-+$/g, "") ||
    "taxpayer";

  if (format === "pdf") {
    return {
      content: await renderAccountCardPdfBase64(data),
      base64: true,
      filename: `taxpayer-card-${safeName}.pdf`,
      mimeType: "application/pdf",
    };
  }

  const rows = data.cards.flatMap((card) =>
    card.rows.map((r) => toAccountCardCsvRow(card.kindOfBusiness, r))
  );
  return {
    content: buildTableCsv({ columns: ACCOUNT_CARD_CSV_COLUMNS, rows }),
    base64: false,
    filename: `taxpayer-card-${safeName}.csv`,
    mimeType: "text/csv;charset=utf-8;",
  };
}
