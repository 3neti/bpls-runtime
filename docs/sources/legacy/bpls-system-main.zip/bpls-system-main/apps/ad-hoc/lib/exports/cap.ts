/**
 * Server-side helpers for the display safety cap. The cap only limits what the
 * browser renders/holds; totals are always computed over the FULL result set
 * (before capping) so on-screen figures and downloads stay correct.
 */

import type { ReportRow } from "@/components/reports/data-table";
import { DISPLAY_ROW_CAP, type CapMeta } from "./types";

/**
 * Cap an array of rows for on-screen display. Pass `limit = undefined` to get
 * the full set unchanged (used by the export path).
 */
export function capRows<T>(
  rows: T[],
  limit: number | undefined = DISPLAY_ROW_CAP
): { rows: T[] } & CapMeta {
  const totalCount = rows.length;
  if (limit != null && totalCount > limit) {
    return { rows: rows.slice(0, limit), truncated: true, totalCount };
  }
  return { rows, truncated: false, totalCount };
}

/**
 * Sum every finite-numeric field across ALL rows. Callers pick the keys they
 * need for their footer/totals row, so extra sums are harmless. Compute this on
 * the full set BEFORE capping so totals never reflect only the displayed rows.
 */
export function sumNumericColumns(rows: ReportRow[]): Record<string, number> {
  const totals: Record<string, number> = {};
  for (const row of rows) {
    for (const key in row) {
      const value = row[key];
      const n = typeof value === "number" ? value : Number(value);
      if (Number.isFinite(n)) totals[key] = (totals[key] ?? 0) + n;
    }
  }
  return totals;
}
