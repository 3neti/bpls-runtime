"use server";

import {
  generateCmciLdcs,
  type CmciLdcsRow,
  type CmciLdcsParams,
} from "@repo/clickhouse/queries/cmci-ldcs";
import { capRows, sumNumericColumns } from "@/lib/exports/cap";
import {
  buildTableExport,
  type TableExportMeta,
} from "@/lib/exports/table-export";
import {
  DISPLAY_ROW_CAP,
  type ExportFormat,
  type ExportResult,
} from "@/lib/exports/types";

export type { CmciLdcsRow };

/**
 * Build the FULL (uncapped) CMCI LDCS Annex B rows directly from ClickHouse.
 * No Convex enrichment needed — all columns resolve from ClickHouse tables.
 */
async function buildCmciLdcsRows(
  params: CmciLdcsParams
): Promise<CmciLdcsRow[]> {
  const { rows } = await generateCmciLdcs(params);
  return rows;
}

/** On-screen data: rows capped for the browser; totals over the full set. */
export async function fetchCmciLdcs(params: CmciLdcsParams): Promise<{
  rows: CmciLdcsRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}> {
  const all = await buildCmciLdcsRows(params);
  const columnTotals = sumNumericColumns(all);
  const { rows, truncated, totalCount } = capRows(all, DISPLAY_ROW_CAP);
  return { rows, truncated, totalCount, columnTotals };
}

/** Full-dataset export (never capped), rendered server-side. */
export async function exportCmciLdcs(
  params: CmciLdcsParams,
  meta: TableExportMeta,
  format: ExportFormat
): Promise<ExportResult> {
  const rows = await buildCmciLdcsRows(params);
  return buildTableExport(meta, rows, format);
}
