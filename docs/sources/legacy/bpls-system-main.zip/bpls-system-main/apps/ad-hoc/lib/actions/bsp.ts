"use server";

import {
  generateBsp,
  type BspRow,
  type BspParams,
} from "@repo/clickhouse/queries/bsp";
import { categoryColumnsReady } from "@repo/clickhouse/queries/_category";
import { capRows, sumNumericColumns } from "@/lib/exports/cap";
import {
  buildTableExport,
  type TableExportMeta,
} from "@/lib/exports/table-export";
import {
  DISPLAY_ROW_CAP,
  type ExportFormat,
  type ExportResult,
} from "@/lib/exports/types";

export type { BspRow };

export interface BspReportRow extends BspRow {
  /** Sequential number assigned after the query, 1-based. */
  no: number;
}

/**
 * Build the FULL (uncapped) BSP Non-Bank Entities rows from ClickHouse and
 * assign sequential "No." numbers.
 *
 * The category schema readiness gate (`categoryColumnsReady()`) is evaluated
 * on every build so the on-screen fetch and the export honor the same schema
 * state (it returns 0 rows without touching missing columns if the sync ever
 * regresses). Coverage defaults to "Money Service Business"; the optional
 * categoryIds/subCategoryIds params narrow/override it — see BspParams.
 */
async function buildBspRows(params: BspParams): Promise<BspReportRow[]> {
  const categoriesAvailable = await categoryColumnsReady();
  const { rows } = await generateBsp(params, categoriesAvailable);

  // Assign sequential No. numbers.
  return rows.map((row, i) => ({ ...row, no: i + 1 }));
}

/** On-screen data: rows capped for the browser; totals over the full set. */
export async function fetchBsp(params: BspParams): Promise<{
  rows: BspReportRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}> {
  const all = await buildBspRows(params);
  const columnTotals = sumNumericColumns(all);
  const { rows, truncated, totalCount } = capRows(all, DISPLAY_ROW_CAP);
  return { rows, truncated, totalCount, columnTotals };
}

/** Full-dataset export (never capped), rendered server-side. */
export async function exportBsp(
  params: BspParams,
  meta: TableExportMeta,
  format: ExportFormat
): Promise<ExportResult> {
  const rows = await buildBspRows(params);
  return buildTableExport(meta, rows, format);
}
