"use server";

import {
  generateTopEstablishmentsTaxDue,
  type TopTaxDueParams,
} from "@repo/clickhouse/queries/top-establishments-tax-due";
import type { ReportRow } from "@/components/reports/data-table";
import { capRows, sumNumericColumns } from "@/lib/exports/cap";
import { buildTableExport, type TableExportMeta } from "@/lib/exports/table-export";
import {
  DISPLAY_ROW_CAP,
  type ExportFormat,
  type ExportResult,
} from "@/lib/exports/types";

/**
 * The top 100 establishments ranked by the chosen metric, each with owner,
 * business, address, gross sales, payment frequency, assessed Tax Due, Tax Paid,
 * Balance, latest OR#/date. Rank is assigned by ordered position (the query
 * already sorts + limits to 100). Returns the FULL (uncapped) set.
 */
async function buildTopTaxDueRows(
  params: TopTaxDueParams
): Promise<ReportRow[]> {
  const { rows } = await generateTopEstablishmentsTaxDue(params);
  return rows.map((r, i) => ({ rank: i + 1, ...r }));
}

/** On-screen data: rows capped for the browser; totals over the full set. */
export async function fetchTopEstablishmentsTaxDue(
  params: TopTaxDueParams
): Promise<{
  rows: ReportRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}> {
  const all = await buildTopTaxDueRows(params);
  const columnTotals = sumNumericColumns(all);
  const { rows, truncated, totalCount } = capRows(all, DISPLAY_ROW_CAP);
  return { rows, truncated, totalCount, columnTotals };
}

/** Full-dataset export (never capped), rendered server-side. */
export async function exportTopEstablishmentsTaxDue(
  params: TopTaxDueParams,
  meta: TableExportMeta,
  format: ExportFormat
): Promise<ExportResult> {
  const rows = await buildTopTaxDueRows(params);
  return buildTableExport(meta, rows, format);
}
