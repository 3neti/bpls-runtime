/**
 * Server-safe CSV builders (pure string output, no DOM). Extracted from the
 * former client-side csv-export.ts / generic-csv.ts so the same output can be
 * produced server-side over the FULL dataset.
 */

import type { ReportColumn, ReportRow } from "@/components/reports/data-table";

const BOM = String.fromCharCode(0xfeff); // UTF-8 BOM for Excel

function escapeCSV(value: string): string {
  if (value.includes(",") || value.includes('"') || value.includes("\n")) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

function cell(col: ReportColumn, row: ReportRow): string {
  const value = row[col.key];
  if (value === undefined || value === null || value === "") return "";
  if (col.csvFormat === "peso") {
    const n = typeof value === "number" ? value : Number(value);
    // Non-numeric text (e.g. "N/A") passes through money columns as-is.
    return Number.isFinite(n)
      ? n.toLocaleString("en-PH", {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        })
      : String(value);
  }
  if (col.csvFormat === "plain") {
    const n = typeof value === "number" ? value : Number(value);
    return Number.isFinite(n) ? String(n) : String(value);
  }
  if (col.currency) {
    const n = typeof value === "number" ? value : Number(value);
    return Number.isFinite(n) ? n.toFixed(2) : String(value);
  }
  return String(value);
}

/** Generic table CSV (header, rows, optional footer). Mirrors generic-csv.ts. */
export function buildTableCsv({
  columns,
  rows,
  footerRow,
}: {
  columns: ReportColumn[];
  rows: ReportRow[];
  footerRow?: ReportRow;
}): string {
  const lines: string[] = [];
  // Optional banner row above the header: each column group's label appears on
  // the group's first column, mirroring the merged on-screen/PDF group header.
  if (columns.some((c) => c.group)) {
    lines.push(
      columns
        .map((c, i) =>
          c.group && c.group !== columns[i - 1]?.group ? escapeCSV(c.group) : ""
        )
        .join(",")
    );
  }
  lines.push(columns.map((c) => escapeCSV(c.label)).join(","));
  for (const row of rows) {
    lines.push(columns.map((c) => escapeCSV(cell(c, row))).join(","));
  }
  if (footerRow) {
    lines.push(columns.map((c) => escapeCSV(cell(c, footerRow))).join(","));
  }
  return BOM + lines.join("\n");
}

/**
 * Abstract report CSV (top "Total" row, blank separator, then data). Mirrors the
 * exact layout of the former csv-export.ts so downloads are unchanged.
 */
export function buildAbstractCsv({
  columns,
  rows,
  totals,
  grandTotal,
}: {
  columns: string[];
  rows: Array<{
    orNumber: string;
    payorName: string;
    fees: Record<string, number>;
    total: number;
  }>;
  totals: Record<string, number>;
  grandTotal: number;
}): string {
  const allColumns = [...columns, "TOTAL"];
  const lines: string[] = [];

  lines.push(allColumns.map(escapeCSV).join(","));

  const totalsRow = allColumns.map((col) => {
    if (col === "OR #") return escapeCSV("Total");
    if (col === "NAME OF PAYOR") return "";
    if (col === "TOTAL") return grandTotal.toFixed(2);
    return (totals[col] ?? 0) !== 0 ? (totals[col] ?? 0).toFixed(2) : "-";
  });
  lines.push(totalsRow.join(","));

  lines.push("");

  for (const row of rows) {
    const csvRow = allColumns.map((col) => {
      if (col === "OR #") return escapeCSV(row.orNumber);
      if (col === "NAME OF PAYOR") return escapeCSV(row.payorName);
      if (col === "TOTAL") return row.total !== 0 ? row.total.toFixed(2) : "-";
      const val = row.fees[col] ?? 0;
      return val !== 0 ? val.toFixed(2) : "-";
    });
    lines.push(csvRow.join(","));
  }

  return lines.join("\n");
}
