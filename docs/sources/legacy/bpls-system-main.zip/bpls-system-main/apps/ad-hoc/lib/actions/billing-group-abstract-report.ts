"use server";

import { generateBillingGroupAbstractReport } from "@repo/clickhouse/queries/billing-group-abstract-report";
import { capRows } from "@/lib/exports/cap";
import { buildAbstractCsv } from "@/lib/exports/csv";
import { renderTablePdfBase64 } from "@/lib/exports/pdf";
import { abstractToTablePdf } from "@/components/reports/abstract-pdf-adapter";
import {
  DISPLAY_ROW_CAP,
  type ExportFormat,
  type ExportResult,
} from "@/lib/exports/types";

interface BillingGroupAbstractParams {
  billingGroupId: string;
  dateFrom?: string;
  dateTo?: string;
  orNumberFrom?: string;
  orNumberTo?: string;
}

/**
 * On-screen data: full totals/columns (SQL-aggregated) with the row list capped
 * for the browser. `truncated`/`totalCount` drive the on-screen notice.
 */
export async function fetchBillingGroupAbstractReport(
  params: BillingGroupAbstractParams
) {
  const result = await generateBillingGroupAbstractReport(params);
  const { rows, truncated, totalCount } = capRows(result.rows, DISPLAY_ROW_CAP);
  return { ...result, rows, truncated, totalCount };
}

/**
 * Full-dataset export (never capped) rendered server-side. `groupName` supplies
 * the group-specific title/filename (the action only receives the group id).
 */
export async function exportBillingGroupAbstractReport(
  params: BillingGroupAbstractParams & { groupName: string },
  format: ExportFormat
): Promise<ExportResult> {
  const { groupName, ...queryParams } = params;
  const result = await generateBillingGroupAbstractReport(queryParams);
  const stamp = `${params.dateFrom || "all"}-to-${params.dateTo || "all"}`;
  const safeName = groupName.replace(/[^a-z0-9]+/gi, "-").toLowerCase();

  if (format === "csv") {
    return {
      content: buildAbstractCsv(result),
      base64: false,
      filename: `abstract-report-${safeName}-${stamp}.csv`,
      mimeType: "text/csv;charset=utf-8;",
    };
  }

  const { columns, rows, footerRow } = abstractToTablePdf(result);
  const content = await renderTablePdfBase64({
    title: `${groupName.toUpperCase()} ABSTRACT REPORT`,
    columns,
    rows,
    footerRow,
    orientation: "landscape",
  });
  return {
    content,
    base64: true,
    filename: `abstract-report-${safeName}-${stamp}.pdf`,
    mimeType: "application/pdf",
  };
}
