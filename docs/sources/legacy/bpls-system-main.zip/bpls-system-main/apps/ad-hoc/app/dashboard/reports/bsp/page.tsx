import { BspReport } from "@/components/reports/bsp";

export default function BspPage() {
  return <BspReport />;
}
