import { PldsReport } from "@/components/reports/plds";

export default function PldsPage() {
  return <PldsReport />;
}
