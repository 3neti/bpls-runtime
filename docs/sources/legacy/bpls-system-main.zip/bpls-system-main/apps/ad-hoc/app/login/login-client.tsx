"use client";

import { usePreloadedQuery } from "convex/react";
import type { Preloaded } from "convex/react";
import { Building2 } from "lucide-react";
import { api } from "@repo/backend/convex/_generated/api";
import { LoginForm } from "@/components/login-form";

const DEFAULT_PLATFORM_NAME = "BPLS Portal";

interface LoginClientProps {
  preloadedSettings: Preloaded<typeof api.platformSettings.get>;
  preloadedLogoUrl: Preloaded<typeof api.platformSettings.getLogoUrl>;
}

export default function LoginClient({
  preloadedSettings,
  preloadedLogoUrl,
}: LoginClientProps) {
  const settings = usePreloadedQuery(preloadedSettings);
  const logoUrl = usePreloadedQuery(preloadedLogoUrl);

  const platformName = settings?.platformName ?? DEFAULT_PLATFORM_NAME;

  return (
    <div className="min-h-svh flex items-center justify-center bg-muted/40 p-6">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center gap-2 mb-8">
          <div className="flex items-center gap-2">
            <div className="flex size-9 items-center justify-center">
              {logoUrl ? (
                <img
                  src={logoUrl}
                  alt="Platform Logo"
                  className="size-9 object-contain"
                />
              ) : (
                <div className="size-9 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Building2 className="size-5 text-primary" />
                </div>
              )}
            </div>
            <span className="text-lg font-semibold">{platformName}</span>
          </div>
          <p className="text-sm text-muted-foreground">Ad-Hoc Reporting Dashboard</p>
        </div>

        <LoginForm platformName={platformName} />
      </div>
    </div>
  );
}
