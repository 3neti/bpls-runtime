import type React from "react";
import type { Metadata } from "next";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import { ConvexAuthNextjsServerProvider } from "@convex-dev/auth/nextjs/server";

import "./globals.css";

import { ConvexClientProvider } from "@/providers/convex-provider";
import { Toaster } from "@repo/ui/components/toaster";

import { ThemeProvider } from "next-themes";

export const metadata: Metadata = {
  title: "Ad-Hoc Reports - BPLS",
  description: "Ad-Hoc Reporting Dashboard for Business Permit & Licensing System",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <ConvexAuthNextjsServerProvider>
      <html lang="en" suppressHydrationWarning className={`antialiased`}>
        <body>
          <ConvexClientProvider>
            <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
              {children}
              <Toaster />
            </ThemeProvider>
          </ConvexClientProvider>
        </body>
      </html>
    </ConvexAuthNextjsServerProvider>
  );
}
