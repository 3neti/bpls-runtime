import Link from "next/link"
import {
  ClipboardCheck,
  ClipboardX,
  Coins,
  IdCard,
  Landmark,
  Layers,
  Trophy,
  Wallet,
} from "lucide-react"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card"

interface ReportTemplate {
  title: string
  description: string
  href: string
  icon: React.ComponentType<{ className?: string }>
}

const reportTemplates: ReportTemplate[] = [
  {
    title: "All Abstract Report",
    description:
      "Combined abstract of all permit application payments and every billing group, by OR number with fee breakdowns",
    href: "/dashboard/reports/all-abstract",
    icon: Layers,
  },
  {
    title: "Masterlist for Paid Establishment",
    description:
      "Establishments whose business-permit fees are fully settled, with owner, capital, gross sales, OR number, and amount paid",
    href: "/dashboard/reports/masterlist-paid",
    icon: ClipboardCheck,
  },
  {
    title: "Masterlist for Unpaid Establishment",
    description:
      "Establishments with an outstanding business-permit balance, with owner, capital, gross sales, and amount still owed",
    href: "/dashboard/reports/masterlist-unpaid",
    icon: ClipboardX,
  },
  {
    title: "Breakdown of Collectibles",
    description:
      "Remaining balance summary — outstanding permit fees per establishment broken down by quarter for a selected year",
    href: "/dashboard/reports/collectibles",
    icon: Wallet,
  },
  {
    title: "Business Tax on Major Type",
    description:
      "Collected business tax totaled by major business type (Retailer, Dealer, Manufacturer, etc.) — surcharge and interest excluded",
    href: "/dashboard/reports/business-tax-major",
    icon: Landmark,
  },
  {
    title: "Top 100 Establishments (Tax Due)",
    description:
      "The 100 highest-ranking establishments by tax — owner, gross sales, assessed tax due, tax paid, and balance — filterable by year, month, or date range and rankable by tax due, tax paid, or total paid",
    href: "/dashboard/reports/top-establishments-tax-due",
    icon: Trophy,
  },
  {
    title: "Taxpayer's Account Card",
    description:
      "Per-taxpayer ledger — a printable year-by-year account card of annual tax, quarterly receipts, fines, and regulatory fees for one establishment",
    href: "/dashboard/reports/taxpayer-card",
    icon: IdCard,
  },
  {
    title: "Total Capital and Gross Summary",
    description:
      "Total capital and gross sales for establishments paying within a date range, with OR number, payment date, amount paid, and remaining balance",
    href: "/dashboard/reports/capital-gross-summary",
    icon: Coins,
  },
]

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">
          Report Templates
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Select a report template to generate and export data.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {reportTemplates.map((template) => (
          <Link key={template.href} href={template.href} className="group">
            <Card className="h-full transition-shadow hover:shadow-md">
              <CardHeader className="pb-3">
                <div className="mb-3 flex size-10 items-center justify-center rounded-lg bg-primary/10">
                  <template.icon className="size-5 text-primary" />
                </div>
                <CardTitle className="text-base">{template.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>{template.description}</CardDescription>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}
