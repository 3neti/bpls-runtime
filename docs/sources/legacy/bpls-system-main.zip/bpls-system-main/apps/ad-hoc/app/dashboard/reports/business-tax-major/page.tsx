import { BusinessTaxByMajor } from "@/components/reports/business-tax-by-major";

export default function BusinessTaxMajorPage() {
  return <BusinessTaxByMajor />;
}
