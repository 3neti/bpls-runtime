import { redirect } from "next/navigation";
import { fetchQuery, preloadQuery } from "convex/nextjs";
import { api } from "@repo/backend/convex/_generated/api";
import LoginClient from "./login-client";

export default async function LoginPage() {
  const [isOnboarded, hasUsers] = await Promise.all([
    fetchQuery(api.platformSettings.isOnboarded, {}),
    fetchQuery(api.users.hasUsers, {}),
  ]);

  // Ad-hoc app requires an already-onboarded platform with existing users.
  // If not set up, show login anyway – they'll get an auth error.
  if (!isOnboarded || !hasUsers) {
    // Just proceed to render the login form - it will show a helpful error
  }

  const [preloadedSettings, preloadedLogoUrl] = await Promise.all([
    preloadQuery(api.platformSettings.get, {}),
    preloadQuery(api.platformSettings.getLogoUrl, {}),
  ]);

  return (
    <LoginClient
      preloadedSettings={preloadedSettings}
      preloadedLogoUrl={preloadedLogoUrl}
    />
  );
}
