import { BillingGroupAbstractReport } from "@/components/reports/billing-group-abstract-report";

export default async function BillingGroupAbstractReportPage({
  params,
}: {
  params: Promise<{ billingGroupId: string }>;
}) {
  const { billingGroupId } = await params;
  return <BillingGroupAbstractReport billingGroupId={billingGroupId} />;
}
