import { EstablishmentMasterlist } from "@/components/reports/establishment-masterlist";

export default function MasterlistUnpaidPage() {
  return <EstablishmentMasterlist variant="unpaid" />;
}
