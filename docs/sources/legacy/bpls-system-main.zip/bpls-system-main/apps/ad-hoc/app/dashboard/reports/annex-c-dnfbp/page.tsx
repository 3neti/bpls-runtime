import { AnnexCDnfbpReport } from "@/components/reports/annex-c-dnfbp";

export default function AnnexCDnfbpPage() {
  return <AnnexCDnfbpReport />;
}
