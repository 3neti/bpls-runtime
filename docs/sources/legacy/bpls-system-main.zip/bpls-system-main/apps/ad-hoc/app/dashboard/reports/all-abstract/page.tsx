import { AllAbstractReport } from "@/components/reports/all-abstract-report";

export default function AllAbstractReportPage() {
  return <AllAbstractReport />;
}
