import { CmciLdcsReport } from "@/components/reports/cmci-ldcs";

export default function CmciLdcsPage() {
  return <CmciLdcsReport />;
}
