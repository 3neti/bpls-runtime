import { TotalCapitalGrossSummary } from "@/components/reports/total-capital-gross-summary";

export default function CapitalGrossSummaryPage() {
  return <TotalCapitalGrossSummary />;
}
