import { EstablishmentMasterlist } from "@/components/reports/establishment-masterlist";

export default function MasterlistPaidPage() {
  return <EstablishmentMasterlist variant="paid" />;
}
