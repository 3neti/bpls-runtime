import { BreakdownOfCollectibles } from "@/components/reports/breakdown-of-collectibles";

export default function CollectiblesPage() {
  return <BreakdownOfCollectibles />;
}
