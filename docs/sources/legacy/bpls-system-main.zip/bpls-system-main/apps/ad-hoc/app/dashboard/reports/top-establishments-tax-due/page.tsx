import { TopEstablishmentsTaxDue } from "@/components/reports/top-establishments-tax-due";

export default function TopEstablishmentsTaxDuePage() {
  return <TopEstablishmentsTaxDue />;
}
