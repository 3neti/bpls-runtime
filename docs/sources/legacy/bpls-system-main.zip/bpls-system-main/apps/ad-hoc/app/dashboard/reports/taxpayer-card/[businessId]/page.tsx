import { TaxpayerAccountCard } from "@/components/reports/taxpayer-account-card";

export default async function TaxpayerCardDetailPage({
  params,
}: {
  params: Promise<{ businessId: string }>;
}) {
  const { businessId } = await params;
  return <TaxpayerAccountCard businessId={businessId} />;
}
