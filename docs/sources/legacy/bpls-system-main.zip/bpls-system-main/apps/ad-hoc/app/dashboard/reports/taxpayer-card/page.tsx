import { TaxpayerCardList } from "@/components/reports/taxpayer-card-list";

export default function TaxpayerCardPage() {
  return <TaxpayerCardList />;
}
