"use client";

import {
  memo,
  useCallback,
  useMemo,
  useRef,
  type CSSProperties,
  type ReactNode,
} from "react";
import { useVirtualizer } from "@tanstack/react-virtual";
import { cn } from "@/lib/utils";

/**
 * A column that is always rendered and pinned (position: sticky) to the left or
 * right edge of the scroll area. Pinned columns sit OUTSIDE the horizontal
 * virtualization window so they never scroll away.
 */
export interface VirtualPinnedColumn<Row> {
  id: string;
  width: number;
  /** Body cell content. */
  render: (row: Row) => ReactNode;
  /** Header cell content, one entry per header row (index-aligned with `headerRows`). */
  header: ReactNode[];
  /** Footer cell content (only used when a `footer` is provided). */
  footer?: ReactNode;
}

/**
 * A "middle" column. In wide mode these are horizontally virtualized; in narrow
 * mode they are all rendered. Body content is derived via `getValue` (kept as a
 * primitive so the cell can be memoized).
 */
export interface VirtualMiddleColumn<Row> {
  id: string;
  width: number;
  getValue: (row: Row) => string;
  /** Extra classes for the body cell's content span (alignment / font). */
  cellClassName?: string;
}

export interface VirtualHeaderRow {
  /** `<tr>` className (row background). */
  className?: string;
  /** Extra classes for the sticky pinned `<th>` — MUST carry an opaque background matching the row. */
  stickyClassName?: string;
  /** Content of a middle column's `<th>` for this header row. */
  renderMiddle: (columnId: string) => ReactNode;
  /**
   * Optional column grouping for this header row: consecutive middle columns
   * mapped to the same non-empty key are merged into a single `<th colSpan>`,
   * rendered via `renderMiddle(firstColumnIdOfTheGroup)`. Columns mapped to
   * undefined stay individual cells. Only reliable when columns are NOT
   * horizontally virtualized (the fluid DataTable layout) — under
   * virtualization only the currently visible part of a group merges.
   */
  middleGroupOf?: (columnId: string) => string | undefined;
}

export interface VirtualFooter {
  className?: string;
  stickyClassName?: string;
  renderMiddle: (columnId: string) => ReactNode;
}

export interface VirtualTableProps<Row> {
  rows: Row[];
  /** Stable React key per row (defaults to the row index — fine for static report data). */
  getRowKey?: (row: Row, index: number) => string;

  pinnedLeft?: VirtualPinnedColumn<Row>[];
  pinnedRight?: VirtualPinnedColumn<Row>[];
  middleColumns: VirtualMiddleColumn<Row>[];

  headerRows: VirtualHeaderRow[];
  footer?: VirtualFooter;

  onRowClick?: (row: Row) => void;
  rowClassName?: string;
  emptyMessage: string;

  /**
   * "fixed" — content-width table with `table-layout: fixed`, explicit per-cell
   * widths, and horizontal column virtualization past the threshold. Required
   * for pinned columns (sticky offsets depend on exact widths). Used by the wide
   * abstract report.
   * "fluid" — full-width table with auto layout and `minWidth` hints (columns
   * grow to fill the container); no column virtualization. Used by the narrow
   * DataTable reports. Defaults to "fixed".
   */
  columnLayout?: "fixed" | "fluid";

  rowHeight?: number;
  rowOverscan?: number;
  columnOverscan?: number;
  /** Above this many middle columns, columns are virtualized (fixed layout only). */
  columnVirtualizationThreshold?: number;

  maxHeight?: string;
  /** The "N records" line under the table. */
  footerNote?: ReactNode;
  className?: string;
}

const DEFAULT_ROW_HEIGHT = 34;
const DEFAULT_ROW_OVERSCAN = 8;
const DEFAULT_COLUMN_OVERSCAN = 3;
const DEFAULT_COLUMN_VIRTUALIZATION_THRESHOLD = 30;

function fixedWidth(width: number): CSSProperties {
  return { width, minWidth: width, maxWidth: width };
}

/**
 * Fold columns into header cells for one header row: consecutive columns that
 * `groupOf` maps to the same non-empty key collapse into one cell spanning
 * them all (width = the members' combined width). No `groupOf` (the common
 * case) yields one cell per column, exactly as before.
 */
function headerSegments<Row>(
  cols: VirtualMiddleColumn<Row>[],
  groupOf?: (columnId: string) => string | undefined
): Array<{ col: VirtualMiddleColumn<Row>; span: number; width: number }> {
  if (!groupOf) return cols.map((col) => ({ col, span: 1, width: col.width }));
  const segments: Array<{
    col: VirtualMiddleColumn<Row>;
    span: number;
    width: number;
  }> = [];
  let i = 0;
  while (i < cols.length) {
    const col = cols[i];
    const group = groupOf(col.id);
    let span = 1;
    while (
      group &&
      i + span < cols.length &&
      groupOf(cols[i + span].id) === group
    ) {
      span++;
    }
    let width = 0;
    for (let k = i; k < i + span; k++) width += cols[k].width;
    segments.push({ col, span, width });
    i += span;
  }
  return segments;
}

function spacerStyle(width: number): CSSProperties {
  return { ...fixedWidth(width), padding: 0, border: "none" };
}

/** Memoized middle body cell — pure in (value, width, fixed, className, height). */
const MiddleBodyCell = memo(function MiddleBodyCell({
  value,
  width,
  fixed,
  height,
  cellClassName,
}: {
  value: string;
  width: number;
  fixed: boolean;
  height: number;
  cellClassName?: string;
}) {
  return (
    <td
      className="border px-3 py-0 whitespace-nowrap"
      style={{ ...(fixed ? fixedWidth(width) : { minWidth: width }), height }}
    >
      <span className={cellClassName}>{value}</span>
    </td>
  );
});

export function VirtualTable<Row>({
  rows,
  getRowKey,
  pinnedLeft = [],
  pinnedRight = [],
  middleColumns,
  headerRows,
  footer,
  onRowClick,
  rowClassName,
  emptyMessage,
  columnLayout = "fixed",
  rowHeight = DEFAULT_ROW_HEIGHT,
  rowOverscan = DEFAULT_ROW_OVERSCAN,
  columnOverscan = DEFAULT_COLUMN_OVERSCAN,
  columnVirtualizationThreshold = DEFAULT_COLUMN_VIRTUALIZATION_THRESHOLD,
  maxHeight = "calc(100vh - 280px)",
  footerNote,
  className,
}: VirtualTableProps<Row>) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const fixed = columnLayout === "fixed";

  // In fixed layout every cell gets an exact width; in fluid layout width is a
  // grow-from hint so columns fill the container (matches the legacy DataTable).
  const widthStyle = useCallback(
    (width: number): CSSProperties =>
      fixed ? fixedWidth(width) : { minWidth: width },
    [fixed]
  );

  const virtualizeColumns =
    fixed && middleColumns.length > columnVirtualizationThreshold;

  // Prefix-sum offsets for pinned columns (left grows from 0; right grows from 0 at the far edge).
  const { pinnedLeftWidth, pinnedRightWidth, leftOffsets, rightOffsets } =
    useMemo(() => {
      const lOff: number[] = [];
      let lAcc = 0;
      for (const col of pinnedLeft) {
        lOff.push(lAcc);
        lAcc += col.width;
      }
      const rOff: number[] = new Array(pinnedRight.length);
      let rAcc = 0;
      for (let i = pinnedRight.length - 1; i >= 0; i--) {
        rOff[i] = rAcc;
        rAcc += pinnedRight[i].width;
      }
      return {
        pinnedLeftWidth: lAcc,
        pinnedRightWidth: rAcc,
        leftOffsets: lOff,
        rightOffsets: rOff,
      };
    }, [pinnedLeft, pinnedRight]);

  const middleWidthTotal = useMemo(
    () => middleColumns.reduce((sum, c) => sum + c.width, 0),
    [middleColumns]
  );

  const rowVirtualizer = useVirtualizer({
    count: rows.length,
    getScrollElement: () => scrollRef.current,
    estimateSize: useCallback(() => rowHeight, [rowHeight]),
    overscan: rowOverscan,
  });

  const columnVirtualizer = useVirtualizer({
    horizontal: true,
    count: virtualizeColumns ? middleColumns.length : 0,
    getScrollElement: () => scrollRef.current,
    estimateSize: useCallback(
      (i: number) => middleColumns[i].width,
      [middleColumns]
    ),
    overscan: columnOverscan,
  });

  const virtualRows = rowVirtualizer.getVirtualItems();
  const virtualCols = columnVirtualizer.getVirtualItems();
  const totalRowHeight = rowVirtualizer.getTotalSize();

  const middleTotalWidth = virtualizeColumns
    ? columnVirtualizer.getTotalSize()
    : middleWidthTotal;

  const leftSpacer =
    virtualizeColumns && virtualCols.length > 0 ? virtualCols[0].start : 0;
  const rightSpacer =
    virtualizeColumns && virtualCols.length > 0
      ? middleTotalWidth - virtualCols[virtualCols.length - 1].end
      : 0;

  const visibleMiddle = virtualizeColumns
    ? virtualCols.map((vc) => middleColumns[vc.index])
    : middleColumns;

  const tableWidth = pinnedLeftWidth + middleTotalWidth + pinnedRightWidth;

  const renderedColCount =
    pinnedLeft.length +
    (leftSpacer > 0 ? 1 : 0) +
    visibleMiddle.length +
    (rightSpacer > 0 ? 1 : 0) +
    pinnedRight.length;

  const totalColCount =
    pinnedLeft.length + middleColumns.length + pinnedRight.length;

  const pinnedThClass =
    "border px-3 py-2 text-xs font-semibold whitespace-nowrap sticky z-30";
  const pinnedTdClass =
    "border px-3 py-0 whitespace-nowrap sticky z-10 bg-background group-hover:bg-muted/50";

  return (
    <div
      className={cn("rounded-md border flex flex-col", className)}
      style={{ maxHeight }}
    >
      <div ref={scrollRef} className="overflow-auto flex-1">
        <table
          className="text-sm border-collapse"
          style={
            fixed
              ? { tableLayout: "fixed", width: tableWidth }
              : { width: "100%" }
          }
        >
          <thead className="sticky top-0 z-20">
            {headerRows.map((hr, rowIndex) => (
              <tr key={rowIndex} className={hr.className}>
                {pinnedLeft.map((col, i) => (
                  <th
                    key={col.id}
                    className={cn(pinnedThClass, hr.stickyClassName)}
                    style={{ ...fixedWidth(col.width), left: leftOffsets[i] }}
                  >
                    {col.header[rowIndex]}
                  </th>
                ))}

                {leftSpacer > 0 && <th aria-hidden style={spacerStyle(leftSpacer)} />}

                {headerSegments(visibleMiddle, hr.middleGroupOf).map(
                  ({ col, span, width }) => (
                    <th
                      key={col.id}
                      colSpan={span > 1 ? span : undefined}
                      className="border px-3 py-2 text-xs font-semibold whitespace-nowrap"
                      style={widthStyle(width)}
                    >
                      {hr.renderMiddle(col.id)}
                    </th>
                  )
                )}

                {rightSpacer > 0 && (
                  <th aria-hidden style={spacerStyle(rightSpacer)} />
                )}

                {pinnedRight.map((col, i) => (
                  <th
                    key={col.id}
                    className={cn(pinnedThClass, hr.stickyClassName)}
                    style={{ ...fixedWidth(col.width), right: rightOffsets[i] }}
                  >
                    {col.header[rowIndex]}
                  </th>
                ))}
              </tr>
            ))}
          </thead>

          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td
                  colSpan={totalColCount}
                  className="border px-3 py-8 text-center text-sm text-muted-foreground"
                >
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              <>
                {virtualRows.length > 0 && virtualRows[0].start > 0 && (
                  <tr aria-hidden="true">
                    <td
                      colSpan={renderedColCount}
                      style={{
                        height: virtualRows[0].start,
                        padding: 0,
                        border: "none",
                      }}
                    />
                  </tr>
                )}

                {virtualRows.map((virtualRow) => {
                  const row = rows[virtualRow.index];
                  return (
                    <tr
                      key={getRowKey ? getRowKey(row, virtualRow.index) : virtualRow.index}
                      data-index={virtualRow.index}
                      className={cn(
                        "group",
                        rowClassName ?? "hover:bg-muted/50",
                        onRowClick && "cursor-pointer"
                      )}
                      style={{ height: rowHeight }}
                      onClick={onRowClick ? () => onRowClick(row) : undefined}
                    >
                      {pinnedLeft.map((col, i) => (
                        <td
                          key={col.id}
                          className={pinnedTdClass}
                          style={{
                            ...fixedWidth(col.width),
                            left: leftOffsets[i],
                            height: rowHeight,
                          }}
                        >
                          {col.render(row)}
                        </td>
                      ))}

                      {leftSpacer > 0 && (
                        <td aria-hidden style={spacerStyle(leftSpacer)} />
                      )}

                      {visibleMiddle.map((col) => (
                        <MiddleBodyCell
                          key={col.id}
                          value={col.getValue(row)}
                          width={col.width}
                          fixed={fixed}
                          height={rowHeight}
                          cellClassName={col.cellClassName}
                        />
                      ))}

                      {rightSpacer > 0 && (
                        <td aria-hidden style={spacerStyle(rightSpacer)} />
                      )}

                      {pinnedRight.map((col, i) => (
                        <td
                          key={col.id}
                          className={pinnedTdClass}
                          style={{
                            ...fixedWidth(col.width),
                            right: rightOffsets[i],
                            height: rowHeight,
                          }}
                        >
                          {col.render(row)}
                        </td>
                      ))}
                    </tr>
                  );
                })}

                {virtualRows.length > 0 && (
                  <tr aria-hidden="true">
                    <td
                      colSpan={renderedColCount}
                      style={{
                        height: Math.max(
                          0,
                          totalRowHeight - virtualRows[virtualRows.length - 1].end
                        ),
                        padding: 0,
                        border: "none",
                      }}
                    />
                  </tr>
                )}
              </>
            )}
          </tbody>

          {footer && rows.length > 0 && (
            <tfoot className="sticky bottom-0 z-20">
              <tr className={footer.className}>
                {pinnedLeft.map((col, i) => (
                  <td
                    key={col.id}
                    className={cn(
                      "border px-3 py-2 text-xs whitespace-nowrap sticky z-30",
                      footer.stickyClassName
                    )}
                    style={{ ...fixedWidth(col.width), left: leftOffsets[i] }}
                  >
                    {col.footer}
                  </td>
                ))}

                {leftSpacer > 0 && <td aria-hidden style={spacerStyle(leftSpacer)} />}

                {visibleMiddle.map((col) => (
                  <td
                    key={col.id}
                    className="border px-3 py-2 text-xs whitespace-nowrap"
                    style={widthStyle(col.width)}
                  >
                    {footer.renderMiddle(col.id)}
                  </td>
                ))}

                {rightSpacer > 0 && <td aria-hidden style={spacerStyle(rightSpacer)} />}

                {pinnedRight.map((col, i) => (
                  <td
                    key={col.id}
                    className={cn(
                      "border px-3 py-2 text-xs whitespace-nowrap sticky z-30",
                      footer.stickyClassName
                    )}
                    style={{ ...fixedWidth(col.width), right: rightOffsets[i] }}
                  >
                    {col.footer}
                  </td>
                ))}
              </tr>
            </tfoot>
          )}
        </table>
      </div>

      {footerNote != null && (
        <div className="border-t px-3 py-1.5 text-xs text-muted-foreground bg-muted/30 shrink-0">
          {footerNote}
        </div>
      )}
    </div>
  );
}
