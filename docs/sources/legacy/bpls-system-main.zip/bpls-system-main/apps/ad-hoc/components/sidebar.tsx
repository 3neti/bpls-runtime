"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useQuery } from "convex/react"
import { useConvexAuth } from "convex/react"
import { useAuthActions } from "@convex-dev/auth/react"
import {
  Banknote,
  Building2,
  ClipboardCheck,
  ClipboardX,
  FileSpreadsheet,
  FileText,
  Gauge,
  Home,
  IdCard,
  Landmark,
  Layers,
  LogOut,
  ShieldCheck,
  Trophy,
  Wallet,
} from "lucide-react"
import { api } from "@repo/backend/convex/_generated/api"
import { Button } from "@repo/ui/components/button"
import { cn } from "@/lib/utils"

interface NavItem {
  label: string
  href: string
  icon: React.ComponentType<{ className?: string }>
}

const navItems: NavItem[] = [
  {
    label: "Dashboard",
    href: "/dashboard",
    icon: Home,
  },
  {
    label: "All Abstract Report",
    href: "/dashboard/reports/all-abstract",
    icon: Layers,
  },
  {
    label: "Paid Masterlist",
    href: "/dashboard/reports/masterlist-paid",
    icon: ClipboardCheck,
  },
  {
    label: "Unpaid Masterlist",
    href: "/dashboard/reports/masterlist-unpaid",
    icon: ClipboardX,
  },
  {
    label: "Collectibles",
    href: "/dashboard/reports/collectibles",
    icon: Wallet,
  },
  {
    label: "Business Tax by Major",
    href: "/dashboard/reports/business-tax-major",
    icon: Landmark,
  },
  {
    label: "Top 100 Tax Due",
    href: "/dashboard/reports/top-establishments-tax-due",
    icon: Trophy,
  },
  {
    label: "Taxpayer Account Card",
    href: "/dashboard/reports/taxpayer-card",
    icon: IdCard,
  },
  {
    label: "CMCI LDCS",
    href: "/dashboard/reports/cmci-ldcs",
    icon: Gauge,
  },
  {
    label: "PLDS Template",
    href: "/dashboard/reports/plds",
    icon: FileText,
  },
  {
    label: "BSP Report",
    href: "/dashboard/reports/bsp",
    icon: Banknote,
  },
  {
    label: "ANNEX-C DNFBP",
    href: "/dashboard/reports/annex-c-dnfbp",
    icon: ShieldCheck,
  },
]

export function AppSidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const { isAuthenticated } = useConvexAuth()
  const { signOut } = useAuthActions()

  const platformSettings = useQuery(api.platformSettings.get)
  const logoUrl = useQuery(api.platformSettings.getLogoUrl)
  const currentUser = useQuery(api.users.getCurrentUser)
  const billingGroups = useQuery(api.billingGroups.list, {
    includeInactive: false,
    includeDeleted: false,
  })

  const platformName = platformSettings?.platformName ?? "BPLS Portal"
  const effectiveLogoUrl = logoUrl ?? null

  const handleLogout = async () => {
    await signOut()
    router.push("/login")
  }

  const userName = currentUser
    ? `${currentUser.firstName} ${currentUser.lastName}`
    : null
  const userEmail = currentUser?.email ?? null

  return (
    <aside className="flex h-full w-60 flex-col border-r bg-sidebar">
      {/* Logo / Platform name */}
      <div className="flex h-16 items-center gap-3 border-b px-4">
        {effectiveLogoUrl ? (
          <img
            src={effectiveLogoUrl}
            alt="Platform Logo"
            className="size-8 shrink-0 object-contain"
          />
        ) : (
          <div className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-primary/10">
            <Building2 className="size-5 text-primary" />
          </div>
        )}
        <span className="truncate text-sm font-semibold">{platformName}</span>
      </div>

      {/* Navigation */}
      <nav className="flex flex-1 flex-col gap-1 p-3">
        {navItems.map((item) => {
          // Exact-match the dashboard so its link isn't always active.
          const isActive =
            item.href === "/dashboard"
              ? pathname === item.href
              : pathname.startsWith(item.href)

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                isActive
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              )}
            >
              <item.icon className="size-4 shrink-0" />
              {item.label}
            </Link>
          )
        })}

        {/* Per–billing-group abstract reports (mapped over existing groups) */}
        {billingGroups && billingGroups.length > 0 && (
          <div className="mt-2">
            <p className="px-3 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70">
              Abstract by Billing Group
            </p>
            {billingGroups.map((group) => {
              const href = `/dashboard/reports/abstract/${group._id}`
              const isActive = pathname === href

              return (
                <Link
                  key={group._id}
                  href={href}
                  className={cn(
                    "flex items-center gap-3 rounded-md py-2 pl-9 pr-3 text-sm font-medium transition-colors",
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                  )}
                >
                  <FileSpreadsheet className="size-4 shrink-0" />
                  <span className="truncate">{group.name}</span>
                </Link>
              )
            })}
          </div>
        )}
      </nav>

      {/* User info + logout */}
      {isAuthenticated && (
        <div className="border-t p-3">
          <div className="mb-2 px-3">
            {userName && (
              <p className="truncate text-sm font-medium">{userName}</p>
            )}
            {userEmail && (
              <p className="truncate text-xs text-muted-foreground">
                {userEmail}
              </p>
            )}
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start gap-2 text-muted-foreground hover:text-foreground"
            onClick={handleLogout}
          >
            <LogOut className="size-4" />
            Log out
          </Button>
        </div>
      )}
    </aside>
  )
}
