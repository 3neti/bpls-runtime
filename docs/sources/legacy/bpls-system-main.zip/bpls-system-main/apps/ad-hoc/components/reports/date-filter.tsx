"use client";

import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { DatePicker } from "@repo/ui/components/date-picker";
import { Download, Loader2, Play } from "lucide-react";
import type { ReactNode } from "react";

interface DateFilterProps {
  dateFrom: string;
  dateTo: string;
  orNumberFrom: string;
  orNumberTo: string;
  onDateFromChange: (value: string) => void;
  onDateToChange: (value: string) => void;
  onOrNumberFromChange: (value: string) => void;
  onOrNumberToChange: (value: string) => void;
  onGenerate: () => void;
  onExport: () => void;
  isLoading: boolean;
  hasData: boolean;
  /** Extra action buttons rendered after Export CSV (e.g. Download PDF). */
  extraActions?: ReactNode;
}

export function DateFilter({
  dateFrom,
  dateTo,
  orNumberFrom,
  orNumberTo,
  onDateFromChange,
  onDateToChange,
  onOrNumberFromChange,
  onOrNumberToChange,
  onGenerate,
  onExport,
  isLoading,
  hasData,
  extraActions,
}: DateFilterProps) {
  return (
    <div className="flex flex-wrap items-end gap-4">
      <div className="grid gap-1.5">
        <Label className="text-xs">Date From</Label>
        <DatePicker
          value={dateFrom}
          onChange={onDateFromChange}
          placeholder="Start date"
          className="w-44"
        />
      </div>
      <div className="grid gap-1.5">
        <Label className="text-xs">Date To</Label>
        <DatePicker
          value={dateTo}
          onChange={onDateToChange}
          placeholder="End date"
          className="w-44"
        />
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="or-from" className="text-xs">
          OR # From
        </Label>
        <Input
          id="or-from"
          type="text"
          value={orNumberFrom}
          onChange={(e) => onOrNumberFromChange(e.target.value)}
          placeholder="e.g. 8753500"
          className="w-36"
        />
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="or-to" className="text-xs">
          OR # To
        </Label>
        <Input
          id="or-to"
          type="text"
          value={orNumberTo}
          onChange={(e) => onOrNumberToChange(e.target.value)}
          placeholder="e.g. 8753600"
          className="w-36"
        />
      </div>
      <Button onClick={onGenerate} disabled={isLoading}>
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Generating...
          </>
        ) : (
          <>
            <Play className="mr-2 h-4 w-4" />
            Generate
          </>
        )}
      </Button>
      <Button
        variant="outline"
        onClick={onExport}
        disabled={!hasData || isLoading}
      >
        <Download className="mr-2 h-4 w-4" />
        Export CSV
      </Button>
      {extraActions}
    </div>
  );
}
