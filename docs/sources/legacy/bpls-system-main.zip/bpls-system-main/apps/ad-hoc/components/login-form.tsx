"use client";

import type React from "react";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useConvexAuth, useConvex } from "convex/react";
import { useAuthActions } from "@convex-dev/auth/react";
import { Loader2, Eye, EyeOff } from "lucide-react";
import { cn } from "@/lib/utils";
import { api } from "@repo/backend/convex/_generated/api";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@repo/ui/components/card";

interface LoginFormProps extends React.ComponentProps<"div"> {
  platformName?: string;
}

export function LoginForm({
  className,
  platformName = "BPLS Portal",
  ...props
}: LoginFormProps) {
  const router = useRouter();
  const { isAuthenticated } = useConvexAuth();
  const { signIn, signOut } = useAuthActions();
  const convex = useConvex();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isAuthenticated) {
      router.push("/dashboard");
    }
  }, [isAuthenticated, router]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      const formData = new FormData();
      formData.append("email", email);
      formData.append("password", password);
      formData.append("flow", "signIn");

      await signIn("password", formData);

      // Allow auth state to propagate before querying the user
      await new Promise((resolve) => setTimeout(resolve, 500));

      const user = await convex.query(api.users.getCurrentUser);

      if (user?.userType === "citizen") {
        await signOut();
        setError("Access restricted to administrators only.");
        setIsSubmitting(false);
        return;
      }

      if (user?.status === "Inactive") {
        await signOut();
        setError("Your account has been deactivated. Please contact an administrator.");
        setIsSubmitting(false);
        return;
      }

      router.push("/dashboard");
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Authentication failed";
      const errorString = errorMessage.toLowerCase();

      if (
        errorString.includes("invalid email or password") ||
        errorString.includes("invalid password") ||
        errorString.includes("incorrect password") ||
        errorString.includes("wrong password") ||
        errorString.includes("invalidaccountid") ||
        errorString.includes("invalid account") ||
        errorString.includes("account not found") ||
        errorString.includes("user not found") ||
        errorString.includes("no account") ||
        errorString.includes("retrieveaccount")
      ) {
        setError("Invalid email or password. Please try again.");
      } else if (
        errorString.includes("already exists") ||
        errorString.includes("email in use") ||
        errorString.includes("duplicate")
      ) {
        setError("Please try signing in with your existing account.");
      } else if (
        errorString.includes("network") ||
        errorString.includes("connection") ||
        errorString.includes("timeout")
      ) {
        setError(
          "Connection error. Please check your internet connection and try again."
        );
      } else if (
        errorString.includes("rate limit") ||
        errorString.includes("too many")
      ) {
        setError("Too many attempts. Please wait a moment and try again.");
      } else if (
        errorString.includes("deactivated") ||
        errorString.includes("inactive") ||
        errorString.includes("disabled")
      ) {
        setError("Your account has been deactivated. Please contact an administrator.");
      } else {
        console.error("Authentication error:", errorMessage);
        setError(
          "Unable to sign in. Please check your credentials and try again."
        );
      }

      setIsSubmitting(false);
    }
  };

  return (
    <div className={cn("w-full", className)} {...props}>
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="text-xl">Sign in to {platformName}</CardTitle>
          <CardDescription>
            Enter your administrator credentials to continue
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            {error && (
              <div className="p-3 text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md">
                {error}
              </div>
            )}

            <div className="grid gap-3">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="admin@example.gov.ph"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={isSubmitting}
                autoComplete="email"
              />
            </div>

            <div className="grid gap-3">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  disabled={isSubmitting}
                  autoComplete="current-password"
                  className="pr-10"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                  disabled={isSubmitting}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <Eye className="h-4 w-4 text-muted-foreground" />
                  )}
                  <span className="sr-only">
                    {showPassword ? "Hide password" : "Show password"}
                  </span>
                </Button>
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Signing in...
                </>
              ) : (
                "Sign In"
              )}
            </Button>

            <p className="text-center text-sm text-muted-foreground">
              Need help?{" "}
              <a
                href="#"
                className="underline underline-offset-4 hover:text-foreground"
              >
                Contact IT Support
              </a>
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
