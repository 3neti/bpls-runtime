"use client";

import { useState, useCallback } from "react";
import { useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import {
  fetchBillingGroupAbstractReport,
  exportBillingGroupAbstractReport,
} from "@/lib/actions/billing-group-abstract-report";
import { DISPLAY_ROW_CAP, type ExportFormat } from "@/lib/exports/types";
import { DateFilter } from "./date-filter";
import { ReportTable } from "./report-table";
import { PdfExportButton } from "./pdf-export-button";
import { TruncationNotice } from "./truncation-notice";
import { triggerDownload } from "./report-download";
import { toast } from "sonner";

interface ReportData {
  columns: string[];
  rows: Array<{
    orNumber: string;
    payorName: string;
    fees: Record<string, number>;
    total: number;
    source: string;
  }>;
  totals: Record<string, number>;
  grandTotal: number;
  truncated: boolean;
  totalCount: number;
}

export function BillingGroupAbstractReport({
  billingGroupId,
}: {
  billingGroupId: string;
}) {
  // Reuses the same cached query the sidebar uses to resolve the group's name.
  const billingGroups = useQuery(api.billingGroups.list, {
    includeInactive: false,
    includeDeleted: false,
  });
  const group = billingGroups?.find((g) => g._id === billingGroupId);
  const groupName = group?.name ?? "Billing Group";

  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [orNumberFrom, setOrNumberFrom] = useState("");
  const [orNumberTo, setOrNumberTo] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [reportData, setReportData] = useState<ReportData | null>(null);

  const buildParams = useCallback(
    () => ({
      billingGroupId,
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
      orNumberFrom: orNumberFrom.trim() || undefined,
      orNumberTo: orNumberTo.trim() || undefined,
    }),
    [billingGroupId, dateFrom, dateTo, orNumberFrom, orNumberTo]
  );

  const handleGenerate = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await fetchBillingGroupAbstractReport(buildParams());
      setReportData(result);
      if (result.totalCount === 0) {
        toast.info("No records found for the selected filters.");
      } else {
        toast.success(`Report generated with ${result.totalCount} records.`);
      }
    } catch (error) {
      console.error("Failed to generate report:", error);
      toast.error("Failed to generate report. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [buildParams]);

  const handleCsvExport = useCallback(async () => {
    setIsExporting(true);
    try {
      const result = await exportBillingGroupAbstractReport(
        { ...buildParams(), groupName },
        "csv"
      );
      triggerDownload(result);
      toast.success("CSV exported successfully.");
    } catch (error) {
      console.error("Failed to export CSV:", error);
      toast.error("Failed to export CSV. Please try again.");
    } finally {
      setIsExporting(false);
    }
  }, [buildParams, groupName]);

  const exportPdf = useCallback(
    (format: ExportFormat) =>
      exportBillingGroupAbstractReport({ ...buildParams(), groupName }, format),
    [buildParams, groupName]
  );

  const hasData = !!reportData && reportData.totalCount > 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">
          {groupName.toUpperCase()} ABSTRACT REPORT
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Abstract of collections for the {groupName} billing group.
        </p>
      </div>

      <DateFilter
        dateFrom={dateFrom}
        dateTo={dateTo}
        orNumberFrom={orNumberFrom}
        orNumberTo={orNumberTo}
        onDateFromChange={setDateFrom}
        onDateToChange={setDateTo}
        onOrNumberFromChange={setOrNumberFrom}
        onOrNumberToChange={setOrNumberTo}
        onGenerate={handleGenerate}
        onExport={handleCsvExport}
        isLoading={isLoading || isExporting}
        hasData={hasData}
        extraActions={
          hasData ? (
            <PdfExportButton onDownload={() => exportPdf("pdf")} />
          ) : undefined
        }
      />

      {reportData?.truncated && (
        <TruncationNotice totalCount={reportData.totalCount} cap={DISPLAY_ROW_CAP} />
      )}

      {reportData && (
        <ReportTable
          columns={reportData.columns}
          rows={reportData.rows}
          totals={reportData.totals}
          grandTotal={reportData.grandTotal}
        />
      )}

      {!reportData && !isLoading && (
        <div className="flex items-center justify-center rounded-lg border border-dashed p-12">
          <p className="text-sm text-muted-foreground">
            Select filters and click Generate to view the report.
          </p>
        </div>
      )}
    </div>
  );
}
