"use client";

import { useState, useCallback, useMemo } from "react";
import {
  fetchTopEstablishmentsTaxDue,
  exportTopEstablishmentsTaxDue,
} from "@/lib/actions/top-establishments-tax-due";
import type {
  TopTaxDueRankBy,
  TopTaxDueFeeScope,
} from "@repo/clickhouse/queries/top-establishments-tax-due";
import { DataTable, type ReportColumn, type ReportRow } from "./data-table";
import { ReportToolbar } from "./report-toolbar";
import { ReportSummary } from "./report-summary";
import { PdfExportButton } from "./pdf-export-button";
import { TruncationNotice } from "./truncation-notice";
import { triggerDownload } from "./report-download";
import { buildFooterRow, type FooterSpec } from "@/lib/exports/footer";
import type { TableExportMeta } from "@/lib/exports/table-export";
import { DISPLAY_ROW_CAP, type ExportFormat } from "@/lib/exports/types";
import { toast } from "sonner";

const TITLE = "TOP 100 ESTABLISHMENTS TAX DUE";

// Columns. The DUE / PAID labels follow the Amounts scope: "Tax" shows assessed
// business tax, "All" shows every fee. The row keys (taxDue/taxPaid/balance)
// stay stable; only the labels change.
function buildColumns(feeScope: TopTaxDueFeeScope): ReportColumn[] {
  const isTax = feeScope === "tax";
  return [
    { key: "rank", label: "RANK", align: "right", minWidth: 60 },
    { key: "ownerName", label: "BUSINESS OWNER", minWidth: 190 },
    { key: "businessName", label: "BUSINESS NAME", minWidth: 170 },
    { key: "businessAddress", label: "BUSINESS ADDRESS", minWidth: 260 },
    { key: "grossSales", label: "GROSS SALES", currency: true, minWidth: 130 },
    { key: "paymentFrequency", label: "MODE OF PAYMENT", minWidth: 130 },
    {
      key: "taxDue",
      label: isTax ? "TAX DUE" : "AMOUNT DUE",
      currency: true,
      minWidth: 120,
    },
    {
      key: "taxPaid",
      label: isTax ? "TAX PAID" : "AMOUNT PAID",
      currency: true,
      minWidth: 120,
    },
    { key: "balance", label: "BALANCE", currency: true, minWidth: 120 },
    { key: "paymentDate", label: "PAYMENT DATE", minWidth: 120 },
    { key: "orNumber", label: "OR/RECEIPT NO.", minWidth: 130 },
  ];
}

function buildRankByOptions(
  feeScope: TopTaxDueFeeScope
): { value: TopTaxDueRankBy; label: string }[] {
  const isTax = feeScope === "tax";
  return [
    { value: "taxDue", label: isTax ? "Tax Due" : "Amount Due" },
    { value: "taxPaid", label: isTax ? "Tax Paid" : "Amount Paid" },
    { value: "totalPaid", label: "Total Paid" },
  ];
}

const FEE_SCOPE_OPTIONS: { value: TopTaxDueFeeScope; label: string }[] = [
  { value: "tax", label: "Tax" },
  { value: "all", label: "All" },
];

const FOOTER: FooterSpec = {
  labelKey: "ownerName",
  label: "TOTAL",
  sumKeys: ["grossSales", "taxDue", "taxPaid", "balance"],
};

const CURRENT_YEAR = new Date().getFullYear();
const YEAR_OPTIONS = [
  CURRENT_YEAR + 1,
  CURRENT_YEAR,
  CURRENT_YEAR - 1,
  CURRENT_YEAR - 2,
  CURRENT_YEAR - 3,
];

const SUMMARY_POINTS = [
  "Ranks the top 100 establishments that made a completed payment within the selected period. Choose a Year (and optionally a Month), or set an explicit Date Range, pick what to Rank By, then click Generate.",
  "Use the Amounts switch to scope the DUE / PAID / BALANCE columns: Tax = assessed business tax only (fees categorized as Tax); All = every fee, including regulatory and other charges plus surcharge and penalty. DUE minus PAID equals BALANCE in both modes.",
  "The period selects which establishments appear (those paying within it); the amounts are each establishment's standing figures. MODE OF PAYMENT shows the declared payment frequency (Annually / Semi-Annually / Quarterly).",
  "PAYMENT DATE and OR/RECEIPT NO. reflect the latest completed payment. The bold TOTAL row sums Gross Sales, Due, Paid, and Balance. Data refreshes from the live system about once an hour.",
];

interface TopTaxDueData {
  rows: ReportRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}

/** Last calendar day (1-based) of a given 1-based month in a year. */
function lastDayOfMonth(year: number, month: number): number {
  return new Date(year, month, 0).getDate();
}

export function TopEstablishmentsTaxDue() {
  const [year, setYear] = useState(CURRENT_YEAR);
  const [month, setMonth] = useState(0); // 0 = all months
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [rankBy, setRankBy] = useState<TopTaxDueRankBy>("taxDue");
  const [feeScope, setFeeScope] = useState<TopTaxDueFeeScope>("tax");
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [data, setData] = useState<TopTaxDueData | null>(null);

  const columns = useMemo(() => buildColumns(feeScope), [feeScope]);
  const rankByOptions = useMemo(() => buildRankByOptions(feeScope), [feeScope]);

  // Totals come from the server's full-data column totals so they stay correct
  // even when the on-screen rows are capped.
  const footerRow = useMemo<ReportRow | undefined>(
    () =>
      data && data.totalCount > 0
        ? buildFooterRow(FOOTER, data.columnTotals)
        : undefined,
    [data]
  );

  // Resolve the effective payment-date window: an explicit Date Range overrides
  // Year/Month; otherwise the selected Month narrows within the Year, or the
  // whole Year when no month is chosen.
  const buildParams = useCallback(() => {
    const base = { rankBy, feeScope };
    if (dateFrom || dateTo) {
      return {
        ...base,
        dateFrom: dateFrom || undefined,
        dateTo: dateTo || undefined,
      };
    }
    if (month >= 1 && month <= 12) {
      const mm = String(month).padStart(2, "0");
      const last = String(lastDayOfMonth(year, month)).padStart(2, "0");
      return { ...base, dateFrom: `${year}-${mm}-01`, dateTo: `${year}-${mm}-${last}` };
    }
    return { ...base, dateFrom: `${year}-01-01`, dateTo: `${year}-12-31` };
  }, [year, month, dateFrom, dateTo, rankBy, feeScope]);

  const exportMeta = useCallback(
    (): TableExportMeta => ({
      columns,
      title: TITLE,
      orientation: "landscape",
      footer: FOOTER,
      filenameBase: `top-100-tax-due-${feeScope}-${rankBy}-${year}`,
    }),
    [columns, feeScope, rankBy, year]
  );

  const handleGenerate = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await fetchTopEstablishmentsTaxDue(buildParams());
      setData(result);
      if (result.totalCount === 0) {
        toast.info("No establishments found for the selected period.");
      } else {
        const rankLabel =
          rankByOptions.find((o) => o.value === rankBy)?.label ?? "Tax Due";
        toast.success(
          `Top ${result.totalCount} establishments by ${rankLabel}.`
        );
      }
    } catch (error) {
      console.error("Failed to generate top establishments report:", error);
      toast.error("Failed to generate report. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [buildParams, rankBy, rankByOptions]);

  const handleCsvExport = useCallback(async () => {
    setIsExporting(true);
    try {
      const result = await exportTopEstablishmentsTaxDue(
        buildParams(),
        exportMeta(),
        "csv"
      );
      triggerDownload(result);
      toast.success("CSV exported successfully.");
    } catch (error) {
      console.error("Failed to export CSV:", error);
      toast.error("Failed to export CSV. Please try again.");
    } finally {
      setIsExporting(false);
    }
  }, [buildParams, exportMeta]);

  const exportPdf = useCallback(
    (format: ExportFormat) =>
      exportTopEstablishmentsTaxDue(buildParams(), exportMeta(), format),
    [buildParams, exportMeta]
  );

  const hasData = !!data && data.totalCount > 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{TITLE}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          The 100 highest-ranking establishments by tax, for establishments
          paying within the selected period.
        </p>
      </div>

      <ReportSummary points={SUMMARY_POINTS} />

      <ReportToolbar
        showYear
        year={year}
        onYearChange={setYear}
        yearOptions={YEAR_OPTIONS}
        showMonth
        month={month}
        onMonthChange={setMonth}
        showDateRange
        dateFrom={dateFrom}
        dateTo={dateTo}
        onDateFromChange={setDateFrom}
        onDateToChange={setDateTo}
        dateFromLabel="Start Date"
        dateToLabel="End Date"
        showRankBy
        rankBy={rankBy}
        onRankByChange={(v) => setRankBy(v as TopTaxDueRankBy)}
        rankByOptions={rankByOptions}
        showFeeScope
        feeScope={feeScope}
        onFeeScopeChange={(v) => setFeeScope(v as TopTaxDueFeeScope)}
        feeScopeOptions={FEE_SCOPE_OPTIONS}
        feeScopeLabel="Amounts"
        onGenerate={handleGenerate}
        onExport={handleCsvExport}
        isLoading={isLoading || isExporting}
        hasData={hasData}
        extraActions={
          hasData ? (
            <PdfExportButton onDownload={() => exportPdf("pdf")} />
          ) : undefined
        }
      />

      {data?.truncated && (
        <TruncationNotice totalCount={data.totalCount} cap={DISPLAY_ROW_CAP} />
      )}

      {data && (
        <DataTable columns={columns} rows={data.rows} footerRow={footerRow} />
      )}

      {!data && !isLoading && (
        <div className="flex items-center justify-center rounded-lg border border-dashed p-12">
          <p className="text-sm text-muted-foreground">
            Select a period and rank metric, then click Generate to view the top
            100 establishments.
          </p>
        </div>
      )}
    </div>
  );
}
