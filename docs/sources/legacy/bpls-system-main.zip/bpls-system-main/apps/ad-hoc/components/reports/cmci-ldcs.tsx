"use client";

import { useState, useCallback } from "react";
import { fetchCmciLdcs, exportCmciLdcs } from "@/lib/actions/cmci-ldcs";
import { DataTable, type ReportColumn, type ReportRow } from "./data-table";
import { ReportToolbar } from "./report-toolbar";
import { ReportSummary } from "./report-summary";
import { PdfExportButton } from "./pdf-export-button";
import { TruncationNotice } from "./truncation-notice";
import { triggerDownload } from "./report-download";
import type { TableExportMeta } from "@/lib/exports/table-export";
import { DISPLAY_ROW_CAP, type ExportFormat } from "@/lib/exports/types";
import { toast } from "sonner";

// Flat column labels — the official template has 2-level merged headers but
// the DataTable/CSV/PDF infrastructure is flat; group names are prefixed to
// each leaf label (e.g. "ADDRESS — STREET"). Pixel-faithful merged headers
// can be added later via an optional `group?` on ReportColumn if needed.
const COLUMNS: ReportColumn[] = [
  { key: "lgu",                      label: "LGU",                          minWidth: 70 },
  { key: "province",                  label: "PROVINCE",                     minWidth: 130 },
  { key: "region",                    label: "REGION",                       minWidth: 70 },
  { key: "classification",            label: "CLASSIFICATION",               minWidth: 100 },
  { key: "lguType",                   label: "LGU TYPE",                     minWidth: 100 },
  { key: "businessName",              label: "BUSINESS NAME",                minWidth: 200 },
  { key: "addressHouseBldg",          label: "ADDRESS — HOUSE/BLDG. NO.",    minWidth: 130 },
  { key: "addressStreetBarangay",     label: "ADDRESS — STREET & BARANGAY",  minWidth: 200 },
  { key: "addressSubdivisionDistrict",label: "ADDRESS — SUBDIVISION/DISTRICT",minWidth: 140 },
  { key: "ownerName",                 label: "OWNER'S NAME",                 minWidth: 190 },
  { key: "lineOfBusiness",            label: "LINE OF BUSINESS",             minWidth: 180 },
  { key: "businessType",              label: "BUSINESS TYPE",                minWidth: 160 },
  { key: "capitalizationSize",        label: "CAPITALIZATION SIZE",          minWidth: 200 },
  { key: "capitalization",            label: "CAPITALIZATION",               currency: true, csvFormat: "plain", minWidth: 130 },
  { key: "grossSale",                 label: "GROSS SALE",                   currency: true, csvFormat: "plain", minWidth: 120 },
  { key: "newOrRenewal",              label: "NEW / RENEWAL",                minWidth: 100 },
  { key: "yearOfRegistration",        label: "YEAR OF REGISTRATION",         minWidth: 120 },
  { key: "permitNo",                  label: "PERMIT NO.",                   minWidth: 130 },
];

const SUMMARY_POINTS = [
  "Matches the DTI CMCI Local Data Capture Sheet (Annex B) template — one row per Released business permit (New or Renewal).",
  "LGU, Province, Region, Classification, and LGU Type are hardcoded for Ipil, Zamboanga Sibugay, Region IX.",
  "Line of Business is the first line's category from the existing per-line groups dimension (e.g. S- RETAIL TRADE).",
  "Business Type maps ownershipType: Sole Proprietorship → Single Proprietor; Partnership/Corporation/Non-Profit → Partnership/Corporation; Cooperative → Cooperative.",
  "Capitalization Size maps businessScale: Micro/Small/Medium/Large to the DTI bracket labels.",
  "Capitalization is the total capital investment summed across the business's lines of business (recorded during the permit application).",
  "Gross Sale is the sum of gross sales across all lines of business (no thousands separators in CSV — native number).",
  "Permit No. and Year of Registration come from the official permit record, not the application form.",
  "Date filter applies to the permit issue date (when the permit was actually issued).",
  "Figures are refreshed from the live system about once an hour.",
];

interface CmciLdcsData {
  rows: ReportRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}

export function CmciLdcsReport() {
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [data, setData] = useState<CmciLdcsData | null>(null);

  const title = "CMCI LDCS ANNEX B — LOCAL DATA CAPTURE SHEET";

  const buildParams = useCallback(
    () => ({
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
    }),
    [dateFrom, dateTo]
  );

  const exportMeta = useCallback(
    (): TableExportMeta => ({
      columns: COLUMNS,
      title,
      orientation: "landscape",
      filenameBase: `cmci-ldcs-${dateFrom || "all"}-to-${dateTo || "all"}`,
    }),
    [dateFrom, dateTo]
  );

  const handleGenerate = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await fetchCmciLdcs(buildParams());
      setData(result);
      if (result.totalCount === 0) {
        toast.info("No records found for the selected date range.");
      } else {
        toast.success(`Report generated with ${result.totalCount} records.`);
      }
    } catch (error) {
      console.error("Failed to generate CMCI LDCS report:", error);
      toast.error("Failed to generate report. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [buildParams]);

  const handleCsvExport = useCallback(async () => {
    setIsExporting(true);
    try {
      const result = await exportCmciLdcs(buildParams(), exportMeta(), "csv");
      triggerDownload(result);
      toast.success("CSV exported successfully.");
    } catch (error) {
      console.error("Failed to export CSV:", error);
      toast.error("Failed to export CSV. Please try again.");
    } finally {
      setIsExporting(false);
    }
  }, [buildParams, exportMeta]);

  const exportPdf = useCallback(
    (format: ExportFormat) =>
      exportCmciLdcs(buildParams(), exportMeta(), format),
    [buildParams, exportMeta]
  );

  const hasData = !!data && data.totalCount > 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          DTI Cities and Municipalities Competitiveness Index — local economy structure, approved business permits.
        </p>
      </div>

      <ReportSummary points={SUMMARY_POINTS} />

      <ReportToolbar
        showDateRange
        dateFrom={dateFrom}
        dateTo={dateTo}
        onDateFromChange={setDateFrom}
        onDateToChange={setDateTo}
        dateFromLabel="Permit Issued From"
        dateToLabel="Permit Issued To"
        onGenerate={handleGenerate}
        onExport={handleCsvExport}
        isLoading={isLoading || isExporting}
        hasData={hasData}
        extraActions={
          hasData ? (
            <PdfExportButton onDownload={() => exportPdf("pdf")} />
          ) : undefined
        }
      />

      {data?.truncated && (
        <TruncationNotice totalCount={data.totalCount} cap={DISPLAY_ROW_CAP} />
      )}

      {data && <DataTable columns={COLUMNS} rows={data.rows} />}

      {!data && !isLoading && (
        <div className="flex items-center justify-center rounded-lg border border-dashed p-12">
          <p className="text-sm text-muted-foreground">
            Optionally filter by permit issue date range, then click Generate to view the report.
          </p>
        </div>
      )}
    </div>
  );
}
