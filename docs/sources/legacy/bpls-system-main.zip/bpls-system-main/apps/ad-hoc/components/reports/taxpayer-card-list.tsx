"use client";

import { useState, useEffect, useMemo, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Input } from "@repo/ui/components/input";
import { Loader2, Search } from "lucide-react";
import { fetchTaxpayerBusinesses } from "@/lib/actions/taxpayer-account-card";
import { DataTable, type ReportColumn, type ReportRow } from "./data-table";
import { ReportSummary } from "./report-summary";
import { TruncationNotice } from "./truncation-notice";
import { DISPLAY_ROW_CAP } from "@/lib/exports/types";
import { toast } from "sonner";

const COLUMNS: ReportColumn[] = [
  { key: "businessName", label: "BUSINESS TRADE NAME", minWidth: 220 },
  { key: "ownerName", label: "NAME OF OWNER/TAXPAYER", minWidth: 220 },
  { key: "businessAddress", label: "BUSINESS ADDRESS", minWidth: 240 },
  { key: "latestYear", label: "LATEST YEAR", align: "right", minWidth: 110 },
];

const SUMMARY_POINTS = [
  "Browse every taxpayer (business) on record. Use the search box to filter by business trade name or owner/taxpayer name.",
  "Click a row to open that taxpayer's Account Card — a printable year-by-year ledger of annual tax, quarterly receipts, fines/penalties, and regulatory fees.",
  "Data refreshes from the live system about once an hour.",
];

interface TaxpayerListData {
  rows: ReportRow[];
  truncated: boolean;
  totalCount: number;
}

export function TaxpayerCardList() {
  const router = useRouter();
  const [data, setData] = useState<TaxpayerListData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setIsLoading(true);
      try {
        const result = await fetchTaxpayerBusinesses();
        if (!cancelled)
          setData({
            rows: result.rows.map((r) => ({ ...r })),
            truncated: result.truncated,
            totalCount: result.totalCount,
          });
      } catch (error) {
        console.error("Failed to load taxpayers:", error);
        if (!cancelled) toast.error("Failed to load taxpayers. Please try again.");
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const filteredRows = useMemo(() => {
    if (!data) return [];
    const term = search.trim().toLowerCase();
    if (!term) return data.rows;
    return data.rows.filter((r) => {
      const name = String(r.businessName ?? "").toLowerCase();
      const owner = String(r.ownerName ?? "").toLowerCase();
      return name.includes(term) || owner.includes(term);
    });
  }, [data, search]);

  const handleRowClick = useCallback(
    (row: ReportRow) => {
      const id = row.businessId;
      if (id) router.push(`/dashboard/reports/taxpayer-card/${id}`);
    },
    [router]
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">
          TAXPAYER&apos;S ACCOUNT CARD
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Select a taxpayer to view and print their account card.
        </p>
      </div>

      <ReportSummary points={SUMMARY_POINTS} />

      <div className="relative w-full max-w-sm">
        <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by business or owner name…"
          className="pl-9"
        />
      </div>

      {data?.truncated && (
        <TruncationNotice totalCount={data.totalCount} cap={DISPLAY_ROW_CAP} />
      )}

      {isLoading ? (
        <div className="flex items-center justify-center rounded-lg border border-dashed p-12">
          <Loader2 className="mr-2 size-4 animate-spin text-muted-foreground" />
          <p className="text-sm text-muted-foreground">Loading taxpayers…</p>
        </div>
      ) : (
        <DataTable
          columns={COLUMNS}
          rows={filteredRows}
          zeroAs="zero"
          onRowClick={handleRowClick}
        />
      )}
    </div>
  );
}
