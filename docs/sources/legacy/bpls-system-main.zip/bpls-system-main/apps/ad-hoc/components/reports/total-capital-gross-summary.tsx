"use client";

import { useState, useCallback, useMemo } from "react";
import {
  fetchTotalCapitalGrossSummary,
  exportTotalCapitalGrossSummary,
} from "@/lib/actions/total-capital-gross-summary";
import { DataTable, type ReportColumn, type ReportRow } from "./data-table";
import { ReportToolbar } from "./report-toolbar";
import { ReportSummary } from "./report-summary";
import { PdfExportButton } from "./pdf-export-button";
import { TruncationNotice } from "./truncation-notice";
import { triggerDownload } from "./report-download";
import { buildFooterRow, type FooterSpec } from "@/lib/exports/footer";
import type { TableExportMeta } from "@/lib/exports/table-export";
import { DISPLAY_ROW_CAP, type ExportFormat } from "@/lib/exports/types";
import { toast } from "sonner";

const TITLE = "TOTAL CAPITAL AND GROSS SUMMARY";

const COLUMNS: ReportColumn[] = [
  { key: "ownerName", label: "NAME", minWidth: 190 },
  { key: "businessName", label: "BUSINESS NAME", minWidth: 160 },
  { key: "capitalInvestment", label: "CAPITAL", currency: true, minWidth: 130 },
  { key: "grossSales", label: "GROSS", currency: true, minWidth: 130 },
  { key: "orNumber", label: "OR NUMBER", minWidth: 120 },
  { key: "paymentDate", label: "PAYMENT DATE", minWidth: 120 },
  { key: "paymentAmount", label: "PAYMENT AMOUNT", currency: true, minWidth: 130 },
  {
    key: "remainingBalance",
    label: "REMAINING BALANCE",
    currency: true,
    minWidth: 150,
  },
  { key: "paymentStatus", label: "PAYMENT STATUS", minWidth: 120 },
];

const FOOTER: FooterSpec = {
  labelKey: "ownerName",
  label: "TOTAL",
  sumKeys: [
    "capitalInvestment",
    "grossSales",
    "paymentAmount",
    "remainingBalance",
  ],
};

const SUMMARY_POINTS = [
  "Shows one row per establishment that made a completed payment within the selected date range. Pick a Start Date and End Date, then click Generate.",
  "CAPITAL and GROSS are totaled across the business's lines of business and counted once per establishment. The bold TOTAL row sums Capital, Gross, Payment Amount, and Remaining Balance.",
  "PAYMENT AMOUNT is the total of all completed payments; REMAINING BALANCE is the assessed fees still owed (Payment Amount + Remaining Balance = total fees). OR NUMBER and PAYMENT DATE reflect the latest completed payment.",
  "PAYMENT STATUS is 'Completed' when nothing is owed, otherwise 'Partial'. Data refreshes from the live system about once an hour.",
];

interface CapitalGrossData {
  rows: ReportRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}

export function TotalCapitalGrossSummary() {
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [data, setData] = useState<CapitalGrossData | null>(null);

  // Totals come from the server's full-data column totals so they stay correct
  // even when the on-screen rows are capped.
  const footerRow = useMemo<ReportRow | undefined>(
    () =>
      data && data.totalCount > 0
        ? buildFooterRow(FOOTER, data.columnTotals)
        : undefined,
    [data]
  );

  const buildParams = useCallback(
    () => ({
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
    }),
    [dateFrom, dateTo]
  );

  const exportMeta = useCallback(
    (): TableExportMeta => ({
      columns: COLUMNS,
      title: TITLE,
      orientation: "landscape",
      footer: FOOTER,
      filenameBase: `total-capital-gross-summary-${dateFrom || "all"}-to-${dateTo || "all"}`,
    }),
    [dateFrom, dateTo]
  );

  const handleGenerate = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await fetchTotalCapitalGrossSummary(buildParams());
      setData(result);
      if (result.totalCount === 0) {
        toast.info("No establishments found for the selected date range.");
      } else {
        toast.success(
          `Report generated with ${result.totalCount} establishments.`
        );
      }
    } catch (error) {
      console.error("Failed to generate capital and gross summary:", error);
      toast.error("Failed to generate report. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [buildParams]);

  const handleCsvExport = useCallback(async () => {
    setIsExporting(true);
    try {
      const result = await exportTotalCapitalGrossSummary(
        buildParams(),
        exportMeta(),
        "csv"
      );
      triggerDownload(result);
      toast.success("CSV exported successfully.");
    } catch (error) {
      console.error("Failed to export CSV:", error);
      toast.error("Failed to export CSV. Please try again.");
    } finally {
      setIsExporting(false);
    }
  }, [buildParams, exportMeta]);

  const exportPdf = useCallback(
    (format: ExportFormat) =>
      exportTotalCapitalGrossSummary(buildParams(), exportMeta(), format),
    [buildParams, exportMeta]
  );

  const hasData = !!data && data.totalCount > 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{TITLE}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Capital and gross sales totals for establishments paying within a date
          range.
        </p>
      </div>

      <ReportSummary points={SUMMARY_POINTS} />

      <ReportToolbar
        showDateRange
        dateFrom={dateFrom}
        dateTo={dateTo}
        onDateFromChange={setDateFrom}
        onDateToChange={setDateTo}
        dateFromLabel="Start Date"
        dateToLabel="End Date"
        onGenerate={handleGenerate}
        onExport={handleCsvExport}
        isLoading={isLoading || isExporting}
        hasData={hasData}
        extraActions={
          hasData ? (
            <PdfExportButton onDownload={() => exportPdf("pdf")} />
          ) : undefined
        }
      />

      {data?.truncated && (
        <TruncationNotice totalCount={data.totalCount} cap={DISPLAY_ROW_CAP} />
      )}

      {data && (
        <DataTable columns={COLUMNS} rows={data.rows} footerRow={footerRow} />
      )}

      {!data && !isLoading && (
        <div className="flex items-center justify-center rounded-lg border border-dashed p-12">
          <p className="text-sm text-muted-foreground">
            Select a date range and click Generate to view the capital and gross
            summary.
          </p>
        </div>
      )}
    </div>
  );
}
