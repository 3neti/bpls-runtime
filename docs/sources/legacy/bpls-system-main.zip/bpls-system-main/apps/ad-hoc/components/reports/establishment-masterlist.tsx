"use client";

import { useState, useCallback, useMemo } from "react";
import {
  fetchEstablishmentMasterlist,
  exportEstablishmentMasterlist,
} from "@/lib/actions/establishment-masterlist";
import { DataTable, type ReportColumn, type ReportRow } from "./data-table";
import { ReportToolbar } from "./report-toolbar";
import { ReportSummary } from "./report-summary";
import { PdfExportButton } from "./pdf-export-button";
import { TruncationNotice } from "./truncation-notice";
import { triggerDownload } from "./report-download";
import { buildFooterRow, type FooterSpec } from "@/lib/exports/footer";
import type { TableExportMeta } from "@/lib/exports/table-export";
import { DISPLAY_ROW_CAP, type ExportFormat } from "@/lib/exports/types";
import { toast } from "sonner";

function footerFor(variant: "paid" | "unpaid"): FooterSpec {
  return {
    labelKey: "seqNo",
    label: "TOTAL",
    sumKeys:
      variant === "paid"
        ? [
            "computedBusinessTax",
            "paidQ1",
            "paidQ2",
            "paidQ3",
            "paidQ4",
            "paidSem1",
            "paidSem2",
            "paidAnnual",
            "regulatoryFees",
            "amount",
          ]
        : ["businessTax", "regulatoryFees", "amount"],
  };
}

interface MasterlistData {
  rows: ReportRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}

// Column set differs by variant. PAID: the assessed tax is shown as COMPUTED
// BUSINESS TAX and the tax portion of the cash received is broken out under a
// PAID BUSINESS TAX banner into the installment-period columns of the mode of
// payment (inapplicable periods read "N/A"); AMOUNT stays the fees-only cash
// per line (surcharge/interest excluded). UNPAID: assessed BUSINESS TAX /
// REGULATORY FEES with the last column labelled "TOTAL AMOUNT DUE" (full
// assessed fees owed — no cash received).
function columnsFor(variant: "paid" | "unpaid"): ReportColumn[] {
  const period = (key: string, label: string): ReportColumn => ({
    key,
    label,
    group: "PAID BUSINESS TAX",
    currency: true,
    csvFormat: "peso",
    minWidth: 105,
  });
  return [
    { key: "seqNo", label: "SEQ. NO.", minWidth: 70 },
    { key: "ownerName", label: "NAME OF OWNER/ APPLICANT", minWidth: 190 },
    { key: "businessName", label: "NAME OF BUSINESS", minWidth: 170 },
    { key: "lineOfBusiness", label: "LINE OF BUSINESS", minWidth: 180 },
    { key: "businessAddress", label: "BUSINESS ADDRESS", minWidth: 240 },
    // Capital / gross are exported as natural numbers (sample CSV shows no
    // thousands separators); the on-screen table still formats them.
    { key: "capitalInvestment", label: "CAPITAL INVESTMENT", currency: true, csvFormat: "plain", minWidth: 130 },
    { key: "grossSales", label: "GROSS SALES", currency: true, csvFormat: "plain", minWidth: 120 },
    ...(variant === "paid"
      ? [{ key: "computedBusinessTax", label: "COMPUTED BUSINESS TAX", currency: true, csvFormat: "peso", minWidth: 130 } satisfies ReportColumn]
      : []),
    { key: "modeOfPayment", label: "MODE OF PAYMENT", minWidth: 130 },
    { key: "orNumber", label: "OR NUMBER", minWidth: 110 },
    ...(variant === "paid"
      ? [
          period("paidQ1", "QUARTER 1"),
          period("paidQ2", "QUARTER 2"),
          period("paidQ3", "QUARTER 3"),
          period("paidQ4", "QUARTER 4"),
          period("paidSem1", "1ST SEMESTER"),
          period("paidSem2", "2ND SEMESTER"),
          period("paidAnnual", "ANNUALLY"),
        ]
      : [
          { key: "businessTax", label: "BUSINESS TAX", currency: true, csvFormat: "peso", minWidth: 120 } satisfies ReportColumn,
        ]),
    { key: "regulatoryFees", label: "REGULATORY FEES", currency: true, csvFormat: "peso", minWidth: 120 },
    // Zero renders as 0.00 (not a dash) so a line with no assessed fees reads
    // as an explicit zero rather than a blank.
    {
      key: "amount",
      label: variant === "unpaid" ? "TOTAL AMOUNT DUE" : "AMOUNT",
      currency: true,
      csvFormat: "peso",
      minWidth: 120,
      zeroAs: "zero",
    },
  ];
}

function summaryPoints(variant: "paid" | "unpaid"): string[] {
  const shared = [
    "Each row is a single LINE OF BUSINESS; SEQ. NO. and OR NUMBER repeat across the lines of the same establishment.",
    "CAPITAL INVESTMENT and GROSS SALES are per line of business.",
    "Filtering by an OR # range works as a receipt lookup: every matching receipt is listed regardless of payment status.",
    "MODE OF PAYMENT is the chosen payment frequency: Annually, Semi-Annually, or Quarterly.",
    "Figures come from the official permit and payment records, refreshed from the live system about once an hour.",
  ];
  if (variant === "paid") {
    return [
      "Lists establishments that have made at least one completed payment — including partial payers who have paid some but not all periods.",
      "OR NUMBER shows the establishment's most recent official receipt.",
      "COMPUTED BUSINESS TAX is the full assessed business tax for the line of business, recomputed from its own gross sales/capital (not scaled to cash).",
      "PAID BUSINESS TAX breaks the business-tax portion of the cash received into the installment periods of the mode of payment (quarters, semesters, or annually). \"N/A\" marks periods that don't exist for that mode; a dash means the period simply hasn't been paid.",
      "Each period's tax cash is allocated across the establishment's lines in proportion to each line's assessed business tax; REGULATORY FEES is the regulatory/other portion of the cash, allocated by assessed regulatory fees.",
      "AMOUNT is the fees-only portion of the cash received — surcharge and interest charged on late payments are excluded. AMOUNT = paid business tax across the periods + REGULATORY FEES.",
      ...shared,
    ];
  }
  return [
    "Lists establishments that have not made any payment yet — no completed payment on record at all.",
    "OR NUMBER is blank because no receipt has been issued.",
    "BUSINESS TAX and REGULATORY FEES are the assessed amounts recomputed per line from its own gross sales/capital.",
    "TOTAL AMOUNT DUE is the full assessed fee per line (BUSINESS TAX + REGULATORY FEES) that the establishment owes.",
    ...shared,
  ];
}

export function EstablishmentMasterlist({
  variant,
}: {
  variant: "paid" | "unpaid";
}) {
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [orNumberFrom, setOrNumberFrom] = useState("");
  const [orNumberTo, setOrNumberTo] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [data, setData] = useState<MasterlistData | null>(null);

  const title =
    variant === "paid"
      ? "MASTERLIST FOR PAID ESTABLISHMENT"
      : "MASTERLIST FOR UNPAID ESTABLISHMENT";

  // Columns and totals row are variant-dependent.
  const columns = useMemo(() => columnsFor(variant), [variant]);
  const footer = useMemo(() => footerFor(variant), [variant]);

  // Totals come from the server's full-data column totals so they stay correct
  // even when the on-screen rows are capped ("N/A" period cells are skipped).
  const footerRow = useMemo<ReportRow | undefined>(
    () =>
      data && data.totalCount > 0
        ? buildFooterRow(footer, data.columnTotals)
        : undefined,
    [data, footer]
  );

  const buildParams = useCallback(
    () => ({
      mode: variant,
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
      orNumberFrom: orNumberFrom.trim() || undefined,
      orNumberTo: orNumberTo.trim() || undefined,
    }),
    [variant, dateFrom, dateTo, orNumberFrom, orNumberTo]
  );

  const exportMeta = useCallback(
    (): TableExportMeta => ({
      columns,
      title,
      orientation: "landscape",
      footer,
      filenameBase: `masterlist-${variant}-establishment-${dateFrom || "all"}-to-${dateTo || "all"}`,
    }),
    [columns, footer, title, variant, dateFrom, dateTo]
  );

  const handleGenerate = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await fetchEstablishmentMasterlist(buildParams());
      setData(result);
      if (result.totalCount === 0) {
        toast.info("No establishments found for the selected filters.");
      } else {
        toast.success(`Report generated with ${result.totalCount} line items.`);
      }
    } catch (error) {
      console.error("Failed to generate masterlist:", error);
      toast.error("Failed to generate report. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [buildParams]);

  const handleCsvExport = useCallback(async () => {
    setIsExporting(true);
    try {
      const result = await exportEstablishmentMasterlist(
        buildParams(),
        exportMeta(),
        "csv"
      );
      triggerDownload(result);
      toast.success("CSV exported successfully.");
    } catch (error) {
      console.error("Failed to export CSV:", error);
      toast.error("Failed to export CSV. Please try again.");
    } finally {
      setIsExporting(false);
    }
  }, [buildParams, exportMeta]);

  const exportPdf = useCallback(
    (format: ExportFormat) =>
      exportEstablishmentMasterlist(buildParams(), exportMeta(), format),
    [buildParams, exportMeta]
  );

  const hasData = !!data && data.totalCount > 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {variant === "paid"
            ? "Establishments that have made at least one completed payment (including partial payers)."
            : "Establishments with no payment on record — total amount due shown."}
        </p>
      </div>

      <ReportSummary points={summaryPoints(variant)} />

      <ReportToolbar
        showDateRange
        dateFrom={dateFrom}
        dateTo={dateTo}
        onDateFromChange={setDateFrom}
        onDateToChange={setDateTo}
        dateFromLabel="Application From"
        dateToLabel="Application To"
        showOrNumberRange
        orNumberFrom={orNumberFrom}
        orNumberTo={orNumberTo}
        onOrNumberFromChange={setOrNumberFrom}
        onOrNumberToChange={setOrNumberTo}
        onGenerate={handleGenerate}
        onExport={handleCsvExport}
        isLoading={isLoading || isExporting}
        hasData={hasData}
        extraActions={
          hasData ? (
            <PdfExportButton onDownload={() => exportPdf("pdf")} />
          ) : undefined
        }
      />

      {data?.truncated && (
        <TruncationNotice totalCount={data.totalCount} cap={DISPLAY_ROW_CAP} />
      )}

      {data && (
        <DataTable columns={columns} rows={data.rows} footerRow={footerRow} />
      )}

      {!data && !isLoading && (
        <div className="flex items-center justify-center rounded-lg border border-dashed p-12">
          <p className="text-sm text-muted-foreground">
            Optionally filter by application date or OR # range, then click Generate to view the report.
          </p>
        </div>
      )}
    </div>
  );
}
