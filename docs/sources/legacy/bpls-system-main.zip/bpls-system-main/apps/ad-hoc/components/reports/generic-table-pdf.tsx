import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
} from "@react-pdf/renderer";
import type { ReportColumn, ReportRow } from "./data-table";

function fmtCurrency(value: unknown, zeroAs: "dash" | "zero"): string {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n) || n === 0) return zeroAs === "zero" ? "0.00" : "-";
  return n.toLocaleString("en-PH", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function fmtCell(col: ReportColumn, row: ReportRow): string {
  const value = row[col.key];
  if (col.currency) {
    // Literal annotations (e.g. "N/A") pass through currency columns as-is.
    if (
      typeof value === "string" &&
      value.trim() !== "" &&
      Number.isNaN(Number(value))
    ) {
      return value;
    }
    return fmtCurrency(value, col.zeroAs ?? "dash");
  }
  if (value === undefined || value === null) return "";
  return String(value);
}

/**
 * Fold columns into group-banner cells: consecutive columns sharing a `group`
 * merge into one cell spanning their combined width; ungrouped columns yield
 * an empty spacer cell of their own width.
 */
function groupSegments(
  columns: ReportColumn[]
): Array<{ key: string; label: string; minWidth: number }> {
  const segments: Array<{ key: string; label: string; minWidth: number }> = [];
  for (const col of columns) {
    const last = segments[segments.length - 1];
    if (col.group && last && last.label === col.group) {
      last.minWidth += col.minWidth || 100;
    } else {
      segments.push({
        key: col.key,
        label: col.group ?? "",
        minWidth: col.minWidth || 100,
      });
    }
  }
  return segments;
}

const styles = StyleSheet.create({
  page: {
    paddingVertical: 22,
    paddingHorizontal: 18,
    fontFamily: "Helvetica",
    fontSize: 8,
    color: "#000",
  },
  title: {
    fontSize: 12,
    fontFamily: "Helvetica-Bold",
    textAlign: "center",
    marginBottom: 10,
  },
  table: { borderTop: "1pt solid #000", borderLeft: "1pt solid #000" },
  row: { flexDirection: "row" },
  headerRow: { backgroundColor: "#e8e8e8" },
  footerRow: { backgroundColor: "#f2f2f2" },
  cell: {
    paddingVertical: 3,
    paddingHorizontal: 3,
    borderRight: "1pt solid #000",
    borderBottom: "1pt solid #000",
    fontSize: 7,
  },
  headerCell: { fontFamily: "Helvetica-Bold" },
});

export interface GenericTablePdfProps {
  title: string;
  columns: ReportColumn[];
  rows: ReportRow[];
  footerRow?: ReportRow;
  orientation?: "portrait" | "landscape";
}

/** Reusable A4 table PDF that consumes the same ReportColumn[]/ReportRow[] the reports feed to CSV. */
export function GenericTablePdfDocument({
  title,
  columns,
  rows,
  footerRow,
  orientation = "landscape",
}: GenericTablePdfProps) {
  const totalMin = columns.reduce((s, c) => s + (c.minWidth || 100), 0) || 1;
  const widthOf = (c: ReportColumn) =>
    `${((c.minWidth || 100) / totalMin) * 100}%`;
  const alignOf = (c: ReportColumn): "left" | "right" =>
    c.currency || c.align === "right" ? "right" : "left";
  const hasGroups = columns.some((c) => c.group);

  return (
    <Document>
      <Page size="A4" orientation={orientation} style={styles.page}>
        <Text style={styles.title}>{title}</Text>
        <View style={styles.table}>
          {hasGroups && (
            <View style={[styles.row, styles.headerRow]} fixed>
              {groupSegments(columns).map((seg) => (
                <Text
                  key={seg.key}
                  style={[
                    styles.cell,
                    styles.headerCell,
                    {
                      width: `${(seg.minWidth / totalMin) * 100}%`,
                      textAlign: "center",
                    },
                  ]}
                >
                  {seg.label}
                </Text>
              ))}
            </View>
          )}
          <View style={[styles.row, styles.headerRow]} fixed>
            {columns.map((c) => (
              <Text
                key={c.key}
                style={[
                  styles.cell,
                  styles.headerCell,
                  { width: widthOf(c), textAlign: alignOf(c) },
                ]}
              >
                {c.label}
              </Text>
            ))}
          </View>
          {rows.map((r, i) => (
            <View key={i} style={styles.row} wrap={false}>
              {columns.map((c) => (
                <Text
                  key={c.key}
                  style={[
                    styles.cell,
                    { width: widthOf(c), textAlign: alignOf(c) },
                  ]}
                >
                  {fmtCell(c, r)}
                </Text>
              ))}
            </View>
          ))}
          {footerRow && (
            <View style={[styles.row, styles.footerRow]} wrap={false}>
              {columns.map((c) => (
                <Text
                  key={c.key}
                  style={[
                    styles.cell,
                    styles.headerCell,
                    { width: widthOf(c), textAlign: alignOf(c) },
                  ]}
                >
                  {fmtCell(c, footerRow)}
                </Text>
              ))}
            </View>
          )}
        </View>
      </Page>
    </Document>
  );
}
