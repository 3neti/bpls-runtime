/**
 * Pure adapter that flattens an abstract report's fees-record shape into the
 * generic ReportColumn[]/ReportRow[] the PDF table consumes. Kept in its own
 * module (no @react-pdf/renderer import) so the abstract report components can
 * use it without pulling react-pdf into their initial bundle — the heavy PDF
 * code stays behind the dynamic import in download-pdf-button.tsx.
 */

import type { ReportColumn, ReportRow } from "./data-table";

export interface AbstractReportData {
  columns: string[];
  rows: Array<{
    orNumber: string;
    payorName: string;
    fees: Record<string, number>;
    total: number;
  }>;
  totals: Record<string, number>;
  grandTotal: number;
}

export function abstractToTablePdf(data: AbstractReportData): {
  columns: ReportColumn[];
  rows: ReportRow[];
  footerRow: ReportRow;
} {
  const columns: ReportColumn[] = [
    { key: "orNumber", label: "OR #", minWidth: 90 },
    { key: "payorName", label: "NAME OF PAYOR", minWidth: 180 },
    ...data.columns.map(
      (name): ReportColumn => ({
        key: name,
        label: name,
        currency: true,
        minWidth: 110,
      })
    ),
    { key: "total", label: "TOTAL", currency: true, minWidth: 110 },
  ];
  const rows: ReportRow[] = data.rows.map((r) => ({
    orNumber: r.orNumber,
    payorName: r.payorName,
    ...r.fees,
    total: r.total,
  }));
  const footerRow: ReportRow = {
    orNumber: "",
    payorName: "TOTAL",
    ...data.totals,
    total: data.grandTotal,
  };
  return { columns, rows, footerRow };
}
