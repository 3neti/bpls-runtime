"use client";

import { useState } from "react";
import { FileDown, Loader2 } from "lucide-react";
import { Button } from "@repo/ui/components/button";
import { toast } from "sonner";
import type { ExportResult } from "@/lib/exports/types";
import { triggerDownload } from "./report-download";

/**
 * Download-PDF button that calls a server export action (which renders the full
 * report server-side) and streams the result to a browser download. Replaces the
 * former client-side @react-pdf/renderer PDFDownloadLink.
 */
export function PdfExportButton({
  onDownload,
  disabled,
  label = "Download PDF",
}: {
  onDownload: () => Promise<ExportResult>;
  disabled?: boolean;
  label?: string;
}) {
  const [loading, setLoading] = useState(false);

  const handleClick = async () => {
    setLoading(true);
    try {
      const result = await onDownload();
      triggerDownload(result);
    } catch (error) {
      console.error("Failed to generate PDF:", error);
      toast.error("Failed to generate PDF. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      variant="outline"
      onClick={handleClick}
      disabled={disabled || loading}
    >
      {loading ? (
        <>
          <Loader2 className="mr-2 size-4 animate-spin" /> Preparing…
        </>
      ) : (
        <>
          <FileDown className="mr-2 size-4" /> {label}
        </>
      )}
    </Button>
  );
}
