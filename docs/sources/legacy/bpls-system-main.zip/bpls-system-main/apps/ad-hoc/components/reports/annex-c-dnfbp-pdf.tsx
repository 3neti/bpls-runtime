import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
} from "@react-pdf/renderer";
import type { DnfbpReportData, DnfbpSection } from "@repo/backend/convex/reports";
import { sectionLetter } from "@/lib/section-letter";

// Same LGU identity as the taxpayer account card PDF.
const PROVINCE_LINE = "Province of Zamboanga Sibugay";
const MUNICIPALITY_LINE = "MUNICIPALITY OF IPIL";

// The blank government form shows 5 numbered empty rows per section; mirror
// that when a selected classification has no businesses.
const MIN_EMPTY_ROWS = 5;

// Fixed column point-widths (A4 portrait content = 595 - 2×16 = 563pt).
const C = {
  no: 20,
  name: 118,
  address: 130,
  email: 92,
  contact: 78,
  permit: 72,
  issued: 53,
};
const HEADER_BG = "#C6E0B4"; // light green header band, as on the ANNEX C form
const ROW_H = 18;

const s = StyleSheet.create({
  page: {
    paddingVertical: 24,
    paddingHorizontal: 16,
    fontFamily: "Helvetica",
    fontSize: 8,
    color: "#000",
  },
  annex: {
    fontSize: 11,
    fontFamily: "Helvetica-Bold",
    textAlign: "right",
    marginBottom: 10,
  },
  provLine: { fontSize: 10, textAlign: "center" },
  muniLine: { fontSize: 10, fontFamily: "Helvetica-Bold", textAlign: "center" },
  title: {
    fontSize: 10,
    fontFamily: "Helvetica-Bold",
    marginTop: 14,
    marginBottom: 10,
  },
  sectionHeading: {
    fontSize: 9,
    fontFamily: "Helvetica-Bold",
    marginBottom: 3,
  },
  table: { borderTop: "1pt solid #000", borderLeft: "1pt solid #000" },
  row: { flexDirection: "row" },
  hCell: {
    borderRight: "1pt solid #000",
    borderBottom: "1pt solid #000",
    backgroundColor: HEADER_BG,
    fontFamily: "Helvetica-Bold",
    fontSize: 7.5,
    textAlign: "center",
    justifyContent: "center",
    paddingHorizontal: 2,
    paddingVertical: 4,
  },
  dCell: {
    borderRight: "1pt solid #000",
    borderBottom: "1pt solid #000",
    fontSize: 7.5,
    paddingHorizontal: 3,
    paddingVertical: 3,
    minHeight: ROW_H,
  },
});

function HeaderRow() {
  const cell = (w: number, label: string) => (
    <View style={[s.hCell, { width: w }]}>
      <Text>{label}</Text>
    </View>
  );
  return (
    <View style={s.row}>
      {cell(C.no, "")}
      {cell(C.name, "Business Name")}
      {cell(C.address, "Address")}
      {cell(C.email, "e-Mail")}
      {cell(C.contact, "Contact Details")}
      {cell(C.permit, "Mayor's Permit/\nLicense No.")}
      {cell(C.issued, "Issued on")}
    </View>
  );
}

function DataRow({
  seq,
  values,
}: {
  seq: number;
  values: [string, string, string, string, string, string];
}) {
  const widths = [C.name, C.address, C.email, C.contact, C.permit, C.issued];
  return (
    <View style={s.row} wrap={false}>
      <Text style={[s.dCell, { width: C.no, textAlign: "center" }]}>{String(seq)}</Text>
      {values.map((v, i) => (
        <Text key={i} style={[s.dCell, { width: widths[i] }]}>
          {v}
        </Text>
      ))}
    </View>
  );
}

function SectionBlock({ section, index }: { section: DnfbpSection; index: number }) {
  const emptyFiller = section.rows.length === 0 ? MIN_EMPTY_ROWS : 0;
  return (
    <View style={{ marginBottom: 14 }}>
      {/* Keep the heading, header band and first row together across pages. */}
      <View wrap={false}>
        <Text style={s.sectionHeading}>
          {sectionLetter(index)}. {section.title}
        </Text>
        <View style={s.table}>
          <HeaderRow />
          {section.rows.slice(0, 1).map((r, i) => (
            <DataRow
              key={`first-${i}`}
              seq={1}
              values={[r.businessName, r.address, r.email, r.contactDetails, r.permitNumber, r.issuedOn]}
            />
          ))}
        </View>
      </View>
      <View style={[s.table, { borderTop: "0" }]}>
        {section.rows.slice(1).map((r, i) => (
          <DataRow
            key={i}
            seq={i + 2}
            values={[r.businessName, r.address, r.email, r.contactDetails, r.permitNumber, r.issuedOn]}
          />
        ))}
        {Array.from({ length: emptyFiller }).map((_, i) => (
          <DataRow key={`empty-${i}`} seq={i + 1} values={["", "", "", "", "", ""]} />
        ))}
      </View>
    </View>
  );
}

/**
 * ANNEX C — Semestral Report on Designated Non-Financial Businesses and
 * Professions (DNFBPs). One lettered Category - Sub Category section per
 * selection, flowing across as many A4 portrait pages as needed.
 */
export function AnnexCDnfbpDocument({ data }: { data: DnfbpReportData }) {
  return (
    <Document>
      <Page size="A4" style={s.page}>
        <Text style={s.annex}>ANNEX C</Text>
        <Text style={s.provLine}>{PROVINCE_LINE}</Text>
        <Text style={s.muniLine}>{MUNICIPALITY_LINE}</Text>
        <Text style={s.title}>
          SEMESTRAL REPORT ON DESIGNATED NON-FINANCIAL BUSINESSES AND PROFESSIONS
          (DNFBPs) WITH LICENSES/PERMITS ISSUED BY THE CITY/MUNICIPALITY
        </Text>
        {data.sections.map((section, i) => (
          <SectionBlock
            key={`${section.categoryId}-${section.subCategoryId ?? "all"}`}
            section={section}
            index={i}
          />
        ))}
      </Page>
    </Document>
  );
}
