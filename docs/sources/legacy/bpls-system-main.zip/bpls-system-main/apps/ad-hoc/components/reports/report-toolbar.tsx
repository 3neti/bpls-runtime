"use client";

import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { DatePicker } from "@repo/ui/components/date-picker";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";
import { Tabs, TabsList, TabsTrigger } from "@repo/ui/components/tabs";
import { Download, Loader2, Play } from "lucide-react";
import type { ReactNode } from "react";

/** Month options for the optional Month selector (0 = all months). */
const MONTHS: { value: number; label: string }[] = [
  { value: 0, label: "All Months" },
  { value: 1, label: "January" },
  { value: 2, label: "February" },
  { value: 3, label: "March" },
  { value: 4, label: "April" },
  { value: 5, label: "May" },
  { value: 6, label: "June" },
  { value: 7, label: "July" },
  { value: 8, label: "August" },
  { value: 9, label: "September" },
  { value: 10, label: "October" },
  { value: 11, label: "November" },
  { value: 12, label: "December" },
];

interface ReportToolbarProps {
  // Date range (optional)
  showDateRange?: boolean;
  dateFrom?: string;
  dateTo?: string;
  onDateFromChange?: (value: string) => void;
  onDateToChange?: (value: string) => void;
  dateFromLabel?: string;
  dateToLabel?: string;

  // OR number range (optional)
  showOrNumberRange?: boolean;
  orNumberFrom?: string;
  orNumberTo?: string;
  onOrNumberFromChange?: (value: string) => void;
  onOrNumberToChange?: (value: string) => void;

  // Year selector (optional)
  showYear?: boolean;
  year?: number;
  onYearChange?: (value: number) => void;
  yearOptions?: number[];

  // Month selector (optional; 0 = all months)
  showMonth?: boolean;
  month?: number;
  onMonthChange?: (value: number) => void;

  // Rank By selector (optional)
  showRankBy?: boolean;
  rankBy?: string;
  onRankByChange?: (value: string) => void;
  rankByOptions?: { value: string; label: string }[];

  // Fee scope segmented switch (optional)
  showFeeScope?: boolean;
  feeScope?: string;
  onFeeScopeChange?: (value: string) => void;
  feeScopeOptions?: { value: string; label: string }[];
  feeScopeLabel?: string;

  // Custom filter controls (optional) rendered after the built-in filters,
  // before the Generate button — e.g. the DNFBP category multi-selects.
  filters?: ReactNode;

  // Actions
  onGenerate: () => void;
  onExport: () => void;
  isLoading: boolean;
  hasData: boolean;
  /** Extra action buttons rendered after Export CSV (e.g. Download PDF). */
  extraActions?: ReactNode;
}

export function ReportToolbar({
  showDateRange = false,
  dateFrom = "",
  dateTo = "",
  onDateFromChange = () => {},
  onDateToChange = () => {},
  dateFromLabel = "Date From",
  dateToLabel = "Date To",
  showOrNumberRange = false,
  orNumberFrom = "",
  orNumberTo = "",
  onOrNumberFromChange = () => {},
  onOrNumberToChange = () => {},
  showYear = false,
  year,
  onYearChange = () => {},
  yearOptions = [],
  showMonth = false,
  month,
  onMonthChange = () => {},
  showRankBy = false,
  rankBy,
  onRankByChange = () => {},
  rankByOptions = [],
  showFeeScope = false,
  feeScope,
  onFeeScopeChange = () => {},
  feeScopeOptions = [],
  feeScopeLabel = "Amounts",
  filters,
  onGenerate,
  onExport,
  isLoading,
  hasData,
  extraActions,
}: ReportToolbarProps) {
  return (
    <div className="flex flex-wrap items-end gap-4">
      {showYear && (
        <div className="grid gap-1.5">
          <Label className="text-xs">Year</Label>
          <Select
            value={year !== undefined ? String(year) : undefined}
            onValueChange={(v) => onYearChange(Number(v))}
          >
            <SelectTrigger className="w-32">
              <SelectValue placeholder="Year" />
            </SelectTrigger>
            <SelectContent>
              {yearOptions.map((y) => (
                <SelectItem key={y} value={String(y)}>
                  {y}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {showMonth && (
        <div className="grid gap-1.5">
          <Label className="text-xs">Month</Label>
          <Select
            value={month !== undefined ? String(month) : undefined}
            onValueChange={(v) => onMonthChange(Number(v))}
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Month" />
            </SelectTrigger>
            <SelectContent>
              {MONTHS.map((m) => (
                <SelectItem key={m.value} value={String(m.value)}>
                  {m.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {showDateRange && (
        <>
          <div className="grid gap-1.5">
            <Label className="text-xs">{dateFromLabel}</Label>
            <DatePicker
              value={dateFrom}
              onChange={onDateFromChange}
              placeholder="Start date"
              className="w-44"
            />
          </div>
          <div className="grid gap-1.5">
            <Label className="text-xs">{dateToLabel}</Label>
            <DatePicker
              value={dateTo}
              onChange={onDateToChange}
              placeholder="End date"
              className="w-44"
            />
          </div>
        </>
      )}

      {showOrNumberRange && (
        <>
          <div className="grid gap-1.5">
            <Label htmlFor="or-from" className="text-xs">
              OR # From
            </Label>
            <Input
              id="or-from"
              type="text"
              value={orNumberFrom}
              onChange={(e) => onOrNumberFromChange(e.target.value)}
              placeholder="e.g. 8753500"
              className="w-36"
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="or-to" className="text-xs">
              OR # To
            </Label>
            <Input
              id="or-to"
              type="text"
              value={orNumberTo}
              onChange={(e) => onOrNumberToChange(e.target.value)}
              placeholder="e.g. 8753600"
              className="w-36"
            />
          </div>
        </>
      )}

      {showRankBy && (
        <div className="grid gap-1.5">
          <Label className="text-xs">Rank By</Label>
          <Select
            value={rankBy !== undefined ? rankBy : undefined}
            onValueChange={(v) => onRankByChange(v)}
          >
            <SelectTrigger className="w-44">
              <SelectValue placeholder="Rank by" />
            </SelectTrigger>
            <SelectContent>
              {rankByOptions.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {showFeeScope && (
        <div className="grid gap-1.5">
          <Label className="text-xs">{feeScopeLabel}</Label>
          <Tabs value={feeScope} onValueChange={(v) => onFeeScopeChange(v)}>
            <TabsList>
              {feeScopeOptions.map((opt) => (
                <TabsTrigger key={opt.value} value={opt.value}>
                  {opt.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </div>
      )}

      {filters}

      <Button onClick={onGenerate} disabled={isLoading}>
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Generating...
          </>
        ) : (
          <>
            <Play className="mr-2 h-4 w-4" />
            Generate
          </>
        )}
      </Button>
      <Button variant="outline" onClick={onExport} disabled={!hasData || isLoading}>
        <Download className="mr-2 h-4 w-4" />
        Export CSV
      </Button>
      {extraActions}
    </div>
  );
}
