"use client";

import { useMemo, type ReactNode } from "react";
import {
  VirtualTable,
  type VirtualHeaderRow,
  type VirtualMiddleColumn,
  type VirtualPinnedColumn,
} from "./virtual-table";

interface ReportRow {
  orNumber: string;
  payorName: string;
  fees: Record<string, number>;
  total: number;
  source: string;
}

interface ReportTableProps {
  columns: string[];
  rows: ReportRow[];
  totals: Record<string, number>;
  grandTotal: number;
}

const ROW_HEIGHT = 32;
const OR_COL_WIDTH = 110;
const PAYOR_COL_WIDTH = 200;
const FEE_COL_WIDTH = 120;
const TOTAL_COL_WIDTH = 130;

function formatCurrency(value: number | undefined): string {
  if (!value || value === 0) return "-";
  return value.toLocaleString("en-PH", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

export function ReportTable({
  columns: reportColumns,
  rows,
  totals,
  grandTotal,
}: ReportTableProps) {
  const feeColumnHeaders = useMemo(
    () => reportColumns.filter((c) => c !== "OR #" && c !== "NAME OF PAYOR"),
    [reportColumns]
  );

  const pinnedLeft = useMemo<VirtualPinnedColumn<ReportRow>[]>(
    () => [
      {
        id: "orNumber",
        width: OR_COL_WIDTH,
        render: (row) => (
          <span className="font-mono text-xs">{row.orNumber}</span>
        ),
        header: ["Total", "OR #"],
      },
      {
        id: "payorName",
        width: PAYOR_COL_WIDTH,
        render: (row) => (
          <span className="text-xs whitespace-nowrap">{row.payorName}</span>
        ),
        header: ["", "NAME OF PAYOR"],
      },
    ],
    []
  );

  const pinnedRight = useMemo<VirtualPinnedColumn<ReportRow>[]>(
    () => [
      {
        id: "total",
        width: TOTAL_COL_WIDTH,
        render: (row) => (
          <span className="font-mono text-xs font-semibold text-right block">
            {formatCurrency(row.total)}
          </span>
        ),
        header: [
          <span key="gt" className="block text-right font-mono font-bold">
            {grandTotal > 0 ? `₱${formatCurrency(grandTotal)}` : "-"}
          </span>,
          <span key="lbl" className="block text-right">
            TOTAL
          </span>,
        ],
      },
    ],
    [grandTotal]
  );

  const middleColumns = useMemo<VirtualMiddleColumn<ReportRow>[]>(
    () =>
      feeColumnHeaders.map((name) => ({
        id: name,
        width: FEE_COL_WIDTH,
        getValue: (row) => formatCurrency(row.fees[name] ?? 0),
        cellClassName: "font-mono text-xs text-right block",
      })),
    [feeColumnHeaders]
  );

  const headerRows = useMemo<VirtualHeaderRow[]>(
    () => [
      {
        // Totals row
        className: "bg-blue-50 dark:bg-[#0a1628]",
        stickyClassName: "bg-blue-50 dark:bg-[#0a1628]",
        renderMiddle: (colId): ReactNode => (
          <span className="block text-right font-mono">
            {formatCurrency(totals[colId])}
          </span>
        ),
      },
      {
        // Column labels row
        className: "bg-blue-100 dark:bg-[#0d1d33]",
        stickyClassName: "bg-blue-100 dark:bg-[#0d1d33]",
        renderMiddle: (colId): ReactNode => (
          <span className="text-xs whitespace-nowrap">{colId}</span>
        ),
      },
    ],
    [totals]
  );

  return (
    <VirtualTable
      rows={rows}
      pinnedLeft={pinnedLeft}
      pinnedRight={pinnedRight}
      middleColumns={middleColumns}
      headerRows={headerRows}
      rowHeight={ROW_HEIGHT}
      maxHeight="calc(100vh - 280px)"
      emptyMessage="No data. Adjust the date range and click Generate."
      footerNote={`${rows.length.toLocaleString()} records`}
    />
  );
}
