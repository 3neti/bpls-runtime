"use client";

import { useState, useCallback, useMemo } from "react";
import {
  fetchBusinessTaxByMajor,
  exportBusinessTaxByMajor,
} from "@/lib/actions/business-tax-by-major";
import { DataTable, type ReportColumn, type ReportRow } from "./data-table";
import { ReportToolbar } from "./report-toolbar";
import { ReportSummary } from "./report-summary";
import { PdfExportButton } from "./pdf-export-button";
import { TruncationNotice } from "./truncation-notice";
import { triggerDownload } from "./report-download";
import { buildFooterRow, type FooterSpec } from "@/lib/exports/footer";
import type { TableExportMeta } from "@/lib/exports/table-export";
import { DISPLAY_ROW_CAP, type ExportFormat } from "@/lib/exports/types";
import { toast } from "sonner";

const COLUMNS: ReportColumn[] = [
  { key: "majorType", label: "Major Type", minWidth: 220 },
  { key: "amount", label: "Amount", currency: true, minWidth: 120 },
];

const SUMMARY_POINTS = [
  "Summarizes COLLECTED business tax by major business type — only completed payments are counted.",
  "Amount = business tax collected (fees categorized as Tax). Surcharge and interest/penalty collections are excluded from this report.",
  "Each establishment is grouped by the major type of its first line of business; businesses whose type can't be matched appear under 'Unclassified'.",
  "Use the optional date range to limit to collections within a period (by payment date), or an OR # range to limit to specific receipts. Data refreshes from the live system about once an hour.",
];

const FOOTER: FooterSpec = {
  labelKey: "majorType",
  label: "Total Amount",
  sumKeys: ["amount"],
};

interface TaxData {
  rows: ReportRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}

export function BusinessTaxByMajor() {
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [orNumberFrom, setOrNumberFrom] = useState("");
  const [orNumberTo, setOrNumberTo] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [data, setData] = useState<TaxData | null>(null);

  // Totals come from the server's full-data column totals so they stay correct
  // even when the on-screen rows are capped.
  const footerRow = useMemo<ReportRow | undefined>(
    () =>
      data && data.totalCount > 0
        ? buildFooterRow(FOOTER, data.columnTotals)
        : undefined,
    [data]
  );

  const buildParams = useCallback(
    () => ({
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
      orNumberFrom: orNumberFrom.trim() || undefined,
      orNumberTo: orNumberTo.trim() || undefined,
    }),
    [dateFrom, dateTo, orNumberFrom, orNumberTo]
  );

  const exportMeta = useCallback(
    (): TableExportMeta => ({
      columns: COLUMNS,
      title: "BUSINESS TAX ON MAJOR TYPE",
      orientation: "portrait",
      footer: FOOTER,
      filenameBase: `business-tax-by-major-type-${dateFrom || "all"}-to-${dateTo || "all"}`,
    }),
    [dateFrom, dateTo]
  );

  const handleGenerate = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await fetchBusinessTaxByMajor(buildParams());
      setData(result);
      if (result.totalCount === 0) {
        toast.info("No collections found for the selected filters.");
      } else {
        toast.success(`Report generated with ${result.totalCount} major types.`);
      }
    } catch (error) {
      console.error("Failed to generate business tax report:", error);
      toast.error("Failed to generate report. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [buildParams]);

  const handleCsvExport = useCallback(async () => {
    setIsExporting(true);
    try {
      const result = await exportBusinessTaxByMajor(
        buildParams(),
        exportMeta(),
        "csv"
      );
      triggerDownload(result);
      toast.success("CSV exported successfully.");
    } catch (error) {
      console.error("Failed to export CSV:", error);
      toast.error("Failed to export CSV. Please try again.");
    } finally {
      setIsExporting(false);
    }
  }, [buildParams, exportMeta]);

  const exportPdf = useCallback(
    (format: ExportFormat) =>
      exportBusinessTaxByMajor(buildParams(), exportMeta(), format),
    [buildParams, exportMeta]
  );

  const hasData = !!data && data.totalCount > 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">
          BUSINESS TAX ON MAJOR TYPE
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Collected business tax by major business type — surcharge and interest excluded.
        </p>
      </div>

      <ReportSummary points={SUMMARY_POINTS} />

      <ReportToolbar
        showDateRange
        dateFrom={dateFrom}
        dateTo={dateTo}
        onDateFromChange={setDateFrom}
        onDateToChange={setDateTo}
        dateFromLabel="Collected From"
        dateToLabel="Collected To"
        showOrNumberRange
        orNumberFrom={orNumberFrom}
        orNumberTo={orNumberTo}
        onOrNumberFromChange={setOrNumberFrom}
        onOrNumberToChange={setOrNumberTo}
        onGenerate={handleGenerate}
        onExport={handleCsvExport}
        isLoading={isLoading || isExporting}
        hasData={hasData}
        extraActions={
          hasData ? (
            <PdfExportButton onDownload={() => exportPdf("pdf")} />
          ) : undefined
        }
      />

      {data?.truncated && (
        <TruncationNotice totalCount={data.totalCount} cap={DISPLAY_ROW_CAP} />
      )}

      {data && (
        <DataTable
          columns={COLUMNS}
          rows={data.rows}
          footerRow={footerRow}
          zeroAs="zero"
        />
      )}

      {!data && !isLoading && (
        <div className="flex items-center justify-center rounded-lg border border-dashed p-12">
          <p className="text-sm text-muted-foreground">
            Optionally filter by collection date or OR # range, then click Generate to view the report.
          </p>
        </div>
      )}
    </div>
  );
}
