"use client";

import { useState, useCallback } from "react";
import { fetchPlds, exportPlds } from "@/lib/actions/plds";
import { DataTable, type ReportColumn, type ReportRow } from "./data-table";
import { ReportToolbar } from "./report-toolbar";
import { ReportSummary } from "./report-summary";
import { PdfExportButton } from "./pdf-export-button";
import { TruncationNotice } from "./truncation-notice";
import { triggerDownload } from "./report-download";
import type { TableExportMeta } from "@/lib/exports/table-export";
import { DISPLAY_ROW_CAP, type ExportFormat } from "@/lib/exports/types";
import { toast } from "sonner";

const COLUMNS: ReportColumn[] = [
  { key: "dateRegisteredToLgu",   label: "DATE REGISTERED TO LGU",     minWidth: 150 },
  { key: "businessIdNumber",      label: "BUSINESS ID NUMBER",          minWidth: 140 },
  { key: "businessName",          label: "BUSINESS NAME",               minWidth: 200 },
  { key: "registeredName",        label: "REGISTERED NAME",             minWidth: 190 },
  { key: "completeBusinessAddress",label: "COMPLETE BUSINESS ADDRESS",  minWidth: 240 },
  { key: "tin",                   label: "TAX IDENTIFICATION NUMBER",   minWidth: 160 },
  { key: "newOrRenewal",          label: "NEW OR RENEWAL",              minWidth: 100 },
  // Blank until businesses.categoryId/subCategoryId sync to ClickHouse (Part B).
  { key: "mainEconomicActivity",  label: "MAIN ECONOMIC ACTIVITY",      minWidth: 180 },
  { key: "majorProductServices",  label: "MAJOR PRODUCT/ SERVICES",     minWidth: 180 },
  { key: "grossRevenue",          label: "GROSS REVENUE",               currency: true, csvFormat: "plain", minWidth: 130 },
  { key: "capital",               label: "CAPITAL",                     currency: true, csvFormat: "plain", minWidth: 120 },
  { key: "typeOfBusiness",        label: "TYPE OF BUSINESS",            minWidth: 160 },
  { key: "totalEmployees",        label: "TOTAL EMPLOYEES",             minWidth: 120 },
  { key: "totalEmployeesMale",    label: "TOTAL EMPLOYEES MALE",        minWidth: 130 },
  { key: "totalEmployeesFemale",  label: "TOTAL EMPLOYEES FEMALE",      minWidth: 140 },
  { key: "telephoneNumber",       label: "TELEPHONE NUMBER",            minWidth: 140 },
  { key: "mobileNumber",          label: "MOBILE NUMBER",               minWidth: 130 },
  { key: "emailAddress",          label: "EMAIL ADDRESS",               minWidth: 170 },
  { key: "socialMediaAccounts",   label: "SOCIAL MEDIA ACCOUNTS",       minWidth: 150 },
  { key: "website",               label: "WEBSITE",                     minWidth: 130 },
  { key: "dtiSecCdaNumber",       label: "DTI/SEC/CDA REGISTRATION NUMBER", minWidth: 190 },
  { key: "dateRegistered",        label: "DATE REGISTERED",             minWidth: 130 },
  { key: "assets",                label: "ASSETS",                      currency: true, csvFormat: "plain", minWidth: 120 },
];

const SUMMARY_POINTS = [
  "Matches the Philippine Local Development Survey (PLDS) template — one row per Released business permit application.",
  "Main Economic Activity and Major Product/Services are blank for now; they will populate once the business category feature (Part B) is deployed and Airbyte syncs the new category fields to the reporting warehouse.",
  "Gross Revenue is the sum of gross sales across all lines of business; Capital is the sum of capital investment across all lines.",
  "Social Media Accounts and Website are always blank — these fields are not collected by the BPLS system.",
  "Assets is the amount of the line-of-business fee driven by a Unit of Measurement (e.g. the Mayor's Permit Fee), summed across the application's lines of business; it is 0 when no such fee applies.",
  "Date Registered to LGU is the permit issue date (MM/DD/YYYY); Date Registered is the business registration date.",
  "Business ID Number and DTI/SEC/CDA Registration Number use the business's registration number.",
  "Date filter applies to the permit issue date.",
  "Figures are refreshed from the live system about once an hour.",
];

interface PldsData {
  rows: ReportRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}

export function PldsReport() {
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [data, setData] = useState<PldsData | null>(null);

  const title = "PLDS — PHILIPPINE LOCAL DEVELOPMENT SURVEY";

  const buildParams = useCallback(
    () => ({
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
    }),
    [dateFrom, dateTo]
  );

  const exportMeta = useCallback(
    (): TableExportMeta => ({
      columns: COLUMNS,
      title,
      orientation: "landscape",
      filenameBase: `plds-${dateFrom || "all"}-to-${dateTo || "all"}`,
    }),
    [dateFrom, dateTo]
  );

  const handleGenerate = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await fetchPlds(buildParams());
      setData(result);
      if (result.totalCount === 0) {
        toast.info("No records found for the selected date range.");
      } else {
        toast.success(`Report generated with ${result.totalCount} records.`);
      }
    } catch (error) {
      console.error("Failed to generate PLDS report:", error);
      toast.error("Failed to generate report. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [buildParams]);

  const handleCsvExport = useCallback(async () => {
    setIsExporting(true);
    try {
      const result = await exportPlds(buildParams(), exportMeta(), "csv");
      triggerDownload(result);
      toast.success("CSV exported successfully.");
    } catch (error) {
      console.error("Failed to export CSV:", error);
      toast.error("Failed to export CSV. Please try again.");
    } finally {
      setIsExporting(false);
    }
  }, [buildParams, exportMeta]);

  const exportPdf = useCallback(
    (format: ExportFormat) => exportPlds(buildParams(), exportMeta(), format),
    [buildParams, exportMeta]
  );

  const hasData = !!data && data.totalCount > 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Official government template for local business permit data — new and renewal permits.
        </p>
      </div>

      <ReportSummary points={SUMMARY_POINTS} />

      <ReportToolbar
        showDateRange
        dateFrom={dateFrom}
        dateTo={dateTo}
        onDateFromChange={setDateFrom}
        onDateToChange={setDateTo}
        dateFromLabel="Permit Issued From"
        dateToLabel="Permit Issued To"
        onGenerate={handleGenerate}
        onExport={handleCsvExport}
        isLoading={isLoading || isExporting}
        hasData={hasData}
        extraActions={
          hasData ? (
            <PdfExportButton onDownload={() => exportPdf("pdf")} />
          ) : undefined
        }
      />

      {data?.truncated && (
        <TruncationNotice totalCount={data.totalCount} cap={DISPLAY_ROW_CAP} />
      )}

      {data && <DataTable columns={COLUMNS} rows={data.rows} />}

      {!data && !isLoading && (
        <div className="flex items-center justify-center rounded-lg border border-dashed p-12">
          <p className="text-sm text-muted-foreground">
            Optionally filter by permit issue date range, then click Generate to view the report.
          </p>
        </div>
      )}
    </div>
  );
}
