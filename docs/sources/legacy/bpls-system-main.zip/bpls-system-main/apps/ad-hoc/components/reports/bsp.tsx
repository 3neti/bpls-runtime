"use client";

import { useState, useCallback } from "react";
import { fetchBsp, exportBsp } from "@/lib/actions/bsp";
import { DataTable, type ReportColumn, type ReportRow } from "./data-table";
import {
  FilterMultiSelect,
  useCategoryFilterSelection,
} from "./filter-multi-select";
import { ReportToolbar } from "./report-toolbar";
import { ReportSummary } from "./report-summary";
import { PdfExportButton } from "./pdf-export-button";
import { TruncationNotice } from "./truncation-notice";
import { triggerDownload } from "./report-download";
import type { TableExportMeta } from "@/lib/exports/table-export";
import { DISPLAY_ROW_CAP, type ExportFormat } from "@/lib/exports/types";
import { toast } from "sonner";

// Flat column labels — the official BSP template has 3-level merged headers
// (business address, line of business, status). Flattened with group prefix,
// e.g. "LOB — PAWNSHOP", "STATUS — NEW".
const COLUMNS: ReportColumn[] = [
  { key: "no",                   label: "NO.",                                    minWidth: 50 },
  { key: "bspRegNo",             label: "BSP REGISTRATION NO.",                   minWidth: 160 },
  { key: "entityName",           label: "NAME OF ENTITY",                         minWidth: 200 },
  { key: "addressHouseBldgNo",   label: "ADDRESS — HOUSE/BLDG. NO.",              minWidth: 140 },
  { key: "addressStreet",        label: "ADDRESS — STREET",                       minWidth: 180 },
  { key: "addressBarangay",      label: "ADDRESS — BARANGAY",                     minWidth: 140 },
  { key: "lobPawnshop",          label: "LOB — PAWNSHOP",                         minWidth: 120 },
  { key: "lobMoneyChanger",      label: "LOB — MONEY CHANGER/FOREIGN EXCHANGE DEALER", minWidth: 240 },
  { key: "lobRtc",               label: "LOB — REMITTANCE AND TRANSFER COMPANY (RTC)", minWidth: 240 },
  { key: "lobRtcVirtual",        label: "LOB — RTC WITH VIRTUAL CURRENCY EXCHANGE", minWidth: 220 },
  { key: "permitDateOfIssuance", label: "BUSINESS PERMIT — DATE OF ISSUANCE",     minWidth: 180 },
  { key: "permitNumber",         label: "BUSINESS PERMIT — NUMBER",               minWidth: 160 },
  { key: "statusNew",            label: "STATUS — NEW",                           minWidth: 100 },
  { key: "statusRenewal",        label: "STATUS — RENEWAL",                       minWidth: 110 },
  { key: "statusFailedToRenew",  label: "STATUS — FAILED TO RENEW",               minWidth: 150 },
  { key: "statusCancelledRevoked",label: "STATUS — CANCELLED/REVOKED/RETIRED",    minWidth: 200 },
];

const SUMMARY_POINTS = [
  "BSP Report of Non-Bank Entities — Pawnshop, Money Changing/FX, and Remittance operations.",
  "With no Category/Sub-Category selection the report covers businesses classified under 'Money Service Business'. Use the filters to change or narrow the coverage — picking Sub-Categories narrows their parent Category, like the ANNEX-C DNFBP report.",
  "Businesses are classified (Category / Sub-Category) on the admin Businesses page; rows appear as released permit applications' businesses get classified. Classifications reach this report on the warehouse sync (about once an hour).",
  "LOB X-marks use one X per business (v1 limitation): a business with a single subcategory gets one X. Multi-service entities that need multiple X marks require extending the data model to multi-select subcategories or deriving marks from per-line linesOfBusiness[].businessCategory.",
  "Status 'Failed to renew' and 'Cancelled/Revoked/Retired' are always blank — these statuses are not derivable from the available data (permits.status is only ever 'Active' in this system).",
  "BSP Registration No. is always blank — not collected by the BPLS system.",
  "Date filter applies to the permit issue date.",
];

interface BspData {
  rows: ReportRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}

export function BspReport() {
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [data, setData] = useState<BspData | null>(null);
  const {
    optionsLoading,
    categoryOptions,
    subCategoryOptions,
    selectedCategoryIds,
    selectedSubCategoryIds,
    setSelectedSubCategoryIds,
    handleCategoriesChange,
  } = useCategoryFilterSelection();

  const title = "BSP — REPORT OF NON-BANK ENTITIES PERMITS";

  const buildParams = useCallback(
    () => ({
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
      categoryIds: selectedCategoryIds,
      subCategoryIds: selectedSubCategoryIds,
    }),
    [dateFrom, dateTo, selectedCategoryIds, selectedSubCategoryIds]
  );

  const exportMeta = useCallback(
    (): TableExportMeta => ({
      columns: COLUMNS,
      title,
      orientation: "landscape",
      filenameBase: `bsp-${dateFrom || "all"}-to-${dateTo || "all"}`,
    }),
    [dateFrom, dateTo]
  );

  const handleGenerate = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await fetchBsp(buildParams());
      setData(result);
      if (result.totalCount === 0) {
        toast.info(
          "No records found. Rows appear once businesses in the selected coverage are classified on the admin Businesses page."
        );
      } else {
        toast.success(`Report generated with ${result.totalCount} records.`);
      }
    } catch (error) {
      console.error("Failed to generate BSP report:", error);
      toast.error("Failed to generate report. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [buildParams]);

  const handleCsvExport = useCallback(async () => {
    setIsExporting(true);
    try {
      const result = await exportBsp(buildParams(), exportMeta(), "csv");
      triggerDownload(result);
      toast.success("CSV exported successfully.");
    } catch (error) {
      console.error("Failed to export CSV:", error);
      toast.error("Failed to export CSV. Please try again.");
    } finally {
      setIsExporting(false);
    }
  }, [buildParams, exportMeta]);

  const exportPdf = useCallback(
    (format: ExportFormat) => exportBsp(buildParams(), exportMeta(), format),
    [buildParams, exportMeta]
  );

  const hasData = !!data && data.totalCount > 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Pawnshop, Money Changing/Foreign Exchange Dealing, and Remittance
          operations with mayor&apos;s permits — coverage adjustable via the
          Category/Sub-Category filters.
        </p>
      </div>

      <ReportSummary points={SUMMARY_POINTS} />

      <ReportToolbar
        showDateRange
        dateFrom={dateFrom}
        dateTo={dateTo}
        onDateFromChange={setDateFrom}
        onDateToChange={setDateTo}
        dateFromLabel="Permit Issued From"
        dateToLabel="Permit Issued To"
        filters={
          <>
            <FilterMultiSelect
              label="Categories"
              placeholder="Money Service Business (default)"
              options={categoryOptions}
              selected={selectedCategoryIds}
              onChange={handleCategoriesChange}
              disabled={optionsLoading}
            />
            <FilterMultiSelect
              label="Sub-Categories (optional)"
              placeholder={
                selectedCategoryIds.length === 0
                  ? "Select categories first"
                  : "All sub-categories"
              }
              options={subCategoryOptions}
              selected={selectedSubCategoryIds}
              onChange={setSelectedSubCategoryIds}
              disabled={selectedCategoryIds.length === 0}
            />
          </>
        }
        onGenerate={handleGenerate}
        onExport={handleCsvExport}
        isLoading={isLoading || isExporting}
        hasData={hasData}
        extraActions={
          hasData ? (
            <PdfExportButton onDownload={() => exportPdf("pdf")} />
          ) : undefined
        }
      />

      {data?.truncated && (
        <TruncationNotice totalCount={data.totalCount} cap={DISPLAY_ROW_CAP} />
      )}

      {data && data.totalCount > 0 && (
        <DataTable columns={COLUMNS} rows={data.rows} />
      )}

      {(!data || data.totalCount === 0) && !isLoading && (
        <div className="flex items-center justify-center rounded-lg border border-dashed p-12">
          <p className="text-sm text-muted-foreground">
            Optionally adjust the Category/Sub-Category coverage and date range,
            then click Generate. Default coverage: Money Service Business.
          </p>
        </div>
      )}
    </div>
  );
}
