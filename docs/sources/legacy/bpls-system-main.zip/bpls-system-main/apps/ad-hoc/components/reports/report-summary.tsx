import { Info } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@repo/ui/components/alert";

interface ReportSummaryProps {
  title?: string;
  /** Plain-language bullet points explaining how the report was built. */
  points: string[];
}

/**
 * A plain-language summary shown at the top of a report, aimed at
 * non-technical (treasury) users — what the report shows and how it's built.
 */
export function ReportSummary({
  title = "About this report",
  points,
}: ReportSummaryProps) {
  return (
    <Alert>
      <Info className="h-4 w-4" />
      <AlertTitle>{title}</AlertTitle>
      <AlertDescription>
        <ul className="mt-1 list-disc space-y-1 pl-4 text-sm text-muted-foreground">
          {points.map((point, i) => (
            <li key={i}>{point}</li>
          ))}
        </ul>
      </AlertDescription>
    </Alert>
  );
}
