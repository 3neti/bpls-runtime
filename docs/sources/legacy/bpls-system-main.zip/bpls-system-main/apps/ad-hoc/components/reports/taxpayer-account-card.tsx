"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { ArrowLeft, Download, Loader2, Printer } from "lucide-react";
import { Button } from "@repo/ui/components/button";
import {
  fetchTaxpayerAccountCard,
  exportTaxpayerAccountCard,
} from "@/lib/actions/taxpayer-account-card";
import type {
  TaxpayerCardData,
  TaxpayerCard,
  TaxpayerCardQuarter,
} from "@repo/backend/convex/reports";
import { PdfExportButton } from "./pdf-export-button";
import { triggerDownload } from "./report-download";
import { toast } from "sonner";

// Institutional header — matches the municipal form. Could later be wired to
// platformSettings if the deployment serves another LGU.
const PROVINCE = "PROVINCE OF ZAMBOANGA SIBUGAY";
const MUNICIPALITY = "MUNICIPALITY OF IPIL";

// Minimum number of grid rows so a sparse card still resembles the blank form.
export const MIN_ROWS = 8;

function money(value: number): string {
  if (!Number.isFinite(value) || value === 0) return "";
  return value.toLocaleString("en-PH", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

const TH = "border border-black px-1 py-1 text-[10px] font-bold text-center align-middle leading-tight";
const TD = "border border-black px-1 text-[11px] align-middle h-8";

function InfoField({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-end gap-2">
      <span className="whitespace-nowrap font-bold">{label}:</span>
      <span className="min-h-[1.25rem] flex-1 border-b border-black px-1">
        {value || " "}
      </span>
    </div>
  );
}

function QuarterCells({ q }: { q: TaxpayerCardQuarter }) {
  return (
    <>
      <td className={`${TD} text-center font-mono text-[10px]`}>{q.receipt}</td>
      <td className={`${TD} text-right font-mono`}>{money(q.amount)}</td>
    </>
  );
}

/** A single Taxpayer's Account Card for ONE Kind of Business. */
function CardSection({
  data,
  card,
}: {
  data: TaxpayerCardData;
  card: TaxpayerCard;
}) {
  const dataRows = card.rows;
  const fillerCount = Math.max(0, MIN_ROWS - dataRows.length);

  return (
    <div className="taxpayer-card-page overflow-x-auto rounded-md border bg-white p-6 text-black print:rounded-none print:border-0 print:p-0">
      <div className="min-w-[1000px]">
        {/* Form header */}
        <div className="text-center">
          <p className="text-sm font-bold">{PROVINCE}</p>
          <p className="text-sm font-bold">{MUNICIPALITY}</p>
          <h2 className="mt-1 text-2xl font-extrabold tracking-wide">
            TAXPAYER&apos;S ACCOUNT CARD
          </h2>
          <p className="mx-auto mt-1 max-w-xl border-t border-black pt-1 text-xs font-bold">
            (KIND of BUSINESS)
          </p>
          <p className="text-sm font-bold uppercase">{card.kindOfBusiness || " "}</p>
        </div>

        {/* Taxpayer / business info */}
        <div className="mt-4 grid grid-cols-1 gap-x-10 gap-y-2 text-sm sm:grid-cols-2">
          <InfoField label="NAME" value={data.ownerName} />
          <InfoField label="RESIDENCE ADDRESS" value={data.residenceAddress} />
          <InfoField label="BUSINESS TRADE NAME" value={data.businessName} />
          <InfoField label="BUSINESS ADDRESS" value={data.businessAddress} />
        </div>

        {/* Ledger grid */}
        <table className="mt-4 w-full border-collapse">
          <thead>
            <tr>
              <th className={TH} rowSpan={3}>YEAR</th>
              <th className={TH} rowSpan={3}>ANNUAL TAX</th>
              <th className={TH} colSpan={8}>
                QUARTER (RECEIPT NUMBER &amp; AMOUNT PAID)
              </th>
              <th className={TH} rowSpan={3}>FINES/ PENALTIES</th>
              <th className={TH} rowSpan={3}>REGULATORY FEES</th>
              <th className={TH} rowSpan={3}>TOTAL</th>
              <th className={TH} colSpan={2}>DATE LICENSE</th>
              <th className={TH} rowSpan={3}>ORDINANCE NUMBER</th>
              <th className={TH} rowSpan={3}>INITIAL</th>
            </tr>
            <tr>
              <th className={TH} colSpan={2}>FIRST</th>
              <th className={TH} colSpan={2}>SECOND</th>
              <th className={TH} colSpan={2}>THIRD</th>
              <th className={TH} colSpan={2}>FOURTH</th>
              <th className={TH} rowSpan={2}>ISSUED</th>
              <th className={TH} rowSpan={2}>SURRENDERED</th>
            </tr>
            <tr>
              <th className={TH}>OR #</th>
              <th className={TH}>AMOUNT</th>
              <th className={TH}>OR #</th>
              <th className={TH}>AMOUNT</th>
              <th className={TH}>OR #</th>
              <th className={TH}>AMOUNT</th>
              <th className={TH}>OR #</th>
              <th className={TH}>AMOUNT</th>
            </tr>
          </thead>
          <tbody>
            {dataRows.map((r) => (
              <tr key={r.year}>
                <td className={`${TD} text-center font-semibold`}>{r.year}</td>
                <td className={`${TD} text-right font-mono`}>{money(r.annualTax)}</td>
                <QuarterCells q={r.q1} />
                <QuarterCells q={r.q2} />
                <QuarterCells q={r.q3} />
                <QuarterCells q={r.q4} />
                <td className={`${TD} text-right font-mono`}>{money(r.finesPenalties)}</td>
                <td className={`${TD} text-right font-mono`}>{money(r.regulatoryFees)}</td>
                <td className={`${TD} text-right font-mono font-semibold`}>{money(r.total)}</td>
                <td className={`${TD} text-center text-[10px]`}>{r.dateLicenseIssued}</td>
                <td className={`${TD} text-center text-[10px]`}>{r.dateLicenseSurrendered}</td>
                <td className={`${TD} text-center text-[10px]`}>{r.ordinanceNumber}</td>
                <td className={TD} />
              </tr>
            ))}
            {Array.from({ length: fillerCount }).map((_, i) => (
              <tr key={`filler-${i}`}>
                {Array.from({ length: 17 }).map((__, j) => (
                  <td key={j} className={TD} />
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function TaxpayerAccountCard({ businessId }: { businessId: string }) {
  const [data, setData] = useState<TaxpayerCardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isExporting, setIsExporting] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setIsLoading(true);
      try {
        const result = await fetchTaxpayerAccountCard({ businessId });
        if (!cancelled) setData(result);
      } catch (error) {
        console.error("Failed to load taxpayer account card:", error);
        if (!cancelled)
          toast.error("Failed to load account card. Please try again.");
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [businessId]);

  const handleExport = useCallback(async () => {
    if (!data) return;
    setIsExporting(true);
    try {
      const result = await exportTaxpayerAccountCard(businessId, "csv");
      triggerDownload(result);
      toast.success("CSV exported successfully.");
    } catch (error) {
      console.error("Failed to export CSV:", error);
      toast.error("Failed to export CSV. Please try again.");
    } finally {
      setIsExporting(false);
    }
  }, [data, businessId]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center rounded-lg border border-dashed p-12">
        <Loader2 className="mr-2 size-4 animate-spin text-muted-foreground" />
        <p className="text-sm text-muted-foreground">Loading account card…</p>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="space-y-4">
        <Link
          href="/dashboard/reports/taxpayer-card"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="size-4" /> Back to list
        </Link>
        <div className="flex items-center justify-center rounded-lg border border-dashed p-12">
          <p className="text-sm text-muted-foreground">Taxpayer not found.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Landscape printing; one card per page; hide app chrome on print. */}
      <style>{`@media print {
        @page { size: A4 landscape; margin: 8mm; }
        .taxpayer-card-page { break-before: page; }
        .taxpayer-card-page:first-of-type { break-before: auto; }
      }`}</style>

      {/* Controls (hidden when printing) */}
      <div className="flex flex-wrap items-center justify-between gap-3 print:hidden">
        <Link
          href="/dashboard/reports/taxpayer-card"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="size-4" /> Back to list
        </Link>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => window.print()}>
            <Printer className="mr-2 size-4" /> Print
          </Button>
          <Button
            variant="outline"
            onClick={handleExport}
            disabled={data.cards.length === 0 || isExporting}
          >
            <Download className="mr-2 size-4" /> Export CSV
          </Button>
          <PdfExportButton
            onDownload={() => exportTaxpayerAccountCard(businessId, "pdf")}
            disabled={data.cards.length === 0}
          />
        </div>
      </div>

      {data.cards.length === 0 ? (
        <div className="flex items-center justify-center rounded-lg border border-dashed p-12">
          <p className="text-sm text-muted-foreground">
            No kinds of business or payment history on record for this taxpayer.
          </p>
        </div>
      ) : (
        <div className="space-y-6 print:space-y-0">
          {data.cards.map((card) => (
            <CardSection key={card.kindOfBusiness} data={data} card={card} />
          ))}
        </div>
      )}
    </div>
  );
}
