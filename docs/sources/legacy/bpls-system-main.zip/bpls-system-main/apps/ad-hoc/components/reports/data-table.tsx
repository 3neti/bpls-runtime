"use client";

import { useMemo, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import {
  VirtualTable,
  type VirtualFooter,
  type VirtualHeaderRow,
  type VirtualMiddleColumn,
} from "./virtual-table";

export interface ReportColumn {
  /** Key into the row record. */
  key: string;
  /** Header label. */
  label: string;
  /**
   * Optional group header (e.g. "PAID BUSINESS TAX"): consecutive columns
   * sharing the same group get a merged banner row above their labels, in the
   * on-screen table and the CSV/PDF exports alike.
   */
  group?: string;
  /** Text alignment (defaults to "left"). */
  align?: "left" | "right";
  /** Format the value as PHP currency (2 decimals). */
  currency?: boolean;
  /** Minimum column width in px. */
  minWidth?: number;
  /** Override the table-level zero rendering for this column. */
  zeroAs?: "dash" | "zero";
  /**
   * CSV-only number formatting override (does not affect on-screen display):
   *  - "peso": thousands separators + 2 decimals (e.g. 1,234.50)
   *  - "plain": natural number string, no separators/forced decimals
   * When unset, currency columns export as a plain fixed-2 number.
   */
  csvFormat?: "peso" | "plain";
}

export type ReportRow = Record<string, string | number | null | undefined>;

interface DataTableProps {
  columns: ReportColumn[];
  rows: ReportRow[];
  /** Optional bold totals row pinned to the bottom of the scroll area. */
  footerRow?: ReportRow;
  /** How to render a zero currency value. Defaults to "dash". */
  zeroAs?: "dash" | "zero";
  /** When set, rows become clickable and call this with the row's data. */
  onRowClick?: (row: ReportRow) => void;
}

const ROW_HEIGHT = 34;

function formatCurrency(value: unknown, zeroAs: "dash" | "zero"): string {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n) || n === 0) return zeroAs === "zero" ? "0.00" : "-";
  return n.toLocaleString("en-PH", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

function renderCell(
  col: ReportColumn,
  row: ReportRow,
  zeroAs: "dash" | "zero"
): string {
  const value = row[col.key];
  if (col.currency) {
    // Literal annotations (e.g. "N/A") pass through currency columns as-is.
    if (
      typeof value === "string" &&
      value.trim() !== "" &&
      Number.isNaN(Number(value))
    ) {
      return value;
    }
    return formatCurrency(value, col.zeroAs ?? zeroAs);
  }
  if (value === undefined || value === null) return "";
  return String(value);
}

export function DataTable({
  columns,
  rows,
  footerRow,
  zeroAs = "dash",
  onRowClick,
}: DataTableProps) {
  const middleColumns = useMemo<VirtualMiddleColumn<ReportRow>[]>(
    () =>
      columns.map((col) => ({
        id: col.key,
        width: col.minWidth ?? 0,
        getValue: (row) => renderCell(col, row, zeroAs),
        cellClassName: cn(
          "block text-xs whitespace-nowrap",
          col.currency || col.align === "right"
            ? "text-right font-mono"
            : "text-left"
        ),
      })),
    [columns, zeroAs]
  );

  const columnByKey = useMemo(() => {
    const m = new Map<string, ReportColumn>();
    for (const c of columns) m.set(c.key, c);
    return m;
  }, [columns]);

  const headerRows = useMemo<VirtualHeaderRow[]>(() => {
    const labelRow: VirtualHeaderRow = {
      className: "bg-muted",
      stickyClassName: "bg-muted",
      renderMiddle: (colId): ReactNode => {
        const col = columnByKey.get(colId);
        if (!col) return null;
        return (
          <span
            className={cn(
              "block",
              col.currency || col.align === "right"
                ? "text-right"
                : "text-left"
            )}
          >
            {col.label}
          </span>
        );
      },
    };
    if (!columns.some((c) => c.group)) return [labelRow];
    // Banner row: consecutive columns sharing a `group` merge into one
    // centered cell (VirtualTable folds them via middleGroupOf); ungrouped
    // columns get an empty cell above their label.
    const groupRow: VirtualHeaderRow = {
      className: "bg-muted",
      stickyClassName: "bg-muted",
      middleGroupOf: (colId) => columnByKey.get(colId)?.group,
      renderMiddle: (colId): ReactNode => {
        const group = columnByKey.get(colId)?.group;
        return group ? <span className="block text-center">{group}</span> : null;
      },
    };
    return [groupRow, labelRow];
  }, [columns, columnByKey]);

  const footer = useMemo<VirtualFooter | undefined>(
    () =>
      footerRow
        ? {
            className: "bg-muted font-semibold",
            stickyClassName: "bg-muted font-semibold",
            renderMiddle: (colId): ReactNode => {
              const col = columnByKey.get(colId);
              if (!col) return null;
              return (
                <span
                  className={cn(
                    "block",
                    col.currency || col.align === "right"
                      ? "text-right font-mono"
                      : "text-left"
                  )}
                >
                  {renderCell(col, footerRow, zeroAs)}
                </span>
              );
            },
          }
        : undefined,
    [footerRow, columnByKey, zeroAs]
  );

  return (
    <VirtualTable
      rows={rows}
      columnLayout="fluid"
      middleColumns={middleColumns}
      headerRows={headerRows}
      footer={footer}
      onRowClick={onRowClick}
      rowHeight={ROW_HEIGHT}
      maxHeight="calc(100vh - 360px)"
      emptyMessage="No data. Adjust the filters and click Generate."
      footerNote={`${rows.length.toLocaleString()} records`}
    />
  );
}
