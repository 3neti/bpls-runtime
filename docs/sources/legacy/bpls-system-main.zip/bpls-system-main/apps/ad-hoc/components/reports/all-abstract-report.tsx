"use client";

import { useState, useCallback } from "react";
import {
  fetchAllAbstractReport,
  exportAllAbstractReport,
} from "@/lib/actions/all-abstract-report";
import { DISPLAY_ROW_CAP, type ExportFormat } from "@/lib/exports/types";
import { DateFilter } from "./date-filter";
import { ReportTable } from "./report-table";
import { PdfExportButton } from "./pdf-export-button";
import { TruncationNotice } from "./truncation-notice";
import { triggerDownload } from "./report-download";
import { toast } from "sonner";

interface ReportData {
  columns: string[];
  rows: Array<{
    orNumber: string;
    payorName: string;
    fees: Record<string, number>;
    total: number;
    source: "permit" | "billing_group";
  }>;
  totals: Record<string, number>;
  grandTotal: number;
  truncated: boolean;
  totalCount: number;
}

export function AllAbstractReport() {
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [orNumberFrom, setOrNumberFrom] = useState("");
  const [orNumberTo, setOrNumberTo] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [reportData, setReportData] = useState<ReportData | null>(null);

  const buildParams = useCallback(
    () => ({
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
      orNumberFrom: orNumberFrom.trim() || undefined,
      orNumberTo: orNumberTo.trim() || undefined,
    }),
    [dateFrom, dateTo, orNumberFrom, orNumberTo]
  );

  const handleGenerate = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await fetchAllAbstractReport(buildParams());
      setReportData(result);
      if (result.totalCount === 0) {
        toast.info("No records found for the selected filters.");
      } else {
        toast.success(`Report generated with ${result.totalCount} records.`);
      }
    } catch (error) {
      console.error("Failed to generate report:", error);
      toast.error("Failed to generate report. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [buildParams]);

  const handleCsvExport = useCallback(async () => {
    setIsExporting(true);
    try {
      const result = await exportAllAbstractReport(buildParams(), "csv");
      triggerDownload(result);
      toast.success("CSV exported successfully.");
    } catch (error) {
      console.error("Failed to export CSV:", error);
      toast.error("Failed to export CSV. Please try again.");
    } finally {
      setIsExporting(false);
    }
  }, [buildParams]);

  const exportPdf = useCallback(
    (format: ExportFormat) => exportAllAbstractReport(buildParams(), format),
    [buildParams]
  );

  const hasData = !!reportData && reportData.totalCount > 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">ALL ABSTRACT REPORT</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Abstract of payments from permit applications and all billing groups.
        </p>
      </div>

      <DateFilter
        dateFrom={dateFrom}
        dateTo={dateTo}
        orNumberFrom={orNumberFrom}
        orNumberTo={orNumberTo}
        onDateFromChange={setDateFrom}
        onDateToChange={setDateTo}
        onOrNumberFromChange={setOrNumberFrom}
        onOrNumberToChange={setOrNumberTo}
        onGenerate={handleGenerate}
        onExport={handleCsvExport}
        isLoading={isLoading || isExporting}
        hasData={hasData}
        extraActions={
          hasData ? (
            <PdfExportButton onDownload={() => exportPdf("pdf")} />
          ) : undefined
        }
      />

      {reportData?.truncated && (
        <TruncationNotice totalCount={reportData.totalCount} cap={DISPLAY_ROW_CAP} />
      )}

      {reportData && (
        <ReportTable
          columns={reportData.columns}
          rows={reportData.rows}
          totals={reportData.totals}
          grandTotal={reportData.grandTotal}
        />
      )}

      {!reportData && !isLoading && (
        <div className="flex items-center justify-center rounded-lg border border-dashed p-12">
          <p className="text-sm text-muted-foreground">
            Select filters and click Generate to view the report.
          </p>
        </div>
      )}
    </div>
  );
}
