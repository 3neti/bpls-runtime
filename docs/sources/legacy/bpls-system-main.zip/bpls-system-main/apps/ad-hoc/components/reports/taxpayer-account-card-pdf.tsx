import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
} from "@react-pdf/renderer";
import type {
  TaxpayerCardData,
  TaxpayerCard,
  TaxpayerCardYearRow,
} from "@repo/backend/convex/reports";

const PROVINCE = "PROVINCE OF ZAMBOANGA SIBUGAY";
const MUNICIPALITY = "MUNICIPALITY OF IPIL";
const MIN_ROWS = 8; // keep in sync with taxpayer-account-card.tsx

// Fixed column point-widths (A4 landscape content ≈ 800pt). A single source of
// truth so the multi-band header and the body rows stay aligned.
const C = {
  year: 32,
  annualTax: 58,
  qOr: 40,
  qAmt: 50,
  fines: 46,
  reg: 46,
  total: 56,
  issued: 50,
  surrendered: 56,
  ordinance: 50,
  initial: 30,
};
const QUARTER_W = (C.qOr + C.qAmt) * 4; // 360
const DATELIC_W = C.issued + C.surrendered; // 106
const BAND = 13;
const HEADER_H = BAND * 3; // 39
const ROW_H = 16;

function money(value: number): string {
  if (!Number.isFinite(value) || value === 0) return "";
  return value.toLocaleString("en-PH", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

const s = StyleSheet.create({
  page: {
    paddingVertical: 16,
    paddingHorizontal: 16,
    fontFamily: "Helvetica",
    fontSize: 7,
    color: "#000",
  },
  centerLine: { textAlign: "center" },
  provLine: { fontSize: 9, fontFamily: "Helvetica-Bold", textAlign: "center" },
  title: {
    fontSize: 15,
    fontFamily: "Helvetica-Bold",
    textAlign: "center",
    letterSpacing: 1,
    marginTop: 2,
  },
  kindLabel: {
    fontSize: 7,
    fontFamily: "Helvetica-Bold",
    textAlign: "center",
    marginTop: 4,
    borderTop: "1pt solid #000",
    paddingTop: 2,
  },
  kindValue: {
    fontSize: 9,
    fontFamily: "Helvetica-Bold",
    textAlign: "center",
    textTransform: "uppercase",
    marginBottom: 6,
  },
  infoGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginBottom: 8,
  },
  infoCell: { width: "50%", flexDirection: "row", marginBottom: 3, paddingRight: 10 },
  infoLabel: { fontFamily: "Helvetica-Bold", fontSize: 7 },
  infoValue: {
    fontSize: 7,
    flexGrow: 1,
    borderBottom: "1pt solid #000",
    marginLeft: 3,
  },
  table: { borderTop: "1pt solid #000", borderLeft: "1pt solid #000" },
  row: { flexDirection: "row" },
  hCell: {
    borderRight: "1pt solid #000",
    borderBottom: "1pt solid #000",
    fontFamily: "Helvetica-Bold",
    fontSize: 5.6,
    textAlign: "center",
    justifyContent: "center",
    paddingHorizontal: 1,
    paddingVertical: 1,
  },
  dCell: {
    borderRight: "1pt solid #000",
    borderBottom: "1pt solid #000",
    fontSize: 6.5,
    paddingHorizontal: 2,
    paddingVertical: 2,
    height: ROW_H,
  },
});

/** Full-height (3-band) header cell. */
function HCellTall({ w, children }: { w: number; children: string }) {
  return (
    <View style={[s.hCell, { width: w, height: HEADER_H }]}>
      <Text>{children}</Text>
    </View>
  );
}

function HeaderBlock() {
  return (
    <View style={[s.row, { backgroundColor: "#ededed" }]}>
      <HCellTall w={C.year}>YEAR</HCellTall>
      <HCellTall w={C.annualTax}>ANNUAL TAX</HCellTall>

      {/* QUARTER block — band over FIRST..FOURTH over OR#/AMOUNT */}
      <View style={{ width: QUARTER_W }}>
        <View style={[s.hCell, { width: QUARTER_W, height: BAND }]}>
          <Text>QUARTER (RECEIPT NUMBER &amp; AMOUNT PAID)</Text>
        </View>
        <View style={[s.row, { width: QUARTER_W }]}>
          {["FIRST", "SECOND", "THIRD", "FOURTH"].map((q) => (
            <View key={q} style={[s.hCell, { width: C.qOr + C.qAmt, height: BAND }]}>
              <Text>{q}</Text>
            </View>
          ))}
        </View>
        <View style={[s.row, { width: QUARTER_W }]}>
          {[0, 1, 2, 3].map((i) => (
            <View key={i} style={[s.row, { width: C.qOr + C.qAmt }]}>
              <View style={[s.hCell, { width: C.qOr, height: BAND }]}>
                <Text>OR #</Text>
              </View>
              <View style={[s.hCell, { width: C.qAmt, height: BAND }]}>
                <Text>AMOUNT</Text>
              </View>
            </View>
          ))}
        </View>
      </View>

      <HCellTall w={C.fines}>FINES/ PENALTIES</HCellTall>
      <HCellTall w={C.reg}>REGULATORY FEES</HCellTall>
      <HCellTall w={C.total}>TOTAL</HCellTall>

      {/* DATE LICENSE block — band over ISSUED / SURRENDERED */}
      <View style={{ width: DATELIC_W }}>
        <View style={[s.hCell, { width: DATELIC_W, height: BAND }]}>
          <Text>DATE LICENSE</Text>
        </View>
        <View style={[s.row, { width: DATELIC_W }]}>
          <View style={[s.hCell, { width: C.issued, height: BAND * 2 }]}>
            <Text>ISSUED</Text>
          </View>
          <View style={[s.hCell, { width: C.surrendered, height: BAND * 2 }]}>
            <Text>SURRENDERED</Text>
          </View>
        </View>
      </View>

      <HCellTall w={C.ordinance}>ORDINANCE NUMBER</HCellTall>
      <HCellTall w={C.initial}>INITIAL</HCellTall>
    </View>
  );
}

function DataRow({ r }: { r: TaxpayerCardYearRow }) {
  const num = (w: number, v: number, bold?: boolean) => (
    <Text
      style={[
        s.dCell,
        { width: w, textAlign: "right" },
        bold ? { fontFamily: "Helvetica-Bold" } : {},
      ]}
    >
      {money(v)}
    </Text>
  );
  const txt = (w: number, v: string, align: "left" | "center" = "center") => (
    <Text style={[s.dCell, { width: w, textAlign: align, fontSize: 6 }]}>{v}</Text>
  );
  const quarters = [r.q1, r.q2, r.q3, r.q4];
  return (
    <View style={s.row} wrap={false}>
      <Text style={[s.dCell, { width: C.year, textAlign: "center", fontFamily: "Helvetica-Bold" }]}>
        {r.year}
      </Text>
      {num(C.annualTax, r.annualTax)}
      {quarters.map((q, i) => (
        <View key={i} style={s.row}>
          {txt(C.qOr, q.receipt)}
          {num(C.qAmt, q.amount)}
        </View>
      ))}
      {num(C.fines, r.finesPenalties)}
      {num(C.reg, r.regulatoryFees)}
      {num(C.total, r.total, true)}
      {txt(C.issued, r.dateLicenseIssued)}
      {txt(C.surrendered, r.dateLicenseSurrendered)}
      {txt(C.ordinance, r.ordinanceNumber)}
      <Text style={[s.dCell, { width: C.initial }]} />
    </View>
  );
}

function EmptyRow() {
  const widths = [
    C.year, C.annualTax, C.qOr, C.qAmt, C.qOr, C.qAmt, C.qOr, C.qAmt,
    C.qOr, C.qAmt, C.fines, C.reg, C.total, C.issued, C.surrendered,
    C.ordinance, C.initial,
  ];
  return (
    <View style={s.row} wrap={false}>
      {widths.map((w, i) => (
        <Text key={i} style={[s.dCell, { width: w }]} />
      ))}
    </View>
  );
}

function InfoField({ label, value }: { label: string; value: string }) {
  return (
    <View style={s.infoCell}>
      <Text style={s.infoLabel}>{label}: </Text>
      <Text style={s.infoValue}>{value || " "}</Text>
    </View>
  );
}

function CardPage({ data, card }: { data: TaxpayerCardData; card: TaxpayerCard }) {
  const filler = Math.max(0, MIN_ROWS - card.rows.length);
  return (
    <Page size="A4" orientation="landscape" style={s.page}>
      <Text style={s.provLine}>{PROVINCE}</Text>
      <Text style={s.provLine}>{MUNICIPALITY}</Text>
      <Text style={s.title}>TAXPAYER&apos;S ACCOUNT CARD</Text>
      <Text style={s.kindLabel}>(KIND of BUSINESS)</Text>
      <Text style={s.kindValue}>{card.kindOfBusiness || " "}</Text>

      <View style={s.infoGrid}>
        <InfoField label="NAME" value={data.ownerName} />
        <InfoField label="RESIDENCE ADDRESS" value={data.residenceAddress} />
        <InfoField label="BUSINESS TRADE NAME" value={data.businessName} />
        <InfoField label="BUSINESS ADDRESS" value={data.businessAddress} />
      </View>

      <View style={s.table}>
        <HeaderBlock />
        {card.rows.map((r) => (
          <DataRow key={r.year} r={r} />
        ))}
        {Array.from({ length: filler }).map((_, i) => (
          <EmptyRow key={`f-${i}`} />
        ))}
      </View>
    </Page>
  );
}

/** Multi-page Taxpayer's Account Card — one A4 landscape page per Kind of Business. */
export function TaxpayerAccountCardDocument({ data }: { data: TaxpayerCardData }) {
  return (
    <Document>
      {data.cards.map((card) => (
        <CardPage key={card.kindOfBusiness} data={data} card={card} />
      ))}
    </Document>
  );
}
