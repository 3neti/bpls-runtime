"use client";

import type { ExportResult } from "@/lib/exports/types";

/** Turn an ExportResult (from a server export action) into a browser download. */
export function triggerDownload(result: ExportResult) {
  let blob: Blob;
  if (result.base64) {
    const binary = atob(result.content);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    blob = new Blob([bytes], { type: result.mimeType });
  } else {
    blob = new Blob([result.content], { type: result.mimeType });
  }

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = result.filename;
  link.click();
  URL.revokeObjectURL(url);
}
