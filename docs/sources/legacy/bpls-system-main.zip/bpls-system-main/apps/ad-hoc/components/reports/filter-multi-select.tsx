"use client";

import { useCallback, useMemo, useState } from "react";
import { useQuery } from "convex/react";
import { ChevronsUpDown } from "lucide-react";
import { api } from "@repo/backend/convex/_generated/api";
import { Button } from "@repo/ui/components/button";
import { Checkbox } from "@repo/ui/components/checkbox";
import { Label } from "@repo/ui/components/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@repo/ui/components/popover";

export interface MultiSelectOption {
  value: string;
  label: string;
}

// authenticatedQuery return types don't flow through useQuery, so the filter
// option shapes are annotated at the call sites (matching the admin app).
interface CategoryOption {
  id: string;
  name: string;
}
interface SubCategoryOption extends CategoryOption {
  categoryId: string;
}

/**
 * Popover checkbox multi-select used for report filters (Category /
 * Sub-Category on the ANNEX-C DNFBP and BSP reports).
 */
export function FilterMultiSelect({
  label,
  placeholder,
  options,
  selected,
  onChange,
  disabled,
}: {
  label: string;
  placeholder: string;
  options: MultiSelectOption[];
  selected: string[];
  onChange: (values: string[]) => void;
  disabled?: boolean;
}) {
  const toggle = (value: string) =>
    onChange(
      selected.includes(value)
        ? selected.filter((v) => v !== value)
        : [...selected, value]
    );

  const summary =
    selected.length === 0
      ? placeholder
      : selected.length === 1
        ? (options.find((o) => o.value === selected[0])?.label ?? "1 selected")
        : `${selected.length} selected`;

  return (
    <div className="grid gap-1.5">
      <Label className="text-xs">{label}</Label>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            disabled={disabled}
            className="w-60 justify-between font-normal"
          >
            <span className="truncate">{summary}</span>
            <ChevronsUpDown className="ml-2 size-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-72 p-0" align="start">
          <div className="flex items-center justify-between border-b px-3 py-2">
            <button
              type="button"
              className="text-xs text-primary hover:underline"
              onClick={() => onChange(options.map((o) => o.value))}
            >
              Select all
            </button>
            <button
              type="button"
              className="text-xs text-muted-foreground hover:underline"
              onClick={() => onChange([])}
            >
              Clear
            </button>
          </div>
          <div className="max-h-64 overflow-y-auto p-1">
            {options.length === 0 && (
              <p className="px-2 py-3 text-center text-xs text-muted-foreground">
                No options available.
              </p>
            )}
            {options.map((o) => (
              <label
                key={o.value}
                className="flex cursor-pointer items-center gap-2 rounded-sm px-2 py-1.5 text-sm hover:bg-accent"
              >
                <Checkbox
                  checked={selected.includes(o.value)}
                  onCheckedChange={() => toggle(o.value)}
                />
                <span className="truncate">{o.label}</span>
              </label>
            ))}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}

/**
 * Shared selection state + option lists for the Category / Sub-Category
 * report filters (options come from `reports.getDnfbpFilterOptions`, exposed
 * under the REPORTS resource so report-only users can load them).
 *
 * Sub-category choices are limited to the selected categories; unselecting a
 * category drops its sub-category selections. When several categories are
 * selected the sub-category labels carry the parent in parentheses.
 */
export function useCategoryFilterSelection() {
  const options = useQuery(api.reports.getDnfbpFilterOptions);
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<string[]>([]);
  const [selectedSubCategoryIds, setSelectedSubCategoryIds] = useState<string[]>([]);

  const categoryOptions = useMemo<MultiSelectOption[]>(
    () =>
      (options?.categories ?? []).map((c: CategoryOption) => ({
        value: c.id,
        label: c.name,
      })),
    [options]
  );

  const subCategoryOptions = useMemo<MultiSelectOption[]>(() => {
    if (!options) return [];
    const selectedSet = new Set(selectedCategoryIds);
    const catName = new Map<string, string>(
      options.categories.map((c: CategoryOption) => [c.id, c.name])
    );
    return options.subCategories
      .filter((s: SubCategoryOption) => selectedSet.has(s.categoryId))
      .map((s: SubCategoryOption) => ({
        value: s.id,
        label:
          selectedCategoryIds.length > 1
            ? `${s.name} (${catName.get(s.categoryId) ?? ""})`
            : s.name,
      }));
  }, [options, selectedCategoryIds]);

  const handleCategoriesChange = useCallback(
    (values: string[]) => {
      setSelectedCategoryIds(values);
      // Drop sub-category selections whose parent category was unselected.
      if (options) {
        const kept = new Set(values);
        const parentBySub = new Map<string, string>(
          options.subCategories.map((s: SubCategoryOption) => [s.id, s.categoryId])
        );
        setSelectedSubCategoryIds((prev) =>
          prev.filter((id) => kept.has(parentBySub.get(id) ?? ""))
        );
      }
    },
    [options]
  );

  return {
    optionsLoading: options === undefined,
    categoryOptions,
    subCategoryOptions,
    selectedCategoryIds,
    selectedSubCategoryIds,
    setSelectedSubCategoryIds,
    handleCategoriesChange,
  };
}
