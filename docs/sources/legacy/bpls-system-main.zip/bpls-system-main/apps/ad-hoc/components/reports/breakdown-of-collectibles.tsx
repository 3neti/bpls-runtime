"use client";

import { useState, useCallback, useMemo } from "react";
import {
  fetchBreakdownOfCollectibles,
  exportBreakdownOfCollectibles,
} from "@/lib/actions/breakdown-of-collectibles";
import { DataTable, type ReportColumn, type ReportRow } from "./data-table";
import { ReportToolbar } from "./report-toolbar";
import { ReportSummary } from "./report-summary";
import { PdfExportButton } from "./pdf-export-button";
import { TruncationNotice } from "./truncation-notice";
import { triggerDownload } from "./report-download";
import { buildFooterRow, type FooterSpec } from "@/lib/exports/footer";
import type { TableExportMeta } from "@/lib/exports/table-export";
import { DISPLAY_ROW_CAP, type ExportFormat } from "@/lib/exports/types";
import { toast } from "sonner";

const COLUMNS: ReportColumn[] = [
  { key: "ownerName", label: "NAME OF OWNER/APPLICANT", minWidth: 190 },
  { key: "businessName", label: "BUSINESS NAME", minWidth: 160 },
  { key: "businessAddress", label: "BUSINESS ADDRESS", minWidth: 280 },
  { key: "typeOfApplication", label: "TYPE OF APPLICATION", minWidth: 130 },
  { key: "dateOfApplication", label: "DATE OF APPLICATION", minWidth: 130 },
  { key: "capitalInvestment", label: "CAPITAL INVESTMENT", currency: true, minWidth: 130 },
  { key: "grossSales", label: "GROSS SALES", currency: true, minWidth: 120 },
  { key: "paymentMode", label: "PAYMENT MODE", minWidth: 110 },
  { key: "q1", label: "1ST QUARTER", currency: true, minWidth: 110 },
  { key: "q2", label: "SECOND QUARTER", currency: true, minWidth: 120 },
  { key: "q3", label: "3RD QUARTER", currency: true, minWidth: 110 },
  { key: "q4", label: "4TH QUARTER", currency: true, minWidth: 110 },
  { key: "total", label: "TOTAL", currency: true, minWidth: 120 },
];

const CURRENT_YEAR = new Date().getFullYear();
const YEAR_OPTIONS = [
  CURRENT_YEAR + 1,
  CURRENT_YEAR,
  CURRENT_YEAR - 1,
  CURRENT_YEAR - 2,
  CURRENT_YEAR - 3,
];

const SUMMARY_POINTS = [
  "Shows the unpaid balances (collectibles) still owed by each establishment for the selected year, broken down by quarter.",
  "Each quarter column is the remaining balance of the payment due that quarter; fully paid quarters show '-'. TOTAL is the establishment's total remaining balance for the year.",
  "PAYMENT MODE shows the payment frequency: Q = Quarterly, S = Semi-Annually, A = Annually.",
  "CAPITAL INVESTMENT and GROSS SALES are totaled across the business's lines of business. Data refreshes from the live system about once an hour.",
];

const FOOTER: FooterSpec = {
  labelKey: "ownerName",
  label: "TOTAL",
  sumKeys: ["q1", "q2", "q3", "q4", "total"],
};

interface BreakdownData {
  rows: ReportRow[];
  truncated: boolean;
  totalCount: number;
  columnTotals: Record<string, number>;
}

export function BreakdownOfCollectibles() {
  const [year, setYear] = useState(CURRENT_YEAR);
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [data, setData] = useState<BreakdownData | null>(null);

  // Totals come from the server's full-data column totals so they stay correct
  // even when the on-screen rows are capped.
  const footerRow = useMemo<ReportRow | undefined>(
    () =>
      data && data.totalCount > 0
        ? buildFooterRow(FOOTER, data.columnTotals)
        : undefined,
    [data]
  );

  const buildParams = useCallback(() => ({ year }), [year]);

  const exportMeta = useCallback(
    (): TableExportMeta => ({
      columns: COLUMNS,
      title: "BREAKDOWN OF COLLECTIBLES",
      orientation: "landscape",
      footer: FOOTER,
      filenameBase: `breakdown-of-collectibles-${year}`,
    }),
    [year]
  );

  const handleGenerate = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await fetchBreakdownOfCollectibles(buildParams());
      setData(result);
      if (result.totalCount === 0) {
        toast.info(`No collectibles found for ${year}.`);
      } else {
        toast.success(
          `Report generated with ${result.totalCount} establishments.`
        );
      }
    } catch (error) {
      console.error("Failed to generate collectibles report:", error);
      toast.error("Failed to generate report. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [buildParams, year]);

  const handleCsvExport = useCallback(async () => {
    setIsExporting(true);
    try {
      const result = await exportBreakdownOfCollectibles(
        buildParams(),
        exportMeta(),
        "csv"
      );
      triggerDownload(result);
      toast.success("CSV exported successfully.");
    } catch (error) {
      console.error("Failed to export CSV:", error);
      toast.error("Failed to export CSV. Please try again.");
    } finally {
      setIsExporting(false);
    }
  }, [buildParams, exportMeta]);

  const exportPdf = useCallback(
    (format: ExportFormat) =>
      exportBreakdownOfCollectibles(buildParams(), exportMeta(), format),
    [buildParams, exportMeta]
  );

  const hasData = !!data && data.totalCount > 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">
          BREAKDOWN OF COLLECTIBLES
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Remaining balance summary — outstanding business-permit fees by quarter.
        </p>
      </div>

      <ReportSummary points={SUMMARY_POINTS} />

      <ReportToolbar
        showYear
        year={year}
        onYearChange={setYear}
        yearOptions={YEAR_OPTIONS}
        onGenerate={handleGenerate}
        onExport={handleCsvExport}
        isLoading={isLoading || isExporting}
        hasData={hasData}
        extraActions={
          hasData ? (
            <PdfExportButton onDownload={() => exportPdf("pdf")} />
          ) : undefined
        }
      />

      {data?.truncated && (
        <TruncationNotice totalCount={data.totalCount} cap={DISPLAY_ROW_CAP} />
      )}

      {data && (
        <DataTable columns={COLUMNS} rows={data.rows} footerRow={footerRow} />
      )}

      {!data && !isLoading && (
        <div className="flex items-center justify-center rounded-lg border border-dashed p-12">
          <p className="text-sm text-muted-foreground">
            Select a year and click Generate to view outstanding collectibles.
          </p>
        </div>
      )}
    </div>
  );
}
