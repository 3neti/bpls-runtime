"use client";

import { useCallback, useState } from "react";
import { toast } from "sonner";
import type { DnfbpReportData } from "@repo/backend/convex/reports";
import {
  fetchDnfbpReport,
  exportDnfbpReport,
} from "@/lib/actions/annex-c-dnfbp";
import { sectionLetter } from "@/lib/section-letter";
import { DataTable, type ReportColumn, type ReportRow } from "./data-table";
import {
  FilterMultiSelect,
  useCategoryFilterSelection,
} from "./filter-multi-select";
import { ReportToolbar } from "./report-toolbar";
import { ReportSummary } from "./report-summary";
import { PdfExportButton } from "./pdf-export-button";
import { triggerDownload } from "./report-download";
import type { ExportFormat } from "@/lib/exports/types";

const COLUMNS: ReportColumn[] = [
  { key: "seqNo", label: "#", minWidth: 50 },
  { key: "businessName", label: "Business Name", minWidth: 200 },
  { key: "address", label: "Address", minWidth: 260 },
  { key: "email", label: "e-Mail", minWidth: 170 },
  { key: "contactDetails", label: "Contact Details", minWidth: 140 },
  { key: "permitNumber", label: "Mayor's Permit/ License No.", minWidth: 160 },
  { key: "issuedOn", label: "Issued on", minWidth: 100 },
];

const SUMMARY_POINTS = [
  "Semestral report on Designated Non-Financial Businesses and Professions (DNFBPs) with licenses/permits issued by the city/municipality — one lettered section per Category - Sub Category.",
  "Pick one or more Categories to include every business classified under them; picking specific Sub-Categories narrows that category to just those sections.",
  "Businesses are classified (Category / Sub-Category) on the admin Businesses page; unclassified businesses never appear here.",
  "Mayor's Permit/License No. and Issued on come from the business' latest issued permit and stay blank when no permit is on record.",
  "Reads live from the operational database, so newly classified businesses appear immediately (no warehouse sync delay).",
];

export function AnnexCDnfbpReport() {
  const {
    optionsLoading,
    categoryOptions,
    subCategoryOptions,
    selectedCategoryIds,
    selectedSubCategoryIds,
    setSelectedSubCategoryIds,
    handleCategoriesChange,
  } = useCategoryFilterSelection();
  const [isLoading, setIsLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [data, setData] = useState<DnfbpReportData | null>(null);

  const buildParams = useCallback(
    () => ({
      categoryIds: selectedCategoryIds,
      subCategoryIds: selectedSubCategoryIds,
    }),
    [selectedCategoryIds, selectedSubCategoryIds]
  );

  const handleGenerate = useCallback(async () => {
    if (selectedCategoryIds.length === 0 && selectedSubCategoryIds.length === 0) {
      toast.info("Select at least one category or sub-category first.");
      return;
    }
    setIsLoading(true);
    try {
      const result = await fetchDnfbpReport(buildParams());
      setData(result);
      if (result.totalBusinesses === 0) {
        toast.info("No businesses found for the selected classifications.");
      } else {
        toast.success(
          `Report generated with ${result.totalBusinesses} business${result.totalBusinesses === 1 ? "" : "es"} across ${result.sections.length} section${result.sections.length === 1 ? "" : "s"}.`
        );
      }
    } catch (error) {
      console.error("Failed to generate ANNEX-C DNFBP report:", error);
      toast.error("Failed to generate report. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [buildParams, selectedCategoryIds, selectedSubCategoryIds]);

  const handleCsvExport = useCallback(async () => {
    setIsExporting(true);
    try {
      const result = await exportDnfbpReport(buildParams(), "csv");
      triggerDownload(result);
      toast.success("CSV exported successfully.");
    } catch (error) {
      console.error("Failed to export CSV:", error);
      toast.error("Failed to export CSV. Please try again.");
    } finally {
      setIsExporting(false);
    }
  }, [buildParams]);

  const exportPdf = useCallback(
    (format: ExportFormat) => exportDnfbpReport(buildParams(), format),
    [buildParams]
  );

  const hasData = !!data && data.sections.length > 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">
          ANNEX-C DNFBP REPORT
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Semestral report on Designated Non-Financial Businesses and
          Professions (DNFBPs) with licenses/permits issued by the
          city/municipality.
        </p>
      </div>

      <ReportSummary points={SUMMARY_POINTS} />

      <ReportToolbar
        filters={
          <>
            <FilterMultiSelect
              label="Categories"
              placeholder="Select categories"
              options={categoryOptions}
              selected={selectedCategoryIds}
              onChange={handleCategoriesChange}
              disabled={optionsLoading}
            />
            <FilterMultiSelect
              label="Sub-Categories (optional)"
              placeholder={
                selectedCategoryIds.length === 0
                  ? "Select categories first"
                  : "All sub-categories"
              }
              options={subCategoryOptions}
              selected={selectedSubCategoryIds}
              onChange={setSelectedSubCategoryIds}
              disabled={selectedCategoryIds.length === 0}
            />
          </>
        }
        onGenerate={handleGenerate}
        onExport={handleCsvExport}
        isLoading={isLoading || isExporting}
        hasData={hasData}
        extraActions={
          hasData ? (
            <PdfExportButton onDownload={() => exportPdf("pdf")} />
          ) : undefined
        }
      />

      {data &&
        data.sections.map((section, idx) => (
          <div
            key={`${section.categoryId}-${section.subCategoryId ?? "all"}`}
            className="space-y-2"
          >
            <h2 className="text-sm font-semibold">
              {sectionLetter(idx)}. {section.title}
            </h2>
            {section.rows.length > 0 ? (
              <DataTable
                columns={COLUMNS}
                rows={section.rows.map<ReportRow>((r, i) => ({
                  seqNo: i + 1,
                  ...r,
                }))}
              />
            ) : (
              <p className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
                No businesses with this classification.
              </p>
            )}
          </div>
        ))}

      {!data && !isLoading && (
        <div className="flex items-center justify-center rounded-lg border border-dashed p-12">
          <p className="text-sm text-muted-foreground">
            Select the categories (and optionally sub-categories) to report on,
            then click Generate.
          </p>
        </div>
      )}
    </div>
  );
}
