"use client";

import { TriangleAlert } from "lucide-react";

/**
 * Shown when the on-screen table was capped for performance. Totals always
 * reflect the full dataset; downloads always contain every row.
 */
export function TruncationNotice({
  totalCount,
  cap,
}: {
  totalCount: number;
  cap: number;
}) {
  return (
    <div className="flex items-start gap-2 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-900 dark:border-amber-800/60 dark:bg-amber-950/40 dark:text-amber-200">
      <TriangleAlert className="mt-0.5 size-4 shrink-0" />
      <span>
        Showing the first {cap.toLocaleString()} of{" "}
        {totalCount.toLocaleString()} records on screen for performance. Totals
        reflect the full dataset. Narrow the date/OR range to see fewer rows, or
        download the report to get all {totalCount.toLocaleString()} rows.
      </span>
    </div>
  );
}
