/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "standalone",
  transpilePackages: ["@repo/ui", "@repo/shared"],
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: false,
  },
  productionBrowserSourceMaps: true,

  // Fix for @react-pdf/renderer in Next.js
  webpack: (config) => {
    // Disable canvas module (not needed for PDF generation, causes webpack issues)
    config.resolve.alias.canvas = false;
    return config;
  },

  // Prevent Next.js from processing react-pdf on server side
  serverExternalPackages: ["@react-pdf/renderer"],
};

export default nextConfig;
