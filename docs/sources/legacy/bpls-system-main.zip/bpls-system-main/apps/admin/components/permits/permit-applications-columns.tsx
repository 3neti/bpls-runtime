"use client"

import { ColumnDef } from "@tanstack/react-table"
import { ArrowUpDown, Eye, Trash2 } from "lucide-react"

import { Button } from "@repo/ui/components/button"
import { Badge } from "@repo/ui/components/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@repo/ui/components/avatar"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import type { Doc } from "@repo/backend/convex/_generated/dataModel"
import { STATUS_COLORS, STATUS_LABELS } from "@/lib/types/permit-application"
import { getInitials } from "@/lib/utils/formatting"

// Type for permit application with enriched data
type PermitApplicationRow = Doc<"business_permit_applications"> & {
  ownerName: string
  businessName: string
  ownerAvatar?: string
  permitNumber?: string | null
  businessOwner: Doc<"business_owners"> | null
  business: Doc<"businesses"> | null
}

interface PermitApplicationsColumnsProps {
  onView?: (applicationId: string) => void
  onDelete?: (applicationId: string) => void
}

export const createPermitApplicationsColumns = (
  props?: PermitApplicationsColumnsProps
): ColumnDef<PermitApplicationRow>[] => [
  {
    id: "applicationNumber",
    accessorKey: "applicationNumber",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Application Number
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      return (
        <div className="font-medium font-mono">
          {row.original.applicationNumber}
        </div>
      )
    },
    enableHiding: false,
  },
  {
    id: "permitNumber",
    accessorKey: "permitNumber",
    header: "Permit Number",
    cell: ({ row }) => {
      const permitNumber = row.original.permitNumber
      if (!permitNumber) {
        return <span className="text-muted-foreground text-sm">{"\u2014"}</span>
      }
      return <div className="font-medium font-mono text-sm">{permitNumber}</div>
    },
    enableHiding: true,
  },
  {
    id: "businessName",
    accessorKey: "businessName",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Business Name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      return <div className="text-sm">{row.original.businessName}</div>
    },
  },
  {
    id: "ownerName",
    accessorKey: "ownerName",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Business Owner
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const owner = row.original
      return (
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8">
            <AvatarImage src={owner.ownerAvatar} alt={owner.ownerName} />
            <AvatarFallback className="text-xs">
              {getInitials(owner.ownerName)}
            </AvatarFallback>
          </Avatar>
          <span className="font-medium text-sm">{owner.ownerName}</span>
        </div>
      )
    },
  },
  {
    id: "applicationType",
    accessorKey: "permitApplicationType",
    header: "Type",
    cell: ({ row }) => {
      const type = row.original.permitApplicationType
      return (
        <Badge variant="outline" className={type === "Renewal" ? "bg-blue-50 text-blue-700 border-blue-200" : "bg-green-50 text-green-700 border-green-200"}>
          {type || "New"}
        </Badge>
      )
    },
  },
  {
    id: "submittedAt",
    accessorKey: "submittedAt",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Submitted
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const date = new Date(row.original.submittedAt)
      return (
        <div className="text-sm">
          {date.toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric",
          })}
        </div>
      )
    },
  },
  {
    id: "status",
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.original.status
      return (
        <Badge className={STATUS_COLORS[status]} variant="outline">
          {STATUS_LABELS[status]}
        </Badge>
      )
    },
  },
  {
    id: "actions",
    header: "Actions",
    cell: ({ row }) => {
      const application = row.original
      return (
        <div className="flex items-center gap-1">
          <TooltipProvider>
            {props?.onView && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation()
                      props.onView?.(application._id)
                    }}
                    className="h-8 w-8"
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>View application</p>
                </TooltipContent>
              </Tooltip>
            )}
            {props?.onDelete && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation()
                      props.onDelete?.(application._id)
                    }}
                    className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Delete application</p>
                </TooltipContent>
              </Tooltip>
            )}
          </TooltipProvider>
        </div>
      )
    },
    enableSorting: false,
    enableHiding: false,
  },
  // Additional columns (hidden by default)
  {
    id: "lineOfBusiness",
    accessorFn: (row) => {
      const lobs = row.linesOfBusiness
      if (lobs && lobs.length > 0) {
        return lobs[0].businessCategory || "N/A"
      }
      return null
    },
    header: "Line of Business",
    cell: ({ row }) => {
      const lobs = row.original.linesOfBusiness
      if (!lobs || lobs.length === 0) {
        return <span className="text-muted-foreground text-sm">N/A</span>
      }
      const primaryLob = lobs[0].businessCategory || "Unknown"
      const additionalCount = lobs.length > 1 ? ` +${lobs.length - 1} more` : ""
      return (
        <div className="text-sm">
          {primaryLob}
          {additionalCount && (
            <span className="text-muted-foreground">{additionalCount}</span>
          )}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "businessScale",
    accessorFn: (row) => row.business?.businessScale,
    header: "Business Scale",
    cell: ({ row }) => {
      const scale = row.original.business?.businessScale
      return (
        <Badge variant="outline" className="text-xs">
          {scale || "N/A"}
        </Badge>
      )
    },
    enableHiding: true,
  },
  {
    id: "ownershipType",
    accessorFn: (row) => row.business?.ownershipType,
    header: "Ownership Type",
    cell: ({ row }) => {
      const ownershipType = row.original.business?.ownershipType
      return (
        <div className="text-sm">
          {ownershipType || <span className="text-muted-foreground">N/A</span>}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "businessAddress",
    accessorFn: (row) => row.business?.address,
    header: "Business Address",
    cell: ({ row }) => {
      const address = row.original.business?.address
      return (
        <div className="text-sm max-w-[200px] truncate" title={address || undefined}>
          {address || <span className="text-muted-foreground">N/A</span>}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "ownerEmail",
    accessorFn: (row) => row.businessOwner?.email,
    header: "Owner Email",
    cell: ({ row }) => {
      const email = row.original.businessOwner?.email
      return (
        <div className="text-sm text-muted-foreground">
          {email || "N/A"}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "ownerContact",
    accessorFn: (row) => row.businessOwner?.mobile,
    header: "Owner Contact",
    cell: ({ row }) => {
      const mobile = row.original.businessOwner?.mobile
      return (
        <div className="text-sm font-mono">
          {mobile || <span className="text-muted-foreground">N/A</span>}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "ownerTin",
    accessorFn: (row) => row.businessOwner?.tin,
    header: "TIN",
    cell: ({ row }) => {
      const tin = row.original.businessOwner?.tin
      return (
        <div className="text-sm font-mono">
          {tin || <span className="text-muted-foreground">N/A</span>}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "createdAt",
    accessorKey: "_creationTime",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Created Date
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const date = new Date(row.original._creationTime)
      return (
        <div className="text-sm text-muted-foreground">
          {date.toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric",
          })}
        </div>
      )
    },
    enableHiding: true,
  },
]

export type { PermitApplicationRow }
