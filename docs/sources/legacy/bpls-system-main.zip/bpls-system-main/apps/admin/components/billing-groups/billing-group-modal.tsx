"use client"

import { useEffect } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { useMutation, useQuery } from "convex/react"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form"
import { Input } from "@repo/ui/components/input"
import { Textarea } from "@repo/ui/components/textarea"
import { Button } from "@repo/ui/components/button"
import { Switch } from "@repo/ui/components/switch"
import { useToast } from "@/hooks/use-toast"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

const formSchema = z.object({
  name: z
    .string()
    .min(3, "Name must be at least 3 characters")
    .max(100, "Name cannot exceed 100 characters"),
  description: z.string().max(500, "Description cannot exceed 500 characters").optional(),
  isActive: z.boolean(),
})

type FormValues = z.infer<typeof formSchema>

interface BillingGroupModalProps {
  open: boolean
  onClose: () => void
  editingGroup: {
    id: Id<"billing_groups">
    name: string
    description?: string
  } | null
}

export function BillingGroupModal({ open, onClose, editingGroup }: BillingGroupModalProps) {
  const { toast } = useToast()
  const isEditing = editingGroup !== null

  // Fetch full group data if editing
  const groupData = useQuery(
    api.billingGroups.getById,
    editingGroup ? { id: editingGroup.id } : "skip"
  )

  // Mutations
  const createGroup = useMutation(api.billingGroups.create)
  const updateGroup = useMutation(api.billingGroups.update)

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
      isActive: true,
    },
  })

  // Reset form when modal opens/closes or editing group changes
  useEffect(() => {
    if (open) {
      if (groupData) {
        form.reset({
          name: groupData.name,
          description: groupData.description || "",
          isActive: groupData.isActive,
        })
      } else if (!editingGroup) {
        form.reset({
          name: "",
          description: "",
          isActive: true,
        })
      }
    }
  }, [open, groupData, editingGroup, form])

  const handleSubmit = async (values: FormValues) => {
    try {
      if (isEditing && editingGroup) {
        // Update group
        await updateGroup({
          id: editingGroup.id,
          name: values.name,
          description: values.description || undefined,
          isActive: values.isActive,
        })

        toast({
          title: "Billing group updated",
          description: `${values.name} has been updated successfully.`,
        })
      } else {
        // Create new group
        await createGroup({
          name: values.name,
          description: values.description || undefined,
        })

        toast({
          title: "Billing group created",
          description: `${values.name} has been created. Add fields to start collecting data.`,
        })
      }

      onClose()
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "An unexpected error occurred",
        variant: "destructive",
      })
    }
  }

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? "Edit Billing Group" : "Create Billing Group"}
          </DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Update billing group settings and amount field mapping."
              : "Create a new billing group to organize custom fees and charges."}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            {/* Name */}
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Name</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="e.g., Miscellaneous Fees, Special Assessments"
                      maxLength={100}
                      autoFocus
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    {field.value.length} / 100 characters
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Description */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description (Optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Brief description of this billing group"
                      className="min-h-[80px] resize-none"
                      maxLength={500}
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    {field.value?.length || 0} / 500 characters
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Active Status (only for editing) */}
            {isEditing && (
              <FormField
                control={form.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                    <div className="space-y-0.5">
                      <FormLabel>Active Status</FormLabel>
                      <FormDescription className="text-xs">
                        {field.value
                          ? "Billing group is active and can receive new records"
                          : "Billing group is inactive and hidden from new record creation"}
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                  </FormItem>
                )}
              />
            )}

            <DialogFooter>
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting
                  ? "Saving..."
                  : isEditing
                    ? "Save Changes"
                    : "Create Group"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
