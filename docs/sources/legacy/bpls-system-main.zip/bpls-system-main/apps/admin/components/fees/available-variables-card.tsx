"use client";

import { Info } from "lucide-react";
import { Alert, AlertDescription } from "@repo/ui/components/alert";

interface CategoryVariable {
  variableName: string;
  assetClass: string;
  quantity: number;
  description?: string;
}

interface AvailableVariablesCardProps {
  /**
   * Dynamic category variables from the business (e.g., numberOfHorses, numberOfTables)
   */
  categoryVariables?: CategoryVariable[];
  /**
   * The selected range field (for Range fee types)
   * Used to show special warnings for dynamic fields like unitOfMeasurement
   */
  rangeField?: string;
  /**
   * Whether to show in a compact inline format (for use inside range cards)
   */
  compact?: boolean;
}

/**
 * Shared component displaying available variables for fee formulas
 * Used by both Range and Formula fee types for consistency
 */
export function AvailableVariablesCard({
  categoryVariables,
  rangeField,
  compact = false,
}: AvailableVariablesCardProps) {
  const hasAssetVariables = categoryVariables && categoryVariables.length > 0;
  const showDynamicSection = rangeField === "unitOfMeasurement" || hasAssetVariables;

  if (compact) {
    return (
      <div className="mt-2 p-2 bg-muted/50 rounded-md border">
        <p className="text-xs font-medium mb-1">Available Variables:</p>
        <ul className="text-xs text-muted-foreground space-y-0.5 ml-2">
          <li>
            • <code className="bg-background px-1 py-0.5 rounded">numberOfEmployees</code> - Total
            number of employees
          </li>
          <li>
            • <code className="bg-background px-1 py-0.5 rounded">maleEmployeeCount</code> - Number
            of male employees
          </li>
          <li>
            • <code className="bg-background px-1 py-0.5 rounded">femaleEmployeeCount</code> -
            Number of female employees
          </li>
          <li>
            • <code className="bg-background px-1 py-0.5 rounded">businessArea</code> - Business
            area in square meters
          </li>
          <li>
            • <code className="bg-background px-1 py-0.5 rounded">capitalInvestment</code> - Capital
            investment from LOB (₱)
          </li>
          <li>
            • <code className="bg-background px-1 py-0.5 rounded">grossSales</code> - Gross sales
            from LOB (₱)
          </li>
          {/* Special Dynamic Variable */}
          {rangeField === "assetSize" && (
            <li>
              •{" "}
              <code className="bg-yellow-100 dark:bg-yellow-900/50 px-1 py-0.5 rounded text-yellow-800 dark:text-yellow-200">
                assetSize
              </code>{" "}
              - The value of the mapped asset size
            </li>
          )}
          {/* Dynamic Asset Variables */}
          {hasAssetVariables &&
            categoryVariables.map((asset) => (
              <li key={asset.variableName}>
                •{" "}
                <code className="bg-green-100 dark:bg-green-900/50 px-1 py-0.5 rounded text-green-800 dark:text-green-200">
                  {asset.variableName}
                </code>
                {asset.description ? ` - ${asset.description}` : ` - ${asset.assetClass}`}
              </li>
            ))}
        </ul>
        <p className="text-xs text-muted-foreground mt-2">
          <strong>Example:</strong>{" "}
          <code className="bg-background px-1 py-0.5 rounded">
            numberOfEmployees * 100 + businessArea * 50
          </code>
        </p>
      </div>
    );
  }

  return (
    <Alert className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800">
      <Info className="h-4 w-4 text-blue-600 dark:text-blue-400" />
      <AlertDescription>
        <p className="font-semibold text-sm mb-2 text-blue-900 dark:text-blue-100">
          Available Variables for Formulas:
        </p>
        <div className="space-y-3">
          {/* Standard Variables */}
          <div>
            <p className="text-xs font-medium text-blue-800 dark:text-blue-200 mb-1">
              Standard Variables:
            </p>
            <ul className="list-disc list-inside space-y-1 text-xs text-blue-800 dark:text-blue-200">
              <li>
                <code className="bg-blue-100 dark:bg-blue-900/50 px-1.5 py-0.5 rounded">
                  numberOfEmployees
                </code>{" "}
                - Total number of employees
              </li>
              <li>
                <code className="bg-blue-100 dark:bg-blue-900/50 px-1.5 py-0.5 rounded">
                  maleEmployeeCount
                </code>{" "}
                - Number of male employees
              </li>
              <li>
                <code className="bg-blue-100 dark:bg-blue-900/50 px-1.5 py-0.5 rounded">
                  femaleEmployeeCount
                </code>{" "}
                - Number of female employees
              </li>
              <li>
                <code className="bg-blue-100 dark:bg-blue-900/50 px-1.5 py-0.5 rounded">
                  businessArea
                </code>{" "}
                - Business area in square meters
              </li>
              <li>
                <code className="bg-blue-100 dark:bg-blue-900/50 px-1.5 py-0.5 rounded">
                  capitalInvestment
                </code>{" "}
                - Capital investment from LOB (₱)
              </li>
              <li>
                <code className="bg-blue-100 dark:bg-blue-900/50 px-1.5 py-0.5 rounded">
                  grossSales
                </code>{" "}
                - Gross sales from LOB (₱)
              </li>
            </ul>
          </div>

          {/* Dynamic Asset Variables */}
          {showDynamicSection && (
            <div className="border-t border-blue-200 dark:border-blue-700 pt-2">
              <p className="text-xs font-medium text-blue-800 dark:text-blue-200 mb-1">
                Dynamic Asset Variables:
              </p>
              <ul className="list-disc list-inside space-y-1 text-xs text-blue-800 dark:text-blue-200">
                {rangeField === "unitOfMeasurement" && (
                  <li>
                    <code className="bg-yellow-100 dark:bg-yellow-900/50 px-1.5 py-0.5 rounded text-yellow-800 dark:text-yellow-200">
                      {rangeField}
                    </code>{" "}
                    - Placeholder for a mapped value (requires mapping on dashboard)
                  </li>
                )}
                {hasAssetVariables &&
                  categoryVariables.map((asset) => (
                    <div key={asset.variableName} className="text-xs">
                      <code className="bg-green-100 dark:bg-green-900/50 px-1.5 py-0.5 rounded text-green-800 dark:text-green-200">
                        {asset.variableName}
                      </code>
                      {asset.description && (
                        <span className="text-blue-700 dark:text-blue-300 ml-1">
                          - {asset.description}
                        </span>
                      )}
                    </div>
                  ))}
              </ul>
            </div>
          )}
        </div>
        <p className="text-xs text-blue-700 dark:text-blue-300 mt-2">
          <strong>Example:</strong>{" "}
          <code className="bg-blue-100 dark:bg-blue-900/50 px-1.5 py-0.5 rounded">
            numberOfEmployees * 100 + businessArea * 50
            {hasAssetVariables && ` + ${categoryVariables[0].variableName} * 25`}
          </code>
        </p>
      </AlertDescription>
    </Alert>
  );
}
