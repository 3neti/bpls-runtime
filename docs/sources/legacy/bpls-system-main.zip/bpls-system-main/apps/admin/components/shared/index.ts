/**
 * Shared Form Components - Export Index
 *
 * Provides unified form components for business and business owner management
 * that work seamlessly in both create and update modes.
 */

export { BusinessDetailsForm, businessDetailsFormSchema } from "./business-details-form";
export type { BusinessDetailsFormSchema } from "./business-details-form";

export { BusinessOwnerForm, businessOwnerFormSchema } from "./business-owner-form";
export type { BusinessOwnerFormSchema } from "./business-owner-form";
