"use client"

import { ColumnDef } from "@tanstack/react-table"
import { ArrowUpDown, Eye, Calendar, CheckCircle2, Trash2 } from "lucide-react"

import { Button } from "@repo/ui/components/button"
import { Badge } from "@repo/ui/components/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@repo/ui/components/avatar"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import type { Doc } from "@repo/backend/convex/_generated/dataModel"
import { formatCurrency, formatDate, getInitials } from "@/lib/utils/formatting"

// Type for released application with payment summary
// paymentSummary is optional because search results may not include it
type ReleasedApplicationRow = Doc<"business_permit_applications"> & {
  ownerName: string
  businessName: string
  ownerAvatar?: string
  businessOwner: Doc<"business_owners"> | null
  business: Doc<"businesses"> | null
  paymentSummary?: {
    totalPaid: number
    totalRemaining: number
    periodsPaid: number
    totalPeriods: number
    nextPaymentDate: string | null
  }
  clearanceProgress?: {
    completed: number
    total: number
    percentage: number
  }
}

interface ReleasedColumnsProps {
  onRowClick?: (applicationId: string) => void
  onDelete?: (applicationId: string) => void
}

export const createReleasedColumns = (
  props?: ReleasedColumnsProps
): ColumnDef<ReleasedApplicationRow>[] => [
  {
    id: "applicationNumber",
    accessorKey: "applicationNumber",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Application Name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const application = row.original
      return (
        <div>
          <p className="font-semibold">{application.applicationNumber}</p>
          <p className="text-sm text-muted-foreground">{application.businessName}</p>
        </div>
      )
    },
    enableHiding: false,
  },
  {
    id: "ownerName",
    accessorKey: "ownerName",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Business Owner
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const owner = row.original
      return (
        <div className="flex items-center space-x-3">
          <Avatar className="h-8 w-8">
            <AvatarImage src={owner.ownerAvatar || "/placeholder.svg"} alt={owner.ownerName} />
            <AvatarFallback>{getInitials(owner.ownerName)}</AvatarFallback>
          </Avatar>
          <span className="text-sm">{owner.ownerName}</span>
        </div>
      )
    },
  },
  {
    id: "totalPaid",
    accessorFn: (row) => row.paymentSummary?.totalPaid ?? 0,
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="justify-end w-full"
        >
          Total Paid
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      return (
        <div className="text-right">
          <span className="font-medium text-green-600">
            {formatCurrency(row.original.paymentSummary?.totalPaid ?? 0, { withSymbol: true })}
          </span>
        </div>
      )
    },
  },
  {
    id: "nextPayment",
    accessorFn: (row) => row.paymentSummary?.nextPaymentDate,
    header: "Next Payment",
    cell: ({ row }) => {
      const paymentSummary = row.original.paymentSummary
      const isFullyPaid = (paymentSummary?.totalRemaining ?? 0) <= 0
      const nextPaymentDisplay = isFullyPaid
        ? "Fully Paid"
        : formatDate(paymentSummary?.nextPaymentDate, "short") || "No schedule"

      return isFullyPaid ? (
        <Badge className="bg-green-100 text-green-700 border-green-200">
          <CheckCircle2 className="mr-1 h-3 w-3" />
          Fully Paid
        </Badge>
      ) : (
        <div className="flex items-center gap-1 text-sm">
          <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
          {nextPaymentDisplay}
        </div>
      )
    },
  },
  {
    id: "periodsPaid",
    accessorFn: (row) => row.paymentSummary?.periodsPaid ?? 0,
    header: "Periods Paid",
    cell: ({ row }) => {
      const paymentSummary = row.original.paymentSummary
      return (
        <Badge variant="outline" className="font-medium">
          {paymentSummary?.periodsPaid ?? 0}/{paymentSummary?.totalPeriods ?? 0} periods
        </Badge>
      )
    },
  },
  {
    id: "clearances",
    accessorFn: (row) => row.clearanceProgress?.percentage || 0,
    header: "Clearances",
    cell: ({ row }) => {
      const progress = row.original.clearanceProgress
      return (
        <div className="flex items-center gap-2">
          <div className="w-16 bg-gray-200 rounded-full h-1.5">
            <div
              className="bg-green-600 h-1.5 rounded-full transition-all"
              style={{ width: `${progress?.percentage || 0}%` }}
            />
          </div>
          <span className="text-xs text-muted-foreground whitespace-nowrap">
            {progress?.completed || 0}/{progress?.total || 0}
          </span>
        </div>
      )
    },
  },
  {
    id: "totalRemaining",
    accessorFn: (row) => row.paymentSummary?.totalRemaining ?? 0,
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="justify-end w-full"
        >
          Total Remaining
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const paymentSummary = row.original.paymentSummary
      const isFullyPaid = (paymentSummary?.totalRemaining ?? 0) <= 0

      return (
        <div className="text-right">
          {isFullyPaid ? (
            <span className="text-muted-foreground">—</span>
          ) : (
            <span className="font-medium text-orange-600">
              {formatCurrency(paymentSummary?.totalRemaining ?? 0, { withSymbol: true })}
            </span>
          )}
        </div>
      )
    },
  },
  {
    id: "actions",
    header: "Actions",
    cell: ({ row }) => {
      const application = row.original
      return (
        <div className="flex items-center gap-1">
          <TooltipProvider>
            {props?.onRowClick && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation()
                      props.onRowClick?.(application._id)
                    }}
                    className="h-8 w-8"
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>View application</p>
                </TooltipContent>
              </Tooltip>
            )}
            {props?.onDelete && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation()
                      props.onDelete?.(application._id)
                    }}
                    className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Delete application</p>
                </TooltipContent>
              </Tooltip>
            )}
          </TooltipProvider>
        </div>
      )
    },
    enableSorting: false,
    enableHiding: false,
  },
  // Additional columns (hidden by default)
  {
    id: "lineOfBusiness",
    accessorFn: (row) => {
      const lobs = row.linesOfBusiness
      if (lobs && lobs.length > 0) {
        return lobs[0].businessCategory || "N/A"
      }
      return null
    },
    header: "Line of Business",
    cell: ({ row }) => {
      const lobs = row.original.linesOfBusiness
      if (!lobs || lobs.length === 0) {
        return <span className="text-muted-foreground text-sm">N/A</span>
      }
      const primaryLob = lobs[0].businessCategory || "Unknown"
      const additionalCount = lobs.length > 1 ? ` +${lobs.length - 1} more` : ""
      return (
        <div className="text-sm">
          {primaryLob}
          {additionalCount && (
            <span className="text-muted-foreground">{additionalCount}</span>
          )}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "businessScale",
    accessorFn: (row) => row.business?.businessScale,
    header: "Business Scale",
    cell: ({ row }) => {
      const scale = row.original.business?.businessScale
      return (
        <Badge variant="outline" className="text-xs">
          {scale || "N/A"}
        </Badge>
      )
    },
    enableHiding: true,
  },
  {
    id: "ownershipType",
    accessorFn: (row) => row.business?.ownershipType,
    header: "Ownership Type",
    cell: ({ row }) => {
      const ownershipType = row.original.business?.ownershipType
      return (
        <div className="text-sm">
          {ownershipType || <span className="text-muted-foreground">N/A</span>}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "businessAddress",
    accessorFn: (row) => row.business?.address,
    header: "Business Address",
    cell: ({ row }) => {
      const address = row.original.business?.address
      return (
        <div className="text-sm max-w-[200px] truncate" title={address || undefined}>
          {address || <span className="text-muted-foreground">N/A</span>}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "ownerEmail",
    accessorFn: (row) => row.businessOwner?.email,
    header: "Owner Email",
    cell: ({ row }) => {
      const email = row.original.businessOwner?.email
      return (
        <div className="text-sm text-muted-foreground">
          {email || "N/A"}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "ownerContact",
    accessorFn: (row) => row.businessOwner?.mobile,
    header: "Owner Contact",
    cell: ({ row }) => {
      const mobile = row.original.businessOwner?.mobile
      return (
        <div className="text-sm font-mono">
          {mobile || <span className="text-muted-foreground">N/A</span>}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "applicationType",
    accessorKey: "permitApplicationType",
    header: "Application Type",
    cell: ({ row }) => {
      const type = row.original.permitApplicationType
      return (
        <Badge variant="outline" className={type === "Renewal" ? "bg-blue-50 text-blue-700 border-blue-200" : "bg-green-50 text-green-700 border-green-200"}>
          {type || "New"}
        </Badge>
      )
    },
    enableHiding: true,
  },
]

export type { ReleasedApplicationRow }
