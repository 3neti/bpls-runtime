"use client";

import type {
  AssessmentSheetData,
  AggregatedFee,
  FeeBreakdownItem,
  LobGroupedFee,
  PaymentScheduleSection,
} from "./assessment-sheet-document";

// Re-export types for external use
export type {
  AssessmentSheetData,
  AggregatedFee,
  FeeBreakdownItem,
  LobGroupedFee,
  PaymentScheduleSection,
};

// Props interface that matches what the assessment page will provide
export interface AssessmentSheetPdfProps {
  applicationNumber: string;
  permitApplicationType?: "New" | "Renewal" | "Additional";
  modeOfPayment?: "Annually" | "Semi-Annually" | "Quarterly";
  businessOwner?: {
    firstName: string;
    middleName?: string;
    lastName: string;
  } | null;
  business?: {
    name: string;
    address?: string;
  } | null;
  provinceName?: string;
  cityName?: string;
  barangayName?: string;
  linesOfBusiness?: Array<{
    businessCategory: string;
  }>;
  // Aggregated fees from LOB configuration (same structure as FeeSummarySection)
  aggregatedFees?: Array<{
    feeName: string;
    totalAmount: number;
    breakdown: Array<{
      lobId: string;
      lobName: string;
      amount: number;
      isExcluded?: boolean;
    }>;
  }>;
  // Payment schedule data for the Schedule of Payments section
  paymentSchedule?: PaymentScheduleSection[];
  // Footer fields
  preparedBy?: string;
  preparedDate?: string;
  approvedByName?: string;
  approvedByTitle?: string;
  // Platform settings for PDF header
  platformProvinceName?: string;   // Province name from settings (for header)
  municipalityName?: string;       // e.g., "MUNICIPALITY OF IPIL"
  municipalSealUrl?: string | null; // URL to municipal seal image
}

/**
 * Transforms fee-grouped aggregated fees to LOB-grouped fees
 * Input: Fees grouped by fee name with LOB breakdown
 * Output: Fees grouped by LOB name with fee list
 */
function transformToLobGrouped(
  aggregatedFees: AggregatedFee[] | undefined
): LobGroupedFee[] {
  if (!aggregatedFees || aggregatedFees.length === 0) {
    return [];
  }

  // Map to collect fees by LOB
  const lobMap = new Map<
    string,
    { fees: Array<{ feeName: string; amount: number }>; subtotal: number }
  >();

  // Iterate through each fee and its breakdown (skip excluded items)
  aggregatedFees.forEach((fee) => {
    fee.breakdown
      .filter((item) => !item.isExcluded)
      .forEach((item) => {
        const existing = lobMap.get(item.lobName) || { fees: [], subtotal: 0 };
        existing.fees.push({ feeName: fee.feeName, amount: item.amount });
        existing.subtotal += item.amount;
        lobMap.set(item.lobName, existing);
      });
  });

  // Convert map to array
  return Array.from(lobMap.entries()).map(([lobName, data]) => ({
    lobName,
    fees: data.fees,
    subtotal: data.subtotal,
  }));
}

/**
 * Maps permit application data to AssessmentSheetData interface
 * for rendering in the Assessment Sheet PDF
 */
export function mapToAssessmentData(
  props: AssessmentSheetPdfProps
): AssessmentSheetData {
  const {
    applicationNumber,
    permitApplicationType,
    modeOfPayment,
    businessOwner,
    business,
    provinceName,
    cityName,
    barangayName,
    linesOfBusiness,
    aggregatedFees,
    paymentSchedule,
    preparedBy,
    preparedDate,
    approvedByName,
    approvedByTitle,
    // Platform settings for PDF header
    platformProvinceName,
    municipalityName,
    municipalSealUrl,
  } = props;

  // Build owner name
  const ownerName = businessOwner
    ? [businessOwner.firstName, businessOwner.middleName, businessOwner.lastName]
        .filter(Boolean)
        .join(" ")
        .toUpperCase()
    : "";

  // Build business address
  const addressParts = [
    business?.address,
    barangayName,
    cityName,
    provinceName,
  ].filter(Boolean);
  const businessAddress = addressParts.join(", ");

  // Extract LOB names
  const lobNames = linesOfBusiness?.map((lob) => lob.businessCategory) || [];

  // Calculate grand total from aggregated fees
  const grandTotal =
    aggregatedFees?.reduce((sum, fee) => sum + fee.totalAmount, 0) || 0;

  // Transform to LOB-grouped fees
  const lobGroupedFees = transformToLobGrouped(aggregatedFees);

  // Map transaction type
  let transactionType: AssessmentSheetData["transactionType"] = "New";
  if (permitApplicationType === "Renewal") {
    transactionType = "ReNew";
  } else if (permitApplicationType === "Additional") {
    transactionType = "Additional";
  } else if (permitApplicationType === "New") {
    transactionType = "New";
  }

  return {
    applicationNumber,
    transactionType,
    ownerName,
    businessName: business?.name?.toUpperCase() || "",
    businessAddress,
    paymentMode: modeOfPayment,
    linesOfBusiness: lobNames,
    aggregatedFees: aggregatedFees || [],
    lobGroupedFees,
    paymentSchedule: paymentSchedule || [],
    grandTotal,
    preparedBy,
    preparedDate,
    approvedByName,
    approvedByTitle,
    // Platform settings for PDF header - prefer platform settings over business location
    provinceName: platformProvinceName || provinceName,
    municipalityName,
    municipalSealUrl: municipalSealUrl || undefined,
  };
}
