/**
 * Add Clearance Dialog Component
 *
 * Simplified dialog form for creating new clearances with only:
 * - Clearance Name
 * - Description
 */

"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { useMutation } from "convex/react"
import { api } from "@repo/backend/convex/_generated/api"
import { useToast } from "@/hooks/use-toast"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form"
import { Input } from "@repo/ui/components/input"
import { Textarea } from "@repo/ui/components/textarea"
import { Button } from "@repo/ui/components/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import { clearanceFormSchema, clearanceFormDefaultValues, type ClearanceFormSchema } from "@/lib/schemas/department-form"
import { iconOptions } from "@/lib/utils/icon-mapper"

interface AddDepartmentDialogProps {
  /** Whether the dialog is open */
  open: boolean
  /** Callback when dialog close state changes */
  onOpenChange: (open: boolean) => void
  /** Callback when form is submitted successfully */
  onSubmit?: (values: ClearanceFormSchema) => void
}

/**
 * Generate slug from text (lowercase, spaces to hyphens)
 */
function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, "") // Remove special characters
    .replace(/\s+/g, "-") // Replace spaces with hyphens
    .replace(/-+/g, "-") // Remove consecutive hyphens
}

export function AddDepartmentDialog({ open, onOpenChange, onSubmit }: AddDepartmentDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()
  const createDepartment = useMutation(api.departments.createDepartment)

  const form = useForm<ClearanceFormSchema>({
    resolver: zodResolver(clearanceFormSchema),
    defaultValues: clearanceFormDefaultValues,
    mode: "onChange",
  })

  const handleSubmit = async (values: ClearanceFormSchema) => {
    setIsSubmitting(true)
    try {
      // Generate derived values for backward compatibility
      const slug = generateSlug(values.name)

      // Call Convex mutation with auto-generated defaults
      const result = await createDepartment({
        name: values.name,
        description: values.description || "",
        isActive: true,
      } as any)

      console.log("Clearance created:", result)

      // Call parent's onSubmit if provided
      onSubmit?.(values)

      toast({
        title: "Clearance Created",
        description: `${values.name} has been created successfully.`,
      })

      // Reset form and close dialog
      form.reset()
      onOpenChange(false)
    } catch (error) {
      console.error("Failed to create clearance:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create clearance. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleCancel = () => {
    form.reset()
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Add New Clearance</DialogTitle>
          <DialogDescription>
            Create a new clearance type for business permits.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Clearance Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Sanitary Clearance" {...field} />
                  </FormControl>
                  <FormDescription>
                    The display name for this clearance type
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="icon"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Icon</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select an icon" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {iconOptions.map((option) => {
                        const IconComponent = option.icon
                        return (
                          <SelectItem key={option.value} value={option.value}>
                            <div className="flex items-center gap-2">
                              <IconComponent className="h-4 w-4" />
                              <span>{option.label}</span>
                            </div>
                          </SelectItem>
                        )
                      })}
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Icon displayed for this clearance
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Brief description of the clearance requirement..."
                      className="min-h-[80px] resize-none"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Optional description of the clearance
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </form>
        </Form>

        <DialogFooter>
          <Button variant="outline" onClick={handleCancel} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button onClick={form.handleSubmit(handleSubmit)} disabled={isSubmitting || !form.formState.isValid}>
            {isSubmitting ? "Creating..." : "Create Clearance"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
