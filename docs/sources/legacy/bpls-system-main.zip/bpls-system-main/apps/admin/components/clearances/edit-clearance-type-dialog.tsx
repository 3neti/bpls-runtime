"use client"

import { useState, useEffect } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { useMutation } from "convex/react"
import { api } from "@repo/backend/convex/_generated/api"
import { useToast } from "@/hooks/use-toast"
import {
  clearanceTypeFormSchema,
  type ClearanceTypeFormValues,
  CLEARANCE_TYPE_ICONS,
} from "@/lib/schemas/clearance-type-form"
import type { Doc } from "@repo/backend/convex/_generated/dataModel"

import { Button } from "@repo/ui/components/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form"
import { Input } from "@repo/ui/components/input"
import { Textarea } from "@repo/ui/components/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import { Switch } from "@repo/ui/components/switch"
import { Loader2 } from "lucide-react"
import { getIconComponent } from "@/lib/utils/icon-mapper"

interface EditClearanceTypeDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  clearanceTypeData: Doc<"clearance_types"> | null
  onSuccess?: () => void
}

export function EditClearanceTypeDialog({
  open,
  onOpenChange,
  clearanceTypeData,
  onSuccess,
}: EditClearanceTypeDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()
  const updateClearanceType = useMutation(api.clearanceTypes.updateClearanceType)

  const form = useForm<ClearanceTypeFormValues>({
    resolver: zodResolver(clearanceTypeFormSchema),
    defaultValues: {
      name: "",
      shortName: "",
      icon: "Shield",
      certificateName: "",
      description: "",
      isActive: true,
    },
  })

  // Reset form when clearanceTypeData changes
  useEffect(() => {
    if (clearanceTypeData) {
      form.reset({
        name: clearanceTypeData.name,
        shortName: clearanceTypeData.shortName,
        icon: clearanceTypeData.icon,
        certificateName: clearanceTypeData.certificateName,
        description: clearanceTypeData.description,
        isActive: clearanceTypeData.isActive,
      })
    }
  }, [clearanceTypeData, form])

  const onSubmit = async (data: ClearanceTypeFormValues) => {
    if (!clearanceTypeData) return

    setIsSubmitting(true)
    try {
      await updateClearanceType({
        id: clearanceTypeData._id,
        ...data,
      })

      toast({
        title: "Clearance Type Updated",
        description: `${data.name} has been updated successfully.`,
      })

      onSuccess?.()
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to update clearance type",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Clearance Type</DialogTitle>
          <DialogDescription>
            Update clearance type information.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Sanitary Department" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="shortName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Short Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Sanitary" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="icon"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Icon</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select an icon" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {CLEARANCE_TYPE_ICONS.map((icon) => {
                        const IconComponent = getIconComponent(icon.value)
                        return (
                          <SelectItem key={icon.value} value={icon.value}>
                            <div className="flex items-center gap-2">
                              <IconComponent className="h-4 w-4" />
                              <span>{icon.label}</span>
                            </div>
                          </SelectItem>
                        )
                      })}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="certificateName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Certificate Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Sanitary Permit" {...field} />
                  </FormControl>
                  <FormDescription>
                    Official certificate name issued after clearance
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Health and sanitation compliance clearance"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="isActive"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                  <div className="space-y-0.5">
                    <FormLabel>Active</FormLabel>
                    <FormDescription>
                      Inactive clearance types won&apos;t be assigned to new permits
                    </FormDescription>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                Save Changes
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
