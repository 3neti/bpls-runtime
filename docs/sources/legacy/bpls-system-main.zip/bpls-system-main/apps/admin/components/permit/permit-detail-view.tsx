"use client";

import { useParams, useRouter } from "next/navigation";
import { useState, useMemo, useEffect, useRef, useCallback } from "react";
import { usePreloadedQuery, useMutation, useQuery } from "convex/react";
import type { Preloaded } from "convex/react";
import { ArrowLeft, CheckCircle, Save, Lock, Loader2, AlertCircle } from "lucide-react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import { Button } from "@repo/ui/components/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@repo/ui/components/tooltip";
import { Alert, AlertDescription, AlertTitle } from "@repo/ui/components/alert";
import { usePermissions, type Resource } from "@/hooks/use-permissions";
import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card";
import { Label } from "@repo/ui/components/label";
import { Textarea } from "@repo/ui/components/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog";
import { useToast } from "@/hooks/use-toast";
import { api } from "@repo/backend/convex/_generated/api";
import { STATUS_COLORS, STATUS_LABELS, type PermitApplicationStatus } from "@/lib/types/permit-application";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import { BusinessOwnerCard } from "@/components/permit/business-owner-card";
import { BusinessInfoCard } from "@/components/permit/business-info-card";
import {
  LOBConfigurationCard,
  type FeeOverride,
  type FeeExclusion,
  type UnmappedFeeInfo,
  type AggregatedFeeSummary,
} from "@/components/permit/lob-configuration-card";
import { UnitsOfMeasurementCard } from "@/components/permit/units-of-measurement-card";
import { ModeOfPaymentCard } from "@/components/permit/mode-of-payment-card";
import { PermitTransactionTypeCard } from "@/components/permit/permit-transaction-type-card";
import { BplsFormsCard } from "@/components/permit/bpls-forms-card";
import { ScheduleOfPaymentsCard } from "@/components/permit/schedule-of-payments-card";
import { ApplicationTimelineCard } from "@/components/permit/application-timeline-card";
import { ApplicationStatusSelect } from "@/components/permit/application-status-select";

// Zod schema for fee override
const feeOverrideSchema = z.object({
  feeId: z.custom<Id<"fees">>(),
  feeName: z.string(),
  originalAmount: z.number().min(0, "Amount must be 0 or greater"),
  overriddenAmount: z.number().min(0, "Amount must be 0 or greater"),
  overriddenAt: z.string().optional(),
  overriddenBy: z.string().optional(),
});

// Zod schema for disabled fees (per-LOB)
const feeExclusionSchema = z.object({
  lobId: z.string(),
  feeId: z.custom<Id<"fees">>(),
  feeName: z.string(),
  excludedAmount: z.number().min(0, "Amount must be 0 or greater"),
});

// Zod schema for LOB validation with conditional logic
const lobSchema = z
  .object({
    id: z.string(),
    businessCategory: z.string().min(1, "Category is required"),
    groupId: z
      .custom<Id<"groups">>((val) => val !== null, {
        message: "Group must be selected",
      })
      .nullable(),
    capitalInvestment: z.string(),
    grossSales: z.string(),
    permitApplicationType: z.enum(["New", "Renewal"]),
    numberOfEmployees: z.number().optional(),
    feeOverrides: z.array(feeOverrideSchema).optional(),
    excludedFees: z.array(z.custom<Id<"fees">>()).optional(),
    feeVariableMappings: z
      .array(
        z.object({
          feeId: z.custom<Id<"fees">>(),
          variableName: z.string(),
        })
      )
      .optional(),
  })
  .superRefine((data, ctx) => {
    if (data.permitApplicationType === "New" && data.capitalInvestment.trim().length === 0) {
      ctx.addIssue({
        code: "custom",
        message: "Capital investment is required for new applications",
        path: ["capitalInvestment"],
      });
    }
    if (data.permitApplicationType === "Renewal" && data.grossSales.trim().length === 0) {
      ctx.addIssue({
        code: "custom",
        message: "Gross sales is required for renewal applications",
        path: ["grossSales"],
      });
    }
  });

const assessmentFormSchema = z.object({
  linesOfBusiness: z.array(lobSchema).min(1, "At least one line of business is required"),
});

type AssessmentFormValues = z.infer<typeof assessmentFormSchema>;

export type PermitDetailMode = "assessment" | "payment" | "approval";

interface PermitDetailViewProps {
  preloadedApplication: Preloaded<typeof api.businessPermitApplications.getById>;
  preloadedGroups: Preloaded<typeof api.groups.list>;
  preloadedActivityLogs: Preloaded<typeof api.activityLogs.getResourceHistory>;
  applicationId: Id<"business_permit_applications">;
  mode: PermitDetailMode;
}

export function PermitDetailView({
  preloadedApplication,
  preloadedGroups,
  preloadedActivityLogs,
  applicationId,
  mode,
}: PermitDetailViewProps) {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();

  const id = params.id as Id<"business_permit_applications">;

  // Determine back URL based on mode
  const backUrl =
    mode === "assessment"
      ? "/dashboard/permit-applications/assessment"
      : mode === "approval"
        ? "/dashboard/permit-applications/approval"
        : "/dashboard/permit-applications/payment";
  const pageTitle =
    mode === "assessment"
      ? "Assessment Detail"
      : mode === "approval"
        ? "Approval Detail"
        : "Payment Detail";

  // In payment mode, most editing is disabled except Schedule of Payments
  const isPaymentMode = mode === "payment";
  // Approval mode is a pure review gate: all assessment fields are read-only
  const isApprovalMode = mode === "approval";
  // Combined flag for fields that are not editable in payment OR approval mode
  const isReadOnlyMode = isPaymentMode || isApprovalMode;

  const application = usePreloadedQuery(preloadedApplication);
  const groupsResult = usePreloadedQuery(preloadedGroups);
  const groups = groupsResult?.success ? groupsResult.data : [];
  const submitForClearances = useMutation(api.businessPermitApplications.submitForClearances);
  const updateLOBConfiguration = useMutation(api.businessPermitApplications.updateLOBConfiguration);
  const generatePaymentSchedules = useMutation(api.paymentSchedules.generate);
  const updateModeOfPaymentMutation = useMutation(api.businessPermitApplications.updateModeOfPayment);
  const approveForPaymentMutation = useMutation(api.businessPermitApplications.approveForPayment);
  const returnToAssessmentMutation = useMutation(api.businessPermitApplications.returnToAssessment);

  // Query location names for business
  const businessLocationData = useQuery(
    api.locations.getLocationHierarchy,
    application?.business?.provinceId
      ? {
          provinceId: application.business.provinceId,
          cityId: application.business.cityId,
          barangayId: application.business.barangayId,
        }
      : "skip"
  );

  // Query location names for business owner
  const ownerLocationData = useQuery(
    api.locations.getLocationHierarchy,
    application?.businessOwner?.provinceId
      ? {
          provinceId: application.businessOwner.provinceId,
          cityId: application.businessOwner.cityId,
          barangayId: application.businessOwner.barangayId,
        }
      : "skip"
  );

  const isLoading = application === undefined;

  // Initialize React Hook Form
  const form = useForm<AssessmentFormValues>({
    resolver: zodResolver(assessmentFormSchema),
    defaultValues: {
      linesOfBusiness: [],
    },
    mode: "onChange",
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "linesOfBusiness",
  });

  // Track if we've already initialized LOBs for this application
  const hasInitializedLOBs = useRef<string | null>(null);

  // Initialize form with application data when loaded
  useEffect(() => {
    if (application?.linesOfBusiness && groups && groups.length > 0) {
      if (hasInitializedLOBs.current !== application._id) {
        const initialLOBs = application.linesOfBusiness.map((lob: any, idx: number) => {
          const group = groups.find((g: (typeof groups)[number]) => g.name === lob.businessCategory);

          const excludedFeeIds = (lob.excludedFees || [])
            .map((ef: any) => (typeof ef === "object" && ef.feeId ? ef.feeId : ef))
            .filter((id: any): id is Id<"fees"> => id !== undefined && id !== null);

          return {
            id: `${application._id}-${idx}`,
            businessCategory: lob.businessCategory,
            groupId: group?._id || null,
            capitalInvestment: lob.capitalInvestment || "",
            grossSales: lob.grossSales || lob.businessAnnualRevenue || "",
            permitApplicationType: lob.permitApplicationType as "New" | "Renewal",
            numberOfEmployees: lob.numberOfEmployees,
            feeOverrides: lob.feeOverrides || [],
            excludedFees: excludedFeeIds,
            feeVariableMappings: lob.feeVariableMappings || [],
          };
        });

        form.reset({
          linesOfBusiness: initialLOBs,
        });

        if (application.feeOverrides && application.feeOverrides.length > 0) {
          setFeeOverrides(application.feeOverrides as FeeOverride[]);
        } else {
          setFeeOverrides([]);
        }

        const allExclusions: FeeExclusion[] = [];
        application.linesOfBusiness.forEach((lob: any, idx: number) => {
          const lobId = `${application._id}-${idx}`;
          if (lob.excludedFees && lob.excludedFees.length > 0) {
            lob.excludedFees.forEach((exclusion: any) => {
              const feeId = typeof exclusion === "string" ? exclusion : exclusion?.feeId;
              const feeName = typeof exclusion === "string" ? "Disabled Fee" : (exclusion?.feeName || "Disabled Fee");
              const excludedAmount = typeof exclusion === "string" ? 0 : (exclusion?.excludedAmount || 0);

              if (feeId) {
                allExclusions.push({
                  lobId,
                  feeId,
                  feeName,
                  excludedAmount,
                });
              }
            });
          }
        });
        setFeeExclusions(allExclusions);

        if (application.modeOfPayment) {
          setModeOfPayment(application.modeOfPayment as "Annually" | "Semi-Annually" | "Quarterly");
        }

        hasInitializedLOBs.current = application._id;
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [application, groups]);

  // Cleanup timers on unmount
  useEffect(() => {
    return () => {
      if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current);
      if (debouncedAutoSaveRef.current) clearTimeout(debouncedAutoSaveRef.current);
    };
  }, []);

  // Form state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isApproving, setIsApproving] = useState(false);
  const [isReturning, setIsReturning] = useState(false);
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showReturnDialog, setShowReturnDialog] = useState(false);
  const [returnReason, setReturnReason] = useState("");

  // Fee state
  const [feeOverrides, setFeeOverrides] = useState<FeeOverride[]>([]);
  const [feeExclusions, setFeeExclusions] = useState<FeeExclusion[]>([]);
  const [unmappedFees, setUnmappedFees] = useState<UnmappedFeeInfo[]>([]);
  const [aggregatedFees, setAggregatedFees] = useState<AggregatedFeeSummary[]>([]);

  // Mode of payment state
  const [modeOfPayment, setModeOfPayment] = useState<"Annually" | "Semi-Annually" | "Quarterly" | undefined>(
    application?.modeOfPayment as "Annually" | "Semi-Annually" | "Quarterly" | undefined
  );

  // Track if payments have been made
  const [hasPaymentsMade, setHasPaymentsMade] = useState(false);

  // Auto-save state
  const [autoSaveStatus, setAutoSaveStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [autoSaveError, setAutoSaveError] = useState<string | null>(null);
  const autoSaveTimerRef = useRef<NodeJS.Timeout | null>(null);
  const debouncedAutoSaveRef = useRef<NodeJS.Timeout | null>(null);

  // Permit application type state
  const [permitApplicationType, setPermitApplicationType] = useState<"New" | "Renewal" | "Additional" | undefined>(
    application?.permitApplicationType as "New" | "Renewal" | "Additional" | undefined
  );

  // Mutations
  const updatePermitApplicationTypeMutation = useMutation(api.businessPermitApplications.updatePermitApplicationType);

  // Permission checks - status-aware: each sub-resource maps to an application status
  const { canUpdate, isLoading: permissionsLoading } = usePermissions();

  // Check if user can override LOB fees after payment schedule creation
  const canOverrideFees = canUpdate("permit_applications:fees_override" as Resource);

  // Check if user can update the status of permit applications
  const canUpdateStatus = canUpdate("permit_applications:status_update" as Resource);

  // Check if user can approve applications (Approval -> Pending Payment / back to Assessment)
  const canApprove = canUpdate("permit_applications:approval" as Resource);

  // Fees/LOB are locked (read-only) in approval mode always, and in payment mode
  // unless the user has the fee-override permission.
  const feesLocked = isApprovalMode || (isPaymentMode && !canOverrideFees);

  const getStatusPermissionResource = (status: string): Resource | null => {
    switch (status) {
      case "Assessment": return "permit_applications:assessment";
      case "Approval": return "permit_applications:approval";
      case "Pending Payment": return "permit_applications:payment";
      case "Released": return "permit_applications:releasing";
      default: return null;
    }
  };

  const statusResource = application ? getStatusPermissionResource(application.status) : null;
  const canUpdateApplication =
    canUpdate("permit_applications:all_applications") ||
    (statusResource !== null && canUpdate(statusResource));

  // Calculate total employees from business data
  const totalEmployees = useMemo(() => {
    if (!application?.business) return 0;
    return application.business.maleEmployeeCount + application.business.femaleEmployeeCount;
  }, [application]);

  // Watch form values
  const linesOfBusiness = form.watch("linesOfBusiness");

  // Calculate total fees from LOB data
  const totalFees = useMemo(() => {
    return linesOfBusiness.reduce((total, lob) => {
      const capital = Number.parseFloat(lob.capitalInvestment) || 0;
      const revenue = Number.parseFloat(lob.grossSales) || 0;
      return total + (capital + revenue) * 0.01;
    }, 0);
  }, [linesOfBusiness]);

  // Sequential save queue: prevents race conditions when saves overlap
  const isSavingRef = useRef(false);
  const pendingSaveRef = useRef(false);

  // Auto-save: builds the same payload as handleSaveConfiguration but without toast
  const triggerAutoSave = useCallback(async () => {
    const formValues = form.getValues();
    if (formValues.linesOfBusiness.length === 0 || feesLocked) return;

    // If a save is already in-flight, mark as pending and return
    if (isSavingRef.current) {
      pendingSaveRef.current = true;
      return;
    }

    isSavingRef.current = true;
    if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current);
    setAutoSaveStatus("saving");
    setAutoSaveError(null);

    try {
      const currentLOBs = formValues.linesOfBusiness;
      const lobsForSave = currentLOBs.map((lob) => {
        const lobExclusions = feeExclusions.filter((e) => e.lobId === lob.id);

        const lobData: {
          businessCategory: string;
          capitalInvestment: string;
          grossSales: string;
          permitApplicationType: string;
          numberOfEmployees?: number;
          feeOverrides?: typeof lob.feeOverrides;
          excludedFees?: Id<"fees">[];
          feeVariableMappings?: typeof lob.feeVariableMappings;
        } = {
          businessCategory: lob.businessCategory,
          capitalInvestment: lob.capitalInvestment,
          grossSales: lob.grossSales,
          permitApplicationType: lob.permitApplicationType,
        };

        if (lob.numberOfEmployees !== undefined && lob.numberOfEmployees !== null) {
          lobData.numberOfEmployees = lob.numberOfEmployees;
        }

        if (lob.feeOverrides && lob.feeOverrides.length > 0) {
          lobData.feeOverrides = lob.feeOverrides;
        }

        if (lobExclusions.length > 0) {
          const validFeeIds = lobExclusions
            .map((e) => e.feeId)
            .filter((feeId): feeId is Id<"fees"> => feeId !== undefined && feeId !== null);
          if (validFeeIds.length > 0) {
            lobData.excludedFees = validFeeIds;
          }
        }

        if (lob.feeVariableMappings && lob.feeVariableMappings.length > 0) {
          const validMappings = lob.feeVariableMappings.filter(
            (m) => m.feeId !== undefined && m.variableName !== undefined
          );
          if (validMappings.length > 0) {
            lobData.feeVariableMappings = validMappings;
          }
        }

        return lobData;
      });

      const feeOverridesForSave =
        feeOverrides.length > 0
          ? feeOverrides.map((override) => ({
              feeId: override.feeId,
              feeName: override.feeName,
              originalAmount: override.originalAmount,
              overriddenAmount: override.overriddenAmount,
              overriddenAt: new Date().toISOString(),
              overriddenBy: "Current User",
            }))
          : undefined;

      // Don't send modeOfPayment here — it's saved independently via updateModeOfPayment.
      // Sending it here causes a loop: updateLOBConfiguration patches modeOfPayment →
      // ScheduleOfPaymentsCard detects change → regenerates schedules → triggers again.
      await updateLOBConfiguration({
        id,
        linesOfBusiness: lobsForSave,
        feeOverrides: feeOverridesForSave,
      });
      // Schedule regeneration is handled by the ScheduleOfPaymentsCard component
      // when it detects modeOfPayment or fee changes. Don't duplicate it here.

      setAutoSaveStatus("saved");
      toast({ title: "Changes saved", description: "LOB configuration updated successfully." });
      autoSaveTimerRef.current = setTimeout(() => setAutoSaveStatus("idle"), 2000);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to save. Please try again.";
      setAutoSaveError(message);
      setAutoSaveStatus("error");
      toast({ title: "Save failed", description: message, variant: "destructive" });
    } finally {
      isSavingRef.current = false;
      // If another save was requested while we were saving, re-trigger with latest state
      if (pendingSaveRef.current) {
        pendingSaveRef.current = false;
        triggerAutoSaveRef.current();
      }
    }
  }, [form, feeOverrides, feeExclusions, id, isPaymentMode, canOverrideFees, updateLOBConfiguration, toast]);

  // Keep a ref to the latest triggerAutoSave to avoid stale closures in debounced calls
  const triggerAutoSaveRef = useRef(triggerAutoSave);
  useEffect(() => {
    triggerAutoSaveRef.current = triggerAutoSave;
  }, [triggerAutoSave]);

  // Debounced wrapper so rapid changes batch into a single save
  // Uses ref to always call the latest triggerAutoSave (avoids stale closure with old state)
  const handleAutoSaveRequest = useCallback(() => {
    if (debouncedAutoSaveRef.current) clearTimeout(debouncedAutoSaveRef.current);
    debouncedAutoSaveRef.current = setTimeout(() => {
      triggerAutoSaveRef.current();
    }, 300);
  }, []);

  // Handle mode of payment change with immediate save
  const handleModeOfPaymentChange = async (value: "Annually" | "Semi-Annually" | "Quarterly") => {
    const previousMode = modeOfPayment;
    setModeOfPayment(value);

    if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current);
    setAutoSaveStatus("saving");
    setAutoSaveError(null);

    try {
      await updateModeOfPaymentMutation({ id, modeOfPayment: value });
      setAutoSaveStatus("saved");
      autoSaveTimerRef.current = setTimeout(() => setAutoSaveStatus("idle"), 2000);
    } catch (error) {
      setModeOfPayment(previousMode);
      const message = error instanceof Error ? error.message : "Failed to update mode of payment";
      setAutoSaveError(message);
      setAutoSaveStatus("error");
      toast({ title: "Error", description: message, variant: "destructive" });
    }
  };

  // Handle permit application type change
  const handlePermitApplicationTypeChange = async (value: "New" | "Renewal" | "Additional") => {
    if (!application?._id) return;

    // Optimistically update UI
    setPermitApplicationType(value);

    try {
      await updatePermitApplicationTypeMutation({
        id: application._id,
        permitApplicationType: value,
      });
      toast({
        title: "Updated",
        description: "Permit application type has been updated.",
      });
    } catch (error) {
      // Revert on error
      setPermitApplicationType(application.permitApplicationType as "New" | "Renewal" | "Additional" | undefined);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update permit application type.",
        variant: "destructive",
      });
    }
  };

  const handleSubmitForClearances = async (values: AssessmentFormValues) => {
    setIsSubmitting(true);

    try {
      // Final save to ensure latest state is persisted
      if (debouncedAutoSaveRef.current) clearTimeout(debouncedAutoSaveRef.current);

      // Save configuration first
      const lobsForSave = values.linesOfBusiness.map((lob) => {
        const lobExclusions = feeExclusions.filter((e) => e.lobId === lob.id);

        const lobData: {
          businessCategory: string;
          capitalInvestment: string;
          grossSales: string;
          permitApplicationType: string;
          numberOfEmployees?: number;
          feeOverrides?: typeof lob.feeOverrides;
          excludedFees?: Id<"fees">[];
          feeVariableMappings?: typeof lob.feeVariableMappings;
        } = {
          businessCategory: lob.businessCategory,
          capitalInvestment: lob.capitalInvestment,
          grossSales: lob.grossSales,
          permitApplicationType: lob.permitApplicationType,
        };

        if (lob.numberOfEmployees !== undefined && lob.numberOfEmployees !== null) {
          lobData.numberOfEmployees = lob.numberOfEmployees;
        }

        if (lob.feeOverrides && lob.feeOverrides.length > 0) {
          lobData.feeOverrides = lob.feeOverrides;
        }

        if (lobExclusions.length > 0) {
          const validFeeIds = lobExclusions
            .map((e) => e.feeId)
            .filter((feeId): feeId is Id<"fees"> => feeId !== undefined && feeId !== null);

          if (validFeeIds.length > 0) {
            lobData.excludedFees = validFeeIds;
          }
        }

        if (lob.feeVariableMappings && lob.feeVariableMappings.length > 0) {
          const validMappings = lob.feeVariableMappings.filter(
            (m) => m.feeId !== undefined && m.variableName !== undefined
          );

          if (validMappings.length > 0) {
            lobData.feeVariableMappings = validMappings;
          }
        }

        return lobData;
      });

      const feeOverridesForSave =
        feeOverrides.length > 0
          ? feeOverrides.map((override) => ({
              feeId: override.feeId,
              feeName: override.feeName,
              originalAmount: override.originalAmount,
              overriddenAmount: override.overriddenAmount,
              overriddenAt: new Date().toISOString(),
              overriddenBy: "Current User",
            }))
          : undefined;

      await updateLOBConfiguration({
        id,
        linesOfBusiness: lobsForSave,
        feeOverrides: feeOverridesForSave,
        modeOfPayment,
      });

      // Submit for clearances
      const lobsForSubmission = values.linesOfBusiness.map((lob) => {
        const lobExclusions = feeExclusions.filter((e) => e.lobId === lob.id);

        return {
          businessCategory: lob.businessCategory,
          capitalInvestment: lob.capitalInvestment,
          grossSales: lob.grossSales,
          permitApplicationType: lob.permitApplicationType,
          numberOfEmployees: lob.numberOfEmployees,
          feeOverrides: lob.feeOverrides && lob.feeOverrides.length > 0 ? lob.feeOverrides : undefined,
          excludedFees: lobExclusions.length > 0 ? lobExclusions.map((e) => e.feeId) : undefined,
          feeVariableMappings:
            lob.feeVariableMappings && lob.feeVariableMappings.length > 0 ? lob.feeVariableMappings : undefined,
        };
      });

      const feeOverridesForSubmission = feeOverrides.map((override) => ({
        feeId: override.feeId,
        feeName: override.feeName,
        originalAmount: override.originalAmount,
        overriddenAmount: override.overriddenAmount,
        overriddenAt: new Date().toISOString(),
        overriddenBy: "Current User",
      }));

      await submitForClearances({
        id,
        linesOfBusiness: lobsForSubmission,
        totalFees,
        assessedBy: "Current User",
        assessmentRemarks: "LOB configuration completed",
        feeOverrides: feeOverridesForSubmission.length > 0 ? feeOverridesForSubmission : undefined,
      });

      toast({
        title: "Success",
        description: "Configuration saved and application submitted for clearances",
      });

      router.push(backUrl);
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to submit application",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleApprove = async () => {
    setIsApproving(true);
    try {
      await approveForPaymentMutation({ id });
      toast({
        title: "Application approved",
        description: "The application has been approved and sent to Payment.",
      });
      router.push("/dashboard/permit-applications/approval");
    } catch (error) {
      toast({
        title: "Approval failed",
        description: error instanceof Error ? error.message : "Failed to approve application.",
        variant: "destructive",
      });
    } finally {
      setIsApproving(false);
      setShowApproveDialog(false);
    }
  };

  const handleReturnToAssessment = async () => {
    setIsReturning(true);
    try {
      await returnToAssessmentMutation({ id, remarks: returnReason.trim() || undefined });
      toast({
        title: "Returned to assessment",
        description: "The application has been sent back for re-assessment.",
      });
      router.push("/dashboard/permit-applications/approval");
    } catch (error) {
      toast({
        title: "Return failed",
        description: error instanceof Error ? error.message : "Failed to return application.",
        variant: "destructive",
      });
    } finally {
      setIsReturning(false);
      setShowReturnDialog(false);
      setReturnReason("");
    }
  };

  const handleSaveConfiguration = async () => {
    if (!modeOfPayment) {
      toast({
        title: "Validation Error",
        description: "Please select a Mode of Payment before saving.",
        variant: "destructive",
      });
      return;
    }

    setIsSaving(true);

    try {
      const formValues = form.getValues();
      const currentLOBs = formValues.linesOfBusiness;

      const lobsForSave = currentLOBs.map((lob) => {
        const lobExclusions = feeExclusions.filter((e) => e.lobId === lob.id);

        const lobData: {
          businessCategory: string;
          capitalInvestment: string;
          grossSales: string;
          permitApplicationType: string;
          numberOfEmployees?: number;
          feeOverrides?: typeof lob.feeOverrides;
          excludedFees?: Id<"fees">[];
          feeVariableMappings?: typeof lob.feeVariableMappings;
        } = {
          businessCategory: lob.businessCategory,
          capitalInvestment: lob.capitalInvestment,
          grossSales: lob.grossSales,
          permitApplicationType: lob.permitApplicationType,
        };

        if (lob.numberOfEmployees !== undefined && lob.numberOfEmployees !== null) {
          lobData.numberOfEmployees = lob.numberOfEmployees;
        }

        if (lob.feeOverrides && lob.feeOverrides.length > 0) {
          lobData.feeOverrides = lob.feeOverrides;
        }

        if (lobExclusions.length > 0) {
          const validFeeIds = lobExclusions
            .map((e) => e.feeId)
            .filter((feeId): feeId is Id<"fees"> => feeId !== undefined && feeId !== null);

          if (validFeeIds.length > 0) {
            lobData.excludedFees = validFeeIds;
          }
        }

        if (lob.feeVariableMappings && lob.feeVariableMappings.length > 0) {
          const validMappings = lob.feeVariableMappings.filter(
            (m) => m.feeId !== undefined && m.variableName !== undefined
          );

          if (validMappings.length > 0) {
            lobData.feeVariableMappings = validMappings;
          }
        }

        return lobData;
      });

      const feeOverridesForSave =
        feeOverrides.length > 0
          ? feeOverrides.map((override) => ({
              feeId: override.feeId,
              feeName: override.feeName,
              originalAmount: override.originalAmount,
              overriddenAmount: override.overriddenAmount,
              overriddenAt: new Date().toISOString(),
              overriddenBy: "Current User",
            }))
          : undefined;

      const result = await updateLOBConfiguration({
        id,
        linesOfBusiness: lobsForSave,
        feeOverrides: feeOverridesForSave,
        modeOfPayment,
      });

      // Regenerate payment schedules if in Pending Payment status
      if (application.status === "Pending Payment" && aggregatedFees.length > 0) {
        const feesForSchedule = aggregatedFees.map((fee) => ({
          feeName: fee.feeName,
          feeCategory: fee.feeCategory,
          totalAmount: fee.totalAmount,
        }));

        try {
          await generatePaymentSchedules({
            applicationId: id,
            modeOfPayment,
            fees: feesForSchedule,
          });
        } catch (scheduleError) {
          toast({
            title: "Warning",
            description: scheduleError instanceof Error ? scheduleError.message : "LOB configuration saved, but payment schedules could not be updated.",
            variant: "destructive",
          });
          return;
        }
      }

      toast({
        title: "Configuration saved",
        description: application.status === "Pending Payment"
          ? "Lines of business configuration and payment schedules have been updated successfully."
          : "Lines of business configuration, fee overrides, mode of payment, and disabled fees have been saved successfully.",
      });
    } catch (error) {
      toast({
        title: "Save failed",
        description: error instanceof Error ? error.message : "Failed to save configuration. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  // Form validation
  const hasUnmappedFees = unmappedFees.length > 0;
  const hasLinesOfBusiness = linesOfBusiness.length > 0;
  const hasModeOfPayment = !!modeOfPayment;
  const isFormValid = hasLinesOfBusiness && hasModeOfPayment && !hasUnmappedFees;

  const formErrors = form.formState.errors;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          <p className="text-sm text-muted-foreground">Loading application...</p>
        </div>
      </div>
    );
  }

  if (!application) {
    return (
      <div className="flex-1 space-y-4 p-4 pt-6">
        <Button variant="ghost" size="icon" onClick={() => router.push(backUrl)}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <Card>
          <CardContent className="flex items-center justify-center py-8">
            <div className="text-center">
              <h3 className="text-lg font-semibold">Application Not Found</h3>
              <p className="text-muted-foreground">The application with ID "{id}" could not be found.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex-1 space-y-6 p-4 pt-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.push(backUrl)}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h2 className="text-3xl font-bold tracking-tight">{pageTitle}</h2>
            <p className="text-muted-foreground">Application {application.applicationNumber}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <ApplicationStatusSelect
            applicationId={applicationId}
            currentStatus={application.status as PermitApplicationStatus}
            disabled={!canUpdateStatus || permissionsLoading}
          />
        </div>
      </div>

      {/* Read-Only Alert */}
      {!canUpdateApplication && !permissionsLoading && (
        <Alert className="border-amber-500 bg-amber-50">
          <Lock className="h-4 w-4 text-amber-600" />
          <AlertTitle className="text-amber-900">Read-Only Access</AlertTitle>
          <AlertDescription className="text-amber-700">
            You don't have permission to update permit applications. You can view this application but cannot make changes.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Business Owner Information */}
          {application.businessOwner && (
            <BusinessOwnerCard
              owner={{
                profilePhoto: application.businessOwner.avatar,
                fullName: `${application.businessOwner.firstName} ${application.businessOwner.lastName}`,
                firstName: application.businessOwner.firstName,
                middleName: application.businessOwner.middleName,
                lastName: application.businessOwner.lastName,
                birthDate: application.businessOwner.birthDate,
                civilStatus: application.businessOwner.civilStatus,
                gender: application.businessOwner.gender,
                citizenship: application.businessOwner.citizenship,
                tin: application.businessOwner.tin,
                mobile: application.businessOwner.mobile,
                email: application.businessOwner.email,
                address: application.businessOwner.address,
                provinceId: application.businessOwner.provinceId,
                cityId: application.businessOwner.cityId,
                barangayId: application.businessOwner.barangayId,
                // New fields for link and owner details
                ownerId: application.businessOwner._id,
                ownerType: application.businessOwner.ownerType,
                groupName: application.businessOwner.groupName,
              }}
            />
          )}

          {/* Business Information */}
          {application.business && (
            <BusinessInfoCard
              business={{
                name: application.business.name,
                dateEstablished: application.business.establishedDate,
                ownershipType: application.business.ownershipType,
                occupancy: application.business.occupancy,
                permitPaymentCadence: application.business.permitPaymentCadence,
                maleEmployeeCount: application.business.maleEmployeeCount,
                femaleEmployeeCount: application.business.femaleEmployeeCount,
                contactNumber: application.business.contactNumber,
                email: application.business.email,
                address: application.business.address,
                provinceId: application.business.provinceId,
                cityId: application.business.cityId,
                barangayId: application.business.barangayId,
                linesOfBusiness: [],
                businessArea: application.business.businessArea,
                // New fields for link and business details
                businessId: application.business._id,
                registrationNumber: application.business.registrationNumber,
                registrationDate: application.business.registrationDate,
                propertyIndexNumber: application.business.propertyIndexNumber,
                businessScale: application.business.businessScale,
                annualRevenue: application.business.annualRevenue ? Number(application.business.annualRevenue) : undefined,
                dateStarted: application.business.dateStarted,
              }}
              applicationId={application._id}
              hideFeesSection={true}
            />
          )}

          {/* Permit Transaction Type - Only editable during Assessment */}
          <PermitTransactionTypeCard
            value={permitApplicationType}
            onChange={application.status === "Assessment" && !isPaymentMode ? handlePermitApplicationTypeChange : undefined}
            readonly={application.status !== "Assessment" || isPaymentMode}
            disabled={!canUpdateApplication || permissionsLoading}
            disabledReason={
              !canUpdateApplication
                ? "You don't have permission to update permit applications."
                : "Permit application type can only be changed during assessment."
            }
          />

          {/* Mode of Payment - Read-only in payment mode */}
          <ModeOfPaymentCard
            value={modeOfPayment}
            onChange={isReadOnlyMode ? undefined : handleModeOfPaymentChange}
            disabled={isReadOnlyMode || hasPaymentsMade || !canUpdateApplication || permissionsLoading}
            disabledReason={
              !canUpdateApplication
                ? "You don't have permission to update permit applications."
                : isReadOnlyMode
                ? "Mode of payment cannot be changed in this view."
                : "Mode of payment cannot be changed after a payment has been made."
            }
            readonly={isReadOnlyMode}
          />

          {/* Units of Measurement - Read-only in payment mode */}
          <UnitsOfMeasurementCard
            applicationId={application._id}
            title="Units of Measurement"
            description="Configure unit quantities for formula-based fee calculations. These values are used in formula-based fee calculations for this permit application."
            disabled={isReadOnlyMode || !modeOfPayment || !canUpdateApplication || permissionsLoading}
            disabledReason={
              !canUpdateApplication
                ? "You don't have permission to update permit applications."
                : isReadOnlyMode
                ? "Units of measurement cannot be changed in this view."
                : "Please select a Mode of Payment first"
            }
            readOnly={isReadOnlyMode}
          />

          {/* Lines of Business Configuration - Read-only in payment mode */}
          <LOBConfigurationCard
            form={form}
            fields={fields}
            append={append}
            remove={remove}
            totalEmployees={totalEmployees}
            applicationId={application._id}
            businessArea={application.business?.businessArea}
            maleEmployeeCount={application?.business?.maleEmployeeCount}
            femaleEmployeeCount={application?.business?.femaleEmployeeCount}
            permitApplicationType={application.permitApplicationType}
            onFeeOverridesChange={feesLocked ? undefined : setFeeOverrides}
            initialFeeOverrides={feeOverrides}
            onFeeExclusionsChange={feesLocked ? undefined : setFeeExclusions}
            initialFeeExclusions={feeExclusions}
            onUnmappedFeesChange={setUnmappedFees}
            onAggregatedFeesChange={setAggregatedFees}
            disabled={feesLocked || !modeOfPayment || !canUpdateApplication || permissionsLoading}
            disabledReason={
              !canUpdateApplication
                ? "You don't have permission to update permit applications."
                : feesLocked
                ? "Lines of business cannot be changed in this view."
                : "Please select a Mode of Payment first"
            }
            onAutoSave={handleAutoSaveRequest}
          />

          {/* Schedule of Payments - Always editable */}
          <ScheduleOfPaymentsCard
            applicationId={application._id}
            modeOfPayment={modeOfPayment}
            aggregatedFees={aggregatedFees}
            onPaymentStatusChange={setHasPaymentsMade}
            applicationNumber={application.applicationNumber}
            businessName={application.business?.name}
            businessOwnerName={application.businessOwner ? `${application.businessOwner.firstName} ${application.businessOwner.lastName}` : undefined}
            applicationStatus={application.status}
            readOnly={isApprovalMode}
          />
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Actions Card - Hidden in payment and approval modes */}
          {!isReadOnlyMode && (
            <Card>
              <CardHeader>
                <CardTitle>Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {/* Validation Error Display */}
                {(() => {
                  const hasFieldErrors =
                    formErrors.linesOfBusiness &&
                    Array.isArray(formErrors.linesOfBusiness) &&
                    formErrors.linesOfBusiness.some((lobError) => lobError !== null && lobError !== undefined);

                  const hasAnyErrors = hasFieldErrors || hasUnmappedFees;

                  if (!hasAnyErrors || linesOfBusiness.length === 0) return null;

                  return (
                    <div className="bg-destructive/10 border border-destructive/20 text-destructive rounded-md p-3 text-sm space-y-1">
                      <p className="font-semibold">Cannot submit - validation errors:</p>
                      <ul className="list-disc list-inside space-y-0.5">
                        {formErrors.linesOfBusiness &&
                          Array.isArray(formErrors.linesOfBusiness) &&
                          formErrors.linesOfBusiness.map((lobError, idx) => {
                            if (!lobError) return null;
                            return (
                              <li key={`field-${idx}`}>
                                <span className="font-medium">Line {idx + 1}:</span>{" "}
                                {lobError.businessCategory?.message ||
                                  lobError.groupId?.message ||
                                  lobError.capitalInvestment?.message ||
                                  lobError.grossSales?.message ||
                                  "Missing required fields"}
                              </li>
                            );
                          })}

                        {hasUnmappedFees &&
                          (() => {
                            const groupedByLob = unmappedFees.reduce(
                              (acc, fee) => {
                                if (!acc[fee.lobIndex]) {
                                  acc[fee.lobIndex] = { lobName: fee.lobName, fees: [] };
                                }
                                acc[fee.lobIndex].fees.push(fee.feeName);
                                return acc;
                              },
                              {} as Record<number, { lobName: string; fees: string[] }>
                            );

                            return Object.entries(groupedByLob).map(([lobIndexStr, data]) => {
                              const lobIndex = Number.parseInt(lobIndexStr, 10);
                              return (
                                <li key={`unmapped-${lobIndex}`}>
                                  <span className="font-medium">
                                    Line {lobIndex + 1} ({data.lobName}):
                                  </span>{" "}
                                  {data.fees.length === 1
                                    ? `"${data.fees[0]}" requires unit of measurement selection`
                                    : `${data.fees.length} fee(s) require unit of measurement selection`}
                                </li>
                              );
                            });
                          })()}
                      </ul>
                    </div>
                  );
                })()}

                {linesOfBusiness.length === 0 && (
                  <div className="bg-amber-50 border border-amber-200 text-amber-700 rounded-md p-3 text-sm">
                    <p className="font-semibold">Required</p>
                    <p>Add at least one line of business to submit for clearances.</p>
                  </div>
                )}

                <div className="flex flex-col gap-2">
                  {/* Auto-save status */}
                  {autoSaveStatus !== "idle" && (
                    <div className="w-full">
                      {autoSaveStatus === "saving" && (
                        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                          <Loader2 className="h-3 w-3 animate-spin" />
                          <span>Saving changes...</span>
                        </div>
                      )}
                      {autoSaveStatus === "saved" && (
                        <div className="flex items-center gap-1.5 text-sm text-green-600">
                          <CheckCircle className="h-3 w-3" />
                          <span>All changes saved</span>
                        </div>
                      )}
                      {autoSaveStatus === "error" && (
                        <div className="bg-destructive/10 border border-destructive/20 text-destructive rounded-md p-2.5 text-sm w-full">
                          <p className="font-semibold flex items-center gap-1.5">
                            <AlertCircle className="h-3.5 w-3.5" />
                            Failed to save
                          </p>
                          {autoSaveError && <p className="text-xs mt-1">{autoSaveError}</p>}
                        </div>
                      )}
                    </div>
                  )}
                  {application.status === "Assessment" && (
                    <>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              onClick={form.handleSubmit(handleSubmitForClearances)}
                              disabled={!isFormValid || isSubmitting || !canUpdateApplication || permissionsLoading}
                              className="w-full bg-green-600 hover:bg-green-700"
                            >
                              <CheckCircle className="mr-2 h-4 w-4 shrink-0" />
                              <span className="truncate">{isSubmitting ? "Submitting..." : "Submit for Approval"}</span>
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            {!canUpdateApplication ? (
                              <p>You don't have permission to update permit applications</p>
                            ) : !isFormValid ? (
                              <p>Complete LOB configuration and fix validation errors first</p>
                            ) : (
                              <p>Submit application for review and approval</p>
                            )}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Approval Actions - shown only in approval mode */}
          {isApprovalMode && (
            <Card>
              <CardHeader>
                <CardTitle>Approval</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {!canApprove && !permissionsLoading && (
                  <p className="text-sm text-muted-foreground">
                    You don't have permission to approve applications.
                  </p>
                )}
                <Button
                  onClick={() => setShowApproveDialog(true)}
                  disabled={!canApprove || isApproving || isReturning || permissionsLoading}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  <CheckCircle className="mr-2 h-4 w-4 shrink-0" />
                  <span className="truncate">
                    {isApproving ? "Approving..." : "Approve & Send to Payment"}
                  </span>
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setShowReturnDialog(true)}
                  disabled={!canApprove || isApproving || isReturning || permissionsLoading}
                  className="w-full"
                >
                  <ArrowLeft className="mr-2 h-4 w-4 shrink-0" />
                  <span className="truncate">Return to Assessment</span>
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Approve confirmation dialog */}
          <Dialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Approve application?</DialogTitle>
                <DialogDescription>
                  This approves the assessment and moves the application to Pending
                  Payment, making it available on the Payment page.
                </DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setShowApproveDialog(false)}
                  disabled={isApproving}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleApprove}
                  disabled={isApproving}
                  className="bg-green-600 hover:bg-green-700"
                >
                  {isApproving ? "Approving..." : "Approve & Send to Payment"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Return to assessment dialog */}
          <Dialog open={showReturnDialog} onOpenChange={setShowReturnDialog}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Return to assessment?</DialogTitle>
                <DialogDescription>
                  This sends the application back to the Assessment stage for
                  corrections or re-assessment.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-2">
                <Label htmlFor="return-reason">Reason (optional)</Label>
                <Textarea
                  id="return-reason"
                  value={returnReason}
                  onChange={(e) => setReturnReason(e.target.value)}
                  placeholder="Add a note about what needs to be corrected..."
                />
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setShowReturnDialog(false)}
                  disabled={isReturning}
                >
                  Cancel
                </Button>
                <Button onClick={handleReturnToAssessment} disabled={isReturning}>
                  {isReturning ? "Returning..." : "Return to Assessment"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Application Timeline */}
          <ApplicationTimelineCard
            resourceId={application._id}
            resourceType="permit_application"
            preloadedActivityLogs={preloadedActivityLogs}
          />

          {/* BPLS Forms */}
          <BplsFormsCard
            applicationId={application._id}
            applicationNumber={application.applicationNumber}
            permitApplicationType={application.permitApplicationType as "New" | "Renewal" | "Additional" | undefined}
            modeOfPayment={modeOfPayment}
            submittedAt={application.submittedAt}
            businessOwner={
              application.businessOwner
                ? {
                    firstName: application.businessOwner.firstName,
                    middleName: application.businessOwner.middleName,
                    lastName: application.businessOwner.lastName,
                    birthDate: application.businessOwner.birthDate,
                    civilStatus: application.businessOwner.civilStatus,
                    gender: application.businessOwner.gender,
                    citizenship: application.businessOwner.citizenship,
                    tin: application.businessOwner.tin,
                    mobile: application.businessOwner.mobile,
                    email: application.businessOwner.email,
                    address: application.businessOwner.address,
                  }
                : null
            }
            business={
              application.business
                ? {
                    name: application.business.name,
                    establishedDate: application.business.establishedDate,
                    ownershipType: application.business.ownershipType,
                    occupancy: application.business.occupancy,
                    permitPaymentCadence: application.business.permitPaymentCadence,
                    maleEmployeeCount: application.business.maleEmployeeCount,
                    femaleEmployeeCount: application.business.femaleEmployeeCount,
                    contactNumber: application.business.contactNumber,
                    email: application.business.email,
                    address: application.business.address,
                    buildingName: application.business.buildingName,
                    businessArea: application.business.businessArea,
                    registrationNumber: application.business.registrationNumber,
                    registrationDate: application.business.registrationDate,
                    propertyIndexNumber: application.business.propertyIndexNumber,
                  }
                : null
            }
            linesOfBusiness={application.linesOfBusiness?.map((lob: any) => ({
              businessCategory: lob.businessCategory,
              capitalInvestment: lob.capitalInvestment,
              grossSales: lob.grossSales,
              permitApplicationType: lob.permitApplicationType,
              numberOfEmployees: lob.numberOfEmployees,
            }))}
            provinceName={businessLocationData?.province?.name}
            cityName={businessLocationData?.city?.name}
            barangayName={businessLocationData?.barangay?.name}
            ownerProvinceName={ownerLocationData?.province?.name}
            ownerCityName={ownerLocationData?.city?.name}
            ownerBarangayName={ownerLocationData?.barangay?.name}
            aggregatedFees={aggregatedFees}
          />
        </div>
      </div>

    </div>
  );
}
