"use client"

import * as React from "react"
import { Plus, Trash2 } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@repo/ui/components/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import { Input } from "@repo/ui/components/input"
import { ScrollArea } from "@repo/ui/components/scroll-area"
import {
  getOperatorsForType,
  getOperatorLabel,
  type Dimension,
  type FilterGroup,
  type FilterCondition,
  type LogicalOperator,
  type FilterOperator,
} from "@/lib/types/report-builder"

interface FilterBuilderProps {
  dimensions: Dimension[]
  filterGroup: FilterGroup | null
  onChange: (filterGroup: FilterGroup | null) => void
  maxHeight?: string
}

export function FilterBuilder({
  dimensions,
  filterGroup,
  onChange,
  maxHeight = "300px",
}: FilterBuilderProps) {
  // Get only filterable dimensions
  const filterableDimensions = dimensions.filter((d) => d.filterable)

  const addCondition = () => {
    const firstDimension = filterableDimensions[0]
    if (!firstDimension) return

    const newCondition: FilterCondition = {
      dimensionId: firstDimension.id,
      operator: "equals",
      value: "",
    }

    if (!filterGroup) {
      onChange({
        id: crypto.randomUUID(),
        logic: "AND",
        conditions: [newCondition],
      })
    } else {
      onChange({
        ...filterGroup,
        conditions: [...filterGroup.conditions, newCondition],
      })
    }
  }

  const updateCondition = (index: number, updates: Partial<FilterCondition>) => {
    if (!filterGroup) return

    const newConditions = [...filterGroup.conditions]
    newConditions[index] = { ...newConditions[index], ...updates }
    onChange({ ...filterGroup, conditions: newConditions })
  }

  const removeCondition = (index: number) => {
    if (!filterGroup) return

    const newConditions = filterGroup.conditions.filter((_, i) => i !== index)
    if (newConditions.length === 0) {
      onChange(null)
    } else {
      onChange({ ...filterGroup, conditions: newConditions })
    }
  }

  const toggleLogic = () => {
    if (!filterGroup) return

    onChange({
      ...filterGroup,
      logic: filterGroup.logic === "AND" ? "OR" : "AND",
    })
  }

  const clearAll = () => {
    onChange(null)
  }

  const conditionCount = filterGroup?.conditions.length || 0

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-end gap-1">
        {conditionCount > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearAll}
            className="h-6 px-1.5 text-[10px]"
          >
            Clear
          </Button>
        )}
        <Button
          variant="outline"
          size="sm"
          onClick={addCondition}
          disabled={filterableDimensions.length === 0}
          className="h-6 px-2 text-[10px]"
        >
          <Plus className="size-3 mr-0.5" />
          Add
        </Button>
      </div>

      {conditionCount > 0 && filterGroup && (
        <ScrollArea style={{ maxHeight }} className="rounded-md border bg-muted/20 p-2">
          <div className="space-y-2">
            {filterGroup.conditions.map((condition, index) => (
              <div key={index} className="space-y-1.5">
                {index > 0 && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={toggleLogic}
                    className="h-5 w-10 text-[10px] mx-auto block"
                  >
                    {filterGroup.logic}
                  </Button>
                )}
                <FilterConditionRow
                  condition={condition}
                  dimensions={filterableDimensions}
                  onChange={(updates) => updateCondition(index, updates)}
                  onRemove={() => removeCondition(index)}
                />
              </div>
            ))}
          </div>
        </ScrollArea>
      )}

      {conditionCount === 0 && (
        <div className="rounded-md border border-dashed p-3 text-center text-xs text-muted-foreground">
          No filters applied. Click &quot;Add&quot; to filter your data.
        </div>
      )}
    </div>
  )
}

interface FilterConditionRowProps {
  condition: FilterCondition
  dimensions: Dimension[]
  onChange: (updates: Partial<FilterCondition>) => void
  onRemove: () => void
}

function FilterConditionRow({
  condition,
  dimensions,
  onChange,
  onRemove,
}: FilterConditionRowProps) {
  const selectedDimension = dimensions.find((d) => d.id === condition.dimensionId)
  const availableOperators = selectedDimension
    ? getOperatorsForType(selectedDimension.type)
    : []

  const handleDimensionChange = (dimensionId: string) => {
    const dimension = dimensions.find((d) => d.id === dimensionId)
    if (!dimension) return

    const operators = getOperatorsForType(dimension.type)
    onChange({
      dimensionId,
      operator: operators[0] as FilterOperator,
      value: "",
    })
  }

  const renderValueInput = () => {
    if (!selectedDimension) return null

    const operator = condition.operator

    // No value needed for isEmpty/isNotEmpty
    if (operator === "isEmpty" || operator === "isNotEmpty") {
      return (
        <div className="h-8 flex items-center px-3 text-xs text-muted-foreground italic bg-muted/50 rounded-md">
          No value needed
        </div>
      )
    }

    // Categorical with options - show select
    if (selectedDimension.type === "categorical" && selectedDimension.options) {
      if (operator === "in" || operator === "notIn") {
        // Multi-select - for now just use a comma-separated input
        return (
          <Input
            value={Array.isArray(condition.value) ? condition.value.join(", ") : ""}
            onChange={(e) =>
              onChange({
                value: e.target.value.split(",").map((s) => s.trim()),
              })
            }
            placeholder="Val1, Val2..."
            className="h-8 text-xs w-full"
          />
        )
      }

      return (
        <Select
          value={condition.value as string}
          onValueChange={(val) => onChange({ value: val })}
        >
          <SelectTrigger className="h-8 text-xs w-full">
            <SelectValue placeholder="Select..." />
          </SelectTrigger>
          <SelectContent>
            {selectedDimension.options.map((opt) => (
              <SelectItem key={opt} value={opt}>
                {opt}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )
    }

    // Boolean
    if (selectedDimension.type === "boolean") {
      return (
        <Select
          value={String(condition.value)}
          onValueChange={(val) => onChange({ value: val === "true" })}
        >
          <SelectTrigger className="h-8 text-xs w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="true">Yes</SelectItem>
            <SelectItem value="false">No</SelectItem>
          </SelectContent>
        </Select>
      )
    }

    // Date with between
    if (selectedDimension.type === "date" && operator === "between") {
      const values = Array.isArray(condition.value)
        ? (condition.value as [string, string])
        : ["", ""]
      return (
        <div className="flex items-center gap-1 w-full">
          <Input
            type="date"
            value={values[0] || ""}
            onChange={(e) =>
              onChange({ value: [e.target.value, values[1] || ""] as [string, string] })
            }
            className="h-8 text-xs flex-1 min-w-0"
          />
          <Input
            type="date"
            value={values[1] || ""}
            onChange={(e) =>
              onChange({ value: [values[0] || "", e.target.value] as [string, string] })
            }
            className="h-8 text-xs flex-1 min-w-0"
          />
        </div>
      )
    }

    // Text with between (supports alphanumeric like BPA# and numeric strings like OR Number)
    if (selectedDimension.type === "text" && operator === "between") {
      const values = Array.isArray(condition.value)
        ? (condition.value as [string, string])
        : ["", ""]
      return (
        <div className="flex items-center gap-1 w-full">
          <Input
            type="text"
            value={values[0] ?? ""}
            onChange={(e) =>
              onChange({ value: [e.target.value, values[1] ?? ""] as [string, string] })
            }
            className="h-8 text-xs flex-1 min-w-0"
            placeholder="From"
          />
          <Input
            type="text"
            value={values[1] ?? ""}
            onChange={(e) =>
              onChange({ value: [values[0] ?? "", e.target.value] as [string, string] })
            }
            className="h-8 text-xs flex-1 min-w-0"
            placeholder="To"
          />
        </div>
      )
    }

    // Date
    if (selectedDimension.type === "date") {
      return (
        <Input
          type="date"
          value={condition.value as string}
          onChange={(e) => onChange({ value: e.target.value })}
          className="h-8 text-xs w-full"
        />
      )
    }

    // Numeric with between
    if (selectedDimension.type === "numeric" && operator === "between") {
      const values = Array.isArray(condition.value)
        ? (condition.value as [number, number])
        : [0, 0]
      return (
        <div className="flex items-center gap-1 w-full">
          <Input
            type="number"
            value={values[0] || ""}
            onChange={(e) =>
              onChange({ value: [Number(e.target.value), values[1] || 0] as [number, number] })
            }
            className="h-8 text-xs flex-1 min-w-0"
            placeholder="Min"
          />
          <Input
            type="number"
            value={values[1] || ""}
            onChange={(e) =>
              onChange({ value: [values[0] || 0, Number(e.target.value)] as [number, number] })
            }
            className="h-8 text-xs flex-1 min-w-0"
            placeholder="Max"
          />
        </div>
      )
    }

    // Numeric
    if (selectedDimension.type === "numeric") {
      return (
        <Input
          type="number"
          value={condition.value as number}
          onChange={(e) => onChange({ value: Number(e.target.value) })}
          className="h-8 text-xs w-full"
          placeholder="Value..."
        />
      )
    }

    // Default: text input
    return (
      <Input
        value={condition.value as string}
        onChange={(e) => onChange({ value: e.target.value })}
        className="h-8 text-xs w-full"
        placeholder="Value..."
      />
    )
  }

  return (
    <div className="space-y-1.5 p-2 bg-background rounded-md border">
      {/* Row 1: Dimension + Remove */}
      <div className="flex items-center gap-1.5">
        <Select value={condition.dimensionId} onValueChange={handleDimensionChange}>
          <SelectTrigger className="h-8 text-xs flex-1">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {dimensions.map((dim) => (
              <SelectItem key={dim.id} value={dim.id}>
                {dim.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button
          variant="ghost"
          size="icon"
          onClick={onRemove}
          className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive"
        >
          <Trash2 className="size-3.5" />
        </Button>
      </div>

      {/* Row 2: Operator + Value */}
      <div className={cn(
        "gap-1.5",
        condition.operator === "between" ? "flex flex-col" : "grid grid-cols-2"
      )}>
        <Select
          value={condition.operator}
          onValueChange={(val) => onChange({ operator: val as FilterOperator })}
        >
          <SelectTrigger className="h-8 text-xs w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {availableOperators.map((op) => (
              <SelectItem key={op} value={op}>
                {getOperatorLabel(op)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="min-w-0">
          {renderValueInput()}
        </div>
      </div>
    </div>
  )
}
