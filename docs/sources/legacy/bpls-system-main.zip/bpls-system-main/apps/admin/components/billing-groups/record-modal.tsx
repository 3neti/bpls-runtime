"use client"

import { useEffect, useMemo, useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { useConvex, useMutation, useQuery } from "convex/react"
import { CalendarIcon, Check, ChevronsUpDown } from "lucide-react"
import { format } from "date-fns"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form"
import { Input } from "@repo/ui/components/input"
import { Button } from "@repo/ui/components/button"
import { Switch } from "@repo/ui/components/switch"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@repo/ui/components/popover"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@repo/ui/components/command"
import { Calendar } from "@repo/ui/components/calendar"
import { useToast } from "@/hooks/use-toast"
import { cn } from "@/lib/utils"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

type FieldType = "text" | "number" | "currency" | "date" | "dropdown" | "checkbox"

interface Field {
  _id: Id<"billing_group_fields">
  name: string
  fieldType: FieldType
  isRequired: boolean
  isUnique?: boolean
  sortOrder: number
  options?: string[]
  placeholder?: string
  defaultValue?: string
}

interface RecordModalProps {
  open: boolean
  onClose: () => void
  billingGroupId: Id<"billing_groups">
  fields: Field[]
  editingRecordId: Id<"billing_group_records"> | null
}

export function RecordModal({
  open,
  onClose,
  billingGroupId,
  fields,
  editingRecordId,
}: RecordModalProps) {
  const { toast } = useToast()
  const convex = useConvex()
  const isEditing = editingRecordId !== null
  const [openDropdowns, setOpenDropdowns] = useState<Record<string, boolean>>({})

  // Fetch record data if editing
  const recordData = useQuery(
    api.billingGroupRecords.getById,
    editingRecordId ? { id: editingRecordId } : "skip"
  )

  // Mutations
  const createRecord = useMutation(api.billingGroupRecords.create)
  const updateRecord = useMutation(api.billingGroupRecords.update)

  // Create a stable key based on field IDs to detect when fields change
  const fieldsKey = useMemo(() => {
    return fields.map(f => `${f._id}:${f.fieldType}:${f.isRequired}:${f.isUnique}`).join('|')
  }, [fields])

  // Build dynamic schema based on fields - memoized to update when fields change
  const formSchema = useMemo(() => {
    const schemaShape: Record<string, z.ZodTypeAny> = {}

    fields.forEach((field) => {
      let fieldSchema: z.ZodTypeAny

      switch (field.fieldType) {
        case "number":
        case "currency":
          fieldSchema = z.string().refine(
            (val) => val === "" || !isNaN(parseFloat(val)),
            { message: "Must be a valid number" }
          )
          break
        case "checkbox":
          fieldSchema = z.boolean()
          break
        case "date":
          fieldSchema = z.string()
          break
        default:
          fieldSchema = z.string()
      }

      if (field.isRequired && field.fieldType !== "checkbox") {
        fieldSchema = fieldSchema.refine(
          (val) => val !== "" && val !== undefined && val !== null,
          { message: `${field.name} is required` }
        )
      }

      schemaShape[field._id] = fieldSchema
    })

    return z.object(schemaShape)
  }, [fields])

  type FormValues = z.infer<typeof formSchema>

  // Build default values - memoized to update when fields change
  const defaultValues = useMemo((): FormValues => {
    const defaults: Record<string, string | boolean> = {}

    fields.forEach((field) => {
      if (field.fieldType === "checkbox") {
        defaults[field._id] = field.defaultValue === "true"
      } else {
        defaults[field._id] = field.defaultValue || ""
      }
    })

    return defaults as FormValues
  }, [fields])

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
  })

  // Reset form when fields change (schema rebuild)
  useEffect(() => {
    if (!editingRecordId) {
      form.reset(defaultValues)
    }
  }, [fieldsKey])

  // Reset form when modal opens/closes or editing record changes
  useEffect(() => {
    if (open) {
      if (recordData) {
        // Populate form with existing record data
        // Include ALL current fields - not just those that have saved values
        const values: Record<string, string | boolean> = {}
        fields.forEach((field) => {
          const fieldValue = recordData.fieldValues?.find(
            (fv: { fieldId: string; value: string }) => fv.fieldId === field._id
          )
          if (field.fieldType === "checkbox") {
            // Use saved value if exists, otherwise use default or false
            values[field._id] = fieldValue
              ? fieldValue.value === "true"
              : (field.defaultValue === "true")
          } else {
            // Use saved value if exists, otherwise use default or empty string
            values[field._id] = fieldValue?.value ?? field.defaultValue ?? ""
          }
        })
        form.reset(values as FormValues)
      } else if (!editingRecordId) {
        form.reset(defaultValues)
      }
    }
  }, [open, recordData, editingRecordId, fields, form, defaultValues, fieldsKey])

  const handleSubmit = async (values: FormValues) => {
    try {
      // Check uniqueness for unique fields before submitting
      const uniqueFields = fields.filter((f) => f.isUnique)
      let hasUniqueError = false

      for (const field of uniqueFields) {
        const value = String(values[field._id] || "")
        if (!value || value.trim() === "") continue

        const result = await convex.query(
          api.billingGroupRecords.checkFieldUniqueness,
          {
            billingGroupId,
            fieldId: field._id,
            value,
            excludeRecordId: editingRecordId ?? undefined,
          }
        )

        if (!result.isUnique) {
          form.setError(field._id as any, {
            type: "manual",
            message: `This value already exists. "${field.name}" must be unique.`,
          })
          hasUniqueError = true
        }
      }

      if (hasUniqueError) return

      // Convert form values to fieldValues array
      const fieldValues = fields.map((field) => ({
        fieldId: field._id,
        value: field.fieldType === "checkbox"
          ? String(values[field._id])
          : String(values[field._id] || ""),
      }))

      if (isEditing && editingRecordId) {
        await updateRecord({
          id: editingRecordId,
          fieldValues,
        })
        toast({
          title: "Record updated",
          description: "The record has been updated successfully.",
        })
      } else {
        await createRecord({
          billingGroupId,
          fieldValues,
        })
        toast({
          title: "Record created",
          description: "A new record has been added to this billing group.",
        })
      }

      onClose()
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save record",
        variant: "destructive",
      })
    }
  }

  const renderField = (field: Field) => {
    switch (field.fieldType) {
      case "text":
        return (
          <FormField
            key={field._id}
            control={form.control}
            name={field._id}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>
                  {field.name}
                  {field.isRequired && <span className="text-destructive ml-1">*</span>}
                </FormLabel>
                <FormControl>
                  <Input
                    placeholder={field.placeholder || `Enter ${field.name.toLowerCase()}`}
                    {...formField}
                    value={formField.value as string}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )

      case "number":
        return (
          <FormField
            key={field._id}
            control={form.control}
            name={field._id}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>
                  {field.name}
                  {field.isRequired && <span className="text-destructive ml-1">*</span>}
                </FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    placeholder={field.placeholder || "0"}
                    {...formField}
                    value={formField.value as string}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )

      case "currency":
        return (
          <FormField
            key={field._id}
            control={form.control}
            name={field._id}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>
                  {field.name}
                  {field.isRequired && <span className="text-destructive ml-1">*</span>}
                </FormLabel>
                <FormControl>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                      ₱
                    </span>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder={field.placeholder || "0.00"}
                      className="pl-7"
                      {...formField}
                      value={formField.value as string}
                    />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )

      case "date":
        return (
          <FormField
            key={field._id}
            control={form.control}
            name={field._id}
            render={({ field: formField }) => (
              <FormItem className="flex flex-col">
                <FormLabel>
                  {field.name}
                  {field.isRequired && <span className="text-destructive ml-1">*</span>}
                </FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full pl-3 text-left font-normal",
                          !formField.value && "text-muted-foreground"
                        )}
                      >
                        {formField.value ? (
                          format(new Date(formField.value as string), "PPP")
                        ) : (
                          <span>{field.placeholder || "Pick a date"}</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={formField.value ? new Date(formField.value as string) : undefined}
                      onSelect={(date) =>
                        formField.onChange(date ? date.toISOString() : "")
                      }
                      autoFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
        )

      case "dropdown":
        return (
          <FormField
            key={field._id}
            control={form.control}
            name={field._id}
            render={({ field: formField }) => (
              <FormItem className="flex flex-col">
                <FormLabel>
                  {field.name}
                  {field.isRequired && <span className="text-destructive ml-1">*</span>}
                </FormLabel>
                <Popover
                  open={openDropdowns[field._id] || false}
                  onOpenChange={(open) => setOpenDropdowns(prev => ({ ...prev, [field._id]: open }))}
                >
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant="outline"
                        role="combobox"
                        className={cn(
                          "w-full justify-between overflow-hidden",
                          !formField.value && "text-muted-foreground"
                        )}
                      >
                        <span className="truncate">{String(formField.value) || field.placeholder || `Select ${field.name.toLowerCase()}`}</span>
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-full p-0" align="start">
                    <Command>
                      <CommandInput placeholder={`Search ${field.name.toLowerCase()}...`} />
                      <CommandList>
                        <CommandEmpty>No options found.</CommandEmpty>
                        <CommandGroup>
                          {field.options?.map((option) => (
                            <CommandItem
                              key={option}
                              value={option}
                              onSelect={() => {
                                formField.onChange(option)
                                setOpenDropdowns(prev => ({ ...prev, [field._id]: false }))
                              }}
                            >
                              <Check
                                className={cn(
                                  "mr-2 h-4 w-4",
                                  formField.value === option ? "opacity-100" : "opacity-0"
                                )}
                              />
                              {option}
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
        )

      case "checkbox":
        return (
          <FormField
            key={field._id}
            control={form.control}
            name={field._id}
            render={({ field: formField }) => (
              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                <div className="space-y-0.5">
                  <FormLabel>{field.name}</FormLabel>
                  {field.placeholder && (
                    <FormDescription className="text-xs">
                      {field.placeholder}
                    </FormDescription>
                  )}
                </div>
                <FormControl>
                  <Switch
                    checked={formField.value as boolean}
                    onCheckedChange={formField.onChange}
                  />
                </FormControl>
              </FormItem>
            )}
          />
        )

      default:
        return null
    }
  }

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-[500px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Record" : "Add Record"}</DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Update the record information below."
              : "Fill in the fields to create a new record."}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            {fields
              .sort((a, b) => a.sortOrder - b.sortOrder)
              .map((field) => renderField(field))}

            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting
                  ? "Saving..."
                  : isEditing
                    ? "Save Changes"
                    : "Add Record"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
