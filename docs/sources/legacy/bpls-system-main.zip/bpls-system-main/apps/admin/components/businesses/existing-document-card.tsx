"use client"

import { useState } from "react"
import { Download, Trash2, FileText, File, Image as ImageIcon } from "lucide-react"
import { useQuery, useMutation } from "convex/react"

import { Button } from "@repo/ui/components/button"
import { Badge } from "@repo/ui/components/badge"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@repo/ui/components/alert-dialog"
import { useToast } from "@/hooks/use-toast"
import { api } from "@repo/backend/convex/_generated/api"
import { cn } from "@/lib/utils"

import type { Id } from "@repo/backend/convex/_generated/dataModel"
import type { BusinessDocument } from "@/lib/types/business"

interface ExistingDocumentCardProps {
  businessId: string
  document: BusinessDocument
  onDelete?: () => void
  disabled?: boolean
}

/**
 * Display card for existing uploaded business documents
 *
 * Features:
 * - Shows document name, type, and upload date
 * - Download/view button with Convex storage URL
 * - Delete button with confirmation
 * - Status badge (pending/approved/rejected)
 * - Rejection reason display if rejected
 * - Color-coded by status (yellow/green/red)
 * - Matches Dropzone component styling
 */
export function ExistingDocumentCard({ businessId, document, onDelete, disabled = false }: ExistingDocumentCardProps) {
  const { toast } = useToast()
  const [isDeleting, setIsDeleting] = useState(false)

  // Get download URL for the document
  const documentUrl = useQuery(api.businesses.getDocumentUrl, {
    storageId: document.storageId as Id<"_storage">,
  })

  // Delete mutation
  const removeDocument = useMutation(api.businesses.removeDocument)

  const handleDownload = () => {
    if (!documentUrl) {
      toast({
        title: "Error",
        description: "Document URL not available",
        variant: "destructive",
      })
      return
    }

    // Open document in new tab
    window.open(documentUrl, "_blank")
  }

  const handleDelete = async () => {
    setIsDeleting(true)
    try {
      await removeDocument({
        businessId: businessId as Id<"businesses">,
        storageId: document.storageId as Id<"_storage">,
      })

      toast({
        title: "Success",
        description: "Document deleted successfully",
      })

      onDelete?.()
    } catch (error) {
      console.error("Error deleting document:", error)
      toast({
        title: "Error",
        description: "Failed to delete document. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  // Format upload date
  const uploadDate = new Date(document.uploadedAt).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })

  // Get file type icon based on filename
  const getFileIcon = () => {
    const fileName = document.fileName.toLowerCase()
    if (fileName.endsWith(".pdf")) {
      return FileText
    }
    if (fileName.match(/\.(png|jpg|jpeg|gif)$/)) {
      return ImageIcon
    }
    return File
  }

  const FileIconComponent = getFileIcon()

  // Status-based styling
  const status = document.status || "pending"

  const statusStyles = {
    pending: {
      container: "border-yellow-200 bg-yellow-50",
      icon: "text-yellow-600",
      iconBg: "bg-yellow-100",
      text: "text-yellow-900",
      textSecondary: "text-yellow-700",
      textMuted: "text-yellow-600",
      badge: "bg-yellow-100 text-yellow-800 border-yellow-300",
      downloadBtn: "border-yellow-300 text-yellow-700 hover:bg-yellow-100",
      deleteBtn: "border-red-300 text-red-700 hover:bg-red-50",
    },
    approved: {
      container: "border-green-200 bg-green-50",
      icon: "text-green-600",
      iconBg: "bg-green-100",
      text: "text-green-900",
      textSecondary: "text-green-700",
      textMuted: "text-green-600",
      badge: "bg-green-100 text-green-800 border-green-300",
      downloadBtn: "border-green-300 text-green-700 hover:bg-green-100",
      deleteBtn: "border-red-300 text-red-700 hover:bg-red-50",
    },
    rejected: {
      container: "border-red-200 bg-red-50",
      icon: "text-red-600",
      iconBg: "bg-red-100",
      text: "text-red-900",
      textSecondary: "text-red-700",
      textMuted: "text-red-600",
      badge: "bg-red-100 text-red-800 border-red-300",
      downloadBtn: "border-red-300 text-red-700 hover:bg-red-100",
      deleteBtn: "border-red-400 text-red-800 hover:bg-red-100",
    },
  }

  const styles = statusStyles[status]

  return (
    <div className="relative">
      {/* Main Container - matches Dropzone styling */}
      <div className={cn("relative rounded-lg border-2 p-4", styles.container)}>
        {/* Status Badge - Top Right */}
        <div className="absolute top-2 right-2">
          <Badge className={cn("border", styles.badge)}>
            {status === "pending" && "Pending Review"}
            {status === "approved" && "Approved"}
            {status === "rejected" && "Rejected"}
          </Badge>
        </div>

        {/* File Icon + Info */}
        <div className="flex items-start gap-3 pr-24">
          {/* Icon */}
          <div className={cn("flex-shrink-0 h-10 w-10 rounded flex items-center justify-center", styles.iconBg)}>
            <FileIconComponent className={cn("h-6 w-6", styles.icon)} />
          </div>

          {/* Document Details */}
          <div className="flex-1 min-w-0">
            {/* Document Type */}
            <p className={cn("text-sm font-medium", styles.text)}>
              {document.documentType}
            </p>

            {/* File Name */}
            <p className={cn("text-sm truncate mt-0.5", styles.textSecondary)}>
              {document.fileName}
            </p>

            {/* Upload Date */}
            <p className={cn("text-xs mt-1", styles.textMuted)}>
              Uploaded: {uploadDate}
            </p>
          </div>
        </div>

        {/* Rejection Reason (if rejected) */}
        {status === "rejected" && document.rejectionReason && (
          <div className="mt-3 p-2 bg-red-100 rounded-md border border-red-200">
            <p className="text-xs font-medium text-red-900 mb-1">Rejection Reason:</p>
            <p className="text-xs text-red-800">{document.rejectionReason}</p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-2 mt-3">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleDownload}
            disabled={!documentUrl}
            className={cn(styles.downloadBtn)}
          >
            <Download className="h-4 w-4 mr-1" />
            Download
          </Button>

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                type="button"
                variant="outline"
                size="sm"
                disabled={isDeleting || disabled}
                className={cn(styles.deleteBtn)}
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Delete
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Document</AlertDialogTitle>
                <AlertDialogDescription>
                  Are you sure you want to delete this document? This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
    </div>
  )
}
