"use client";

import { useState } from "react";
import { format, subHours, startOfDay, subDays, subMonths } from "date-fns";
import { CalendarIcon, ChevronDown } from "lucide-react";

import { Button } from "@repo/ui/components/button";
import { Badge } from "@repo/ui/components/badge";
import { Checkbox } from "@repo/ui/components/checkbox";
import { Label } from "@repo/ui/components/label";
import { Calendar } from "@repo/ui/components/calendar";
import { ScrollArea } from "@repo/ui/components/scroll-area";
import { Separator } from "@repo/ui/components/separator";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@repo/ui/components/popover";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@repo/ui/components/collapsible";
import { cn } from "@/lib/utils";

import type { ActivityFilters } from "@/app/dashboard/activity/activity-client";

// Action options with display labels
const ACTION_OPTIONS = [
  { value: "create", label: "Created" },
  { value: "update", label: "Updated" },
  { value: "delete", label: "Deleted" },
  { value: "restore", label: "Restored" },
  { value: "status_change", label: "Status Changed" },
  { value: "payment", label: "Payment Recorded" },
  { value: "verification", label: "Verified" },
  { value: "issued", label: "Issued" },
];

// Resource type options with display labels
const RESOURCE_TYPE_OPTIONS = [
  { value: "permit_application", label: "Permit Application" },
  { value: "payment", label: "Payment" },
  { value: "permit", label: "Permit" },
  { value: "business", label: "Business" },
  { value: "business_owner", label: "Business Owner" },
  { value: "clearance", label: "Clearance" },
  { value: "billing_group", label: "Billing Group" },
  { value: "billing_group_record", label: "Billing Record" },
  { value: "settings", label: "Settings" },
];

// Quick timeline presets (horizontal chips)
const QUICK_PRESETS = [
  { value: "hour", label: "Last hour" },
  { value: "today", label: "Today" },
  { value: "week", label: "7 days" },
];

interface ActivityFiltersSidebarProps {
  filters: ActivityFilters;
  onFiltersChange: (filters: ActivityFilters) => void;
  onClearFilters: () => void;
  facets: {
    actions: Record<string, number>;
    resourceTypes: Record<string, number>;
    performers: Array<{ id: string; name: string; count: number }>;
    totalCount: number;
  } | null;
  activeFilterCount: number;
}

export function ActivityFiltersSidebar({
  filters,
  onFiltersChange,
  onClearFilters,
  facets,
  activeFilterCount,
}: ActivityFiltersSidebarProps) {
  // Handle timeline preset change
  const handleTimelinePreset = (preset: typeof filters.timelinePreset) => {
    const now = new Date();
    let dateFrom: Date | undefined;
    let dateTo: Date | undefined;

    switch (preset) {
      case "hour":
        dateFrom = subHours(now, 1);
        dateTo = now;
        break;
      case "today":
        dateFrom = startOfDay(now);
        dateTo = now;
        break;
      case "week":
        dateFrom = subDays(now, 7);
        dateTo = now;
        break;
      case "month":
        dateFrom = subMonths(now, 1);
        dateTo = now;
        break;
      case "all":
      default:
        dateFrom = undefined;
        dateTo = undefined;
        break;
    }

    onFiltersChange({
      ...filters,
      timelinePreset: preset,
      dateFrom,
      dateTo,
    });
  };

  // Handle action checkbox change
  const handleActionChange = (action: string, checked: boolean) => {
    const newActions = checked
      ? [...filters.actions, action]
      : filters.actions.filter((a) => a !== action);
    onFiltersChange({ ...filters, actions: newActions });
  };

  // Handle resource type checkbox change
  const handleResourceTypeChange = (type: string, checked: boolean) => {
    const newTypes = checked
      ? [...filters.resourceTypes, type]
      : filters.resourceTypes.filter((t) => t !== type);
    onFiltersChange({ ...filters, resourceTypes: newTypes });
  };

  // Handle performer checkbox change
  const handlePerformerChange = (performerId: string, checked: boolean) => {
    const newPerformers = checked
      ? [...filters.performerIds, performerId]
      : filters.performerIds.filter((p) => p !== performerId);
    onFiltersChange({ ...filters, performerIds: newPerformers });
  };

  // Handle date from change
  const handleDateFromChange = (date: Date | undefined) => {
    onFiltersChange({
      ...filters,
      dateFrom: date,
      timelinePreset: "all", // Clear preset when manually selecting dates
    });
  };

  // Handle date to change
  const handleDateToChange = (date: Date | undefined) => {
    onFiltersChange({
      ...filters,
      dateTo: date,
      timelinePreset: "all", // Clear preset when manually selecting dates
    });
  };

  // Get action count from facets
  const getActionCount = (action: string) => {
    return facets?.actions[action] ?? 0;
  };

  // Get resource type count from facets
  const getResourceTypeCount = (type: string) => {
    return facets?.resourceTypes[type] ?? 0;
  };

  // Collapsible section states
  const [actionOpen, setActionOpen] = useState(true);
  const [typeOpen, setTypeOpen] = useState(true);
  const [performerOpen, setPerformerOpen] = useState(true);

  return (
    <div className="w-64 border-r bg-muted/10">
      <ScrollArea className="h-full">
        <div className="p-4 space-y-4">
          {/* Header */}
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">
              Filters
              {activeFilterCount > 0 && (
                <Badge variant="secondary" className="ml-2 text-xs">
                  {activeFilterCount}
                </Badge>
              )}
            </h3>
            {activeFilterCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onClearFilters}
                className="h-6 px-2 text-xs"
              >
                Clear
              </Button>
            )}
          </div>

          <Separator />

          {/* Timeline - Horizontal Chips */}
          <div className="space-y-2">
            <Label className="text-xs font-medium text-muted-foreground">
              Timeline
            </Label>
            <div className="flex flex-wrap gap-1">
              {QUICK_PRESETS.map((preset) => (
                <Button
                  key={preset.value}
                  variant={
                    filters.timelinePreset === preset.value ? "secondary" : "ghost"
                  }
                  size="sm"
                  className="h-7 text-xs px-2"
                  onClick={() =>
                    handleTimelinePreset(
                      preset.value as typeof filters.timelinePreset
                    )
                  }
                >
                  {preset.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Date Range - Compact */}
          <div className="space-y-2">
            <div className="grid grid-cols-2 gap-2">
              {/* From Date */}
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className={cn(
                      "w-full justify-start text-left font-normal h-8 text-xs",
                      !filters.dateFrom && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-1 h-3 w-3" />
                    {filters.dateFrom
                      ? format(filters.dateFrom, "MMM d")
                      : "From"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={filters.dateFrom}
                    onSelect={handleDateFromChange}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>

              {/* To Date */}
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className={cn(
                      "w-full justify-start text-left font-normal h-8 text-xs",
                      !filters.dateTo && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-1 h-3 w-3" />
                    {filters.dateTo
                      ? format(filters.dateTo, "MMM d")
                      : "To"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={filters.dateTo}
                    onSelect={handleDateToChange}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <Separator />

          {/* Action Filter - Collapsible */}
          <Collapsible open={actionOpen} onOpenChange={setActionOpen}>
            <CollapsibleTrigger className="flex items-center justify-between w-full py-1">
              <Label className="text-xs font-medium text-muted-foreground cursor-pointer">
                Action
              </Label>
              <ChevronDown
                className={cn(
                  "h-4 w-4 text-muted-foreground transition-transform",
                  actionOpen && "rotate-180"
                )}
              />
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-1 pt-2">
              {ACTION_OPTIONS.map((option) => {
                const count = getActionCount(option.value);
                return (
                  <div
                    key={option.value}
                    className="flex items-center justify-between"
                  >
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id={`action-${option.value}`}
                        checked={filters.actions.includes(option.value)}
                        onCheckedChange={(checked) =>
                          handleActionChange(option.value, checked as boolean)
                        }
                      />
                      <label
                        htmlFor={`action-${option.value}`}
                        className="text-sm cursor-pointer"
                      >
                        {option.label}
                      </label>
                    </div>
                    {count > 0 && (
                      <span className="text-xs text-muted-foreground">
                        {count}
                      </span>
                    )}
                  </div>
                );
              })}
            </CollapsibleContent>
          </Collapsible>

          <Separator />

          {/* Resource Type Filter - Collapsible */}
          <Collapsible open={typeOpen} onOpenChange={setTypeOpen}>
            <CollapsibleTrigger className="flex items-center justify-between w-full py-1">
              <Label className="text-xs font-medium text-muted-foreground cursor-pointer">
                Type
              </Label>
              <ChevronDown
                className={cn(
                  "h-4 w-4 text-muted-foreground transition-transform",
                  typeOpen && "rotate-180"
                )}
              />
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-1 pt-2">
              {RESOURCE_TYPE_OPTIONS.map((option) => {
                const count = getResourceTypeCount(option.value);
                return (
                  <div
                    key={option.value}
                    className="flex items-center justify-between"
                  >
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id={`type-${option.value}`}
                        checked={filters.resourceTypes.includes(option.value)}
                        onCheckedChange={(checked) =>
                          handleResourceTypeChange(
                            option.value,
                            checked as boolean
                          )
                        }
                      />
                      <label
                        htmlFor={`type-${option.value}`}
                        className="text-sm cursor-pointer"
                      >
                        {option.label}
                      </label>
                    </div>
                    {count > 0 && (
                      <span className="text-xs text-muted-foreground">
                        {count}
                      </span>
                    )}
                  </div>
                );
              })}
            </CollapsibleContent>
          </Collapsible>

          <Separator />

          {/* Performer Filter - Collapsible */}
          {facets && facets.performers.length > 0 && (
            <Collapsible open={performerOpen} onOpenChange={setPerformerOpen}>
              <CollapsibleTrigger className="flex items-center justify-between w-full py-1">
                <Label className="text-xs font-medium text-muted-foreground cursor-pointer">
                  Performer
                </Label>
                <ChevronDown
                  className={cn(
                    "h-4 w-4 text-muted-foreground transition-transform",
                    performerOpen && "rotate-180"
                  )}
                />
              </CollapsibleTrigger>
              <CollapsibleContent className="space-y-1 pt-2">
                {facets.performers.map((performer) => (
                  <div
                    key={performer.id}
                    className="flex items-center justify-between"
                  >
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id={`performer-${performer.id}`}
                        checked={filters.performerIds.includes(performer.id)}
                        onCheckedChange={(checked) =>
                          handlePerformerChange(performer.id, checked as boolean)
                        }
                      />
                      <label
                        htmlFor={`performer-${performer.id}`}
                        className="text-sm cursor-pointer truncate max-w-[120px]"
                        title={performer.name}
                      >
                        {performer.name}
                      </label>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {performer.count}
                    </span>
                  </div>
                ))}
              </CollapsibleContent>
            </Collapsible>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
