"use client";

import { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "convex/react";
import Webcam from "react-webcam";

import { api } from "@repo/backend/convex/_generated/api";
import { BusinessOwnerForm } from "@/components/permit/business-owner-form";
import { Button } from "@repo/ui/components/button";
import { useToast } from "@/hooks/use-toast";
import { businessOwnerFormSchema, businessOwnerFormDefaultValues } from "@/lib/schemas/business-owner-form";

import type { Doc, Id } from "@repo/backend/convex/_generated/dataModel";
import type { BusinessOwnerFormSchema } from "@/lib/schemas/business-owner-form";
import type { CameraMode } from "@/lib/types/common";
import type { UseFormReturn } from "react-hook-form";

interface BusinessOwnerFormWrapperProps {
  mode: "create" | "edit";
  initialData?: Doc<"business_owners">;
  onSuccess: () => void;
  onCancel: () => void;
}

export function BusinessOwnerFormWrapper({ mode, initialData, onSuccess, onCancel }: BusinessOwnerFormWrapperProps) {
  const { toast } = useToast();
  const createOwner = useMutation(api.businessOwners.create);
  const updateOwner = useMutation(api.businessOwners.update);

  const [profilePhotoPreview, setProfilePhotoPreview] = useState<string | null>(initialData?.avatar || null);
  const [cameraMode, setCameraMode] = useState<CameraMode>("upload");
  const cameraRef = useRef<Webcam>(null);

  const form = useForm<BusinessOwnerFormSchema>({
    resolver: zodResolver(businessOwnerFormSchema),
    defaultValues: initialData
      ? {
          firstName: initialData.firstName,
          middleName: initialData.middleName || "",
          lastName: initialData.lastName,
          birthDate: initialData.birthDate,
          civilStatus: initialData.civilStatus,
          gender: initialData.gender,
          citizenship: initialData.citizenship,
          tin: initialData.tin || "",
          mobile: initialData.mobile,
          email: initialData.email,
          address: initialData.address || "",
          provinceId: initialData.provinceId || "",
          cityId: initialData.cityId || "",
          barangayId: initialData.barangayId || "",
          avatar: initialData.avatar,
          ownerType: initialData.ownerType ?? "Single",
          groupName: initialData.groupName || "",
        }
      : businessOwnerFormDefaultValues,
    mode: "onChange",
  });

  const handleSubmit = async (values: BusinessOwnerFormSchema) => {
    console.log("values", values);
    console.log("mode", mode);
    try {
      if (mode === "create") {
        await createOwner({
          firstName: values.firstName,
          lastName: values.lastName,
          middleName: values.middleName || undefined,
          birthDate: values.birthDate,
          civilStatus: values.civilStatus,
          gender: values.gender,
          citizenship: values.citizenship,
          tin: values.tin || undefined, // Optional field
          mobile: values.mobile,
          email: values.email,
          address: values.address || undefined, // Optional field
          provinceId: values.provinceId as Id<"provinces">,
          cityId: values.cityId as Id<"cities">,
          barangayId: values.barangayId as Id<"barangays">,
          avatar: profilePhotoPreview || undefined,
          ownerType: values.ownerType,
          groupName: values.groupName || undefined,
        });

        toast({
          title: "Success",
          description: "Business owner created successfully",
        });
      } else {
        if (!initialData?._id) {
          throw new Error("Owner ID is required for update");
        }

        await updateOwner({
          id: initialData._id as Id<"business_owners">,
          firstName: values.firstName,
          lastName: values.lastName,
          middleName: values.middleName || undefined,
          birthDate: values.birthDate,
          civilStatus: values.civilStatus,
          gender: values.gender,
          citizenship: values.citizenship,
          tin: values.tin || undefined, // Optional field
          mobile: values.mobile,
          email: values.email,
          address: values.address || undefined, // Optional field
          provinceId: values.provinceId as Id<"provinces">,
          cityId: values.cityId as Id<"cities">,
          barangayId: values.barangayId as Id<"barangays">,
          avatar: profilePhotoPreview || undefined,
          ownerType: values.ownerType,
          groupName: values.groupName || undefined,
        });

        toast({
          title: "Success",
          description: "Business owner updated successfully",
        });
      }

      onSuccess();
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    }
  };

  const handlePhotoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTakePhoto = () => {
    if (cameraRef.current) {
      try {
        const photo = cameraRef.current.getScreenshot();
        if (photo) {
          setProfilePhotoPreview(photo);
          setCameraMode("upload");
        }
      } catch (error) {
        console.error("Error taking photo:", error);
        toast({
          title: "Camera Error",
          description: "Failed to capture photo. Please try again or use file upload.",
          variant: "destructive",
        });
      }
    }
  };

  return (
    <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
      <BusinessOwnerForm
        form={form}
        profilePhotoPreview={profilePhotoPreview}
        cameraMode={cameraMode}
        cameraRef={cameraRef}
        selectedOwnerId={initialData?._id}
        onBack={onCancel}
        onPhotoChange={handlePhotoChange}
        onCameraModeChange={setCameraMode}
        onTakePhoto={handleTakePhoto}
      />
      <div className="flex justify-end gap-2 pt-4 border-t">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button
          type="submit"
          disabled={form.formState.isSubmitting}
          onClick={() => console.log("form.getValues()", form.getValues())}
        >
          {form.formState.isSubmitting ? "Saving..." : mode === "create" ? "Create Owner" : "Update Owner"}
        </Button>
      </div>
    </form>
  );
}
