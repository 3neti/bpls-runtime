"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@repo/ui/components/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@repo/ui/components/table";
import { CheckCircle2, XCircle } from "lucide-react";
import { QuickApprovalModal } from "@/components/departments/quick-approval-modal";
import { getClearanceByDepartmentSlug } from "@/lib/data/clearances";
import type { DepartmentPermit } from "@/lib/types/department";
import type { ClearanceMultiFeeApprovalFormValues } from "@/components/departments/clearance-multi-fee-approval-form";

interface ReviewTableProps {
  /** Array of permits to display in the table */
  permits: DepartmentPermit[];
  /** Department route prefix (e.g., "sanitary", "bfp", "mpdc") */
  departmentRoute: string;
  /** Optional callback when a row is clicked */
  onRowClick?: (permitId: string) => void;
  /** Optional callback when approval is submitted */
  onApproveSubmit?: (permitId: string, values: ClearanceMultiFeeApprovalFormValues) => void;
  /** Optional callback when rejection is submitted */
  onRejectSubmit?: (permitId: string) => void;
}

/**
 * ReviewTable Component
 *
 * Displays a table of permits awaiting review for a department.
 * Features:
 * - Clickable rows that navigate to detail page
 * - Review button to view permit details
 * - Quick approve/reject actions via modal
 * - Mobile responsive with horizontal scrolling
 * - Empty state when no permits
 *
 * @example
 * ```tsx
 * <ReviewTable
 *   permits={permitList}
 *   departmentRoute="departments/sanitary"
 *   onApproveSubmit={(id, values) => console.log('Approved:', id, values)}
 *   onRejectSubmit={(id) => console.log('Rejected:', id)}
 * />
 * ```
 */
export function ReviewTable({
  permits,
  departmentRoute,
  onRowClick,
  onApproveSubmit,
  onRejectSubmit,
}: ReviewTableProps) {
  const router = useRouter();

  // Modal state
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedPermit, setSelectedPermit] = useState<DepartmentPermit | null>(null);
  const [modalMode, setModalMode] = useState<"approve" | "reject">("approve");

  // Extract department slug from route (e.g., "departments/sanitary" -> "sanitary")
  const departmentSlug = departmentRoute.split("/").pop() || "";
  const clearanceConfig = getClearanceByDepartmentSlug(departmentSlug);

  const handleRowClick = (permitId: string) => {
    if (onRowClick) {
      onRowClick(permitId);
    } else {
      router.push(`/${departmentRoute}/review/${permitId}`);
    }
  };

  const handleQuickApprove = (permit: DepartmentPermit, event: React.MouseEvent) => {
    event.stopPropagation();
    setSelectedPermit(permit);
    setModalMode("approve");
    setModalOpen(true);
  };

  const handleQuickReject = (permit: DepartmentPermit, event: React.MouseEvent) => {
    event.stopPropagation();
    setSelectedPermit(permit);
    setModalMode("reject");
    setModalOpen(true);
  };

  const handleCloseModal = () => {
    setModalOpen(false);
    setSelectedPermit(null);
  };

  if (!clearanceConfig) {
    return (
      <div className="rounded-lg border bg-card p-8 text-center">
        <p className="text-muted-foreground">Invalid department configuration</p>
      </div>
    );
  }

  return (
    <div className="rounded-lg border bg-card overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="min-w-[120px]">Owner Name</TableHead>
              <TableHead className="min-w-[150px]">Business Name</TableHead>
              <TableHead className="min-w-[120px]">Application Date</TableHead>
              <TableHead className="min-w-[100px]">Status</TableHead>
              <TableHead className="text-right min-w-[200px]">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {permits.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                  No pending reviews
                </TableCell>
              </TableRow>
            ) : (
              permits.map((permit) => (
                <TableRow
                  key={permit.id}
                  onClick={() => handleRowClick(permit.id)}
                  className="cursor-pointer hover:bg-muted/50 transition-colors"
                >
                  <TableCell className="font-medium">{permit.ownerName}</TableCell>
                  <TableCell>{permit.businessName}</TableCell>
                  <TableCell className="whitespace-nowrap">
                    {new Date(permit.submittedAt).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "short",
                      day: "numeric",
                    })}
                  </TableCell>
                  <TableCell>
                    <span className="inline-flex items-center rounded-full bg-yellow-100 px-2.5 py-0.5 text-xs font-medium text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400 whitespace-nowrap">
                      {permit.status}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={(e) => handleQuickApprove(permit, e)}
                        className="min-w-[90px] text-green-600 border-green-600 hover:bg-green-50"
                      >
                        <CheckCircle2 className="h-4 w-4 sm:mr-2" />
                        <span className="hidden sm:inline">Approve</span>
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={(e) => handleQuickReject(permit, e)}
                        className="min-w-[80px] text-red-600 border-red-600 hover:bg-red-50"
                      >
                        <XCircle className="h-4 w-4 sm:mr-2" />
                        <span className="hidden sm:inline">Reject</span>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Quick Approval/Rejection Modal */}
      <QuickApprovalModal
        open={modalOpen}
        onClose={handleCloseModal}
        permit={selectedPermit}
        clearanceConfig={clearanceConfig}
        mode={modalMode}
        onApproveSubmit={onApproveSubmit}
        onRejectSubmit={onRejectSubmit}
      />
    </div>
  );
}
