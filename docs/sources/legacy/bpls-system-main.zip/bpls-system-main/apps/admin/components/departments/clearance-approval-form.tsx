/**
 * Clearance Approval Form Component
 *
 * Form for department staff to approve clearances with:
 * - Fee input with currency formatting
 * - Optional remarks textarea
 * - Approve and Reject actions
 * - Validation and error handling
 */

"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@repo/ui/components/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@repo/ui/components/form";
import { Input } from "@repo/ui/components/input";
import { Textarea } from "@repo/ui/components/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import { CheckCircle, XCircle, DollarSign } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/utils/formatting";
import type { ClearanceApprovalFormValues } from "@/lib/types/clearance";

/**
 * Zod schema for clearance approval form validation
 */
const clearanceApprovalSchema = z.object({
  fee: z.coerce
    .number({
      message: "Fee must be a valid number",
    })
    .min(0, "Fee must be a positive number")
    .max(1000000, "Fee cannot exceed ₱1,000,000"),
  remarks: z.string().max(500, "Remarks cannot exceed 500 characters").default(""),
});

type ClearanceApprovalSchema = z.infer<typeof clearanceApprovalSchema>;

interface ClearanceApprovalFormProps {
  /** Department name for display */
  departmentName: string;
  /** Certificate/clearance name */
  certificateName: string;
  /** Application number being reviewed */
  applicationNumber: string;
  /** Callback when clearance is approved */
  onApprove: (values: ClearanceApprovalFormValues) => void;
  /** Optional: Callback when clearance is rejected */
  onReject?: () => void;
}


export function ClearanceApprovalForm({
  departmentName,
  certificateName,
  applicationNumber,
  onApprove,
  onReject,
}: ClearanceApprovalFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<ClearanceApprovalSchema>({
    resolver: zodResolver(clearanceApprovalSchema) as any,
    defaultValues: {
      fee: 0,
      remarks: "",
    },
    mode: "onChange",
  });

  const feeValue = form.watch("fee");

  const handleApprove = async (values: ClearanceApprovalSchema) => {
    setIsSubmitting(true);
    try {
      await onApprove({
        fee: values.fee,
        remarks: values.remarks || "",
      });

      toast({
        title: "Clearance Approved",
        description: `${certificateName} has been approved for application ${applicationNumber}.`,
        variant: "default",
      });

      form.reset();
    } catch (error) {
      toast({
        title: "Approval Failed",
        description: error instanceof Error ? error.message : "Failed to approve clearance",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReject = () => {
    if (onReject) {
      onReject();
      toast({
        title: "Clearance Rejected",
        description: `${certificateName} has been rejected for application ${applicationNumber}.`,
        variant: "destructive",
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Approve Clearance</CardTitle>
        <CardDescription>
          Review and approve the {certificateName} for {departmentName}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleApprove as any)} className="space-y-4">
            {/* Fee Input */}
            <FormField
              control={form.control as any}
              name="fee"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4" />
                    Fee Amount
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₱</span>
                      <Input type="number" placeholder="0.00" className="pl-7" step="0.01" min="0" {...field} />
                    </div>
                  </FormControl>
                  <FormDescription>
                    {feeValue > 0 && <span className="text-sm font-medium">{formatCurrency(feeValue, { withSymbol: true })}</span>}
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Remarks */}
            <FormField
              control={form.control as any}
              name="remarks"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Remarks </FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Add any notes or requirements for this clearance..."
                      className="min-h-[80px] resize-none"
                      maxLength={500}
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>{field.value?.length || 0} / 500 characters</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Action Buttons - Styled like PermitApplicationHeader */}
            <div className="flex gap-2 pt-2">
              <Button
                type="submit"
                variant="outline"
                className="flex-1 text-green-600 border-green-600 hover:bg-green-50"
                disabled={isSubmitting || !form.formState.isValid}
              >
                <CheckCircle className="mr-2 h-4 w-4" />
                {isSubmitting ? "Approving..." : "Approve"}
              </Button>

              {onReject && (
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1 text-red-600 border-red-600 hover:bg-red-50"
                  onClick={handleReject}
                  disabled={isSubmitting}
                >
                  <XCircle className="mr-2 h-4 w-4" />
                  Reject
                </Button>
              )}
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
