"use client"

import { useEffect } from "react"
import { useMutation } from "convex/react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form"
import { Textarea } from "@repo/ui/components/textarea"
import { Button } from "@repo/ui/components/button"
import { Badge } from "@repo/ui/components/badge"
import { useToast } from "@/hooks/use-toast"

import { api } from "@repo/backend/convex/_generated/api"

const formSchema = z.object({
  description: z.string().max(500, "Description cannot exceed 500 characters"),
})

type FormValues = z.infer<typeof formSchema>

interface EditDescriptionModalProps {
  open: boolean
  onClose: () => void
  transaction: {
    _id: string
    transactionNumber: string
    description?: string
    source: "permitPayment" | "billingGroup" | "manual"
  } | null
}

export function EditDescriptionModal({ open, onClose, transaction }: EditDescriptionModalProps) {
  const { toast } = useToast()
  const updateDescription = useMutation(api.payments.updateTransactionDescription)

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      description: "",
    },
  })

  // Reset form when transaction changes
  useEffect(() => {
    if (transaction) {
      form.reset({
        description: transaction.description || "",
      })
    }
  }, [transaction, form])

  const handleClose = () => {
    form.reset()
    onClose()
  }

  const handleSubmit = async (values: FormValues) => {
    if (!transaction) return

    // Billing group records can't be edited here - they use field mapping
    if (transaction.source === "billingGroup") {
      toast({
        title: "Cannot edit",
        description: "Billing group record descriptions are managed through field mappings.",
        variant: "destructive",
      })
      return
    }

    try {
      await updateDescription({
        transactionId: transaction._id,
        source: transaction.source,
        description: values.description,
      })

      toast({
        title: "Description updated",
        description: `Transaction ${transaction.transactionNumber} has been updated.`,
      })

      handleClose()
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update description",
        variant: "destructive",
      })
    }
  }

  const isEditable = transaction?.source !== "billingGroup"

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && handleClose()}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Edit Description</DialogTitle>
          <DialogDescription>
            {transaction && (
              <span className="flex items-center gap-2 mt-1">
                <span className="font-mono text-sm">{transaction.transactionNumber}</span>
                <Badge variant="outline" className="text-xs">
                  {transaction.source === "permitPayment" && "Permit Payment"}
                  {transaction.source === "billingGroup" && "Billing Group"}
                  {transaction.source === "manual" && "Manual"}
                </Badge>
              </span>
            )}
          </DialogDescription>
        </DialogHeader>

        {!isEditable ? (
          <div className="py-4">
            <p className="text-sm text-muted-foreground">
              Billing group record descriptions are managed through the billing group's field
              configuration. To edit this description, go to the billing group and update the
              record's description field.
            </p>
            <DialogFooter className="mt-4">
              <Button variant="outline" onClick={handleClose}>
                Close
              </Button>
            </DialogFooter>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Enter a description for this transaction..."
                        className="min-h-[100px] resize-none"
                        maxLength={500}
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      {field.value?.length || 0} / 500 characters
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button type="button" variant="outline" onClick={handleClose}>
                  Cancel
                </Button>
                <Button type="submit" disabled={form.formState.isSubmitting}>
                  {form.formState.isSubmitting ? "Saving..." : "Save Changes"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  )
}
