/**
 * Clearance Multi-Fee Approval Form Component
 *
 * Enhanced form for department staff to approve clearances with:
 * - Multiple fees from department fee library
 * - Fee amount overrides with reasons
 * - Add/remove fees dynamically
 * - Real-time total calculation
 * - Validation and error handling
 */

"use client";

import { useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Link from "next/link";
import { Button } from "@repo/ui/components/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@repo/ui/components/form";
import { Input } from "@repo/ui/components/input";
import { Textarea } from "@repo/ui/components/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@repo/ui/components/tooltip";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import { CheckCircle, XCircle, Plus, Trash2, DollarSign, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/utils/formatting";
import type { DepartmentFee, AppliedFee } from "@/lib/types/fees";

/**
 * Zod schema for multi-fee clearance approval
 */
const appliedFeeSchema = z.object({
  feeId: z.string().min(1, "Please select a fee"),
  feeName: z.string().min(1),
  defaultAmount: z.number(),
  appliedAmount: z.coerce
    .number({
      message: "Amount must be a valid number",
    })
    .min(0, "Amount must be positive")
    .max(1000000, "Amount cannot exceed ₱1,000,000"),
  overrideReason: z.string().max(200, "Reason cannot exceed 200 characters").optional(),
});

const clearanceMultiFeeApprovalSchema = z.object({
  fees: z.array(appliedFeeSchema).min(1, "At least one fee must be added").max(10, "Maximum 10 fees allowed"),
  remarks: z.string().max(500, "Remarks cannot exceed 500 characters").default(""),
});

type ClearanceMultiFeeApprovalSchema = z.infer<typeof clearanceMultiFeeApprovalSchema>;

export interface ClearanceMultiFeeApprovalFormValues {
  fees: AppliedFee[];
  remarks: string;
  totalAmount: number;
}

interface ClearanceMultiFeeApprovalFormProps {
  /** Department name for display */
  departmentName: string;
  /** Certificate/clearance name */
  certificateName: string;
  /** Application number being reviewed */
  applicationNumber: string;
  /** Available fees from department library */
  availableFees: DepartmentFee[];
  /** Callback when clearance is approved */
  onApprove: (values: ClearanceMultiFeeApprovalFormValues) => void;
  /** Optional: Callback when clearance is rejected */
  onReject?: () => void;
  /** Optional: URL to fee library page */
  feeLibraryUrl?: string;
}


export function ClearanceMultiFeeApprovalForm({
  departmentName,
  certificateName,
  applicationNumber,
  availableFees,
  onApprove,
  onReject,
  feeLibraryUrl,
}: ClearanceMultiFeeApprovalFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<ClearanceMultiFeeApprovalSchema>({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    resolver: zodResolver(clearanceMultiFeeApprovalSchema) as any,
    defaultValues: {
      fees: [],
      remarks: "",
    },
    mode: "onChange",
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "fees",
  });

  const watchedFees = form.watch("fees");
  const totalAmount = watchedFees.reduce((sum, fee) => sum + (Number(fee.appliedAmount) || 0), 0);

  // Get fees that haven't been added yet
  // Filter to only show active fees - inactive fees should not be selectable
  const getAvailableFeesForSelection = () => {
    const selectedFeeIds = watchedFees.map((f) => f.feeId);
    return availableFees.filter((fee) => fee.isActive && !selectedFeeIds.includes(fee.id));
  };

  const handleAddFee = () => {
    const available = getAvailableFeesForSelection();
    if (available.length === 0) {
      toast({
        title: "No fees available",
        description: "All available fees have been added",
        variant: "default",
      });
      return;
    }

    // Add first available fee as default
    const firstFee = available[0];
    append({
      feeId: firstFee.id,
      feeName: firstFee.name,
      defaultAmount: firstFee.defaultAmount,
      appliedAmount: firstFee.defaultAmount,
      overrideReason: "",
    });
  };

  const handleFeeSelect = (index: number, feeId: string) => {
    const selectedFee = availableFees.find((f) => f.id === feeId);
    if (selectedFee) {
      form.setValue(`fees.${index}.feeId`, selectedFee.id);
      form.setValue(`fees.${index}.feeName`, selectedFee.name);
      form.setValue(`fees.${index}.defaultAmount`, selectedFee.defaultAmount);
      form.setValue(`fees.${index}.appliedAmount`, selectedFee.defaultAmount);
    }
  };

  const handleApprove = async (values: ClearanceMultiFeeApprovalSchema) => {
    setIsSubmitting(true);
    try {
      onApprove({
        fees: values.fees as AppliedFee[],
        remarks: values.remarks || "",
        totalAmount,
      });

      toast({
        title: "Clearance Approved",
        description: `${certificateName} has been approved for application ${applicationNumber}.`,
        variant: "default",
      });

      form.reset();
    } catch (error) {
      toast({
        title: "Approval Failed",
        description: error instanceof Error ? error.message : "Failed to approve clearance",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReject = () => {
    if (onReject) {
      onReject();
      toast({
        title: "Clearance Rejected",
        description: `${certificateName} has been rejected for application ${applicationNumber}.`,
        variant: "destructive",
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-3">
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5" />
            Approve Clearance
          </CardTitle>
          {feeLibraryUrl && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href={feeLibraryUrl}>
                    <Button variant="ghost" size="icon" className="h-7 w-7">
                      <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      <span className="sr-only">View Fee Library</span>
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>View all available fees for this department</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </div>
        <CardDescription>
          Review and approve the {certificateName} for {departmentName}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleApprove)} className="space-y-6">
            {/* Fees Section */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <FormLabel>Fees to Apply</FormLabel>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleAddFee}
                  disabled={getAvailableFeesForSelection().length === 0}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Fee
                </Button>
              </div>

              {fields.length === 0 ? (
                <div className="border-2 border-dashed rounded-lg p-8 text-center">
                  <DollarSign className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">No fees added yet. Click "Add Fee" to start.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {fields.map((field, index) => {
                    const currentFee = watchedFees[index];
                    const isOverridden =
                      currentFee && Number(currentFee.appliedAmount) !== Number(currentFee.defaultAmount);

                    return (
                      <Card key={field.id} className="p-4 relative">
                        {/* Delete Button - Top Right Corner */}
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 absolute top-3 right-3 hover:bg-destructive/10"
                          onClick={() => remove(index)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>

                        <div className="space-y-4 pr-8">
                          {/* Fee Selection */}
                          <FormField
                            control={form.control}
                            name={`fees.${index}.feeId`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Fee</FormLabel>
                                <Select onValueChange={(value) => handleFeeSelect(index, value)} value={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select a fee" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    {/* Current selected fee */}
                                    {currentFee && (
                                      <SelectItem key={currentFee.feeId} value={currentFee.feeId}>
                                        {currentFee.feeName}
                                      </SelectItem>
                                    )}
                                    {/* Available fees */}
                                    {getAvailableFeesForSelection().map((fee) => (
                                      <SelectItem key={fee.id} value={fee.id}>
                                        {fee.name}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          {/* Amount Input */}
                          <FormField
                            control={form.control}
                            name={`fees.${index}.appliedAmount`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Amount</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                                      ₱
                                    </span>
                                    <Input
                                      type="number"
                                      placeholder="0.00"
                                      className="pl-7"
                                      step="0.01"
                                      min="0"
                                      {...field}
                                    />
                                  </div>
                                </FormControl>
                                <FormDescription>
                                  {isOverridden && (
                                    <span className="text-amber-600 font-medium">
                                      Overridden from default: {formatCurrency(currentFee.defaultAmount, { withSymbol: true })}
                                    </span>
                                  )}
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          {/* Override Reason (shown only when overridden) */}
                          {isOverridden && (
                            <FormField
                              control={form.control}
                              name={`fees.${index}.overrideReason`}
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Override Reason </FormLabel>
                                  <FormControl>
                                    <Input placeholder="Why was the amount changed?" maxLength={200} {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          )}
                        </div>
                      </Card>
                    );
                  })}
                </div>
              )}

              {form.formState.errors.fees?.root && (
                <p className="text-sm text-destructive">{form.formState.errors.fees.root.message}</p>
              )}
            </div>

            {/* Total Amount */}
            {fields.length > 0 && (
              <Card className="bg-muted/30">
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Total Amount:</span>
                    <span className="text-2xl font-bold text-primary">{formatCurrency(totalAmount, { withSymbol: true })}</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {fields.length} {fields.length === 1 ? "fee" : "fees"} applied
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Remarks */}
            <FormField
              control={form.control}
              name="remarks"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Remarks </FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Add any notes or requirements for this clearance..."
                      className="min-h-[80px] resize-none"
                      maxLength={500}
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>{field.value?.length || 0} / 500 characters</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Action Buttons */}
            <div className="flex gap-2 pt-2">
              <Button
                type="submit"
                variant="outline"
                className="flex-1 text-green-600 border-green-600 hover:bg-green-50"
                disabled={isSubmitting || !form.formState.isValid || fields.length === 0}
              >
                <CheckCircle className="mr-2 h-4 w-4" />
                {isSubmitting ? "Approving..." : "Approve"}
              </Button>

              {onReject && (
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1 text-red-600 border-red-600 hover:bg-red-50"
                  onClick={handleReject}
                  disabled={isSubmitting}
                >
                  <XCircle className="mr-2 h-4 w-4" />
                  Reject
                </Button>
              )}
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
