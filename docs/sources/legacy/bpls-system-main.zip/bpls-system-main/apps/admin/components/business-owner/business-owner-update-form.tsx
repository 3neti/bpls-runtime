"use client";

import { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "convex/react";
import { format } from "date-fns";
import Webcam from "react-webcam";
import { Loader2, Calendar as CalendarIcon } from "lucide-react";

import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select";
import { Calendar } from "@repo/ui/components/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@repo/ui/components/popover";
import { useToast } from "@/hooks/use-toast";
import { useLocationSelects } from "@/hooks/use-location-selects";
import { ProfilePhotoUpload } from "@/components/permit/profile-photo-upload";
import { businessOwnerUpdateSchema, type BusinessOwnerUpdateSchema } from "@/lib/schemas/business-owner-update";
import { api } from "@repo/backend/convex/_generated/api";
import { cn } from "@/lib/utils";

import type { Id } from "@repo/backend/convex/_generated/dataModel";
import type { BusinessOwner } from "@/lib/types/business-owners";
import type { CameraMode } from "@/lib/types/common";

interface BusinessOwnerUpdateFormProps {
  businessOwner: BusinessOwner;
  onSuccess?: () => void;
  disabled?: boolean;
}

export function BusinessOwnerUpdateForm({ businessOwner, onSuccess, disabled = false }: BusinessOwnerUpdateFormProps) {
  const [profilePhotoPreview, setProfilePhotoPreview] = useState<string | null>(businessOwner.avatar || null);
  const [cameraMode, setCameraMode] = useState<CameraMode>("upload");
  const cameraRef = useRef<Webcam>(null);
  const { toast } = useToast();

  const updateOwner = useMutation(api.businessOwners.update);
  const generateUploadUrl = useMutation(api.businessOwners.generateUploadUrl);
  const saveAvatar = useMutation(api.businessOwners.saveAvatar);

  const form = useForm<BusinessOwnerUpdateSchema>({
    resolver: zodResolver(businessOwnerUpdateSchema),
    defaultValues: {
      id: businessOwner.id,
      firstName: businessOwner.firstName,
      middleName: businessOwner.middleName || "",
      lastName: businessOwner.lastName,
      birthDate: businessOwner.birthDate,
      civilStatus: businessOwner.civilStatus,
      gender: businessOwner.gender,
      citizenship: businessOwner.citizenship,
      tin: businessOwner.tin || "",
      mobile: businessOwner.mobile,
      email: businessOwner.email,
      address: businessOwner.address || "",
      provinceId: businessOwner.provinceId || "",
      cityId: businessOwner.cityId || "",
      barangayId: businessOwner.barangayId || "",
      avatar: businessOwner.avatar || "",
      profilePhoto: null,
    },
    mode: "onChange",
  });

  // Use the reusable location selects hook
  const {
    provinces,
    cities,
    barangays,
    handleProvinceChange,
    handleCityChange,
    isCityDisabled,
    isBarangayDisabled,
  } = useLocationSelects({
    initialProvinceId: businessOwner.provinceId || "",
    initialCityId: businessOwner.cityId || "",
    onProvinceChange: (id) => form.setValue("provinceId", id),
    onCityChange: (id) => form.setValue("cityId", id),
    onBarangayChange: (id) => form.setValue("barangayId", id),
  });

  const handleProfilePhotoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      form.setValue("profilePhoto", file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfilePhotoPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTakePhoto = () => {
    if (cameraRef.current) {
      try {
        const photo = cameraRef.current.getScreenshot();
        if (photo) {
          setProfilePhotoPreview(photo);
          fetch(photo)
            .then((res) => res.blob())
            .then((blob) => {
              const file = new File([blob], "camera-photo.jpg", { type: "image/jpeg" });
              form.setValue("profilePhoto", file);
            });
          setCameraMode("upload");
        }
      } catch (error) {
        console.error("Error taking photo:", error);
        toast({
          title: "Camera Error",
          description: "Failed to capture photo. Please try again or use file upload.",
          variant: "destructive",
        });
      }
    }
  };

  const onSubmit = form.handleSubmit(async (data) => {
    if (disabled) {
      toast({
        title: "Error",
        description: "You don't have permission to modify business owners",
        variant: "destructive",
      })
      return
    }

    try {
      let avatarUrl = data.avatar; // existing avatar

      // If new photo was uploaded or taken
      if (data.profilePhoto) {
        // Step 1: Generate upload URL
        const uploadUrl = await generateUploadUrl();

        // Step 2: Upload file to Convex storage
        const uploadResult = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": data.profilePhoto.type },
          body: data.profilePhoto,
        });

        const { storageId } = await uploadResult.json();

        // Step 3: Save avatar to business owner and get public URL
        avatarUrl = await saveAvatar({
          ownerId: data.id as Id<"business_owners">,
          storageId: storageId as Id<"_storage">,
        });

        // Update preview with new avatar URL
        setProfilePhotoPreview(avatarUrl ?? null);
      }

      // Update business owner with all fields including avatar
      await updateOwner({
        id: data.id as Id<"business_owners">,
        firstName: data.firstName,
        middleName: data.middleName,
        lastName: data.lastName,
        birthDate: data.birthDate,
        civilStatus: data.civilStatus,
        gender: data.gender,
        citizenship: data.citizenship,
        tin: data.tin || undefined, // Optional field
        mobile: data.mobile,
        email: data.email,
        address: data.address || undefined, // Optional field
        provinceId: data.provinceId as Id<"provinces">,
        cityId: data.cityId as Id<"cities">,
        barangayId: data.barangayId as Id<"barangays">,
        avatar: avatarUrl,
      });

      toast({
        title: "Success",
        description: "Business owner information updated successfully",
      });

      onSuccess?.();
    } catch (error) {
      console.error("Error updating business owner:", error);
      toast({
        title: "Error",
        description: "Failed to update business owner information. Please try again.",
        variant: "destructive",
      });
    }
  });

  const formValues = form.watch();
  const isSubmitting = form.formState.isSubmitting;

  return (
    <form onSubmit={onSubmit} className="space-y-8">
      {/* Personal Information Section */}
      <div className="space-y-4">
        <div className="border-b pb-2">
          <h4 className="text-md font-medium text-primary">Personal Information</h4>
        </div>

        <ProfilePhotoUpload
          profilePhotoPreview={profilePhotoPreview}
          cameraMode={cameraMode}
          isDisabled={disabled}
          onPhotoChange={handleProfilePhotoChange}
          onCameraModeChange={setCameraMode}
          onTakePhoto={handleTakePhoto}
          cameraRef={cameraRef}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="firstName">First Name <span className="text-destructive">*</span></Label>
            <Input id="firstName" {...form.register("firstName")} placeholder="Juan" disabled={disabled || isSubmitting} />
            {form.formState.errors.firstName && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.firstName.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="middleName">Middle Name</Label>
            <Input id="middleName" {...form.register("middleName")} placeholder="Dela" disabled={disabled || isSubmitting} />
          </div>

          <div>
            <Label htmlFor="lastName">Last Name <span className="text-destructive">*</span></Label>
            <Input id="lastName" {...form.register("lastName")} placeholder="Cruz" disabled={disabled || isSubmitting} />
            {form.formState.errors.lastName && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.lastName.message}</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <Label htmlFor="birthDate">Birth Date <span className="text-destructive">*</span></Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !formValues.birthDate && "text-muted-foreground"
                  )}
                  disabled={disabled || isSubmitting}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {formValues.birthDate ? format(new Date(formValues.birthDate), "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={formValues.birthDate ? new Date(formValues.birthDate) : undefined}
                  onSelect={(date) => {
                    if (date) {
                      form.setValue("birthDate", format(date, "yyyy-MM-dd"));
                    }
                  }}
                  disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
                />
              </PopoverContent>
            </Popover>
            {form.formState.errors.birthDate && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.birthDate.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="civilStatus">Civil Status <span className="text-destructive">*</span></Label>
            <Select value={formValues.civilStatus} onValueChange={(value) => form.setValue("civilStatus", value)} disabled={disabled || isSubmitting}>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="single">Single</SelectItem>
                <SelectItem value="married">Married</SelectItem>
                <SelectItem value="divorced">Divorced</SelectItem>
                <SelectItem value="widowed">Widowed</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.civilStatus && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.civilStatus.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="gender">Gender <span className="text-destructive">*</span></Label>
            <Select value={formValues.gender} onValueChange={(value) => form.setValue("gender", value)} disabled={disabled || isSubmitting}>
              <SelectTrigger>
                <SelectValue placeholder="Select gender" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="female">Female</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.gender && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.gender.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="citizenship">Citizenship <span className="text-destructive">*</span></Label>
            <Select value={formValues.citizenship} onValueChange={(value) => form.setValue("citizenship", value)} disabled={disabled || isSubmitting}>
              <SelectTrigger>
                <SelectValue placeholder="Select citizenship" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="filipino">Filipino</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.citizenship && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.citizenship.message}</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-1 gap-4">
          <div>
            <Label htmlFor="tin">TIN (Tax Identification Number)</Label>
            <Input id="tin" placeholder="000-000-000-000" {...form.register("tin")} disabled={disabled || isSubmitting} />
            {form.formState.errors.tin && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.tin.message}</p>
            )}
          </div>
        </div>
      </div>

      {/* Contact Information Section */}
      <div className="space-y-4">
        <div className="border-b pb-2">
          <h4 className="text-md font-medium text-primary">Contact Information</h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="mobile">Mobile Number <span className="text-destructive">*</span></Label>
            <Input id="mobile" placeholder="+63 912 345 6789" {...form.register("mobile")} disabled={disabled || isSubmitting} />
            {form.formState.errors.mobile && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.mobile.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="email">Email Address <span className="text-destructive">*</span></Label>
            <Input id="email" type="email" placeholder="juan@example.com" {...form.register("email")} disabled={disabled || isSubmitting} />
            {form.formState.errors.email && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.email.message}</p>
            )}
          </div>
        </div>
      </div>

      {/* Address Information Section */}
      <div className="space-y-4">
        <div className="border-b pb-2">
          <h4 className="text-md font-medium text-primary">Address Information</h4>
        </div>

        <div>
          <Label htmlFor="address">Street Address</Label>
          <Input id="address" placeholder="House No., Street Name, Building Name" {...form.register("address")} disabled={disabled || isSubmitting} />
          {form.formState.errors.address && (
            <p className="text-sm text-red-600 mt-1">{form.formState.errors.address.message}</p>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="provinceId">
              Province <span className="text-destructive">*</span>
            </Label>
            <Select value={formValues.provinceId} onValueChange={handleProvinceChange} disabled={disabled || isSubmitting}>
              <SelectTrigger>
                <SelectValue placeholder="Select province" />
              </SelectTrigger>
              <SelectContent>
                {provinces?.map((province: { _id: string; name: string }) => (
                  <SelectItem key={province._id} value={province._id}>
                    {province.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.provinceId && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.provinceId.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="cityId">
              City/Municipality <span className="text-destructive">*</span>
            </Label>
            <Select
              value={formValues.cityId}
              onValueChange={handleCityChange}
              disabled={disabled || isSubmitting || isCityDisabled}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select city/municipality" />
              </SelectTrigger>
              <SelectContent>
                {cities?.map((city: { _id: string; name: string }) => (
                  <SelectItem key={city._id} value={city._id}>
                    {city.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.cityId && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.cityId.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="barangayId">
              Barangay <span className="text-destructive">*</span>
            </Label>
            <Select
              value={formValues.barangayId}
              onValueChange={(value) => form.setValue("barangayId", value)}
              disabled={disabled || isSubmitting || isBarangayDisabled}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select barangay" />
              </SelectTrigger>
              <SelectContent>
                {barangays?.map((barangay: { _id: string; name: string }) => (
                  <SelectItem key={barangay._id} value={barangay._id}>
                    {barangay.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.barangayId && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.barangayId.message}</p>
            )}
          </div>
        </div>
      </div>

      {/* Submit Button */}
      <div className="flex justify-end pt-6 border-t">
        <Button type="submit" disabled={disabled || isSubmitting}>
          {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {isSubmitting ? "Updating..." : "Update"}
        </Button>
      </div>
    </form>
  );
}
