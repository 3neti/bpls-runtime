"use client";

import { Document, Page, Text, View, StyleSheet } from "@react-pdf/renderer";
import {
  parseTemplate,
  formatCurrency,
  type ReceiptMacroData,
  type PaymentReceiptFee,
} from "@/lib/utils/receipt-template-renderer";

// Paper sizes in points (1 point = 1/72 inch)
const PAPER_SIZES = {
  A4: { width: 595.28, height: 841.89 },
  Letter: { width: 612, height: 792 },
  "Half-Letter": { width: 396, height: 612 },
};

// Fixed table configuration for consistent receipt formatting
const TABLE_FIXED_ROWS = 11;
const ROW_HEIGHT = 11; // points (fontSize 10 + marginBottom 1)

// Convert mm to points (1mm = 2.83465 points)
const mmToPoints = (mm: number) => mm * 2.83465;

/**
 * Truncate text to max characters with ellipsis
 * Ensures text fits in single line within fixed-width table cells
 */
const truncateText = (text: string, maxChars: number): string => {
  if (!text || text.length <= maxChars) return text;
  return text.substring(0, maxChars - 3) + "...";
};

// Layout type from Convex
interface ReceiptLayout {
  _id: string;
  name: string;
  paperSize: "A4" | "Letter" | "Half-Letter";
  orientation: "portrait" | "landscape";
  marginTop: number;
  marginRight: number;
  marginBottom: number;
  marginLeft: number;
  headerTemplate: string;
  bodyTemplate: string;
  footerTemplate: string;
  hideZeroAmountFees?: boolean;
  fontSize: number;
  fontFamily: "Helvetica" | "Times-Roman" | "Courier";
}

// Extended receipt data that includes system fields
interface TemplateReceiptData extends ReceiptMacroData {
  receiptNumber: string;
  transactionNumber: string;
  date: string;
  amount: number;
  paymentMethod: string;
  referenceNumber?: string;
  periodLabel: string;
  dueDate: string;
  fees: PaymentReceiptFee[];
  totalAmount: number;
  surcharge?: number;
  penalty?: number;
  applicationNumber: string;
  businessName?: string;
  businessOwnerName?: string;
  printDate: string;
  municipalityName?: string;
  provinceName?: string;
  mayorName?: string;
  treasurerName?: string;
}

interface TemplateBasedReceiptDocumentProps {
  layout: ReceiptLayout;
  data: TemplateReceiptData;
}

export function TemplateBasedReceiptDocument({
  layout,
  data,
}: TemplateBasedReceiptDocumentProps) {
  // Get paper dimensions based on size and orientation (no hooks - PDFDownloadLink renders in Web Worker)
  const size = PAPER_SIZES[layout.paperSize];
  const dimensions = layout.orientation === "landscape"
    ? { width: size.height, height: size.width }
    : size;

  // Calculate max characters for fee names based on available width
  // Available width = page width - left margin - right margin - amount column (80pt)
  // Character width ≈ fontSize * 0.5 (conservative estimate for Helvetica)
  const availableWidth = dimensions.width - mmToPoints(layout.marginLeft) - mmToPoints(layout.marginRight) - 80;
  const charWidth = layout.fontSize * 0.5;
  const maxFeeNameChars = Math.max(40, Math.floor(availableWidth / charWidth));

  // Create styles (computed directly, not memoized)
  const styles = StyleSheet.create({
    page: {
      paddingTop: mmToPoints(layout.marginTop),
      paddingRight: mmToPoints(layout.marginRight),
      paddingBottom: mmToPoints(layout.marginBottom),
      paddingLeft: mmToPoints(layout.marginLeft),
      fontSize: layout.fontSize,
      fontFamily: layout.fontFamily,
      backgroundColor: "#ffffff",
      color: "#000000",
    },
    section: {
      marginBottom: 10,
    },
    text: {
      marginBottom: 2,
    },
    header: {
      marginBottom: 15,
    },
    body: {
      flex: 1,
    },
    footer: {
      marginTop: 15,
    },
    feesTable: {
      marginVertical: 10,
      height: TABLE_FIXED_ROWS * (ROW_HEIGHT + 1), // Account for marginBottom in each row
    },
    feeRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      height: ROW_HEIGHT, // Fixed row height
      marginBottom: 1, // Minimal spacing (1pt)
    },
    feeName: {
      flex: 1,
      overflow: 'hidden',
    },
    feeAmount: {
      width: 80,
      textAlign: "right",
    },
  });

  // Parse templates with data (computed directly, not memoized)
  const parsedHeader = parseTemplate(layout.headerTemplate, data);
  const parsedBody = parseTemplate(layout.bodyTemplate, data);
  const parsedFooter = parseTemplate(layout.footerTemplate, data);

  // Render fees table with fixed 11 rows (includes surcharge/penalty rows)
  // When layout.hideZeroAmountFees is true, fee items with amount === 0 are
  // filtered out before the row math, so empty padding rows expand to keep
  // the table at TABLE_FIXED_ROWS total.
  const renderFeesTable = (fees: PaymentReceiptFee[] | undefined) => {
    const rawItems = fees || [];
    const items = layout.hideZeroAmountFees
      ? rawItems.filter((f) => f.amount !== 0)
      : rawItems;
    const surcharge = data.surcharge ?? 0;
    const penalty = data.penalty ?? 0;
    const extraRows = (surcharge > 0 ? 1 : 0) + (penalty > 0 ? 1 : 0);
    const totalItemRows = items.length + extraRows;
    const emptyRowsCount = Math.max(0, TABLE_FIXED_ROWS - totalItemRows);

    return (
      <View style={styles.feesTable}>
        {/* Render actual fee items */}
        {items.slice(0, TABLE_FIXED_ROWS).map((fee, index) => (
          <View key={index} style={styles.feeRow}>
            <Text style={styles.feeName}>{truncateText(fee.feeName, maxFeeNameChars)}</Text>
            <Text style={styles.feeAmount}>{formatCurrency(fee.amount)}</Text>
          </View>
        ))}
        {/* Render surcharge row if > 0 */}
        {surcharge > 0 && (
          <View style={styles.feeRow}>
            <Text style={styles.feeName}>Surcharge</Text>
            <Text style={styles.feeAmount}>{formatCurrency(surcharge)}</Text>
          </View>
        )}
        {/* Render penalty row if > 0 */}
        {penalty > 0 && (
          <View style={styles.feeRow}>
            <Text style={styles.feeName}>Interest</Text>
            <Text style={styles.feeAmount}>{formatCurrency(penalty)}</Text>
          </View>
        )}
        {/* Render empty rows to fill to 11 */}
        {Array.from({ length: emptyRowsCount }).map((_, index) => (
          <View key={`empty-${index}`} style={styles.feeRow}>
            <Text style={styles.feeName}>{"\u00A0"}</Text>
            <Text style={styles.feeAmount}>{"\u00A0"}</Text>
          </View>
        ))}
      </View>
    );
  };

  // Preserve whitespace by converting spaces to non-breaking spaces
  const preserveWhitespace = (text: string): string => {
    if (!text) return "";
    // Convert regular spaces to non-breaking spaces to preserve formatting
    // This is necessary because PDF renderers collapse regular whitespace
    return text.replace(/ /g, "\u00A0");
  };

  // Render text with line breaks and handle {{FEES_TABLE}}
  const renderTemplateContent = (content: string) => {
    if (!content) return null;

    // Split by FEES_TABLE marker - use regex for robust whitespace handling
    if (/\{\{\s*FEES_TABLE\s*\}\}/.test(content)) {
      const parts = content.split(/\{\{\s*FEES_TABLE\s*\}\}/);
      return (
        <>
          {parts[0] && renderLines(parts[0])}
          {renderFeesTable(data.fees)}
          {parts[1] && renderLines(parts[1])}
        </>
      );
    }

    return renderLines(content);
  };

  // Render lines of text
  const renderLines = (content: string) => {
    if (!content) return null;

    const lines = content.split("\n");
    return (
      <>
        {lines.map((line, index) => (
          <Text key={index} style={styles.text}>
            {preserveWhitespace(line) || "\u00A0"} {/* Use non-breaking space for empty lines */}
          </Text>
        ))}
      </>
    );
  };

  return (
    <Document>
      <Page size={dimensions} style={styles.page}>
        {/* Header */}
        <View style={styles.header}>
          {renderTemplateContent(parsedHeader)}
        </View>

        {/* Body */}
        <View style={styles.body}>
          {renderTemplateContent(parsedBody)}
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          {renderTemplateContent(parsedFooter)}
        </View>
      </Page>
    </Document>
  );
}
