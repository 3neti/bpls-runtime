/**
 * Clearance Detail Modal Component
 *
 * Displays detailed information about a department clearance including:
 * - Department name and certificate name
 * - Current status with badge
 * - Fee amount (if approved)
 * - Remarks from department
 * - Approval date and approver
 */

import { Badge } from "@repo/ui/components/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { Separator } from "@repo/ui/components/separator"
import { CheckCircle, Clock, AlertCircle, DollarSign, MessageSquare, Calendar, User, FileCheck2 } from "lucide-react"
import { formatDate } from "@/lib/utils/permit-helpers"
import { formatCurrency } from "@/lib/utils/formatting"
import type { Clearance } from "@/lib/types/clearance"
import { QRCodeSVG } from "qrcode.react"

interface ClearanceDetailModalProps {
  /** The clearance to display details for */
  clearance: Clearance | null
  /** Whether the modal is open */
  open: boolean
  /** Callback when the modal should close */
  onClose: () => void
}

/**
 * Get status badge configuration based on clearance status
 */
function getStatusBadge(status: Clearance['status']) {
  switch (status) {
    case 'approved':
      return {
        variant: 'default' as const,
        className: 'bg-green-100 text-green-800 hover:bg-green-100',
        icon: CheckCircle,
        label: 'Approved',
      }
    case 'pending':
      return {
        variant: 'secondary' as const,
        className: 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100',
        icon: Clock,
        label: 'Pending Review',
      }
    case 'not_started':
      return {
        variant: 'secondary' as const,
        className: 'bg-gray-100 text-gray-600 hover:bg-gray-100',
        icon: AlertCircle,
        label: 'Not Started',
      }
  }
}

/**
 * Format currency amount in Philippine Pesos with symbol
 */
function formatCurrencyWithSymbol(amount: number): string {
  return formatCurrency(amount, { withSymbol: true })
}

export function ClearanceDetailModal({ clearance, open, onClose }: ClearanceDetailModalProps) {
  if (!clearance) return null

  const statusBadge = getStatusBadge(clearance.status)
  const StatusIcon = statusBadge.icon

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="text-xl">{clearance.certificateName}</DialogTitle>
          <DialogDescription>{clearance.department.name}</DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Status */}
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-muted-foreground">Status</h4>
            <Badge variant={statusBadge.variant} className={statusBadge.className}>
              <StatusIcon className="mr-1.5 h-3.5 w-3.5" />
              {statusBadge.label}
            </Badge>
          </div>

          <Separator />

          {/* Fee - Multi-fee structure (new) */}
          {clearance.status === 'approved' && clearance.fees && clearance.fees.length > 0 && (
            <>
              <div className="space-y-3">
                <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Fee Breakdown
                </h4>
                <div className="space-y-2 bg-muted/50 p-3 rounded-md">
                  {clearance.fees.map((fee, index) => (
                    <div key={index} className="flex items-start justify-between text-sm">
                      <div className="flex-1">
                        <p className="font-medium">{fee.feeName}</p>
                        {fee.overrideReason && (
                          <p className="text-xs text-muted-foreground italic mt-0.5">
                            {fee.overrideReason}
                          </p>
                        )}
                      </div>
                      <p className="font-semibold ml-4">{formatCurrencyWithSymbol(fee.appliedAmount)}</p>
                    </div>
                  ))}
                  <Separator className="my-2" />
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-semibold">Total:</p>
                    <p className="text-2xl font-bold text-primary">{formatCurrencyWithSymbol(clearance.totalAmount || 0)}</p>
                  </div>
                </div>
              </div>
              <Separator />
            </>
          )}

          {/* Fee - Single fee (legacy) */}
          {clearance.status === 'approved' &&
           clearance.fee !== undefined &&
           (!clearance.fees || clearance.fees.length === 0) && (
            <>
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Fee Amount
                </h4>
                <p className="text-2xl font-semibold">{formatCurrencyWithSymbol(clearance.fee)}</p>
              </div>
              <Separator />
            </>
          )}

          {/* Remarks */}
          {clearance.remarks && (
            <>
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  Remarks
                </h4>
                <p className="text-sm text-foreground leading-relaxed bg-muted/50 p-3 rounded-md">
                  {clearance.remarks}
                </p>
              </div>
              <Separator />
            </>
          )}

          {/* Approval Information */}
          {clearance.status === 'approved' && (
            <>
              <div className="grid grid-cols-2 gap-4">
                {clearance.approvedAt && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      Approved On
                    </h4>
                    <p className="text-sm">{formatDate(clearance.approvedAt)}</p>
                  </div>
                )}

                {clearance.approvedByName && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                      <User className="h-4 w-4" />
                      Approved By
                    </h4>
                    <p className="text-sm">{clearance.approvedByName}</p>
                  </div>
                )}
              </div>

              <Separator />

              {/* Generated Certificate with QR Code */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <FileCheck2 className="h-4 w-4" />
                  Generated Certificate
                </h4>
                <div className="bg-muted/30 p-6 rounded-lg border border-border">
                  <div className="flex flex-col items-center gap-4">
                    {/* QR Code */}
                    <div className="bg-white p-4 rounded-lg">
                      <QRCodeSVG
                        value={`${clearance.id}|${clearance.permitId}|${clearance.department.id}|${clearance.approvedAt}`}
                        size={160}
                        level="H"
                      />
                    </div>

                    {/* Certificate Info */}
                    <div className="text-center space-y-1">
                      <p className="text-sm font-semibold">{clearance.certificateName}</p>
                      <p className="text-xs text-muted-foreground">Certificate ID: {clearance.id}</p>
                      <p className="text-xs text-muted-foreground">
                        Scan QR code to verify authenticity
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* Not Started Message */}
          {clearance.status === 'not_started' && (
            <div className="bg-muted/50 p-4 rounded-md">
              <p className="text-sm text-muted-foreground">
                This clearance has not been reviewed by the {clearance.department.name} yet.
              </p>
            </div>
          )}

          {/* Pending Message */}
          {clearance.status === 'pending' && (
            <div className="bg-yellow-50 p-4 rounded-md border border-yellow-200">
              <p className="text-sm text-yellow-800">
                This clearance is currently under review by the {clearance.department.name}.
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
