"use client";

import { useState, useEffect } from "react";
import { useForm, UseFormReturn } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "convex/react";
import { Loader2 } from "lucide-react";
import { z } from "zod";

import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select";
import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card";
import { DatePicker } from "@repo/ui/components/date-picker";
import { Popover, PopoverContent, PopoverTrigger } from "@repo/ui/components/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@repo/ui/components/command";
import { Check, ChevronsUpDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { OwnershipDocumentsField } from "@/components/businesses/ownership-documents-field";
import { useDefaultLocations } from "@/hooks/use-default-locations";
import { useCategorySelects } from "@/hooks/use-category-selects";
import { api } from "@repo/backend/convex/_generated/api";
import { cn } from "@/lib/utils";

import type { Id } from "@repo/backend/convex/_generated/dataModel";

/**
 * Combined schema that works for both create and update modes
 * Uses discriminated union to handle mode-specific requirements
 */
const baseBusinessSchema = z.object({
  name: z.string().min(1, "Business name is required"),
  businessArea: z.number().positive("Must be a positive number").optional(),
  propertyIndexNumber: z.string().optional(),
  dateEstablished: z.string().optional(),
  registrationDate: z.string().optional(),
  registrationNumber: z.string().optional(),
  dateStarted: z.string().min(1, "Date started is required"),
  occupancy: z.string().optional(),
  maleEmployeeCount: z.number().min(0, "Male employee count must be 0 or greater"),
  femaleEmployeeCount: z.number().min(0, "Female employee count must be 0 or greater"),
  ownershipType: z.string().min(1, "Ownership type is required"),
  groupName: z.string().optional(),
  contactNumber: z.string().optional(),
  email: z.union([z.string().email(), z.literal("")]).optional(),
  address: z.string().min(1, "Street address is required"),
  buildingName: z.string().optional(),
  provinceId: z.string().min(1, "Province is required"),
  cityId: z.string().min(1, "City/Municipality is required"),
  barangayId: z.string().min(1, "Barangay is required"),
  lineOfBusiness: z.string().optional(), // Optional for create, required for update
  categoryId: z.string().optional(),
  subCategoryId: z.string().optional(),
  documents: z.record(z.string(), z.object({
    file: z.instanceof(File).nullable(),
    uploaded: z.boolean(),
  })).optional(),
});

const createModeSchema = baseBusinessSchema.extend({
  mode: z.literal("create"),
  ownerId: z.string().min(1, "Owner ID is required"),
  lineOfBusiness: z.string().min(1, "Line of business is required"),
});

const updateModeSchema = baseBusinessSchema.extend({
  mode: z.literal("update"),
  id: z.string().min(1, "ID is required"),
  lineOfBusiness: z.string().min(1, "Line of business is required"),
});

export const businessDetailsFormSchema = z.discriminatedUnion("mode", [
  createModeSchema,
  updateModeSchema,
])
  .refine((data) => data.maleEmployeeCount + data.femaleEmployeeCount > 0, {
    message: "At least one employee is required (male or female)",
    path: ["maleEmployeeCount"],
  })
  .superRefine((data, ctx) => {
    const normalizedOwnershipType = data.ownershipType.toLowerCase().replace(/\s+/g, "-");
    const requiresGroupName = ["partnership", "corporation", "cooperative"].includes(normalizedOwnershipType);
    if (requiresGroupName && (!data.groupName || data.groupName.trim().length === 0)) {
      ctx.addIssue({
        code: "custom",
        message: `Company/Organization name is required for ${data.ownershipType}`,
        path: ["groupName"],
      });
    }
  });

export type BusinessDetailsFormSchema = z.infer<typeof businessDetailsFormSchema>;

/**
 * Props for BusinessDetailsForm component
 */
interface BusinessDetailsFormProps {
  mode: "create" | "update";
  ownerId?: Id<"business_owners"> | string; // Required for create mode
  businessId?: Id<"businesses">; // Required for update mode
  initialData?: Partial<BusinessDetailsFormSchema>;
  existingDocuments?: Array<{
    storageId: Id<"_storage">;
    documentType: string;
    fileName: string;
    uploadedAt: string;
  }>;
  onSuccess?: () => void;
  onCancel?: () => void;
  showCancelButton?: boolean;
}

/**
 * BusinessDetailsForm - Reusable component for business creation and updates
 *
 * @example Create Mode
 * ```tsx
 * <BusinessDetailsForm
 *   mode="create"
 *   ownerId={selectedOwnerId}
 *   onSuccess={() => router.push("/dashboard/businesses")}
 * />
 * ```
 *
 * @example Update Mode
 * ```tsx
 * <BusinessDetailsForm
 *   mode="update"
 *   businessId={business.id}
 *   initialData={business}
 *   existingDocuments={business.documents}
 *   onSuccess={() => router.refresh()}
 * />
 * ```
 */
export function BusinessDetailsForm({
  mode,
  ownerId,
  businessId,
  initialData,
  existingDocuments = [],
  onSuccess,
  onCancel,
  showCancelButton = false,
}: BusinessDetailsFormProps) {
  const { toast } = useToast();
  const createBusiness = useMutation(api.businesses.create);
  const updateBusiness = useMutation(api.businesses.update);
  const addDocument = useMutation(api.businesses.addDocument);
  const generateUploadUrl = useMutation(api.businessOwners.generateUploadUrl);

  // Get default locations for new resources
  const {
    defaultProvinceId,
    defaultCityId,
    defaultBarangayId,
    isLoading: isLoadingDefaults,
  } = useDefaultLocations();

  // Compute effective initial values: use initialData if available, otherwise use defaults for create mode
  const effectiveInitialProvinceId = initialData?.provinceId || (mode === "create" ? (defaultProvinceId ?? "") : "");
  const effectiveInitialCityId = initialData?.cityId || (mode === "create" ? (defaultCityId ?? "") : "");
  const effectiveInitialBarangayId = initialData?.barangayId || (mode === "create" ? (defaultBarangayId ?? "") : "");

  // Location data queries
  const provinces = useQuery(api.locations.listProvinces);
  const [selectedProvinceId, setSelectedProvinceId] = useState<string>(effectiveInitialProvinceId);
  const [selectedCityId, setSelectedCityId] = useState<string>(effectiveInitialCityId);

  // Combobox open/close states
  const [openOccupancyCombobox, setOpenOccupancyCombobox] = useState(false);
  const [openOwnershipTypeCombobox, setOpenOwnershipTypeCombobox] = useState(false);
  const [openProvinceCombobox, setOpenProvinceCombobox] = useState(false);
  const [openCityCombobox, setOpenCityCombobox] = useState(false);
  const [openBarangayCombobox, setOpenBarangayCombobox] = useState(false);

  const cities = useQuery(
    api.locations.listCitiesByProvince,
    selectedProvinceId ? { provinceId: selectedProvinceId as Id<"provinces"> } : "skip"
  );
  const barangays = useQuery(
    api.locations.listBarangaysByCity,
    selectedCityId ? { cityId: selectedCityId as Id<"cities"> } : "skip"
  );

  // Cascading category selects hook
  const {
    categories,
    subCategories,
    isSubCategoryDisabled,
    handleCategoryChange,
    handleSubCategoryChange,
  } = useCategorySelects({
    initialCategoryId: initialData?.categoryId || "",
    initialSubCategoryId: initialData?.subCategoryId || "",
    onCategoryChange: (id) => form.setValue("categoryId", id),
    onSubCategoryChange: (id) => form.setValue("subCategoryId", id),
  });

  // Initialize form with proper default values based on mode
  const getDefaultValues = (): BusinessDetailsFormSchema => {
    if (mode === "create") {
      return {
        mode: "create",
        ownerId: ownerId as string || "",
        name: initialData?.name || "",
        businessArea: initialData?.businessArea || undefined,
        propertyIndexNumber: initialData?.propertyIndexNumber || "",
        dateEstablished: initialData?.dateEstablished || new Date().toISOString().split("T")[0],
        registrationDate: initialData?.registrationDate || "",
        registrationNumber: initialData?.registrationNumber || "",
        dateStarted: initialData?.dateStarted || new Date().toISOString().split("T")[0],
        occupancy: initialData?.occupancy || "rented",
        maleEmployeeCount: initialData?.maleEmployeeCount || 1,
        femaleEmployeeCount: initialData?.femaleEmployeeCount || 0,
        ownershipType: initialData?.ownershipType || "sole-proprietorship",
        groupName: initialData?.groupName || "",
        contactNumber: initialData?.contactNumber || "",
        email: initialData?.email || "",
        address: initialData?.address || "",
        buildingName: initialData?.buildingName || "",
        provinceId: effectiveInitialProvinceId,
        cityId: effectiveInitialCityId,
        barangayId: effectiveInitialBarangayId,
        lineOfBusiness: initialData?.lineOfBusiness || "",
        categoryId: initialData?.categoryId || "",
        subCategoryId: initialData?.subCategoryId || "",
        documents: {},
      };
    } else {
      return {
        mode: "update",
        id: businessId as string || "",
        name: initialData?.name || "",
        businessArea: initialData?.businessArea || 1,
        propertyIndexNumber: initialData?.propertyIndexNumber || "",
        dateEstablished: initialData?.dateEstablished || "",
        registrationDate: initialData?.registrationDate || "",
        registrationNumber: initialData?.registrationNumber || "",
        dateStarted: initialData?.dateStarted || new Date().toISOString().split("T")[0],
        occupancy: initialData?.occupancy?.toLowerCase() || "",
        maleEmployeeCount: initialData?.maleEmployeeCount || 0,
        femaleEmployeeCount: initialData?.femaleEmployeeCount || 0,
        ownershipType: initialData?.ownershipType?.toLowerCase().replace(/\s+/g, "-") || "",
        groupName: initialData?.groupName || "",
        contactNumber: initialData?.contactNumber || "",
        email: initialData?.email || "",
        address: initialData?.address || "",
        buildingName: initialData?.buildingName || "",
        provinceId: initialData?.provinceId || "",
        cityId: initialData?.cityId || "",
        barangayId: initialData?.barangayId || "",
        lineOfBusiness: initialData?.lineOfBusiness || "",
        categoryId: initialData?.categoryId || "",
        subCategoryId: initialData?.subCategoryId || "",
        documents: {},
      };
    }
  };

  const form = useForm<BusinessDetailsFormSchema>({
    resolver: zodResolver(businessDetailsFormSchema),
    defaultValues: getDefaultValues(),
    mode: "onChange",
  });

  // Watch form values for cascading selects and conditional fields
  const formValues = form.watch();
  const provinceId = form.watch("provinceId");
  const cityId = form.watch("cityId");
  const ownershipType = formValues.ownershipType;

  // Apply default locations when they finish loading (for create mode only)
  useEffect(() => {
    if (mode === "create" && !isLoadingDefaults && !initialData) {
      // Update province if default is available and field is empty
      if (defaultProvinceId && !form.getValues("provinceId")) {
        form.setValue("provinceId", defaultProvinceId);
        setSelectedProvinceId(defaultProvinceId);
      }
      // Update city if default is available and field is empty
      if (defaultCityId && !form.getValues("cityId")) {
        form.setValue("cityId", defaultCityId);
        setSelectedCityId(defaultCityId);
      }
      // Update barangay if default is available and field is empty
      if (defaultBarangayId && !form.getValues("barangayId")) {
        form.setValue("barangayId", defaultBarangayId);
      }
    }
  }, [mode, isLoadingDefaults, defaultProvinceId, defaultCityId, defaultBarangayId, initialData, form]);

  // Helper function to get registration date description
  const getRegistrationDateDescription = (ownershipType?: string): string => {
    const normalizedOwnershipType = ownershipType?.toLowerCase().replace(/\s+/g, "-");
    switch (normalizedOwnershipType) {
      case "sole-proprietorship":
        return "DTI Registration Date";
      case "partnership":
        return "CDA Registration Date";
      case "corporation":
        return "SEC Registration Date";
      case "cooperative":
        return "CDA Registration Date";
      case "religious":
        return "SEC Registration Date";
      case "non-profit":
        return "SEC Registration Date";
      default:
        return "Registration Date";
    }
  };

  // Document upload handlers
  const handleFileSelect = (documentType: string, file: File) => {
    const currentDocuments = formValues.documents || {};
    form.setValue("documents", {
      ...currentDocuments,
      [documentType]: { file, uploaded: true },
    });
  };

  const handleFileRemove = (documentType: string) => {
    const currentDocuments = formValues.documents || {};
    form.setValue("documents", {
      ...currentDocuments,
      [documentType]: { file: null, uploaded: false },
    });
  };

  // Auto-clear groupName when ownership type changes
  useEffect(() => {
    const normalizedOwnershipType = ownershipType?.toLowerCase().replace(/\s+/g, "-");
    const requiresGroupName = ["partnership", "corporation", "cooperative"].includes(normalizedOwnershipType);
    if (!requiresGroupName && formValues.groupName) {
      form.setValue("groupName", "");
    }
  }, [ownershipType, formValues.groupName, form]);

  // Update local state when form values change
  useEffect(() => {
    setSelectedProvinceId(provinceId || "");
  }, [provinceId]);

  useEffect(() => {
    setSelectedCityId(cityId || "");
  }, [cityId]);

  // Clear dependent fields when parent changes
  useEffect(() => {
    if (provinceId && provinceId !== initialData?.provinceId) {
      form.setValue("cityId", "");
      form.setValue("barangayId", "");
      setSelectedCityId("");
    }
  }, [provinceId, form, initialData?.provinceId]);

  useEffect(() => {
    if (cityId && cityId !== initialData?.cityId) {
      form.setValue("barangayId", "");
    }
  }, [cityId, form, initialData?.cityId]);

  const onSubmit = form.handleSubmit(async (data) => {
    try {
      // Calculate business scale based on total employees
      const totalEmployees = data.maleEmployeeCount + data.femaleEmployeeCount;
      let businessScale = "Micro";
      if (totalEmployees >= 200) {
        businessScale = "Large";
      } else if (totalEmployees >= 100) {
        businessScale = "Medium";
      } else if (totalEmployees >= 10) {
        businessScale = "Small";
      }

      let businessIdForDocuments: Id<"businesses">;

      if (data.mode === "create") {
        // Create new business
        businessIdForDocuments = await createBusiness({
          name: data.name,
          ownerId: data.ownerId as Id<"business_owners">,
          businessArea: data.businessArea,
          propertyIndexNumber: data.propertyIndexNumber || undefined,
          establishedDate: data.dateEstablished || new Date().toISOString().split("T")[0],
          registrationDate: data.registrationDate || undefined,
          registrationNumber: data.registrationNumber || undefined,
          dateStarted: data.dateStarted,
          occupancy: data.occupancy || "rented",
          maleEmployeeCount: data.maleEmployeeCount,
          femaleEmployeeCount: data.femaleEmployeeCount,
          ownershipType: data.ownershipType,
          groupName: data.groupName,
          contactNumber: data.contactNumber || "",
          email: data.email || "",
          address: data.address,
          buildingName: data.buildingName || undefined,
          provinceId: data.provinceId as Id<"provinces">,
          cityId: data.cityId as Id<"cities">,
          barangayId: data.barangayId as Id<"barangays">,
          lineOfBusiness: data.lineOfBusiness,
          categoryId: data.categoryId ? data.categoryId as Id<"business_categories"> : undefined,
          subCategoryId: data.subCategoryId ? data.subCategoryId as Id<"business_subcategories"> : undefined,
          businessScale: businessScale,
          annualRevenue: "0-100000", // Default value
          permitPaymentCadence: "annually", // Default value
        });
      } else {
        // Update existing business
        await updateBusiness({
          id: data.id as Id<"businesses">,
          name: data.name,
          businessArea: data.businessArea,
          propertyIndexNumber: data.propertyIndexNumber || undefined,
          establishedDate: data.dateEstablished || new Date().toISOString().split("T")[0],
          registrationDate: data.registrationDate || undefined,
          registrationNumber: data.registrationNumber || undefined,
          occupancy: data.occupancy || "rented",
          maleEmployeeCount: data.maleEmployeeCount,
          femaleEmployeeCount: data.femaleEmployeeCount,
          ownershipType: data.ownershipType,
          groupName: data.groupName,
          contactNumber: data.contactNumber || "",
          email: data.email || "",
          address: data.address,
          buildingName: data.buildingName || undefined,
          provinceId: data.provinceId as Id<"provinces">,
          cityId: data.cityId as Id<"cities">,
          barangayId: data.barangayId as Id<"barangays">,
          categoryId: data.categoryId ? data.categoryId as Id<"business_categories"> : undefined,
          subCategoryId: data.subCategoryId ? data.subCategoryId as Id<"business_subcategories"> : undefined,
          lineOfBusiness: data.lineOfBusiness,
          businessScale: businessScale,
        });
        businessIdForDocuments = data.id as Id<"businesses">;
      }

      // Upload documents to Convex storage
      const documents = data.documents || {};
      const documentEntries = Object.entries(documents).filter(([_, doc]) => doc.file !== null && doc.uploaded);

      if (documentEntries.length > 0) {
        const documentTypeMap: Record<string, string> = {
          dtiCertificate: "DTI Certificate",
          secCertificate: "SEC Certificate",
          articlesOfPartnership: "Articles of Partnership",
          articlesOfIncorporation: "Articles of Incorporation",
          bylaws: "By-Laws",
          gis: "General Information Sheet (GIS)",
          cdaCertificate: "CDA Certificate",
          articlesOfCooperation: "Articles of Cooperation",
        };

        for (const [documentType, doc] of documentEntries) {
          if (!doc.file) continue;

          try {
            const uploadUrl = await generateUploadUrl();
            const uploadResult = await fetch(uploadUrl, {
              method: "POST",
              headers: { "Content-Type": doc.file.type },
              body: doc.file,
            });

            if (!uploadResult.ok) {
              throw new Error(`Failed to upload ${documentType}`);
            }

            const { storageId } = (await uploadResult.json()) as { storageId: Id<"_storage"> };
            const documentDisplayName = documentTypeMap[documentType] || documentType;

            await addDocument({
              businessId: businessIdForDocuments,
              storageId,
              documentType: documentDisplayName,
              fileName: doc.file.name,
            });
          } catch (uploadError) {
            console.error(`Error uploading document ${documentType}:`, uploadError);
            toast({
              title: "Document Upload Warning",
              description: `Failed to upload ${documentType}. Other documents may have been uploaded successfully.`,
              variant: "destructive",
            });
          }
        }
      }

      toast({
        title: "Success",
        description: mode === "create"
          ? "Business created successfully"
          : "Business information updated successfully",
      });

      onSuccess?.();
    } catch (error) {
      console.error(`Error ${mode === "create" ? "creating" : "updating"} business:`, error);
      toast({
        title: "Error",
        description: `Failed to ${mode === "create" ? "create" : "update"} business information. Please try again.`,
        variant: "destructive",
      });
    }
  });

  const isSubmitting = form.formState.isSubmitting;

  return (
    <form onSubmit={onSubmit} className="space-y-6">
      {/* Business Information Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Business Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Business Name */}
          <div>
            <Label htmlFor="name">
              Business Name <span className="text-destructive">*</span>
            </Label>
            <Input id="name" placeholder="Enter business name" {...form.register("name")} />
            {form.formState.errors.name && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.name.message}</p>
            )}
          </div>

          {/* Floor Area and Property Index Number */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="businessArea">Floor Area (sq.m)</Label>
              <Input
                id="businessArea"
                type="number"
                min="1"
                step="0.01"
                placeholder="Enter floor area in square meters"
                {...form.register("businessArea", { valueAsNumber: true })}
              />
              {form.formState.errors.businessArea && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.businessArea.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="propertyIndexNumber">Property Index Number</Label>
              <Input
                id="propertyIndexNumber"
                placeholder="Enter property index number"
                {...form.register("propertyIndexNumber")}
              />
              {form.formState.errors.propertyIndexNumber && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.propertyIndexNumber.message}</p>
              )}
            </div>
          </div>

          {/* Date Established and Date Started */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="dateEstablished">Date Established</Label>
              <DatePicker
                value={formValues.dateEstablished}
                onChange={(date) => form.setValue("dateEstablished", date)}
                placeholder="Select date established"
              />
              {form.formState.errors.dateEstablished && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.dateEstablished.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="dateStarted">
                Date Started <span className="text-destructive">*</span>
              </Label>
              <DatePicker
                value={formValues.dateStarted}
                onChange={(date) => form.setValue("dateStarted", date)}
                placeholder="Select date started"
              />
              {form.formState.errors.dateStarted && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.dateStarted.message}</p>
              )}
            </div>
          </div>

          {/* Occupancy and Ownership Type */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="min-w-0">
              <Label htmlFor="occupancy">Occupancy</Label>
              <Popover open={openOccupancyCombobox} onOpenChange={setOpenOccupancyCombobox}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={openOccupancyCombobox}
                    className="w-full justify-between overflow-hidden"
                  >
                    <span className="truncate">
                      {formValues.occupancy === "rented" && "Rented"}
                      {formValues.occupancy === "owned" && "Owned"}
                      {!formValues.occupancy && "Select occupancy type"}
                    </span>
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0" align="start">
                  <Command>
                    <CommandList>
                      <CommandGroup>
                        <CommandItem
                          value="rented"
                          onSelect={() => {
                            form.setValue("occupancy", "rented");
                            setOpenOccupancyCombobox(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              formValues.occupancy === "rented" ? "opacity-100" : "opacity-0"
                            )}
                          />
                          Rented
                        </CommandItem>
                        <CommandItem
                          value="owned"
                          onSelect={() => {
                            form.setValue("occupancy", "owned");
                            setOpenOccupancyCombobox(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              formValues.occupancy === "owned" ? "opacity-100" : "opacity-0"
                            )}
                          />
                          Owned
                        </CommandItem>
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
              {form.formState.errors.occupancy && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.occupancy.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="ownershipType">
                Ownership Type <span className="text-destructive">*</span>
              </Label>
              <Popover open={openOwnershipTypeCombobox} onOpenChange={setOpenOwnershipTypeCombobox}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={openOwnershipTypeCombobox}
                    className="w-full justify-between"
                  >
                    {formValues.ownershipType === "sole-proprietorship" && "Sole Proprietorship"}
                    {formValues.ownershipType === "partnership" && "Partnership"}
                    {formValues.ownershipType === "corporation" && "Corporation"}
                    {formValues.ownershipType === "cooperative" && "Cooperative"}
                    {formValues.ownershipType === "religious" && "Religious Organization"}
                    {formValues.ownershipType === "non-profit" && "Non-Profit / Non-Stock Organization"}
                    {!formValues.ownershipType && "Select ownership type"}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0" align="start">
                  <Command>
                    <CommandInput placeholder="Search ownership type..." />
                    <CommandList>
                      <CommandEmpty>No ownership type found.</CommandEmpty>
                      <CommandGroup>
                        <CommandItem
                          value="sole-proprietorship"
                          onSelect={() => {
                            form.setValue("ownershipType", "sole-proprietorship");
                            setOpenOwnershipTypeCombobox(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              formValues.ownershipType === "sole-proprietorship" ? "opacity-100" : "opacity-0"
                            )}
                          />
                          Sole Proprietorship
                        </CommandItem>
                        <CommandItem
                          value="partnership"
                          onSelect={() => {
                            form.setValue("ownershipType", "partnership");
                            setOpenOwnershipTypeCombobox(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              formValues.ownershipType === "partnership" ? "opacity-100" : "opacity-0"
                            )}
                          />
                          Partnership
                        </CommandItem>
                        <CommandItem
                          value="corporation"
                          onSelect={() => {
                            form.setValue("ownershipType", "corporation");
                            setOpenOwnershipTypeCombobox(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              formValues.ownershipType === "corporation" ? "opacity-100" : "opacity-0"
                            )}
                          />
                          Corporation
                        </CommandItem>
                        <CommandItem
                          value="cooperative"
                          onSelect={() => {
                            form.setValue("ownershipType", "cooperative");
                            setOpenOwnershipTypeCombobox(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              formValues.ownershipType === "cooperative" ? "opacity-100" : "opacity-0"
                            )}
                          />
                          Cooperative
                        </CommandItem>
                        <CommandItem
                          value="religious"
                          onSelect={() => {
                            form.setValue("ownershipType", "religious");
                            setOpenOwnershipTypeCombobox(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              formValues.ownershipType === "religious" ? "opacity-100" : "opacity-0"
                            )}
                          />
                          Religious Organization
                        </CommandItem>
                        <CommandItem
                          value="non-profit"
                          onSelect={() => {
                            form.setValue("ownershipType", "non-profit");
                            setOpenOwnershipTypeCombobox(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              formValues.ownershipType === "non-profit" ? "opacity-100" : "opacity-0"
                            )}
                          />
                          Non-Profit / Non-Stock Organization
                        </CommandItem>
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
              {form.formState.errors.ownershipType && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.ownershipType.message}</p>
              )}
            </div>
          </div>

          {/* Conditional Group Name Field */}
          {["partnership", "corporation", "cooperative"].includes(
            formValues.ownershipType?.toLowerCase().replace(/\s+/g, "-")
          ) && (
            <div>
              <Label htmlFor="groupName">
                Company/Organization Name <span className="text-destructive">*</span>
              </Label>
              <Input id="groupName" placeholder="Enter company or organization name" {...form.register("groupName")} />
              {form.formState.errors.groupName && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.groupName.message}</p>
              )}
            </div>
          )}

          {/* Line of Business */}
          <div>
            <Label htmlFor="lineOfBusiness">
              Line of Business <span className="text-destructive">*</span>
            </Label>
            <Input
              id="lineOfBusiness"
              placeholder="Enter line of business"
              {...form.register("lineOfBusiness")}
            />
            {form.formState.errors.lineOfBusiness && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.lineOfBusiness.message}</p>
            )}
          </div>

          {/* Employee Count */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Employee Count</Label>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="maleEmployeeCount">Male Employees</Label>
                <Input
                  id="maleEmployeeCount"
                  type="number"
                  min="0"
                  placeholder="0"
                  {...form.register("maleEmployeeCount", { valueAsNumber: true })}
                />
                {form.formState.errors.maleEmployeeCount && (
                  <p className="text-sm text-red-600 mt-1">{form.formState.errors.maleEmployeeCount.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="femaleEmployeeCount">Female Employees</Label>
                <Input
                  id="femaleEmployeeCount"
                  type="number"
                  min="0"
                  placeholder="0"
                  {...form.register("femaleEmployeeCount", { valueAsNumber: true })}
                />
                {form.formState.errors.femaleEmployeeCount && (
                  <p className="text-sm text-red-600 mt-1">{form.formState.errors.femaleEmployeeCount.message}</p>
                )}
              </div>
            </div>
            <div className="bg-muted px-4 py-2 rounded-lg">
              <p className="text-sm font-medium">
                Total Employees: {(formValues.maleEmployeeCount || 0) + (formValues.femaleEmployeeCount || 0)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Contact & Address Information Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Contact & Address Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="contactNumber">Business Contact Number</Label>
              <Input id="contactNumber" placeholder="+63 912 345 6789" {...form.register("contactNumber")} />
              {form.formState.errors.contactNumber && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.contactNumber.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input id="email" type="email" placeholder="business@example.com" {...form.register("email")} />
              {form.formState.errors.email && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.email.message}</p>
              )}
            </div>
          </div>

          <div>
            <Label htmlFor="address">
              Street Address <span className="text-destructive">*</span>
            </Label>
            <Input id="address" placeholder="House No., Street Name" {...form.register("address")} />
            {form.formState.errors.address && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.address.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="buildingName">Building Name</Label>
            <Input id="buildingName" placeholder="Enter building name" {...form.register("buildingName")} />
            {form.formState.errors.buildingName && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.buildingName.message}</p>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="min-w-0">
              <Label htmlFor="provinceId">
                Province <span className="text-destructive">*</span>
              </Label>
              <Popover open={openProvinceCombobox} onOpenChange={setOpenProvinceCombobox}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={openProvinceCombobox}
                    className="w-full justify-between overflow-hidden"
                  >
                    <span className="truncate">
                      {formValues.provinceId
                        ? provinces?.find((p: { _id: string; name: string }) => p._id === formValues.provinceId)?.name
                        : "Select province"}
                    </span>
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0" align="start">
                  <Command>
                    <CommandInput placeholder="Search province..." />
                    <CommandList>
                      <CommandEmpty>No province found.</CommandEmpty>
                      <CommandGroup>
                        {provinces?.map((province: { _id: string; name: string }) => (
                          <CommandItem
                            key={province._id}
                            value={province.name}
                            onSelect={() => {
                              form.setValue("provinceId", province._id);
                              setOpenProvinceCombobox(false);
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                formValues.provinceId === province._id ? "opacity-100" : "opacity-0"
                              )}
                            />
                            {province.name}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
              {form.formState.errors.provinceId && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.provinceId.message}</p>
              )}
            </div>

            <div className="min-w-0">
              <Label htmlFor="cityId">
                City/Municipality <span className="text-destructive">*</span>
              </Label>
              <Popover open={openCityCombobox} onOpenChange={setOpenCityCombobox}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={openCityCombobox}
                    className="w-full justify-between overflow-hidden"
                    disabled={!selectedProvinceId}
                  >
                    <span className="truncate">
                      {formValues.cityId
                        ? cities?.find((c: { _id: string; name: string }) => c._id === formValues.cityId)?.name
                        : "Select city/municipality"}
                    </span>
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0" align="start">
                  <Command>
                    <CommandInput placeholder="Search city/municipality..." />
                    <CommandList>
                      <CommandEmpty>No city/municipality found.</CommandEmpty>
                      <CommandGroup>
                        {cities?.map((city: { _id: string; name: string }) => (
                          <CommandItem
                            key={city._id}
                            value={city.name}
                            onSelect={() => {
                              form.setValue("cityId", city._id);
                              setOpenCityCombobox(false);
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                formValues.cityId === city._id ? "opacity-100" : "opacity-0"
                              )}
                            />
                            {city.name}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
              {form.formState.errors.cityId && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.cityId.message}</p>
              )}
            </div>

            <div className="min-w-0">
              <Label htmlFor="barangayId">
                Barangay <span className="text-destructive">*</span>
              </Label>
              <Popover open={openBarangayCombobox} onOpenChange={setOpenBarangayCombobox}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={openBarangayCombobox}
                    className="w-full justify-between overflow-hidden"
                    disabled={!selectedCityId}
                  >
                    <span className="truncate">
                      {formValues.barangayId
                        ? barangays?.find((b: { _id: string; name: string }) => b._id === formValues.barangayId)?.name
                        : "Select barangay"}
                    </span>
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0" align="start">
                  <Command>
                    <CommandInput placeholder="Search barangay..." />
                    <CommandList>
                      <CommandEmpty>No barangay found.</CommandEmpty>
                      <CommandGroup>
                        {barangays?.map((barangay: { _id: string; name: string }) => (
                          <CommandItem
                            key={barangay._id}
                            value={barangay.name}
                            onSelect={() => {
                              form.setValue("barangayId", barangay._id);
                              setOpenBarangayCombobox(false);
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                formValues.barangayId === barangay._id ? "opacity-100" : "opacity-0"
                              )}
                            />
                            {barangay.name}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
              {form.formState.errors.barangayId && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.barangayId.message}</p>
              )}
            </div>
          </div>

          {/* Business Classification */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="categoryId">Category</Label>
              <Select
                value={formValues.categoryId || ""}
                onValueChange={handleCategoryChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category (optional)" />
                </SelectTrigger>
                <SelectContent>
                  {categories?.map((cat: { _id: string; name: string }) => (
                    <SelectItem key={cat._id} value={cat._id}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="subCategoryId">Sub-Category</Label>
              <Select
                value={formValues.subCategoryId || ""}
                onValueChange={handleSubCategoryChange}
                disabled={isSubCategoryDisabled}
              >
                <SelectTrigger>
                  <SelectValue placeholder={isSubCategoryDisabled ? "Select a category first" : "Select sub-category (optional)"} />
                </SelectTrigger>
                <SelectContent>
                  {subCategories?.map((sub: { _id: string; name: string }) => (
                    <SelectItem key={sub._id} value={sub._id}>
                      {sub.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Ownership-Specific Documents Section */}
      {ownershipType && ownershipType !== "" && (
        <div className="space-y-6 pt-6 border-t">
          <div>
            <h3 className="text-lg font-semibold mb-2">Ownership-Specific Documents</h3>
            <p className="text-muted-foreground mb-6">
              Additional documents required based on your selected ownership type
            </p>
          </div>

          {/* Registration Date and Number Fields */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{getRegistrationDateDescription(ownershipType)}</Label>
              <DatePicker
                value={formValues.registrationDate}
                onChange={(date) => form.setValue("registrationDate", date)}
                placeholder="Select or type date (MM/DD/YYYY)"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="registrationNumber">Registration Number</Label>
              <Input
                id="registrationNumber"
                placeholder="Enter registration number"
                {...form.register("registrationNumber")}
              />
              {form.formState.errors.registrationNumber && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.registrationNumber.message}</p>
              )}
            </div>
          </div>

          <OwnershipDocumentsField
            ownershipType={ownershipType}
            businessId={businessId}
            documents={formValues.documents}
            existingDocuments={existingDocuments}
            onFileSelect={handleFileSelect}
            onFileRemove={handleFileRemove}
            onExistingDocumentDeleted={onSuccess}
          />
        </div>
      )}

      {/* Submit Button */}
      <div className="flex justify-end gap-2 pt-6 border-t">
        {showCancelButton && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {isSubmitting ? (mode === "create" ? "Creating..." : "Updating...") : (mode === "create" ? "Create Business" : "Update Business")}
        </Button>
      </div>
    </form>
  );
}
