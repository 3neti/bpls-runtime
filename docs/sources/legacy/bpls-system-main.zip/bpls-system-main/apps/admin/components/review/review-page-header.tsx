interface ReviewPageHeaderProps {
  /** Main page title */
  title: string
  /** Descriptive text displayed below the title */
  description: string
}

/**
 * ReviewPageHeader Component
 *
 * Displays the page title and description for clearance review pages.
 * Used in clearance approval workflows.
 *
 * Mobile-responsive with text size adjustments.
 *
 * @example
 * ```tsx
 * <ReviewPageHeader
 *   title="Sanitary Certificate Review"
 *   description="Health and sanitation compliance certificate for business premises"
 * />
 * ```
 */
export function ReviewPageHeader({ title, description }: ReviewPageHeaderProps) {
  return (
    <div>
      <h2 className="text-xl font-bold tracking-tight sm:text-2xl">{title}</h2>
      <p className="text-sm text-muted-foreground sm:text-base">{description}</p>
    </div>
  )
}
