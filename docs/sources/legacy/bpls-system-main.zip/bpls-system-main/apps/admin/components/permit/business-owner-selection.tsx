"use client"

import { Search, User, Info } from "lucide-react"
import { Card, CardContent } from "@repo/ui/components/card"
import { Popover, PopoverContent, PopoverTrigger } from "@repo/ui/components/popover"
import { Button } from "@repo/ui/components/button"
import { usePermissions } from "@/hooks/use-permissions"

interface BusinessOwnerSelectionProps {
  onSelectExisting: () => void
  onSelectNew: () => void
}

export function BusinessOwnerSelection({ onSelectExisting, onSelectNew }: BusinessOwnerSelectionProps) {
  const { canCreate, isLoading: permissionsLoading } = usePermissions()
  const canCreateBusinessOwner = canCreate("business_owners")

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card
        className="cursor-pointer transition-all hover:shadow-md hover:border-primary/50"
        onClick={onSelectExisting}
      >
        <CardContent className="p-6 text-center">
          <div className="flex flex-col items-center space-y-4">
            <div className="p-4 bg-primary/10 rounded-full">
              <Search className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">Select Existing Business Owner</h3>
              <p className="text-sm text-muted-foreground mt-1">Choose from previously registered business owners</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card
        className={`transition-all relative ${
          canCreateBusinessOwner && !permissionsLoading
            ? "cursor-pointer hover:shadow-md hover:border-primary/50"
            : "cursor-not-allowed opacity-50"
        }`}
        onClick={canCreateBusinessOwner && !permissionsLoading ? onSelectNew : undefined}
      >
        <CardContent className="p-6 text-center">
          <div className="flex flex-col items-center space-y-4">
            <div className="p-4 bg-primary/10 rounded-full">
              <User className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">New Business Owner</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Register a new business owner with complete information
              </p>
            </div>
          </div>

          {!canCreateBusinessOwner && !permissionsLoading && (
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 h-8 w-8"
                  onClick={(e) => e.stopPropagation()}
                >
                  <Info className="h-4 w-4 text-destructive" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80" align="end">
                <div className="space-y-2">
                  <h4 className="font-semibold text-sm">Permission Required</h4>
                  <p className="text-sm text-muted-foreground">
                    You don't have permission to create business owners.
                  </p>
                  <div className="pt-2 border-t">
                    <p className="text-xs font-mono text-muted-foreground">
                      Required: <span className="font-semibold">business_owners:create</span>
                    </p>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
