"use client";

import { useState, useRef, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "convex/react";
import { format } from "date-fns";
import Webcam from "react-webcam";
import { Loader2, Calendar as CalendarIcon } from "lucide-react";
import { z } from "zod";

import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select";
import { Calendar } from "@repo/ui/components/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@repo/ui/components/popover";
import { useToast } from "@/hooks/use-toast";
import { ProfilePhotoUpload } from "@/components/permit/profile-photo-upload";
import { useDefaultLocations } from "@/hooks/use-default-locations";
import { api } from "@repo/backend/convex/_generated/api";
import { cn } from "@/lib/utils";

import type { Id } from "@repo/backend/convex/_generated/dataModel";
import type { CameraMode } from "@/lib/types/common";

/**
 * Combined schema that works for both create and update modes
 * Uses discriminated union to handle mode-specific requirements
 */
const baseOwnerSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  middleName: z.string().optional(),
  lastName: z.string().min(1, "Last name is required"),
  birthDate: z.string().min(1, "Birth date is required"),
  civilStatus: z.string().min(1, "Civil status is required"),
  gender: z.string().min(1, "Gender is required"),
  citizenship: z.string().min(1, "Citizenship is required"),
  tin: z.string().optional(),
  mobile: z.string().min(1, "Mobile number is required"),
  email: z.string().email("Invalid email address").min(1, "Email is required"),
  address: z.string().optional(),
  provinceId: z.string().min(1, "Province is required"),
  cityId: z.string().min(1, "City/Municipality is required"),
  barangayId: z.string().min(1, "Barangay is required"),
  avatar: z.string().optional(),
  profilePhoto: z.any().nullable().optional(),
  ownerType: z.enum(["Single", "Group"]),
  groupName: z.string().optional(),
});

const createModeSchema = baseOwnerSchema.extend({
  mode: z.literal("create"),
});

const updateModeSchema = baseOwnerSchema.extend({
  mode: z.literal("update"),
  id: z.string().min(1, "ID is required"),
});

export const businessOwnerFormSchema = z.discriminatedUnion("mode", [
  createModeSchema,
  updateModeSchema,
]).superRefine((data, ctx) => {
  // Validate groupName is required for Group owners
  if (data.ownerType === "Group" && (!data.groupName || data.groupName.trim().length === 0)) {
    ctx.addIssue({
      code: "custom",
      message: "Group name is required for group owners",
      path: ["groupName"],
    });
  }
});

export type BusinessOwnerFormSchema = z.infer<typeof businessOwnerFormSchema>;

/**
 * Props for BusinessOwnerForm component
 */
interface BusinessOwnerFormProps {
  mode: "create" | "update";
  ownerId?: Id<"business_owners">; // Required for update mode
  initialData?: Partial<BusinessOwnerFormSchema>;
  onSuccess?: () => void;
  onCancel?: () => void;
  showCancelButton?: boolean;
}

/**
 * BusinessOwnerForm - Reusable component for business owner creation and updates
 *
 * @example Create Mode
 * ```tsx
 * <BusinessOwnerForm
 *   mode="create"
 *   onSuccess={(ownerId) => router.push(`/dashboard/business-owners/${ownerId}`)}
 * />
 * ```
 *
 * @example Update Mode
 * ```tsx
 * <BusinessOwnerForm
 *   mode="update"
 *   ownerId={owner.id}
 *   initialData={owner}
 *   onSuccess={() => router.refresh()}
 * />
 * ```
 */
export function BusinessOwnerForm({
  mode,
  ownerId,
  initialData,
  onSuccess,
  onCancel,
  showCancelButton = false,
}: BusinessOwnerFormProps) {
  const [profilePhotoPreview, setProfilePhotoPreview] = useState<string | null>(initialData?.avatar || null);
  const [cameraMode, setCameraMode] = useState<CameraMode>("upload");
  const cameraRef = useRef<Webcam>(null);
  const { toast } = useToast();

  const createOwner = useMutation(api.businessOwners.create);
  const updateOwner = useMutation(api.businessOwners.update);
  const generateUploadUrl = useMutation(api.businessOwners.generateUploadUrl);
  const saveAvatar = useMutation(api.businessOwners.saveAvatar);

  // Get default locations from platform settings (only used in create mode)
  const { defaultProvinceId, defaultCityId, defaultBarangayId, isLoading: isLoadingDefaults } = useDefaultLocations();

  // Determine effective initial values (for create mode, use defaults if no initialData)
  const effectiveInitialProvinceId = initialData?.provinceId || (mode === "create" ? (defaultProvinceId ?? "") : "");
  const effectiveInitialCityId = initialData?.cityId || (mode === "create" ? (defaultCityId ?? "") : "");

  // Location data queries
  const provinces = useQuery(api.locations.listProvinces);
  const [selectedProvinceId, setSelectedProvinceId] = useState<string>(effectiveInitialProvinceId);
  const [selectedCityId, setSelectedCityId] = useState<string>(effectiveInitialCityId);

  // Update location selections when defaults load (for create mode without initialData)
  useEffect(() => {
    if (mode === "create" && !isLoadingDefaults && !initialData?.provinceId) {
      if (defaultProvinceId && !selectedProvinceId) {
        setSelectedProvinceId(defaultProvinceId);
      }
      if (defaultCityId && !selectedCityId) {
        setSelectedCityId(defaultCityId);
      }
    }
  }, [mode, defaultProvinceId, defaultCityId, isLoadingDefaults, initialData?.provinceId, selectedProvinceId, selectedCityId]);

  const cities = useQuery(
    api.locations.listCitiesByProvince,
    selectedProvinceId ? { provinceId: selectedProvinceId as Id<"provinces"> } : "skip"
  );
  const barangays = useQuery(
    api.locations.listBarangaysByCity,
    selectedCityId ? { cityId: selectedCityId as Id<"cities"> } : "skip"
  );

  // Initialize form with proper default values based on mode
  const getDefaultValues = (): BusinessOwnerFormSchema => {
    if (mode === "create") {
      return {
        mode: "create",
        firstName: initialData?.firstName || "",
        middleName: initialData?.middleName || "",
        lastName: initialData?.lastName || "",
        birthDate: initialData?.birthDate || "",
        civilStatus: initialData?.civilStatus || "",
        gender: initialData?.gender || "",
        citizenship: initialData?.citizenship || "filipino",
        tin: initialData?.tin || "",
        mobile: initialData?.mobile || "",
        email: initialData?.email || "",
        address: initialData?.address || "",
        provinceId: initialData?.provinceId || effectiveInitialProvinceId || "",
        cityId: initialData?.cityId || effectiveInitialCityId || "",
        barangayId: initialData?.barangayId || (mode === "create" ? (defaultBarangayId ?? "") : ""),
        avatar: initialData?.avatar || "",
        profilePhoto: null,
        ownerType: initialData?.ownerType || "Single",
        groupName: initialData?.groupName || "",
      };
    } else {
      return {
        mode: "update",
        id: ownerId as string || "",
        firstName: initialData?.firstName || "",
        middleName: initialData?.middleName || "",
        lastName: initialData?.lastName || "",
        birthDate: initialData?.birthDate || "",
        civilStatus: initialData?.civilStatus || "",
        gender: initialData?.gender || "",
        citizenship: initialData?.citizenship || "",
        tin: initialData?.tin || "",
        mobile: initialData?.mobile || "",
        email: initialData?.email || "",
        address: initialData?.address || "",
        provinceId: initialData?.provinceId || "",
        cityId: initialData?.cityId || "",
        barangayId: initialData?.barangayId || "",
        avatar: initialData?.avatar || "",
        profilePhoto: null,
        ownerType: initialData?.ownerType || "Single",
        groupName: initialData?.groupName || "",
      };
    }
  };

  const form = useForm<BusinessOwnerFormSchema>({
    resolver: zodResolver(businessOwnerFormSchema),
    defaultValues: getDefaultValues(),
    mode: "onChange",
  });

  // Watch form values for cascading selects
  const formValues = form.watch();
  const provinceId = form.watch("provinceId");
  const cityId = form.watch("cityId");

  // Update local state when form values change
  useEffect(() => {
    setSelectedProvinceId(provinceId || "");
  }, [provinceId]);

  useEffect(() => {
    setSelectedCityId(cityId || "");
  }, [cityId]);

  // Clear dependent fields when parent changes
  useEffect(() => {
    if (provinceId && provinceId !== initialData?.provinceId) {
      form.setValue("cityId", "");
      form.setValue("barangayId", "");
      setSelectedCityId("");
    }
  }, [provinceId, form, initialData?.provinceId]);

  useEffect(() => {
    if (cityId && cityId !== initialData?.cityId) {
      form.setValue("barangayId", "");
    }
  }, [cityId, form, initialData?.cityId]);

  const handleProfilePhotoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      form.setValue("profilePhoto", file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfilePhotoPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTakePhoto = () => {
    if (cameraRef.current) {
      try {
        const photo = cameraRef.current.getScreenshot();
        if (photo) {
          setProfilePhotoPreview(photo);
          fetch(photo)
            .then((res) => res.blob())
            .then((blob) => {
              const file = new File([blob], "camera-photo.jpg", { type: "image/jpeg" });
              form.setValue("profilePhoto", file);
            });
          setCameraMode("upload");
        }
      } catch (error) {
        console.error("Error taking photo:", error);
        toast({
          title: "Camera Error",
          description: "Failed to capture photo. Please try again or use file upload.",
          variant: "destructive",
        });
      }
    }
  };

  const onSubmit = form.handleSubmit(async (data) => {
    try {
      let avatarUrl = data.avatar; // existing avatar
      let ownerIdForAvatar: Id<"business_owners">;

      // If new photo was uploaded or taken
      if (data.profilePhoto) {
        const uploadUrl = await generateUploadUrl();
        const uploadResult = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": data.profilePhoto.type },
          body: data.profilePhoto,
        });

        const { storageId } = await uploadResult.json();

        if (mode === "create") {
          // We'll handle avatar after creating the owner
          avatarUrl = storageId;
        } else {
          // Update mode - save avatar immediately
          avatarUrl = await saveAvatar({
            ownerId: (data as any).id as Id<"business_owners">,
            storageId: storageId as Id<"_storage">,
          });
          setProfilePhotoPreview(avatarUrl ?? null);
        }
      }

      if (data.mode === "create") {
        // Create new business owner
        ownerIdForAvatar = await createOwner({
          firstName: data.firstName,
          middleName: data.middleName,
          lastName: data.lastName,
          birthDate: data.birthDate,
          civilStatus: data.civilStatus,
          gender: data.gender,
          citizenship: data.citizenship,
          tin: data.tin || undefined,
          mobile: data.mobile,
          email: data.email,
          address: data.address || undefined,
          provinceId: data.provinceId as Id<"provinces">,
          cityId: data.cityId as Id<"cities">,
          barangayId: data.barangayId as Id<"barangays">,
          ownerType: data.ownerType,
          groupName: data.groupName || undefined,
        });

        // If we have a photo storage ID, save the avatar now
        if (avatarUrl && data.profilePhoto) {
          avatarUrl = await saveAvatar({
            ownerId: ownerIdForAvatar,
            storageId: avatarUrl as Id<"_storage">,
          });
        }
      } else {
        // Update existing business owner
        await updateOwner({
          id: data.id as Id<"business_owners">,
          firstName: data.firstName,
          middleName: data.middleName,
          lastName: data.lastName,
          birthDate: data.birthDate,
          civilStatus: data.civilStatus,
          gender: data.gender,
          citizenship: data.citizenship,
          tin: data.tin || undefined,
          mobile: data.mobile,
          email: data.email,
          address: data.address || undefined,
          provinceId: data.provinceId as Id<"provinces">,
          cityId: data.cityId as Id<"cities">,
          barangayId: data.barangayId as Id<"barangays">,
          avatar: avatarUrl,
        });
      }

      toast({
        title: "Success",
        description: mode === "create"
          ? "Business owner created successfully"
          : "Business owner information updated successfully",
      });

      onSuccess?.();
    } catch (error) {
      console.error(`Error ${mode === "create" ? "creating" : "updating"} business owner:`, error);
      toast({
        title: "Error",
        description: `Failed to ${mode === "create" ? "create" : "update"} business owner information. Please try again.`,
        variant: "destructive",
      });
    }
  });

  const isSubmitting = form.formState.isSubmitting;

  return (
    <form onSubmit={onSubmit} className="space-y-8">
      {/* Personal Information Section */}
      <div className="space-y-4">
        <div className="border-b pb-2">
          <h4 className="text-md font-medium text-primary">Personal Information</h4>
        </div>

        <ProfilePhotoUpload
          profilePhotoPreview={profilePhotoPreview}
          cameraMode={cameraMode}
          isDisabled={false}
          onPhotoChange={handleProfilePhotoChange}
          onCameraModeChange={setCameraMode}
          onTakePhoto={handleTakePhoto}
          cameraRef={cameraRef}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="firstName">
              First Name <span className="text-destructive">*</span>
            </Label>
            <Input id="firstName" {...form.register("firstName")} placeholder="Juan" />
            {form.formState.errors.firstName && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.firstName.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="middleName">Middle Name</Label>
            <Input id="middleName" {...form.register("middleName")} placeholder="Dela" />
          </div>

          <div>
            <Label htmlFor="lastName">
              Last Name <span className="text-destructive">*</span>
            </Label>
            <Input id="lastName" {...form.register("lastName")} placeholder="Cruz" />
            {form.formState.errors.lastName && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.lastName.message}</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <Label htmlFor="birthDate">
              Birth Date <span className="text-destructive">*</span>
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !formValues.birthDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {formValues.birthDate ? format(new Date(formValues.birthDate), "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={formValues.birthDate ? new Date(formValues.birthDate) : undefined}
                  onSelect={(date) => {
                    if (date) {
                      form.setValue("birthDate", format(date, "yyyy-MM-dd"));
                    }
                  }}
                  disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
                />
              </PopoverContent>
            </Popover>
            {form.formState.errors.birthDate && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.birthDate.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="civilStatus">
              Civil Status <span className="text-destructive">*</span>
            </Label>
            <Select value={formValues.civilStatus} onValueChange={(value) => form.setValue("civilStatus", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="single">Single</SelectItem>
                <SelectItem value="married">Married</SelectItem>
                <SelectItem value="divorced">Divorced</SelectItem>
                <SelectItem value="widowed">Widowed</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.civilStatus && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.civilStatus.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="gender">
              Gender <span className="text-destructive">*</span>
            </Label>
            <Select value={formValues.gender} onValueChange={(value) => form.setValue("gender", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select gender" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="female">Female</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.gender && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.gender.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="citizenship">
              Citizenship <span className="text-destructive">*</span>
            </Label>
            <Select value={formValues.citizenship} onValueChange={(value) => form.setValue("citizenship", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select citizenship" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="filipino">Filipino</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.citizenship && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.citizenship.message}</p>
            )}
          </div>
        </div>

        {/* Owner Type Classification - Only shown in create mode */}
        {mode === "create" && (
          <div className="space-y-4">
            <div className="border-b pb-2">
              <h4 className="text-md font-medium text-primary">Owner Classification</h4>
              <p className="text-sm text-muted-foreground mt-1">
                Specify if this is a single individual owner or represents a group/organization
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="ownerType">
                  Owner Type <span className="text-destructive">*</span>
                </Label>
                <Select value={formValues.ownerType} onValueChange={(value: "Single" | "Group") => form.setValue("ownerType", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select owner type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Single">Single (Individual)</SelectItem>
                    <SelectItem value="Group">Group (Partnership/Corporation)</SelectItem>
                  </SelectContent>
                </Select>
                {form.formState.errors.ownerType && (
                  <p className="text-sm text-red-600 mt-1">{form.formState.errors.ownerType.message}</p>
                )}
              </div>

              {formValues.ownerType === "Group" && (
                <div>
                  <Label htmlFor="groupName">
                    Group/Organization Name <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="groupName"
                    {...form.register("groupName")}
                    placeholder="Enter group or organization name"
                  />
                  {form.formState.errors.groupName && (
                    <p className="text-sm text-red-600 mt-1">{form.formState.errors.groupName.message}</p>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-1 gap-4">
          <div>
            <Label htmlFor="tin">
              TIN (Tax Identification Number) <span className="text-muted-foreground text-sm"></span>
            </Label>
            <Input id="tin" placeholder="000-000-000-000" {...form.register("tin")} />
            {form.formState.errors.tin && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.tin.message}</p>
            )}
          </div>
        </div>
      </div>

      {/* Contact Information Section */}
      <div className="space-y-4">
        <div className="border-b pb-2">
          <h4 className="text-md font-medium text-primary">Contact Information</h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="mobile">
              Mobile Number <span className="text-destructive">*</span>
            </Label>
            <Input id="mobile" placeholder="+63 912 345 6789" {...form.register("mobile")} />
            {form.formState.errors.mobile && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.mobile.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="email">
              Email Address <span className="text-destructive">*</span>
            </Label>
            <Input id="email" type="email" placeholder="juan@example.com" {...form.register("email")} />
            {form.formState.errors.email && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.email.message}</p>
            )}
          </div>
        </div>
      </div>

      {/* Address Information Section */}
      <div className="space-y-4">
        <div className="border-b pb-2">
          <h4 className="text-md font-medium text-primary">Address Information</h4>
        </div>

        <div>
          <Label htmlFor="address">
            Street Address <span className="text-muted-foreground text-sm"></span>
          </Label>
          <Input id="address" placeholder="House No., Street Name, Building Name" {...form.register("address")} />
          {form.formState.errors.address && (
            <p className="text-sm text-red-600 mt-1">{form.formState.errors.address.message}</p>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="provinceId">
              Province <span className="text-destructive">*</span>
            </Label>
            <Select value={formValues.provinceId} onValueChange={(value) => form.setValue("provinceId", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select province" />
              </SelectTrigger>
              <SelectContent>
                {provinces?.map((province: { _id: string; name: string }) => (
                  <SelectItem key={province._id} value={province._id}>
                    {province.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.provinceId && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.provinceId.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="cityId">
              City/Municipality <span className="text-destructive">*</span>
            </Label>
            <Select
              value={formValues.cityId}
              onValueChange={(value) => form.setValue("cityId", value)}
              disabled={!selectedProvinceId}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select city/municipality" />
              </SelectTrigger>
              <SelectContent>
                {cities?.map((city: { _id: string; name: string }) => (
                  <SelectItem key={city._id} value={city._id}>
                    {city.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.cityId && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.cityId.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="barangayId">
              Barangay <span className="text-destructive">*</span>
            </Label>
            <Select
              value={formValues.barangayId}
              onValueChange={(value) => form.setValue("barangayId", value)}
              disabled={!selectedCityId}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select barangay" />
              </SelectTrigger>
              <SelectContent>
                {barangays?.map((barangay: { _id: string; name: string }) => (
                  <SelectItem key={barangay._id} value={barangay._id}>
                    {barangay.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.barangayId && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.barangayId.message}</p>
            )}
          </div>
        </div>
      </div>

      {/* Submit Button */}
      <div className="flex justify-end gap-2 pt-6 border-t">
        {showCancelButton && (
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        )}
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {isSubmitting ? (mode === "create" ? "Creating..." : "Updating...") : (mode === "create" ? "Create Owner" : "Update Owner")}
        </Button>
      </div>
    </form>
  );
}
