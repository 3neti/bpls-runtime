"use client";

import type React from "react";
import { User, Upload, CameraIcon } from "lucide-react";
import Webcam from "react-webcam";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Avatar, AvatarFallback, AvatarImage } from "@repo/ui/components/avatar";

interface ProfilePhotoUploadProps {
  profilePhotoPreview: string | null;
  cameraMode: "upload" | "camera";
  isDisabled?: boolean;
  onPhotoChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onCameraModeChange: (mode: "upload" | "camera") => void;
  onTakePhoto: () => void;
  cameraRef: React.RefObject<Webcam | null>;
}

export function ProfilePhotoUpload({
  profilePhotoPreview,
  cameraMode,
  isDisabled = false,
  onPhotoChange,
  onCameraModeChange,
  onTakePhoto,
  cameraRef,
}: ProfilePhotoUploadProps) {
  return (
    <div className="flex items-center space-x-6">
      <div className="flex flex-col items-center space-y-2">
        {cameraMode === "camera" ? (
          <div className="relative w-24 h-24">
            <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-border">
              <Webcam
                ref={cameraRef}
                audio={false}
                screenshotFormat="image/jpeg"
                videoConstraints={{
                  width: 640,
                  height: 640,
                  facingMode: "user",
                }}
                className="w-full h-full object-cover"
                mirrored={true}
              />
            </div>
            <Button
              type="button"
              size="sm"
              className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 h-8 w-8 rounded-full p-0"
              onClick={onTakePhoto}
            >
              <CameraIcon className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <Avatar className="h-24 w-24">
            <AvatarImage src={profilePhotoPreview || "/placeholder.svg"} alt="Profile" />
            <AvatarFallback>
              <User className="h-8 w-8" />
            </AvatarFallback>
          </Avatar>
        )}

        <div className="flex space-x-2">
          {cameraMode === "upload" ? (
            <>
              <Label htmlFor="profilePhoto" className="cursor-pointer">
                <div className="flex items-center space-x-2 text-sm text-primary hover:text-primary/80 px-3 py-1 border rounded-md">
                  <Upload className="h-4 w-4" />
                  <span>Upload</span>
                </div>
              </Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => onCameraModeChange("camera")}
                disabled={isDisabled}
              >
                <CameraIcon className="h-4 w-4 mr-2" />
                Camera
              </Button>
            </>
          ) : (
            <Button type="button" variant="outline" size="sm" onClick={() => onCameraModeChange("upload")}>
              <Upload className="h-4 w-4 mr-2" />
              Upload Instead
            </Button>
          )}
        </div>
        <Input
          id="profilePhoto"
          type="file"
          accept="image/*"
          className="hidden"
          onChange={onPhotoChange}
          disabled={isDisabled}
        />
      </div>
      <div className="flex-1">
        <p className="text-sm text-muted-foreground">
          {cameraMode === "camera"
            ? "Position yourself in the camera view and click the camera button to take a photo."
            : "Upload a clear photo of the business owner or take a photo using your camera. Accepted formats: JPG, PNG, GIF. Maximum size: 5MB."}
        </p>
      </div>
    </div>
  );
}
