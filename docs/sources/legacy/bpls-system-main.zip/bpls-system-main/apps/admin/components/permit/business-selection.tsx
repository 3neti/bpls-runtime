"use client"

import { Card, CardContent } from "@repo/ui/components/card"
import { Building2, RefreshCw, Info } from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@repo/ui/components/popover"
import { Button } from "@repo/ui/components/button"
import { usePermissions } from "@/hooks/use-permissions"

interface BusinessSelectionProps {
  onSelectNew: () => void
  onSelectRenew: () => void
  selectedOwnerId?: string
  businesses: Array<{
    id: string
    name: string
    ownerName: string
    businessScale: string
    annualRevenue: string
    establishedDate: string
    address: string
    avatar?: string
  }>
}

export function BusinessSelection({ onSelectNew, onSelectRenew, selectedOwnerId, businesses }: BusinessSelectionProps) {
  const { canCreate, isLoading: permissionsLoading } = usePermissions()
  const canCreateBusiness = canCreate("businesses")

  const ownerBusinesses = businesses.filter((business) => {
    // For now, we'll match by owner name since we don't have ownerId in business data
    // In a real app, you'd have proper foreign key relationships
    const selectedOwner = selectedOwnerId // This would be used to find the actual owner
    return true // For now, return all businesses - this would be filtered by actual owner ID
  })

  const hasOwnerBusinesses = ownerBusinesses.length > 0

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card
        className={`transition-colors border-2 relative ${
          canCreateBusiness && !permissionsLoading
            ? "cursor-pointer hover:bg-accent/50 hover:border-primary/20"
            : "cursor-not-allowed opacity-50"
        }`}
        onClick={canCreateBusiness && !permissionsLoading ? onSelectNew : undefined}
      >
        <CardContent className="flex flex-col items-center justify-center p-8 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
            <Building2 className="w-8 h-8 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">New Business</h3>
            <p className="text-sm text-muted-foreground">Register a new business with fresh business information</p>
          </div>
        </CardContent>

        {!canCreateBusiness && !permissionsLoading && (
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-2 right-2 h-8 w-8"
                onClick={(e) => e.stopPropagation()}
              >
                <Info className="h-4 w-4 text-destructive" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80" align="end">
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Permission Required</h4>
                <p className="text-sm text-muted-foreground">
                  You don't have permission to create businesses.
                </p>
                <div className="pt-2 border-t">
                  <p className="text-xs font-mono text-muted-foreground">
                    Required: <span className="font-semibold">businesses:create</span>
                  </p>
                </div>
              </div>
            </PopoverContent>
          </Popover>
        )}
      </Card>

      <Card
        className={`transition-colors border-2 ${
          hasOwnerBusinesses
            ? "cursor-pointer hover:bg-accent/50 hover:border-primary/20"
            : "cursor-not-allowed opacity-50"
        }`}
        onClick={hasOwnerBusinesses ? onSelectRenew : undefined}
      >
        <CardContent className="flex flex-col items-center justify-center p-8 text-center space-y-4">
          <div
            className={`w-16 h-16 rounded-full flex items-center justify-center ${
              hasOwnerBusinesses ? "bg-green-100" : "bg-gray-100"
            }`}
          >
            <RefreshCw className={`w-8 h-8 ${hasOwnerBusinesses ? "text-green-600" : "text-gray-400"}`} />
          </div>
          <div>
            <h3 className={`text-lg font-semibold mb-2 ${hasOwnerBusinesses ? "" : "text-muted-foreground"}`}>
              Existing Business
            </h3>
            <p className="text-sm text-muted-foreground">
              {hasOwnerBusinesses
                ? "Select an existing business for permit application"
                : "No existing businesses found for this owner"}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
