"use client";

import { useState, useMemo, useCallback, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { CalendarIcon, ChevronDown, DollarSign, CreditCard, AlertCircle, CheckCircle2, Clock, XCircle, Receipt, MoreHorizontal, Printer, Info, ExternalLink, Lock } from "lucide-react";
import Link from "next/link";
import { useQuery, useMutation } from "convex/react";
import { format, parseISO } from "date-fns";

import { Button } from "@repo/ui/components/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import { Badge } from "@repo/ui/components/badge";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Separator } from "@repo/ui/components/separator";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@repo/ui/components/collapsible";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu";
import { Textarea } from "@repo/ui/components/textarea";
import { Calendar } from "@repo/ui/components/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@repo/ui/components/popover";
import { Skeleton } from "@repo/ui/components/skeleton";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@repo/ui/components/tooltip"; // Tooltip still used for Pay button

import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import { formatCurrency, parseCurrency, cn } from "@/lib/utils";
import type { AggregatedFeeSummary, FeeCategory } from "@/components/permit/lob-configuration-card";
import { PaymentReceiptModal } from "@/components/permit/payment-receipt-modal";
import { calculateSurchargeAndPenalty } from "@/lib/utils/surcharge-penalty-calculator";
import { PermissionGuard } from "@/components/permission-guard";
import { usePermissions } from "@/hooks/use-permissions";

// Payment method type (must match backend validator)
type PaymentMethod = "Cash" | "Credit Card" | "Bank Transfer" | "GCash" | "PayMaya" | "Check";

const PAYMENT_METHODS: { value: PaymentMethod; label: string }[] = [
  { value: "Cash", label: "Cash" },
  { value: "Credit Card", label: "Credit Card" },
  { value: "Bank Transfer", label: "Bank Transfer" },
  { value: "GCash", label: "GCash" },
  { value: "PayMaya", label: "PayMaya" },
  { value: "Check", label: "Check" },
];

interface ScheduleOfPaymentsCardProps {
  applicationId: Id<"business_permit_applications">;
  modeOfPayment: "Annually" | "Semi-Annually" | "Quarterly" | undefined;
  aggregatedFees: AggregatedFeeSummary[];
  readOnly?: boolean;
  startYear?: number;
  /**
   * Callback to notify parent when payment status changes
   * Returns true if any payments have been made
   */
  onPaymentStatusChange?: (hasPayments: boolean) => void;
  /** Application number for receipt display */
  applicationNumber?: string;
  /** Business name for receipt display */
  businessName?: string;
  /** Business owner name for receipt display */
  businessOwnerName?: string;
  /**
   * Application status - payments can only be made when status is "Pending Payment"
   */
  applicationStatus?: string;
}

// Schedule section fee type from backend
interface ScheduleFee {
  feeId?: Id<"fees">;
  feeName: string;
  feeCategory: string;
  originalAmount: number;
  sectionAmount: number;
  isEdited?: boolean;
  editedAt?: string;
  editedBy?: string;
}

// Type hint for schedule section from backend (used for documentation)
// eslint-disable-next-line @typescript-eslint/no-unused-vars
type _PaymentScheduleSection = {
  _id: Id<"payment_schedules">;
  applicationId: Id<"business_permit_applications">;
  sectionNumber: number;
  dueDate: string;
  status: "pending" | "partial" | "paid";
  fees: ScheduleFee[];
  totalAmount: number;
  paidAmount: number;
  createdAt: string;
  updatedAt: string;
};

// Status badge colors
const STATUS_CONFIG: Record<string, { label: string; variant: "secondary" | "warning" | "success"; icon: typeof Clock }> = {
  pending: { label: "Pending", variant: "secondary" as const, icon: Clock },
  partial: { label: "Partial", variant: "warning" as const, icon: AlertCircle },
  paid: { label: "Paid", variant: "success" as const, icon: CheckCircle2 },
};

// Fee category colors (same as LOBConfigurationCard)
const CATEGORY_COLORS: Record<FeeCategory, string> = {
  "Tax": "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
  "Regulatory Fee": "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  "Other Charges": "bg-gray-100 text-gray-800 dark:bg-gray-800/50 dark:text-gray-400",
  "Special Fee": "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
};

export function ScheduleOfPaymentsCard({
  applicationId,
  modeOfPayment,
  aggregatedFees,
  readOnly = false,
  startYear,
  onPaymentStatusChange,
  applicationNumber,
  businessName,
  businessOwnerName,
  applicationStatus,
}: ScheduleOfPaymentsCardProps) {
  const { toast } = useToast();
  const router = useRouter();
  const { hasPermission } = usePermissions();

  // Check payment sub-permissions
  const canRecordPayments = hasPermission("permit_applications:schedule_of_payments", "create");
  const canEditPayments = hasPermission("permit_applications:schedule_of_payments", "update");
  const canVoidPayments = hasPermission("payments_billing", "delete");

  // Fetch existing payment schedules
  const schedules = useQuery(api.paymentSchedules.getByApplication, { applicationId });

  // Fetch surcharge/penalty configuration
  const surchargeConfig = useQuery(api.surchargeConfig.get);

  // Mutations
  const generateSchedule = useMutation(api.paymentSchedules.generate);
  const updateSectionDate = useMutation(api.paymentSchedules.updateSectionDate);
  const updateFeeAmount = useMutation(api.paymentSchedules.updateFeeAmount);
  const updateSurcharge = useMutation(api.paymentSchedules.updateSurcharge);
  const updatePenalty = useMutation(api.paymentSchedules.updatePenalty);
  const recordPayment = useMutation(api.payments.recordPayment);
  const voidPayment = useMutation(api.payments.voidPayment);

  // Query all payments for this application (for receipt display and void functionality)
  const allPayments = useQuery(api.payments.getByApplication, { applicationId });

  // Group payments by scheduleId for easy lookup
  type PaymentArray = NonNullable<typeof allPayments>;
  type PaymentRecord = Record<string, PaymentArray>;
  const paymentsByScheduleId = useMemo(() => {
    if (!allPayments) return {} as PaymentRecord;
    return allPayments.reduce((acc: PaymentRecord, payment: PaymentArray[number]) => {
      const schedId = payment.scheduleId as string;
      if (!acc[schedId]) acc[schedId] = [];
      acc[schedId].push(payment);
      return acc;
    }, {} as PaymentRecord);
  }, [allPayments]);

  // Local state
  const [isGenerating, setIsGenerating] = useState(false);
  const [expandedSections, setExpandedSections] = useState<Set<number>>(new Set([1])); // First section expanded by default
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const [selectedScheduleId, setSelectedScheduleId] = useState<Id<"payment_schedules"> | null>(null);
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("Cash");
  const [referenceNumber, setReferenceNumber] = useState("");
  const [receiptNumber, setReceiptNumber] = useState("");
  const [paymentRemarks, setPaymentRemarks] = useState("");
  const [isSubmittingPayment, setIsSubmittingPayment] = useState(false);

  // Void payment dialog state
  const [voidDialogOpen, setVoidDialogOpen] = useState(false);
  const [selectedPaymentToVoid, setSelectedPaymentToVoid] = useState<{
    paymentId: Id<"payments">;
    receiptNumber: string;
    amount: number;
  } | null>(null);
  const [voidReason, setVoidReason] = useState("");
  const [isVoiding, setIsVoiding] = useState(false);

  // Query to check if voiding will demote the application
  const checkVoidDemotion = useQuery(
    api.payments.checkVoidWillDemote,
    selectedPaymentToVoid ? { paymentId: selectedPaymentToVoid.paymentId } : "skip"
  );

  // Query to check if payment will auto-mark zero-total sections
  const checkAutoMark = useQuery(
    api.payments.checkPaymentWillAutoMark,
    selectedScheduleId && paymentAmount
      ? { scheduleId: selectedScheduleId, paymentAmount: parseFloat(paymentAmount) || 0 }
      : "skip"
  );

  // Receipt preview modal state
  const [receiptPreviewOpen, setReceiptPreviewOpen] = useState(false);
  const [selectedScheduleForReceipt, setSelectedScheduleForReceipt] = useState<Id<"payment_schedules"> | null>(null);

  // Check if schedule exists
  const hasSchedule = schedules && schedules.length > 0;
  const isLoading = schedules === undefined;

  // Track previous values for change detection
  const prevModeOfPaymentRef = useRef<string | undefined>(undefined);
  const prevFeesKeyRef = useRef<string>("");

  // Calculate grand total from aggregated fees (used for generation)
  const grandTotalFromFees = useMemo(() => {
    return aggregatedFees.reduce((sum, fee) => sum + fee.totalAmount, 0);
  }, [aggregatedFees]);

  // Calculate grand total from schedules (used for display when schedules exist)
  const grandTotalFromSchedules = useMemo(() => {
    if (!schedules || schedules.length === 0) return 0;
    return schedules.reduce((sum: number, s: NonNullable<typeof schedules>[number]) => sum + s.totalAmount, 0);
  }, [schedules]);

  // Effective grand total: use schedules if they exist, otherwise use fees
  const grandTotal = hasSchedule ? grandTotalFromSchedules : grandTotalFromFees;

  // Create a stable key for fees to detect changes
  const feesKey = useMemo(() => {
    return aggregatedFees
      .map((fee) => `${fee.feeName}:${fee.feeCategory}:${fee.totalAmount}`)
      .sort()
      .join("|");
  }, [aggregatedFees]);

  // Create a key from database schedule fees to detect stale data
  const scheduleFeesKey = useMemo(() => {
    if (!schedules || schedules.length === 0) return "";
    // Aggregate all fees across all sections to get unique fee names with total amounts
    const feeMap = new Map<string, { feeName: string; feeCategory: string; totalAmount: number }>();
    schedules.forEach((schedule: NonNullable<typeof schedules>[number]) => {
      schedule.fees.forEach((fee: ScheduleFee) => {
        const key = `${fee.feeName}:${fee.feeCategory}`;
        const existing = feeMap.get(key);
        if (existing) {
          // For tax fees, they're split across sections - accumulate the original amount
          // For non-tax fees, they're in section 1 only
          existing.totalAmount = fee.originalAmount; // Use originalAmount which is the full amount
        } else {
          feeMap.set(key, {
            feeName: fee.feeName,
            feeCategory: fee.feeCategory,
            totalAmount: fee.originalAmount,
          });
        }
      });
    });
    return Array.from(feeMap.values())
      .map((fee) => `${fee.feeName}:${fee.feeCategory}:${fee.totalAmount}`)
      .sort()
      .join("|");
  }, [schedules]);

  // Check if schedule fees are stale (don't match current aggregated fees)
  const isScheduleStale = useMemo(() => {
    if (!hasSchedule || !feesKey) return false;
    return feesKey !== scheduleFeesKey;
  }, [hasSchedule, feesKey, scheduleFeesKey]);

  // Calculate total paid from all schedules
  const totalPaid = useMemo(() => {
    if (!schedules) return 0;
    return schedules.reduce((sum: number, s: NonNullable<typeof schedules>[number]) => sum + s.paidAmount, 0);
  }, [schedules]);

  // Check if any payments have been made
  const hasPayments = totalPaid > 0;

  // Notify parent when payment status changes
  useEffect(() => {
    if (onPaymentStatusChange) {
      onPaymentStatusChange(hasPayments);
    }
  }, [hasPayments, onPaymentStatusChange]);

  // Remaining balance
  const remainingBalance = grandTotal - totalPaid;

  // Toggle section expansion
  const toggleSection = useCallback((sectionNumber: number) => {
    setExpandedSections((prev) => {
      const next = new Set(prev);
      if (next.has(sectionNumber)) {
        next.delete(sectionNumber);
      } else {
        next.add(sectionNumber);
      }
      return next;
    });
  }, []);

  // Handle schedule generation
  const handleGenerate = async () => {
    if (!modeOfPayment || aggregatedFees.length === 0) return;

    setIsGenerating(true);
    try {
      // Convert aggregated fees to the format expected by the backend
      const fees = aggregatedFees.map((fee) => ({
        feeId: undefined, // We don't track feeId in aggregated fees
        feeName: fee.feeName,
        feeCategory: fee.feeCategory,
        totalAmount: fee.totalAmount,
      }));

      await generateSchedule({
        applicationId,
        modeOfPayment,
        fees,
        startYear: startYear || new Date().getFullYear(),
      });
    } catch (error) {
      console.error("Failed to generate payment schedule:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  // Auto-generate schedule when mode of payment changes or fees change
  // Only triggers when:
  // 1. Mode of payment is selected
  // 2. Fees are available
  // 3. No existing schedule with payments made
  // 4. Not in readonly mode
  // 5. Not already generating
  useEffect(() => {
    // Skip if loading, readonly, or already generating
    if (isLoading || readOnly || isGenerating) return;

    // Skip if no mode of payment or no fees (use grandTotalFromFees for generation logic)
    if (!modeOfPayment || aggregatedFees.length === 0 || grandTotalFromFees === 0) return;

    // Check if this is an actual change (not initial render)
    const modeChanged = prevModeOfPaymentRef.current !== undefined &&
                        prevModeOfPaymentRef.current !== modeOfPayment;
    const feesChanged = prevFeesKeyRef.current !== "" &&
                        prevFeesKeyRef.current !== feesKey;

    // Update refs
    prevModeOfPaymentRef.current = modeOfPayment;
    prevFeesKeyRef.current = feesKey;

    // If schedule exists and has payments, don't auto-regenerate
    if (hasSchedule && totalPaid > 0) return;

    // Auto-generate if:
    // - No schedule exists and we have mode + fees (initial generation)
    // - Mode of payment changed (regenerate)
    // - Fees changed significantly (regenerate)
    // - Schedule fees are stale (don't match current aggregated fees)
    const shouldGenerate = !hasSchedule || modeChanged || feesChanged || isScheduleStale;

    if (shouldGenerate) {
      handleGenerate();
    }
  }, [modeOfPayment, feesKey, isLoading, readOnly, isGenerating, hasSchedule, totalPaid, grandTotalFromFees, aggregatedFees.length, isScheduleStale, scheduleFeesKey]);

  // Handle date change for a schedule section
  const handleDateChange = async (scheduleId: Id<"payment_schedules">, newDate: Date) => {
    if (!canEditPayments) return;
    try {
      await updateSectionDate({
        scheduleId,
        newDate: format(newDate, "yyyy-MM-dd"),
      });
    } catch (error) {
      console.error("Failed to update date:", error);
      const errorMessage = error instanceof Error ? error.message : "Failed to update due date";
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  // Handle fee amount edit
  const handleFeeAmountChange = async (
    scheduleId: Id<"payment_schedules">,
    feeIndex: number,
    newAmount: number
  ) => {
    if (!canEditPayments) return;
    try {
      await updateFeeAmount({
        scheduleId,
        feeIndex,
        newAmount,
        editedBy: "User", // TODO: Get actual user from auth context
      });
    } catch (error) {
      console.error("Failed to update fee amount:", error);
    }
  };

  // Handle surcharge change
  const handleSurchargeChange = async (
    scheduleId: Id<"payment_schedules">,
    newAmount: number
  ) => {
    if (!canEditPayments) return;
    try {
      await updateSurcharge({
        scheduleId,
        surcharge: newAmount,
      });
    } catch (error) {
      console.error("Failed to update surcharge:", error);
    }
  };

  // Handle penalty change
  const handlePenaltyChange = async (
    scheduleId: Id<"payment_schedules">,
    newAmount: number
  ) => {
    if (!canEditPayments) return;
    try {
      await updatePenalty({
        scheduleId,
        penalty: newAmount,
      });
    } catch (error) {
      console.error("Failed to update penalty:", error);
    }
  };

  // Auto-calculate surcharge and penalty based on configuration formulas
  // Returns { surcharge, penalty } or null if not applicable
  //
  // The section's stored dueDate is authoritative. It is editable per section
  // (see updateSectionDate), so it must not be re-derived from the surcharge
  // config, which holds only one date per payment mode and cannot address an
  // individual section.
  //
  // periodToPay comes from the actual number of sections rather than
  // modeOfPayment, so each section is charged against its own share of the tax
  // even when an application's mode and its section count disagree.
  const calculateSurchargeAndPenaltyForSchedule = useCallback((
    dueDate: string,
    Tax: number,
    sectionCount: number
  ): { surcharge: number; penalty: number } | null => {
    if (!surchargeConfig) {
      return null;
    }

    // Check if any formulas are configured
    if (!surchargeConfig.surchargeFormula && !surchargeConfig.penaltyFormula) {
      return null;
    }

    const periodToPay: 1 | 2 | 4 =
      sectionCount === 1 ? 1 : sectionCount === 2 ? 2 : 4;

    const { surcharge, penalty } = calculateSurchargeAndPenalty(
      {
        surchargeFormula: surchargeConfig.surchargeFormula,
        penaltyFormula: surchargeConfig.penaltyFormula,
      },
      {
        Tax,
        periodToPay,
        dueDate: parseISO(dueDate),
        paymentDate: new Date(),
      }
    );

    return { surcharge, penalty };
  }, [surchargeConfig]);

  // Auto-calculate surcharge and penalty when page loads
  useEffect(() => {
    if (!schedules || schedules.length === 0 || !surchargeConfig || readOnly) return;

    // Only auto-calculate for pending schedules that haven't been manually edited
    const pendingSchedules = schedules.filter((s: NonNullable<typeof schedules>[number]) => s.status === "pending");
    if (pendingSchedules.length === 0) return;

    // Check if formulas are configured
    if (!surchargeConfig.surchargeFormula && !surchargeConfig.penaltyFormula) return;

    // Auto-calculate for each pending schedule
    pendingSchedules.forEach(async (schedule: NonNullable<typeof schedules>[number]) => {
      // Calculate total Tax from Tax category fees
      const taxTotal = schedule.fees
        .filter((fee: ScheduleFee) => fee.feeCategory === "Tax")
        .reduce((sum: number, fee: ScheduleFee) => sum + fee.originalAmount, 0);

      const result = calculateSurchargeAndPenaltyForSchedule(schedule.dueDate, taxTotal, schedules.length);
      if (result) {
        // Only update if values are different to avoid infinite loops
        if (schedule.surcharge !== result.surcharge) {
          await updateSurcharge({ scheduleId: schedule._id, surcharge: result.surcharge });
        }
        if (schedule.penalty !== result.penalty) {
          await updatePenalty({ scheduleId: schedule._id, penalty: result.penalty });
        }
      }
    });
  }, [schedules, surchargeConfig, readOnly, calculateSurchargeAndPenaltyForSchedule, updateSurcharge, updatePenalty]);

  // Open payment dialog
  const handleOpenPaymentDialog = (scheduleId: Id<"payment_schedules">, remainingAmount: number) => {
    setSelectedScheduleId(scheduleId);
    setPaymentAmount(remainingAmount.toFixed(2));
    setPaymentMethod("Cash");
    setReferenceNumber("");
    setReceiptNumber("");
    setPaymentRemarks("");
    setPaymentDialogOpen(true);
  };

  // Check if reference number is required (required for non-Cash payments)
  const isReferenceNumberRequired = paymentMethod !== "Cash";

  // Submit payment
  const handleSubmitPayment = async () => {
    if (!selectedScheduleId) return;

    const amount = parseFloat(paymentAmount);
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Validation Error",
        description: "Please enter a valid payment amount.",
        variant: "destructive",
      });
      return;
    }

    // Validate Receipt Number (always required)
    if (!receiptNumber.trim()) {
      toast({
        title: "Validation Error",
        description: "Receipt Number is required.",
        variant: "destructive",
      });
      return;
    }

    // Validate Reference Number (required for non-Cash payments)
    if (isReferenceNumberRequired && !referenceNumber.trim()) {
      toast({
        title: "Validation Error",
        description: `Reference Number is required for ${paymentMethod} payments.`,
        variant: "destructive",
      });
      return;
    }

    setIsSubmittingPayment(true);
    try {
      await recordPayment({
        scheduleId: selectedScheduleId,
        amount,
        paymentMethod,
        referenceNumber: referenceNumber || undefined,
        receiptNumber: receiptNumber,
        remarks: paymentRemarks || undefined,
        processedBy: "Admin", // TODO: Get actual user from auth context
      });

      setPaymentDialogOpen(false);
      toast({
        title: "Payment Recorded",
        description: "The payment has been recorded successfully.",
      });
    } catch (error) {
      console.error("Failed to record payment:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to record payment.",
        variant: "destructive",
      });
    } finally {
      setIsSubmittingPayment(false);
    }
  };

  // Handle void/cancel payment
  const handleVoidPayment = async () => {
    if (!selectedPaymentToVoid || !voidReason.trim()) return;

    setIsVoiding(true);
    try {
      const result = await voidPayment({
        paymentId: selectedPaymentToVoid.paymentId,
        reason: voidReason,
        processedBy: "Admin", // TODO: Get from auth context
      });

      setVoidDialogOpen(false);
      setSelectedPaymentToVoid(null);
      setVoidReason("");

      // Show appropriate toast based on whether demotion occurred
      if (result.applicationDemoted) {
        toast({
          title: "Permit Status Changed",
          description: `The permit has been changed to "Pending Payment" status. ${result.clearancesDeleted} clearance(s) were removed.`,
        });
        // Redirect to payment page after demotion
        router.push("/dashboard/permit-applications/payment");
      } else {
        toast({
          title: "Payment Cancelled",
          description: "The payment has been voided and the schedule updated.",
        });
      }
    } catch (error) {
      console.error("Failed to void payment:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to void payment",
        variant: "destructive",
      });
    } finally {
      setIsVoiding(false);
    }
  };

  // Handle opening receipt preview
  const handleOpenReceiptPreview = (scheduleId: Id<"payment_schedules">) => {
    setSelectedScheduleForReceipt(scheduleId);
    setReceiptPreviewOpen(true);
  };

  // Handle opening void dialog
  const handleOpenVoidDialog = (scheduleId: Id<"payment_schedules">) => {
    const payment = paymentsByScheduleId[scheduleId]?.find((p: PaymentArray[number]) => p.status === "completed");
    if (payment) {
      setSelectedPaymentToVoid({
        paymentId: payment._id as Id<"payments">,
        receiptNumber: payment.receiptNumber || payment.transactionNumber,
        amount: payment.amount,
      });
      setVoidDialogOpen(true);
    }
  };

  // Get section label based on mode of payment
  const getSectionLabel = (sectionNumber: number, total: number) => {
    if (total === 1) return "Full Payment";
    if (total === 2) return sectionNumber === 1 ? "1st Semester" : "2nd Semester";
    return `Q${sectionNumber}`;
  };

  // Render loading state
  if (isLoading) {
    return (
      <PermissionGuard
        resource="permit_applications:schedule_of_payments"
        action="read"
        fallback={
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Schedule of Payments
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 text-sm text-muted-foreground p-4 border rounded-md">
                <Lock className="h-4 w-4" />
                <span>You don't have permission to view payment schedules.</span>
              </div>
            </CardContent>
          </Card>
        }
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Schedule of Payments
            </CardTitle>
            <CardDescription>Loading payment schedule...</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
          </CardContent>
        </Card>
      </PermissionGuard>
    );
  }

  // Render waiting/generating state if no schedule exists
  if (!hasSchedule) {
    return (
      <PermissionGuard
        resource="permit_applications:schedule_of_payments"
        action="read"
        fallback={
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Schedule of Payments
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 text-sm text-muted-foreground p-4 border rounded-md">
                <Lock className="h-4 w-4" />
                <span>You don't have permission to view payment schedules.</span>
              </div>
            </CardContent>
          </Card>
        }
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Schedule of Payments
            </CardTitle>
            <CardDescription>
              {!modeOfPayment
                ? "Please select a mode of payment to generate the schedule."
                : isGenerating
                  ? "Generating payment schedule..."
                  : `Payment schedule based on ${modeOfPayment} payment mode.`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {modeOfPayment && aggregatedFees.length > 0 && grandTotalFromFees > 0 ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Total Fees:</span>
                  <span className="font-semibold">{formatCurrency(grandTotalFromFees)}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Payment Sections:</span>
                  <span className="font-semibold">
                    {modeOfPayment === "Annually" ? "1" : modeOfPayment === "Semi-Annually" ? "2" : "4"}
                  </span>
                </div>
                {isGenerating && (
                  <>
                    <Separator />
                    <div className="flex items-center justify-center gap-2 py-2 text-muted-foreground">
                      <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                      <span className="text-sm">Generating schedule...</span>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                {!modeOfPayment
                  ? "Select a mode of payment above to automatically generate the schedule."
                  : grandTotalFromFees === 0
                    ? "Waiting for fee calculations..."
                    : "No fees configured for this application."}
              </p>
            )}
          </CardContent>
        </Card>
      </PermissionGuard>
    );
  }

  // Render schedule sections
  return (
    <PermissionGuard
      resource="permit_applications:schedule_of_payments"
      action="read"
      fallback={
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Schedule of Payments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 text-sm text-muted-foreground p-4 border rounded-md">
              <Lock className="h-4 w-4" />
              <span>You don't have permission to view payment schedules.</span>
            </div>
          </CardContent>
        </Card>
      }
    >
      <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <DollarSign className="h-5 w-5" />
          Schedule of Payments
        </CardTitle>
        <CardDescription>
          {modeOfPayment} payment schedule with {schedules.length} section
          {schedules.length > 1 ? "s" : ""}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Schedule Sections */}
        {schedules.map((schedule: NonNullable<typeof schedules>[number]) => {
          const remainingAmount = schedule.totalAmount - schedule.paidAmount;
          const statusConfig = STATUS_CONFIG[schedule.status as string];
          const StatusIcon = statusConfig.icon;
          const isExpanded = expandedSections.has(schedule.sectionNumber);

          return (
            <Collapsible
              key={schedule._id}
              open={isExpanded}
              onOpenChange={() => toggleSection(schedule.sectionNumber)}
            >
              <div className="border rounded-lg">
                {/* Section Header */}
                <CollapsibleTrigger asChild>
                  <div className="flex items-center justify-between p-4 cursor-pointer hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-3">
                      <ChevronDown
                        className={cn(
                          "h-4 w-4 transition-transform",
                          isExpanded && "rotate-180"
                        )}
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">
                            {getSectionLabel(schedule.sectionNumber, schedules.length)}
                          </span>
                          <Badge
                            variant={statusConfig.variant === "success" ? "default" : statusConfig.variant === "warning" ? "secondary" : "outline"}
                            className={cn(
                              "text-xs",
                              statusConfig.variant === "success" && "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
                              statusConfig.variant === "warning" && "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400"
                            )}
                          >
                            <StatusIcon className="h-3 w-3 mr-1" />
                            {statusConfig.label}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Due: {format(parseISO(schedule.dueDate), "MMM d, yyyy")}
                        </div>
                        {/* Show receipt number(s) when paid */}
                        {(() => {
                          const schedulePayments = paymentsByScheduleId[schedule._id];
                          if (schedule.status !== "paid" || !schedulePayments || schedulePayments.length === 0) return null;
                          const receipts = schedulePayments
                            .filter((p: PaymentArray[number]) => p.status === "completed" && p.receiptNumber)
                            .map((p: PaymentArray[number]) => p.receiptNumber)
                            .join(", ");
                          return (
                            <div className="flex items-center gap-1 text-xs text-green-600 dark:text-green-400 mt-0.5">
                              <Receipt className="h-3 w-3" />
                              <span>{receipts || "No receipt"}</span>
                            </div>
                          );
                        })()}
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="font-semibold">{formatCurrency(schedule.totalAmount)}</div>
                        {schedule.paidAmount > 0 && (
                          <div className="text-xs text-muted-foreground">
                            Paid: {formatCurrency(schedule.paidAmount)}
                          </div>
                        )}
                      </div>
                      {schedule.status !== "paid" && !readOnly && (
                        (() => {
                          const canPay =
                            canRecordPayments &&
                            (applicationStatus === "Pending Payment" || applicationStatus === "Released");
                          const payButton = (
                            <Button
                              size="sm"
                              disabled={!canPay}
                              onClick={(e) => {
                                e.stopPropagation();
                                if (canPay) {
                                  handleOpenPaymentDialog(schedule._id, remainingAmount);
                                }
                              }}
                              className={!canPay ? "cursor-not-allowed opacity-50" : ""}
                            >
                              <CreditCard className="h-4 w-4 mr-1" />
                              Pay
                            </Button>
                          );

                          if (!canPay) {
                            const tooltipContent = !canRecordPayments
                              ? "You don't have permission to record payments"
                              : "Payment can only be made when application status is 'Pending Payment' or 'Released'";

                            return (
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <span tabIndex={0}>
                                      {payButton}
                                    </span>
                                  </TooltipTrigger>
                                  <TooltipContent side="left">
                                    <div className="flex items-center gap-2">
                                      {!canRecordPayments && <Lock className="h-4 w-4" />}
                                      <span>{tooltipContent}</span>
                                    </div>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            );
                          }

                          return payButton;
                        })()
                      )}
                      {/* Actions dropdown for paid periods */}
                      {schedule.status === "paid" && !readOnly && (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => e.stopPropagation()}
                              className="h-8 w-8 p-0"
                            >
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Open menu</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenReceiptPreview(schedule._id);
                              }}
                            >
                              <Printer className="h-4 w-4 mr-2" />
                              Print Receipt
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={(e) => {
                                e.stopPropagation();
                                if (canVoidPayments) {
                                  handleOpenVoidDialog(schedule._id);
                                }
                              }}
                              disabled={!canVoidPayments}
                              className={canVoidPayments ? "text-destructive focus:text-destructive" : ""}
                            >
                              {canVoidPayments ? (
                                <XCircle className="h-4 w-4 mr-2" />
                              ) : (
                                <Lock className="h-4 w-4 mr-2" />
                              )}
                              Cancel
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </div>
                  </div>
                </CollapsibleTrigger>

                {/* Section Content */}
                <CollapsibleContent>
                  <Separator />
                  <div className="p-4 space-y-3">
                    {/* Due Date Editor - Not editable when paid or lacking permission */}
                    <div className="flex items-center gap-2 mb-3">
                      <Label className="text-sm text-muted-foreground">Due Date:</Label>
                      {schedule.status === "paid" || !canEditPayments || readOnly ? (
                        <Button
                          variant="outline"
                          size="sm"
                          disabled
                          className="w-[180px] justify-start text-left font-normal cursor-not-allowed"
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {format(parseISO(schedule.dueDate), "MMM d, yyyy")}
                        </Button>
                      ) : (
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              className="w-[180px] justify-start text-left font-normal"
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {format(parseISO(schedule.dueDate), "MMM d, yyyy")}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={parseISO(schedule.dueDate)}
                              onSelect={(date) =>
                                date && handleDateChange(schedule._id, date)
                              }
                              autoFocus
                            />
                          </PopoverContent>
                        </Popover>
                      )}
                    </div>

                    {/* Fee List */}
                    <div className="space-y-2">
                      {schedule.fees.map((fee: ScheduleFee, feeIndex: number) => (
                        <div key={feeIndex}>
                          <div
                            className="flex items-center justify-between py-2 px-3 bg-muted/30 rounded-md"
                          >
                            <div className="flex items-center gap-2">
                              <span className="text-sm">{fee.feeName}</span>
                              <Badge
                                variant="secondary"
                                className={cn(
                                  "text-xs",
                                  CATEGORY_COLORS[fee.feeCategory as FeeCategory] || CATEGORY_COLORS["Other Charges"]
                                )}
                              >
                                {fee.feeCategory}
                              </Badge>
                              {fee.isEdited && (
                                <Badge variant="outline" className="text-xs">
                                  Edited
                                </Badge>
                              )}
                            </div>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₱</span>
                              <Input
                                type="text"
                                value={formatCurrency(fee.sectionAmount.toString())}
                                onChange={(e) => {
                                  const rawValue = parseCurrency(e.target.value);
                                  const numValue = Number.parseFloat(rawValue) || 0;
                                  if (numValue >= 0) {
                                    handleFeeAmountChange(schedule._id, feeIndex, numValue);
                                  }
                                }}
                                disabled={
                                  !canEditPayments ||
                                  schedule.status === "paid" ||
                                  readOnly
                                }
                                className={cn(
                                  "w-32 pl-7 pr-2 text-right font-semibold",
                                  (!canEditPayments || schedule.status === "paid" || readOnly) && "bg-muted/50 cursor-not-allowed"
                                )}
                              />
                            </div>
                          </div>
                          {!canEditPayments && schedule.status !== "paid" && !readOnly && (
                            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1 ml-3">
                              <Lock className="h-3 w-3" />
                              Payment editing restricted
                            </p>
                          )}
                        </div>
                      ))}

                      {/* Surcharge Row */}
                      <div className="flex items-center justify-between py-2 px-3 bg-orange-50 dark:bg-orange-900/20 rounded-md border border-orange-200 dark:border-orange-800">
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          <span className="text-sm font-medium text-orange-700 dark:text-orange-400">Surcharge</span>
                          <Popover>
                            <PopoverTrigger asChild>
                              <button type="button" className="focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-1 rounded">
                                <Info className="h-3.5 w-3.5 text-orange-500 hover:text-orange-700 cursor-pointer" />
                              </button>
                            </PopoverTrigger>
                            <PopoverContent side="top" className="w-80">
                              {surchargeConfig?.surchargeFormula ? (
                                <div className="space-y-3">
                                  <div>
                                    <p className="font-medium text-sm">Surcharge Formula</p>
                                    <p className="text-xs text-muted-foreground">Applied when payment is past due date</p>
                                  </div>
                                  <div className="bg-muted/50 rounded-md p-2">
                                    <code className="text-xs font-mono break-all">{surchargeConfig.surchargeFormula}</code>
                                  </div>
                                  <Link
                                    href="/dashboard/taxes-and-fees/surcharge-penalty"
                                    className="inline-flex items-center gap-1.5 text-xs text-orange-600 hover:text-orange-700 font-medium"
                                  >
                                    <ExternalLink className="h-3 w-3" />
                                    Configure Formula
                                  </Link>
                                </div>
                              ) : (
                                <div className="space-y-3">
                                  <p className="text-sm">No surcharge formula configured.</p>
                                  <Link
                                    href="/dashboard/taxes-and-fees/surcharge-penalty"
                                    className="inline-flex items-center gap-1.5 text-xs text-orange-600 hover:text-orange-700 font-medium"
                                  >
                                    <ExternalLink className="h-3 w-3" />
                                    Configure Formula
                                  </Link>
                                </div>
                              )}
                            </PopoverContent>
                          </Popover>
                        </div>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₱</span>
                          <Input
                            type="text"
                            value={formatCurrency((schedule.surcharge || 0).toString())}
                            onChange={(e) => {
                              const rawValue = parseCurrency(e.target.value);
                              const numValue = Number.parseFloat(rawValue) || 0;
                              if (numValue >= 0) {
                                handleSurchargeChange(schedule._id, numValue);
                              }
                            }}
                            disabled={!canEditPayments || schedule.status === "paid" || readOnly}
                            className={cn(
                              "w-32 pl-7 pr-2 text-right font-semibold",
                              (!canEditPayments || schedule.status === "paid" || readOnly) && "bg-muted/50 cursor-not-allowed"
                            )}
                          />
                        </div>
                      </div>

                      {/* Penalty Row */}
                      <div className="flex items-center justify-between py-2 px-3 bg-red-50 dark:bg-red-900/20 rounded-md border border-red-200 dark:border-red-800">
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          <span className="text-sm font-medium text-red-700 dark:text-red-400">Penalty</span>
                          <Popover>
                            <PopoverTrigger asChild>
                              <button type="button" className="focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-1 rounded">
                                <Info className="h-3.5 w-3.5 text-red-500 hover:text-red-700 cursor-pointer" />
                              </button>
                            </PopoverTrigger>
                            <PopoverContent side="top" className="w-80">
                              {surchargeConfig?.penaltyFormula ? (
                                <div className="space-y-3">
                                  <div>
                                    <p className="font-medium text-sm">Penalty Formula</p>
                                    <p className="text-xs text-muted-foreground">Applied when payment is past due date</p>
                                  </div>
                                  <div className="bg-muted/50 rounded-md p-2">
                                    <code className="text-xs font-mono break-all">{surchargeConfig.penaltyFormula}</code>
                                  </div>
                                  <Link
                                    href="/dashboard/taxes-and-fees/surcharge-penalty"
                                    className="inline-flex items-center gap-1.5 text-xs text-red-600 hover:text-red-700 font-medium"
                                  >
                                    <ExternalLink className="h-3 w-3" />
                                    Configure Formula
                                  </Link>
                                </div>
                              ) : (
                                <div className="space-y-3">
                                  <p className="text-sm">No penalty formula configured.</p>
                                  <Link
                                    href="/dashboard/taxes-and-fees/surcharge-penalty"
                                    className="inline-flex items-center gap-1.5 text-xs text-red-600 hover:text-red-700 font-medium"
                                  >
                                    <ExternalLink className="h-3 w-3" />
                                    Configure Formula
                                  </Link>
                                </div>
                              )}
                            </PopoverContent>
                          </Popover>
                        </div>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₱</span>
                          <Input
                            type="text"
                            value={formatCurrency((schedule.penalty || 0).toString())}
                            onChange={(e) => {
                              const rawValue = parseCurrency(e.target.value);
                              const numValue = Number.parseFloat(rawValue) || 0;
                              if (numValue >= 0) {
                                handlePenaltyChange(schedule._id, numValue);
                              }
                            }}
                            disabled={!canEditPayments || schedule.status === "paid" || readOnly}
                            className={cn(
                              "w-32 pl-7 pr-2 text-right font-semibold",
                              (!canEditPayments || schedule.status === "paid" || readOnly) && "bg-muted/50 cursor-not-allowed"
                            )}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Section Total */}
                    <Separator />
                    <div className="flex items-center justify-between font-semibold">
                      <span>Section Total:</span>
                      <span>{formatCurrency(schedule.totalAmount)}</span>
                    </div>
                    {schedule.paidAmount > 0 && (
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <span>Paid:</span>
                        <span>{formatCurrency(schedule.paidAmount)}</span>
                      </div>
                    )}
                    {remainingAmount > 0 && (
                      <div className="flex items-center justify-between text-sm text-destructive">
                        <span>Remaining:</span>
                        <span>{formatCurrency(remainingAmount)}</span>
                      </div>
                    )}
                  </div>
                </CollapsibleContent>
              </div>
            </Collapsible>
          );
        })}

        {/* Grand Total Summary */}
        <Separator />
        <div className="space-y-2">
          <div className="flex items-center justify-between font-semibold text-lg">
            <span>Grand Total:</span>
            <span>{formatCurrency(grandTotal)}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Total Paid:</span>
            <span className="text-green-600 dark:text-green-400 font-medium">
              {formatCurrency(totalPaid)}
            </span>
          </div>
          {remainingBalance > 0 && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Remaining Balance:</span>
              <span className="text-destructive font-medium">
                {formatCurrency(remainingBalance)}
              </span>
            </div>
          )}
        </div>
      </CardContent>

      {/* Payment Dialog */}
      <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Record Payment</DialogTitle>
            <DialogDescription>
              Enter the payment details to record a manual payment.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₱</span>
                <Input
                  id="amount"
                  type="text"
                  value={paymentAmount ? formatCurrency(paymentAmount) : ""}
                  readOnly
                  disabled
                  className="pl-7 bg-muted/50 cursor-not-allowed font-semibold"
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Amount is fixed based on the remaining balance
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="paymentMethod">Payment Method</Label>
              <Select value={paymentMethod} onValueChange={(v) => setPaymentMethod(v as PaymentMethod)}>
                <SelectTrigger id="paymentMethod">
                  <SelectValue placeholder="Select payment method" />
                </SelectTrigger>
                <SelectContent>
                  {PAYMENT_METHODS.map((method) => (
                    <SelectItem key={method.value} value={method.value}>
                      {method.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="referenceNumber">
                Reference Number {isReferenceNumberRequired ? <span className="text-destructive">*</span> : "(Optional)"}
              </Label>
              <Input
                id="referenceNumber"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                placeholder="e.g., Bank transaction ID"
                className={isReferenceNumberRequired && !referenceNumber.trim() ? "border-destructive" : ""}
              />
              {isReferenceNumberRequired && (
                <p className="text-xs text-muted-foreground">
                  Required for {paymentMethod} payments
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="receiptNumber">
                Receipt Number <span className="text-destructive">*</span>
              </Label>
              <Input
                id="receiptNumber"
                value={receiptNumber}
                onChange={(e) => setReceiptNumber(e.target.value)}
                placeholder="e.g., OR-2025-0001"
                className={!receiptNumber.trim() ? "border-destructive" : ""}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="remarks">Remarks (Optional)</Label>
              <Textarea
                id="remarks"
                value={paymentRemarks}
                onChange={(e) => setPaymentRemarks(e.target.value)}
                placeholder="Add any notes about this payment"
                rows={2}
              />
            </div>
            {/* Auto-mark confirmation for zero-total sections */}
            {checkAutoMark?.willAutoMark && (
              <div className="bg-blue-50 border border-blue-200 rounded-md p-3 space-y-1">
                <div className="flex items-center gap-2">
                  <Info className="h-4 w-4 text-blue-600" />
                  <p className="text-sm text-blue-700 font-medium">
                    Additional periods will be marked as paid
                  </p>
                </div>
                <p className="text-sm text-blue-600">
                  The following {checkAutoMark.count} period(s) have ₱0.00 total and will be automatically marked as paid:{" "}
                  <span className="font-medium">
                    {checkAutoMark.zeroTotalSections.map((s: { label: string }) => s.label).join(", ")}
                  </span>
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setPaymentDialogOpen(false)}
              disabled={isSubmittingPayment}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmitPayment}
              disabled={
                isSubmittingPayment ||
                !receiptNumber.trim() ||
                (isReferenceNumberRequired && !referenceNumber.trim())
              }
            >
              {isSubmittingPayment ? "Recording..." : "Record Payment"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Void Payment Confirmation Dialog */}
      <Dialog open={voidDialogOpen} onOpenChange={setVoidDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Cancel Payment</DialogTitle>
            <DialogDescription>
              Are you sure you want to cancel this payment? This action will:
            </DialogDescription>
          </DialogHeader>
          <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1 pl-2">
            <li>Void the payment record</li>
            <li>Reverse the paid amount from the schedule</li>
            <li>Change the schedule status back to pending</li>
          </ul>
          {selectedPaymentToVoid && (
            <div className="py-4 space-y-3">
              <div className="bg-muted/50 rounded-md p-3 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Receipt:</span>
                  <span className="font-medium">{selectedPaymentToVoid.receiptNumber}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Amount:</span>
                  <span className="font-medium">{formatCurrency(selectedPaymentToVoid.amount)}</span>
                </div>
              </div>

              {/* Warning when demotion will occur */}
              {checkVoidDemotion?.willDemote && (
                <div className="bg-destructive/10 border border-destructive rounded-md p-3 space-y-1">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-destructive" />
                    <p className="text-sm text-destructive font-medium">
                      Warning: This action will change the permit status
                    </p>
                  </div>
                  <p className="text-sm text-destructive/90">
                    Cancelling this payment will result in 0 total payments. The permit status
                    will be changed from &quot;Released&quot; to &quot;Pending Payment&quot; and {checkVoidDemotion.clearancesCount} clearance
                    record(s) will be deleted.
                  </p>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="voidReason">
                  Reason for cancellation <span className="text-destructive">*</span>
                </Label>
                <Textarea
                  id="voidReason"
                  value={voidReason}
                  onChange={(e) => setVoidReason(e.target.value)}
                  placeholder="Enter reason for voiding this payment..."
                  rows={3}
                  className={!voidReason.trim() ? "border-destructive" : ""}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setVoidDialogOpen(false);
                setSelectedPaymentToVoid(null);
                setVoidReason("");
              }}
              disabled={isVoiding}
            >
              Keep Payment
            </Button>
            <Button
              variant="destructive"
              onClick={handleVoidPayment}
              disabled={isVoiding || !voidReason.trim()}
            >
              {isVoiding ? "Cancelling..." : "Confirm Cancellation"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Payment Receipt Preview Modal - Conditional rendering with key for hard reset */}
      {receiptPreviewOpen && selectedScheduleForReceipt && (
        <PaymentReceiptModal
          key={selectedScheduleForReceipt}
          open={receiptPreviewOpen}
          onClose={() => {
            setReceiptPreviewOpen(false);
            setSelectedScheduleForReceipt(null);
          }}
          payment={(() => {
            const payment = paymentsByScheduleId[selectedScheduleForReceipt]?.find(
              (p: PaymentArray[number]) => p.status === "completed"
            );
            return payment
              ? {
                  _id: payment._id as Id<"payments">,
                  receiptNumber: payment.receiptNumber,
                  transactionNumber: payment.transactionNumber,
                  amount: payment.amount,
                  paymentMethod: payment.paymentMethod,
                  referenceNumber: payment.referenceNumber,
                  paidAt: payment.paidAt,
                }
              : null;
          })()}
          schedule={schedules?.find((s: NonNullable<typeof schedules>[number]) => s._id === selectedScheduleForReceipt) || null}
          applicationNumber={applicationNumber || "N/A"}
          businessName={businessName}
          businessOwnerName={businessOwnerName}
          totalSections={schedules?.length || 1}
        />
      )}
      </Card>
    </PermissionGuard>
  );
}
