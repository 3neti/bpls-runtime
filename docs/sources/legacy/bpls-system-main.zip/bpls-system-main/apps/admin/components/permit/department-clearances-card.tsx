/**
 * Clearances Card Component
 *
 * Displays required clearances for a permit application with:
 * - List of clearances with status badges and fees
 * - Clickable items to view clearance details in modal
 * - Info icon linking to clearances management page
 * - Progress bar showing completion percentage
 * - Status indicators: Approved, Pending, Not Started
 * - Total clearance fees summary at the bottom
 *
 * This component uses a clearance-first architecture where departments
 * are metadata of clearances, not primary entities.
 */

"use client"

import { useState } from "react"
import Link from "next/link"
import { Shield, FileText, CheckCircle, Clock, AlertCircle, ExternalLink } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"
import { Button } from "@repo/ui/components/button"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import { formatCurrency } from "@/lib/utils/formatting"
import { ClearanceDetailModal } from "../permits/clearance-detail-modal"
import type { Clearance, ClearanceStatistics } from "@/lib/types/clearance"

/**
 * Format number as Philippine Peso currency with symbol
 */
function formatCurrencyWithSymbol(amount: number | undefined): string {
  if (!amount) return formatCurrency(0, { withSymbol: true })
  return formatCurrency(amount, { withSymbol: true })
}

export interface DepartmentClearancesCardProps {
  /** List of required clearances for the permit */
  clearances: Clearance[]
}

/**
 * Calculate clearance statistics
 */
function calculateStatistics(clearances: Clearance[]): ClearanceStatistics {
  const total = clearances.length
  const approved = clearances.filter((c) => c.status === 'approved').length
  const pending = clearances.filter((c) => c.status === 'pending').length
  const notStarted = clearances.filter((c) => c.status === 'not_started').length
  const completionPercentage = total > 0 ? (approved / total) * 100 : 0

  return { total, approved, pending, notStarted, completionPercentage }
}

/**
 * Calculate total fees from all clearances
 * Supports both multi-fee (new) and single fee (legacy) structures
 */
function calculateTotalFees(clearances: Clearance[]): number {
  return clearances.reduce((total, clearance) => {
    // Use new multi-fee structure if available
    if (clearance.totalAmount !== undefined) {
      return total + clearance.totalAmount
    }
    // Fall back to legacy single fee
    return total + (clearance.fee || 0)
  }, 0)
}

/**
 * Get status badge configuration
 */
function getStatusBadge(status: Clearance['status']) {
  switch (status) {
    case 'approved':
      return {
        variant: 'default' as const,
        className: 'bg-green-100 text-green-800 hover:bg-green-100',
        icon: CheckCircle,
        label: 'Approved',
      }
    case 'pending':
      return {
        variant: 'secondary' as const,
        className: 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100',
        icon: Clock,
        label: 'Pending',
      }
    case 'not_started':
      return {
        variant: 'secondary' as const,
        className: 'bg-gray-100 text-gray-600 hover:bg-gray-100',
        icon: AlertCircle,
        label: 'Not Started',
      }
  }
}

export function DepartmentClearancesCard({ clearances }: DepartmentClearancesCardProps) {
  const [selectedClearance, setSelectedClearance] = useState<Clearance | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const stats = calculateStatistics(clearances)
  const totalFees = calculateTotalFees(clearances)

  const handleClearanceClick = (clearance: Clearance) => {
    setSelectedClearance(clearance)
    setIsModalOpen(true)
  }

  const handleCloseModal = () => {
    setIsModalOpen(false)
    setSelectedClearance(null)
  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Required Clearances
              </CardTitle>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Link href="/dashboard/clearances">
                      <Button variant="ghost" size="icon" className="h-7 w-7">
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                        <span className="sr-only">Visit Clearances page</span>
                      </Button>
                    </Link>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Visit Clearances page to manage clearance requirements</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
          <CardDescription>
            All required clearances must be approved before final permit approval
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {clearances.map((clearance) => {
              const statusBadge = getStatusBadge(clearance.status)
              const StatusIcon = statusBadge.icon

              // Check for multi-fee structure (new) or single fee (legacy)
              const hasMultiFees = clearance.status === 'approved' && clearance.fees && clearance.fees.length > 0
              const hasSingleFee = clearance.status === 'approved' && clearance.fee && !hasMultiFees
              const displayAmount = hasMultiFees ? clearance.totalAmount : clearance.fee

              return (
                <button
                  key={clearance.id}
                  onClick={() => handleClearanceClick(clearance)}
                  className="w-full p-3 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer text-left"
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`p-2 rounded-full flex-shrink-0 ${
                        clearance.status === 'approved'
                          ? 'bg-green-100'
                          : clearance.status === 'pending'
                            ? 'bg-yellow-100'
                            : 'bg-gray-100'
                      }`}
                    >
                      <FileText
                        className={`h-4 w-4 ${
                          clearance.status === 'approved'
                            ? 'text-green-600'
                            : clearance.status === 'pending'
                              ? 'text-yellow-600'
                              : 'text-gray-600'
                        }`}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <div className="flex-1 min-w-0">
                          <h6 className="font-medium text-sm truncate">
                            {clearance.certificateName}
                          </h6>
                          <p className="text-xs text-muted-foreground truncate">
                            {clearance.department.name}
                          </p>
                        </div>
                        <Badge
                          variant={statusBadge.variant}
                          className={`${statusBadge.className} flex-shrink-0`}
                        >
                          <StatusIcon className="mr-1 h-3 w-3" />
                          {statusBadge.label}
                        </Badge>
                      </div>

                      {/* Multi-fee breakdown display */}
                      {hasMultiFees && (
                        <div className="mt-2 space-y-1">
                          <p className="text-xs font-medium text-muted-foreground">Fee Breakdown:</p>
                          <div className="space-y-0.5">
                            {clearance.fees!.map((fee, index) => (
                              <div key={index} className="flex items-center justify-between text-xs">
                                <span className="text-muted-foreground truncate">{fee.feeName}</span>
                                <span className="font-medium ml-2">{formatCurrencyWithSymbol(fee.appliedAmount)}</span>
                              </div>
                            ))}
                          </div>
                          <div className="flex items-center justify-between text-xs pt-1 border-t">
                            <span className="font-medium">Total:</span>
                            <span className="font-semibold">{formatCurrencyWithSymbol(displayAmount || 0)}</span>
                          </div>
                        </div>
                      )}

                      {/* Single fee display (legacy) */}
                      {hasSingleFee && (
                        <p className="text-xs text-muted-foreground mt-1">
                          Fee: <span className="font-medium">{formatCurrencyWithSymbol(clearance.fee)}</span>
                        </p>
                      )}
                    </div>
                  </div>
                </button>
              )
            })}
          </div>

          {/* Statistics Summary */}
          <div className="mt-4 p-3 bg-muted/30 rounded-lg space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium">Progress:</span>
              <span className="font-medium">
                {stats.approved} of {stats.total} approved
              </span>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-green-600 h-2 rounded-full transition-all duration-300"
                style={{
                  width: `${stats.completionPercentage}%`,
                }}
              />
            </div>

            {/* Status Breakdown */}
            <div className="grid grid-cols-3 gap-2 text-xs text-muted-foreground">
              <div className="flex items-center gap-1">
                <CheckCircle className="h-3 w-3 text-green-600" />
                <span>{stats.approved} Approved</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3 text-yellow-600" />
                <span>{stats.pending} Pending</span>
              </div>
              <div className="flex items-center gap-1">
                <AlertCircle className="h-3 w-3 text-gray-600" />
                <span>{stats.notStarted} Not Started</span>
              </div>
            </div>
          </div>

          {/* Total Fees Summary */}
          <div className="mt-4 pt-4 border-t">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold">Total Clearance Fees:</span>
              <span className="text-lg font-bold text-primary">{formatCurrencyWithSymbol(totalFees)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Clearance Detail Modal */}
      <ClearanceDetailModal
        clearance={selectedClearance}
        open={isModalOpen}
        onClose={handleCloseModal}
      />
    </>
  )
}
