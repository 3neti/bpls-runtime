"use client";

import { useState, useRef, useCallback } from "react";
import { useMutation, useQuery } from "convex/react";
import { Palette, Upload, Trash2, Loader2, ImageIcon, Lock } from "lucide-react";
import { usePermissions } from "@/hooks/use-permissions";
import { Button } from "@repo/ui/components/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import { Separator } from "@repo/ui/components/separator";
import { Badge } from "@repo/ui/components/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@repo/ui/components/alert-dialog";
import { cn } from "@/lib/utils";
import { api } from "@repo/backend/convex/_generated/api";

interface BrandingSectionProps {
  settings: NonNullable<ReturnType<typeof useQuery<typeof api.platformSettings.get>>>;
  logoUrl: string | null | undefined;
  landingImageUrl: string | null | undefined;
  municipalSealUrl: string | null | undefined;
  toast: (options: { title: string; description: string; variant?: "default" | "destructive" }) => void;
}

export function BrandingSection({ logoUrl, landingImageUrl, municipalSealUrl, toast }: BrandingSectionProps) {
  const { canUpdate, isLoading: permissionsLoading } = usePermissions();
  const canEdit = canUpdate("settings:branding");

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Palette className="h-5 w-5" />
          Branding Assets
          {!canEdit && !permissionsLoading && (
            <Badge variant="secondary" className="ml-2 gap-1">
              <Lock className="h-3 w-3" />
              Read Only
            </Badge>
          )}
          {canEdit && (
            <Badge variant="outline" className="ml-2">
              Admin Only
            </Badge>
          )}
        </CardTitle>
        <CardDescription>
          Customize your platform&apos;s visual identity for white-label deployments
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-8">
        {/* Platform Logo */}
        <ImageUploadRow
          imageType="logo"
          title="Platform Logo"
          description="Appears in the navigation bar and login page. Square format recommended."
          currentUrl={logoUrl}
          toast={toast}
          previewSize="small"
          maxSize="2 MB"
          disabled={!canEdit || permissionsLoading}
        />

        <Separator />

        {/* Municipal Seal */}
        <ImageUploadRow
          imageType="municipalSeal"
          title="Municipal Seal"
          description="Official seal used in permits, receipts, and documents. Square format recommended."
          currentUrl={municipalSealUrl}
          toast={toast}
          previewSize="small"
          maxSize="2 MB"
          disabled={!canEdit || permissionsLoading}
        />

        <Separator />

        {/* Landing Page Image */}
        <ImageUploadRow
          imageType="landingImage"
          title="Landing Page Hero"
          description="Background image for the login page. Recommended: 1920×1080px."
          currentUrl={landingImageUrl}
          toast={toast}
          previewSize="large"
          maxSize="5 MB"
          disabled={!canEdit || permissionsLoading}
        />
      </CardContent>
    </Card>
  );
}

// Image Upload Row Component
interface ImageUploadRowProps {
  imageType: "logo" | "landingImage" | "municipalSeal";
  title: string;
  description: string;
  currentUrl: string | null | undefined;
  toast: (options: { title: string; description: string; variant?: "default" | "destructive" }) => void;
  previewSize: "small" | "large";
  maxSize: string;
  disabled?: boolean;
}

function ImageUploadRow({
  imageType,
  title,
  description,
  currentUrl,
  toast,
  previewSize,
  maxSize,
  disabled = false,
}: ImageUploadRowProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const generateUploadUrl = useMutation(api.platformSettings.generateUploadUrl);
  const updateSettings = useMutation(api.platformSettings.update);
  const deleteImage = useMutation(api.platformSettings.deleteImage);

  const handleFile = useCallback(
    async (file: File) => {
      if (!file.type.startsWith("image/")) {
        toast({
          title: "Invalid file type",
          description: "Please upload an image file (PNG, JPG, etc.)",
          variant: "destructive",
        });
        return;
      }

      const maxBytes = imageType === "landingImage" ? 5 * 1024 * 1024 : 2 * 1024 * 1024;
      if (file.size > maxBytes) {
        toast({
          title: "File too large",
          description: `Please upload an image smaller than ${maxSize}`,
          variant: "destructive",
        });
        return;
      }

      setIsUploading(true);
      try {
        const uploadUrl = await generateUploadUrl({});
        const response = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": file.type },
          body: file,
        });

        if (!response.ok) throw new Error("Upload failed");

        const { storageId } = await response.json();
        const updateArgMap = {
          logo: { logoStorageId: storageId },
          landingImage: { landingImageStorageId: storageId },
          municipalSeal: { municipalSealStorageId: storageId },
        };
        await updateSettings(updateArgMap[imageType]);

        const imageNameMap = {
          logo: "logo",
          landingImage: "landing page image",
          municipalSeal: "municipal seal",
        };
        toast({
          title: "Image uploaded",
          description: `Your ${imageNameMap[imageType]} has been updated.`,
        });
      } catch {
        toast({
          title: "Upload failed",
          description: "Failed to upload image. Please try again.",
          variant: "destructive",
        });
      } finally {
        setIsUploading(false);
      }
    },
    [generateUploadUrl, updateSettings, imageType, maxSize, toast]
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const file = e.dataTransfer.files[0];
      if (file) handleFile(file);
    },
    [handleFile]
  );

  const handleDelete = async () => {
    try {
      await deleteImage({ imageType });
      const imageNameMap = {
        logo: "logo",
        landingImage: "landing page image",
        municipalSeal: "municipal seal",
      };
      toast({
        title: "Image removed",
        description: `The ${imageNameMap[imageType]} has been removed.`,
      });
    } catch {
      toast({
        title: "Error",
        description: "Failed to remove image. Please try again.",
        variant: "destructive",
      });
    }
  };

  // No default fallbacks - show placeholders when no image is configured
  const displayUrl = currentUrl;
  const hasCustomImage = currentUrl !== null && currentUrl !== undefined;

  return (
    <div className="flex flex-col sm:flex-row gap-6">
      {/* Left: Preview */}
      <div className="shrink-0">
        <div
          className={cn(
            "relative overflow-hidden rounded-lg border-2 bg-muted/50 flex items-center justify-center",
            previewSize === "small" ? "h-24 w-24" : "h-32 w-48"
          )}
        >
          {displayUrl ? (
            <img
              src={displayUrl}
              alt={title}
              className={cn(
                "h-full w-full",
                previewSize === "small" ? "object-contain p-2" : "object-cover"
              )}
            />
          ) : (
            <div className="flex flex-col items-center justify-center text-muted-foreground">
              <ImageIcon className="h-8 w-8 mb-1" />
              <span className="text-xs">No image</span>
            </div>
          )}
        </div>
      </div>

      {/* Right: Info + Actions */}
      <div className="flex-1 min-w-0 space-y-3">
        <div>
          <h4 className="font-medium text-sm">{title}</h4>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>

        {/* Compact upload zone */}
        <div
          className={cn(
            "relative rounded-md border border-dashed px-4 py-3 transition-colors",
            disabled
              ? "opacity-50 cursor-not-allowed"
              : "cursor-pointer",
            !disabled && isDragging
              ? "border-primary bg-primary/5"
              : !disabled
                ? "border-muted-foreground/30 hover:border-primary/50 hover:bg-muted/50"
                : "border-muted-foreground/30",
            isUploading && "pointer-events-none opacity-50"
          )}
          onDragOver={(e) => {
            e.preventDefault();
            if (!disabled) setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={(e) => !disabled && handleDrop(e)}
          onClick={() => !isUploading && !disabled && fileInputRef.current?.click()}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            disabled={disabled}
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) handleFile(file);
            }}
          />

          <div className="flex items-center gap-3">
            {isUploading ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin text-primary" />
                <span className="text-sm text-muted-foreground">Uploading...</span>
              </>
            ) : (
              <>
                <Upload className="h-5 w-5 text-muted-foreground" />
                <div className="text-sm">
                  <span className="text-primary font-medium">Click to upload</span>
                  <span className="text-muted-foreground"> or drag and drop</span>
                </div>
                <span className="text-xs text-muted-foreground ml-auto hidden sm:inline">
                  Max {maxSize}
                </span>
              </>
            )}
          </div>
        </div>

        {/* Remove button - only show when user can edit */}
        {hasCustomImage && !disabled && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-8 px-2 text-xs text-muted-foreground hover:text-destructive"
              >
                <Trash2 className="mr-1.5 h-3.5 w-3.5" />
                Remove custom image
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Remove image?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will remove the custom {imageType === "logo" ? "logo" : "landing page image"} and
                  revert to the default image.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete}>Remove</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>
    </div>
  );
}
