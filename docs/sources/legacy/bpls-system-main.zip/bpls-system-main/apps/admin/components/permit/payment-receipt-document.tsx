"use client";

import React from "react";
import { Document, Page, Text, View, StyleSheet } from "@react-pdf/renderer";

// Types for payment receipt data
export interface PaymentReceiptFee {
  feeName: string;
  feeCategory: string;
  amount: number;
}

export interface PaymentReceiptData {
  receiptNumber: string;
  transactionNumber: string;
  date: string;
  amount: number;
  paymentMethod: string;
  referenceNumber?: string;

  // Schedule info
  periodLabel: string;
  dueDate: string;
  fees: PaymentReceiptFee[];
  totalAmount: number;
  surcharge?: number;
  penalty?: number;

  // Application info
  applicationNumber: string;
  businessName?: string;
  businessOwnerName?: string;

  printDate: string;

  // Settings - optional, uses defaults if not provided
  fullAddress?: string; // e.g., "IPIL, ZAMBOANGA SIBUGAY"
}

// Convert number to words helper
const numberToWords = (amount: number): { line1: string; line2: string } => {
  const ones = [
    "",
    "One",
    "Two",
    "Three",
    "Four",
    "Five",
    "Six",
    "Seven",
    "Eight",
    "Nine",
    "Ten",
    "Eleven",
    "Twelve",
    "Thirteen",
    "Fourteen",
    "Fifteen",
    "Sixteen",
    "Seventeen",
    "Eighteen",
    "Nineteen",
  ];
  const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

  const convertHundreds = (num: number): string => {
    if (num === 0) return "";
    if (num < 20) return ones[num];
    if (num < 100) {
      return tens[Math.floor(num / 10)] + (num % 10 !== 0 ? " " + ones[num % 10] : "");
    }
    return ones[Math.floor(num / 100)] + " Hundred" + (num % 100 !== 0 ? " " + convertHundreds(num % 100) : "");
  };

  const convertThousands = (num: number): string => {
    if (num === 0) return "Zero";
    if (num < 1000) return convertHundreds(num);
    if (num < 1000000) {
      return (
        convertHundreds(Math.floor(num / 1000)) +
        " Thousand" +
        (num % 1000 !== 0 ? " " + convertHundreds(num % 1000) : "")
      );
    }
    if (num < 1000000000) {
      return (
        convertThousands(Math.floor(num / 1000000)) +
        " Million" +
        (num % 1000000 !== 0 ? " " + convertThousands(num % 1000000) : "")
      );
    }
    return (
      convertThousands(Math.floor(num / 1000000000)) +
      " Billion" +
      (num % 1000000000 !== 0 ? " " + convertThousands(num % 1000000000) : "")
    );
  };

  // Handle decimal part
  const wholePart = Math.floor(amount);
  const decimalPart = Math.round((amount - wholePart) * 100);

  const line1 = convertThousands(wholePart);
  let line2 = "Pesos";
  if (decimalPart > 0) {
    line2 += " And " + convertThousands(decimalPart) + " Cents";
  } else {
    line2 += " Only";
  }

  return { line1, line2 };
};

// Format currency without peso sign
const formatAmount = (amount: number): string => {
  return new Intl.NumberFormat("en-PH", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
};

// Format date/time as YYYY-MM-DD HH:MM:SS
const formatDateTime = (dateString: string): string => {
  try {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  } catch {
    return dateString;
  }
};

const styles = StyleSheet.create({
  page: {
    padding: 10,
    paddingTop: 120,
    paddingRight: 380,
    fontSize: 10,
    fontFamily: "Helvetica",
    backgroundColor: "#ffffff",
  },
  dateTime: {
    marginBottom: 12,
    fontSize: 10,
    marginLeft: 20,
  },
  location: {
    marginBottom: 12,
    fontSize: 10,
    marginLeft: 20,
  },
  ownerName: {
    marginBottom: 2,
    fontSize: 10,
    marginLeft: 20,
  },
  businessName: {
    marginBottom: 20,
    fontSize: 10,
    marginLeft: 20,
  },
  lineItemsContainer: {
    marginBottom: 20,
  },
  lineRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  lineDescription: {
    flex: 1,
    fontSize: 10,
  },
  lineAmount: {
    width: 70,
    textAlign: "right",
    fontSize: 10,
  },
  totalContainer: {
    marginTop: 30,
    alignItems: "flex-end",
  },
  totalAmount: {
    fontSize: 12,
    fontFamily: "Helvetica-Bold",
    textAlign: "right",
    marginBottom: 15,
  },
  amountInWordsContainer: {
    alignItems: "flex-end",
  },
  amountInWordsLine1: {
    fontSize: 10,
    textAlign: "right",
  },
  amountInWordsLine2: {
    fontSize: 10,
    textAlign: "right",
  },
});

interface PaymentReceiptDocumentProps {
  data: PaymentReceiptData;
}

// No default values - fullAddress must be configured in settings

export function PaymentReceiptDocument({ data }: PaymentReceiptDocumentProps) {
  const { date, fees, surcharge = 0, penalty = 0, amount, businessName, businessOwnerName, fullAddress = "" } = data;

  // Get amount in words split into two lines
  const amountWords = numberToWords(amount);

  return (
    <Document>
      {/* Half A4 width: A4 is 595 x 842 points, half width is ~297 points */}
      <Page size={{ width: 595, height: 842 }} style={styles.page}>
        {/* Date/Time */}
        <Text style={styles.dateTime}>{formatDateTime(date)}</Text>

        {/* Location */}
        <Text style={styles.location}>{fullAddress}</Text>

        {/* Owner Name */}
        {businessOwnerName && <Text style={styles.ownerName}>{businessOwnerName.toUpperCase()}</Text>}

        {/* Business Name */}
        {businessName && <Text style={styles.businessName}>{businessName.toUpperCase()}</Text>}

        {/* Line Items */}
        <View style={styles.lineItemsContainer}>
          {fees.map((fee, index) => (
            <View key={index} style={styles.lineRow}>
              <Text style={styles.lineDescription}>{fee.feeName}</Text>
              <Text style={styles.lineAmount}>{formatAmount(fee.amount)}</Text>
            </View>
          ))}

          {/* Surcharge if any */}
          {surcharge > 0 && (
            <View style={styles.lineRow}>
              <Text style={styles.lineDescription}>Surcharge</Text>
              <Text style={styles.lineAmount}>{formatAmount(surcharge)}</Text>
            </View>
          )}

          {/* Penalty if any */}
          {penalty > 0 && (
            <View style={styles.lineRow}>
              <Text style={styles.lineDescription}>Interest</Text>
              <Text style={styles.lineAmount}>{formatAmount(penalty)}</Text>
            </View>
          )}
        </View>

        {/* Total Amount */}
        <View style={styles.totalContainer}>
          <Text style={styles.totalAmount}>{formatAmount(amount)}</Text>
        </View>

        {/* Amount in Words */}
        <View style={styles.amountInWordsContainer}>
          <Text style={styles.amountInWordsLine1}>{amountWords.line1}</Text>
          <Text style={styles.amountInWordsLine2}>{amountWords.line2}</Text>
        </View>
      </Page>
    </Document>
  );
}
