"use client";

import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "convex/react";

import { api } from "@repo/backend/convex/_generated/api";
import { Button } from "@repo/ui/components/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@repo/ui/components/form";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select";
import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card";
import { DatePicker } from "@repo/ui/components/date-picker";
import { useToast } from "@/hooks/use-toast";
import { useLocationSelects } from "@/hooks/use-location-selects";
import { useDefaultLocations } from "@/hooks/use-default-locations";
import { useCategorySelects } from "@/hooks/use-category-selects";
import { businessFormSchema, businessFormDefaultValues, type BusinessFormSchema } from "@/lib/schemas/business-form";
import { OwnershipDocumentsField } from "@/components/businesses/ownership-documents-field";

import type { Id } from "@repo/backend/convex/_generated/dataModel";

interface CreateBusinessFormProps {
  ownerId: Id<"business_owners">;
  ownerType?: "Single" | "Group"; // NEW: Owner type for filtering ownership options
  onSuccess: () => void;
  onCancel: () => void;
}

export function CreateBusinessForm({ ownerId, ownerType, onSuccess, onCancel }: CreateBusinessFormProps) {
  const { toast } = useToast();
  const createBusiness = useMutation(api.businesses.create);

  // Get default locations from platform settings
  const { defaultProvinceId, defaultCityId, defaultBarangayId, isLoading: isLoadingDefaults } = useDefaultLocations();

  const form = useForm<BusinessFormSchema>({
    resolver: zodResolver(businessFormSchema),
    defaultValues: businessFormDefaultValues,
    mode: "onChange",
  });

  // Watch form values for cascading selects and conditional fields
  const formValues = form.watch();
  const ownershipType = formValues.ownershipType;

  // Cascading category selects hook
  const {
    categories,
    subCategories,
    isSubCategoryDisabled,
    handleCategoryChange,
    handleSubCategoryChange,
  } = useCategorySelects({
    initialCategoryId: formValues.categoryId || "",
    initialSubCategoryId: formValues.subCategoryId || "",
    onCategoryChange: (id) => form.setValue("categoryId", id),
    onSubCategoryChange: (id) => form.setValue("subCategoryId", id),
  });

  // Use the reusable location selects hook
  const {
    provinces,
    cities,
    barangays,
    isCityDisabled,
    isBarangayDisabled,
    handleProvinceChange,
    handleCityChange,
    handleBarangayChange,
    setSelections,
    setSelectedCityId,
  } = useLocationSelects({
    initialProvinceId: defaultProvinceId ?? "",
    initialCityId: defaultCityId ?? "",
    onProvinceChange: (id) => form.setValue("provinceId", id),
    onCityChange: (id) => form.setValue("cityId", id),
    onBarangayChange: (id) => form.setValue("barangayId", id),
  });

  // Apply all default locations at once when they finish loading
  // Using setSelections to avoid cascade clearing that happens with handleProvinceChange
  useEffect(() => {
    if (!isLoadingDefaults && defaultProvinceId && !form.getValues("provinceId")) {
      // Set all locations at once to avoid cascade clearing
      setSelections(
        defaultProvinceId,
        defaultCityId ?? "",
        defaultBarangayId ?? undefined
      );
    }
  }, [defaultProvinceId, defaultCityId, defaultBarangayId, isLoadingDefaults, form, setSelections]);

  // Apply default city when cities are loaded
  // This handles the case where city wasn't set initially because cities hadn't loaded yet
  useEffect(() => {
    if (!isLoadingDefaults && cities && cities.length > 0 && defaultCityId) {
      // Apply default city if province matches and city not already set
      if (!formValues.cityId && formValues.provinceId === defaultProvinceId) {
        // Verify the city belongs to the selected province
        const cityExists = cities.some((c: { _id: string }) => c._id === defaultCityId);
        if (cityExists) {
          form.setValue("cityId", defaultCityId);
          setSelectedCityId(defaultCityId);
        }
      }
    }
  }, [isLoadingDefaults, cities, defaultCityId, defaultProvinceId, formValues.cityId, formValues.provinceId, form, setSelectedCityId]);

  // Apply default barangay when barangays are loaded
  useEffect(() => {
    if (!isLoadingDefaults && barangays && barangays.length > 0 && defaultBarangayId) {
      // Apply default barangay if city matches and barangay not already set
      if (!formValues.barangayId && formValues.cityId === defaultCityId) {
        // Verify the barangay belongs to the selected city
        const barangayExists = barangays.some((b: { _id: string }) => b._id === defaultBarangayId);
        if (barangayExists) {
          form.setValue("barangayId", defaultBarangayId);
        }
      }
    }
  }, [isLoadingDefaults, barangays, defaultBarangayId, defaultCityId, formValues.barangayId, formValues.cityId, form]);

  // Helper function to filter ownership type options based on owner type
  const getOwnershipTypeOptions = () => {
    if (ownerType === "Single") {
      // Single owners can only have Sole Proprietorship
      return [
        <SelectItem key="sole-proprietorship" value="sole-proprietorship">
          Sole Proprietorship
        </SelectItem>,
      ];
    }

    // For "Group" or undefined, show all options
    return [
      <SelectItem key="sole-proprietorship" value="sole-proprietorship">
        Sole Proprietorship
      </SelectItem>,
      <SelectItem key="partnership" value="partnership">
        Partnership
      </SelectItem>,
      <SelectItem key="corporation" value="corporation">
        Corporation
      </SelectItem>,
      <SelectItem key="cooperative" value="cooperative">
        Cooperative
      </SelectItem>,
      <SelectItem key="religious" value="religious">
        Religious Organization
      </SelectItem>,
      <SelectItem key="non-profit" value="non-profit">
        Non-Profit / Non-Stock Organization
      </SelectItem>,
    ];
  };

  // Helper function to get registration date description based on ownership type
  const getRegistrationDateDescription = (ownershipType?: string): string => {
    const normalizedOwnershipType = ownershipType?.toLowerCase().replace(/\s+/g, "-");

    switch (normalizedOwnershipType) {
      case "sole-proprietorship":
        return "DTI Registration Date";
      case "partnership":
        return "CDA Registration Date";
      case "corporation":
        return "SEC Registration Date";
      case "cooperative":
        return "CDA Registration Date";
      case "religious":
        return "SEC Registration Date";
      case "non-profit":
        return "SEC Registration Date";
      default:
        return "Registration Date";
    }
  };

  // Document upload handlers
  const handleFileSelect = (documentType: string, file: File) => {
    const currentDocuments = formValues.documents || {};
    form.setValue("documents", {
      ...currentDocuments,
      [documentType]: { file, uploaded: true },
    });
  };

  const handleFileRemove = (documentType: string) => {
    const currentDocuments = formValues.documents || {};
    form.setValue("documents", {
      ...currentDocuments,
      [documentType]: { file: null, uploaded: false },
    });
  };

  // Auto-clear groupName when ownership type changes to types that don't require it
  useEffect(() => {
    const requiresGroupName = ["partnership", "corporation", "cooperative"].includes(ownershipType);
    if (!requiresGroupName && formValues.groupName) {
      form.setValue("groupName", "");
    }
  }, [ownershipType, formValues.groupName, form]);

  const handleSubmit = async (values: BusinessFormSchema) => {
    console.log("🚀 handleSubmit called with values:", values);

    try {
      console.log("📝 Validating required fields...");

      // Calculate total employees and business scale
      const totalEmployees = values.maleEmployeeCount + values.femaleEmployeeCount;
      let businessScale = "Micro";
      if (totalEmployees >= 200) {
        businessScale = "Large";
      } else if (totalEmployees >= 100) {
        businessScale = "Medium";
      } else if (totalEmployees >= 10) {
        businessScale = "Small";
      }

      console.log("📊 Calculated business scale:", businessScale, `(Total employees: ${totalEmployees})`);

      console.log("💾 Creating business in database...");
      const businessId = await createBusiness({
        name: values.businessName.trim(),
        ownerId: ownerId,
        businessArea: values.businessArea,
        propertyIndexNumber: values.propertyIndexNumber || undefined,
        businessScale: businessScale,
        annualRevenue: "0-100000", // Default for new businesses
        establishedDate: values.establishedDate || new Date().toISOString().split("T")[0],
        registrationDate: values.registrationDate || undefined,
        registrationNumber: values.registrationNumber || undefined,
        dateStarted: values.dateStarted,
        address: values.address.trim(),
        buildingName: values.buildingName || undefined,
        provinceId: values.provinceId as Id<"provinces">,
        cityId: values.cityId as Id<"cities">,
        barangayId: values.barangayId as Id<"barangays">,
        // lineOfBusiness field removed - businesses are created without lines of business
        // Lines of business should be added separately after business creation
        ownershipType: values.ownershipType,
        groupName: values.groupName || undefined, // Optional: Company/Organization name for Partnership/Corporation/Cooperative
        categoryId: values.categoryId ? values.categoryId as Id<"business_categories"> : undefined,
        subCategoryId: values.subCategoryId ? values.subCategoryId as Id<"business_subcategories"> : undefined,
        occupancy: values.occupancy || "rented",
        permitPaymentCadence: "annual",
        maleEmployeeCount: values.maleEmployeeCount,
        femaleEmployeeCount: values.femaleEmployeeCount,
        contactNumber: values.contactNumber || "",
        email: values.email || "",
        isBlacklisted: false,
      });

      console.log("✅ Business created successfully with ID:", businessId);

      toast({
        title: "Success",
        description: `Business "${values.businessName}" created successfully`,
      });

      onSuccess();
    } catch (error) {
      console.error("❌ Business creation error:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "An error occurred while creating the business",
        variant: "destructive",
      });
    }
  };

  const handleButtonClick = () => {
    console.log("🖱️ Submit button clicked");
    console.log("📋 Form state:", {
      isValid: form.formState.isValid,
      isSubmitting: form.formState.isSubmitting,
      errors: form.formState.errors,
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
        {/* Business Information */}
        <Card>
          <CardHeader>
            <CardTitle>Business Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="businessName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Business Name <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Enter business name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="businessArea"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Business Area (sqm.) <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="1"
                        step="0.01"
                        placeholder="Enter business area in square meters"
                        {...field}
                        value={field.value ?? 1}
                        onChange={(e) => field.onChange(Number(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="propertyIndexNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Property Index Number</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Enter property index number " />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="establishedDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date Established</FormLabel>
                    <FormControl>
                      <DatePicker
                        value={field.value || ""}
                        onChange={field.onChange}
                        placeholder="Select or type date (MM/DD/YYYY)"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="dateStarted"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Date Started <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <DatePicker
                        value={field.value || ""}
                        onChange={field.onChange}
                        placeholder="Select or type date (MM/DD/YYYY)"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="ownershipType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Ownership Type <span className="text-destructive">*</span>
                    </FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select ownership type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>{getOwnershipTypeOptions()}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Conditional Group Name Field - Only for Partnership, Corporation, Cooperative */}
              {["partnership", "corporation", "cooperative"].includes(formValues.ownershipType) && (
                <FormField
                  control={form.control}
                  name="groupName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        Company/Organization Name <span className="text-destructive">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Enter company or organization name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              <div className="space-y-3">
                <Label className="text-sm font-medium">Employee Count</Label>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="maleEmployeeCount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Male Employees</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min="0"
                            placeholder="0"
                            {...field}
                            value={field.value ?? 0}
                            onChange={(e) => field.onChange(Number(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="femaleEmployeeCount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Female Employees</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min="0"
                            placeholder="0"
                            {...field}
                            value={field.value ?? 0}
                            onChange={(e) => field.onChange(Number(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="bg-muted px-4 py-2 rounded-lg">
                  <p className="text-sm font-medium">
                    Total Employees: {(form.watch("maleEmployeeCount") || 0) + (form.watch("femaleEmployeeCount") || 0)}
                  </p>
                </div>
              </div>

              <FormField
                control={form.control}
                name="occupancy"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Occupancy</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select occupancy type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="rented">Rented</SelectItem>
                        <SelectItem value="owned">Owned</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <Card>
          <CardHeader>
            <CardTitle>Contact Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="contactNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Contact Number</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="+63 912 345 6789" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address</FormLabel>
                    <FormControl>
                      <Input {...field} type="email" placeholder="business@example.com" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </CardContent>
        </Card>

        {/* Address Information */}
        <Card>
          <CardHeader>
            <CardTitle>Business Address</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Street Address <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="House No., Street Name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="buildingName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Building Name <span className="text-destructive">*</span></FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Enter building name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="provinceId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Province <span className="text-destructive">*</span>
                    </FormLabel>
                    <Select value={field.value} onValueChange={handleProvinceChange}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select province" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {provinces?.map((province: { _id: string; name: string }) => (
                          <SelectItem key={province._id} value={province._id}>
                            {province.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="cityId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      City/Municipality <span className="text-destructive">*</span>
                    </FormLabel>
                    <Select value={field.value} onValueChange={handleCityChange} disabled={isCityDisabled}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select city/municipality" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {cities?.map((city: { _id: string; name: string }) => (
                          <SelectItem key={city._id} value={city._id}>
                            {city.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="barangayId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Barangay <span className="text-destructive">*</span>
                    </FormLabel>
                    <Select value={field.value} onValueChange={handleBarangayChange} disabled={isBarangayDisabled}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select barangay" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {barangays?.map((barangay: { _id: string; name: string }) => (
                          <SelectItem key={barangay._id} value={barangay._id}>
                            {barangay.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Business Classification */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="categoryId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select value={field.value || ""} onValueChange={handleCategoryChange}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category (optional)" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categories?.map((cat: { _id: string; name: string }) => (
                          <SelectItem key={cat._id} value={cat._id}>
                            {cat.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="subCategoryId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Sub-Category</FormLabel>
                    <Select
                      value={field.value || ""}
                      onValueChange={handleSubCategoryChange}
                      disabled={isSubCategoryDisabled}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder={isSubCategoryDisabled ? "Select a category first" : "Select sub-category (optional)"} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {subCategories?.map((sub: { _id: string; name: string }) => (
                          <SelectItem key={sub._id} value={sub._id}>
                            {sub.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </CardContent>
        </Card>

        {/* Ownership-Specific Documents Section */}
        {ownershipType && (
          <div className="space-y-6 pt-6 border-t">
            <div>
              <h3 className="text-lg font-semibold mb-2">Ownership-Specific Documents</h3>
              <p className="text-muted-foreground mb-6">
                Additional documents required based on your selected ownership type
              </p>
            </div>

            {/* Registration Date and Number Fields - Related to ownership documents */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{getRegistrationDateDescription(ownershipType)}</Label>
                <DatePicker
                  value={formValues.registrationDate}
                  onChange={(date) => form.setValue("registrationDate", date)}
                  placeholder="Select or type date (MM/DD/YYYY)"
                />
              </div>

              <FormField
                control={form.control}
                name="registrationNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Registration Number</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Enter registration number " />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <OwnershipDocumentsField
              ownershipType={ownershipType}
              documents={formValues.documents}
              onFileSelect={handleFileSelect}
              onFileRemove={handleFileRemove}
            />
          </div>
        )}

        {/* Form Actions */}
        <div className="flex justify-end gap-2 pt-4 border-t">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit" disabled={form.formState.isSubmitting} onClick={handleButtonClick}>
            {form.formState.isSubmitting ? "Creating..." : "Create Business"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
