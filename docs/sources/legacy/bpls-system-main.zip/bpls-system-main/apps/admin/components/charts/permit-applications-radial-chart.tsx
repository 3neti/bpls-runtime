"use client";

import { Cell, Pie, PieChart } from "recharts";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import { type ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from "@repo/ui/components/chart";
import { Skeleton } from "@repo/ui/components/skeleton";

interface PermitApplicationsRadialChartProps {
  newCount?: number;
  renewalCount?: number;
  isLoading?: boolean;
}

const chartConfig = {
  applications: {
    label: "Applications",
  },
  new: {
    label: "New Applications",
    color: "hsl(var(--chart-1))",
  },
  renewal: {
    label: "Renewals",
    color: "hsl(var(--chart-2))",
  },
} satisfies ChartConfig;

export function PermitApplicationsRadialChart({
  newCount = 0,
  renewalCount = 0,
  isLoading,
}: PermitApplicationsRadialChartProps) {
  // Show skeleton while loading
  if (isLoading) {
    return (
      <Card className="flex flex-col h-full">
        <CardHeader className="items-center pb-0">
          <CardTitle>Permit Applications</CardTitle>
          <CardDescription>Distribution of application types</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-1 items-center pb-0">
          <Skeleton className="mx-auto aspect-square w-full max-w-[250px] rounded-full" />
        </CardContent>
      </Card>
    );
  }

  const chartData = [
    { type: "new", applications: newCount, fill: "hsl(var(--chart-1))" },
    { type: "renewal", applications: renewalCount, fill: "hsl(var(--chart-2))" },
  ];

  const totalApplications = newCount + renewalCount;
  const hasData = totalApplications > 0;

  return (
    <Card className="flex flex-col h-full">
      <CardHeader className="items-center pb-0">
        <CardTitle>Permit Applications</CardTitle>
        <CardDescription>Distribution of application types</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-1 items-center pb-0">
        {!hasData ? (
          <div className="mx-auto flex aspect-square w-full max-w-[250px] items-center justify-center text-center text-muted-foreground">
            No applications yet
          </div>
        ) : (
          <ChartContainer config={chartConfig} className="mx-auto aspect-square w-full max-w-[250px]">
            <PieChart>
              <ChartTooltip
                cursor={false}
                content={<ChartTooltipContent hideLabel label="" payload={[]} />}
              />
              <Pie
                data={chartData}
                dataKey="applications"
                nameKey="type"
                innerRadius={60}
                outerRadius={120}
                strokeWidth={5}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Pie>
              <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle">
                <tspan x="50%" y="45%" className="fill-foreground text-2xl font-bold">
                  {totalApplications.toLocaleString()}
                </tspan>
                <tspan x="50%" y="55%" className="fill-muted-foreground text-sm">
                  Applications
                </tspan>
              </text>
            </PieChart>
          </ChartContainer>
        )}
      </CardContent>
    </Card>
  );
}
