"use client";

import React from "react";
import { PDFViewer } from "@react-pdf/renderer";
import { BusinessPermitFormDocument } from "./business-permit-form-document";
import { AssessmentSheetDocument } from "./assessment-sheet-document";
import type { BusinessPermitFormData } from "./application-form-pdf";
import type { AssessmentSheetData } from "./assessment-sheet-document";

type DocumentType = "application" | "assessment";

interface PdfViewerContentProps {
  formData?: BusinessPermitFormData;
  assessmentData?: AssessmentSheetData;
  applicationNumber: string;
  fileName?: string;
  fullHeight?: boolean;
  documentType?: DocumentType;
}

export default function PdfViewerContent({
  formData,
  assessmentData,
  fullHeight = false,
  documentType = "application",
}: PdfViewerContentProps) {
  return (
    <div className={`flex flex-col ${fullHeight ? "h-full" : "space-y-4"}`}>
      <div
        className={`${fullHeight ? "flex-1" : "h-[600px]"} border rounded-lg overflow-hidden`}
      >
        <PDFViewer width="100%" height="100%" showToolbar={true}>
          {documentType === "assessment" && assessmentData ? (
            <AssessmentSheetDocument data={assessmentData} />
          ) : (
            <BusinessPermitFormDocument data={formData} />
          )}
        </PDFViewer>
      </div>
    </div>
  );
}
