"use client";

import { useState } from "react";
import { useMutation } from "convex/react";
import { Loader2, AlertTriangle, ChevronDown, Check } from "lucide-react";

import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@repo/ui/components/popover";
import { Badge } from "@repo/ui/components/badge";
import { Button } from "@repo/ui/components/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import {
  STATUS_LABELS,
  STATUS_COLORS,
  STATUS_TRANSITIONS,
  type PermitApplicationStatus,
} from "@/lib/types/permit-application";
import { cn } from "@/lib/utils";

interface ApplicationStatusSelectProps {
  applicationId: Id<"business_permit_applications">;
  currentStatus: PermitApplicationStatus;
  disabled?: boolean;
}

/**
 * Get the status dot color class
 */
function getStatusDotColor(status: PermitApplicationStatus): string {
  switch (status) {
    case "Draft":
      return "bg-gray-400";
    case "Assessment":
      return "bg-yellow-500";
    case "Approval":
      return "bg-purple-500";
    case "Pending Payment":
      return "bg-orange-500";
    case "Released":
      return "bg-blue-500";
    default:
      return "bg-gray-400";
  }
}

/**
 * Get the impact message for a status transition
 */
function getStatusImpact(
  currentStatus: PermitApplicationStatus,
  targetStatus: PermitApplicationStatus
): {
  title: string;
  items: string[];
  isDestructive: boolean;
} {
  // Determine if this is a backward transition
  const statusOrder = ["Draft", "Assessment", "Approval", "Pending Payment", "Released"];
  const currentIndex = statusOrder.indexOf(currentStatus);
  const targetIndex = statusOrder.indexOf(targetStatus);
  const isBackward = targetIndex < currentIndex;

  switch (targetStatus) {
    case "Draft":
      return {
        title: "Impact on Resources",
        items: ["Application will return to draft status for revision"],
        isDestructive: false,
      };
    case "Assessment":
      return {
        title: "Impact on Resources",
        items: isBackward
          ? ["Application will return to assessment phase for re-evaluation"]
          : ["Application will move to assessment phase"],
        isDestructive: false,
      };
    case "Approval":
      return {
        title: "Impact on Resources",
        items: isBackward
          ? ["Application will return to the approval stage"]
          : ["Application will be sent for review and approval"],
        isDestructive: false,
      };
    case "Pending Payment":
      return {
        title: "Impact on Resources",
        items: isBackward
          ? ["Application will return to pending payment status"]
          : [
              "Fee calculations will be finalized",
              "Payment schedule will be generated",
            ],
        isDestructive: false,
      };
    case "Released":
      return {
        title: "Impact on Resources",
        items: [
          "Clearances will be automatically assigned to the application",
          "Released timestamp will be set",
          "Permit release process will be initiated",
        ],
        isDestructive: false,
      };
    default:
      return {
        title: "Impact on Resources",
        items: ["Status will be updated"],
        isDestructive: false,
      };
  }
}

export function ApplicationStatusSelect({
  applicationId,
  currentStatus,
  disabled = false,
}: ApplicationStatusSelectProps) {
  const { toast } = useToast();
  const [isUpdating, setIsUpdating] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [pendingStatus, setPendingStatus] = useState<PermitApplicationStatus | null>(null);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);

  const updateStatus = useMutation(api.businessPermitApplications.updateStatus);

  // Get valid next statuses for current status
  const validTransitions = STATUS_TRANSITIONS[currentStatus] || [];
  const isTerminalState = validTransitions.length === 0;
  const isDisabledState = disabled || isTerminalState || isUpdating;

  // All available statuses for the dropdown (excluding terminal states)
  const allStatuses: PermitApplicationStatus[] = [
    "Draft",
    "Assessment",
    "Approval",
    "Pending Payment",
    "Released",
  ];

  const handleStatusSelect = (status: PermitApplicationStatus) => {
    if (status === currentStatus) {
      setIsOpen(false);
      return;
    }

    // Close popover and show confirmation dialog
    setIsOpen(false);
    setPendingStatus(status);
    setShowConfirmDialog(true);
  };

  const handleConfirmStatusChange = async () => {
    if (!pendingStatus) return;

    setIsUpdating(true);
    try {
      await updateStatus({
        id: applicationId,
        status: pendingStatus,
      });
      toast({
        title: "Status Updated",
        description: `Application status changed to ${STATUS_LABELS[pendingStatus]}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update status",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
      setShowConfirmDialog(false);
      setPendingStatus(null);
    }
  };

  const handleCancelStatusChange = () => {
    setShowConfirmDialog(false);
    setPendingStatus(null);
  };

  const impact = pendingStatus ? getStatusImpact(currentStatus, pendingStatus) : null;

  return (
    <>
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={isOpen}
            disabled={isDisabledState}
            className={cn(
              "justify-between gap-2 h-8 px-3",
              STATUS_COLORS[currentStatus],
              isUpdating && "opacity-70",
              !isDisabledState && "hover:opacity-80"
            )}
          >
            {isUpdating ? (
              <>
                <Loader2 className="h-3 w-3 animate-spin" />
                <span>Updating...</span>
              </>
            ) : (
              <>
                <span
                  className={cn(
                    "inline-block h-2 w-2 rounded-full shrink-0",
                    getStatusDotColor(currentStatus)
                  )}
                />
                <span className="font-medium truncate">{STATUS_LABELS[currentStatus]}</span>
                {!isTerminalState && (
                  <ChevronDown className="h-3 w-3 shrink-0 opacity-50" />
                )}
              </>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[220px] p-1" align="end">
          <div className="space-y-1">
            {allStatuses.map((status) => {
              const isCurrentStatus = status === currentStatus;
              const isValidTransition = validTransitions.includes(status);
              const isStatusDisabled = !isCurrentStatus && !isValidTransition;

              return (
                <button
                  key={status}
                  onClick={() => !isStatusDisabled && handleStatusSelect(status)}
                  disabled={isStatusDisabled}
                  className={cn(
                    "w-full flex items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors",
                    isCurrentStatus && "bg-accent",
                    !isStatusDisabled && !isCurrentStatus && "hover:bg-accent cursor-pointer",
                    isStatusDisabled && "opacity-50 cursor-not-allowed"
                  )}
                >
                  <span
                    className={cn(
                      "inline-block h-2 w-2 rounded-full shrink-0",
                      getStatusDotColor(status)
                    )}
                  />
                  <span className="flex-1 text-left">{STATUS_LABELS[status]}</span>
                  {isCurrentStatus && (
                    <Check className="h-4 w-4 shrink-0" />
                  )}
                  {isStatusDisabled && !isCurrentStatus && (
                    <span className="text-muted-foreground text-xs">(not allowed)</span>
                  )}
                </button>
              );
            })}
          </div>
        </PopoverContent>
      </Popover>

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              {impact?.isDestructive && (
                <AlertTriangle className="h-5 w-5 text-destructive" />
              )}
              Confirm Status Change
            </AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-4">
                <p>
                  Are you sure you want to change the status from{" "}
                  <Badge variant="outline" className={cn("mx-1", STATUS_COLORS[currentStatus])}>
                    {STATUS_LABELS[currentStatus]}
                  </Badge>{" "}
                  to{" "}
                  {pendingStatus && (
                    <Badge variant="outline" className={cn("mx-1", STATUS_COLORS[pendingStatus])}>
                      {STATUS_LABELS[pendingStatus]}
                    </Badge>
                  )}
                  ?
                </p>

                {impact && (
                  <div className="rounded-md border p-3 bg-muted/50">
                    <p className="font-medium text-sm mb-2">{impact.title}</p>
                    <ul className="text-sm space-y-1">
                      {impact.items.map((item, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="text-muted-foreground">•</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={handleCancelStatusChange} disabled={isUpdating}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmStatusChange}
              disabled={isUpdating}
              className={cn(
                impact?.isDestructive &&
                  "bg-destructive text-destructive-foreground hover:bg-destructive/90"
              )}
            >
              {isUpdating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Updating...
                </>
              ) : (
                "Confirm"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
