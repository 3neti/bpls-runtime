"use client"

import { useState, useEffect, useMemo } from "react"
import { useQuery } from "convex/react"
import { PDFDownloadLink, PDFViewer } from "@react-pdf/renderer"
import QRCode from "qrcode"
import {
  Download,
  Printer,
  Loader2,
  FileCheck,
  ExternalLink,
  Eye,
  Calendar,
  Hash,
  Building2,
  User,
  MapPin,
  CheckCircle2,
  ArrowLeft,
} from "lucide-react"

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { Button } from "@repo/ui/components/button"
import { Badge } from "@repo/ui/components/badge"
import { Separator } from "@repo/ui/components/separator"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card"
import { MayorsPermitDocument, type MayorsPermitData, type PermitLayoutConfig } from "./mayors-permit-document"
import { generatePermitNumber, calculateExpirationDate, formatDate } from "@/lib/utils/permit-helpers"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

interface MayorsPermitModalProps {
  open: boolean
  onClose: () => void
  applicationNumber: string
  businessName: string
  ownerName: string
  businessAddress: string
  releasedAt?: string
  permitId?: Id<"permits"> // For verification URL
  // Optional extended data for dynamic layout
  businessTIN?: string
  businessEmail?: string
  businessContactNumber?: string
  ownershipType?: string
  dateStarted?: string
  registrationNumber?: string
  ownerAddress?: string
  ownerContactNumber?: string
  ownerEmail?: string
  linesOfBusiness?: string[]
}

export function MayorsPermitModal({
  open,
  onClose,
  applicationNumber,
  businessName,
  ownerName,
  businessAddress,
  releasedAt,
  permitId,
  // Extended data for dynamic layout
  businessTIN,
  businessEmail,
  businessContactNumber,
  ownershipType,
  dateStarted,
  registrationNumber,
  ownerAddress,
  ownerContactNumber,
  ownerEmail,
  linesOfBusiness,
}: MayorsPermitModalProps) {
  const [isClient, setIsClient] = useState(false)
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>("")
  const [showPdfViewer, setShowPdfViewer] = useState(false)

  // Fetch permit layout configuration
  const permitLayout = useQuery(api.permitLayouts.get)
  const permitBackgroundImageUrl = useQuery(api.permitLayouts.getBackgroundImageUrl)

  // Fetch platform settings for municipality info
  const platformSettings = useQuery(api.platformSettings.get)

  useEffect(() => {
    setIsClient(true)
  }, [])

  // Generate permit data
  const permitData: MayorsPermitData = useMemo(() => {
    const dateIssued = releasedAt || new Date().toISOString()
    const expirationDate = calculateExpirationDate(dateIssued)
    const permitNumber = generatePermitNumber(applicationNumber)

    return {
      businessName,
      ownerName,
      businessAddress,
      permitNumber,
      dateIssued,
      expirationDate,
      qrCodeDataUrl,
      applicationNumber,
      // Extended fields for dynamic layout
      businessTIN,
      businessEmail,
      businessContactNumber,
      ownershipType,
      dateStarted,
      registrationNumber,
      ownerAddress,
      ownerContactNumber,
      ownerEmail,
      linesOfBusiness,
      // Platform settings
      municipalityName: platformSettings?.municipalityName || "",
      mayorName: platformSettings?.mayorName || "",
      mayorTitle: platformSettings?.mayorTitle || "Municipal Mayor",
      provinceName: platformSettings?.provinceName || "",
      fullAddress: platformSettings?.fullAddress || "",
      treasurerName: platformSettings?.treasurerName || "",
    }
  }, [
    applicationNumber,
    businessName,
    ownerName,
    businessAddress,
    releasedAt,
    qrCodeDataUrl,
    businessTIN,
    businessEmail,
    businessContactNumber,
    ownershipType,
    dateStarted,
    registrationNumber,
    ownerAddress,
    ownerContactNumber,
    ownerEmail,
    linesOfBusiness,
    platformSettings,
  ])

  // Build layout config from permit layout
  const layoutConfig: PermitLayoutConfig | null = useMemo(() => {
    if (!permitLayout) return null

    return {
      paperSize: permitLayout.paperSize,
      orientation: permitLayout.orientation,
      marginTop: permitLayout.marginTop,
      marginRight: permitLayout.marginRight,
      marginBottom: permitLayout.marginBottom,
      marginLeft: permitLayout.marginLeft,
      headerTemplate: permitLayout.headerTemplate,
      bodyTemplate: permitLayout.bodyTemplate,
      footerTemplate: permitLayout.footerTemplate,
      qrCodeSize: permitLayout.qrCodeSize,
      logoUrl: undefined,
      sealUrl: undefined,
      backgroundImageUrl: permitBackgroundImageUrl ?? undefined,
      backgroundImageOpacity: permitLayout.backgroundImageOpacity,
      backgroundImageWidth: permitLayout.backgroundImageWidth,
      backgroundImageHeight: permitLayout.backgroundImageHeight,
    }
  }, [permitLayout, permitBackgroundImageUrl])

  // Generate verification URL using permit ID
  // Uses window.location.origin to get the current hostname (works for localhost, staging, production)
  const verificationUrl = useMemo(() => {
    let baseUrl = ""

    if (typeof window !== "undefined") {
      // Client-side: use the current origin (protocol + hostname + port)
      baseUrl = window.location.origin
    } else if (process.env.NEXT_PUBLIC_APP_URL) {
      // SSR fallback: use environment variable if set
      baseUrl = process.env.NEXT_PUBLIC_APP_URL
    }

    return permitId
      ? `${baseUrl}/permits/verify/${permitId}`
      : `${baseUrl}/verify/${applicationNumber}` // Fallback for legacy
  }, [permitId, applicationNumber])

  // Generate QR code when modal opens
  useEffect(() => {
    if (open && isClient) {
      QRCode.toDataURL(verificationUrl, {
        width: 200,
        margin: 1,
        color: { dark: "#000000", light: "#ffffff" },
      })
        .then((url) => setQrCodeDataUrl(url))
        .catch((err) => console.error("QR Code generation failed:", err))
    }
  }, [open, isClient, verificationUrl])

  const handlePrint = () => {
    window.print()
  }

  const handleViewVerificationUrl = () => {
    window.open(verificationUrl, "_blank")
  }

  // Reset state when modal closes
  useEffect(() => {
    if (!open) {
      setShowPdfViewer(false)
    }
  }, [open])

  // PDF Viewer view
  if (showPdfViewer) {
    return (
      <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
        <DialogContent className="sm:max-w-[95vw] w-full h-[90vh] flex flex-col p-0">
          <DialogHeader className="flex-shrink-0 px-6 py-4 border-b">
            <div className="flex items-center justify-between">
              <DialogTitle className="flex items-center gap-2">
                <FileCheck className="h-5 w-5" />
                Mayor's Permit - PDF Preview
              </DialogTitle>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => setShowPdfViewer(false)}>
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Details
                </Button>
                {isClient && qrCodeDataUrl && (
                  <PDFDownloadLink
                    document={<MayorsPermitDocument data={permitData} layout={layoutConfig} />}
                    fileName={`mayors-permit-${permitData.permitNumber}.pdf`}
                  >
                    {({ loading }) => (
                      <Button variant="outline" size="sm" disabled={loading}>
                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
                        {loading ? "Preparing..." : "Download PDF"}
                      </Button>
                    )}
                  </PDFDownloadLink>
                )}
              </div>
            </div>
          </DialogHeader>
          <div className="flex-1 overflow-hidden p-6">
            {isClient && qrCodeDataUrl ? (
              <div className="w-full h-full border rounded-lg overflow-hidden">
                <PDFViewer width="100%" height="100%" showToolbar={true}>
                  <MayorsPermitDocument data={permitData} layout={layoutConfig} />
                </PDFViewer>
              </div>
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  // Main UI-first view
  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileCheck className="h-5 w-5 text-green-600" />
            Mayor's Permit
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Status Badge */}
          <div className="flex items-center justify-between">
            <Badge variant="outline" className="text-green-600 border-green-300 bg-green-50">
              <CheckCircle2 className="mr-1 h-3 w-3" />
              Active
            </Badge>
            <span className="text-sm text-muted-foreground font-mono">
              {permitData.permitNumber}
            </span>
          </div>

          {/* Permit Details Card */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Permit Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Hash className="h-3 w-3" />
                    Permit Number
                  </div>
                  <p className="font-mono font-medium">{permitData.permitNumber}</p>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    Date Issued
                  </div>
                  <p className="font-medium">{formatDate(permitData.dateIssued)}</p>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Building2 className="h-3 w-3" />
                    Business Name
                  </div>
                  <p className="font-medium">{businessName}</p>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    Valid Until
                  </div>
                  <p className="font-medium">{formatDate(permitData.expirationDate)}</p>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <User className="h-3 w-3" />
                    Owner/Operator
                  </div>
                  <p className="font-medium">{ownerName}</p>
                </div>
                <div className="space-y-1 col-span-2">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <MapPin className="h-3 w-3" />
                    Business Address
                  </div>
                  <p className="font-medium">{businessAddress}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* QR Code */}
          {qrCodeDataUrl && (
            <div className="flex justify-center">
              <div className="text-center">
                <img src={qrCodeDataUrl} alt="Verification QR Code" className="w-24 h-24 mx-auto" />
                <p className="text-xs text-muted-foreground mt-2">
                  Scan to verify permit
                </p>
              </div>
            </div>
          )}

          <Separator />

          {/* Primary Action Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" onClick={() => setShowPdfViewer(true)} className="w-full">
              <Eye className="mr-2 h-4 w-4" />
              View PDF
            </Button>
            <Button variant="outline" onClick={handleViewVerificationUrl} className="w-full">
              <ExternalLink className="mr-2 h-4 w-4" />
              View Verification URL
            </Button>
          </div>

          {/* Secondary Actions */}
          <div className="flex gap-2">
            {isClient && qrCodeDataUrl && (
              <PDFDownloadLink
                document={<MayorsPermitDocument data={permitData} layout={layoutConfig} />}
                fileName={`mayors-permit-${permitData.permitNumber}.pdf`}
                className="flex-1"
              >
                {({ loading }) => (
                  <Button variant="secondary" className="w-full" disabled={loading}>
                    {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
                    Download PDF
                  </Button>
                )}
              </PDFDownloadLink>
            )}
            <Button variant="secondary" onClick={handlePrint} className="flex-1">
              <Printer className="mr-2 h-4 w-4" />
              Print
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
