"use client"

import * as React from "react"
import { Play, Save, RotateCcw, Download } from "lucide-react"
import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Separator } from "@repo/ui/components/separator"
import { ResourceSelector } from "./resource-selector"
import { DimensionSelector } from "./dimension-selector"
import { MetricSelector } from "./metric-selector"
import { FilterBuilder } from "./filter-builder"
import { DateRangePicker } from "./date-range-picker"
import { RESOURCE_CONFIGS, getAllDimensions } from "@/lib/config/report-resources"
import {
  useReportBuilderStore,
  useCurrentResourceConfig,
  useCanGenerateReport,
} from "@/lib/stores/report-builder-store"
import type { ResourceType, FilterGroup, DateRange } from "@/lib/types/report-builder"

interface ReportBuilderProps {
  onGenerate?: () => void
  onSave?: () => void
  onExport?: () => void
  isGenerating?: boolean
  isSaving?: boolean
}

export function ReportBuilder({
  onGenerate,
  onSave,
  onExport,
  isGenerating = false,
  isSaving = false,
}: ReportBuilderProps) {
  const {
    resourceType,
    selectedDimensions,
    selectedMetrics,
    filters,
    dateRange,
    setResourceType,
    setDimensions,
    toggleDimension,
    clearDimensions,
    toggleMetric,
    clearMetrics,
    setFilters,
    setDateRange,
    resetAll,
  } = useReportBuilderStore()

  const currentConfig = useCurrentResourceConfig()
  const canGenerate = useCanGenerateReport()

  const handleResourceChange = (type: ResourceType) => {
    setResourceType(type)
  }

  const handleReset = () => {
    resetAll()
  }

  // Get date dimensions for the date range picker
  const dateDimensions = React.useMemo(() => {
    if (!resourceType) return []
    return getAllDimensions(resourceType).filter((d) => d.type === "date")
  }, [resourceType])

  // Get filterable dimensions for the filter builder
  const filterableDimensions = React.useMemo(() => {
    if (!resourceType) return []
    return getAllDimensions(resourceType).filter((d) => d.filterable)
  }, [resourceType])

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_350px]">
      {/* Main Configuration Panel */}
      <div className="space-y-6">
        {/* Resource Selection */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Report Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <ResourceSelector
              value={resourceType}
              onChange={handleResourceChange}
            />

            {currentConfig && (
              <>
                <Separator />

                {/* Dimension & Metric Selection */}
                <div className="grid gap-6 md:grid-cols-2">
                  <DimensionSelector
                    groups={currentConfig.dimensionGroups}
                    selectedDimensions={selectedDimensions}
                    onToggle={toggleDimension}
                    onSelectAll={setDimensions}
                    onClear={clearDimensions}
                    maxHeight="350px"
                  />

                  <MetricSelector
                    groups={currentConfig.metricGroups}
                    selectedMetrics={selectedMetrics}
                    onToggle={toggleMetric}
                    onClear={clearMetrics}
                    maxHeight="350px"
                  />
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Filters Card */}
        {currentConfig && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Filters</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <DateRangePicker
                  value={dateRange}
                  onChange={setDateRange}
                  dateDimensions={dateDimensions}
                  primaryDimensionId={currentConfig.primaryDateDimension}
                />

                <FilterBuilder
                  dimensions={filterableDimensions}
                  filterGroup={filters}
                  onChange={setFilters}
                  maxHeight="200px"
                />
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Actions Sidebar */}
      <div className="space-y-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button
              className="w-full"
              onClick={onGenerate}
              disabled={!canGenerate || isGenerating}
            >
              <Play className="size-4 mr-2" />
              {isGenerating ? "Generating..." : "Generate Report"}
            </Button>

            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                onClick={onSave}
                disabled={!canGenerate || isSaving}
              >
                <Save className="size-4 mr-2" />
                {isSaving ? "Saving..." : "Save"}
              </Button>

              <Button
                variant="outline"
                onClick={onExport}
                disabled={!canGenerate}
              >
                <Download className="size-4 mr-2" />
                Export
              </Button>
            </div>

            <Separator />

            <Button
              variant="ghost"
              className="w-full"
              onClick={handleReset}
            >
              <RotateCcw className="size-4 mr-2" />
              Reset All
            </Button>
          </CardContent>
        </Card>

        {/* Summary Card */}
        {currentConfig && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <dl className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Data Source</dt>
                  <dd className="font-medium">{currentConfig.meta.name}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Columns</dt>
                  <dd className="font-medium">{selectedDimensions.length}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Metrics</dt>
                  <dd className="font-medium">{selectedMetrics.length}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Filters</dt>
                  <dd className="font-medium">
                    {filters?.conditions.length || 0}
                  </dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Date Range</dt>
                  <dd className="font-medium capitalize">
                    {dateRange?.preset || "None"}
                  </dd>
                </div>
              </dl>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
