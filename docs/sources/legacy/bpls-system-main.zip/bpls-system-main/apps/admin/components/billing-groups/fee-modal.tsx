"use client"

import { useEffect, useMemo } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { useMutation, useQuery } from "convex/react"
import { CalendarIcon } from "lucide-react"
import { format } from "date-fns"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form"
import { Input } from "@repo/ui/components/input"
import { Button } from "@repo/ui/components/button"
import { Switch } from "@repo/ui/components/switch"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@repo/ui/components/popover"
import { Calendar } from "@repo/ui/components/calendar"
import { useToast } from "@/hooks/use-toast"
import { cn } from "@/lib/utils"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

type FieldType = "text" | "number" | "currency" | "date" | "dropdown" | "checkbox"

interface CustomField {
  _id: Id<"billing_group_fee_fields">
  name: string
  fieldType: FieldType
  isRequired: boolean
  sortOrder: number
  options?: string[]
  placeholder?: string
  defaultValue?: string
}

interface FeeModalProps {
  open: boolean
  onClose: () => void
  billingGroupId: Id<"billing_groups">
  editingFeeId: Id<"billing_group_fees"> | null
  customFields: CustomField[]
}

export function FeeModal({
  open,
  onClose,
  billingGroupId,
  editingFeeId,
  customFields,
}: FeeModalProps) {
  const { toast } = useToast()
  const isEditing = editingFeeId !== null

  // Fetch fee data if editing
  const feeData = useQuery(
    api.billingGroupFees.getById,
    editingFeeId ? { id: editingFeeId } : "skip"
  )

  // Mutations
  const createFee = useMutation(api.billingGroupFees.create)
  const updateFee = useMutation(api.billingGroupFees.update)

  // Build dynamic schema
  const formSchema = useMemo(() => {
    const schemaShape: Record<string, z.ZodTypeAny> = {
      // System fields
      name: z.string().min(1, "Fee name is required"),
      code: z.string().min(1, "Fee code is required").regex(
        /^[A-Z0-9-]+$/,
        "Code must contain only uppercase letters, numbers, and hyphens"
      ),
      defaultAmount: z.string().refine(
        (val) => val !== "" && !isNaN(parseFloat(val)) && parseFloat(val) >= 0,
        { message: "Amount must be a valid positive number" }
      ),
      isActive: z.boolean(),
    }

    // Add custom field schemas
    customFields.forEach((field) => {
      let fieldSchema: z.ZodTypeAny

      switch (field.fieldType) {
        case "number":
        case "currency":
          fieldSchema = z.string().refine(
            (val) => val === "" || !isNaN(parseFloat(val)),
            { message: "Must be a valid number" }
          )
          break
        case "checkbox":
          fieldSchema = z.boolean()
          break
        case "date":
          fieldSchema = z.string()
          break
        default:
          fieldSchema = z.string()
      }

      if (field.isRequired && field.fieldType !== "checkbox") {
        fieldSchema = fieldSchema.refine(
          (val) => val !== "" && val !== undefined && val !== null,
          { message: `${field.name} is required` }
        )
      }

      schemaShape[`custom_${field._id}`] = fieldSchema
    })

    return z.object(schemaShape)
  }, [customFields])

  type FormValues = z.infer<typeof formSchema>

  // Build default values
  const defaultValues = useMemo((): FormValues => {
    const defaults: Record<string, string | boolean> = {
      name: "",
      code: "",
      defaultAmount: "",
      isActive: true,
    }

    customFields.forEach((field) => {
      if (field.fieldType === "checkbox") {
        defaults[`custom_${field._id}`] = field.defaultValue === "true"
      } else {
        defaults[`custom_${field._id}`] = field.defaultValue || ""
      }
    })

    return defaults as FormValues
  }, [customFields])

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
  })

  // Reset form when modal opens/closes or editing fee changes
  useEffect(() => {
    if (open) {
      if (feeData) {
        // Populate with existing fee data
        const values: Record<string, string | boolean> = {
          name: feeData.name,
          code: feeData.code,
          defaultAmount: feeData.defaultAmount.toString(),
          isActive: feeData.isActive,
        }

        // Populate custom field values
        customFields.forEach((field) => {
          const fieldValue = feeData.customFieldValues?.find(
            (fv: { fieldId: string; value: string }) => fv.fieldId === field._id
          )
          if (field.fieldType === "checkbox") {
            values[`custom_${field._id}`] = fieldValue
              ? fieldValue.value === "true"
              : (field.defaultValue === "true")
          } else {
            values[`custom_${field._id}`] = fieldValue?.value ?? field.defaultValue ?? ""
          }
        })

        form.reset(values as FormValues)
      } else if (!editingFeeId) {
        form.reset(defaultValues)
      }
    }
  }, [open, feeData, editingFeeId, customFields, form, defaultValues])

  const handleSubmit = async (values: FormValues) => {
    try {
      // Build custom field values array
      const customFieldValues = customFields.map((field) => ({
        fieldId: field._id,
        value: field.fieldType === "checkbox"
          ? String(values[`custom_${field._id}`])
          : String(values[`custom_${field._id}`] || ""),
      }))

      if (isEditing && editingFeeId) {
        await updateFee({
          id: editingFeeId,
          name: values.name as string,
          code: values.code as string,
          defaultAmount: parseFloat(values.defaultAmount as string),
          customFieldValues,
          isActive: values.isActive as boolean,
        })
        toast({
          title: "Fee updated",
          description: "The fee has been updated successfully.",
        })
      } else {
        await createFee({
          billingGroupId,
          name: values.name as string,
          code: values.code as string,
          defaultAmount: parseFloat(values.defaultAmount as string),
          customFieldValues,
          isActive: values.isActive as boolean,
        })
        toast({
          title: "Fee created",
          description: "A new fee has been added to the library.",
        })
      }

      onClose()
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save fee",
        variant: "destructive",
      })
    }
  }

  const renderCustomField = (field: CustomField) => {
    const fieldName = `custom_${field._id}` as keyof FormValues

    switch (field.fieldType) {
      case "text":
        return (
          <FormField
            key={field._id}
            control={form.control}
            name={fieldName}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>
                  {field.name}
                  {field.isRequired && <span className="text-destructive ml-1">*</span>}
                </FormLabel>
                <FormControl>
                  <Input
                    placeholder={field.placeholder || `Enter ${field.name.toLowerCase()}`}
                    {...formField}
                    value={formField.value as string}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )

      case "number":
        return (
          <FormField
            key={field._id}
            control={form.control}
            name={fieldName}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>
                  {field.name}
                  {field.isRequired && <span className="text-destructive ml-1">*</span>}
                </FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    placeholder={field.placeholder || "0"}
                    {...formField}
                    value={formField.value as string}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )

      case "currency":
        return (
          <FormField
            key={field._id}
            control={form.control}
            name={fieldName}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>
                  {field.name}
                  {field.isRequired && <span className="text-destructive ml-1">*</span>}
                </FormLabel>
                <FormControl>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                      ₱
                    </span>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder={field.placeholder || "0.00"}
                      className="pl-7"
                      {...formField}
                      value={formField.value as string}
                    />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )

      case "date":
        return (
          <FormField
            key={field._id}
            control={form.control}
            name={fieldName}
            render={({ field: formField }) => (
              <FormItem className="flex flex-col">
                <FormLabel>
                  {field.name}
                  {field.isRequired && <span className="text-destructive ml-1">*</span>}
                </FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full pl-3 text-left font-normal",
                          !formField.value && "text-muted-foreground"
                        )}
                      >
                        {formField.value ? (
                          format(new Date(formField.value as string), "PPP")
                        ) : (
                          <span>{field.placeholder || "Pick a date"}</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={formField.value ? new Date(formField.value as string) : undefined}
                      onSelect={(date) =>
                        formField.onChange(date ? date.toISOString() : "")
                      }
                      autoFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
        )

      case "dropdown":
        return (
          <FormField
            key={field._id}
            control={form.control}
            name={fieldName}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>
                  {field.name}
                  {field.isRequired && <span className="text-destructive ml-1">*</span>}
                </FormLabel>
                <Select
                  onValueChange={formField.onChange}
                  value={formField.value as string}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder={field.placeholder || `Select ${field.name.toLowerCase()}`} />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {field.options?.map((option) => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        )

      case "checkbox":
        return (
          <FormField
            key={field._id}
            control={form.control}
            name={fieldName}
            render={({ field: formField }) => (
              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                <div className="space-y-0.5">
                  <FormLabel>{field.name}</FormLabel>
                  {field.placeholder && (
                    <FormDescription className="text-xs">
                      {field.placeholder}
                    </FormDescription>
                  )}
                </div>
                <FormControl>
                  <Switch
                    checked={formField.value as boolean}
                    onCheckedChange={formField.onChange}
                  />
                </FormControl>
              </FormItem>
            )}
          />
        )

      default:
        return null
    }
  }

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-[500px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Fee" : "Add Fee"}</DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Update the fee information below."
              : "Add a new fee to the library."}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            {/* System Fields */}
            <div className="space-y-4 pb-4 border-b">
              <FormField
                control={form.control}
                name="code"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Fee Code <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input
                        placeholder="e.g., BPF-001"
                        {...field}
                        value={field.value as string}
                        onChange={(e) => field.onChange(e.target.value.toUpperCase())}
                      />
                    </FormControl>
                    <FormDescription>
                      Unique code for this fee (uppercase letters, numbers, hyphens only)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Fee Name <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input
                        placeholder="e.g., Building Permit Fee"
                        {...field}
                        value={field.value as string}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="defaultAmount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Default Amount <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                          ₱
                        </span>
                        <Input
                          type="number"
                          step="0.01"
                          min="0"
                          placeholder="0.00"
                          className="pl-7"
                          {...field}
                          value={field.value as string}
                        />
                      </div>
                    </FormControl>
                    <FormDescription>
                      Default amount when selecting this fee in transactions
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                    <div className="space-y-0.5">
                      <FormLabel>Active</FormLabel>
                      <FormDescription className="text-xs">
                        Inactive fees won't appear in fee selection
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value as boolean}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>

            {/* Custom Fields */}
            {customFields.length > 0 && (
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-muted-foreground">
                  Additional Fields
                </h4>
                {customFields
                  .sort((a, b) => a.sortOrder - b.sortOrder)
                  .map((field) => renderCustomField(field))}
              </div>
            )}

            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting
                  ? "Saving..."
                  : isEditing
                    ? "Save Changes"
                    : "Add Fee"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
