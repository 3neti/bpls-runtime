"use client"

import * as React from "react"
import { ChevronRight, ChevronDown, Calculator } from "lucide-react"
import { cn } from "@/lib/utils"
import { Checkbox } from "@repo/ui/components/checkbox"
import { Badge } from "@repo/ui/components/badge"
import { Button } from "@repo/ui/components/button"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@repo/ui/components/collapsible"
import { ScrollArea } from "@repo/ui/components/scroll-area"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import type { MetricGroup, Metric } from "@/lib/types/report-builder"

interface MetricSelectorProps {
  groups: MetricGroup[]
  selectedMetrics: string[]
  onToggle: (metricId: string) => void
  onSelectAll?: (metricIds: string[]) => void
  onClear?: () => void
  maxHeight?: string
}

export function MetricSelector({
  groups,
  selectedMetrics,
  onToggle,
  onSelectAll,
  onClear,
  maxHeight = "300px",
}: MetricSelectorProps) {
  const [expandedGroups, setExpandedGroups] = React.useState<Set<string>>(() => {
    // Expand first group by default
    return new Set(groups.length > 0 ? [groups[0].id] : [])
  })

  const toggleGroup = (groupId: string) => {
    setExpandedGroups((prev) => {
      const next = new Set(prev)
      if (next.has(groupId)) {
        next.delete(groupId)
      } else {
        next.add(groupId)
      }
      return next
    })
  }

  const getGroupSelectedCount = (group: MetricGroup) => {
    return group.metrics.filter((m) => selectedMetrics.includes(m.id)).length
  }

  const getAggregationLabel = (aggregation: string) => {
    const labels: Record<string, string> = {
      count: "Count",
      sum: "Sum",
      average: "Avg",
      min: "Min",
      max: "Max",
      countDistinct: "Distinct",
    }
    return labels[aggregation] || aggregation
  }

  const getFormatLabel = (format: string) => {
    const labels: Record<string, string> = {
      number: "#",
      currency: "₱",
      percentage: "%",
    }
    return labels[format] || format
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Calculator className="size-4 text-muted-foreground" />
          <span className="text-sm font-medium">Metrics</span>
          <Badge variant="secondary" className="ml-1">
            {selectedMetrics.length}
          </Badge>
        </div>
        {onClear && selectedMetrics.length > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClear}
            className="h-7 text-xs"
          >
            Clear all
          </Button>
        )}
      </div>

      <ScrollArea style={{ maxHeight }} className="rounded-md border">
        <div className="p-2 space-y-1">
          {groups.map((group) => (
            <Collapsible
              key={group.id}
              open={expandedGroups.has(group.id)}
              onOpenChange={() => toggleGroup(group.id)}
            >
              <div className="flex items-center gap-1">
                <CollapsibleTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 hover:bg-accent"
                  >
                    {expandedGroups.has(group.id) ? (
                      <ChevronDown className="size-4" />
                    ) : (
                      <ChevronRight className="size-4" />
                    )}
                  </Button>
                </CollapsibleTrigger>

                <div className="flex-1 flex items-center justify-between px-2 py-1.5">
                  <span className="font-medium text-sm">{group.name}</span>
                  {getGroupSelectedCount(group) > 0 && (
                    <Badge variant="outline" className="h-5 text-xs">
                      {getGroupSelectedCount(group)}/{group.metrics.length}
                    </Badge>
                  )}
                </div>
              </div>

              <CollapsibleContent>
                <div className="ml-9 space-y-0.5 py-1">
                  {group.metrics.map((metric) => (
                    <MetricItem
                      key={metric.id}
                      metric={metric}
                      isSelected={selectedMetrics.includes(metric.id)}
                      onToggle={() => onToggle(metric.id)}
                      aggregationLabel={getAggregationLabel(metric.aggregation)}
                      formatLabel={getFormatLabel(metric.format)}
                    />
                  ))}
                </div>
              </CollapsibleContent>
            </Collapsible>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}

interface MetricItemProps {
  metric: Metric
  isSelected: boolean
  onToggle: () => void
  aggregationLabel: string
  formatLabel: string
}

function MetricItem({
  metric,
  isSelected,
  onToggle,
  aggregationLabel,
  formatLabel,
}: MetricItemProps) {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <label
            className={cn(
              "flex items-center gap-2 px-2 py-1.5 rounded-md cursor-pointer hover:bg-accent transition-colors",
              isSelected && "bg-accent/50"
            )}
          >
            <Checkbox
              checked={isSelected}
              onCheckedChange={onToggle}
              className="data-[state=checked]:bg-primary"
            />
            <span className="text-sm flex-1">{metric.name}</span>
            <div className="flex items-center gap-1">
              <Badge variant="secondary" className="h-5 text-[10px] px-1.5">
                {aggregationLabel}
              </Badge>
              <Badge variant="outline" className="h-5 text-[10px] px-1.5">
                {formatLabel}
              </Badge>
            </div>
          </label>
        </TooltipTrigger>
        {metric.description && (
          <TooltipContent side="right">
            <p className="text-xs max-w-xs">{metric.description}</p>
          </TooltipContent>
        )}
      </Tooltip>
    </TooltipProvider>
  )
}
