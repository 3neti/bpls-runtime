"use client"

import React from "react"
import { ConvexError } from "convex/values"
import { RefreshCw, Home, AlertTriangle } from "lucide-react"
import Link from "next/link"

import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"
import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Alert, AlertDescription, AlertTitle } from "@repo/ui/components/alert"
import {
  isPermissionDenied,
  isAuthenticationError,
  getPermissionErrorDetails,
  getErrorMessage,
} from "@/lib/convex-error-handler"

interface ConvexErrorBoundaryProps {
  children: React.ReactNode
  fallback?: React.ReactNode
}

interface ConvexErrorBoundaryState {
  hasError: boolean
  error: Error | null
}

/**
 * Error Boundary for catching Convex errors in the dashboard
 *
 * Provides graceful error handling for:
 * - Permission denied errors (shows PermissionDenied component)
 * - Authentication errors (shows AuthenticationRequired component)
 * - Other errors (shows generic error UI with retry option)
 *
 * Usage:
 * ```tsx
 * <ConvexErrorBoundary>
 *   <DashboardContent />
 * </ConvexErrorBoundary>
 * ```
 */
export class ConvexErrorBoundary extends React.Component<
  ConvexErrorBoundaryProps,
  ConvexErrorBoundaryState
> {
  constructor(props: ConvexErrorBoundaryProps) {
    super(props)
    this.state = { hasError: false, error: null }
  }

  static getDerivedStateFromError(error: Error): ConvexErrorBoundaryState {
    return { hasError: true, error }
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo): void {
    // Log the error for debugging
    console.error("ConvexErrorBoundary caught an error:", error, errorInfo)
  }

  handleReset = (): void => {
    this.setState({ hasError: false, error: null })
  }

  render(): React.ReactNode {
    if (this.state.hasError && this.state.error) {
      const { error } = this.state
      const { fallback } = this.props

      // Handle permission denied errors
      if (isPermissionDenied(error)) {
        const details = getPermissionErrorDetails(error)
        const message = getErrorMessage(error, "You don't have permission to access this resource")

        return (
          <PermissionDenied
            title="Access Denied"
            description="This section requires additional permissions"
            message={message}
            details={details}
            backLink="/dashboard"
            backLinkText="Back to Dashboard"
          />
        )
      }

      // Handle authentication errors
      if (isAuthenticationError(error)) {
        const message = getErrorMessage(error, "Please log in to access this page")
        return <AuthenticationRequired message={message} />
      }

      // Use custom fallback if provided
      if (fallback) {
        return fallback
      }

      // Generic error UI
      return <GenericErrorFallback error={error} onReset={this.handleReset} />
    }

    return this.props.children
  }
}

/**
 * Generic error fallback component
 */
interface GenericErrorFallbackProps {
  error: Error
  onReset: () => void
}

function GenericErrorFallback({ error, onReset }: GenericErrorFallbackProps): React.ReactNode {
  const message = getErrorMessage(error, "Something went wrong")

  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Something went wrong</AlertTitle>
        <AlertDescription>{message}</AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle>Error Details</CardTitle>
          <CardDescription>An unexpected error occurred while loading this page</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-sm text-muted-foreground">
            <p>
              If this problem persists, please contact your system administrator with the following
              information:
            </p>
            <pre className="mt-2 rounded bg-muted p-2 text-xs overflow-auto">
              {error.message || "Unknown error"}
            </pre>
          </div>

          <div className="flex gap-2">
            <Button onClick={onReset} variant="outline">
              <RefreshCw className="mr-2 h-4 w-4" />
              Try Again
            </Button>
            <Link href="/dashboard">
              <Button variant="default">
                <Home className="mr-2 h-4 w-4" />
                Go to Dashboard
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

/**
 * Hook for handling Convex errors in functional components
 *
 * Useful for handling errors from mutations that aren't caught by Error Boundaries
 *
 * Usage:
 * ```tsx
 * function MyComponent() {
 *   const { error, setError, clearError, ErrorDisplay } = useConvexErrorState()
 *
 *   const handleSave = async () => {
 *     try {
 *       await mutation()
 *     } catch (e) {
 *       setError(e)
 *     }
 *   }
 *
 *   if (error) return <ErrorDisplay />
 *   return <MyContent />
 * }
 * ```
 */
export function useConvexErrorState() {
  const [error, setError] = React.useState<Error | null>(null)

  const clearError = React.useCallback(() => {
    setError(null)
  }, [])

  const handleError = React.useCallback((e: unknown) => {
    if (e instanceof Error) {
      setError(e)
    } else if (e instanceof ConvexError) {
      setError(new Error(getErrorMessage(e)))
    } else {
      setError(new Error("An unexpected error occurred"))
    }
  }, [])

  const ErrorDisplay = React.useCallback(() => {
    if (!error) return null

    // Check if it's a permission error
    if (isPermissionDenied(error)) {
      const details = getPermissionErrorDetails(error)
      return (
        <PermissionDenied
          title="Access Denied"
          message={getErrorMessage(error)}
          details={details}
          backLink="/dashboard"
          backLinkText="Back to Dashboard"
        />
      )
    }

    // Check if it's an auth error
    if (isAuthenticationError(error)) {
      return <AuthenticationRequired message={getErrorMessage(error)} />
    }

    // Generic error
    return <GenericErrorFallback error={error} onReset={clearError} />
  }, [error, clearError])

  return {
    error,
    setError: handleError,
    clearError,
    hasError: error !== null,
    isPermissionError: error ? isPermissionDenied(error) : false,
    isAuthError: error ? isAuthenticationError(error) : false,
    ErrorDisplay,
  }
}

export default ConvexErrorBoundary
