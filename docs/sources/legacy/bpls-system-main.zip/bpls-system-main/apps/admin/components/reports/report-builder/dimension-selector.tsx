"use client"

import * as React from "react"
import { ChevronRight, ChevronDown, Check, Columns3 } from "lucide-react"
import { cn } from "@/lib/utils"
import { Checkbox } from "@repo/ui/components/checkbox"
import { Badge } from "@repo/ui/components/badge"
import { Button } from "@repo/ui/components/button"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@repo/ui/components/collapsible"
import { ScrollArea } from "@repo/ui/components/scroll-area"
import type { DimensionGroup, Dimension } from "@/lib/types/report-builder"

interface DimensionSelectorProps {
  groups: DimensionGroup[]
  selectedDimensions: string[]
  onToggle: (dimensionId: string) => void
  onSelectAll?: (dimensionIds: string[]) => void
  onClear?: () => void
  maxHeight?: string
}

export function DimensionSelector({
  groups,
  selectedDimensions,
  onToggle,
  onSelectAll,
  onClear,
  maxHeight = "400px",
}: DimensionSelectorProps) {
  const [expandedGroups, setExpandedGroups] = React.useState<Set<string>>(() => {
    const defaultExpanded = new Set<string>()
    groups.forEach((group) => {
      if (group.defaultExpanded) {
        defaultExpanded.add(group.id)
      }
    })
    return defaultExpanded
  })

  const toggleGroup = (groupId: string) => {
    setExpandedGroups((prev) => {
      const next = new Set(prev)
      if (next.has(groupId)) {
        next.delete(groupId)
      } else {
        next.add(groupId)
      }
      return next
    })
  }

  const handleSelectAllInGroup = (group: DimensionGroup) => {
    if (onSelectAll) {
      const groupDimensionIds = group.dimensions.map((d) => d.id)
      const allSelected = groupDimensionIds.every((id) =>
        selectedDimensions.includes(id)
      )

      if (allSelected) {
        // Deselect all in group
        const newSelection = selectedDimensions.filter(
          (id) => !groupDimensionIds.includes(id)
        )
        onSelectAll(newSelection)
      } else {
        // Select all in group
        const newSelection = [
          ...new Set([...selectedDimensions, ...groupDimensionIds]),
        ]
        onSelectAll(newSelection)
      }
    }
  }

  const isGroupFullySelected = (group: DimensionGroup) => {
    return group.dimensions.every((d) => selectedDimensions.includes(d.id))
  }

  const isGroupPartiallySelected = (group: DimensionGroup) => {
    const selected = group.dimensions.filter((d) =>
      selectedDimensions.includes(d.id)
    )
    return selected.length > 0 && selected.length < group.dimensions.length
  }

  const getGroupSelectedCount = (group: DimensionGroup) => {
    return group.dimensions.filter((d) => selectedDimensions.includes(d.id))
      .length
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Columns3 className="size-4 text-muted-foreground" />
          <span className="text-sm font-medium">Columns</span>
          <Badge variant="secondary" className="ml-1">
            {selectedDimensions.length}
          </Badge>
        </div>
        {onClear && selectedDimensions.length > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClear}
            className="h-7 text-xs"
          >
            Clear all
          </Button>
        )}
      </div>

      <ScrollArea style={{ maxHeight }} className="rounded-md border">
        <div className="p-2 space-y-1">
          {groups.map((group) => (
            <Collapsible
              key={group.id}
              open={expandedGroups.has(group.id)}
              onOpenChange={() => toggleGroup(group.id)}
            >
              <div className="flex items-center gap-1">
                <CollapsibleTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0 hover:bg-accent"
                  >
                    {expandedGroups.has(group.id) ? (
                      <ChevronDown className="size-4" />
                    ) : (
                      <ChevronRight className="size-4" />
                    )}
                  </Button>
                </CollapsibleTrigger>

                <button
                  type="button"
                  onClick={() => handleSelectAllInGroup(group)}
                  className={cn(
                    "flex-1 flex items-center justify-between px-2 py-1.5 rounded-md text-sm hover:bg-accent transition-colors",
                    isGroupFullySelected(group) && "bg-accent/50"
                  )}
                >
                  <span className="font-medium">{group.name}</span>
                  <div className="flex items-center gap-2">
                    {getGroupSelectedCount(group) > 0 && (
                      <Badge variant="outline" className="h-5 text-xs">
                        {getGroupSelectedCount(group)}/{group.dimensions.length}
                      </Badge>
                    )}
                    <div
                      className={cn(
                        "size-4 rounded border flex items-center justify-center",
                        isGroupFullySelected(group)
                          ? "bg-primary border-primary"
                          : isGroupPartiallySelected(group)
                            ? "bg-primary/50 border-primary"
                            : "border-input"
                      )}
                    >
                      {(isGroupFullySelected(group) ||
                        isGroupPartiallySelected(group)) && (
                        <Check className="size-3 text-primary-foreground" />
                      )}
                    </div>
                  </div>
                </button>
              </div>

              <CollapsibleContent>
                <div className="ml-9 space-y-0.5 py-1">
                  {group.dimensions.map((dimension) => (
                    <DimensionItem
                      key={dimension.id}
                      dimension={dimension}
                      isSelected={selectedDimensions.includes(dimension.id)}
                      onToggle={() => onToggle(dimension.id)}
                    />
                  ))}
                </div>
              </CollapsibleContent>
            </Collapsible>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}

interface DimensionItemProps {
  dimension: Dimension
  isSelected: boolean
  onToggle: () => void
}

function DimensionItem({ dimension, isSelected, onToggle }: DimensionItemProps) {
  return (
    <label
      className={cn(
        "flex items-center gap-2 px-2 py-1.5 rounded-md cursor-pointer hover:bg-accent transition-colors",
        isSelected && "bg-accent/50"
      )}
    >
      <Checkbox
        checked={isSelected}
        onCheckedChange={onToggle}
        className="data-[state=checked]:bg-primary"
      />
      <span className="text-sm flex-1">{dimension.name}</span>
      {dimension.filterable && (
        <Badge variant="outline" className="h-4 text-[10px] px-1">
          Filter
        </Badge>
      )}
    </label>
  )
}
