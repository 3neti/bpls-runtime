"use client";

import type React from "react";
import { useMemo, useEffect } from "react";
import { useRouter } from "next/navigation";
import type { UseFormReturn } from "react-hook-form";
import Webcam from "react-webcam";
import { format } from "date-fns";
import { ArrowLeft, Calendar as CalendarIcon } from "lucide-react";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@repo/ui/components/tooltip";
import { Textarea } from "@repo/ui/components/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@repo/ui/components/table";
import { Badge } from "@repo/ui/components/badge";
import { Calendar } from "@repo/ui/components/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@repo/ui/components/popover";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import { ProfilePhotoUpload } from "./profile-photo-upload";
import { MOCK_BUSINESSES } from "@/lib/data/mock-businesses";
import { cn } from "@/lib/utils";
import { useLocationSelects } from "@/hooks/use-location-selects";
import { useDefaultLocations } from "@/hooks/use-default-locations";
import type { PermitFormSchema } from "@/lib/schemas/permit-form";
import type { BusinessOwnerFormSchema } from "@/lib/schemas/business-owner-form";

import type { CameraMode } from "@/lib/types/common";

// Union type for forms that can use this component
type BusinessOwnerFormType = UseFormReturn<PermitFormSchema> | UseFormReturn<BusinessOwnerFormSchema>;

// Type guard to check if form is PermitFormSchema
function isPermitFormType(form: BusinessOwnerFormType): form is UseFormReturn<PermitFormSchema> {
  const values = form.getValues();
  return "businessOwnerType" in values;
}

interface BusinessOwnerFormProps {
  form: BusinessOwnerFormType;
  profilePhotoPreview: string | null;
  cameraMode: CameraMode;
  cameraRef: React.RefObject<Webcam | null>;
  selectedOwnerId?: string;
  onBack: () => void;
  onPhotoChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onCameraModeChange: (mode: CameraMode) => void;
  onTakePhoto: () => void;
}

export function BusinessOwnerForm({
  form,
  profilePhotoPreview,
  cameraMode,
  cameraRef,
  selectedOwnerId,
  onBack,
  onPhotoChange,
  onCameraModeChange,
  onTakePhoto,
}: BusinessOwnerFormProps) {
  const router = useRouter();
  const formValues = form.watch();

  // Get default locations for new owners
  const {
    defaultProvinceId,
    defaultCityId,
    defaultBarangayId,
    isLoading: isLoadingDefaults,
  } = useDefaultLocations();
  // Check if ownerType exists (only in PermitFormSchema)
  const ownerType = "ownerType" in formValues ? formValues.ownerType : undefined;
  const isDisabled = ownerType === "existing" && !!selectedOwnerId;

  // Dynamic labels based on owner type
  // PermitFormSchema uses businessOwnerType/businessOwnerGroupName, BusinessOwnerFormSchema uses ownerType/groupName
  const isPermitForm = isPermitFormType(form);
  const currentOwnerType = isPermitForm
    ? (formValues as PermitFormSchema).businessOwnerType || "Single"
    : (formValues as BusinessOwnerFormSchema).ownerType &&
        ((formValues as BusinessOwnerFormSchema).ownerType === "Single" ||
          (formValues as BusinessOwnerFormSchema).ownerType === "Group")
      ? (formValues as BusinessOwnerFormSchema).ownerType
      : "Single";
  const currentGroupName = isPermitForm
    ? (formValues as PermitFormSchema).businessOwnerGroupName
    : (formValues as BusinessOwnerFormSchema).groupName;
  const personalInfoHeader = currentOwnerType === "Group" ? "Group Representative Information" : "Personal Information";

  // Type-safe setValue helpers
  const setFieldValue = <K extends keyof PermitFormSchema | keyof BusinessOwnerFormSchema>(
    field: K,
    value: unknown
  ) => {
    if (isPermitForm) {
      (form as UseFormReturn<PermitFormSchema>).setValue(field as keyof PermitFormSchema, value as never);
    } else {
      (form as UseFormReturn<BusinessOwnerFormSchema>).setValue(field as keyof BusinessOwnerFormSchema, value as never);
    }
  };

  // Determine effective initial values (use defaults for new owners only)
  const isNewOwner = !selectedOwnerId;
  const effectiveInitialProvinceId = formValues.provinceId || (isNewOwner ? (defaultProvinceId ?? "") : "");
  const effectiveInitialCityId = formValues.cityId || (isNewOwner ? (defaultCityId ?? "") : "");

  // Use the reusable location selects hook
  const {
    provinces,
    cities,
    barangays,
    handleProvinceChange,
    handleCityChange,
    handleBarangayChange,
    setSelections,
    setSelectedProvinceId,
    setSelectedCityId,
    isCityDisabled,
    isBarangayDisabled,
  } = useLocationSelects({
    initialProvinceId: effectiveInitialProvinceId,
    initialCityId: effectiveInitialCityId,
    onProvinceChange: (id) => setFieldValue("provinceId", id),
    onCityChange: (id) => setFieldValue("cityId", id),
    onBarangayChange: (id) => setFieldValue("barangayId", id),
  });

  // Apply all default locations at once when they finish loading (for new owners only)
  // Using setSelections to avoid cascade clearing that happens with handleProvinceChange
  useEffect(() => {
    if (isNewOwner && !isLoadingDefaults && defaultProvinceId && !formValues.provinceId) {
      // Set all locations at once to avoid cascade clearing
      setSelections(
        defaultProvinceId,
        defaultCityId ?? "",
        defaultBarangayId ?? undefined
      );
    }
  }, [isNewOwner, isLoadingDefaults, defaultProvinceId, defaultCityId, defaultBarangayId, formValues.provinceId, setSelections]);

  // Apply default city when cities are loaded (for new owners only)
  // This handles the case where city wasn't set initially because cities hadn't loaded yet
  useEffect(() => {
    if (isNewOwner && !isLoadingDefaults && cities && cities.length > 0 && defaultCityId) {
      // Apply default city if province matches and city not already set
      if (!formValues.cityId && formValues.provinceId === defaultProvinceId) {
        // Verify the city belongs to the selected province
        const cityExists = cities.some((c: { _id: string }) => c._id === defaultCityId);
        if (cityExists) {
          setFieldValue("cityId", defaultCityId);
          setSelectedCityId(defaultCityId);
        }
      }
    }
  }, [isNewOwner, isLoadingDefaults, cities, defaultCityId, defaultProvinceId, formValues.cityId, formValues.provinceId, setFieldValue, setSelectedCityId]);

  // Apply default barangay when barangays are loaded (for new owners only)
  useEffect(() => {
    if (isNewOwner && !isLoadingDefaults && barangays && barangays.length > 0 && defaultBarangayId) {
      // Apply default barangay if city matches and barangay not already set
      if (!formValues.barangayId && formValues.cityId === defaultCityId) {
        // Verify the barangay belongs to the selected city
        const barangayExists = barangays.some((b: { _id: string }) => b._id === defaultBarangayId);
        if (barangayExists) {
          setFieldValue("barangayId", defaultBarangayId);
        }
      }
    }
  }, [isNewOwner, isLoadingDefaults, barangays, defaultBarangayId, defaultCityId, formValues.barangayId, formValues.cityId, setFieldValue]);

  // Filter businesses by selected owner
  const ownerBusinesses = useMemo(() => {
    if (!selectedOwnerId) return [];

    return MOCK_BUSINESSES.filter((business) => business.ownerId === selectedOwnerId).map((business) => {
      // Calculate permit expiry (1 year from established date for simplicity)
      const establishedDate = new Date(business.establishedDate);
      const permitExpiry = new Date(establishedDate);
      permitExpiry.setFullYear(permitExpiry.getFullYear() + 1);

      // Check if permit is valid (not expired)
      const isValid = permitExpiry > new Date();

      return {
        id: business.id,
        name: business.name,
        scale: business.businessScale,
        industry: business.lineOfBusiness
          .split("-")
          .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
          .join(" "),
        permitValidity: isValid ? "Valid" : "Expired",
        permitExpiry: permitExpiry.toISOString().split("T")[0],
      };
    });
  }, [selectedOwnerId]);

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="outline" size="sm" className="cursor-pointer bg-transparent" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Back to Options</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <h3 className="text-lg font-semibold">
          {selectedOwnerId ? "Business Owner Information" : "New Business Owner Information"}
        </h3>
      </div>

      {/* Owner Type Selection - Show for both PermitFormSchema and BusinessOwnerFormSchema */}
      {(isPermitForm || "ownerType" in formValues) && (
        <Card>
          <CardHeader>
            <CardTitle>Owner Classification</CardTitle>
            <CardDescription>Select whether this is an individual or group/organization owner</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor={isPermitForm ? "businessOwnerType" : "ownerType"}>
                Owner Type <span className="text-destructive">*</span>
              </Label>
              <Select
                value={currentOwnerType}
                onValueChange={(value) => {
                  const ownerTypeValue = value as "Single" | "Group";
                  if (isPermitForm) {
                    form.setValue("businessOwnerType", ownerTypeValue);
                  } else {
                    form.setValue("ownerType", ownerTypeValue);
                  }
                }}
                disabled={isDisabled}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select owner type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Single">Single (Individual)</SelectItem>
                  <SelectItem value="Group">Group (Partnership/Corporation)</SelectItem>
                </SelectContent>
              </Select>
              {isPermitForm && form.formState.errors.businessOwnerType && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.businessOwnerType.message}</p>
              )}
              {!isPermitForm && form.formState.errors.ownerType && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.ownerType.message}</p>
              )}
            </div>

            {currentOwnerType === "Group" && (
              <div>
                <Label htmlFor={isPermitForm ? "businessOwnerGroupName" : "groupName"}>
                  Group/Organization Name <span className="text-destructive">*</span>
                </Label>
                <Input
                  id={isPermitForm ? "businessOwnerGroupName" : "groupName"}
                  value={currentGroupName || ""}
                  onChange={(e) => {
                    if (isPermitForm) {
                      form.setValue("businessOwnerGroupName", e.target.value);
                    } else {
                      form.setValue("groupName", e.target.value);
                    }
                  }}
                  placeholder="Enter group or organization name"
                  disabled={isDisabled}
                />
                {isPermitForm && form.formState.errors.businessOwnerGroupName && (
                  <p className="text-sm text-red-600 mt-1">{form.formState.errors.businessOwnerGroupName.message}</p>
                )}
                {!isPermitForm && form.formState.errors.groupName && (
                  <p className="text-sm text-red-600 mt-1">{form.formState.errors.groupName.message}</p>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Personal Information Section */}
      <div className="space-y-4">
        <div className="border-b pb-2">
          <h4 className="text-md font-medium text-primary">{personalInfoHeader}</h4>
        </div>

        <ProfilePhotoUpload
          profilePhotoPreview={profilePhotoPreview}
          cameraMode={cameraMode}
          isDisabled={isDisabled}
          onPhotoChange={onPhotoChange}
          onCameraModeChange={onCameraModeChange}
          onTakePhoto={onTakePhoto}
          cameraRef={cameraRef}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="firstName">
              First Name <span className="text-destructive">*</span>
            </Label>
            <Input
              id="firstName"
              name="firstName"
              value={formValues.firstName || ""}
              onChange={(e) => setFieldValue("firstName", e.target.value)}
              disabled={isDisabled}
            />
            {form.formState.errors.firstName && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.firstName.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="middleName">Middle Name</Label>
            <Input
              id="middleName"
              name="middleName"
              value={formValues.middleName || ""}
              onChange={(e) => setFieldValue("middleName", e.target.value)}
              disabled={isDisabled}
            />
          </div>

          <div>
            <Label htmlFor="lastName">
              Last Name <span className="text-destructive">*</span>
            </Label>
            <Input
              id="lastName"
              name="lastName"
              value={formValues.lastName || ""}
              onChange={(e) => setFieldValue("lastName", e.target.value)}
              disabled={isDisabled}
            />
            {form.formState.errors.lastName && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.lastName.message}</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <Label htmlFor="birthDate">
              Birth Date <span className="text-destructive">*</span>
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  disabled={isDisabled}
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !formValues.birthDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {formValues.birthDate ? format(new Date(formValues.birthDate), "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={formValues.birthDate ? new Date(formValues.birthDate) : undefined}
                  onSelect={(date) => {
                    if (date) {
                      setFieldValue("birthDate", format(date, "yyyy-MM-dd"));
                    }
                  }}
                  disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
                />
              </PopoverContent>
            </Popover>
            {form.formState.errors.birthDate && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.birthDate.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="civilStatus">
              Civil Status <span className="text-destructive">*</span>
            </Label>
            <Select
              value={formValues.civilStatus || ""}
              onValueChange={(value) => setFieldValue("civilStatus", value)}
              disabled={isDisabled}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="single">Single</SelectItem>
                <SelectItem value="married">Married</SelectItem>
                <SelectItem value="divorced">Divorced</SelectItem>
                <SelectItem value="widowed">Widowed</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.civilStatus && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.civilStatus.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="gender">
              Sex <span className="text-destructive">*</span>
            </Label>
            <Select
              value={formValues.gender || ""}
              onValueChange={(value) => setFieldValue("gender", value)}
              disabled={isDisabled}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select sex" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="female">Female</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.gender && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.gender.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="citizenship">
              Citizenship <span className="text-destructive">*</span>
            </Label>
            <Select
              value={formValues.citizenship || ""}
              onValueChange={(value) => setFieldValue("citizenship", value)}
              disabled={isDisabled}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select citizenship" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="filipino">Filipino</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.citizenship && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.citizenship.message}</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-1 gap-4">
          <div>
            <Label htmlFor="tin">
              TIN (Tax Identification Number) <span className="text-muted-foreground text-sm"></span>
            </Label>
            <Input
              id="tin"
              name="tin"
              placeholder="000-000-000-000"
              value={formValues.tin || ""}
              onChange={(e) => setFieldValue("tin", e.target.value)}
              disabled={isDisabled}
            />
            {form.formState.errors.tin && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.tin.message}</p>
            )}
          </div>
        </div>
      </div>

      {/* Contact Information Section */}
      <div className="space-y-4">
        <div className="border-b pb-2">
          <h4 className="text-md font-medium text-primary">Contact Information</h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="mobile">
              Mobile Number <span className="text-destructive">*</span>
            </Label>
            <Input
              id="mobile"
              name="mobile"
              placeholder="+63 912 345 6789"
              value={formValues.mobile || ""}
              onChange={(e) => setFieldValue("mobile", e.target.value)}
              disabled={isDisabled}
            />
            {form.formState.errors.mobile && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.mobile.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="email">
              Email Address <span className="text-destructive">*</span>
            </Label>
            <Input
              id="email"
              name="email"
              type="email"
              value={formValues.email || ""}
              onChange={(e) => setFieldValue("email", e.target.value)}
              disabled={isDisabled}
            />
            {form.formState.errors.email && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.email.message}</p>
            )}
          </div>
        </div>
      </div>

      {/* Address Information Section */}
      <div className="space-y-4">
        <div className="border-b pb-2">
          <h4 className="text-md font-medium text-primary">Address Information</h4>
        </div>

        <div>
          <Label htmlFor="address">
            Street Address <span className="text-muted-foreground text-sm"></span>
          </Label>
          <Input
            id="address"
            name="address"
            value={formValues.address || ""}
            onChange={(e) => setFieldValue("address", e.target.value)}
            placeholder="House No., Street Name, Building Name"
            disabled={isDisabled}
          />
          {form.formState.errors.address && (
            <p className="text-sm text-red-600 mt-1">{form.formState.errors.address.message}</p>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="provinceId">
              Province <span className="text-destructive">*</span>
            </Label>
            <Select
              value={formValues.provinceId || ""}
              onValueChange={handleProvinceChange}
              disabled={isDisabled}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select province" />
              </SelectTrigger>
              <SelectContent>
                {provinces?.map((province: { _id: string; name: string }) => (
                  <SelectItem key={province._id} value={province._id}>
                    {province.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.provinceId && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.provinceId.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="cityId">
              City/Municipality <span className="text-destructive">*</span>
            </Label>
            <Select
              value={formValues.cityId || ""}
              onValueChange={handleCityChange}
              disabled={isCityDisabled || isDisabled}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select city/municipality" />
              </SelectTrigger>
              <SelectContent>
                {cities?.map((city: { _id: string; name: string }) => (
                  <SelectItem key={city._id} value={city._id}>
                    {city.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.cityId && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.cityId.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="barangayId">
              Barangay <span className="text-destructive">*</span>
            </Label>
            <Select
              value={formValues.barangayId || ""}
              onValueChange={handleBarangayChange}
              disabled={isBarangayDisabled || isDisabled}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select barangay" />
              </SelectTrigger>
              <SelectContent>
                {barangays?.map((barangay: { _id: string; name: string }) => (
                  <SelectItem key={barangay._id} value={barangay._id}>
                    {barangay.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.barangayId && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.barangayId.message}</p>
            )}
          </div>
        </div>
      </div>

      {/* Owned Businesses Section */}
      <div className="space-y-4">
        <div className="border-b pb-2">
          <h4 className="text-md font-medium text-primary">Owned Businesses</h4>
        </div>

        <div className="border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Business ID</TableHead>
                <TableHead>Business Name</TableHead>
                <TableHead>Scale</TableHead>
                <TableHead>Industry</TableHead>
                <TableHead>Permit Validity</TableHead>
                <TableHead>Permit Expiry</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {ownerBusinesses.length > 0 ? (
                ownerBusinesses.map((business) => (
                  <TableRow
                    key={business.id}
                    className="cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => router.push(`/dashboard/businesses/${business.id}`)}
                  >
                    <TableCell className="font-medium">{business.id}</TableCell>
                    <TableCell>{business.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {business.scale}
                      </Badge>
                    </TableCell>
                    <TableCell>{business.industry}</TableCell>
                    <TableCell>
                      <Badge
                        variant={business.permitValidity === "Valid" ? "default" : "destructive"}
                        className="text-xs"
                      >
                        {business.permitValidity}
                      </Badge>
                    </TableCell>
                    <TableCell>{business.permitExpiry}</TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground">
                    No businesses found for this owner
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {/* Remarks text area */}
        <div className="space-y-2">
          <Label htmlFor="remarks">Remarks</Label>
          <Textarea
            id="remarks"
            placeholder="Add any additional remarks or notes about the business owner..."
            className="min-h-[100px]"
          />
        </div>
      </div>
    </div>
  );
}
