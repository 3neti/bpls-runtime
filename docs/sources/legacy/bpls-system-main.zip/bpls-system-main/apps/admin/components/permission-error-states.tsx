import { Lock, AlertTriangle, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { Alert, AlertDescription, AlertTitle } from "@repo/ui/components/alert"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Button } from "@repo/ui/components/button"

interface PermissionErrorDetails {
  resource?: string
  action?: string
  userRole?: string
  requiredPermission?: string
}

interface PermissionDeniedProps {
  title: string
  description?: string
  message?: string
  details?: PermissionErrorDetails
  resourceName?: string
  backLink?: string
  backLinkText?: string
}

interface AuthenticationRequiredProps {
  message?: string
}

/**
 * Displays a permission denied error when users lack required permissions
 *
 * Usage:
 * ```tsx
 * <PermissionDenied
 *   title="Permits"
 *   description="Manage business permits"
 *   message={errorData.message}
 *   details={errorData.details}
 *   resourceName="permit"
 * />
 * ```
 */
export function PermissionDenied({
  title,
  description = "Manage resources",
  message,
  details,
  resourceName = "resource",
  backLink,
  backLinkText,
}: PermissionDeniedProps) {
  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      {backLink && backLinkText && (
        <div className="flex items-center gap-4">
          <Link href={backLink}>
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              {backLinkText}
            </Button>
          </Link>
        </div>
      )}

      <div>
        <h1 className="text-3xl font-bold tracking-tight">{title}</h1>
        <p className="text-muted-foreground">{description}</p>
      </div>

      <Alert variant="destructive">
        <Lock className="h-4 w-4" />
        <AlertTitle>Access Denied</AlertTitle>
        <AlertDescription>
          <div className="space-y-2">
            <p>{message || `You don't have permission to access ${resourceName}s.`}</p>
            {details && (
              <div className="text-sm mt-2 space-y-1">
                <p>
                  <span className="font-medium">Your Role:</span> {details.userRole}
                </p>
                <p>
                  <span className="font-medium">Required Permission:</span>{" "}
                  {details.requiredPermission}
                </p>
              </div>
            )}
            <p className="text-sm mt-3 pt-3 border-t border-destructive/20">
              Please contact your administrator to request access to this resource.
            </p>
          </div>
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            What You Can Do
          </CardTitle>
          <CardDescription>
            While you wait for access{backLink ? "" : ", you can explore other features"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="list-disc list-inside space-y-2 text-sm text-muted-foreground">
            <li>Contact your system administrator to request {resourceName} access</li>
            <li>Check your user profile to see your current {backLink ? "permissions" : "role and permissions"}</li>
            <li>{backLink ? "Return to the dashboard to explore other features" : "Explore other sections of the dashboard that you have access to"}</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

/**
 * Displays an authentication required error when users are not logged in
 *
 * Usage:
 * ```tsx
 * <AuthenticationRequired />
 * ```
 */
export function AuthenticationRequired({
  message = "Please log in to access this page.",
}: AuthenticationRequiredProps) {
  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      <Alert variant="destructive">
        <Lock className="h-4 w-4" />
        <AlertTitle>Authentication Required</AlertTitle>
        <AlertDescription>{message}</AlertDescription>
      </Alert>
    </div>
  )
}
