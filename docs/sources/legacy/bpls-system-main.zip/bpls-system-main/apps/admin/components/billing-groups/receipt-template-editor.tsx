"use client"

import { useState, useEffect, useCallback, useMemo } from "react"
import { useQuery, useMutation } from "convex/react"
import {
  Save,
  Eye,
  EyeOff,
  Loader2,
  Plus,
  Edit,
  Trash2,
  Copy,
  Star,
  MoreHorizontal,
  FileText,
  ArrowLeft,
} from "lucide-react"
import dynamic from "next/dynamic"

import { Button } from "@repo/ui/components/button"
import { Input } from "@repo/ui/components/input"
import { Label } from "@repo/ui/components/label"
import { Textarea } from "@repo/ui/components/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@repo/ui/components/tabs"
import { Skeleton } from "@repo/ui/components/skeleton"
import { Badge } from "@repo/ui/components/badge"
import { Separator } from "@repo/ui/components/separator"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import { useToast } from "@/hooks/use-toast"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import {
  getSampleBillingGroupData,
  validateBillingGroupTemplate,
  parseBillingGroupTemplate,
} from "@/lib/utils/billing-group-template-renderer"
import { BillingGroupMacroPicker } from "./billing-group-macro-picker"

// Dynamically import PDF components to avoid SSR issues
const BillingGroupLayoutPreview = dynamic(
  () => import("./billing-group-layout-preview"),
  {
    ssr: false,
    loading: () => <Skeleton className="h-full w-full" />,
  }
)

interface ReceiptTemplateEditorProps {
  billingGroupId: Id<"billing_groups">
  canCreate?: boolean
  canUpdate?: boolean
}

export function ReceiptTemplateEditor({
  billingGroupId,
  canCreate = true,
  canUpdate = true,
}: ReceiptTemplateEditorProps) {
  const { toast } = useToast()

  // Queries
  const layouts = useQuery(api.billingGroupPrintLayouts.listByGroup, {
    billingGroupId,
  })
  const billingGroup = useQuery(api.billingGroups.getById, { id: billingGroupId })
  const customFields = useQuery(api.billingGroupFields.listByGroup, {
    billingGroupId,
  })

  // Mutations
  const createLayout = useMutation(api.billingGroupPrintLayouts.create)
  const updateLayout = useMutation(api.billingGroupPrintLayouts.update)
  const deleteLayout = useMutation(api.billingGroupPrintLayouts.softDelete)
  const duplicateLayout = useMutation(api.billingGroupPrintLayouts.duplicate)
  const setDefaultLayout = useMutation(api.billingGroupPrintLayouts.setDefault)

  // View state: "list" or "editor"
  const [view, setView] = useState<"list" | "editor">("list")
  const [editingLayoutId, setEditingLayoutId] = useState<Id<"billing_group_print_layouts"> | null>(null)

  // Dialog states
  const [createDialogOpen, setCreateDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)

  // Form states for create dialog
  const [newLayoutName, setNewLayoutName] = useState("")
  const [newLayoutDescription, setNewLayoutDescription] = useState("")
  const [layoutToDelete, setLayoutToDelete] = useState<Id<"billing_group_print_layouts"> | null>(null)
  const [isCreating, setIsCreating] = useState(false)

  const isLoading = layouts === undefined
  const billingGroupName = billingGroup?.name || "Billing Group"

  // Create new layout
  const handleCreate = async () => {
    if (!newLayoutName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a layout name",
        variant: "destructive",
      })
      return
    }

    setIsCreating(true)
    try {
      const layoutId = await createLayout({
        billingGroupId,
        name: newLayoutName.trim(),
        description: newLayoutDescription.trim() || undefined,
      })
      toast({
        title: "Layout created",
        description: "Your new receipt layout has been created.",
      })
      setCreateDialogOpen(false)
      setNewLayoutName("")
      setNewLayoutDescription("")
      // Open editor for the new layout
      setEditingLayoutId(layoutId)
      setView("editor")
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create layout",
        variant: "destructive",
      })
    } finally {
      setIsCreating(false)
    }
  }

  // Delete layout
  const handleDelete = async () => {
    if (!layoutToDelete) return

    try {
      await deleteLayout({ id: layoutToDelete })
      toast({
        title: "Layout deleted",
        description: "The receipt layout has been deleted.",
      })
      setDeleteDialogOpen(false)
      setLayoutToDelete(null)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete layout",
        variant: "destructive",
      })
    }
  }

  // Duplicate layout
  const handleDuplicate = async (id: Id<"billing_group_print_layouts">) => {
    try {
      await duplicateLayout({ id })
      toast({
        title: "Layout duplicated",
        description: "A copy of the layout has been created.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to duplicate layout",
        variant: "destructive",
      })
    }
  }

  // Set as default
  const handleSetDefault = async (id: Id<"billing_group_print_layouts">) => {
    try {
      await setDefaultLayout({ id })
      toast({
        title: "Default updated",
        description: "This layout is now the default.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to set default",
        variant: "destructive",
      })
    }
  }

  // Open editor view
  const handleEdit = (id: Id<"billing_group_print_layouts">) => {
    setEditingLayoutId(id)
    setView("editor")
  }

  // Go back to list view
  const handleBack = () => {
    setView("list")
    setEditingLayoutId(null)
  }

  // Confirm delete
  const confirmDelete = (id: Id<"billing_group_print_layouts">) => {
    setLayoutToDelete(id)
    setDeleteDialogOpen(true)
  }

  // Editor View
  if (view === "editor" && editingLayoutId) {
    return (
      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleBack}
              className="h-8 w-8"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <CardTitle>Edit Receipt Layout</CardTitle>
              <CardDescription>
                Customize your receipt template using macros for dynamic content.
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-[calc(100vh-280px)] min-h-[600px]">
            <LayoutEditor
              layoutId={editingLayoutId}
              billingGroupId={billingGroupId}
              billingGroupName={billingGroupName}
              customFields={customFields || []}
              canUpdate={canUpdate}
              onSave={() => {
                toast({
                  title: "Layout saved",
                  description: "Your changes have been saved.",
                })
              }}
              onClose={handleBack}
            />
          </div>
        </CardContent>
      </Card>
    )
  }

  // List View
  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Receipt Layouts</CardTitle>
              <CardDescription>
                Configure custom receipt layouts for this billing group.
                Use templates with macros like {"{{transactionNumber}}"} for dynamic content.
              </CardDescription>
            </div>
            {canCreate && (
              <Button onClick={() => setCreateDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                New Layout
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {/* Layout count */}
          {!isLoading && layouts && (
            <p className="text-sm text-muted-foreground mb-4">
              {layouts.length} layout{layouts.length !== 1 ? "s" : ""} configured
            </p>
          )}

          {/* Loading state */}
          {isLoading ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-32 w-full" />
              ))}
            </div>
          ) : layouts && layouts.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {layouts.map((layout: NonNullable<typeof layouts>[number]) => (
                <LayoutCard
                  key={layout._id}
                  layout={layout}
                  billingGroupName={billingGroupName}
                  canCreate={canCreate}
                  canUpdate={canUpdate}
                  onEdit={() => handleEdit(layout._id)}
                  onDelete={() => confirmDelete(layout._id)}
                  onDuplicate={() => handleDuplicate(layout._id)}
                  onSetDefault={() => handleSetDefault(layout._id)}
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <FileText className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No receipt layouts yet</h3>
              <p className="text-sm text-muted-foreground mt-1 mb-4">
                Create your first custom receipt layout to get started.
              </p>
              {canCreate && (
                <Button onClick={() => setCreateDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Create Layout
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Layout Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Receipt Layout</DialogTitle>
            <DialogDescription>
              Create a new receipt layout template. You can customize it after creation.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Layout Name</Label>
              <Input
                id="name"
                placeholder="e.g., Standard Receipt, Detailed Receipt"
                value={newLayoutName}
                onChange={(e) => setNewLayoutName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description (optional)</Label>
              <Textarea
                id="description"
                placeholder="Describe what this layout is for..."
                value={newLayoutDescription}
                onChange={(e) => setNewLayoutDescription(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreate} disabled={isCreating}>
              {isCreating && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Create Layout
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Receipt Layout</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this receipt layout? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setLayoutToDelete(null)}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}

// Layout Card Component
interface LayoutCardProps {
  layout: {
    _id: Id<"billing_group_print_layouts">
    name: string
    description?: string
    isDefault: boolean
    isActive: boolean
    paperSize: string
    orientation: string
    headerTemplate: string
    bodyTemplate: string
    footerTemplate: string
    createdAt: string
    updatedAt: string
  }
  billingGroupName: string
  canCreate?: boolean
  canUpdate?: boolean
  onEdit: () => void
  onDelete: () => void
  onDuplicate: () => void
  onSetDefault: () => void
}

function LayoutCard({
  layout,
  billingGroupName,
  canCreate = true,
  canUpdate = true,
  onEdit,
  onDelete,
  onDuplicate,
  onSetDefault,
}: LayoutCardProps) {
  // Generate preview content with sample data
  const previewContent = useMemo(() => {
    const sampleData = getSampleBillingGroupData(billingGroupName)

    // Replace macros with sample data
    const replaceMacros = (template: string) => {
      try {
        let result = parseBillingGroupTemplate(template, sampleData)
        // Replace LINE_ITEMS_TABLE with placeholder for preview
        result = result.replace("{{LINE_ITEMS_TABLE}}", "[Line Items Table]")
        return result
      } catch {
        return template
      }
    }

    const header = replaceMacros(layout.headerTemplate || "")
    const body = replaceMacros(layout.bodyTemplate || "")
    const footer = replaceMacros(layout.footerTemplate || "")

    return [header, body, footer].filter(Boolean).join("\n")
  }, [layout.headerTemplate, layout.bodyTemplate, layout.footerTemplate, billingGroupName])

  return (
    <Card className="relative group flex flex-col">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <CardTitle className="text-base flex items-center gap-2">
              {layout.name}
              {layout.isDefault && (
                <Badge variant="secondary" className="text-xs">
                  <Star className="h-3 w-3 mr-1 fill-current" />
                  Default
                </Badge>
              )}
            </CardTitle>
            {layout.description && (
              <CardDescription className="text-xs line-clamp-2">
                {layout.description}
              </CardDescription>
            )}
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={onEdit}>
                <Edit className="mr-2 h-4 w-4" />
                Edit
              </DropdownMenuItem>
              {canCreate && (
                <DropdownMenuItem onClick={onDuplicate}>
                  <Copy className="mr-2 h-4 w-4" />
                  Duplicate
                </DropdownMenuItem>
              )}
              {!layout.isDefault && (
                <DropdownMenuItem onClick={onSetDefault} disabled={!canUpdate}>
                  <Star className="mr-2 h-4 w-4" />
                  Set as Default
                </DropdownMenuItem>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={onDelete}
                disabled={!canUpdate}
                className="text-destructive focus:text-destructive"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent className="pt-2 flex-1 flex flex-col">
        {/* Preview Area */}
        <div
          className="flex-1 min-h-[120px] max-h-[180px] mb-3 p-2 bg-white dark:bg-zinc-900 border rounded-md overflow-hidden cursor-pointer hover:border-primary/50 transition-colors"
          onClick={onEdit}
        >
          <div className="h-full overflow-hidden">
            <pre className="text-[6px] leading-tight font-mono text-foreground whitespace-pre-wrap break-words">
              {previewContent}
            </pre>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
          <span>{layout.paperSize}</span>
          <span>•</span>
          <span className="capitalize">{layout.orientation}</span>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="w-full"
          onClick={onEdit}
        >
          <Edit className="mr-2 h-3 w-3" />
          Edit Template
        </Button>
      </CardContent>
    </Card>
  )
}

// Layout Editor Component (matches Settings > Receipting editor)
interface LayoutEditorProps {
  layoutId: Id<"billing_group_print_layouts">
  billingGroupId: Id<"billing_groups">
  billingGroupName: string
  customFields: Array<{ _id: Id<"billing_group_fields">; name: string }>
  canUpdate?: boolean
  onSave: () => void
  onClose: () => void
}

function LayoutEditor({
  layoutId,
  billingGroupId,
  billingGroupName,
  customFields,
  canUpdate = true,
  onSave,
  onClose,
}: LayoutEditorProps) {
  const layout = useQuery(api.billingGroupPrintLayouts.getById, { id: layoutId })
  const updateLayout = useMutation(api.billingGroupPrintLayouts.update)

  // Form state
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [paperSize, setPaperSize] = useState<"A4" | "Letter" | "Half-Letter">("A4")
  const [orientation, setOrientation] = useState<"portrait" | "landscape">("portrait")
  const [marginTop, setMarginTop] = useState(10)
  const [marginRight, setMarginRight] = useState(10)
  const [marginBottom, setMarginBottom] = useState(10)
  const [marginLeft, setMarginLeft] = useState(10)
  const [fontSize, setFontSize] = useState(10)
  const [fontFamily, setFontFamily] = useState<"Helvetica" | "Times-Roman" | "Courier">("Helvetica")
  const [headerTemplate, setHeaderTemplate] = useState("")
  const [bodyTemplate, setBodyTemplate] = useState("")
  const [footerTemplate, setFooterTemplate] = useState("")

  // UI state
  const [showPreview, setShowPreview] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [hasChanges, setHasChanges] = useState(false)
  const [activeTab, setActiveTab] = useState("header")

  // Cursor positions for macro insertion
  const [headerCursor, setHeaderCursor] = useState<number | null>(null)
  const [bodyCursor, setBodyCursor] = useState<number | null>(null)
  const [footerCursor, setFooterCursor] = useState<number | null>(null)

  // Debounced templates for preview
  const [debouncedHeader, setDebouncedHeader] = useState("")
  const [debouncedBody, setDebouncedBody] = useState("")
  const [debouncedFooter, setDebouncedFooter] = useState("")

  // Debounce template updates for preview
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedHeader(headerTemplate)
      setDebouncedBody(bodyTemplate)
      setDebouncedFooter(footerTemplate)
    }, 300)
    return () => clearTimeout(timer)
  }, [headerTemplate, bodyTemplate, footerTemplate])

  // Initialize form from layout data
  useEffect(() => {
    if (layout) {
      setName(layout.name)
      setDescription(layout.description || "")
      setPaperSize(layout.paperSize)
      setOrientation(layout.orientation)
      setMarginTop(layout.marginTop)
      setMarginRight(layout.marginRight)
      setMarginBottom(layout.marginBottom)
      setMarginLeft(layout.marginLeft)
      setFontSize(layout.fontSize)
      setFontFamily(layout.fontFamily)
      setHeaderTemplate(layout.headerTemplate)
      setBodyTemplate(layout.bodyTemplate)
      setFooterTemplate(layout.footerTemplate)
      setHasChanges(false)
    }
  }, [layout])

  // Track changes
  const markChanged = useCallback(() => {
    setHasChanges(true)
  }, [])

  // Sample data for preview
  const sampleData = useMemo(() => {
    return getSampleBillingGroupData(billingGroupName)
  }, [billingGroupName])

  // Get custom field IDs for validation
  const customFieldIds = useMemo(() => {
    return customFields?.map((f) => f._id) || []
  }, [customFields])

  // Validate templates
  const headerValidation = useMemo(
    () => validateBillingGroupTemplate(headerTemplate, customFieldIds),
    [headerTemplate, customFieldIds]
  )
  const bodyValidation = useMemo(
    () => validateBillingGroupTemplate(bodyTemplate, customFieldIds),
    [bodyTemplate, customFieldIds]
  )
  const footerValidation = useMemo(
    () => validateBillingGroupTemplate(footerTemplate, customFieldIds),
    [footerTemplate, customFieldIds]
  )

  // Handle save
  const handleSave = async () => {
    setIsSaving(true)
    try {
      await updateLayout({
        id: layoutId,
        name,
        description: description || undefined,
        paperSize,
        orientation,
        marginTop,
        marginRight,
        marginBottom,
        marginLeft,
        fontSize,
        fontFamily,
        headerTemplate,
        bodyTemplate,
        footerTemplate,
      })
      setHasChanges(false)
      onSave()
    } catch (error) {
      console.error("Failed to save layout:", error)
    } finally {
      setIsSaving(false)
    }
  }

  // Insert macro at cursor position
  const insertMacro = (macro: string) => {
    const macroText = `{{${macro}}}`

    if (activeTab === "header" && headerCursor !== null) {
      const before = headerTemplate.slice(0, headerCursor)
      const after = headerTemplate.slice(headerCursor)
      setHeaderTemplate(before + macroText + after)
      markChanged()
    } else if (activeTab === "body" && bodyCursor !== null) {
      const before = bodyTemplate.slice(0, bodyCursor)
      const after = bodyTemplate.slice(bodyCursor)
      setBodyTemplate(before + macroText + after)
      markChanged()
    } else if (activeTab === "footer" && footerCursor !== null) {
      const before = footerTemplate.slice(0, footerCursor)
      const after = footerTemplate.slice(footerCursor)
      setFooterTemplate(before + macroText + after)
      markChanged()
    } else {
      // If no cursor position, append to the active template
      if (activeTab === "header") {
        setHeaderTemplate((prev) => prev + macroText)
      } else if (activeTab === "body") {
        setBodyTemplate((prev) => prev + macroText)
      } else if (activeTab === "footer") {
        setFooterTemplate((prev) => prev + macroText)
      }
      markChanged()
    }
  }

  if (!layout) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center justify-between pb-4 border-b">
        <div className="flex items-center gap-4">
          <div className="space-y-1">
            <Input
              value={name}
              onChange={(e) => {
                setName(e.target.value)
                markChanged()
              }}
              disabled={!canUpdate}
              className="font-medium text-lg h-8 w-64"
              placeholder="Layout name"
            />
          </div>
          {hasChanges && (
            <Badge variant="outline" className="text-yellow-600">
              Unsaved changes
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowPreview(!showPreview)}
          >
            {showPreview ? (
              <>
                <EyeOff className="mr-2 h-4 w-4" />
                Hide Preview
              </>
            ) : (
              <>
                <Eye className="mr-2 h-4 w-4" />
                Show Preview
              </>
            )}
          </Button>
          <Button
            size="sm"
            onClick={handleSave}
            disabled={isSaving || !hasChanges || !canUpdate}
          >
            {isSaving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Save
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-1 gap-4 pt-4 overflow-hidden">
        {/* Editor Panel */}
        <div className={`flex flex-col ${showPreview ? "w-1/2" : "w-full"} overflow-hidden`}>
          {/* Settings - Fixed height section */}
          <div className="flex-shrink-0 space-y-4 pr-4 pb-4">
            {/* Paper & Font Settings */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Paper Size</Label>
                <Select
                  value={paperSize}
                  onValueChange={(value: "A4" | "Letter" | "Half-Letter") => {
                    setPaperSize(value)
                    markChanged()
                  }}
                  disabled={!canUpdate}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="A4">A4 (210 × 297 mm)</SelectItem>
                    <SelectItem value="Letter">Letter (8.5 × 11 in)</SelectItem>
                    <SelectItem value="Half-Letter">Half Letter (5.5 × 8.5 in)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Orientation</Label>
                <Select
                  value={orientation}
                  onValueChange={(value: "portrait" | "landscape") => {
                    setOrientation(value)
                    markChanged()
                  }}
                  disabled={!canUpdate}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="portrait">Portrait</SelectItem>
                    <SelectItem value="landscape">Landscape</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Font Family</Label>
                <Select
                  value={fontFamily}
                  onValueChange={(value: "Helvetica" | "Times-Roman" | "Courier") => {
                    setFontFamily(value)
                    markChanged()
                  }}
                  disabled={!canUpdate}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Helvetica">Helvetica (Sans-serif)</SelectItem>
                    <SelectItem value="Times-Roman">Times Roman (Serif)</SelectItem>
                    <SelectItem value="Courier">Courier (Monospace)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Font Size (pt)</Label>
                <Input
                  type="number"
                  min={6}
                  max={24}
                  value={fontSize}
                  onChange={(e) => {
                    setFontSize(Number(e.target.value))
                    markChanged()
                  }}
                  disabled={!canUpdate}
                />
              </div>
            </div>

            {/* Margins */}
            <div className="space-y-2">
              <Label>Margins (mm)</Label>
              <div className="grid grid-cols-4 gap-2">
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Top</span>
                  <Input
                    type="number"
                    min={0}
                    max={100}
                    value={marginTop}
                    onChange={(e) => {
                      setMarginTop(Number(e.target.value))
                      markChanged()
                    }}
                    disabled={!canUpdate}
                  />
                </div>
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Right</span>
                  <Input
                    type="number"
                    min={0}
                    max={100}
                    value={marginRight}
                    onChange={(e) => {
                      setMarginRight(Number(e.target.value))
                      markChanged()
                    }}
                    disabled={!canUpdate}
                  />
                </div>
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Bottom</span>
                  <Input
                    type="number"
                    min={0}
                    max={100}
                    value={marginBottom}
                    onChange={(e) => {
                      setMarginBottom(Number(e.target.value))
                      markChanged()
                    }}
                    disabled={!canUpdate}
                  />
                </div>
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Left</span>
                  <Input
                    type="number"
                    min={0}
                    max={100}
                    value={marginLeft}
                    onChange={(e) => {
                      setMarginLeft(Number(e.target.value))
                      markChanged()
                    }}
                    disabled={!canUpdate}
                  />
                </div>
              </div>
            </div>
          </div>

          <Separator className="flex-shrink-0" />

          {/* Template Sections - Fills remaining space */}
          <div className="flex-1 flex flex-col min-h-0 pt-4 pr-4">
            <div className="flex items-center justify-between flex-shrink-0 mb-2">
              <Label>Template Sections</Label>
              <BillingGroupMacroPicker
                billingGroupId={billingGroupId}
                onSelect={insertMacro}
              />
            </div>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col min-h-0">
              <TabsList className="grid w-full grid-cols-3 flex-shrink-0">
                <TabsTrigger value="header">Header</TabsTrigger>
                <TabsTrigger value="body">Body</TabsTrigger>
                <TabsTrigger value="footer">Footer</TabsTrigger>
              </TabsList>
              <TabsContent value="header" className="flex-1 flex flex-col min-h-0 mt-2">
                <div className="flex-1 overflow-hidden rounded-md border">
                  <Textarea
                    value={headerTemplate}
                    onChange={(e) => {
                      setHeaderTemplate(e.target.value)
                      markChanged()
                    }}
                    onSelect={(e) => {
                      setHeaderCursor((e.target as HTMLTextAreaElement).selectionStart)
                    }}
                    disabled={!canUpdate}
                    placeholder="Enter header template..."
                    className="font-mono text-sm h-full w-full resize-none border-0 rounded-none [field-sizing:fixed]"
                  />
                </div>
                {headerValidation.warnings.length > 0 && (
                  <p className="text-xs text-yellow-600 mt-1 flex-shrink-0">
                    {headerValidation.warnings.join(", ")}
                  </p>
                )}
              </TabsContent>
              <TabsContent value="body" className="flex-1 flex flex-col min-h-0 mt-2">
                <div className="flex-1 overflow-hidden rounded-md border">
                  <Textarea
                    value={bodyTemplate}
                    onChange={(e) => {
                      setBodyTemplate(e.target.value)
                      markChanged()
                    }}
                    onSelect={(e) => {
                      setBodyCursor((e.target as HTMLTextAreaElement).selectionStart)
                    }}
                    disabled={!canUpdate}
                    placeholder="Enter body template (use {{LINE_ITEMS_TABLE}} for the line items table)..."
                    className="font-mono text-sm h-full w-full resize-none border-0 rounded-none [field-sizing:fixed]"
                  />
                </div>
                {bodyValidation.warnings.length > 0 && (
                  <p className="text-xs text-yellow-600 mt-1 flex-shrink-0">
                    {bodyValidation.warnings.join(", ")}
                  </p>
                )}
              </TabsContent>
              <TabsContent value="footer" className="flex-1 flex flex-col min-h-0 mt-2">
                <div className="flex-1 overflow-hidden rounded-md border">
                  <Textarea
                    value={footerTemplate}
                    onChange={(e) => {
                      setFooterTemplate(e.target.value)
                      markChanged()
                    }}
                    onSelect={(e) => {
                      setFooterCursor((e.target as HTMLTextAreaElement).selectionStart)
                    }}
                    disabled={!canUpdate}
                    placeholder="Enter footer template..."
                    className="font-mono text-sm h-full w-full resize-none border-0 rounded-none [field-sizing:fixed]"
                  />
                </div>
                {footerValidation.warnings.length > 0 && (
                  <p className="text-xs text-yellow-600 mt-1 flex-shrink-0">
                    {footerValidation.warnings.join(", ")}
                  </p>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Preview Panel */}
        {showPreview && (
          <div className="w-1/2 border rounded-lg overflow-hidden bg-muted/30">
            <div className="p-2 border-b bg-muted/50 flex items-center justify-between">
              <span className="text-sm font-medium">Preview (Sample Data)</span>
              <Badge variant="outline" className="text-xs">
                {paperSize} • {orientation}
              </Badge>
            </div>
            <div className="h-[calc(100%-40px)]">
              <BillingGroupLayoutPreview
                headerTemplate={debouncedHeader}
                bodyTemplate={debouncedBody}
                footerTemplate={debouncedFooter}
                paperSize={paperSize}
                orientation={orientation}
                marginTop={marginTop}
                marginRight={marginRight}
                marginBottom={marginBottom}
                marginLeft={marginLeft}
                fontSize={fontSize}
                fontFamily={fontFamily}
                data={sampleData}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
