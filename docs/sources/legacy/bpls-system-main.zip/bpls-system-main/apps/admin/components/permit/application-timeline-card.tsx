"use client"

import { useState } from "react"
import { usePaginatedQuery, usePreloadedQuery, useQuery } from "convex/react"
import type { Preloaded } from "convex/react"
import { Clock, AlertCircle, FileText, CreditCard, ShieldCheck, Loader2 } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"
import { Button } from "@repo/ui/components/button"
import { Skeleton } from "@repo/ui/components/skeleton"
import { api } from "@repo/backend/convex/_generated/api"
import { cn } from "@/lib/utils"
import { formatDate } from "@/lib/utils/formatting"

const INITIAL_PAGE_SIZE = 20
const EXPANDED_PAGE_SIZE = 100

export interface ApplicationTimelineCardProps {
  resourceId: string
  resourceType: string
  preloadedActivityLogs?: Preloaded<typeof api.activityLogs.getResourceHistory>
  title?: string
}

type ActivityLog = {
  _id: string
  action: string
  resourceType: string
  description: string
  performerName: string
  timestamp: number
  changes?: string
  metadata?: string
}

function getActionIcon(action: string) {
  switch (action) {
    case "status_change":
      return <Clock className="h-4 w-4" />
    case "payment":
      return <AlertCircle className="h-4 w-4" />
    case "create":
      return <FileText className="h-4 w-4" />
    case "verification":
      return <ShieldCheck className="h-4 w-4" />
    case "issued":
      return <CreditCard className="h-4 w-4" />
    case "update":
      return <FileText className="h-4 w-4" />
    case "delete":
      return <AlertCircle className="h-4 w-4" />
    case "restore":
      return <FileText className="h-4 w-4" />
    default:
      return <Clock className="h-4 w-4" />
  }
}

function getStatusBadgeClasses(status: string): string {
  const normalized = status.toLowerCase().replace(/\s+/g, "_")
  const map: Record<string, string> = {
    draft: "bg-gray-100 text-gray-700 border-gray-300",
    assessment: "bg-yellow-100 text-yellow-700 border-yellow-300",
    pending_payment: "bg-orange-100 text-orange-700 border-orange-300",
    released: "bg-blue-100 text-blue-700 border-blue-300",
    processing: "bg-amber-100 text-amber-700 border-amber-300",
    for_approval: "bg-purple-100 text-purple-700 border-purple-300",
    approved: "bg-green-100 text-green-700 border-green-300",
    for_release: "bg-emerald-100 text-emerald-700 border-emerald-300",
  }
  return map[normalized] || "bg-gray-100 text-gray-700 border-gray-300"
}

function formatStatusLabel(status: string): string {
  return status
    .replace(/_/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase())
}

type ParsedChange = {
  field: string
  label: string
  before?: unknown
  after: unknown
}

const FIELD_LABELS: Record<string, string> = {
  firstName: "First Name",
  middleName: "Middle Name",
  lastName: "Last Name",
  birthDate: "Birth Date",
  civilStatus: "Civil Status",
  gender: "Gender",
  citizenship: "Citizenship",
  tin: "TIN",
  mobile: "Mobile",
  email: "Email",
  address: "Address",
  avatar: "Avatar",
  ownerType: "Owner Type",
  groupName: "Group Name",
  isBlacklisted: "Blacklisted",
  blacklistReason: "Blacklist Reason",
  name: "Business Name",
  businessScale: "Business Scale",
  annualRevenue: "Annual Revenue",
  establishedDate: "Established Date",
  registrationDate: "Registration Date",
  registrationNumber: "Registration Number",
  dateStarted: "Date Started",
  buildingName: "Building Name",
  lineOfBusiness: "Line of Business",
  ownershipType: "Ownership Type",
  occupancy: "Occupancy",
  permitPaymentCadence: "Payment Cadence",
  numberOfEmployees: "No. of Employees",
  maleEmployeeCount: "Male Employees",
  femaleEmployeeCount: "Female Employees",
  businessArea: "Business Area (sqm)",
  propertyIndexNumber: "Property Index No.",
  contactNumber: "Contact Number",
  status: "Status",
  modeOfPayment: "Mode of Payment",
  permitApplicationType: "Permit Type",
  linesOfBusinessCount: "Lines of Business Count",
  feeOverridesCount: "Fee Overrides Count",
}

const HIDDEN_FIELDS = new Set([
  "searchText", "isDeleted", "deletedAt", "provinceId", "cityId", "barangayId",
])

function parseAllChanges(changesStr?: string): ParsedChange[] {
  if (!changesStr) return []
  try {
    const parsed = JSON.parse(changesStr) as Record<string, { before?: unknown; after: unknown }>
    return Object.entries(parsed)
      .filter(([field]) => !HIDDEN_FIELDS.has(field))
      .map(([field, { before, after }]) => ({
        field,
        label: FIELD_LABELS[field] || field.replace(/([A-Z])/g, " $1").replace(/^./, (s) => s.toUpperCase()),
        before,
        after,
      }))
  } catch {
    return []
  }
}

function formatChangeValue(value: unknown): string {
  if (value === undefined || value === null || value === "") return "—"
  if (typeof value === "boolean") return value ? "Yes" : "No"
  return String(value)
}

function getEventTitle(log: ActivityLog): { text: string; statusBadge?: string } {
  if (log.action === "status_change") {
    const changes = parseAllChanges(log.changes)
    const statusChange = changes.find((c) => c.field === "status")
    if (statusChange?.after) {
      return { text: "Status updated to", statusBadge: String(statusChange.after) }
    }
    return { text: log.description }
  }
  return { text: log.description }
}

function TimelineEntry({ log, isFirst, isLast }: { log: ActivityLog; isFirst: boolean; isLast: boolean }) {
  const { text, statusBadge } = getEventTitle(log)

  return (
    <div className="relative flex gap-3">
      {/* Vertical connector line */}
      {!isLast && (
        <div
          className={cn(
            "absolute left-[15px] top-[32px] w-0.5 h-[calc(100%-8px)]",
            "bg-muted-foreground/20"
          )}
        />
      )}

      {/* Icon circle */}
      <div
        className={cn(
          "relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2",
          isFirst
            ? "border-blue-500 bg-blue-500 text-white"
            : "border-muted-foreground/30 bg-muted text-muted-foreground"
        )}
      >
        {getActionIcon(log.action)}
      </div>

      {/* Content */}
      <div className={cn("pb-6 min-w-0 flex-1", isLast && "pb-0")}>
        {/* Title + optional badge */}
        <div className="flex items-center gap-2 flex-wrap">
          <p className="font-medium text-sm">{text}</p>
          {statusBadge && (
            <Badge
              variant="outline"
              className={cn("text-xs px-2 py-0", getStatusBadgeClasses(statusBadge))}
            >
              {formatStatusLabel(statusBadge)}
            </Badge>
          )}
        </div>

        {/* Description for status changes */}
        {log.action === "status_change" && (
          <p className="text-xs text-muted-foreground mt-0.5 truncate">
            {log.description}
          </p>
        )}

        {/* Field-level changes */}
        {(() => {
          const changes = parseAllChanges(log.changes)
          const fieldChanges = log.action === "status_change"
            ? changes.filter((c) => c.field !== "status")
            : changes

          if (fieldChanges.length === 0) return null

          return (
            <div className="mt-1.5 space-y-0.5">
              {fieldChanges.map((change) => (
                <div key={change.field} className="text-xs text-muted-foreground flex items-center gap-1.5 flex-wrap">
                  <span className="font-medium text-muted-foreground">{change.label}:</span>
                  {change.before !== undefined && change.before !== null && change.before !== "" && (
                    <>
                      <span className="line-through opacity-60">{formatChangeValue(change.before)}</span>
                      <span className="text-muted-foreground/60">&rarr;</span>
                    </>
                  )}
                  <span className="font-medium text-foreground">{formatChangeValue(change.after)}</span>
                </div>
              ))}
            </div>
          )
        })()}

        {/* Performer + timestamp */}
        <p className="text-xs text-muted-foreground mt-1">
          {log.performerName}  &middot;  {formatDate(log.timestamp, "full")}
        </p>
      </div>
    </div>
  )
}

/** Shared timeline rendering UI */
function TimelineUI({
  logs,
  isLoading,
  canLoadMore,
  isLoadingMore,
  onLoadMore,
}: {
  logs: ActivityLog[]
  isLoading: boolean
  canLoadMore: boolean
  isLoadingMore: boolean
  onLoadMore: () => void
}) {
  return (
    <div className="max-h-[500px] overflow-y-auto pr-1">
      {isLoading ? (
        <div className="space-y-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="flex gap-3">
              <Skeleton className="h-8 w-8 rounded-full shrink-0" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
                <Skeleton className="h-3 w-2/3" />
              </div>
            </div>
          ))}
        </div>
      ) : logs.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-6">
          No activity recorded yet.
        </p>
      ) : (
        <>
          {logs.map((log, index) => (
            <TimelineEntry
              key={log._id}
              log={log}
              isFirst={index === 0}
              isLast={index === logs.length - 1 && !canLoadMore}
            />
          ))}
          {canLoadMore && (
            <div className="pt-2 text-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={onLoadMore}
                disabled={isLoadingMore}
                className="text-xs text-muted-foreground"
              >
                {isLoadingMore ? (
                  <>
                    <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                    Loading...
                  </>
                ) : (
                  "Load more"
                )}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  )
}

/** SSR path: uses preloaded data with "show more" expansion */
function PreloadedTimelineContent({
  preloaded,
  resourceId,
  resourceType,
}: {
  preloaded: Preloaded<typeof api.activityLogs.getResourceHistory>
  resourceId: string
  resourceType: string
}) {
  const initialLogs = usePreloadedQuery(preloaded) as ActivityLog[]
  const [showMore, setShowMore] = useState(false)

  const expandedLogs = useQuery(
    api.activityLogs.getResourceHistory,
    showMore
      ? { resourceType, resourceId, limit: EXPANDED_PAGE_SIZE }
      : "skip"
  ) as ActivityLog[] | undefined

  const logs = showMore && expandedLogs ? expandedLogs : initialLogs
  const canLoadMore = !showMore && initialLogs.length >= INITIAL_PAGE_SIZE
  const isLoadingMore = showMore && !expandedLogs

  return (
    <TimelineUI
      logs={logs}
      isLoading={false}
      canLoadMore={canLoadMore}
      isLoadingMore={isLoadingMore}
      onLoadMore={() => setShowMore(true)}
    />
  )
}

/** Client-only path: uses paginated query */
function PaginatedTimelineContent({ resourceId, resourceType }: { resourceId: string; resourceType: string }) {
  const { results, status, loadMore } = usePaginatedQuery(
    api.activityLogs.getResourceHistoryPaginated,
    { resourceType, resourceId },
    { initialNumItems: INITIAL_PAGE_SIZE }
  )

  const logs = (results ?? []) as ActivityLog[]

  return (
    <TimelineUI
      logs={logs}
      isLoading={status === "LoadingFirstPage"}
      canLoadMore={status === "CanLoadMore"}
      isLoadingMore={status === "LoadingMore"}
      onLoadMore={() => loadMore(INITIAL_PAGE_SIZE)}
    />
  )
}

export function ApplicationTimelineCard({
  resourceId,
  resourceType,
  preloadedActivityLogs,
  title = "Request History",
}: ApplicationTimelineCardProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Clock className="h-5 w-5" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {preloadedActivityLogs ? (
          <PreloadedTimelineContent
            preloaded={preloadedActivityLogs}
            resourceId={resourceId}
            resourceType={resourceType}
          />
        ) : (
          <PaginatedTimelineContent resourceId={resourceId} resourceType={resourceType} />
        )}
      </CardContent>
    </Card>
  )
}
