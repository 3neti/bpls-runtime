"use client";

import { useState, useEffect, useMemo } from "react";
import { Document, Page, Text, View, StyleSheet, BlobProvider, Image } from "@react-pdf/renderer";
import { type PermitMacroData } from "@/lib/utils/permit-template-renderer";
import { renderTipTapTemplateContent } from "@/lib/utils/permit-tiptap-pdf-renderer";

// Paper sizes in points (1 point = 1/72 inch)
const PAPER_SIZES = {
  LETTER: { width: 612, height: 792 },    // 8.5 x 11 in
  A4: { width: 595.28, height: 841.89 },  // 210 x 297 mm
  LEGAL: { width: 612, height: 1008 },    // 8.5 x 14 in
};

interface PermitLayoutPreviewProps {
  headerTemplate: string;
  bodyTemplate: string;
  footerTemplate: string;
  paperSize: "LETTER" | "A4" | "LEGAL";
  orientation: "portrait" | "landscape";
  marginTop: number;
  marginRight: number;
  marginBottom: number;
  marginLeft: number;
  data: PermitMacroData;
  qrCodeDataUrl?: string;
  logoUrl?: string;
  sealUrl?: string;
  backgroundImageUrl?: string;
  backgroundImageOpacity?: number;
  backgroundImageWidth?: number;
  backgroundImageHeight?: number;
}

// Convert mm to points (1mm = 2.83465 points)
const mmToPoints = (mm: number) => mm * 2.83465;

// Inner document component that doesn't use hooks
function PermitDocument({
  headerTemplate,
  bodyTemplate,
  footerTemplate,
  paperSize,
  orientation,
  marginTop,
  marginRight,
  marginBottom,
  marginLeft,
  data,
  qrCodeDataUrl,
  logoUrl,
  sealUrl,
  backgroundImageUrl,
  backgroundImageOpacity,
  backgroundImageWidth,
  backgroundImageHeight,
}: PermitLayoutPreviewProps) {
  const fontSize = 12;
  const fontFamily = "Helvetica";
  // Get paper dimensions based on size and orientation
  const size = PAPER_SIZES[paperSize] || PAPER_SIZES.LETTER;
  const dimensions = orientation === "landscape"
    ? { width: size.height, height: size.width }
    : size;

  // Create styles - padding lives on contentWrapper, not on page,
  // so that the background image can fill the entire physical page.
  const styles = StyleSheet.create({
    page: {
      fontSize: fontSize || 12,
      fontFamily: fontFamily || "Helvetica",
      backgroundColor: "#ffffff",
      color: "#000000",
    },
    contentWrapper: {
      paddingTop: mmToPoints(marginTop || 15),
      paddingRight: mmToPoints(marginRight || 15),
      paddingBottom: mmToPoints(marginBottom || 15),
      paddingLeft: mmToPoints(marginLeft || 15),
      flex: 1,
    },
    section: {
      marginBottom: 10,
    },
    text: {
      marginBottom: 2,
    },
    header: {
      marginBottom: 15,
    },
    body: {
      flex: 1,
    },
    footer: {
      marginTop: 15,
    },
    logo: {
      width: 60,
      height: 60,
    },
    seal: {
      width: 80,
      height: 80,
    },
    qrCode: {
      width: 80,
      height: 80,
    },
    emptyState: {
      color: "#999999",
      fontStyle: "italic",
    },
  });

  // Helper functions for special macro rendering
  const renderLogo = () => {
    if (logoUrl) {
      return <Image src={logoUrl} style={styles.logo} />;
    }
    return <Text style={styles.emptyState}>[Logo Placeholder]</Text>;
  };

  const renderSeal = () => {
    if (sealUrl) {
      return <Image src={sealUrl} style={styles.seal} />;
    }
    return <Text style={styles.emptyState}>[Municipal Seal Placeholder]</Text>;
  };

  const renderQrCode = () => {
    if (qrCodeDataUrl) {
      return <Image src={qrCodeDataUrl} style={styles.qrCode} />;
    }
    return <Text style={styles.emptyState}>[QR Code Placeholder]</Text>;
  };

  const renderLinesOfBusiness = () => {
    const lines = data.linesOfBusiness || [];
    if (lines.length === 0) {
      return <Text style={styles.emptyState}>[Lines of Business]</Text>;
    }
    return <Text>{lines.join(", ")}</Text>;
  };

  const templateHelpers = { renderLogo, renderSeal, renderQrCode, renderLinesOfBusiness };

  // Check if all templates are empty
  const isEmpty = !headerTemplate && !bodyTemplate && !footerTemplate;

  // Background image fills the entire physical page.
  // Since Page has no padding, top:0/left:0 = physical page origin.
  const bgW = backgroundImageWidth ? mmToPoints(backgroundImageWidth) : dimensions.width;
  const bgH = backgroundImageHeight ? mmToPoints(backgroundImageHeight) : dimensions.height;
  const bgImageStyle = StyleSheet.create({
    container: {
      position: "absolute" as const,
      top: (dimensions.height - bgH) / 2,
      left: (dimensions.width - bgW) / 2,
      width: bgW,
      height: bgH,
    },
    image: {
      width: "100%",
      height: "100%",
      opacity: backgroundImageOpacity ?? 0.3,
    },
  });

  return (
    <Document>
      <Page size={dimensions} style={styles.page}>
        {/* Background image - absolute, fills physical page */}
        {backgroundImageUrl && (
          <View style={bgImageStyle.container}>
            <Image src={backgroundImageUrl} style={bgImageStyle.image} />
          </View>
        )}

        {/* Content wrapper with margins */}
        <View style={styles.contentWrapper}>
          {isEmpty ? (
            <View style={styles.body}>
              <Text style={styles.emptyState}>
                Enter template content to see preview...
              </Text>
            </View>
          ) : (
            <>
              {/* Header */}
              <View style={styles.header}>
                {renderTipTapTemplateContent(headerTemplate, data, fontFamily, fontSize, templateHelpers)}
              </View>

              {/* Body */}
              <View style={styles.body}>
                {renderTipTapTemplateContent(bodyTemplate, data, fontFamily, fontSize, templateHelpers)}
              </View>

              {/* Footer */}
              <View style={styles.footer}>
                {renderTipTapTemplateContent(footerTemplate, data, fontFamily, fontSize, templateHelpers)}
              </View>
            </>
          )}
        </View>
      </Page>
    </Document>
  );
}

export default function PermitLayoutPreview(props: PermitLayoutPreviewProps) {
  const [isReady, setIsReady] = useState(false);

  // Delay rendering to ensure PDF library is fully loaded
  useEffect(() => {
    const timer = setTimeout(() => setIsReady(true), 50);
    return () => clearTimeout(timer);
  }, []);

  // Memoize the document element to prevent unnecessary blob regeneration
  const documentElement = useMemo(
    () => <PermitDocument {...props} />,
    [
      props.headerTemplate,
      props.bodyTemplate,
      props.footerTemplate,
      props.paperSize,
      props.orientation,
      props.marginTop,
      props.marginRight,
      props.marginBottom,
      props.marginLeft,
      props.data,
      props.qrCodeDataUrl,
      props.logoUrl,
      props.sealUrl,
      props.backgroundImageUrl,
      props.backgroundImageOpacity,
      props.backgroundImageWidth,
      props.backgroundImageHeight,
    ]
  );

  if (!isReady) {
    return (
      <div className="flex items-center justify-center h-full bg-muted/30 text-muted-foreground">
        <p className="text-sm">Loading preview...</p>
      </div>
    );
  }

  // Check if we have content to render
  const hasContent = props.headerTemplate || props.bodyTemplate || props.footerTemplate;

  if (!hasContent) {
    return (
      <div className="flex items-center justify-center h-full bg-muted/30 text-muted-foreground">
        <p className="text-sm">Enter template content to see preview...</p>
      </div>
    );
  }

  return (
    <BlobProvider document={documentElement}>
      {({ url, loading, error }) => {
        if (loading) {
          return (
            <div className="flex items-center justify-center h-full bg-muted/30 text-muted-foreground">
              <p className="text-sm">Generating preview...</p>
            </div>
          );
        }

        if (error) {
          return (
            <div className="flex items-center justify-center h-full bg-muted/30 text-destructive">
              <p className="text-sm">Preview error: {error.message}</p>
            </div>
          );
        }

        if (!url) {
          return (
            <div className="flex items-center justify-center h-full bg-muted/30 text-muted-foreground">
              <p className="text-sm">Preparing preview...</p>
            </div>
          );
        }

        return (
          <iframe
            src={`${url}#toolbar=0`}
            width="100%"
            height="100%"
            style={{ border: "none" }}
            title="Permit Layout Preview"
          />
        );
      }}
    </BlobProvider>
  );
}
