"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { useQuery } from "convex/react"
import { Loader2, Upload, Copy, Check, AlertCircle } from "lucide-react"

import { api } from "@repo/backend/convex/_generated/api"
import { usePermissions } from "@/hooks/use-permissions"
import { addUserSchema, addUserDefaults, type AddUserFormData } from "@/lib/schemas/user-form"
import { Button } from "@repo/ui/components/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { Input } from "@repo/ui/components/input"
import { Label } from "@repo/ui/components/label"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select"
import { DepartmentCombobox } from "@/components/department-combobox"
import { Alert, AlertDescription } from "@repo/ui/components/alert"
import { useToast } from "@/hooks/use-toast"

interface AddUserDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onAddUser: (userData: {
    firstName: string
    lastName: string
    email: string
    phone?: string
    role: string
    department: string
    password: string
  }) => Promise<void>
  isSubmitting?: boolean
}

// Generate a secure random password
function generatePassword(): string {
  // Exclude ambiguous characters: 0, O, l, 1, I
  const uppercase = "ABCDEFGHJKLMNPQRSTUVWXYZ"
  const lowercase = "abcdefghijkmnpqrstuvwxyz"
  const numbers = "23456789"
  const special = "!@#$%^&*"
  const allChars = uppercase + lowercase + numbers + special

  let password = ""

  // Ensure at least one of each type
  password += uppercase[Math.floor(Math.random() * uppercase.length)]
  password += lowercase[Math.floor(Math.random() * lowercase.length)]
  password += numbers[Math.floor(Math.random() * numbers.length)]
  password += special[Math.floor(Math.random() * special.length)]

  // Fill remaining 8 characters randomly
  for (let i = 0; i < 8; i++) {
    password += allChars[Math.floor(Math.random() * allChars.length)]
  }

  // Shuffle the password
  return password.split("").sort(() => Math.random() - 0.5).join("")
}

export function AddUserDialog({ open, onOpenChange, onAddUser, isSubmitting = false }: AddUserDialogProps) {
  const { toast } = useToast()
  const { canRead, isLoading: permissionsLoading } = usePermissions()
  const canReadRoles = canRead("roles")

  // Only query roles if user has permission - skip otherwise to avoid error
  const roles = useQuery(
    api.permissions.listRoles,
    canReadRoles ? {} : "skip"
  )

  const form = useForm<AddUserFormData>({
    resolver: zodResolver(addUserSchema),
    defaultValues: addUserDefaults,
  })

  const [generatedPassword, setGeneratedPassword] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const onSubmit = async (data: AddUserFormData) => {
    setError(null)

    // Generate password for the new user
    const password = generatePassword()

    try {
      await onAddUser({
        ...data,
        phone: data.phone || undefined,
        department: data.department || "",
        password,
      })

      // Show success with password
      setGeneratedPassword(password)
    } catch (err) {
      // Extract clean error message
      let errorMessage = "Failed to create user. Please try again."
      if (err instanceof Error) {
        errorMessage = err.message
          .replace(/^Uncaught Error:\s*/i, "")
          .replace(/^Error:\s*/i, "")
          .trim()
      }
      setError(errorMessage)
    }
  }

  const handleCopyPassword = async () => {
    if (!generatedPassword) return

    try {
      await navigator.clipboard.writeText(generatedPassword)
      setCopied(true)
      toast({
        title: "Password copied",
        description: "The temporary password has been copied to your clipboard.",
      })
      setTimeout(() => setCopied(false), 2000)
    } catch {
      toast({
        title: "Copy failed",
        description: "Please manually copy the password.",
        variant: "destructive",
      })
    }
  }

  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      form.reset(addUserDefaults)
      setGeneratedPassword(null)
      setCopied(false)
      setError(null)
    }
    onOpenChange(newOpen)
  }

  const handleDone = () => {
    handleOpenChange(false)
  }

  const watchFirstName = form.watch("firstName")
  const watchLastName = form.watch("lastName")

  // If we have a generated password, show success state
  if (generatedPassword) {
    return (
      <Dialog open={open} onOpenChange={handleOpenChange}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>User Created Successfully</DialogTitle>
            <DialogDescription>
              Share the temporary password below with the new user. They should change it after their first login.
            </DialogDescription>
          </DialogHeader>
          <div className="py-6">
            <div className="space-y-4">
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-2">User</p>
                <p className="font-medium">{watchFirstName} {watchLastName}</p>
                <p className="text-sm text-muted-foreground">{form.getValues("email")}</p>
              </div>
              <div className="space-y-2">
                <Label>Temporary Password</Label>
                <div className="flex gap-2">
                  <Input
                    value={generatedPassword}
                    readOnly
                    className="font-mono text-center"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={handleCopyPassword}
                    className="shrink-0"
                  >
                    {copied ? (
                      <Check className="h-4 w-4 text-green-500" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Click the copy button to copy the password to your clipboard.
                </p>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleDone}>Done</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    )
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Add New User</DialogTitle>
          <DialogDescription>
            Create a new user account. A temporary password will be auto-generated.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            <div className="grid gap-4 py-4">
              <div className="flex flex-col items-center gap-4">
                <div className="relative">
                  <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center text-2xl font-medium border-2 border-border">
                    {watchFirstName && watchLastName
                      ? `${watchFirstName.charAt(0)}${watchLastName.charAt(0)}`
                      : "?"}
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full bg-background"
                    disabled
                  >
                    <Upload className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground">Profile Photo (optional)</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        First Name <span className="text-destructive">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          disabled={isSubmitting}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        Last Name <span className="text-destructive">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          disabled={isSubmitting}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Email Address <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="email"
                        {...field}
                        disabled={isSubmitting}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number</FormLabel>
                    <FormControl>
                      <Input
                        type="tel"
                        placeholder="+63 XXX XXX XXXX"
                        {...field}
                        disabled={isSubmitting}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Role <span className="text-destructive">*</span>
                    </FormLabel>
                    <Select
                      value={field.value}
                      onValueChange={field.onChange}
                      disabled={isSubmitting || roles === undefined || !canReadRoles}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder={
                            !canReadRoles && !permissionsLoading
                              ? "No permission to view roles"
                              : roles === undefined
                                ? "Loading roles..."
                                : "Select a role"
                          } />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {roles?.map((role: NonNullable<typeof roles>[number]) => (
                          <SelectItem key={role._id} value={role.name}>
                            {role.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="department"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Department</FormLabel>
                    <FormControl>
                      <DepartmentCombobox
                        value={field.value || ""}
                        onChange={field.onChange}
                        disabled={isSubmitting}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => handleOpenChange(false)} disabled={isSubmitting}>
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating...
                  </>
                ) : (
                  "Create User"
                )}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
