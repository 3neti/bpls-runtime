"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@repo/ui/components/dialog"
import { BusinessOwnerFormWrapper } from "./business-owner-form-wrapper"

interface CreateBusinessOwnerDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess: () => void
}

export function CreateBusinessOwnerDialog({
  open,
  onOpenChange,
  onSuccess,
}: CreateBusinessOwnerDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Business Owner</DialogTitle>
        </DialogHeader>
        <BusinessOwnerFormWrapper
          mode="create"
          onSuccess={onSuccess}
          onCancel={() => onOpenChange(false)}
        />
      </DialogContent>
    </Dialog>
  )
}
