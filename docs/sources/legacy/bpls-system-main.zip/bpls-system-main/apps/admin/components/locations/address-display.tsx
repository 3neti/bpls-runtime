"use client"

import { useQuery } from "convex/react"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

interface AddressDisplayProps {
  address: string
  provinceId: string
  cityId: string
  barangayId: string
  className?: string
}

/**
 * AddressDisplay - Displays a complete hierarchical address
 *
 * Fetches location names from Convex and formats them as:
 * "123 Main Street, Poblacion, Ipil, Zamboanga del Sur"
 *
 * @param address - Street address (House No., Street, Building)
 * @param provinceId - Foreign key to provinces table
 * @param cityId - Foreign key to cities table
 * @param barangayId - Foreign key to barangays table
 * @param className - Optional CSS classes
 */
export function AddressDisplay({
  address,
  provinceId,
  cityId,
  barangayId,
  className = "",
}: AddressDisplayProps) {
  const locationData = useQuery(api.locations.getLocationHierarchy, {
    provinceId: provinceId as Id<"provinces">,
    cityId: cityId as Id<"cities">,
    barangayId: barangayId as Id<"barangays">,
  })

  if (!locationData) {
    return <span className={className}>Loading address...</span>
  }

  const { province, city, barangay } = locationData

  // Format: "Street Address, Barangay, City, Province"
  const parts = [address, barangay?.name, city?.name, province?.name].filter(Boolean)

  return <span className={className}>{parts.join(", ")}</span>
}

/**
 * AddressDisplaySkeleton - Loading skeleton for AddressDisplay
 */
export function AddressDisplaySkeleton({ className = "" }: { className?: string }) {
  return <span className={`animate-pulse ${className}`}>Loading address...</span>
}
