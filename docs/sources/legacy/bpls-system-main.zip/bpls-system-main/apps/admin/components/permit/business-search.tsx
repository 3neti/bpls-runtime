"use client";

import { useState, useRef, useCallback } from "react";
import Link from "next/link";
import { Search, ArrowLeft, Building2, Ban, AlertCircle } from "lucide-react";
import { Input } from "@repo/ui/components/input";
import { Card, CardContent } from "@repo/ui/components/card";
import { Button } from "@repo/ui/components/button";
import { Avatar, AvatarFallback, AvatarImage } from "@repo/ui/components/avatar";
import { Badge } from "@repo/ui/components/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@repo/ui/components/tooltip";
import type { Business } from "@/lib/types/business";

interface OutstandingBalanceInfo {
  applicationId: string;
  applicationNumber: string;
  totalBalance: number;
  totalPaid: number;
  status: string;
}

interface BusinessSearchProps {
  businesses: Business[];
  selectedBusinessId?: string;
  onBusinessSelect: (business: Business) => void;
  onBack: () => void;
  selectedOwnerId?: string;
  outstandingBalances?: Record<string, OutstandingBalanceInfo> | null;
}

function BusinessCardContent({ business }: { business: Business }) {
  return (
    <CardContent className="p-4">
      <div className="flex items-center space-x-4">
        <Avatar className="h-12 w-12">
          <AvatarImage src={business.avatar || "/placeholder.svg"} alt={business.name} />
          <AvatarFallback>
            <Building2 className="h-6 w-6" />
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className="text-sm font-medium text-foreground truncate">{business.name}</p>
          </div>
          <p className="text-sm text-muted-foreground truncate">Owner: {business.ownerName}</p>
          <p className="text-xs text-muted-foreground">
            {business.businessScale} • Est. {business.establishedDate}
          </p>
        </div>
      </div>
    </CardContent>
  );
}

export function BusinessSearch({
  businesses,
  selectedBusinessId,
  onBusinessSelect,
  onBack,
  selectedOwnerId,
  outstandingBalances,
}: BusinessSearchProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [hoveredBalanceId, setHoveredBalanceId] = useState<string | null>(null);
  const [cursorPos, setCursorPos] = useState({ x: 0, y: 0 });
  const popoverRef = useRef<HTMLDivElement>(null);
  const [isOverPopover, setIsOverPopover] = useState(false);

  const hoveredBalanceInfo = hoveredBalanceId ? outstandingBalances?.[hoveredBalanceId] : null;
  const showFloatingPopover = (hoveredBalanceId && hoveredBalanceInfo) || isOverPopover;

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    setCursorPos({ x: e.clientX, y: e.clientY });
  }, []);

  const ownerBusinesses = businesses.filter((business) => {
    return business.ownerId === selectedOwnerId;
  });

  const filteredBusinesses = ownerBusinesses.filter(
    (business) =>
      business.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      business.ownerName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Get the balance info for the floating popover (keep showing even when hovering the popover itself)
  const activeBalanceInfo = hoveredBalanceInfo ?? (isOverPopover && hoveredBalanceId ? outstandingBalances?.[hoveredBalanceId] : null);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="sm" onClick={onBack} className="cursor-pointer">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Back to Options</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <h3 className="text-lg font-semibold">Select Existing Business</h3>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        <Input
          placeholder="Search by business name or owner..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="space-y-3 max-h-[600px] overflow-y-auto">
        {filteredBusinesses.map((business) => {
          const isBlacklisted = business.isBlacklisted;
          const balanceInfo = outstandingBalances?.[business.id];
          const hasOutstandingBalance = !!balanceInfo;
          const isDisabled = isBlacklisted || hasOutstandingBalance;

          const cardClassName = `transition-colors ${
            isBlacklisted
              ? "opacity-60 cursor-not-allowed border-destructive/50"
              : hasOutstandingBalance
                ? "opacity-60 cursor-not-allowed border-amber-500/50"
                : `cursor-pointer hover:bg-accent/50 ${
                    selectedBusinessId === business.id ? "ring-2 ring-primary" : ""
                  }`
          }`;

          const handleClick = () => {
            if (!isDisabled) {
              onBusinessSelect(business);
            }
          };

          // Blacklisted businesses: use Tooltip
          if (isBlacklisted) {
            return (
              <TooltipProvider key={business.id}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Card className={cardClassName} onClick={handleClick}>
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-4">
                          <Avatar className="h-12 w-12">
                            <AvatarImage src={business.avatar || "/placeholder.svg"} alt={business.name} />
                            <AvatarFallback>
                              <Building2 className="h-6 w-6" />
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="text-sm font-medium text-foreground truncate">{business.name}</p>
                              <Badge variant="destructive" className="gap-1 text-xs shrink-0">
                                <Ban className="h-3 w-3" />
                                Blacklisted
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground truncate">Owner: {business.ownerName}</p>
                            <p className="text-xs text-muted-foreground">
                              {business.businessScale} • Est. {business.establishedDate}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TooltipTrigger>
                  <TooltipContent side="right" className="max-w-xs">
                    <div className="space-y-1">
                      <p className="font-semibold">Cannot select blacklisted business</p>
                      <p className="text-xs">{business.blacklistReason}</p>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            );
          }

          // Outstanding balance businesses: cursor-following popover
          if (hasOutstandingBalance) {
            return (
              <Card
                key={business.id}
                className={cardClassName}
                onMouseEnter={() => setHoveredBalanceId(business.id)}
                onMouseLeave={() => {
                  // Small delay to allow mouse to reach the popover
                  setTimeout(() => {
                    setHoveredBalanceId((current) =>
                      current === business.id ? null : current
                    );
                  }, 100);
                }}
                onMouseMove={handleMouseMove}
              >
                <CardContent className="p-4">
                  <div className="flex items-center space-x-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={business.avatar || "/placeholder.svg"} alt={business.name} />
                      <AvatarFallback>
                        <Building2 className="h-6 w-6" />
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium text-foreground truncate">{business.name}</p>
                        <Badge variant="outline" className="gap-1 text-xs shrink-0 border-amber-500 text-amber-600">
                          <AlertCircle className="h-3 w-3" />
                          Pending Balance
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">Owner: {business.ownerName}</p>
                      <p className="text-xs text-muted-foreground">
                        {business.businessScale} • Est. {business.establishedDate}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          }

          // Normal selectable businesses
          return (
            <Card key={business.id} className={cardClassName} onClick={handleClick}>
              <BusinessCardContent business={business} />
            </Card>
          );
        })}

        {filteredBusinesses.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <Building2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>
              {ownerBusinesses.length === 0
                ? "This owner has no existing businesses to renew."
                : "No businesses found matching your search."}
            </p>
          </div>
        )}
      </div>

      {/* Cursor-following floating popover for outstanding balance */}
      {showFloatingPopover && activeBalanceInfo && (
        <div
          ref={popoverRef}
          className="fixed z-50 w-80 rounded-md border bg-popover p-4 text-popover-foreground shadow-md animate-in fade-in-0 zoom-in-95 duration-150"
          style={{
            left: `${cursorPos.x + 16}px`,
            top: `${cursorPos.y + 16}px`,
            pointerEvents: "auto",
          }}
          onMouseEnter={() => setIsOverPopover(true)}
          onMouseLeave={() => {
            setIsOverPopover(false);
            setHoveredBalanceId(null);
          }}
        >
          <div className="space-y-2">
            <h4 className="font-semibold text-sm">Outstanding Payment Balance</h4>
            <p className="text-sm text-muted-foreground">
              This business has a pending bill of{" "}
              <span className="font-medium text-foreground">
                ₱{activeBalanceInfo.totalBalance.toLocaleString()}
              </span>{" "}
              on application{" "}
              <span className="font-medium text-foreground">{activeBalanceInfo.applicationNumber}</span>.
            </p>
            <div className="pt-2 border-t">
              <Link
                href={`/dashboard/permit-applications/payment/${activeBalanceInfo.applicationId}`}
                className="text-sm text-primary underline hover:no-underline inline-flex items-center gap-1"
              >
                View Permit Application
                <ArrowLeft className="h-3 w-3 rotate-180" />
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
