"use client"

import * as React from "react"
import { Check, ChevronsUpDown, Plus, Building2, Loader2 } from "lucide-react"
import { useQuery, useMutation } from "convex/react"

import { cn } from "@/lib/utils"
import { api } from "@repo/backend/convex/_generated/api"
import { Button } from "@repo/ui/components/button"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@repo/ui/components/command"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@repo/ui/components/popover"
import { Badge } from "@repo/ui/components/badge"
import { useToast } from "@/hooks/use-toast"

interface DepartmentComboboxProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
  disabled?: boolean
}

export function DepartmentCombobox({
  value,
  onChange,
  placeholder = "Select department...",
  disabled = false,
}: DepartmentComboboxProps) {
  const { toast } = useToast()
  const [open, setOpen] = React.useState(false)
  const [searchValue, setSearchValue] = React.useState("")
  const [isCreating, setIsCreating] = React.useState(false)

  const departments = useQuery(api.departments.listDepartments, { activeOnly: true })
  const quickCreateDepartment = useMutation(api.departments.quickCreateDepartment)

  const handleCreateDepartment = async () => {
    if (!searchValue.trim()) return

    setIsCreating(true)
    try {
      const result = await quickCreateDepartment({ name: searchValue.trim() })
      onChange(result.name)
      setOpen(false)
      setSearchValue("")
      toast({
        title: "Department created",
        description: `"${result.name}" has been added to the system.`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create department",
        variant: "destructive",
      })
    } finally {
      setIsCreating(false)
    }
  }

  // Check if the search value matches any existing department
  type DeptItem = NonNullable<typeof departments>[number];
  const exactMatch = departments?.some(
    (dept: DeptItem) => dept.name.toLowerCase() === searchValue.toLowerCase()
  )

  // Filter departments based on search
  const filteredDepartments = departments?.filter((dept: DeptItem) =>
    dept.name.toLowerCase().includes(searchValue.toLowerCase())
  )

  // Find selected department for display
  const selectedDepartment = departments?.find((dept: DeptItem) => dept.name === value)

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className={cn(
            "w-full justify-between overflow-hidden",
            !value && "text-muted-foreground"
          )}
          disabled={disabled || departments === undefined}
        >
          {departments === undefined ? (
            <span className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              Loading...
            </span>
          ) : value ? (
            <span className="flex items-center gap-2 min-w-0">
              <Building2 className="h-4 w-4 shrink-0" />
              <span className="truncate">{selectedDepartment?.name || value}</span>
            </span>
          ) : (
            <span className="flex items-center gap-2">
              <Badge variant="secondary" className="font-normal">
                No department
              </Badge>
              {placeholder}
            </span>
          )}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[300px] p-0" align="start">
        <Command shouldFilter={false}>
          <CommandInput
            placeholder="Search or create department..."
            value={searchValue}
            onValueChange={setSearchValue}
          />
          <CommandList>
            <CommandEmpty className="py-2 px-4 text-sm text-muted-foreground">
              {searchValue ? (
                <span>No department found. Create "{searchValue}"?</span>
              ) : (
                <span>No departments available.</span>
              )}
            </CommandEmpty>
            {filteredDepartments && filteredDepartments.length > 0 && (
              <CommandGroup heading="Departments">
                {filteredDepartments.map((dept: DeptItem) => (
                  <CommandItem
                    key={dept._id}
                    value={dept.name}
                    onSelect={() => {
                      onChange(dept.name)
                      setOpen(false)
                      setSearchValue("")
                    }}
                  >
                    <Check
                      className={cn(
                        "mr-2 h-4 w-4",
                        value === dept.name ? "opacity-100" : "opacity-0"
                      )}
                    />
                    <Building2 className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span>{dept.name}</span>
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
            {searchValue && !exactMatch && (
              <>
                <CommandSeparator />
                <CommandGroup>
                  <CommandItem
                    onSelect={handleCreateDepartment}
                    disabled={isCreating}
                    className="text-primary"
                  >
                    {isCreating ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Plus className="mr-2 h-4 w-4" />
                    )}
                    Create "{searchValue}"
                  </CommandItem>
                </CommandGroup>
              </>
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  )
}
