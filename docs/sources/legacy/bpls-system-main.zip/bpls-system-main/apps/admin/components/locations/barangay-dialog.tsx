"use client";

import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@repo/ui/components/form";
import { Input } from "@repo/ui/components/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select";
import { Button } from "@repo/ui/components/button";
import { toast } from "sonner";
import type { Barangay } from "@/lib/types/location";
import type { Id } from "@repo/backend/convex/_generated/dataModel";

const barangaySchema = z.object({
  name: z.string().min(1, "Barangay name is required"),
  cityId: z.string().min(1, "City/Municipality is required"),
  code: z.string().optional(),
});

type BarangayFormValues = z.infer<typeof barangaySchema>;

interface BarangayDialogProps {
  mode: "create" | "edit";
  barangay?: Barangay;
  cityId?: string;
  cityName?: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export function BarangayDialog({
  mode,
  barangay,
  cityId,
  cityName,
  open,
  onOpenChange,
  onSuccess,
}: BarangayDialogProps) {
  const cities = useQuery(api.locations.listCities);
  const createBarangay = useMutation(api.locations.createBarangay);
  const updateBarangay = useMutation(api.locations.updateBarangay);

  const form = useForm<BarangayFormValues>({
    resolver: zodResolver(barangaySchema),
    defaultValues: {
      name: barangay?.name || "",
      cityId: cityId || (barangay?.cityId as string) || "",
      code: barangay?.code || "",
    },
  });

  // Reset form when dialog opens or when cityId/barangay changes
  useEffect(() => {
    if (open) {
      form.reset({
        name: barangay?.name || "",
        cityId: cityId || (barangay?.cityId as string) || "",
        code: barangay?.code || "",
      });
    }
  }, [open, cityId, barangay, form]);

  // Determine if we're adding a child location (city is pre-selected)
  const isAddingChild = Boolean(mode === "create" && cityId && cityName);

  const onSubmit = async (values: BarangayFormValues) => {
    try {
      if (mode === "create") {
        await createBarangay({
          name: values.name,
          cityId: values.cityId as Id<"cities">,
          code: values.code || undefined,
        });
        toast.success("Barangay created successfully");
      } else {
        if (!barangay?._id) {
          toast.error("Barangay ID is missing");
          return;
        }
        await updateBarangay({
          id: barangay._id as Id<"barangays">,
          name: values.name,
          cityId: values.cityId as Id<"cities">,
          code: values.code || undefined,
        });
        toast.success("Barangay updated successfully");
      }
      form.reset();
      onOpenChange(false);
      onSuccess?.();
    } catch (error) {
      toast.error(mode === "create" ? "Failed to create barangay" : "Failed to update barangay");
      console.error(error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{mode === "create" ? "Add Barangay" : "Edit Barangay"}</DialogTitle>
          <DialogDescription>
            {mode === "create" ? "Add a new barangay to the location hierarchy." : "Update barangay information."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="cityId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    City/Municipality <span className="text-destructive">*</span>
                  </FormLabel>
                  {isAddingChild ? (
                    <FormControl>
                      <Input value={cityName} disabled className="bg-muted text-muted-foreground cursor-not-allowed" />
                    </FormControl>
                  ) : (
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select city/municipality" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {cities?.map((city: NonNullable<typeof cities>[number]) => (
                          <SelectItem key={city._id} value={city._id}>
                            {city.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    Barangay Name <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g., Poblacion" autoFocus={isAddingChild} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="code"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>PSGC Code </FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g., 097232001" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting
                  ? mode === "create"
                    ? "Creating..."
                    : "Updating..."
                  : mode === "create"
                    ? "Create Barangay"
                    : "Update Barangay"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
