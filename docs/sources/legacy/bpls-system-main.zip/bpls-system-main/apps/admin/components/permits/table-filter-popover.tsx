"use client"

import * as React from "react"
import { Filter, X, CalendarIcon } from "lucide-react"
import { format } from "date-fns"

import { Button } from "@repo/ui/components/button"
import { Badge } from "@repo/ui/components/badge"
import { Checkbox } from "@repo/ui/components/checkbox"
import { Input } from "@repo/ui/components/input"
import { Label } from "@repo/ui/components/label"
import { Calendar } from "@repo/ui/components/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@repo/ui/components/popover"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import { cn } from "@/lib/utils"

export interface StatusOption {
  value: string
  label: string
}

export type NumericFilterOperator = "equals" | "gt" | "gte" | "lt" | "lte" | "between"

export interface NumericFilterValue {
  operator: NumericFilterOperator
  value: number | null
  valueTo?: number | null // only for "between"
}

export interface CustomFilterField {
  key: string
  label: string
  type: "text" | "number"
  placeholder?: string
}

export interface FilterState {
  statuses: string[]
  dateRange: {
    from: Date | undefined
    to: Date | undefined
  }
  applicationType: string | null
  paymentStatus: string | null
  clearanceProgress: string | null
  progressRange: string | null
  textFilters: Record<string, string>
  numericFilters: Record<string, NumericFilterValue>
}

export interface FilterConfig {
  statusOptions?: StatusOption[]
  showDateRange?: boolean
  showTypeFilter?: boolean
  showPaymentStatus?: boolean
  showClearanceProgress?: boolean
  showProgressRange?: boolean
  customFilterFields?: CustomFilterField[]
}

interface TableFilterPopoverProps {
  config: FilterConfig
  filters: FilterState
  onFiltersChange: (filters: FilterState) => void
}

const PAYMENT_STATUS_OPTIONS: StatusOption[] = [
  { value: "fully_paid", label: "Fully Paid" },
  { value: "partial", label: "Partial Payment" },
]

const CLEARANCE_PROGRESS_OPTIONS: StatusOption[] = [
  { value: "complete", label: "Complete (100%)" },
  { value: "in_progress", label: "In Progress (1-99%)" },
  { value: "not_started", label: "Not Started (0%)" },
]

const PROGRESS_RANGE_OPTIONS: StatusOption[] = [
  { value: "0-25", label: "0-25%" },
  { value: "26-50", label: "26-50%" },
  { value: "51-75", label: "51-75%" },
  { value: "76-100", label: "76-100%" },
]

const TYPE_OPTIONS: StatusOption[] = [
  { value: "New Application", label: "New Application" },
  { value: "Renewal", label: "Renewal" },
]

export function TableFilterPopover({
  config,
  filters,
  onFiltersChange,
}: TableFilterPopoverProps) {
  const [open, setOpen] = React.useState(false)
  const [datePickerOpen, setDatePickerOpen] = React.useState<"from" | "to" | null>(null)

  // Calculate active filter count
  const activeFilterCount = React.useMemo(() => {
    let count = 0
    if (filters.statuses.length > 0) count++
    if (filters.dateRange.from || filters.dateRange.to) count++
    if (filters.applicationType) count++
    if (filters.paymentStatus) count++
    if (filters.clearanceProgress) count++
    if (filters.progressRange) count++
    // Count active text filters
    if (filters.textFilters) {
      count += Object.values(filters.textFilters).filter(v => v.trim() !== "").length
    }
    // Count active numeric filters
    if (filters.numericFilters) {
      count += Object.values(filters.numericFilters).filter(v => v.value !== null).length
    }
    return count
  }, [filters])

  const handleStatusChange = (status: string, checked: boolean) => {
    const newStatuses = checked
      ? [...filters.statuses, status]
      : filters.statuses.filter((s) => s !== status)
    onFiltersChange({ ...filters, statuses: newStatuses })
  }

  const handleDateChange = (type: "from" | "to", date: Date | undefined) => {
    onFiltersChange({
      ...filters,
      dateRange: {
        ...filters.dateRange,
        [type]: date,
      },
    })
    setDatePickerOpen(null)
  }

  const handleTypeChange = (type: string | null) => {
    onFiltersChange({ ...filters, applicationType: type })
  }

  const handlePaymentStatusChange = (status: string | null) => {
    onFiltersChange({ ...filters, paymentStatus: status })
  }

  const handleClearanceProgressChange = (progress: string | null) => {
    onFiltersChange({ ...filters, clearanceProgress: progress })
  }

  const handleProgressRangeChange = (range: string | null) => {
    onFiltersChange({ ...filters, progressRange: range })
  }

  const handleTextFilterChange = (key: string, value: string) => {
    onFiltersChange({
      ...filters,
      textFilters: { ...filters.textFilters, [key]: value },
    })
  }

  const handleNumericFilterChange = (key: string, update: Partial<NumericFilterValue>) => {
    const current = filters.numericFilters?.[key] || { operator: "equals" as NumericFilterOperator, value: null }
    const updated = { ...current, ...update }
    // Reset valueTo when operator changes away from "between"
    if (update.operator && update.operator !== "between") {
      updated.valueTo = null
    }
    onFiltersChange({
      ...filters,
      numericFilters: { ...filters.numericFilters, [key]: updated },
    })
  }

  const clearAllFilters = () => {
    onFiltersChange({
      statuses: [],
      dateRange: { from: undefined, to: undefined },
      applicationType: null,
      paymentStatus: null,
      clearanceProgress: null,
      progressRange: null,
      textFilters: {},
      numericFilters: {},
    })
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" className="relative">
          <Filter className="mr-2 h-4 w-4" />
          Filter
          {activeFilterCount > 0 && (
            <Badge
              variant="secondary"
              className="ml-2 h-5 w-5 rounded-full p-0 text-xs flex items-center justify-center"
            >
              {activeFilterCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80" align="end">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-medium text-sm">Filters</h4>
            {activeFilterCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={clearAllFilters}
                className="h-auto py-1 px-2 text-xs text-muted-foreground hover:text-foreground"
              >
                <X className="mr-1 h-3 w-3" />
                Clear all
              </Button>
            )}
          </div>

          {/* Status Filter */}
          {config.statusOptions && config.statusOptions.length > 0 && (
            <div className="space-y-2">
              <Label className="text-xs font-medium text-muted-foreground">
                Status
              </Label>
              <div className="space-y-2">
                {config.statusOptions.map((option) => (
                  <div key={option.value} className="flex items-center space-x-2">
                    <Checkbox
                      id={`status-${option.value}`}
                      checked={filters.statuses.includes(option.value)}
                      onCheckedChange={(checked) =>
                        handleStatusChange(option.value, !!checked)
                      }
                    />
                    <Label
                      htmlFor={`status-${option.value}`}
                      className="text-sm font-normal cursor-pointer"
                    >
                      {option.label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Date Range Filter */}
          {config.showDateRange && (
            <div className="space-y-2">
              <Label className="text-xs font-medium text-muted-foreground">
                Date Range
              </Label>
              <div className="flex gap-2">
                <Popover open={datePickerOpen === "from"} onOpenChange={(open) => setDatePickerOpen(open ? "from" : null)}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className={cn(
                        "flex-1 justify-start text-left font-normal",
                        !filters.dateRange.from && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-3 w-3" />
                      {filters.dateRange.from
                        ? format(filters.dateRange.from, "MMM d")
                        : "From"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={filters.dateRange.from}
                      onSelect={(date) => handleDateChange("from", date)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <Popover open={datePickerOpen === "to"} onOpenChange={(open) => setDatePickerOpen(open ? "to" : null)}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className={cn(
                        "flex-1 justify-start text-left font-normal",
                        !filters.dateRange.to && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-3 w-3" />
                      {filters.dateRange.to
                        ? format(filters.dateRange.to, "MMM d")
                        : "To"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={filters.dateRange.to}
                      onSelect={(date) => handleDateChange("to", date)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          )}

          {/* Application Type Filter */}
          {config.showTypeFilter && (
            <div className="space-y-2">
              <Label className="text-xs font-medium text-muted-foreground">
                Application Type
              </Label>
              <div className="flex gap-2">
                {TYPE_OPTIONS.map((option) => (
                  <Button
                    key={option.value}
                    variant={filters.applicationType === option.value ? "default" : "outline"}
                    size="sm"
                    onClick={() =>
                      handleTypeChange(
                        filters.applicationType === option.value ? null : option.value
                      )
                    }
                    className="flex-1"
                  >
                    {option.label}
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Payment Status Filter (Released table) */}
          {config.showPaymentStatus && (
            <div className="space-y-2">
              <Label className="text-xs font-medium text-muted-foreground">
                Payment Status
              </Label>
              <div className="flex gap-2">
                {PAYMENT_STATUS_OPTIONS.map((option) => (
                  <Button
                    key={option.value}
                    variant={filters.paymentStatus === option.value ? "default" : "outline"}
                    size="sm"
                    onClick={() =>
                      handlePaymentStatusChange(
                        filters.paymentStatus === option.value ? null : option.value
                      )
                    }
                    className="flex-1"
                  >
                    {option.label}
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Clearance Progress Filter (Released table) */}
          {config.showClearanceProgress && (
            <div className="space-y-2">
              <Label className="text-xs font-medium text-muted-foreground">
                Clearance Progress
              </Label>
              <div className="space-y-2">
                {CLEARANCE_PROGRESS_OPTIONS.map((option) => (
                  <div key={option.value} className="flex items-center space-x-2">
                    <Checkbox
                      id={`clearance-${option.value}`}
                      checked={filters.clearanceProgress === option.value}
                      onCheckedChange={(checked) =>
                        handleClearanceProgressChange(checked ? option.value : null)
                      }
                    />
                    <Label
                      htmlFor={`clearance-${option.value}`}
                      className="text-sm font-normal cursor-pointer"
                    >
                      {option.label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Progress Range Filter (Drafts table) */}
          {config.showProgressRange && (
            <div className="space-y-2">
              <Label className="text-xs font-medium text-muted-foreground">
                Progress Range
              </Label>
              <div className="grid grid-cols-2 gap-2">
                {PROGRESS_RANGE_OPTIONS.map((option) => (
                  <Button
                    key={option.value}
                    variant={filters.progressRange === option.value ? "default" : "outline"}
                    size="sm"
                    onClick={() =>
                      handleProgressRangeChange(
                        filters.progressRange === option.value ? null : option.value
                      )
                    }
                  >
                    {option.label}
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Custom Filter Fields (Text & Numeric) */}
          {config.customFilterFields && config.customFilterFields.length > 0 && (
            <>
              {config.customFilterFields.map((field) => (
                <div key={field.key} className="space-y-1.5">
                  <Label className="text-xs font-medium text-muted-foreground">
                    {field.label}
                  </Label>
                  {field.type === "text" ? (
                    <Input
                      value={filters.textFilters?.[field.key] || ""}
                      onChange={(e) => handleTextFilterChange(field.key, e.target.value)}
                      placeholder={field.placeholder || `Search ${field.label.toLowerCase()}...`}
                      className="h-8 text-xs"
                    />
                  ) : (
                    <div className="space-y-1.5">
                      <Select
                        value={filters.numericFilters?.[field.key]?.operator || "equals"}
                        onValueChange={(op) =>
                          handleNumericFilterChange(field.key, { operator: op as NumericFilterOperator })
                        }
                      >
                        <SelectTrigger className="h-8 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="equals">equals</SelectItem>
                          <SelectItem value="gt">greater than</SelectItem>
                          <SelectItem value="gte">greater than or equal</SelectItem>
                          <SelectItem value="lt">less than</SelectItem>
                          <SelectItem value="lte">less than or equal</SelectItem>
                          <SelectItem value="between">between</SelectItem>
                        </SelectContent>
                      </Select>
                      {(filters.numericFilters?.[field.key]?.operator || "equals") === "between" ? (
                        <div className="flex items-center gap-1">
                          <Input
                            type="number"
                            value={filters.numericFilters?.[field.key]?.value ?? ""}
                            onChange={(e) =>
                              handleNumericFilterChange(field.key, {
                                value: e.target.value === "" ? null : Number(e.target.value),
                              })
                            }
                            placeholder="Min"
                            className="h-8 text-xs flex-1"
                          />
                          <Input
                            type="number"
                            value={filters.numericFilters?.[field.key]?.valueTo ?? ""}
                            onChange={(e) =>
                              handleNumericFilterChange(field.key, {
                                valueTo: e.target.value === "" ? null : Number(e.target.value),
                              })
                            }
                            placeholder="Max"
                            className="h-8 text-xs flex-1"
                          />
                        </div>
                      ) : (
                        <Input
                          type="number"
                          value={filters.numericFilters?.[field.key]?.value ?? ""}
                          onChange={(e) =>
                            handleNumericFilterChange(field.key, {
                              value: e.target.value === "" ? null : Number(e.target.value),
                            })
                          }
                          placeholder={field.placeholder || "Value..."}
                          className="h-8 text-xs"
                        />
                      )}
                    </div>
                  )}
                </div>
              ))}
            </>
          )}
        </div>
      </PopoverContent>
    </Popover>
  )
}

// Default filter state factory
export function createDefaultFilterState(): FilterState {
  return {
    statuses: [],
    dateRange: { from: undefined, to: undefined },
    applicationType: null,
    paymentStatus: null,
    clearanceProgress: null,
    progressRange: null,
    textFilters: {},
    numericFilters: {},
  }
}

// Filter application helper
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function applyFilters<T>(
  data: T[],
  filters: FilterState,
  options: {
    statusKey?: keyof T
    dateKey?: keyof T
    typeKey?: keyof T
    paymentStatusKey?: keyof T
    clearanceProgressKey?: keyof T
    progressKey?: keyof T
    getPaymentRemaining?: (item: T) => number
    getClearancePercentage?: (item: T) => number
    getProgress?: (item: T) => number
  }
): T[] {
  let result = [...data]

  // Status filter
  if (filters.statuses.length > 0 && options.statusKey) {
    result = result.filter((item) =>
      filters.statuses.includes(String((item as Record<string, unknown>)[options.statusKey as string]))
    )
  }

  // Date range filter
  if ((filters.dateRange.from || filters.dateRange.to) && options.dateKey) {
    result = result.filter((item) => {
      const itemDate = new Date(String((item as Record<string, unknown>)[options.dateKey as string]))
      if (filters.dateRange.from && itemDate < filters.dateRange.from) return false
      if (filters.dateRange.to && itemDate > filters.dateRange.to) return false
      return true
    })
  }

  // Application type filter
  if (filters.applicationType && options.typeKey) {
    result = result.filter(
      (item) => String((item as Record<string, unknown>)[options.typeKey as string]) === filters.applicationType
    )
  }

  // Payment status filter
  if (filters.paymentStatus && options.getPaymentRemaining) {
    result = result.filter((item) => {
      const remaining = options.getPaymentRemaining!(item)
      if (filters.paymentStatus === "fully_paid") return remaining <= 0
      if (filters.paymentStatus === "partial") return remaining > 0
      return true
    })
  }

  // Clearance progress filter
  if (filters.clearanceProgress && options.getClearancePercentage) {
    result = result.filter((item) => {
      const percentage = options.getClearancePercentage!(item)
      if (filters.clearanceProgress === "complete") return percentage === 100
      if (filters.clearanceProgress === "in_progress") return percentage > 0 && percentage < 100
      if (filters.clearanceProgress === "not_started") return percentage === 0
      return true
    })
  }

  // Progress range filter
  if (filters.progressRange && options.getProgress) {
    result = result.filter((item) => {
      const progress = options.getProgress!(item)
      const [min, max] = filters.progressRange!.split("-").map(Number)
      return progress >= min && progress <= max
    })
  }

  return result
}
