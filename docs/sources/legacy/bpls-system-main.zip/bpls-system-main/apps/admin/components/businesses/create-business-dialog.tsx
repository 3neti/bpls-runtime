"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@repo/ui/components/dialog"
import { BusinessFormWrapper } from "./business-form-wrapper"

interface CreateBusinessDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess: () => void
}

export function CreateBusinessDialog({
  open,
  onOpenChange,
  onSuccess,
}: CreateBusinessDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Business</DialogTitle>
        </DialogHeader>
        <BusinessFormWrapper
          mode="create"
          onSuccess={onSuccess}
          onCancel={() => onOpenChange(false)}
        />
      </DialogContent>
    </Dialog>
  )
}
