"use client";

import { useState } from "react";
import { Code, ChevronDown } from "lucide-react";

import { Button } from "@repo/ui/components/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu";
import { getAvailableMacros } from "@/lib/utils/receipt-template-renderer";

interface MacroPickerProps {
  onSelect: (macro: string) => void;
}

export function MacroPicker({ onSelect }: MacroPickerProps) {
  const macros = getAvailableMacros();

  // Group macros by category
  const groupedMacros = macros.reduce(
    (acc, macro) => {
      if (!acc[macro.category]) {
        acc[macro.category] = [];
      }
      acc[macro.category].push(macro);
      return acc;
    },
    {} as Record<string, typeof macros>
  );

  const categories = ["Payment", "Business", "Schedule", "System"] as const;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm">
          <Code className="mr-2 h-4 w-4" />
          Insert Macro
          <ChevronDown className="ml-2 h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-80" align="end">
        <DropdownMenuLabel>Available Macros</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {categories.map((category, idx) => (
          <div key={category}>
            {idx > 0 && <DropdownMenuSeparator />}
            <DropdownMenuGroup>
              <DropdownMenuLabel className="text-xs text-muted-foreground">
                {category} Fields
              </DropdownMenuLabel>
              {groupedMacros[category]?.map((macro) => (
                <DropdownMenuItem
                  key={macro.key}
                  onClick={() => onSelect(macro.key)}
                  className="flex flex-col items-start"
                >
                  <div className="flex items-center gap-2">
                    <code className="text-xs bg-muted px-1.5 py-0.5 rounded">
                      {`{{${macro.key}}}`}
                    </code>
                  </div>
                  <span className="text-xs text-muted-foreground mt-0.5">
                    {macro.description}
                  </span>
                </DropdownMenuItem>
              ))}
            </DropdownMenuGroup>
          </div>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
