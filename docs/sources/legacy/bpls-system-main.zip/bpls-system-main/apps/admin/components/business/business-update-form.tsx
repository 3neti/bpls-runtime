"use client";

import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "convex/react";
import { Loader2, FileText } from "lucide-react";

import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import { DatePicker } from "@repo/ui/components/date-picker";
import { useToast } from "@/hooks/use-toast";
import { useLocationSelects } from "@/hooks/use-location-selects";
import { useCategorySelects } from "@/hooks/use-category-selects";
import { businessUpdateSchema, type BusinessUpdateSchema } from "@/lib/schemas/business-update";
import { OwnershipDocumentsField } from "@/components/businesses/ownership-documents-field";
import { api } from "@repo/backend/convex/_generated/api";

import type { Id } from "@repo/backend/convex/_generated/dataModel";
import type { Business } from "@/lib/types/business";

interface BusinessUpdateFormProps {
  business: Business;
  onSuccess?: () => void;
  disabled?: boolean;
}

export function BusinessUpdateForm({ business, onSuccess, disabled = false }: BusinessUpdateFormProps) {
  const { toast } = useToast();
  const updateBusiness = useMutation(api.businesses.update);
  const addDocument = useMutation(api.businesses.addDocument);
  const generateUploadUrl = useMutation(api.businessOwners.generateUploadUrl);

  const form = useForm<BusinessUpdateSchema>({
    resolver: zodResolver(businessUpdateSchema),
    defaultValues: {
      id: business.id,
      name: business.name,
      businessArea: business.businessArea || 1,
      propertyIndexNumber: business.propertyIndexNumber || "",
      dateEstablished: business.establishedDate || "",
      registrationDate: business.registrationDate || "",
      registrationNumber: business.registrationNumber || "",
      dateStarted: business.dateStarted || new Date().toISOString().split("T")[0],
      occupancy: business.occupancy?.toLowerCase() || "",
      maleEmployeeCount: business.maleEmployeeCount || 0,
      femaleEmployeeCount: business.femaleEmployeeCount || 0,
      ownershipType: business.ownershipType.toLowerCase().replace(/\s+/g, "-"),
      groupName: business.groupName || "", // ✅ FIXED: No type assertion needed - groupName is part of Business type
      contactNumber: business.contactNumber,
      email: business.email,
      address: business.address || "",
      buildingName: business.buildingName || "",
      provinceId: business.provinceId || "",
      cityId: business.cityId || "",
      barangayId: business.barangayId || "",
      categoryId: business.categoryId || "",
      subCategoryId: business.subCategoryId || "",
      documents: {},
    },
    mode: "onChange",
  });

  // Watch form values for cascading selects and conditional fields
  const formValues = form.watch();
  const ownershipType = formValues.ownershipType;

  // Use the reusable location selects hook
  const {
    provinces,
    cities,
    barangays,
    handleProvinceChange,
    handleCityChange,
    isCityDisabled,
    isBarangayDisabled,
  } = useLocationSelects({
    initialProvinceId: business.provinceId || "",
    initialCityId: business.cityId || "",
    onProvinceChange: (id) => form.setValue("provinceId", id),
    onCityChange: (id) => form.setValue("cityId", id),
    onBarangayChange: (id) => form.setValue("barangayId", id),
  });

  // Cascading category selects hook
  const {
    categories,
    subCategories,
    isSubCategoryDisabled,
    handleCategoryChange,
    handleSubCategoryChange,
  } = useCategorySelects({
    initialCategoryId: business.categoryId || "",
    initialSubCategoryId: business.subCategoryId || "",
    onCategoryChange: (id) => form.setValue("categoryId", id),
    onSubCategoryChange: (id) => form.setValue("subCategoryId", id),
  });

  // Helper function to get registration date description based on ownership type
  const getRegistrationDateDescription = (ownershipType?: string): string => {
    const normalizedOwnershipType = ownershipType?.toLowerCase().replace(/\s+/g, "-");

    switch (normalizedOwnershipType) {
      case "sole-proprietorship":
        return "DTI Registration Date";
      case "partnership":
        return "CDA Registration Date";
      case "corporation":
        return "SEC Registration Date";
      case "cooperative":
        return "CDA Registration Date";
      case "religious":
        return "SEC Registration Date";
      case "non-profit":
        return "SEC Registration Date";
      default:
        return "Registration Date";
    }
  };

  // Document upload handlers
  const handleFileSelect = (documentType: string, file: File) => {
    const currentDocuments = formValues.documents || {};
    form.setValue("documents", {
      ...currentDocuments,
      [documentType]: { file, uploaded: true },
    });
  };

  const handleFileRemove = (documentType: string) => {
    const currentDocuments = formValues.documents || {};
    form.setValue("documents", {
      ...currentDocuments,
      [documentType]: { file: null, uploaded: false },
    });
  };

  // Auto-clear groupName when ownership type changes to types that don't require it
  useEffect(() => {
    const normalizedOwnershipType = ownershipType.toLowerCase().replace(/\s+/g, "-");
    const requiresGroupName = ["partnership", "corporation", "cooperative"].includes(normalizedOwnershipType);
    if (!requiresGroupName && formValues.groupName) {
      form.setValue("groupName", "");
    }
  }, [ownershipType, formValues.groupName, form]);

  const onSubmit = form.handleSubmit(async (data) => {
    if (disabled) {
      toast({
        title: "Error",
        description: "You don't have permission to modify businesses",
        variant: "destructive",
      });
      return;
    }
    try {
      // Calculate business scale based on total employees
      const totalEmployees = data.maleEmployeeCount + data.femaleEmployeeCount;
      let businessScale = "Micro";
      if (totalEmployees >= 200) {
        businessScale = "Large";
      } else if (totalEmployees >= 100) {
        businessScale = "Medium";
      } else if (totalEmployees >= 10) {
        businessScale = "Small";
      }

      // Update business basic information
      await updateBusiness({
        id: data.id as Id<"businesses">,
        name: data.name,
        businessArea: data.businessArea,
        propertyIndexNumber: data.propertyIndexNumber || undefined,
        establishedDate: data.dateEstablished,
        registrationDate: data.registrationDate || undefined,
        registrationNumber: data.registrationNumber || undefined,
        occupancy: data.occupancy,
        maleEmployeeCount: data.maleEmployeeCount,
        femaleEmployeeCount: data.femaleEmployeeCount,
        ownershipType: data.ownershipType,
        groupName: data.groupName,
        contactNumber: data.contactNumber,
        email: data.email,
        address: data.address,
        buildingName: data.buildingName || undefined,
        provinceId: data.provinceId as Id<"provinces">,
        cityId: data.cityId as Id<"cities">,
        barangayId: data.barangayId as Id<"barangays">,
        categoryId: data.categoryId ? data.categoryId as Id<"business_categories"> : undefined,
        // Changing category clears the sub-category select; send an explicit
        // null so a stored sub-category from the previous category is removed
        // (undefined would mean "leave unchanged" and keep the stale value).
        subCategoryId: data.subCategoryId
          ? data.subCategoryId as Id<"business_subcategories">
          : data.categoryId ? null : undefined,
        businessScale: businessScale,
      });

      // Step 2: Upload documents to Convex storage and attach to business
      const documents = data.documents || {};
      const documentEntries = Object.entries(documents).filter(([_, doc]) => {
        const docData = doc as { file: File | null; uploaded: boolean };
        return docData.file !== null && docData.uploaded;
      });

      if (documentEntries.length > 0) {
        // Map document type keys to display names
        const documentTypeMap: Record<string, string> = {
          dtiCertificate: "DTI Certificate",
          secCertificate: "SEC Certificate",
          articlesOfPartnership: "Articles of Partnership",
          articlesOfIncorporation: "Articles of Incorporation",
          bylaws: "By-Laws",
          gis: "General Information Sheet (GIS)",
          cdaCertificate: "CDA Certificate",
          articlesOfCooperation: "Articles of Cooperation",
        };

        // Upload each document to Convex
        for (const [documentType, doc] of documentEntries) {
          const docData = doc as { file: File | null; uploaded: boolean };
          if (!docData.file) continue;

          try {
            // Generate upload URL
            const uploadUrl = await generateUploadUrl();

            // Upload file to Convex storage
            const uploadResult = await fetch(uploadUrl, {
              method: "POST",
              headers: { "Content-Type": docData.file.type },
              body: docData.file,
            });

            if (!uploadResult.ok) {
              throw new Error(`Failed to upload ${documentType}`);
            }

            // Get storage ID from response
            const { storageId } = (await uploadResult.json()) as { storageId: Id<"_storage"> };

            const documentDisplayName = documentTypeMap[documentType] || documentType;

            // Attach document to business
            await addDocument({
              businessId: data.id as Id<"businesses">,
              storageId,
              documentType: documentDisplayName,
              fileName: docData.file.name,
            });
          } catch (uploadError) {
            console.error(`Error uploading document ${documentType}:`, uploadError);
            toast({
              title: "Document Upload Warning",
              description: `Failed to upload ${documentType}. Other documents may have been uploaded successfully.`,
              variant: "destructive",
            });
            // Continue with other documents even if one fails
          }
        }
      }

      console.log('✅ [LOB DEBUG] All operations completed successfully');
      toast({
        title: "Success",
        description: "Business information and documents updated successfully",
      });

      onSuccess?.();
    } catch (error) {
      console.error("❌ [LOB DEBUG] Error updating business:", error);
      toast({
        title: "Error",
        description: "Failed to update business information. Please try again.",
        variant: "destructive",
      });
    }
  });

  const isSubmitting = form.formState.isSubmitting;

  return (
    <form onSubmit={onSubmit} className="space-y-6">
      {/* Business Information Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Business Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Row 1: Business Name */}
          <div>
            <Label htmlFor="name">
              Business Name <span className="text-destructive">*</span>
            </Label>
            <Input id="name" placeholder="Enter business name" {...form.register("name")} disabled={disabled || isSubmitting} />
            {form.formState.errors.name && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.name.message}</p>
            )}
          </div>

          {/* Row 1b: Floor Area and Property Index Number (Side by Side) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="businessArea">Business Area (sq.m) <span className="text-destructive">*</span></Label>
              <Input
                id="businessArea"
                type="number"
                min="1"
                step="0.01"
                placeholder="Enter floor area in square meters"
                {...form.register("businessArea", { valueAsNumber: true })}
                disabled={disabled || isSubmitting}
              />
              {form.formState.errors.businessArea && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.businessArea.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="propertyIndexNumber">Property Index Number</Label>
              <Input
                id="propertyIndexNumber"
                placeholder="Enter property index number "
                {...form.register("propertyIndexNumber")}
                disabled={disabled || isSubmitting}
              />
              {form.formState.errors.propertyIndexNumber && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.propertyIndexNumber.message}</p>
              )}
            </div>
          </div>

          {/* Row 2: Date Established and Date Started (Two Columns) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="dateEstablished">Date Established</Label>
              <DatePicker
                value={formValues.dateEstablished}
                onChange={(date) => form.setValue("dateEstablished", date)}
                placeholder="Select date established"
                disabled={disabled || isSubmitting}
              />
              {form.formState.errors.dateEstablished && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.dateEstablished.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="dateStarted">
                Date Started <span className="text-destructive">*</span>
              </Label>
              <DatePicker
                value={formValues.dateStarted}
                onChange={(date) => form.setValue("dateStarted", date)}
                placeholder="Select date started"
                disabled={disabled || isSubmitting}
              />
              {form.formState.errors.dateStarted && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.dateStarted.message}</p>
              )}
            </div>
          </div>

          {/* Row 2: Occupancy and Ownership Type */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="occupancy">Occupancy</Label>
              <Select value={formValues.occupancy} onValueChange={(value) => form.setValue("occupancy", value)} disabled={disabled || isSubmitting}>
                <SelectTrigger>
                  <SelectValue placeholder="Select occupancy type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rented">Rented</SelectItem>
                  <SelectItem value="owned">Owned</SelectItem>
                </SelectContent>
              </Select>
              {form.formState.errors.occupancy && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.occupancy.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="ownershipType">
                Ownership Type <span className="text-destructive">*</span>
              </Label>
              <Select value={formValues.ownershipType} onValueChange={(value) => form.setValue("ownershipType", value)} disabled={disabled || isSubmitting}>
                <SelectTrigger>
                  <SelectValue placeholder="Select ownership type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sole-proprietorship">Sole Proprietorship</SelectItem>
                  <SelectItem value="partnership">Partnership</SelectItem>
                  <SelectItem value="corporation">Corporation</SelectItem>
                  <SelectItem value="cooperative">Cooperative</SelectItem>
                  <SelectItem value="religious">Religious Organization</SelectItem>
                  <SelectItem value="non-profit">Non-Profit / Non-Stock Organization</SelectItem>
                </SelectContent>
              </Select>
              {form.formState.errors.ownershipType && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.ownershipType.message}</p>
              )}
            </div>
          </div>

          {/* Conditional Group Name Field - Only for Partnership, Corporation, Cooperative */}
          {["partnership", "corporation", "cooperative"].includes(
            formValues.ownershipType.toLowerCase().replace(/\s+/g, "-")
          ) && (
            <div>
              <Label htmlFor="groupName">
                Company/Organization Name <span className="text-destructive">*</span>
              </Label>
              <Input id="groupName" placeholder="Enter company or organization name" {...form.register("groupName")} disabled={disabled || isSubmitting} />
              {form.formState.errors.groupName && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.groupName.message}</p>
              )}
            </div>
          )}

          {/* Row 3-5: Employee Count */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Employee Count</Label>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="maleEmployeeCount">Male Employees</Label>
                <Input
                  id="maleEmployeeCount"
                  type="number"
                  min="0"
                  placeholder="0"
                  {...form.register("maleEmployeeCount", { valueAsNumber: true })}
                  disabled={disabled || isSubmitting}
                />
                {form.formState.errors.maleEmployeeCount && (
                  <p className="text-sm text-red-600 mt-1">{form.formState.errors.maleEmployeeCount.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="femaleEmployeeCount">Female Employees</Label>
                <Input
                  id="femaleEmployeeCount"
                  type="number"
                  min="0"
                  placeholder="0"
                  {...form.register("femaleEmployeeCount", { valueAsNumber: true })}
                  disabled={disabled || isSubmitting}
                />
                {form.formState.errors.femaleEmployeeCount && (
                  <p className="text-sm text-red-600 mt-1">{form.formState.errors.femaleEmployeeCount.message}</p>
                )}
              </div>
            </div>
            <div className="bg-muted px-4 py-2 rounded-lg">
              <p className="text-sm font-medium">
                Total Employees: {(formValues.maleEmployeeCount || 0) + (formValues.femaleEmployeeCount || 0)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Contact & Address Information Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Contact & Address Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="contactNumber">Business Contact Number</Label>
              <Input id="contactNumber" placeholder="+63 912 345 6789" {...form.register("contactNumber")} disabled={disabled || isSubmitting} />
              {form.formState.errors.contactNumber && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.contactNumber.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input id="email" type="email" placeholder="business@example.com" {...form.register("email")} disabled={disabled || isSubmitting} />
              {form.formState.errors.email && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.email.message}</p>
              )}
            </div>
          </div>

          <div>
            <Label htmlFor="address">
              Street Address <span className="text-destructive">*</span>
            </Label>
            <Input id="address" placeholder="House No., Street Name" {...form.register("address")} disabled={disabled || isSubmitting} />
            {form.formState.errors.address && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.address.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="buildingName">Building Name</Label>
            <Input id="buildingName" placeholder="Enter building name" {...form.register("buildingName")} disabled={disabled || isSubmitting} />
            {form.formState.errors.buildingName && (
              <p className="text-sm text-red-600 mt-1">{form.formState.errors.buildingName.message}</p>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="provinceId">
                Province <span className="text-destructive">*</span>
              </Label>
              <Select value={formValues.provinceId} onValueChange={handleProvinceChange} disabled={disabled || isSubmitting}>
                <SelectTrigger>
                  <SelectValue placeholder="Select province" />
                </SelectTrigger>
                <SelectContent>
                  {provinces?.map((province: { _id: string; name: string }) => (
                    <SelectItem key={province._id} value={province._id}>
                      {province.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.formState.errors.provinceId && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.provinceId.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="cityId">
                City/Municipality <span className="text-destructive">*</span>
              </Label>
              <Select
                value={formValues.cityId}
                onValueChange={handleCityChange}
                disabled={disabled || isSubmitting || isCityDisabled}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select city/municipality" />
                </SelectTrigger>
                <SelectContent>
                  {cities?.map((city: { _id: string; name: string }) => (
                    <SelectItem key={city._id} value={city._id}>
                      {city.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.formState.errors.cityId && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.cityId.message}</p>
              )}
            </div>

            <div>
              <Label htmlFor="barangayId">
                Barangay <span className="text-destructive">*</span>
              </Label>
              <Select
                value={formValues.barangayId}
                onValueChange={(value) => form.setValue("barangayId", value)}
                disabled={disabled || isSubmitting || isBarangayDisabled}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select barangay" />
                </SelectTrigger>
                <SelectContent>
                  {barangays?.map((barangay: { _id: string; name: string }) => (
                    <SelectItem key={barangay._id} value={barangay._id}>
                      {barangay.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.formState.errors.barangayId && (
                <p className="text-sm text-red-600 mt-1">{form.formState.errors.barangayId.message}</p>
              )}
            </div>
          </div>

          {/* Business Classification */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="categoryId">Category</Label>
              <Select
                value={formValues.categoryId || ""}
                onValueChange={handleCategoryChange}
                disabled={disabled || isSubmitting}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category (optional)" />
                </SelectTrigger>
                <SelectContent>
                  {categories?.map((cat: { _id: string; name: string }) => (
                    <SelectItem key={cat._id} value={cat._id}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="subCategoryId">Sub-Category</Label>
              <Select
                value={formValues.subCategoryId || ""}
                onValueChange={handleSubCategoryChange}
                disabled={disabled || isSubmitting || isSubCategoryDisabled}
              >
                <SelectTrigger>
                  <SelectValue placeholder={isSubCategoryDisabled ? "Select a category first" : "Select sub-category (optional)"} />
                </SelectTrigger>
                <SelectContent>
                  {subCategories?.map((sub: { _id: string; name: string }) => (
                    <SelectItem key={sub._id} value={sub._id}>
                      {sub.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Ownership-Specific Documents Section */}
      {ownershipType && ownershipType !== "" && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Ownership-Specific Documents
            </CardTitle>
            <CardDescription>
              Additional documents required based on your selected ownership type
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Registration Date and Number Fields - Related to ownership documents */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{getRegistrationDateDescription(ownershipType)}</Label>
                <DatePicker
                  value={formValues.registrationDate}
                  onChange={(date) => form.setValue("registrationDate", date)}
                  placeholder="Select or type date (MM/DD/YYYY)"
                  disabled={disabled || isSubmitting}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="registrationNumber">Registration Number</Label>
                <Input
                  id="registrationNumber"
                  placeholder="Enter registration number "
                  {...form.register("registrationNumber")}
                  disabled={disabled || isSubmitting}
                />
                {form.formState.errors.registrationNumber && (
                  <p className="text-sm text-red-600 mt-1">{form.formState.errors.registrationNumber.message}</p>
                )}
              </div>
            </div>

            <OwnershipDocumentsField
              ownershipType={ownershipType}
              businessId={business.id}
              documents={formValues.documents}
              existingDocuments={business.documents}
              onFileSelect={handleFileSelect}
              onFileRemove={handleFileRemove}
              onExistingDocumentDeleted={onSuccess}
              disabled={disabled}
            />
          </CardContent>
        </Card>
      )}

      {/* Submit Button */}
      <div className="flex justify-end pt-6 border-t">
        <Button type="submit" disabled={disabled || isSubmitting}>
          {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {isSubmitting ? "Updating..." : "Update"}
        </Button>
      </div>
    </form>
  );
}
