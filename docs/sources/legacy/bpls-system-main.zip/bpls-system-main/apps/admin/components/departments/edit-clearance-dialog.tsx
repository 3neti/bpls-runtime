/**
 * Edit Clearance Dialog Component
 *
 * Dialog form for editing existing clearances and their department information:
 * - Clearance details (name, certificate, description)
 * - Department information (name, icon, officer)
 * - Department slug is read-only (cannot be changed to preserve URLs)
 */

"use client"

import { useEffect, useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { useMutation } from "convex/react"
import { api } from "@repo/backend/convex/_generated/api"
import { useToast } from "@/hooks/use-toast"
import { iconOptions } from "@/lib/utils/icon-mapper"
import type { Department } from "@/lib/types/department"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import { Input } from "@repo/ui/components/input"
import { Textarea } from "@repo/ui/components/textarea"
import { Button } from "@repo/ui/components/button"
import { ScrollArea } from "@repo/ui/components/scroll-area"
import { departmentFormSchema, type DepartmentFormSchema } from "@/lib/schemas/department-form"

interface EditClearanceDialogProps {
  /** Whether the dialog is open */
  open: boolean
  /** Callback when dialog close state changes */
  onOpenChange: (open: boolean) => void
  /** Department data to edit (clearances consolidated into departments) */
  clearanceData: Department | null
  /** Callback when edit is successful */
  onSuccess: () => void
}

export function EditClearanceDialog({
  open,
  onOpenChange,
  clearanceData,
  onSuccess,
}: EditClearanceDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()
  const updateDepartment = useMutation(api.departments.updateDepartment)

  const form = useForm<DepartmentFormSchema>({
    resolver: zodResolver(departmentFormSchema),
    defaultValues: {
      clearanceName: "",
      certificateName: "",
      description: "",
      departmentFullName: "",
      departmentShortName: "",
      departmentSlug: "",
      icon: "Shield",
      officerName: "",
      officerEmail: "",
    },
    mode: "onChange",
  })

  // Update form when clearanceData changes
  useEffect(() => {
    if (clearanceData) {
      form.reset({
        clearanceName: clearanceData.name,
        certificateName: clearanceData.certificateName,
        description: clearanceData.description,
        departmentFullName: clearanceData.name,
        departmentShortName: clearanceData.shortName,
        departmentSlug: clearanceData.slug,
        icon: clearanceData.icon,
        officerName: clearanceData.officerName,
        officerEmail: clearanceData.officerEmail,
      })
    }
  }, [clearanceData, form])

  const handleSubmit = async (values: DepartmentFormSchema) => {
    if (!clearanceData) {
      toast({
        title: "Error",
        description: "No department data provided",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)
    try {
      // Use MODERN API (updateDepartment) - clearance is now part of department
      await updateDepartment({
        id: clearanceData._id, // Department ID (clearance consolidated into dept)
        name: values.departmentFullName,
        description: values.description,
        isActive: clearanceData.isActive, // Preserve existing active status
      } as any)

      toast({
        title: "Success",
        description: "Department updated successfully",
      })

      onSuccess()
      onOpenChange(false)
    } catch (error) {
      console.error("Failed to update department:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update department",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleCancel = () => {
    form.reset()
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle>Edit Clearance</DialogTitle>
          <DialogDescription>
            Update clearance and department information
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="max-h-[calc(90vh-200px)] pr-4">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
              {/* Clearance Information */}
              <div className="space-y-4">
                <h3 className="text-sm font-semibold">Clearance Information</h3>

                <FormField
                  control={form.control}
                  name="clearanceName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Clearance Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Sanitary Clearance" {...field} />
                      </FormControl>
                      <FormDescription>Display name for this clearance type</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="certificateName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Certificate Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Sanitary Certificate" {...field} />
                      </FormControl>
                      <FormDescription>Official certificate name</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Health and sanitation compliance certificate for business premises"
                          className="min-h-[80px] resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>Brief description of the clearance</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Department Information */}
              <div className="space-y-4">
                <h3 className="text-sm font-semibold">Department Information</h3>

                <FormField
                  control={form.control}
                  name="departmentFullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Department Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Sanitary Department" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="departmentShortName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Department Short Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Sanitary" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="departmentSlug"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Department Slug</FormLabel>
                      <FormControl>
                        <Input placeholder="sanitary" {...field} disabled />
                      </FormControl>
                      <FormDescription>
                        URL slug cannot be changed (preserves existing routes and links)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="icon"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Icon</FormLabel>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select an icon" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {iconOptions.map((option) => {
                            const IconComponent = option.icon
                            return (
                              <SelectItem key={option.value} value={option.value}>
                                <div className="flex items-center gap-2">
                                  <IconComponent className="h-4 w-4" />
                                  <span>{option.label}</span>
                                </div>
                              </SelectItem>
                            )
                          })}
                        </SelectContent>
                      </Select>
                      <FormDescription>Icon to display for this department</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Officer Information */}
              <div className="space-y-4">
                <h3 className="text-sm font-semibold">Officer Information</h3>

                <FormField
                  control={form.control}
                  name="officerName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Officer Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Sanitary Inspector" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="officerEmail"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Officer Email</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="sanitary@bpls.gov.ph" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </form>
          </Form>
        </ScrollArea>

        <DialogFooter>
          <Button variant="outline" onClick={handleCancel} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button onClick={form.handleSubmit(handleSubmit)} disabled={isSubmitting || !form.formState.isValid}>
            {isSubmitting ? "Updating..." : "Update Clearance"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
