"use client"

import React, { JSX } from "react"
import { Download, FileText, AlertCircle } from "lucide-react"
import { Button } from "@repo/ui/components/button"
import { Label } from "@repo/ui/components/label"
import { Alert, AlertDescription } from "@repo/ui/components/alert"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select"
import { Dropzone } from "@repo/ui/components/dropzone"

interface PrerequisitesFormProps {
  form: {
    state: {
      values: {
        ownershipType?: string
        documents?: Record<string, { file: File | null; uploaded: boolean }>
      }
    }
    setFieldValue: (name: string, value: unknown) => void
    Field: <TName extends string>({ name, validators, children }: {
      name: TName
      validators?: {
        onChange?: ({ value }: { value: string }) => string | undefined
      }
      children: (field: {
        name: string
        state: { value: string; meta: { errors?: string[] } }
        handleChange: (value: string) => void
        handleBlur: () => void
      }) => React.ReactNode
    }) => JSX.Element | null
  }
  onBack?: () => void
}

export function PrerequisitesForm({ form, onBack }: PrerequisitesFormProps) {
  const handleFileSelect = (documentType: string, file: File) => {
    // Use the form state to store documents
    const currentDocuments = form.state.values.documents || {}
    form.setFieldValue("documents", {
      ...currentDocuments,
      [documentType]: { file, uploaded: true }
    })
  }

  const handleFileRemove = (documentType: string) => {
    const currentDocuments = form.state.values.documents || {}
    form.setFieldValue("documents", {
      ...currentDocuments,
      [documentType]: { file: null, uploaded: false }
    })
  }

  const handleDownloadForm = () => {
    const link = document.createElement("a")
    link.href = "/placeholder.pdf"
    link.download = "Business-Permit-Application-Form.pdf"
    link.click()
  }

  const getDocumentFile = (documentType: string): File | null => {
    const documents = form.state.values.documents || {}
    return documents[documentType]?.file || null
  }

  const renderConditionalDocuments = (ownershipType?: string) => {
    console.log("[Prerequisites] Current ownership type:", ownershipType)

    const normalizedOwnershipType = ownershipType?.toLowerCase().replace(/\s+/g, "-")

    if (normalizedOwnershipType === "sole-proprietorship") {
      return (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              DTI Certificate of Business Name Registration
            </CardTitle>
            <CardDescription>Upload your Department of Trade and Industry certificate</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Upload DTI Certificate of Business Name Registration</Label>
              <Dropzone
                onFileSelect={(file) => handleFileSelect("dtiCertificate", file)}
                onFileRemove={() => handleFileRemove("dtiCertificate")}
                selectedFile={getDocumentFile("dtiCertificate")}
              />
            </div>
          </CardContent>
        </Card>
      )
    }

    if (normalizedOwnershipType === "partnership") {
      return (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                SEC Certificate of Registration (Partnership)
              </CardTitle>
              <CardDescription>Upload your SEC Certificate of Registration for Partnership</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload SEC Certificate of Registration (Partnership)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("secCertificate", file)}
                  onFileRemove={() => handleFileRemove("secCertificate")}
                  selectedFile={getDocumentFile("secCertificate")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Articles of Partnership
              </CardTitle>
              <CardDescription>Upload your Articles of Partnership</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Articles of Partnership</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("articlesOfPartnership", file)}
                  onFileRemove={() => handleFileRemove("articlesOfPartnership")}
                  selectedFile={getDocumentFile("articlesOfPartnership")}
                />
              </div>
            </CardContent>
          </Card>
        </>
      )
    }

    if (normalizedOwnershipType === "corporation") {
      return (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                SEC Certificate of Incorporation/Registration
              </CardTitle>
              <CardDescription>Upload your SEC Certificate of Incorporation/Registration</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload SEC Certificate of Incorporation/Registration</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("secCertificate", file)}
                  onFileRemove={() => handleFileRemove("secCertificate")}
                  selectedFile={getDocumentFile("secCertificate")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Articles of Incorporation
              </CardTitle>
              <CardDescription>Upload your Articles of Incorporation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Articles of Incorporation</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("articlesOfIncorporation", file)}
                  onFileRemove={() => handleFileRemove("articlesOfIncorporation")}
                  selectedFile={getDocumentFile("articlesOfIncorporation")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                By-Laws
              </CardTitle>
              <CardDescription>Upload your By-Laws</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload By-Laws</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("bylaws", file)}
                  onFileRemove={() => handleFileRemove("bylaws")}
                  selectedFile={getDocumentFile("bylaws")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Most Recent General Information Sheet (GIS)
              </CardTitle>
              <CardDescription>Upload your most recent GIS filed with SEC</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Most Recent General Information Sheet (GIS)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("gis", file)}
                  onFileRemove={() => handleFileRemove("gis")}
                  selectedFile={getDocumentFile("gis")}
                />
              </div>
            </CardContent>
          </Card>
        </>
      )
    }

    if (normalizedOwnershipType === "cooperative") {
      return (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                CDA Certificate of Registration
              </CardTitle>
              <CardDescription>
                Upload your Cooperative Development Authority Certificate of Registration
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload CDA Certificate of Registration</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("cdaCertificate", file)}
                  onFileRemove={() => handleFileRemove("cdaCertificate")}
                  selectedFile={getDocumentFile("cdaCertificate")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Articles of Cooperation
              </CardTitle>
              <CardDescription>Upload your Articles of Cooperation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Articles of Cooperation</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("articlesOfCooperation", file)}
                  onFileRemove={() => handleFileRemove("articlesOfCooperation")}
                  selectedFile={getDocumentFile("articlesOfCooperation")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                By-Laws
              </CardTitle>
              <CardDescription>Upload your By-Laws</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload By-Laws</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("bylaws", file)}
                  onFileRemove={() => handleFileRemove("bylaws")}
                  selectedFile={getDocumentFile("bylaws")}
                />
              </div>
            </CardContent>
          </Card>
        </>
      )
    }

    if (normalizedOwnershipType === "religious") {
      return (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                SEC Certificate of Incorporation (Religious Corporation)
              </CardTitle>
              <CardDescription>Upload your SEC Certificate of Incorporation for Religious Corporation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload SEC Certificate of Incorporation (Religious Corporation)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("secCertificate", file)}
                  onFileRemove={() => handleFileRemove("secCertificate")}
                  selectedFile={getDocumentFile("secCertificate")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Articles of Incorporation (Religious Corporation)
              </CardTitle>
              <CardDescription>Upload your Articles of Incorporation for Religious Corporation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Articles of Incorporation (Religious Corporation)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("articlesOfIncorporation", file)}
                  onFileRemove={() => handleFileRemove("articlesOfIncorporation")}
                  selectedFile={getDocumentFile("articlesOfIncorporation")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                By-Laws
              </CardTitle>
              <CardDescription>Upload your By-Laws</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload By-Laws</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("bylaws", file)}
                  onFileRemove={() => handleFileRemove("bylaws")}
                  selectedFile={getDocumentFile("bylaws")}
                />
              </div>
            </CardContent>
          </Card>
        </>
      )
    }

    if (normalizedOwnershipType === "non-profit") {
      return (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                SEC Certificate of Incorporation (Non-Stock / Non-Profit)
              </CardTitle>
              <CardDescription>
                Upload your SEC Certificate of Incorporation for Non-Stock/Non-Profit Organization
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload SEC Certificate of Incorporation (Non-Stock / Non-Profit)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("secCertificate", file)}
                  onFileRemove={() => handleFileRemove("secCertificate")}
                  selectedFile={getDocumentFile("secCertificate")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Articles of Incorporation
              </CardTitle>
              <CardDescription>Upload your Articles of Incorporation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Articles of Incorporation</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("articlesOfIncorporation", file)}
                  onFileRemove={() => handleFileRemove("articlesOfIncorporation")}
                  selectedFile={getDocumentFile("articlesOfIncorporation")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                By-Laws
              </CardTitle>
              <CardDescription>Upload your By-Laws</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload By-Laws</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("bylaws", file)}
                  onFileRemove={() => handleFileRemove("bylaws")}
                  selectedFile={getDocumentFile("bylaws")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Most Recent General Information Sheet (GIS)
              </CardTitle>
              <CardDescription>Upload your most recent GIS filed with SEC</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Most Recent General Information Sheet (GIS)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("gis", file)}
                  onFileRemove={() => handleFileRemove("gis")}
                  selectedFile={getDocumentFile("gis")}
                />
              </div>
            </CardContent>
          </Card>
        </>
      )
    }

    return null
  }

  return (
    <div className="space-y-6">
      {/* Ownership Type Selection */}
      <Card>
        <CardHeader>
          <CardTitle>Business Ownership Type</CardTitle>
          <CardDescription>Select the ownership type of your business to determine required documents</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <form.Field
            name="ownershipType"
            validators={{
              onChange: ({ value }: { value: string }) => (!value ? "Ownership type is required" : undefined),
            }}
          >
            {(field) => (
              <div className="space-y-2">
                <Label htmlFor={field.name}>Ownership Type</Label>
                <Select value={field.state.value} onValueChange={field.handleChange}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select ownership type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sole-proprietorship">Sole Proprietorship</SelectItem>
                    <SelectItem value="partnership">Partnership</SelectItem>
                    <SelectItem value="corporation">Corporation</SelectItem>
                    <SelectItem value="cooperative">Cooperative</SelectItem>
                    <SelectItem value="religious">Religious Organization</SelectItem>
                    <SelectItem value="non-profit">Non-Profit / Non-Stock Organization</SelectItem>
                  </SelectContent>
                </Select>
                {field.state.meta.errors && (
                  <p className="text-sm text-destructive">{field.state.meta.errors[0]}</p>
                )}
              </div>
            )}
          </form.Field>
        </CardContent>
      </Card>

      {/* Dynamic Documents Section */}
      <div>
        <h3 className="text-lg font-semibold mb-2">Ownership-Specific Documents</h3>
        <p className="text-muted-foreground mb-6">
          Additional documents required based on your selected ownership type
        </p>
      </div>

      {/* Conditional Documents based on Ownership Type */}
      <form.Field name="ownershipType">
        {(ownershipField) => renderConditionalDocuments(ownershipField.state.value)}
      </form.Field>
    </div>
  )
}
