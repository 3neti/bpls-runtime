"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "convex/react";
import { MapPin, Save, Loader2, X, Info, Lock } from "lucide-react";
import { Button } from "@repo/ui/components/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form";
import { Input } from "@repo/ui/components/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";
import { Badge } from "@repo/ui/components/badge";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import {
  municipalitySettingsSchema,
  municipalitySettingsDefaultValues,
  type MunicipalitySettingsSchema,
} from "@/lib/schemas/settings";
import { usePermissions } from "@/hooks/use-permissions";

interface MunicipalitySectionProps {
  settings: NonNullable<ReturnType<typeof useQuery<typeof api.platformSettings.get>>>;
  toast: (options: { title: string; description: string; variant?: "default" | "destructive" }) => void;
}

export function MunicipalitySection({ settings, toast }: MunicipalitySectionProps) {
  const { canUpdate, isLoading: permissionsLoading } = usePermissions();
  const canEdit = canUpdate("settings:municipality");
  const updateSettings = useMutation(api.platformSettings.update);

  // Location defaults state
  const [selectedProvinceId, setSelectedProvinceId] = useState<string>(
    (settings?.defaultProvinceId as string) || ""
  );
  const [selectedCityId, setSelectedCityId] = useState<string>(
    (settings?.defaultCityId as string) || ""
  );
  const [selectedBarangayId, setSelectedBarangayId] = useState<string>(
    (settings?.defaultBarangayId as string) || ""
  );

  // Location data queries
  const provinces = useQuery(api.locations.listProvinces);
  const cities = useQuery(
    api.locations.listCitiesByProvince,
    selectedProvinceId ? { provinceId: selectedProvinceId as Id<"provinces"> } : "skip"
  );
  const barangays = useQuery(
    api.locations.listBarangaysByCity,
    selectedCityId ? { cityId: selectedCityId as Id<"cities"> } : "skip"
  );

  const form = useForm<MunicipalitySettingsSchema>({
    resolver: zodResolver(municipalitySettingsSchema),
    defaultValues: {
      municipalityName: settings?.municipalityName ?? municipalitySettingsDefaultValues.municipalityName,
      municipalityShortName: settings?.municipalityShortName ?? municipalitySettingsDefaultValues.municipalityShortName,
      provinceName: settings?.provinceName ?? municipalitySettingsDefaultValues.provinceName,
      fullAddress: settings?.fullAddress ?? municipalitySettingsDefaultValues.fullAddress,
    },
  });

  // Combined submit handler for both Municipality Information and Location Defaults
  const onSubmit = async (values: MunicipalitySettingsSchema) => {
    try {
      await updateSettings({
        ...values,
        // Include location defaults in the same save operation
        defaultProvinceId: selectedProvinceId ? (selectedProvinceId as Id<"provinces">) : null,
        defaultCityId: selectedCityId ? (selectedCityId as Id<"cities">) : null,
        defaultBarangayId: selectedBarangayId ? (selectedBarangayId as Id<"barangays">) : null,
      });
      toast({
        title: "Settings saved",
        description: "Municipality information and location defaults have been updated successfully.",
      });
    } catch {
      toast({
        title: "Error",
        description: "Failed to save settings. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Handle province change - clear dependent fields
  const handleProvinceChange = (value: string) => {
    setSelectedProvinceId(value);
    setSelectedCityId("");
    setSelectedBarangayId("");
  };

  // Handle city change - clear barangay
  const handleCityChange = (value: string) => {
    setSelectedCityId(value);
    setSelectedBarangayId("");
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Municipality Information
              {!canEdit && !permissionsLoading && (
                <Badge variant="secondary" className="ml-2 gap-1">
                  <Lock className="h-3 w-3" />
                  Read Only
                </Badge>
              )}
              {canEdit && (
                <Badge variant="outline" className="ml-2">
                  Admin Only
                </Badge>
              )}
            </CardTitle>
            <CardDescription>
              Configure municipality details that appear in permits, receipts, and official documents
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="municipalityName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Municipality Name (Full)</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="MUNICIPALITY OF IPIL" disabled={!canEdit || permissionsLoading} />
                  </FormControl>
                  <FormDescription>
                    Full official name used in document headers (e.g., &quot;MUNICIPALITY OF IPIL&quot;)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="municipalityShortName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Municipality Short Name</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Ipil" disabled={!canEdit || permissionsLoading} />
                  </FormControl>
                  <FormDescription>
                    Short name used in legal text and document body (e.g., &quot;Ipil&quot;)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="provinceName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Province Name</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Zamboanga Sibugay" disabled={!canEdit || permissionsLoading} />
                  </FormControl>
                  <FormDescription>
                    Province name displayed in document headers
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="fullAddress"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Address Line</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="IPIL, ZAMBOANGA SIBUGAY" disabled={!canEdit || permissionsLoading} />
                  </FormControl>
                  <FormDescription>
                    Location line used in receipts and permit documents
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Location Defaults Section - Below Municipality Information */}
            <div className="pt-6 border-t">
              <div className="mb-4">
                <h3 className="text-base font-semibold flex items-center gap-2">
                  Location Defaults for New Resources
                  <Badge variant="outline">Optional</Badge>
                </h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Set default location values that pre-populate when creating new businesses, business owners, and permit applications.
                </p>
              </div>

              {/* Info Banner */}
              <div className="flex items-start gap-3 rounded-lg border border-blue-200 bg-blue-50 p-4 mb-6">
                <Info className="h-5 w-5 text-blue-600 shrink-0 mt-0.5" />
                <div className="text-sm text-blue-800">
                  <p className="font-medium">Optional Settings</p>
                  <p className="text-blue-700 mt-1">
                    All fields are optional. If not set, the first available province will be used as a fallback
                    when creating new resources.
                  </p>
                </div>
              </div>

              {/* Province Dropdown */}
              <div className="space-y-2 mb-4">
                <label className="text-sm font-medium">Default Province</label>
                <div className="flex gap-2">
                  <Select
                    value={selectedProvinceId}
                    onValueChange={handleProvinceChange}
                    disabled={!canEdit || permissionsLoading}
                  >
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Select province..." />
                    </SelectTrigger>
                    <SelectContent>
                      {provinces?.map((province: { _id: string; name: string }) => (
                        <SelectItem key={province._id} value={province._id}>
                          {province.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {selectedProvinceId && (
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => {
                        setSelectedProvinceId("");
                        setSelectedCityId("");
                        setSelectedBarangayId("");
                      }}
                      title="Clear province"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  Select the default province for new resources
                </p>
              </div>

              {/* City Dropdown */}
              <div className="space-y-2 mb-4">
                <label className="text-sm font-medium">Default City/Municipality</label>
                <div className="flex gap-2">
                  <Select
                    value={selectedCityId}
                    onValueChange={handleCityChange}
                    disabled={!selectedProvinceId || !canEdit || permissionsLoading}
                  >
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder={selectedProvinceId ? "Select city/municipality..." : "Select province first"} />
                    </SelectTrigger>
                    <SelectContent>
                      {cities?.map((city: { _id: string; name: string }) => (
                        <SelectItem key={city._id} value={city._id}>
                          {city.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {selectedCityId && (
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => {
                        setSelectedCityId("");
                        setSelectedBarangayId("");
                      }}
                      title="Clear city"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  {selectedProvinceId
                    ? "Select the default city/municipality for new resources"
                    : "Select a province first to enable city selection"}
                </p>
              </div>

              {/* Barangay Dropdown */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Default Barangay</label>
                <div className="flex gap-2">
                  <Select
                    value={selectedBarangayId}
                    onValueChange={setSelectedBarangayId}
                    disabled={!selectedCityId || !canEdit || permissionsLoading}
                  >
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder={selectedCityId ? "Select barangay..." : "Select city first"} />
                    </SelectTrigger>
                    <SelectContent>
                      {barangays?.map((barangay: { _id: string; name: string }) => (
                        <SelectItem key={barangay._id} value={barangay._id}>
                          {barangay.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {selectedBarangayId && (
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => setSelectedBarangayId("")}
                      title="Clear barangay"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  {selectedCityId
                    ? "Select the default barangay for new resources"
                    : "Select a city first to enable barangay selection"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {canEdit && (
          <div className="flex justify-end">
            <Button type="submit" disabled={form.formState.isSubmitting}>
              {form.formState.isSubmitting ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Save className="mr-2 h-4 w-4" />
              )}
              Save Changes
            </Button>
          </div>
        )}
      </form>
    </Form>
  );
}
