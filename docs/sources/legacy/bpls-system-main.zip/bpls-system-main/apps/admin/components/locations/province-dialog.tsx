"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@repo/ui/components/form";
import { Input } from "@repo/ui/components/input";
import { Button } from "@repo/ui/components/button";
import { toast } from "sonner";
import type { Province } from "@/lib/types/location";
import type { Id } from "@repo/backend/convex/_generated/dataModel";

const provinceSchema = z.object({
  name: z.string().min(1, "Province name is required"),
  code: z.string().optional(),
});

type ProvinceFormValues = z.infer<typeof provinceSchema>;

interface ProvinceDialogProps {
  mode: "create" | "edit";
  province?: Province;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export function ProvinceDialog({ mode, province, open, onOpenChange, onSuccess }: ProvinceDialogProps) {
  const createProvince = useMutation(api.locations.createProvince);
  const updateProvince = useMutation(api.locations.updateProvince);

  const form = useForm<ProvinceFormValues>({
    resolver: zodResolver(provinceSchema),
    defaultValues: {
      name: province?.name || "",
      code: province?.code || "",
    },
  });

  const onSubmit = async (values: ProvinceFormValues) => {
    try {
      if (mode === "create") {
        await createProvince({
          name: values.name,
          code: values.code || undefined,
        });
        toast.success("Province created successfully");
      } else {
        if (!province?._id) {
          toast.error("Province ID is missing");
          return;
        }
        await updateProvince({
          id: province._id as Id<"provinces">,
          name: values.name,
          code: values.code || undefined,
        });
        toast.success("Province updated successfully");
      }
      form.reset();
      onOpenChange(false);
      onSuccess?.();
    } catch (error) {
      toast.error(mode === "create" ? "Failed to create province" : "Failed to update province");
      console.error(error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{mode === "create" ? "Add Province" : "Edit Province"}</DialogTitle>
          <DialogDescription>
            {mode === "create" ? "Add a new province to the location hierarchy." : "Update province information."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    Province Name <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g., Zamboanga del Sur" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="code"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>PSGC Code </FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g., 097200000" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting
                  ? mode === "create"
                    ? "Creating..."
                    : "Updating..."
                  : mode === "create"
                    ? "Create Province"
                    : "Update Province"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
