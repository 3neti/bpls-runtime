"use client"

import { Plus, Trash2, AlertCircle, ChevronDown } from "lucide-react"

import { Button } from "@repo/ui/components/button"
import { Input } from "@repo/ui/components/input"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card"
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"
import { Alert, AlertDescription } from "@repo/ui/components/alert"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import { FeeSelector } from "./fee-selector"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { formatCurrency } from "@/lib/utils"
import { useColumnVisibilityStore, isLineItemsColumnVisible } from "@/lib/stores/column-visibility-store"

// Static column definitions for line items table
const STATIC_COLUMNS = [
  { id: "fee", label: "Fee", alwaysVisible: true },
  { id: "amount", label: "Amount", alwaysVisible: false },
  { id: "qty", label: "Qty", alwaysVisible: false },
  { id: "subtotal", label: "Subtotal", alwaysVisible: false },
] as const

type FeeFieldType = "text" | "number" | "currency" | "date" | "dropdown" | "checkbox"

interface FeeCustomFieldValue {
  fieldId: Id<"billing_group_fee_fields">
  value: string
}

interface Fee {
  _id: Id<"billing_group_fees">
  name: string
  code: string
  defaultAmount: number
  isActive: boolean
  customFieldValues?: FeeCustomFieldValue[]
}

export interface FeeField {
  _id: Id<"billing_group_fee_fields">
  name: string
  fieldType: FeeFieldType
  isRequired: boolean
  includeInReceipt?: boolean
  sortOrder: number
  options?: string[]
}

export interface LineItem {
  id: string // Temporary ID for UI tracking
  feeId?: Id<"billing_group_fees">
  fee?: Fee
  amount: number
  quantity: number
}

interface LineItemEditorProps {
  billingGroupId: Id<"billing_groups">
  lineItems: LineItem[]
  onChange: (lineItems: LineItem[]) => void
  maxLineItems: number
  feeFields?: FeeField[]
  disabled?: boolean
}

export function LineItemEditor({
  billingGroupId,
  lineItems,
  onChange,
  maxLineItems,
  feeFields = [],
  disabled = false,
}: LineItemEditorProps) {
  // Column visibility from store
  const { lineItemsColumns, toggleLineItemsColumn } = useColumnVisibilityStore()

  // Helper to check if a column is visible
  const isColumnVisible = (columnId: string) => isLineItemsColumnVisible(lineItemsColumns, columnId)

  // Generate unique ID for new line items
  const generateId = () => `temp_${Date.now()}_${Math.random().toString(36).slice(2)}`

  // Calculate total
  const total = lineItems.reduce(
    (sum, item) => sum + item.amount * item.quantity,
    0
  )

  // Helper to get custom field value from fee
  const getFeeFieldValue = (
    fee: Fee | undefined,
    fieldId: Id<"billing_group_fee_fields">
  ): string => {
    if (!fee?.customFieldValues) return "—"
    const fieldValue = fee.customFieldValues.find(
      (fv) => fv.fieldId === fieldId
    )
    return fieldValue?.value || "—"
  }

  // Format fee field value for display
  const formatFeeFieldValue = (fieldType: FeeFieldType, value: string): string => {
    if (!value || value === "—") return "—"

    if (fieldType === "currency") {
      const num = parseFloat(value)
      return isNaN(num) ? value : formatCurrency(num)
    }
    if (fieldType === "checkbox") {
      return value === "true" ? "Yes" : "No"
    }
    if (fieldType === "date") {
      try {
        return new Date(value).toLocaleDateString("en-US", {
          year: "numeric",
          month: "short",
          day: "numeric",
        })
      } catch {
        return value
      }
    }
    return value
  }

  const addLineItem = () => {
    if (lineItems.length >= maxLineItems) return

    const newItem: LineItem = {
      id: generateId(),
      feeId: undefined,
      fee: undefined,
      amount: 0,
      quantity: 1,
    }

    onChange([...lineItems, newItem])
  }

  const removeLineItem = (id: string) => {
    onChange(lineItems.filter((item) => item.id !== id))
  }

  const updateLineItem = (id: string, updates: Partial<LineItem>) => {
    onChange(
      lineItems.map((item) =>
        item.id === id ? { ...item, ...updates } : item
      )
    )
  }

  const handleFeeSelect = (itemId: string, fee: Fee | null) => {
    if (fee) {
      updateLineItem(itemId, {
        feeId: fee._id,
        fee,
        amount: fee.defaultAmount,
      })
    } else {
      updateLineItem(itemId, {
        feeId: undefined,
        fee: undefined,
        amount: 0,
      })
    }
  }

  const handleAmountChange = (itemId: string, value: string) => {
    const amount = parseFloat(value) || 0
    updateLineItem(itemId, { amount })
  }

  const handleQuantityChange = (itemId: string, value: string) => {
    const quantity = Math.max(1, parseInt(value) || 1)
    updateLineItem(itemId, { quantity })
  }

  const canAddMore = lineItems.length < maxLineItems

  // Count visible fee field columns for colspan calculation
  const visibleFeeFieldsCount = feeFields.filter((f) => isColumnVisible(`feeField_${f._id}`)).length

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-base">Line Items</CardTitle>
            <CardDescription>
              Add fees from the library ({lineItems.length} of {maxLineItems} items)
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  Columns
                  <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[200px]">
                <DropdownMenuLabel>Static Columns</DropdownMenuLabel>
                {STATIC_COLUMNS.map((column) => (
                  <DropdownMenuCheckboxItem
                    key={column.id}
                    checked={isColumnVisible(column.id)}
                    onCheckedChange={() => toggleLineItemsColumn(column.id)}
                    disabled={column.alwaysVisible}
                  >
                    {column.label}
                  </DropdownMenuCheckboxItem>
                ))}
                {feeFields.length > 0 && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuLabel>Fee Fields</DropdownMenuLabel>
                    {feeFields.map((field) => (
                      <DropdownMenuCheckboxItem
                        key={field._id}
                        checked={isColumnVisible(`feeField_${field._id}`)}
                        onCheckedChange={() => toggleLineItemsColumn(`feeField_${field._id}`)}
                      >
                        {field.name}
                      </DropdownMenuCheckboxItem>
                    ))}
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
            <Button
              type="button"
              size="sm"
              onClick={addLineItem}
              disabled={disabled || !canAddMore}
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Fee
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {lineItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center border border-dashed rounded-lg">
            <AlertCircle className="h-8 w-8 text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground mb-3">
              No line items added yet
            </p>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={addLineItem}
              disabled={disabled}
            >
              <Plus className="mr-2 h-4 w-4" />
              Add First Fee
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[40px]"></TableHead>
                    <TableHead className="whitespace-nowrap">Fee</TableHead>
                    {feeFields.map((field) =>
                      isColumnVisible(`feeField_${field._id}`) && (
                        <TableHead key={field._id} className="min-w-[100px] whitespace-nowrap">
                          {field.name}
                        </TableHead>
                      )
                    )}
                    {isColumnVisible("amount") && (
                      <TableHead className="min-w-[130px] shrink-0 text-right whitespace-nowrap px-3">
                        Amount
                      </TableHead>
                    )}
                    {isColumnVisible("qty") && (
                      <TableHead className="min-w-[90px] shrink-0 text-center whitespace-nowrap px-3">
                        Qty
                      </TableHead>
                    )}
                    {isColumnVisible("subtotal") && (
                      <TableHead className="min-w-[120px] shrink-0 text-right whitespace-nowrap">
                        Subtotal
                      </TableHead>
                    )}
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {lineItems.map((item, index) => (
                    <TableRow key={item.id}>
                      <TableCell className="text-muted-foreground text-center">
                        {index + 1}
                      </TableCell>
                      <TableCell>
                        <FeeSelector
                          billingGroupId={billingGroupId}
                          value={item.feeId}
                          onSelect={(fee) => handleFeeSelect(item.id, fee)}
                          disabled={disabled}
                          placeholder="Select fee..."
                        />
                      </TableCell>
                      {feeFields.map((field) =>
                        isColumnVisible(`feeField_${field._id}`) && (
                          <TableCell key={field._id} className="text-sm text-muted-foreground whitespace-nowrap">
                            {formatFeeFieldValue(
                              field.fieldType,
                              getFeeFieldValue(item.fee, field._id)
                            )}
                          </TableCell>
                        )
                      )}
                      {isColumnVisible("amount") && (
                        <TableCell className="px-3">
                          <div className="relative">
                            <span className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">
                              ₱
                            </span>
                            <Input
                              type="number"
                              step="0.01"
                              min="0"
                              value={item.amount || ""}
                              onChange={(e) => handleAmountChange(item.id, e.target.value)}
                              disabled={disabled}
                              className="pl-6 text-right"
                            />
                          </div>
                        </TableCell>
                      )}
                      {isColumnVisible("qty") && (
                        <TableCell className="px-3">
                          <Input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => handleQuantityChange(item.id, e.target.value)}
                            disabled={disabled}
                            className="text-center"
                          />
                        </TableCell>
                      )}
                      {isColumnVisible("subtotal") && (
                        <TableCell className="text-right font-medium whitespace-nowrap">
                          {formatCurrency(item.amount * item.quantity)}
                        </TableCell>
                      )}
                      <TableCell>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removeLineItem(item.id)}
                          disabled={disabled}
                          className="h-8 w-8 text-muted-foreground hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
                <TableFooter>
                  <TableRow>
                    <TableCell
                      colSpan={
                        2 + // # column + Fee column
                        visibleFeeFieldsCount +
                        (isColumnVisible("amount") ? 1 : 0) +
                        (isColumnVisible("qty") ? 1 : 0)
                      }
                      className="text-right font-medium"
                    >
                      Total
                    </TableCell>
                    {isColumnVisible("subtotal") && (
                      <TableCell className="text-right font-bold text-lg whitespace-nowrap">
                        {formatCurrency(total)}
                      </TableCell>
                    )}
                    <TableCell></TableCell>
                  </TableRow>
                </TableFooter>
              </Table>
            </div>

            {!canAddMore && (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Maximum of {maxLineItems} line items reached for this billing group.
                </AlertDescription>
              </Alert>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
