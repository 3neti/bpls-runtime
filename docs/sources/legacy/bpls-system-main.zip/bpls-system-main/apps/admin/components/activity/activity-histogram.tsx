"use client";

import { Bar, BarChart, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Skeleton } from "@repo/ui/components/skeleton";

interface HistogramData {
  buckets: Array<{
    timestamp: number;
    count: number;
    label: string;
  }>;
  bucketMs: number;
  totalCount: number;
}

interface ActivityHistogramProps {
  data: HistogramData | null | undefined;
  isLoading?: boolean;
}

export function ActivityHistogram({ data, isLoading }: ActivityHistogramProps) {
  // Show skeleton while loading
  if (isLoading || !data) {
    return <Skeleton className="h-16 w-full" />;
  }

  const { buckets, totalCount } = data;

  // No data state
  if (buckets.length === 0 || totalCount === 0) {
    return (
      <div className="h-16 flex items-center justify-center text-sm text-muted-foreground">
        No activity data for selected period
      </div>
    );
  }

  // Prepare chart data - ensure we have at least some visible bars
  const chartData = buckets.map((bucket) => ({
    label: bucket.label,
    count: bucket.count,
    timestamp: bucket.timestamp,
  }));

  // Calculate max value for Y axis
  const maxCount = Math.max(...chartData.map((d) => d.count), 1);

  return (
    <div className="h-16">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={chartData}
          margin={{ top: 0, right: 0, left: 0, bottom: 0 }}
        >
          <XAxis
            dataKey="label"
            tick={{ fontSize: 9 }}
            tickLine={false}
            axisLine={false}
            interval="preserveStartEnd"
            minTickGap={30}
          />
          <YAxis hide domain={[0, maxCount]} />
          <Tooltip
            cursor={{ fill: "hsl(var(--muted))", opacity: 0.3 }}
            content={({ active, payload }) => {
              if (!active || !payload?.length) return null;
              const data = payload[0].payload;
              return (
                <div className="bg-popover border rounded-md shadow-md px-2 py-1 text-xs">
                  <p className="font-medium">{data.label}</p>
                  <p className="text-muted-foreground">
                    {data.count} {data.count === 1 ? "activity" : "activities"}
                  </p>
                </div>
              );
            }}
          />
          <Bar
            dataKey="count"
            fill="hsl(var(--chart-1))"
            radius={[2, 2, 0, 0]}
            maxBarSize={12}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
