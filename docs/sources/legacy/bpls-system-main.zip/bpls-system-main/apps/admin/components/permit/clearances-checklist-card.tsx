/**
 * Clearances Checklist Card Component
 *
 * Displays a checklist of clearances for released permit applications with:
 * - Progress bar showing completion percentage
 * - List of clearances with checkboxes for toggling completion
 * - Department icon and certificate name
 * - Completion date when checked
 * - "Issue Business Permit" button (disabled until all clearances complete)
 * - "View Business Permit" button (after permit is issued)
 *
 * Uses permit_clearances table for persistent tracking
 */

"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useMutation, useQuery } from "convex/react"
import {
  ClipboardCheck,
  CheckCircle2,
  Loader2,
  Shield,
  Flame,
  Building2,
  TreePine,
  Wrench,
  Building,
  FileCheck,
  Briefcase,
  Award,
  AlertCircle,
} from "lucide-react"

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card"
import { Checkbox } from "@repo/ui/components/checkbox"
import { Label } from "@repo/ui/components/label"
import { Input } from "@repo/ui/components/input"
import { Button } from "@repo/ui/components/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { useToast } from "@/hooks/use-toast"
import { usePermissions } from "@/hooks/use-permissions"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

// Icon mapping for departments
const DEPARTMENT_ICONS: Record<
  string,
  React.ComponentType<{ className?: string }>
> = {
  Shield,
  Flame,
  Building2,
  TreePine,
  Wrench,
  Building,
  FileCheck,
  Briefcase,
}

interface ClearancesChecklistCardProps {
  applicationId: Id<"business_permit_applications">
  // Props for confirmation dialog display
  applicationNumber?: string
  businessName?: string
}

export function ClearancesChecklistCard({
  applicationId,
  applicationNumber,
  businessName,
}: ClearancesChecklistCardProps) {
  const { toast } = useToast()
  const router = useRouter()
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)
  const [isIssuing, setIsIssuing] = useState(false)
  const [customPermitNumber, setCustomPermitNumber] = useState("")
  const [permitNumberError, setPermitNumberError] = useState("")

  // Permission checking
  const { canCreate, isLoading: permissionsLoading } = usePermissions()
  const canCreatePermit = canCreate("permits")

  // Fetch clearances for this application
  const clearances = useQuery(api.permitClearances.getByApplication, {
    applicationId,
  })
  const progressSummary = useQuery(api.permitClearances.getProgressSummary, {
    applicationId,
  })

  // Check if permit already exists for this application
  const existingPermit = useQuery(api.permits.getByApplication, {
    applicationId,
  })

  // Check permit number availability (debounced via query skip)
  const permitNumberCheck = useQuery(
    api.permits.checkPermitNumberAvailability,
    customPermitNumber.trim()
      ? { permitNumber: customPermitNumber.trim() }
      : "skip"
  )

  // Update error state based on availability check
  useEffect(() => {
    if (permitNumberCheck && !permitNumberCheck.available) {
      setPermitNumberError("This permit number is already in use")
    } else {
      setPermitNumberError("")
    }
  }, [permitNumberCheck])

  // Initialize permit number when dialog opens
  useEffect(() => {
    if (showConfirmDialog && applicationNumber) {
      setCustomPermitNumber(applicationNumber.replace("BPA-", "BP-"))
      setPermitNumberError("")
    }
  }, [showConfirmDialog, applicationNumber])

  // Mutations
  const toggleCompletion = useMutation(api.permitClearances.toggleCompletion)
  const issuePermit = useMutation(api.permits.issuePermit)

  const handleToggle = async (clearanceId: Id<"permit_clearances">) => {
    try {
      const result = await toggleCompletion({
        clearanceId,
        completedBy: "current-user", // TODO: Get from auth context
      })

      toast({
        title: result.isCompleted ? "Clearance Completed" : "Clearance Unchecked",
        description: result.message,
      })
    } catch {
      toast({
        title: "Error",
        description: "Failed to update clearance status",
        variant: "destructive",
      })
    }
  }

  // Handle permit issuance
  const handleIssuePermit = async () => {
    if (!customPermitNumber.trim()) {
      setPermitNumberError("Permit number is required")
      return
    }
    if (permitNumberError) return

    setIsIssuing(true)
    try {
      const result = await issuePermit({
        applicationId,
        issuedBy: "current-user", // TODO: Get from auth context
        permitNumber: customPermitNumber.trim(),
      })

      toast({
        title: "Permit Issued",
        description: result.message,
      })

      setShowConfirmDialog(false)
      // Redirect to the permit detail page
      router.push(`/dashboard/permits/${result.permitId}`)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to issue permit",
        variant: "destructive",
      })
    } finally {
      setIsIssuing(false)
    }
  }

  // Loading state
  if (clearances === undefined || progressSummary === undefined || existingPermit === undefined) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <ClipboardCheck className="h-5 w-5" />
            Clearances Checklist
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        </CardContent>
      </Card>
    )
  }

  // Empty state (no clearances assigned yet)
  if (clearances.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <ClipboardCheck className="h-5 w-5" />
            Clearances Checklist
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-4">
            No clearances assigned yet.
          </p>
        </CardContent>
      </Card>
    )
  }

  const { completed, total, percentage } = progressSummary
  const allClearancesCompleted = completed === total && total > 0
  const permitAlreadyIssued = existingPermit !== null

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <ClipboardCheck className="h-5 w-5" />
            Clearances Checklist
          </CardTitle>
          <CardDescription>Track department clearance completion</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Progress</span>
              <span className="font-medium">
                {completed}/{total} completed
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-green-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>

          {/* Clearance List */}
          <div className="space-y-3">
            {clearances.map((clearance: NonNullable<typeof clearances>[number]) => {
              const IconComponent = clearance.clearanceType?.icon
                ? DEPARTMENT_ICONS[clearance.clearanceType.icon] || ClipboardCheck
                : ClipboardCheck

              return (
                <div
                  key={clearance._id}
                  className={`flex items-start gap-3 p-3 rounded-lg border transition-colors ${
                    permitAlreadyIssued ? "opacity-75" : "hover:bg-muted/50"
                  }`}
                >
                  <Checkbox
                    id={clearance._id}
                    checked={clearance.isCompleted}
                    onCheckedChange={() => handleToggle(clearance._id)}
                    disabled={permitAlreadyIssued}
                    className="mt-0.5"
                  />
                  <div className="flex-1 min-w-0">
                    <Label
                      htmlFor={clearance._id}
                      className={`flex items-center gap-2 ${permitAlreadyIssued ? "cursor-default" : "cursor-pointer"}`}
                    >
                      <IconComponent className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                      <span
                        className={
                          clearance.isCompleted
                            ? "line-through text-muted-foreground"
                            : ""
                        }
                      >
                        {clearance.displayCertificateName}
                      </span>
                    </Label>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {clearance.displayName}
                    </p>
                    {clearance.isCompleted && clearance.completedAt && (
                      <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                        <CheckCircle2 className="h-3 w-3" />
                        Completed{" "}
                        {new Date(clearance.completedAt).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                </div>
              )
            })}
          </div>

          {/* Completion Summary */}
          {allClearancesCompleted && (
            <div className="flex items-center gap-2 p-3 bg-green-50 rounded-lg text-green-700 text-sm">
              <CheckCircle2 className="h-4 w-4" />
              All clearances completed!
            </div>
          )}

          {/* Issue/View Business Permit Button - Always visible */}
          {permitAlreadyIssued ? (
            // Show "View Business Permit" if already issued - redirect to permit page
            <Button
              onClick={() => router.push(`/dashboard/permits/${existingPermit._id}`)}
              className="w-full"
              variant="default"
            >
              <Award className="mr-2 h-4 w-4" />
              View Business Permit
            </Button>
          ) : (
            // Show "Issue Business Permit" - disabled until clearances complete AND user has permission
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="w-full">
                    <Button
                      onClick={() => setShowConfirmDialog(true)}
                      className="w-full"
                      variant="default"
                      disabled={!allClearancesCompleted || !canCreatePermit || permissionsLoading}
                    >
                      <Award className="mr-2 h-4 w-4" />
                      Issue Business Permit
                    </Button>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  {!canCreatePermit && !permissionsLoading ? (
                    <p>You don't have permission to issue permits</p>
                  ) : !allClearancesCompleted ? (
                    <p>All clearances must be completed before issuing permit</p>
                  ) : (
                    <p>Issue business permit for this application</p>
                  )}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </CardContent>
      </Card>

      {/* Issue Permit Dialog */}
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Issue Business Permit</DialogTitle>
            <DialogDescription>
              Issue a Business Permit for{" "}
              <span className="font-semibold">{businessName}</span>.
              You can customize the permit number below.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Permit Number Input */}
            <div className="space-y-2">
              <Label htmlFor="permit-number">Permit Number</Label>
              <Input
                id="permit-number"
                value={customPermitNumber}
                onChange={(e) => {
                  setCustomPermitNumber(e.target.value)
                  if (!e.target.value.trim()) {
                    setPermitNumberError("Permit number is required")
                  }
                }}
                placeholder="e.g., BP-2026-00001"
                className={permitNumberError ? "border-destructive" : ""}
              />
              {permitNumberError && (
                <p className="text-sm text-destructive flex items-center gap-1">
                  <AlertCircle className="h-3 w-3" />
                  {permitNumberError}
                </p>
              )}
              {customPermitNumber.trim() && !permitNumberError && permitNumberCheck?.available && (
                <p className="text-sm text-green-600 flex items-center gap-1">
                  <CheckCircle2 className="h-3 w-3" />
                  Permit number is available
                </p>
              )}
            </div>

            {/* Summary */}
            <div className="text-sm text-muted-foreground space-y-1">
              <p>This action will:</p>
              <ul className="list-disc list-inside space-y-1 ml-1">
                <li>Create a permanent permit record</li>
                <li>Set validity based on platform settings</li>
                <li>Keep application in Released status</li>
              </ul>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowConfirmDialog(false)}
              disabled={isIssuing}
            >
              Cancel
            </Button>
            <Button
              onClick={handleIssuePermit}
              disabled={isIssuing || !customPermitNumber.trim() || !!permitNumberError}
            >
              {isIssuing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Issuing...
                </>
              ) : (
                "Issue Permit"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
