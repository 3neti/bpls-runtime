"use client"

import { usePathname } from "next/navigation"
import { ChevronRight, Home } from "lucide-react"
import Link from "next/link"
import { getClearanceByDepartmentSlug } from "@/lib/data/clearances"

// Route mapping for breadcrumb labels
const routeMap: Record<string, string> = {
  "/dashboard": "Dashboard",
  "/dashboard/user-management": "User Management",
  "/dashboard/user-management/roles": "Role Management",
  "/dashboard/permit-applications": "Permit Applications",
  "/dashboard/permit-applications/new": "New Application",
  "/dashboard/permit-applications/drafts": "Drafts",
  "/dashboard/permit-applications/released": "Releasing",
  "/dashboard/permit-applications/assessment": "Assessment",
  "/dashboard/permit-applications/payment": "Payment",
  "/dashboard/permits": "Permits",
  "/dashboard/payments-billing": "Payments & Billing",
  "/dashboard/taxes-and-fees": "Taxes & Fees",
  "/dashboard/clearances": "Clearance Management",
  "/dashboard/activity": "Activity Logs",
  "/dashboard/businesses": "Businesses",
  "/dashboard/businesses/new": "New Business",
  "/dashboard/business-owners": "Business Owners",
  "/dashboard/business-owners/new": "New Business Owner",
  "/dashboard/billing-groups": "Billing Groups",
  "/dashboard/reports": "Reports",
  "/dashboard/reports/new": "New Report",
  "/dashboard/locations": "Locations",
  "/dashboard/settings": "Settings",
  "/dashboard/settings/platform-configuration": "Platform Configuration",
  "/dashboard/settings/municipality": "Municipality",
  "/dashboard/settings/officials": "Government Officials",
  "/dashboard/settings/branding": "Branding",
  "/dashboard/settings/receipting": "Receipting",
  // Clearance routes (departments/* - backward compatible routes)
  "/departments": "Clearances",
  // Dynamic clearance routes will be added in buildBreadcrumbs
}

// Parent route mapping for proper hierarchy
const parentRoutes: Record<string, string> = {
  "/dashboard/user-management": "/dashboard",
  "/dashboard/user-management/roles": "/dashboard/user-management",
  "/dashboard/permit-applications": "/dashboard",
  "/dashboard/permit-applications/new": "/dashboard/permit-applications",
  "/dashboard/permit-applications/drafts": "/dashboard/permit-applications",
  "/dashboard/permit-applications/released": "/dashboard/permit-applications",
  "/dashboard/permit-applications/assessment": "/dashboard/permit-applications",
  "/dashboard/permit-applications/payment": "/dashboard/permit-applications",
  "/dashboard/permits": "/dashboard",
  "/dashboard/payments-billing": "/dashboard",
  "/dashboard/taxes-and-fees": "/dashboard",
  "/dashboard/clearances": "/dashboard",
  "/dashboard/activity": "/dashboard",
  "/dashboard/businesses": "/dashboard",
  "/dashboard/businesses/new": "/dashboard/businesses",
  "/dashboard/business-owners": "/dashboard",
  "/dashboard/business-owners/new": "/dashboard/business-owners",
  "/dashboard/billing-groups": "/dashboard",
  "/dashboard/reports": "/dashboard",
  "/dashboard/reports/new": "/dashboard/reports",
  "/dashboard/locations": "/dashboard",
  "/dashboard/settings": "/dashboard",
  "/dashboard/settings/platform-configuration": "/dashboard/settings",
  "/dashboard/settings/municipality": "/dashboard/settings",
  "/dashboard/settings/officials": "/dashboard/settings",
  "/dashboard/settings/branding": "/dashboard/settings",
  "/dashboard/settings/receipting": "/dashboard/settings",
  // Clearance routes parent relationships
  "/departments": "/dashboard/clearances",
  // Dynamic clearance routes will be added in buildBreadcrumbs
}

export function BreadcrumbNav() {
  const pathname = usePathname()

  // Build breadcrumb path
  const buildBreadcrumbs = (currentPath: string): Array<{ label: string; href: string; isLast: boolean }> => {
    const breadcrumbs: Array<{ label: string; href: string; isLast: boolean }> = []

    const processedPath = currentPath

    // Handle clearance routes (departments/[department])
    if (currentPath.startsWith("/departments/") && currentPath !== "/departments") {
      const segments = currentPath.split("/")
      const departmentSlug = segments[2] // Get department slug from /departments/[slug]

      // Get clearance config by department slug (clearance-first approach)
      const clearanceConfig = getClearanceByDepartmentSlug(departmentSlug)

      if (clearanceConfig) {
        const departmentPath = `/departments/${departmentSlug}`

        // Set up breadcrumb for main department page
        routeMap[departmentPath] = clearanceConfig.certificateName
        parentRoutes[departmentPath] = "/dashboard/clearances"

        // Handle clearance review detail pages (e.g., /departments/sanitary/review/[id])
        if (segments.length > 3) {
          if (segments[3] === "review" && segments.length > 4) {
            const reviewId = segments[4]
            const reviewPath = `/departments/${departmentSlug}/review/${reviewId}`

            routeMap[reviewPath] = `Application ${reviewId}`
            parentRoutes[reviewPath] = departmentPath
          } else if (segments[3] === "fees") {
            // Handle department fees page (e.g., /departments/sanitary/fees)
            const feesPath = `/departments/${departmentSlug}/fees`

            routeMap[feesPath] = "Fee Library"
            parentRoutes[feesPath] = departmentPath
          }
        }
      }
    }
    // Handle Taxes & Fees detail pages
    else if (
      currentPath.startsWith("/dashboard/taxes-and-fees/") &&
      currentPath !== "/dashboard/taxes-and-fees"
    ) {
      const segments = currentPath.split("/")
      const businessNatureId = segments[segments.length - 1]

      // Mock data to get business nature name (in real app, this would come from API/context)
      const businessNatureData = [
        { id: "BN001", name: "Retail Trade" },
        { id: "BN002", name: "Food Service" },
        { id: "BN003", name: "Manufacturing" },
        { id: "BN004", name: "Professional Services" },
        { id: "BN005", name: "Construction" },
      ]

      const businessNature = businessNatureData.find((bn) => bn.id === businessNatureId)
      const businessNatureName = businessNature ? businessNature.name : businessNatureId

      routeMap[currentPath] = businessNatureName
      parentRoutes[currentPath] = "/dashboard/taxes-and-fees"
    }
    // Handle Business detail pages (exclude /new route)
    else if (
      currentPath.startsWith("/dashboard/businesses/") &&
      currentPath !== "/dashboard/businesses" &&
      currentPath !== "/dashboard/businesses/new"
    ) {
      routeMap[currentPath] = `Business Details`
      parentRoutes[currentPath] = "/dashboard/businesses"
    }
    // Handle Business Owner detail pages (exclude /new route)
    else if (
      currentPath.startsWith("/dashboard/business-owners/") &&
      currentPath !== "/dashboard/business-owners" &&
      currentPath !== "/dashboard/business-owners/new"
    ) {
      routeMap[currentPath] = `Owner Details`
      parentRoutes[currentPath] = "/dashboard/business-owners"
    }
    // Handle Released Permit Application detail pages
    else if (
      currentPath.startsWith("/dashboard/permit-applications/released/") &&
      currentPath !== "/dashboard/permit-applications/released"
    ) {
      const segments = currentPath.split("/")
      const applicationId = segments[segments.length - 1]

      routeMap[currentPath] = `Application ${applicationId}`
      parentRoutes[currentPath] = "/dashboard/permit-applications/released"
    }
    // Handle Permit Application Assessment detail pages
    else if (
      currentPath.startsWith("/dashboard/permit-applications/assessment/") &&
      currentPath !== "/dashboard/permit-applications/assessment"
    ) {
      const segments = currentPath.split("/")
      const assessmentId = segments[segments.length - 1]

      routeMap[currentPath] = `Assessment ${assessmentId}`
      parentRoutes[currentPath] = "/dashboard/permit-applications/assessment"
    }
    // Handle Permit Application Payment detail pages
    else if (
      currentPath.startsWith("/dashboard/permit-applications/payment/") &&
      currentPath !== "/dashboard/permit-applications/payment"
    ) {
      const segments = currentPath.split("/")
      const paymentId = segments[segments.length - 1]

      routeMap[currentPath] = `Payment ${paymentId}`
      parentRoutes[currentPath] = "/dashboard/permit-applications/payment"
    }
    // Handle Billing Groups detail pages
    else if (
      currentPath.startsWith("/dashboard/billing-groups/") &&
      currentPath !== "/dashboard/billing-groups"
    ) {
      routeMap[currentPath] = "Details"
      parentRoutes[currentPath] = "/dashboard/billing-groups"
    }
    // Handle Report detail pages (exclude /new route)
    else if (
      currentPath.startsWith("/dashboard/reports/") &&
      currentPath !== "/dashboard/reports" &&
      currentPath !== "/dashboard/reports/new"
    ) {
      routeMap[currentPath] = "Report Details"
      parentRoutes[currentPath] = "/dashboard/reports"
    }
    // Handle Permit detail pages
    else if (
      currentPath.startsWith("/dashboard/permits/") &&
      currentPath !== "/dashboard/permits"
    ) {
      routeMap[currentPath] = "Permit Details"
      parentRoutes[currentPath] = "/dashboard/permits"
    }

    // Build path hierarchy
    const paths: string[] = []
    let path = processedPath

    while (path && path !== "/") {
      paths.unshift(path)
      path = parentRoutes[path] || ""
    }

    // Convert to breadcrumb objects
    paths.forEach((pathItem, index) => {
      const label = routeMap[pathItem] || pathItem.split("/").pop() || ""
      breadcrumbs.push({
        label,
        href: pathItem,
        isLast: index === paths.length - 1,
      })
    })

    return breadcrumbs
  }

  const breadcrumbs = buildBreadcrumbs(pathname)

  if (breadcrumbs.length <= 1) {
    return null // Don't show breadcrumbs for single level
  }

  return (
    <nav className="flex items-center space-x-1 text-sm text-muted-foreground whitespace-nowrap overflow-hidden">
      <Home className="h-4 w-4 shrink-0" />
      {breadcrumbs.map((crumb) => (
        <div key={crumb.href} className="flex items-center space-x-1 min-w-0">
          <ChevronRight className="h-4 w-4 shrink-0" />
          {crumb.isLast ? (
            <span className="font-medium text-foreground truncate max-w-[200px]">{crumb.label}</span>
          ) : (
            <Link href={crumb.href} className="hover:text-foreground transition-colors truncate max-w-[150px]">
              {crumb.label}
            </Link>
          )}
        </div>
      ))}
    </nav>
  )
}
