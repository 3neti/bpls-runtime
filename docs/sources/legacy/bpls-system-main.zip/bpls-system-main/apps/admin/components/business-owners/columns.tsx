"use client"

import { useState } from "react"
import { ColumnDef } from "@tanstack/react-table"
import { ArrowUpDown, Ban, CheckCircle2, Lock, Trash2 } from "lucide-react"
import { useMutation, useQuery } from "convex/react"

import { Button } from "@repo/ui/components/button"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import { Checkbox } from "@repo/ui/components/checkbox"
import { Avatar, AvatarFallback, AvatarImage } from "@repo/ui/components/avatar"
import { Badge } from "@repo/ui/components/badge"
import { BlacklistDialog } from "@/components/blacklist-dialog"
import { useToast } from "@/hooks/use-toast"
import { usePermissions } from "@/hooks/use-permissions"

import { api } from "@repo/backend/convex/_generated/api"
import type { Doc, Id } from "@repo/backend/convex/_generated/dataModel"
import { formatDate, getInitials } from "@/lib/utils/formatting"

type BusinessOwner = Doc<"business_owners">

// Component for displaying location hierarchy
function LocationCell({
  provinceId,
  cityId,
  barangayId
}: {
  provinceId?: Id<"provinces">
  cityId?: Id<"cities">
  barangayId?: Id<"barangays">
}) {
  const locations = useQuery(
    api.locations.getLocationHierarchy,
    provinceId || cityId || barangayId
      ? { provinceId, cityId, barangayId }
      : "skip"
  )

  if (!locations) {
    return <span className="text-sm text-muted-foreground">-</span>
  }

  const parts = [
    locations.barangay?.name,
    locations.city?.name,
    locations.province?.name,
  ].filter(Boolean)

  if (parts.length === 0) {
    return <span className="text-sm text-muted-foreground">-</span>
  }

  return (
    <div className="text-sm max-w-[200px]">
      <div className="truncate">{parts.join(", ")}</div>
    </div>
  )
}

// Separate component for the actions cell to properly use hooks
function BusinessOwnerActionsCell({ owner, onDelete }: { owner: BusinessOwner; onDelete?: (ownerId: string) => void }) {
  const [blacklistDialogOpen, setBlacklistDialogOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()
  const { canUpdate, canDelete, isLoading: permissionsLoading } = usePermissions()
  const canModifyOwner = canUpdate("business_owners")
  const canDeleteOwner = canDelete("business_owners")

  const blacklistMutation = useMutation(api.businessOwners.blacklist)
  const unblacklistMutation = useMutation(api.businessOwners.unblacklist)

  const handleBlacklistConfirm = async (reason?: string) => {
    if (!canModifyOwner) {
      toast({
        title: "Error",
        description: "You don't have permission to modify business owners",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      if (owner.isBlacklisted) {
        // Remove blacklist
        await unblacklistMutation({
          ownerId: owner._id,
        })
        toast({
          title: "Success",
          description: "Business owner has been removed from blacklist",
        })
      } else {
        // Add to blacklist
        if (!reason) {
          toast({
            title: "Error",
            description: "Reason is required for blacklisting",
            variant: "destructive",
          })
          setIsLoading(false)
          return
        }
        // blacklistedBy is auto-filled by backend from authenticated user
        await blacklistMutation({
          ownerId: owner._id,
          reason,
        })
        toast({
          title: "Success",
          description: "Business owner has been blacklisted",
        })
      }
      setBlacklistDialogOpen(false)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update blacklist status",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const fullName = `${owner.firstName} ${owner.middleName ? owner.middleName + ' ' : ''}${owner.lastName}`

  return (
    <div onClick={(e) => e.stopPropagation()} className="flex items-center gap-1">
      <TooltipProvider delayDuration={300}>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="inline-block">
              <Button
                variant="ghost"
                size="icon"
                className={`h-8 w-8 ${owner.isBlacklisted ? "" : "text-destructive hover:text-destructive"}`}
                onClick={(e) => {
                  e.stopPropagation()
                  setBlacklistDialogOpen(true)
                }}
                disabled={!canModifyOwner || isLoading || permissionsLoading}
              >
                {owner.isBlacklisted ? (
                  <CheckCircle2 className="h-4 w-4" />
                ) : (
                  <Ban className="h-4 w-4" />
                )}
              </Button>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            {!canModifyOwner && !permissionsLoading ? (
              <div className="flex items-center gap-2">
                <Lock className="h-4 w-4" />
                <p>You don't have permission to modify business owners</p>
              </div>
            ) : isLoading ? (
              <p>Processing...</p>
            ) : permissionsLoading ? (
              <p>Loading permissions...</p>
            ) : (
              <p>{owner.isBlacklisted ? "Remove Blacklist" : "Blacklist Owner"}</p>
            )}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <BlacklistDialog
        open={blacklistDialogOpen}
        onOpenChange={setBlacklistDialogOpen}
        entityType="business-owner"
        entityName={fullName}
        isCurrentlyBlacklisted={owner.isBlacklisted ?? false}
        onConfirm={handleBlacklistConfirm}
        onCancel={() => setBlacklistDialogOpen(false)}
      />

      {/* Delete button */}
      {onDelete && canDeleteOwner && (
        <TooltipProvider delayDuration={300}>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="inline-block">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                  onClick={(e) => {
                    e.stopPropagation()
                    onDelete(owner._id)
                  }}
                  disabled={permissionsLoading}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>Delete owner</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}
    </div>
  )
}

interface BusinessOwnerColumnsProps {
  onDelete?: (ownerId: string) => void
}

export const createBusinessOwnerColumns = (props?: BusinessOwnerColumnsProps): ColumnDef<BusinessOwner>[] => [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && "indeterminate")
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    id: "avatar",
    header: "",
    cell: ({ row }) => {
      const owner = row.original
      return (
        <Avatar className="h-10 w-10">
          <AvatarImage src={owner.avatar || "/placeholder.svg"} alt={`${owner.firstName} ${owner.lastName}`} />
          <AvatarFallback>{getInitials(owner.firstName, owner.lastName)}</AvatarFallback>
        </Avatar>
      )
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "fullName",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Full Name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const owner = row.original
      const fullName = `${owner.firstName} ${owner.middleName ? owner.middleName + ' ' : ''}${owner.lastName}`
      return (
        <div>
          <div className="font-medium">{fullName}</div>
        </div>
      )
    },
    sortingFn: (rowA, rowB) => {
      const nameA = `${rowA.original.firstName} ${rowA.original.lastName}`.toLowerCase()
      const nameB = `${rowB.original.firstName} ${rowB.original.lastName}`.toLowerCase()
      return nameA.localeCompare(nameB)
    },
  },
  {
    accessorKey: "ownerType",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Owner Type
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const ownerType = row.getValue("ownerType") as string
      return (
        <Badge variant={ownerType === "Single" ? "default" : "secondary"}>
          {ownerType}
        </Badge>
      )
    },
  },
  {
    accessorKey: "groupName",
    header: "Group Name",
    cell: ({ row }) => {
      const groupName = row.getValue("groupName") as string | undefined
      return <span className="text-sm">{groupName || "-"}</span>
    },
  },
  {
    accessorKey: "email",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Email
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      return <span className="text-sm">{row.getValue("email")}</span>
    },
  },
  {
    accessorKey: "mobile",
    header: "Mobile",
    cell: ({ row }) => {
      return <span className="text-sm">{row.getValue("mobile")}</span>
    },
  },
  {
    accessorKey: "tin",
    header: "TIN",
    cell: ({ row }) => {
      const tin = row.getValue("tin") as string | undefined
      return <span className="font-mono text-sm">{tin || "-"}</span>
    },
  },
  {
    accessorKey: "birthDate",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Birth Date
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const birthDate = row.getValue("birthDate") as string
      return <span className="text-sm">{formatDate(birthDate, "short")}</span>
    },
  },
  {
    accessorKey: "civilStatus",
    header: "Civil Status",
    cell: ({ row }) => {
      const civilStatus = row.getValue("civilStatus") as string
      const variantMap: Record<string, "default" | "outline" | "secondary"> = {
        single: "outline",
        married: "default",
        divorced: "secondary",
        widowed: "outline",
      }
      return (
        <Badge variant={variantMap[civilStatus.toLowerCase()] || "outline"} className="capitalize">
          {civilStatus}
        </Badge>
      )
    },
  },
  {
    accessorKey: "gender",
    header: "Gender",
    cell: ({ row }) => {
      const gender = row.getValue("gender") as string
      return (
        <Badge variant={gender.toLowerCase() === "male" ? "default" : "secondary"} className="capitalize">
          {gender}
        </Badge>
      )
    },
  },
  {
    accessorKey: "citizenship",
    header: "Citizenship",
    cell: ({ row }) => {
      return <span className="text-sm">{row.getValue("citizenship")}</span>
    },
  },
  {
    id: "address",
    header: "Street Address",
    cell: ({ row }) => {
      const owner = row.original
      return (
        <div className="text-sm max-w-[200px]">
          <div className="truncate">{owner.address || "-"}</div>
        </div>
      )
    },
  },
  {
    id: "location",
    header: "Location",
    cell: ({ row }) => {
      const owner = row.original
      return (
        <LocationCell
          provinceId={owner.provinceId}
          cityId={owner.cityId}
          barangayId={owner.barangayId}
        />
      )
    },
  },
  {
    id: "status",
    header: "Status",
    cell: ({ row }) => {
      const owner = row.original

      if (owner.isBlacklisted) {
        return (
          <Badge variant="destructive" className="gap-1">
            <Ban className="h-3 w-3" />
            Blacklisted
          </Badge>
        )
      }

      return (
        <Badge className="bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300">
          Active
        </Badge>
      )
    },
  },
  {
    id: "blacklistReason",
    header: "Blacklist Reason",
    cell: ({ row }) => {
      const owner = row.original
      if (!owner.isBlacklisted || !owner.blacklistReason) {
        return <span className="text-sm text-muted-foreground">-</span>
      }
      return (
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="text-sm max-w-[150px] truncate cursor-help">
              {owner.blacklistReason}
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p className="max-w-xs">{owner.blacklistReason}</p>
          </TooltipContent>
        </Tooltip>
      )
    },
  },
  {
    id: "blacklistedAt",
    header: "Blacklisted Date",
    cell: ({ row }) => {
      const owner = row.original
      if (!owner.blacklistedAt) {
        return <span className="text-sm text-muted-foreground">-</span>
      }
      return <span className="text-sm">{formatDate(owner.blacklistedAt, "short")}</span>
    },
  },
  {
    id: "blacklistedBy",
    header: "Blacklisted By",
    cell: ({ row }) => {
      const owner = row.original
      return <span className="text-sm">{owner.blacklistedBy || "-"}</span>
    },
  },
  {
    id: "actions",
    header: "Actions",
    cell: ({ row }) => {
      const owner = row.original
      return <BusinessOwnerActionsCell owner={owner} onDelete={props?.onDelete} />
    },
    enableSorting: false,
    enableHiding: false,
  },
]

// Backward compatibility - default columns without delete handler
export const columns = createBusinessOwnerColumns()
