"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { useQuery, useMutation } from "convex/react"
import { Loader2, Camera } from "lucide-react"

import { api } from "@repo/backend/convex/_generated/api"
import { usePermissions } from "@/hooks/use-permissions"
import type { Doc, Id } from "@repo/backend/convex/_generated/dataModel"
import { Button } from "@repo/ui/components/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { Input } from "@repo/ui/components/input"
import { Label } from "@repo/ui/components/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select"
import { Avatar, AvatarFallback, AvatarImage } from "@repo/ui/components/avatar"
import { DepartmentCombobox } from "@/components/department-combobox"
import { useToast } from "@/hooks/use-toast"
import { getInitials } from "@/lib/utils/formatting"

interface EditUserDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  user: Doc<"users">
  onEditUser: (userData: {
    firstName?: string
    lastName?: string
    phone?: string
    role?: string
    department?: string
    profilePhoto?: string
  }) => Promise<void>
  isSubmitting?: boolean
}

export function EditUserDialog({
  open,
  onOpenChange,
  user,
  onEditUser,
  isSubmitting = false,
}: EditUserDialogProps) {
  const { toast } = useToast()
  const { canRead, isLoading: permissionsLoading } = usePermissions()
  const canReadRoles = canRead("roles")

  // Only query roles if user has permission - skip otherwise to avoid error
  const roles = useQuery(
    api.permissions.listRoles,
    canReadRoles ? {} : "skip"
  )
  const generateUploadUrl = useMutation(api.users.generateUploadUrl)
  const saveProfilePhoto = useMutation(api.users.saveProfilePhoto)

  const fileInputRef = useRef<HTMLInputElement>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    firstName: user.firstName,
    lastName: user.lastName,
    phone: user.phone || "",
    role: user.role,
    department: user.department,
  })

  // Reset form when user changes
  useEffect(() => {
    setFormData({
      firstName: user.firstName,
      lastName: user.lastName,
      phone: user.phone || "",
      role: user.role,
      department: user.department,
    })
    setPreviewUrl(null)
  }, [user])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await onEditUser({
      ...formData,
      phone: formData.phone || undefined,
    })
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file.",
        variant: "destructive",
      })
      return
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image under 5MB.",
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)
    try {
      // Show preview
      const preview = URL.createObjectURL(file)
      setPreviewUrl(preview)

      // Upload to Convex storage
      const uploadUrl = await generateUploadUrl()
      const response = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      })

      if (!response.ok) {
        throw new Error("Upload failed")
      }

      const { storageId } = await response.json()

      // Save to user profile
      await saveProfilePhoto({
        userId: user._id as Id<"users">,
        storageId,
      })

      toast({
        title: "Photo uploaded",
        description: "Profile photo has been updated.",
      })
    } catch (error) {
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to upload photo",
        variant: "destructive",
      })
      setPreviewUrl(null)
    } finally {
      setIsUploading(false)
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    }
  }

  const currentPhotoUrl = previewUrl || user.profilePhoto

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Edit User</DialogTitle>
          <DialogDescription>
            Update user information. Email cannot be changed.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            {/* Profile Photo Section */}
            <div className="flex flex-col items-center gap-3 mb-2">
              <div className="relative">
                <Avatar className="h-20 w-20 border-2 border-border">
                  <AvatarImage src={currentPhotoUrl || undefined} alt={`${formData.firstName} ${formData.lastName}`} />
                  <AvatarFallback className="text-xl">
                    {getInitials(formData.firstName, formData.lastName)}
                  </AvatarFallback>
                </Avatar>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileSelect}
                  className="hidden"
                  disabled={isUploading || isSubmitting}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  className="absolute -bottom-1 -right-1 h-8 w-8 rounded-full bg-background"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading || isSubmitting}
                >
                  {isUploading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Camera className="h-4 w-4" />
                  )}
                </Button>
              </div>
              <p className="text-sm text-muted-foreground">{user.email}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-firstName">First Name</Label>
                <Input
                  id="edit-firstName"
                  value={formData.firstName}
                  onChange={(e) => handleInputChange("firstName", e.target.value)}
                  required
                  disabled={isSubmitting}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-lastName">Last Name</Label>
                <Input
                  id="edit-lastName"
                  value={formData.lastName}
                  onChange={(e) => handleInputChange("lastName", e.target.value)}
                  required
                  disabled={isSubmitting}
                />
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-phone">Phone Number</Label>
              <Input
                id="edit-phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => handleInputChange("phone", e.target.value)}
                placeholder="+63 XXX XXX XXXX"
                disabled={isSubmitting}
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-role">Role</Label>
              <Select
                value={formData.role}
                onValueChange={(value) => handleInputChange("role", value)}
                disabled={isSubmitting || roles === undefined || !canReadRoles}
              >
                <SelectTrigger>
                  <SelectValue placeholder={
                    !canReadRoles && !permissionsLoading
                      ? "No permission to view roles"
                      : roles === undefined
                        ? "Loading roles..."
                        : "Select a role"
                  } />
                </SelectTrigger>
                <SelectContent>
                  {roles?.map((role: NonNullable<typeof roles>[number]) => (
                    <SelectItem key={role._id} value={role.name}>
                      {role.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-department">Department</Label>
              <DepartmentCombobox
                value={formData.department}
                onChange={(value) => handleInputChange("department", value)}
                disabled={isSubmitting}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting || isUploading}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Changes"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
