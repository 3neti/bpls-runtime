"use client";

import { useState, useEffect, useCallback, useMemo } from "react";
import { useQuery, useMutation } from "convex/react";
import { Save, Eye, EyeOff, RefreshCw, Loader2 } from "lucide-react";
import dynamic from "next/dynamic";

import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Textarea } from "@repo/ui/components/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@repo/ui/components/tabs";
import { Skeleton } from "@repo/ui/components/skeleton";
import { Badge } from "@repo/ui/components/badge";
import { Separator } from "@repo/ui/components/separator";
import { Switch } from "@repo/ui/components/switch";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import {
  getAvailableMacros,
  getSampleReceiptData,
  parseTemplate,
  validateTemplate,
} from "@/lib/utils/receipt-template-renderer";
import { MacroPicker } from "./macro-picker";

// Dynamically import PDF components to avoid SSR issues
const LayoutPreview = dynamic(() => import("./layout-preview"), {
  ssr: false,
  loading: () => <Skeleton className="h-full w-full" />,
});

interface ReceiptLayoutEditorProps {
  layoutId: Id<"receipt_layouts">;
  onSave: () => void;
  onClose: () => void;
}

export function ReceiptLayoutEditor({
  layoutId,
  onSave,
  onClose,
}: ReceiptLayoutEditorProps) {
  const layout = useQuery(api.receiptLayouts.getById, { id: layoutId });
  const platformSettings = useQuery(api.platformSettings.get);
  const updateLayout = useMutation(api.receiptLayouts.update);

  // Form state
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [paperSize, setPaperSize] = useState<"A4" | "Letter" | "Half-Letter">("A4");
  const [orientation, setOrientation] = useState<"portrait" | "landscape">("portrait");
  const [marginTop, setMarginTop] = useState(10);
  const [marginRight, setMarginRight] = useState(10);
  const [marginBottom, setMarginBottom] = useState(10);
  const [marginLeft, setMarginLeft] = useState(10);
  const [fontSize, setFontSize] = useState(10);
  const [fontFamily, setFontFamily] = useState<"Helvetica" | "Times-Roman" | "Courier">("Helvetica");
  const [headerTemplate, setHeaderTemplate] = useState("");
  const [bodyTemplate, setBodyTemplate] = useState("");
  const [footerTemplate, setFooterTemplate] = useState("");
  const [hideZeroAmountFees, setHideZeroAmountFees] = useState(false);

  // UI state
  const [showPreview, setShowPreview] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const [activeTab, setActiveTab] = useState("header");

  // Cursor positions for macro insertion
  const [headerCursor, setHeaderCursor] = useState<number | null>(null);
  const [bodyCursor, setBodyCursor] = useState<number | null>(null);
  const [footerCursor, setFooterCursor] = useState<number | null>(null);

  // Debounced templates for preview (to avoid rapid re-renders)
  const [debouncedHeader, setDebouncedHeader] = useState("");
  const [debouncedBody, setDebouncedBody] = useState("");
  const [debouncedFooter, setDebouncedFooter] = useState("");

  // Debounce template updates for preview
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedHeader(headerTemplate);
      setDebouncedBody(bodyTemplate);
      setDebouncedFooter(footerTemplate);
    }, 300);
    return () => clearTimeout(timer);
  }, [headerTemplate, bodyTemplate, footerTemplate]);

  // Initialize form from layout data
  useEffect(() => {
    if (layout) {
      setName(layout.name);
      setDescription(layout.description || "");
      setPaperSize(layout.paperSize);
      setOrientation(layout.orientation);
      setMarginTop(layout.marginTop);
      setMarginRight(layout.marginRight);
      setMarginBottom(layout.marginBottom);
      setMarginLeft(layout.marginLeft);
      setFontSize(layout.fontSize);
      setFontFamily(layout.fontFamily);
      setHeaderTemplate(layout.headerTemplate);
      setBodyTemplate(layout.bodyTemplate);
      setFooterTemplate(layout.footerTemplate);
      setHideZeroAmountFees(layout.hideZeroAmountFees ?? false);
      setHasChanges(false);
    }
  }, [layout]);

  // Track changes
  const markChanged = useCallback(() => {
    setHasChanges(true);
  }, []);

  // Sample data for preview
  const sampleData = useMemo(() => {
    const data = getSampleReceiptData();
    // Add platform settings data
    if (platformSettings) {
      data.municipalityName = platformSettings.municipalityName || "Municipality";
      data.provinceName = platformSettings.provinceName || "Province";
      data.mayorName = platformSettings.mayorName || "Mayor";
      data.treasurerName = platformSettings.treasurerName || "Treasurer";
      data.fullAddress = platformSettings.fullAddress || "";
    }
    return data;
  }, [platformSettings]);

  // Validate templates
  const headerValidation = useMemo(
    () => validateTemplate(headerTemplate),
    [headerTemplate]
  );
  const bodyValidation = useMemo(
    () => validateTemplate(bodyTemplate),
    [bodyTemplate]
  );
  const footerValidation = useMemo(
    () => validateTemplate(footerTemplate),
    [footerTemplate]
  );

  // Handle save
  const handleSave = async () => {
    setIsSaving(true);
    try {
      await updateLayout({
        id: layoutId,
        name,
        description: description || undefined,
        paperSize,
        orientation,
        marginTop,
        marginRight,
        marginBottom,
        marginLeft,
        fontSize,
        fontFamily,
        headerTemplate,
        bodyTemplate,
        footerTemplate,
        hideZeroAmountFees,
      });
      setHasChanges(false);
      onSave();
    } catch (error) {
      console.error("Failed to save layout:", error);
    } finally {
      setIsSaving(false);
    }
  };

  // Insert macro at cursor position
  const insertMacro = (macro: string) => {
    const macroText = `{{${macro}}}`;

    if (activeTab === "header" && headerCursor !== null) {
      const before = headerTemplate.slice(0, headerCursor);
      const after = headerTemplate.slice(headerCursor);
      setHeaderTemplate(before + macroText + after);
      markChanged();
    } else if (activeTab === "body" && bodyCursor !== null) {
      const before = bodyTemplate.slice(0, bodyCursor);
      const after = bodyTemplate.slice(bodyCursor);
      setBodyTemplate(before + macroText + after);
      markChanged();
    } else if (activeTab === "footer" && footerCursor !== null) {
      const before = footerTemplate.slice(0, footerCursor);
      const after = footerTemplate.slice(footerCursor);
      setFooterTemplate(before + macroText + after);
      markChanged();
    } else {
      // If no cursor position, append to the active template
      if (activeTab === "header") {
        setHeaderTemplate((prev) => prev + macroText);
      } else if (activeTab === "body") {
        setBodyTemplate((prev) => prev + macroText);
      } else if (activeTab === "footer") {
        setFooterTemplate((prev) => prev + macroText);
      }
      markChanged();
    }
  };

  if (!layout) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center justify-between pb-4 border-b">
        <div className="flex items-center gap-4">
          <div className="space-y-1">
            <Input
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                markChanged();
              }}
              className="font-medium text-lg h-8 w-64"
              placeholder="Layout name"
            />
          </div>
          {hasChanges && (
            <Badge variant="outline" className="text-yellow-600">
              Unsaved changes
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowPreview(!showPreview)}
          >
            {showPreview ? (
              <>
                <EyeOff className="mr-2 h-4 w-4" />
                Hide Preview
              </>
            ) : (
              <>
                <Eye className="mr-2 h-4 w-4" />
                Show Preview
              </>
            )}
          </Button>
          <Button
            size="sm"
            onClick={handleSave}
            disabled={isSaving || !hasChanges}
          >
            {isSaving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Save
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-1 gap-4 pt-4 overflow-hidden">
        {/* Editor Panel */}
        <div className={`flex flex-col ${showPreview ? "w-1/2" : "w-full"} overflow-hidden`}>
          {/* Settings - Fixed height section */}
          <div className="flex-shrink-0 space-y-4 pr-4 pb-4">
              {/* Paper & Font Settings */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Paper Size</Label>
                  <Select
                    value={paperSize}
                    onValueChange={(value: "A4" | "Letter" | "Half-Letter") => {
                      setPaperSize(value);
                      markChanged();
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="A4">A4 (210 × 297 mm)</SelectItem>
                      <SelectItem value="Letter">Letter (8.5 × 11 in)</SelectItem>
                      <SelectItem value="Half-Letter">Half Letter (5.5 × 8.5 in)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Orientation</Label>
                  <Select
                    value={orientation}
                    onValueChange={(value: "portrait" | "landscape") => {
                      setOrientation(value);
                      markChanged();
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="portrait">Portrait</SelectItem>
                      <SelectItem value="landscape">Landscape</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Font Family</Label>
                  <Select
                    value={fontFamily}
                    onValueChange={(value: "Helvetica" | "Times-Roman" | "Courier") => {
                      setFontFamily(value);
                      markChanged();
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Helvetica">Helvetica (Sans-serif)</SelectItem>
                      <SelectItem value="Times-Roman">Times Roman (Serif)</SelectItem>
                      <SelectItem value="Courier">Courier (Monospace)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Font Size (pt)</Label>
                  <Input
                    type="number"
                    min={6}
                    max={24}
                    value={fontSize}
                    onChange={(e) => {
                      setFontSize(Number(e.target.value));
                      markChanged();
                    }}
                  />
                </div>
              </div>

              {/* Margins */}
              <div className="space-y-2">
                <Label>Margins (mm)</Label>
                <div className="grid grid-cols-4 gap-2">
                  <div className="space-y-1">
                    <span className="text-xs text-muted-foreground">Top</span>
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      value={marginTop}
                      onChange={(e) => {
                        setMarginTop(Number(e.target.value));
                        markChanged();
                      }}
                    />
                  </div>
                  <div className="space-y-1">
                    <span className="text-xs text-muted-foreground">Right</span>
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      value={marginRight}
                      onChange={(e) => {
                        setMarginRight(Number(e.target.value));
                        markChanged();
                      }}
                    />
                  </div>
                  <div className="space-y-1">
                    <span className="text-xs text-muted-foreground">Bottom</span>
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      value={marginBottom}
                      onChange={(e) => {
                        setMarginBottom(Number(e.target.value));
                        markChanged();
                      }}
                    />
                  </div>
                  <div className="space-y-1">
                    <span className="text-xs text-muted-foreground">Left</span>
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      value={marginLeft}
                      onChange={(e) => {
                        setMarginLeft(Number(e.target.value));
                        markChanged();
                      }}
                    />
                  </div>
                </div>
              </div>

              {/* Fees Table Behavior */}
              <div className="space-y-2">
                <Label>Fees Table Behavior</Label>
                <div className="flex items-start justify-between rounded-md border p-3">
                  <div className="space-y-0.5 pr-4">
                    <p className="text-sm font-medium">Hide zero-amount fees</p>
                    <p className="text-xs text-muted-foreground">
                      When printing, exclude fee rows from {"{{FEES_TABLE}}"} where the amount is 0.00.
                      The 11-row layout is preserved by expanding empty padding rows.
                    </p>
                  </div>
                  <Switch
                    checked={hideZeroAmountFees}
                    onCheckedChange={(checked) => {
                      setHideZeroAmountFees(checked);
                      markChanged();
                    }}
                  />
                </div>
              </div>

          </div>

          <Separator className="flex-shrink-0" />

          {/* Template Sections - Fills remaining space */}
          <div className="flex-1 flex flex-col min-h-0 pt-4 pr-4">
            <div className="flex items-center justify-between flex-shrink-0 mb-2">
              <Label>Template Sections</Label>
              <MacroPicker onSelect={insertMacro} />
            </div>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col min-h-0">
              <TabsList className="grid w-full grid-cols-3 flex-shrink-0">
                <TabsTrigger value="header">Header</TabsTrigger>
                <TabsTrigger value="body">Body</TabsTrigger>
                <TabsTrigger value="footer">Footer</TabsTrigger>
              </TabsList>
              <TabsContent value="header" className="flex-1 flex flex-col min-h-0 mt-2">
                <div className="flex-1 overflow-hidden rounded-md border">
                  <Textarea
                    value={headerTemplate}
                    onChange={(e) => {
                      setHeaderTemplate(e.target.value);
                      markChanged();
                    }}
                    onSelect={(e) => {
                      setHeaderCursor((e.target as HTMLTextAreaElement).selectionStart);
                    }}
                    placeholder="Enter header template..."
                    className="font-mono text-sm h-full w-full resize-none border-0 rounded-none [field-sizing:fixed]"
                  />
                </div>
                {headerValidation.warnings.length > 0 && (
                  <p className="text-xs text-yellow-600 mt-1 flex-shrink-0">
                    {headerValidation.warnings.join(", ")}
                  </p>
                )}
              </TabsContent>
              <TabsContent value="body" className="flex-1 flex flex-col min-h-0 mt-2">
                <div className="flex-1 overflow-hidden rounded-md border">
                  <Textarea
                    value={bodyTemplate}
                    onChange={(e) => {
                      setBodyTemplate(e.target.value);
                      markChanged();
                    }}
                    onSelect={(e) => {
                      setBodyCursor((e.target as HTMLTextAreaElement).selectionStart);
                    }}
                    placeholder="Enter body template (use {{FEES_TABLE}} for the fees table)..."
                    className="font-mono text-sm h-full w-full resize-none border-0 rounded-none [field-sizing:fixed]"
                  />
                </div>
                {bodyValidation.warnings.length > 0 && (
                  <p className="text-xs text-yellow-600 mt-1 flex-shrink-0">
                    {bodyValidation.warnings.join(", ")}
                  </p>
                )}
              </TabsContent>
              <TabsContent value="footer" className="flex-1 flex flex-col min-h-0 mt-2">
                <div className="flex-1 overflow-hidden rounded-md border">
                  <Textarea
                    value={footerTemplate}
                    onChange={(e) => {
                      setFooterTemplate(e.target.value);
                      markChanged();
                    }}
                    onSelect={(e) => {
                      setFooterCursor((e.target as HTMLTextAreaElement).selectionStart);
                    }}
                    placeholder="Enter footer template..."
                    className="font-mono text-sm h-full w-full resize-none border-0 rounded-none [field-sizing:fixed]"
                  />
                </div>
                {footerValidation.warnings.length > 0 && (
                  <p className="text-xs text-yellow-600 mt-1 flex-shrink-0">
                    {footerValidation.warnings.join(", ")}
                  </p>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Preview Panel */}
        {showPreview && (
          <div className="w-1/2 border rounded-lg overflow-hidden bg-muted/30">
            <div className="p-2 border-b bg-muted/50 flex items-center justify-between">
              <span className="text-sm font-medium">Preview (Sample Data)</span>
              <Badge variant="outline" className="text-xs">
                {paperSize} • {orientation}
              </Badge>
            </div>
            <div className="h-[calc(100%-40px)]">
              <LayoutPreview
                headerTemplate={debouncedHeader}
                bodyTemplate={debouncedBody}
                footerTemplate={debouncedFooter}
                paperSize={paperSize}
                orientation={orientation}
                marginTop={marginTop}
                marginRight={marginRight}
                marginBottom={marginBottom}
                marginLeft={marginLeft}
                fontSize={fontSize}
                fontFamily={fontFamily}
                hideZeroAmountFees={hideZeroAmountFees}
                data={sampleData}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
