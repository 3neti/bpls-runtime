"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";

type PermitApplicationType = "New" | "Renewal" | "Additional";

interface PermitApplicationTypeOption {
  value: PermitApplicationType;
  label: string;
  description: string;
}

const APPLICATION_TYPE_OPTIONS: PermitApplicationTypeOption[] = [
  {
    value: "New",
    label: "New",
    description: "First-time application for a new business permit",
  },
  {
    value: "Renewal",
    label: "Renewal",
    description: "Renewing an existing business permit",
  },
  {
    value: "Additional",
    label: "Additional",
    description: "Adding a new line of business to an existing permit",
  },
];

interface PermitTransactionTypeCardProps {
  /**
   * Current selected permit application type
   */
  value?: PermitApplicationType;
  /**
   * Callback when permit application type changes (only called when not readonly)
   */
  onChange?: (value: PermitApplicationType) => void;
  /**
   * Whether the component is in readonly/display mode
   */
  readonly?: boolean;
  /**
   * Whether the component is disabled
   * Shows a disabled state with explanation
   */
  disabled?: boolean;
  /**
   * Reason why the component is disabled (shown to user)
   */
  disabledReason?: string;
  /**
   * Custom title for the card
   */
  title?: string;
  /**
   * Custom description for the card
   */
  description?: string;
}

export function PermitTransactionTypeCard({
  value,
  onChange,
  readonly = false,
  disabled = false,
  disabledReason,
  title = "Permit Transaction Type",
  description = "Select the type of permit application",
}: PermitTransactionTypeCardProps) {
  const isInteractive = !readonly && !disabled;

  const handleSelect = (selectedValue: PermitApplicationType) => {
    if (isInteractive && onChange) {
      onChange(selectedValue);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>
          {readonly
            ? "Transaction type for this permit application"
            : disabled && disabledReason
              ? disabledReason
              : description}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-3">
          {APPLICATION_TYPE_OPTIONS.map((option) => {
            const isSelected = value === option.value;

            return (
              <div
                key={option.value}
                className={`flex items-center space-x-3 p-4 rounded-lg border-2 transition-colors ${
                  isInteractive ? "cursor-pointer" : ""
                } ${
                  isSelected
                    ? disabled
                      ? "border-primary/50 bg-primary/5 opacity-70"
                      : "border-primary bg-primary/5"
                    : readonly || disabled
                      ? "border-border opacity-50"
                      : "border-border hover:bg-accent/50"
                }`}
                onClick={() => handleSelect(option.value)}
                onKeyDown={(e) => {
                  if (isInteractive && (e.key === "Enter" || e.key === " ")) {
                    e.preventDefault();
                    handleSelect(option.value);
                  }
                }}
                role={isInteractive ? "radio" : "presentation"}
                aria-checked={isSelected}
                aria-disabled={disabled}
                tabIndex={isInteractive ? 0 : -1}
              >
                <div
                  className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                    isSelected
                      ? disabled
                        ? "border-primary/50"
                        : "border-primary"
                      : "border-muted-foreground"
                  }`}
                >
                  {isSelected && (
                    <div className={`w-2 h-2 rounded-full ${disabled ? "bg-primary/50" : "bg-primary"}`} />
                  )}
                </div>
                <div className="flex-1">
                  <div className="font-medium">{option.label}</div>
                  <div className="text-sm text-muted-foreground">{option.description}</div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
