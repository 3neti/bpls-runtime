"use client";

import { useState, useEffect } from "react";
import { Document, Page, Text, View, StyleSheet, PDFViewer } from "@react-pdf/renderer";
import {
  parseTemplate,
  formatCurrency,
  type ReceiptMacroData,
  type PaymentReceiptFee,
} from "@/lib/utils/receipt-template-renderer";

// Paper sizes in points (1 point = 1/72 inch)
const PAPER_SIZES = {
  A4: { width: 595.28, height: 841.89 },
  Letter: { width: 612, height: 792 },
  "Half-Letter": { width: 396, height: 612 },
};

// Fixed table configuration for consistent receipt formatting
const TABLE_FIXED_ROWS = 11;
const ROW_HEIGHT = 11; // points (fontSize 10 + marginBottom 1)

interface LayoutPreviewProps {
  headerTemplate: string;
  bodyTemplate: string;
  footerTemplate: string;
  paperSize: "A4" | "Letter" | "Half-Letter";
  orientation: "portrait" | "landscape";
  marginTop: number;
  marginRight: number;
  marginBottom: number;
  marginLeft: number;
  fontSize: number;
  fontFamily: "Helvetica" | "Times-Roman" | "Courier";
  hideZeroAmountFees?: boolean;
  data: ReceiptMacroData;
}

// Convert mm to points (1mm = 2.83465 points)
const mmToPoints = (mm: number) => mm * 2.83465;

// Inner document component that doesn't use hooks
function ReceiptDocument({
  headerTemplate,
  bodyTemplate,
  footerTemplate,
  paperSize,
  orientation,
  marginTop,
  marginRight,
  marginBottom,
  marginLeft,
  fontSize,
  fontFamily,
  hideZeroAmountFees,
  data,
}: LayoutPreviewProps) {
  // Get paper dimensions based on size and orientation
  const size = PAPER_SIZES[paperSize] || PAPER_SIZES.A4;
  const dimensions = orientation === "landscape"
    ? { width: size.height, height: size.width }
    : size;

  // Create styles
  const styles = StyleSheet.create({
    page: {
      paddingTop: mmToPoints(marginTop || 10),
      paddingRight: mmToPoints(marginRight || 10),
      paddingBottom: mmToPoints(marginBottom || 10),
      paddingLeft: mmToPoints(marginLeft || 10),
      fontSize: fontSize || 10,
      fontFamily: fontFamily || "Helvetica",
      backgroundColor: "#ffffff",
      color: "#000000",
    },
    section: {
      marginBottom: 10,
    },
    text: {
      marginBottom: 2,
    },
    header: {
      marginBottom: 15,
    },
    body: {
      flex: 1,
    },
    footer: {
      marginTop: 15,
    },
    feesTable: {
      marginVertical: 10,
      height: TABLE_FIXED_ROWS * (ROW_HEIGHT + 1), // Account for marginBottom in each row
    },
    feeRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      height: ROW_HEIGHT, // Fixed row height
      marginBottom: 1, // Minimal spacing (1pt)
    },
    feeName: {
      flex: 1,
    },
    feeAmount: {
      width: 80,
      textAlign: "right",
    },
    separator: {
      borderBottomWidth: 1,
      borderBottomColor: "#000000",
      marginVertical: 5,
    },
    emptyState: {
      color: "#999999",
      fontStyle: "italic",
    },
  });

  // Parse templates with data - wrap in try-catch for safety
  let parsedHeader = "";
  let parsedBody = "";
  let parsedFooter = "";

  try {
    parsedHeader = parseTemplate(headerTemplate || "", data);
    parsedBody = parseTemplate(bodyTemplate || "", data);
    parsedFooter = parseTemplate(footerTemplate || "", data);
  } catch (e) {
    console.error("Template parsing error:", e);
  }

  // Preserve whitespace by converting spaces to non-breaking spaces
  const preserveWhitespace = (text: string): string => {
    if (!text) return "";
    return text.replace(/ /g, "\u00A0");
  };

  // Static sample fees for preview - always available
  // Includes a zero-amount entry so the "Hide zero-amount fees" toggle has a
  // visible effect in the preview when enabled.
  const SAMPLE_FEES: PaymentReceiptFee[] = [
    { feeName: "Mayor's Permit", feeCategory: "Regulatory", amount: 2500.0 },
    { feeName: "Business Tax", feeCategory: "Tax", amount: 1500.0 },
    { feeName: "Sanitary Permit", feeCategory: "Regulatory", amount: 750.0 },
    { feeName: "Fire Safety Fee", feeCategory: "Safety", amount: 500.0 },
    { feeName: "Waived Inspection Fee", feeCategory: "Regulatory", amount: 0 },
  ];

  // Render fees table with fixed 11 rows - always use static sample data for preview
  const renderFeesTable = (_fees: PaymentReceiptFee[] | undefined) => {
    // Use static sample data; filter zero-amount rows when toggle is enabled.
    // Empty padding rows below absorb the gap so total stays at TABLE_FIXED_ROWS.
    const items = hideZeroAmountFees
      ? SAMPLE_FEES.filter((f) => f.amount !== 0)
      : SAMPLE_FEES;
    const surcharge = data.surcharge ?? 0;
    const penalty = data.penalty ?? 0;
    const extraRows = (surcharge > 0 ? 1 : 0) + (penalty > 0 ? 1 : 0);
    const totalItemRows = items.length + extraRows;
    const emptyRowsCount = Math.max(0, TABLE_FIXED_ROWS - totalItemRows);

    return (
      <View style={styles.feesTable}>
        {/* Render actual fee items */}
        {items.slice(0, TABLE_FIXED_ROWS).map((fee, index) => (
          <View key={index} style={styles.feeRow}>
            <Text style={styles.feeName}>{fee.feeName}</Text>
            <Text style={styles.feeAmount}>{formatCurrency(fee.amount)}</Text>
          </View>
        ))}
        {/* Render surcharge row if > 0 */}
        {surcharge > 0 && (
          <View style={styles.feeRow}>
            <Text style={styles.feeName}>Surcharge</Text>
            <Text style={styles.feeAmount}>{formatCurrency(surcharge)}</Text>
          </View>
        )}
        {/* Render penalty row if > 0 */}
        {penalty > 0 && (
          <View style={styles.feeRow}>
            <Text style={styles.feeName}>Interest</Text>
            <Text style={styles.feeAmount}>{formatCurrency(penalty)}</Text>
          </View>
        )}
        {/* Render empty rows to fill to 11 */}
        {Array.from({ length: emptyRowsCount }).map((_, index) => (
          <View key={`empty-${index}`} style={styles.feeRow}>
            <Text style={styles.feeName}>{"\u00A0"}</Text>
            <Text style={styles.feeAmount}>{"\u00A0"}</Text>
          </View>
        ))}
      </View>
    );
  };

  // Render lines of text
  const renderLines = (content: string) => {
    if (!content) return null;

    const lines = content.split("\n");
    return (
      <>
        {lines.map((line, index) => (
          <Text key={index} style={styles.text}>
            {preserveWhitespace(line) || "\u00A0"}
          </Text>
        ))}
      </>
    );
  };

  // Render text with line breaks and handle {{FEES_TABLE}}
  const renderTemplateContent = (content: string) => {
    if (!content) return null;

    // Split by FEES_TABLE marker - use regex for robust whitespace handling
    if (/\{\{\s*FEES_TABLE\s*\}\}/.test(content)) {
      const parts = content.split(/\{\{\s*FEES_TABLE\s*\}\}/);
      return (
        <>
          {parts[0] && renderLines(parts[0])}
          {renderFeesTable(data.fees)}
          {parts[1] && renderLines(parts[1])}
        </>
      );
    }

    return renderLines(content);
  };

  // Check if all templates are empty
  const isEmpty = !parsedHeader && !parsedBody && !parsedFooter;

  return (
    <Document>
      <Page size={dimensions} style={styles.page}>
        {isEmpty ? (
          <View style={styles.body}>
            <Text style={styles.emptyState}>
              Enter template content to see preview...
            </Text>
          </View>
        ) : (
          <>
            {/* Header */}
            <View style={styles.header}>
              {renderTemplateContent(parsedHeader)}
            </View>

            {/* Body */}
            <View style={styles.body}>
              {renderTemplateContent(parsedBody)}
            </View>

            {/* Footer */}
            <View style={styles.footer}>
              {renderTemplateContent(parsedFooter)}
            </View>
          </>
        )}
      </Page>
    </Document>
  );
}

// Simple hash function for string content
const hashContent = (str: string): number => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return hash;
};

export default function LayoutPreview(props: LayoutPreviewProps) {
  const [isReady, setIsReady] = useState(false);

  // Delay rendering to ensure PDF library is fully loaded
  useEffect(() => {
    const timer = setTimeout(() => setIsReady(true), 50);
    return () => clearTimeout(timer);
  }, []);

  // Generate a key that includes content hash to force remount when content changes
  // This prevents @react-pdf/renderer bugs with in-place updates when structure changes
  const contentHash = hashContent(props.headerTemplate + props.bodyTemplate + props.footerTemplate);
  const key = `${props.paperSize}-${props.orientation}-${props.fontFamily}-${props.hideZeroAmountFees ? "hide" : "show"}-${contentHash}`;

  if (!isReady) {
    return (
      <div className="flex items-center justify-center h-full bg-muted/30 text-muted-foreground">
        <p className="text-sm">Loading preview...</p>
      </div>
    );
  }

  // Check if we have content to render
  const hasContent = props.headerTemplate || props.bodyTemplate || props.footerTemplate;

  if (!hasContent) {
    return (
      <div className="flex items-center justify-center h-full bg-muted/30 text-muted-foreground">
        <p className="text-sm">Enter template content to see preview...</p>
      </div>
    );
  }

  return (
    <PDFViewer key={key} width="100%" height="100%" showToolbar={false}>
      <ReceiptDocument {...props} />
    </PDFViewer>
  );
}
