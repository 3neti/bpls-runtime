"use client"

import * as React from "react"
import { CalendarIcon } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import { Button } from "@repo/ui/components/button"
import { Calendar } from "@repo/ui/components/calendar"
import { Label } from "@repo/ui/components/label"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@repo/ui/components/popover"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import type { DateRange, DateRangePreset, Dimension } from "@/lib/types/report-builder"

const PRESETS: { value: DateRangePreset; label: string }[] = [
  { value: "today", label: "Today" },
  { value: "yesterday", label: "Yesterday" },
  { value: "thisWeek", label: "This Week" },
  { value: "lastWeek", label: "Last Week" },
  { value: "thisMonth", label: "This Month" },
  { value: "lastMonth", label: "Last Month" },
  { value: "thisQuarter", label: "This Quarter" },
  { value: "lastQuarter", label: "Last Quarter" },
  { value: "thisYear", label: "This Year" },
  { value: "lastYear", label: "Last Year" },
  { value: "last7Days", label: "Last 7 Days" },
  { value: "last30Days", label: "Last 30 Days" },
  { value: "last90Days", label: "Last 90 Days" },
  { value: "custom", label: "Custom Range" },
]

interface DateRangePickerProps {
  value: DateRange | null
  onChange: (dateRange: DateRange | null) => void
  dateDimensions?: Dimension[]
  primaryDimensionId?: string
}

export function DateRangePicker({
  value,
  onChange,
  dateDimensions = [],
  primaryDimensionId,
}: DateRangePickerProps) {
  const [startDate, setStartDate] = React.useState<Date | undefined>(
    value?.startDate ? new Date(value.startDate) : undefined
  )
  const [endDate, setEndDate] = React.useState<Date | undefined>(
    value?.endDate ? new Date(value.endDate) : undefined
  )

  const handlePresetChange = (preset: DateRangePreset) => {
    if (preset === "custom") {
      onChange({
        preset: "custom",
        startDate: startDate?.toISOString(),
        endDate: endDate?.toISOString(),
        dimensionId: value?.dimensionId || primaryDimensionId,
      })
    } else {
      onChange({
        preset,
        dimensionId: value?.dimensionId || primaryDimensionId,
      })
    }
  }

  const handleDimensionChange = (dimensionId: string) => {
    if (!value) {
      onChange({
        preset: "thisMonth",
        dimensionId,
      })
    } else {
      onChange({
        ...value,
        dimensionId,
      })
    }
  }

  const handleStartDateChange = (date: Date | undefined) => {
    setStartDate(date)
    if (value?.preset === "custom") {
      onChange({
        ...value,
        startDate: date?.toISOString(),
      })
    }
  }

  const handleEndDateChange = (date: Date | undefined) => {
    setEndDate(date)
    if (value?.preset === "custom") {
      onChange({
        ...value,
        endDate: date?.toISOString(),
      })
    }
  }

  const clearDateRange = () => {
    onChange(null)
    setStartDate(undefined)
    setEndDate(undefined)
  }

  const getPresetLabel = () => {
    if (!value) return "Select date range..."
    const preset = PRESETS.find((p) => p.value === value.preset)
    if (preset?.value === "custom" && value.startDate && value.endDate) {
      return `${format(new Date(value.startDate), "MMM d, yyyy")} - ${format(new Date(value.endDate), "MMM d, yyyy")}`
    }
    return preset?.label || "Select date range..."
  }

  return (
    <div className="space-y-2">
      <div className="grid gap-2">
        {/* Date dimension selector */}
        {dateDimensions.length > 0 && (
          <div className="space-y-1">
            <Label className="text-[11px] text-muted-foreground">Filter by</Label>
            <Select
              value={value?.dimensionId || primaryDimensionId || ""}
              onValueChange={handleDimensionChange}
            >
              <SelectTrigger className="h-7 text-[11px]">
                <SelectValue placeholder="Select date field..." />
              </SelectTrigger>
              <SelectContent>
                {dateDimensions.map((dim) => (
                  <SelectItem key={dim.id} value={dim.id}>
                    {dim.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Preset selector */}
        <div className="space-y-1">
          <Label className="text-[11px] text-muted-foreground">Period</Label>
          <Select
            value={value?.preset || ""}
            onValueChange={(val) => handlePresetChange(val as DateRangePreset)}
          >
            <SelectTrigger className="h-7 text-[11px]">
              <SelectValue placeholder="Select date range..." />
            </SelectTrigger>
            <SelectContent>
              {PRESETS.map((preset) => (
                <SelectItem key={preset.value} value={preset.value}>
                  {preset.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Custom date pickers */}
        {value?.preset === "custom" && (
          <div className="grid grid-cols-2 gap-1.5">
            <div className="space-y-1">
              <Label className="text-[10px] text-muted-foreground">Start</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "h-7 w-full justify-start text-left text-[11px] font-normal px-2",
                      !startDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-1.5 size-3" />
                    {startDate ? format(startDate, "MMM d") : "Pick"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={startDate}
                    onSelect={handleStartDateChange}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-1">
              <Label className="text-[10px] text-muted-foreground">End</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "h-7 w-full justify-start text-left text-[11px] font-normal px-2",
                      !endDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-1.5 size-3" />
                    {endDate ? format(endDate, "MMM d") : "Pick"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={endDate}
                    onSelect={handleEndDateChange}
                    initialFocus
                    disabled={(date) => (startDate ? date < startDate : false)}
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
        )}

        {/* Clear button */}
        {value && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearDateRange}
            className="h-6 text-[10px] w-full mt-1"
          >
            Clear date range
          </Button>
        )}
      </div>
    </div>
  )
}
