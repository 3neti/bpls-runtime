"use client"

import { useState } from "react"
import { Search, CheckCircle2 } from "lucide-react"

import { Input } from "@repo/ui/components/input"
import { Label } from "@repo/ui/components/label"
import { Avatar, AvatarFallback, AvatarImage } from "@repo/ui/components/avatar"
import { Badge } from "@repo/ui/components/badge"
import { ScrollArea } from "@repo/ui/components/scroll-area"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"

import type { Doc, Id } from "@repo/backend/convex/_generated/dataModel"
import { getInitials } from "@/lib/utils/formatting"

interface BusinessOwnerSelectorProps {
  owners: Doc<"business_owners">[]
  selectedOwnerId: Id<"business_owners"> | null
  onOwnerSelect: (ownerId: Id<"business_owners">) => void
}

export function BusinessOwnerSelector({
  owners,
  selectedOwnerId,
  onOwnerSelect,
}: BusinessOwnerSelectorProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [ownerTypeFilter, setOwnerTypeFilter] = useState<"all" | "Single" | "Group">("all")

  const filteredOwners = owners.filter((owner) => {
    // Filter by owner type
    if (ownerTypeFilter !== "all" && owner.ownerType !== ownerTypeFilter) {
      return false
    }

    // Filter by search term
    const fullName = `${owner.firstName} ${owner.middleName || ""} ${owner.lastName}`.toLowerCase()
    const search = searchTerm.toLowerCase()
    return (
      fullName.includes(search) ||
      owner.email.toLowerCase().includes(search) ||
      owner.tin?.toLowerCase().includes(search)
    )
  })

  const selectedOwner = owners.find((owner) => owner._id === selectedOwnerId)

  return (
    <div className="space-y-6">
      {/* Search and Filter */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label>Search Business Owner</Label>
          <div className="relative mt-2">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, email, or TIN..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>
        <div>
          <Label>Filter by Owner Type</Label>
          <Select
            value={ownerTypeFilter}
            onValueChange={(value: "all" | "Single" | "Group") => setOwnerTypeFilter(value)}
          >
            <SelectTrigger className="mt-2">
              <SelectValue placeholder="All Owners" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Owners</SelectItem>
              <SelectItem value="Single">Single Owner</SelectItem>
              <SelectItem value="Group">Group Owner</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Selected Owner Display */}
      {selectedOwner && (
        <div className="p-4 border-2 border-primary rounded-lg bg-primary/5">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="h-5 w-5 text-primary shrink-0" />
            <div className="flex items-center gap-3 flex-1">
              <Avatar className="h-10 w-10">
                <AvatarImage src={selectedOwner.avatar || "/placeholder.svg"} alt={`${selectedOwner.firstName} ${selectedOwner.lastName}`} />
                <AvatarFallback>{getInitials(selectedOwner.firstName, selectedOwner.lastName)}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="font-medium flex items-center gap-2">
                  {`${selectedOwner.firstName} ${selectedOwner.lastName}`}
                  <Badge variant="secondary" className="text-xs">Selected</Badge>
                  {selectedOwner.ownerType && (
                    <Badge variant="outline" className="text-xs">
                      {selectedOwner.ownerType}
                    </Badge>
                  )}
                </div>
                <div className="text-sm text-muted-foreground truncate">{selectedOwner.email}</div>
                <div className="text-sm text-muted-foreground">TIN: {selectedOwner.tin}</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Owner List */}
      <div>
        <Label className="mb-2 block">
          {filteredOwners.length === 0
            ? "No business owners found"
            : `${filteredOwners.length} business owner${filteredOwners.length === 1 ? "" : "s"} available`}
        </Label>
        <ScrollArea className="h-[400px] border rounded-lg">
          <div className="space-y-2 p-2">
            {filteredOwners.map((owner) => {
              const isSelected = selectedOwnerId === owner._id

              return (
                <div
                  key={owner._id}
                  className={`p-4 border rounded-lg transition-all cursor-pointer hover:shadow-md ${
                    isSelected
                      ? "border-primary bg-primary/10"
                      : "border-border hover:border-primary/50 hover:bg-muted/50"
                  }`}
                  onClick={() => onOwnerSelect(owner._id)}
                >
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={owner.avatar || "/placeholder.svg"} alt={`${owner.firstName} ${owner.lastName}`} />
                      <AvatarFallback>{getInitials(owner.firstName, owner.lastName)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium flex items-center gap-2">
                        {`${owner.firstName} ${owner.middleName ? owner.middleName + " " : ""}${owner.lastName}`}
                        {isSelected && <CheckCircle2 className="h-4 w-4 text-primary" />}
                        {owner.ownerType && (
                          <Badge variant="outline" className="text-xs">
                            {owner.ownerType}
                          </Badge>
                        )}
                      </div>
                      <div className="text-sm text-muted-foreground truncate">{owner.email}</div>
                      <div className="text-sm text-muted-foreground">
                        TIN: {owner.tin} • {owner.mobile}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {owner.address}
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </ScrollArea>
      </div>
    </div>
  )
}
