# Department Review System - Reusable Components

This directory contains reusable components for the BPLS department review system. These components enable consistent UI/UX across all department review pages while maintaining department-specific branding and functionality.

## Architecture Overview

The review system is built on a **component composition pattern** where:
- **Reusable components** handle UI rendering and common interactions
- **Department configurations** provide branding and customization
- **Department routes** compose components with their specific config

## Components

### 1. ReviewLayout
Main layout wrapper for all department review pages.

**Features:**
- Department-specific header with logo and branding
- Centralized search bar
- Theme toggle
- Notifications button
- User dropdown with department user info

**Usage:**
```tsx
import { ReviewLayout } from "@/components/review"
import { sanitaryConfig } from "@/lib/data/departments"

export default function SanitaryLayout({ children }) {
  return <ReviewLayout config={sanitaryConfig}>{children}</ReviewLayout>
}
```

### 2. ReviewPageHeader
Page title and description component.

**Features:**
- Mobile-responsive text sizing
- Consistent spacing
- Accessible heading hierarchy

**Usage:**
```tsx
import { ReviewPageHeader } from "@/components/review"

<ReviewPageHeader
  title="Sanitary Certificate Review"
  description="Review business permit applications requiring sanitary certificates"
/>
```

### 3. ReviewStatsCards
Three-card statistics display showing:
- Total Pending permits
- Awaiting Review count
- Approved Today count

**Features:**
- Mobile-responsive grid (stacks on small screens)
- Consistent card styling
- Large, readable numbers

**Usage:**
```tsx
import { ReviewStatsCards } from "@/components/review"

<ReviewStatsCards
  stats={{
    totalPending: 25,
    awaitingReview: 18,
    approvedToday: 7
  }}
/>
```

### 4. ReviewTable
Permits table with clickable rows and action buttons.

**Features:**
- Clickable rows navigate to detail page
- Review button (opens detail page)
- Approve button (triggers approval)
- Mobile-responsive with horizontal scroll
- Empty state when no permits
- Date formatting
- Status badges

**Usage:**
```tsx
import { ReviewTable } from "@/components/review"

<ReviewTable
  permits={permitList}
  departmentRoute="sanitary"
  onApprove={(id) => console.log('Approved:', id)}
/>
```

### 5. ReviewDetailLayout
Detail page layout showing permit application information.

**Features:**
- Application header with status and actions
- Business owner information card
- Business details card
- Document uploads card
- Application timeline sidebar
- Not found state for invalid applications

**Usage:**
```tsx
import { ReviewDetailLayout } from "@/components/review"

<ReviewDetailLayout
  application={applicationData}
  departmentName="Sanitary Department"
  departmentRoute="sanitary"
  applicationId="1"
  onApprove={() => console.log('Approved')}
/>
```

## Department Configurations

Located in `/lib/config/departments.ts`

Each department has a configuration object defining:
- `name`: Full department name
- `shortName`: Abbreviated name
- `icon`: Lucide icon component
- `route`: URL route prefix
- `pageTitle`: Page heading text
- `description`: Page description text
- `user`: Department user information (name, email, avatar)

### Available Departments

1. **Sanitary Department** - `/sanitary/review`
2. **Bureau of Fire Protection (BFP)** - `/bfp/review`
3. **Municipal Planning & Development Coordinator (MPDC)** - `/mpdc/review`
4. **Municipal Environment & Natural Resources Office (MENRO)** - `/menro/review`
5. **Engineering Department** - `/engineering/review`

## Adding a New Department

To add a new department review system:

### Step 1: Create Department Configuration

Add to `/lib/config/departments.ts`:

```typescript
import { YourIcon } from "lucide-react"

export const yourDeptConfig: DepartmentConfig = {
  name: "Your Department Name",
  shortName: "DEPT",
  icon: YourIcon,
  route: "your-dept",
  pageTitle: "Your Certificate Review",
  description: "Review business permit applications requiring your certificates",
  user: {
    name: "Your Department Officer",
    email: "dept@bpls.gov.ph",
    avatar: "/government-official-avatar.png",
  },
}
```

### Step 2: Create Department Routes

Create three files:

**`app/your-dept/review/layout.tsx`**
```typescript
import type { ReactNode } from "react"
import { ReviewLayout } from "@/components/review/review-layout"
import { yourDeptConfig } from "@/lib/data/departments"

interface YourDeptLayoutProps {
  children: ReactNode
}

export default function YourDeptLayout({ children }: YourDeptLayoutProps) {
  return <ReviewLayout config={yourDeptConfig}>{children}</ReviewLayout>
}
```

**`app/your-dept/review/page.tsx`**
```typescript
"use client"

import { useState } from "react"
import { ReviewPageHeader } from "@/components/review/review-page-header"
import { ReviewStatsCards } from "@/components/review/review-stats-cards"
import { ReviewTable } from "@/components/review/review-table"
import { MOCK_PERMITS } from "@/lib/data/mock-permits"
import { yourDeptConfig } from "@/lib/data/departments"
import type { DepartmentPermit } from "@/lib/types/department"

export default function YourDeptReviewPage() {
  const [permits] = useState<DepartmentPermit[]>(MOCK_PERMITS)

  const stats = {
    totalPending: permits.length,
    awaitingReview: permits.filter((p) => p.status === "Applied").length,
    approvedToday: 0,
  }

  return (
    <div className="space-y-4 lg:space-y-6">
      <ReviewPageHeader title={yourDeptConfig.pageTitle} description={yourDeptConfig.description} />
      <ReviewStatsCards stats={stats} />
      <ReviewTable permits={permits} departmentRoute={yourDeptConfig.route} />
    </div>
  )
}
```

**`app/your-dept/review/[id]/page.tsx`**
```typescript
"use client"

import { useParams } from "next/navigation"
import { ReviewDetailLayout } from "@/components/review/review-detail-layout"
import { getMockApplication } from "@/lib/data/mock-applications"
import { yourDeptConfig } from "@/lib/data/departments"

export default function YourDeptReviewDetailsPage() {
  const params = useParams()
  const id = params.id as string

  const application = getMockApplication(id)

  const handleApprove = () => {
    console.log("Approving your department certificate for:", id)
    // TODO: Implement approval logic with Convex mutation
  }

  return (
    <ReviewDetailLayout
      application={application}
      departmentName={yourDeptConfig.name}
      departmentRoute={yourDeptConfig.route}
      applicationId={id}
      onApprove={handleApprove}
    />
  )
}
```

That's it! Your new department is now fully functional.

## Type Definitions

All types are defined in `/lib/types/department.ts`:

- `DepartmentConfig` - Department configuration structure
- `DepartmentUser` - Department user information
- `DepartmentPermit` - Simplified permit for table display
- `DepartmentStats` - Review dashboard statistics

## Mock Data

Mock data is centralized for consistency:

- `/lib/data/mock-permits.ts` - Shared permit list for all departments
- `/lib/data/mock-applications.ts` - Detailed application data for detail pages

In production, these will be replaced with Convex queries.

## Mobile Responsiveness

All components are mobile-first and responsive:
- Headers stack on small screens
- Tables scroll horizontally on narrow screens
- Stats cards stack vertically on mobile
- Action buttons show icons only on small screens
- Text sizes adjust based on viewport

## Future Enhancements

When integrating with Convex backend:

1. Replace `MOCK_PERMITS` with `useQuery(api.permits.listByDepartment, { department: "sanitary" })`
2. Replace `getMockApplication` with `useQuery(api.permits.getById, { id })`
3. Implement `onApprove` with `useMutation(api.permits.approve, { id, department })`
4. Add real-time updates for statistics
5. Implement search functionality in ReviewLayout
6. Add pagination to ReviewTable

## Design Principles

1. **DRY (Don't Repeat Yourself)**: All department pages share the same components
2. **Single Source of Truth**: Department configs centralize all department-specific data
3. **Composition Over Configuration**: Components compose together rather than using complex props
4. **Type Safety**: All components are fully typed with TypeScript
5. **Mobile-First**: Responsive design prioritizes mobile experience
6. **Accessibility**: Proper ARIA labels, semantic HTML, keyboard navigation
