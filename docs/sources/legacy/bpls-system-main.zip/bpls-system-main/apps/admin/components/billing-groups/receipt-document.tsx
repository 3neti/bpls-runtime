"use client"

import React from "react"
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
} from "@react-pdf/renderer"
import { formatCurrency } from "@/lib/utils/formatting"

// Types for fee custom field values
export interface FeeFieldValueData {
  fieldId: string
  value: string
}

// Types for fee fields configuration
export interface FeeFieldData {
  fieldId: string
  name: string
  fieldType: "text" | "number" | "currency" | "date" | "dropdown" | "checkbox"
}

// Types for receipt data
export interface LineItemData {
  feeCode: string
  feeName: string
  amount: number
  quantity: number
  subtotal: number
  customFieldValues?: FeeFieldValueData[]
}

export interface ReceiptData {
  transactionNumber: string
  date: string
  billingGroupName: string
  status: "pending" | "completed" | "cancelled"
  lineItems: LineItemData[]
  totalAmount: number
  // Payment fields
  paymentMethod?: string
  referenceNumber?: string
  description?: string
  // Optional header fields from transaction
  headerFields?: Array<{
    fieldId?: string  // Convex field ID for matching with layout field keys
    name: string
    value: string
  }>
  // Fee fields to include in receipt (where includeInReceipt: true)
  feeFields?: FeeFieldData[]
  // Print settings
  printDate?: string
}

// Convert number to words helper
const numberToWords = (amount: number): string => {
  const ones = [
    "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
    "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
    "Seventeen", "Eighteen", "Nineteen",
  ]
  const tens = [
    "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety",
  ]

  const convertHundreds = (num: number): string => {
    if (num === 0) return ""
    if (num < 20) return ones[num]
    if (num < 100) {
      return tens[Math.floor(num / 10)] + (num % 10 !== 0 ? " " + ones[num % 10] : "")
    }
    return ones[Math.floor(num / 100)] + " Hundred" + (num % 100 !== 0 ? " " + convertHundreds(num % 100) : "")
  }

  const convertThousands = (num: number): string => {
    if (num === 0) return "Zero"
    if (num < 1000) return convertHundreds(num)
    if (num < 1000000) {
      return convertHundreds(Math.floor(num / 1000)) + " Thousand" + (num % 1000 !== 0 ? " " + convertHundreds(num % 1000) : "")
    }
    if (num < 1000000000) {
      return convertThousands(Math.floor(num / 1000000)) + " Million" + (num % 1000000 !== 0 ? " " + convertThousands(num % 1000000) : "")
    }
    return convertThousands(Math.floor(num / 1000000000)) + " Billion" + (num % 1000000000 !== 0 ? " " + convertThousands(num % 1000000000) : "")
  }

  // Handle decimal part
  const wholePart = Math.floor(amount)
  const decimalPart = Math.round((amount - wholePart) * 100)

  let result = convertThousands(wholePart) + " Pesos"
  if (decimalPart > 0) {
    result += " and " + decimalPart + "/100"
  } else {
    result += " Only"
  }

  return result
}


// Styles
const styles = StyleSheet.create({
  page: {
    padding: 20,
    fontSize: 10,
    fontFamily: "Helvetica",
  },
  // Header
  header: {
    marginBottom: 20,
    textAlign: "center",
  },
  title: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 12,
    marginBottom: 10,
  },
  transactionNumber: {
    fontSize: 11,
    fontWeight: "bold",
    marginTop: 5,
  },
  // Info section
  infoSection: {
    marginBottom: 15,
    padding: 10,
    backgroundColor: "#f8f9fa",
    borderRadius: 4,
  },
  infoRow: {
    flexDirection: "row",
    marginBottom: 4,
  },
  infoLabel: {
    width: 120,
    fontWeight: "bold",
  },
  infoValue: {
    flex: 1,
  },
  // Table
  table: {
    marginBottom: 15,
  },
  tableHeader: {
    flexDirection: "row",
    backgroundColor: "#1e3a5f",
    padding: 8,
  },
  tableHeaderCell: {
    color: "#ffffff",
    fontWeight: "bold",
    fontSize: 9,
  },
  tableRow: {
    flexDirection: "row",
    padding: 6,
  },
  tableCell: {
    fontSize: 9,
  },
  // Column widths
  colCode: { width: "15%" },
  colName: { width: "40%" },
  colAmount: { width: "15%", textAlign: "right" as const },
  colQty: { width: "10%", textAlign: "center" as const },
  colSubtotal: { width: "20%", textAlign: "right" as const },
  // Totals
  totalsSection: {
    marginTop: 10,
    borderTopWidth: 2,
    borderTopColor: "#1e3a5f",
    paddingTop: 10,
  },
  totalRow: {
    flexDirection: "row",
    justifyContent: "flex-end",
    marginBottom: 5,
  },
  totalLabel: {
    width: 150,
    textAlign: "right",
    fontWeight: "bold",
    paddingRight: 10,
  },
  totalValue: {
    width: 100,
    textAlign: "right",
    fontWeight: "bold",
  },
  grandTotal: {
    fontSize: 14,
    color: "#1e3a5f",
  },
  // Amount in words
  amountInWords: {
    marginTop: 15,
    padding: 10,
    backgroundColor: "#f0f9ff",
    borderRadius: 4,
  },
  amountInWordsLabel: {
    fontWeight: "bold",
    marginBottom: 3,
    fontSize: 9,
  },
  amountInWordsValue: {
    fontSize: 10,
    fontStyle: "italic",
  },
  // Footer
  footer: {
    marginTop: 30,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  signatureBlock: {
    width: "45%",
    textAlign: "center",
  },
  signatureLine: {
    borderTopWidth: 1,
    borderTopColor: "#000000",
    marginTop: 40,
    marginBottom: 5,
  },
  signatureLabel: {
    fontSize: 9,
  },
  // Print info
  printInfo: {
    position: "absolute",
    bottom: 20,
    left: 30,
    right: 30,
    flexDirection: "row",
    justifyContent: "space-between",
    fontSize: 8,
    color: "#6b7280",
  },
  // Status badge
  statusBadge: {
    paddingVertical: 3,
    paddingHorizontal: 8,
    borderRadius: 4,
    fontSize: 9,
    fontWeight: "bold",
    marginTop: 5,
    alignSelf: "center",
  },
  statusPending: {
    backgroundColor: "#fef3c7",
    color: "#92400e",
  },
  statusCompleted: {
    backgroundColor: "#d1fae5",
    color: "#065f46",
  },
  statusCancelled: {
    backgroundColor: "#fee2e2",
    color: "#991b1b",
  },
})

interface ReceiptDocumentProps {
  data: ReceiptData
}

export function ReceiptDocument({ data }: ReceiptDocumentProps) {
  const {
    transactionNumber,
    date,
    billingGroupName,
    status,
    lineItems,
    totalAmount,
    headerFields,
    printDate,
  } = data

  const getStatusStyle = () => {
    switch (status) {
      case "completed":
        return styles.statusCompleted
      case "cancelled":
        return styles.statusCancelled
      default:
        return styles.statusPending
    }
  }

  const getStatusLabel = () => {
    switch (status) {
      case "completed":
        return "PAID"
      case "cancelled":
        return "CANCELLED"
      default:
        return "PENDING"
    }
  }

  return (
    <Document>
      <Page size="LETTER" style={styles.page}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>{billingGroupName}</Text>
          <Text style={styles.subtitle}>Official Receipt</Text>
          <Text style={styles.transactionNumber}>
            Transaction No: {transactionNumber}
          </Text>
          <View style={[styles.statusBadge, getStatusStyle()]}>
            <Text>{getStatusLabel()}</Text>
          </View>
        </View>

        {/* Info Section */}
        <View style={styles.infoSection}>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Date:</Text>
            <Text style={styles.infoValue}>
              {new Date(date).toLocaleDateString("en-PH", {
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </Text>
          </View>
          {headerFields?.map((field, index) => (
            <View key={index} style={styles.infoRow}>
              <Text style={styles.infoLabel}>{field.name}:</Text>
              <Text style={styles.infoValue}>{field.value}</Text>
            </View>
          ))}
        </View>

        {/* Line Items Table */}
        <View style={styles.table}>
          {/* Table Header */}
          <View style={styles.tableHeader}>
            <Text style={[styles.tableHeaderCell, styles.colCode]}>Code</Text>
            <Text style={[styles.tableHeaderCell, styles.colName]}>Description</Text>
            <Text style={[styles.tableHeaderCell, styles.colAmount]}>Amount</Text>
            <Text style={[styles.tableHeaderCell, styles.colQty]}>Qty</Text>
            <Text style={[styles.tableHeaderCell, styles.colSubtotal]}>Subtotal</Text>
          </View>

          {/* Table Rows */}
          {lineItems.map((item, index) => (
            <View
              key={index}
              style={styles.tableRow}
            >
              <Text style={[styles.tableCell, styles.colCode]}>{item.feeCode}</Text>
              <Text style={[styles.tableCell, styles.colName]}>{item.feeName}</Text>
              <Text style={[styles.tableCell, styles.colAmount]}>
                {formatCurrency(item.amount)}
              </Text>
              <Text style={[styles.tableCell, styles.colQty]}>{item.quantity}</Text>
              <Text style={[styles.tableCell, styles.colSubtotal]}>
                {formatCurrency(item.subtotal)}
              </Text>
            </View>
          ))}
        </View>

        {/* Totals */}
        <View style={styles.totalsSection}>
          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>Total Items:</Text>
            <Text style={styles.totalValue}>{lineItems.length}</Text>
          </View>
          <View style={styles.totalRow}>
            <Text style={[styles.totalLabel, styles.grandTotal]}>GRAND TOTAL:</Text>
            <Text style={[styles.totalValue, styles.grandTotal]}>
              {formatCurrency(totalAmount)}
            </Text>
          </View>
        </View>

        {/* Amount in Words */}
        <View style={styles.amountInWords}>
          <Text style={styles.amountInWordsLabel}>AMOUNT IN WORDS:</Text>
          <Text style={styles.amountInWordsValue}>
            {numberToWords(totalAmount)}
          </Text>
        </View>

        {/* Signature Section */}
        <View style={styles.footer}>
          <View style={styles.signatureBlock}>
            <View style={styles.signatureLine} />
            <Text style={styles.signatureLabel}>Prepared By</Text>
          </View>
          <View style={styles.signatureBlock}>
            <View style={styles.signatureLine} />
            <Text style={styles.signatureLabel}>Received By</Text>
          </View>
        </View>

        {/* Print Info */}
        <View style={styles.printInfo}>
          <Text>Printed: {printDate || new Date().toLocaleDateString()}</Text>
          <Text>This document is computer-generated</Text>
        </View>
      </Page>
    </Document>
  )
}
