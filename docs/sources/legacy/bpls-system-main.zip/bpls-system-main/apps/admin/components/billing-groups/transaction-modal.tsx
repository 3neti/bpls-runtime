"use client"

import { useState, useEffect } from "react"
import { useConvex, useMutation, useQuery } from "convex/react"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { Button } from "@repo/ui/components/button"
import { Input } from "@repo/ui/components/input"
import { Label } from "@repo/ui/components/label"
import { Checkbox } from "@repo/ui/components/checkbox"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@repo/ui/components/popover"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@repo/ui/components/command"
import { Separator } from "@repo/ui/components/separator"
import { Check, ChevronsUpDown } from "lucide-react"
import { cn } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import { LineItemEditor, type LineItem, type FeeField } from "./line-item-editor"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

type FieldType = "text" | "number" | "currency" | "date" | "dropdown" | "checkbox"

// Payment method options (standardized with permits system)
const PAYMENT_METHODS = [
  { value: "Cash", label: "Cash" },
  { value: "Credit Card", label: "Credit Card" },
  { value: "Bank Transfer", label: "Bank Transfer" },
  { value: "GCash", label: "GCash" },
  { value: "PayMaya", label: "PayMaya" },
  { value: "Check", label: "Check" },
] as const

type PaymentMethod = typeof PAYMENT_METHODS[number]["value"]

interface Field {
  _id: Id<"billing_group_fields">
  name: string
  fieldType: FieldType
  isRequired: boolean
  isUnique?: boolean
  sortOrder: number
  options?: string[]
  placeholder?: string
  defaultValue?: string
}

interface FieldValue {
  fieldId: Id<"billing_group_fields">
  value: string
}

interface TransactionModalProps {
  open: boolean
  onClose: () => void
  billingGroupId: Id<"billing_groups">
  maxLineItems: number
  editingRecordId?: Id<"billing_group_records"> | null
}

export function TransactionModal({
  open,
  onClose,
  billingGroupId,
  maxLineItems,
  editingRecordId,
}: TransactionModalProps) {
  const { toast } = useToast()
  const convex = useConvex()
  const isEditing = editingRecordId !== null && editingRecordId !== undefined

  const [lineItems, setLineItems] = useState<LineItem[]>([])
  const [fieldValues, setFieldValues] = useState<FieldValue[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [openDropdowns, setOpenDropdowns] = useState<Record<string, boolean>>({})

  // System columns state
  const [description, setDescription] = useState("")
  const [date, setDate] = useState(() => new Date().toISOString().split("T")[0])
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("Cash")
  const [referenceNumber, setReferenceNumber] = useState("")

  // Fetch billing group with fields
  const billingGroup = useQuery(api.billingGroups.getById, { id: billingGroupId })

  // Fetch fee fields (custom columns for line items)
  const feeFieldsData = useQuery(api.billingGroupFeeFields.listByGroup, { billingGroupId })

  // Fetch record data if editing
  const recordData = useQuery(
    api.billingGroupRecords.getByIdWithLineItems,
    editingRecordId ? { id: editingRecordId } : "skip"
  )

  // Mutations
  const createRecord = useMutation(api.billingGroupRecords.createWithLineItems)
  const updateLineItems = useMutation(api.billingGroupLineItems.bulkUpdate)
  const updateHeaderFields = useMutation(api.billingGroupRecords.updateHeaderFields)
  const updateSystemColumns = useMutation(api.billingGroupRecords.updateSystemColumns)

  // Get fields sorted by sortOrder (exclude amount fields since line items handle amounts)
  const fields: Field[] = (billingGroup?.fields || [])
    .filter((f) => f._id !== billingGroup?.amountFieldId)
    .sort((a, b) => a.sortOrder - b.sortOrder)

  // Reset form when modal opens/closes or editing record changes
  useEffect(() => {
    if (open) {
      if (recordData) {
        // Populate with existing data
        if (recordData.lineItems) {
          const existingItems: LineItem[] = recordData.lineItems.map((item: {
            _id: string
            feeId: Id<"billing_group_fees">
            amount: number
            quantity?: number
            fee?: {
              _id: Id<"billing_group_fees">
              name: string
              code: string
              defaultAmount: number
              customFieldValues?: Array<{ fieldId: Id<"billing_group_fee_fields">; value: string }>
            }
          }) => ({
            id: item._id,
            feeId: item.feeId,
            fee: item.fee
              ? {
                  _id: item.fee._id,
                  name: item.fee.name,
                  code: item.fee.code,
                  defaultAmount: item.fee.defaultAmount,
                  isActive: true,
                  customFieldValues: item.fee.customFieldValues,
                }
              : undefined,
            amount: item.amount,
            quantity: item.quantity || 1,
          }))
          setLineItems(existingItems)
        }
        // Populate field values from record
        if (recordData.fieldValues) {
          setFieldValues(recordData.fieldValues)
        } else {
          setFieldValues([])
        }
        // Populate system columns from record
        setDescription(recordData.description || "")
        setDate(recordData.date || recordData.createdAt?.split("T")[0] || new Date().toISOString().split("T")[0])
        setPaymentMethod((recordData.paymentMethod as PaymentMethod) || "Cash")
        setReferenceNumber(recordData.referenceNumber || "")
      } else if (!editingRecordId) {
        // New record - initialize with default values
        setLineItems([])
        const defaultValues: FieldValue[] = fields
          .filter((f) => f.defaultValue)
          .map((f) => ({
            fieldId: f._id,
            value: f.defaultValue || "",
          }))
        setFieldValues(defaultValues)
        // Reset system columns to defaults
        setDescription("")
        setDate(new Date().toISOString().split("T")[0])
        setPaymentMethod("Cash")
        setReferenceNumber("")
      }
    }
  }, [open, recordData, editingRecordId, fields.length])

  // Helper to get field value
  const getFieldValue = (fieldId: Id<"billing_group_fields">): string => {
    const fv = fieldValues.find((f) => f.fieldId === fieldId)
    return fv?.value || ""
  }

  // Helper to set field value
  const setFieldValue = (fieldId: Id<"billing_group_fields">, value: string) => {
    setFieldValues((prev) => {
      const existing = prev.find((f) => f.fieldId === fieldId)
      if (existing) {
        return prev.map((f) => (f.fieldId === fieldId ? { ...f, value } : f))
      }
      return [...prev, { fieldId, value }]
    })
  }

  // Validate system columns
  const validateSystemColumns = (): boolean => {
    if (!description.trim()) {
      toast({
        title: "Error",
        description: "Description is required.",
        variant: "destructive",
      })
      return false
    }
    if (!date) {
      toast({
        title: "Error",
        description: "Date is required.",
        variant: "destructive",
      })
      return false
    }
    if (!paymentMethod) {
      toast({
        title: "Error",
        description: "Payment Method is required.",
        variant: "destructive",
      })
      return false
    }
    // Reference number is required for non-Cash payments
    if (paymentMethod !== "Cash" && !referenceNumber.trim()) {
      toast({
        title: "Error",
        description: "Reference Number is required for non-Cash payments.",
        variant: "destructive",
      })
      return false
    }
    return true
  }

  // Validate required fields
  const validateFields = (): boolean => {
    for (const field of fields) {
      if (field.isRequired) {
        const value = getFieldValue(field._id)
        if (!value || value.trim() === "") {
          toast({
            title: "Error",
            description: `"${field.name}" is required.`,
            variant: "destructive",
          })
          return false
        }
      }
    }
    return true
  }

  const handleSubmit = async () => {
    // Validate system columns first
    if (!validateSystemColumns()) {
      return
    }

    // Validate required custom fields
    if (!validateFields()) {
      return
    }

    // Validate unique fields
    for (const field of fields) {
      if (!field.isUnique) continue
      const value = getFieldValue(field._id)
      if (!value || value.trim() === "") continue

      const result = await convex.query(
        api.billingGroupRecords.checkFieldUniqueness,
        {
          billingGroupId,
          fieldId: field._id,
          value,
          excludeRecordId: editingRecordId ?? undefined,
        }
      )

      if (!result.isUnique) {
        toast({
          title: "Duplicate Value",
          description: `"${value}" already exists for "${field.name}". This field requires unique values.`,
          variant: "destructive",
        })
        return
      }
    }

    // Validate line items
    if (lineItems.length === 0) {
      toast({
        title: "Error",
        description: "Please add at least one line item.",
        variant: "destructive",
      })
      return
    }

    const invalidItems = lineItems.filter((item) => !item.feeId || item.amount <= 0)
    if (invalidItems.length > 0) {
      toast({
        title: "Error",
        description: "Please select a fee and enter a valid amount for all line items.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      if (isEditing && editingRecordId) {
        // Update existing record's line items
        await updateLineItems({
          recordId: editingRecordId,
          lineItems: lineItems.map((item) => ({
            id: item.id.startsWith("temp_")
              ? undefined
              : (item.id as Id<"billing_group_line_items">),
            feeId: item.feeId as Id<"billing_group_fees">,
            amount: item.amount,
            quantity: item.quantity,
          })),
        })
        // Update field values separately
        if (fieldValues.length > 0) {
          await updateHeaderFields({
            id: editingRecordId,
            fieldValues,
          })
        }
        // Update system columns
        await updateSystemColumns({
          id: editingRecordId,
          description,
          date,
          paymentMethod,
          referenceNumber: referenceNumber || undefined,
        })
        toast({
          title: "Transaction updated",
          description: "The transaction has been updated successfully.",
        })
      } else {
        // Create new record with line items, field values, and system columns
        const result = await createRecord({
          billingGroupId,
          description,
          date,
          paymentMethod,
          referenceNumber: referenceNumber || undefined,
          lineItems: lineItems.map((item) => ({
            feeId: item.feeId as Id<"billing_group_fees">,
            amount: item.amount,
            quantity: item.quantity,
          })),
          fieldValues: fieldValues.length > 0 ? fieldValues : undefined,
        })
        toast({
          title: "Transaction created",
          description: `Transaction ${result.transactionNumber} has been created.`,
        })
      }

      onClose()
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to save transaction",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Calculate total for display
  const total = lineItems.reduce(
    (sum, item) => sum + item.amount * item.quantity,
    0
  )

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-[850px] max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? "Edit Transaction" : "Create Transaction"}
          </DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Update the line items for this transaction."
              : "Add fees from the library to create a new transaction."}
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 space-y-6">
          {/* System Columns (Transaction Details) */}
          <div className="space-y-4">
            <h3 className="font-medium text-sm">Transaction Details</h3>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="date">
                  Date <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="date"
                  type="date"
                  value={date}
                  readOnly
                  disabled
                  className="bg-muted cursor-not-allowed"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="paymentMethod">
                  Payment Method <span className="text-destructive">*</span>
                </Label>
                <Select
                  value={paymentMethod}
                  onValueChange={(value: PaymentMethod) => setPaymentMethod(value)}
                  disabled={isSubmitting}
                >
                  <SelectTrigger id="paymentMethod">
                    <SelectValue placeholder="Select payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    {PAYMENT_METHODS.map((method) => (
                      <SelectItem key={method.value} value={method.value}>
                        {method.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="referenceNumber">
                  Reference Number {paymentMethod !== "Cash" && <span className="text-destructive">*</span>}
                </Label>
                <Input
                  id="referenceNumber"
                  value={referenceNumber}
                  onChange={(e) => setReferenceNumber(e.target.value)}
                  placeholder={paymentMethod !== "Cash" ? "Required for non-Cash payments" : "Optional"}
                  disabled={isSubmitting}
                />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="description">
                  Description <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Enter transaction description"
                  disabled={isSubmitting}
                />
              </div>
            </div>
            <Separator />
          </div>

          {/* Dynamic Header Fields (Custom Fields) */}
          {fields.length > 0 && (
            <div className="space-y-4">
              <h3 className="font-medium text-sm text-muted-foreground">Additional Fields</h3>
              <div className="grid gap-4 sm:grid-cols-2">
                {fields.map((field) => (
                  <div key={field._id} className="space-y-2">
                    <Label htmlFor={field._id}>
                      {field.name}
                      {field.isRequired && <span className="text-destructive ml-1">*</span>}
                    </Label>

                    {field.fieldType === "text" && (
                      <Input
                        id={field._id}
                        value={getFieldValue(field._id)}
                        onChange={(e) => setFieldValue(field._id, e.target.value)}
                        placeholder={field.placeholder || `Enter ${field.name.toLowerCase()}`}
                        disabled={isSubmitting}
                      />
                    )}

                    {field.fieldType === "number" && (
                      <Input
                        id={field._id}
                        type="number"
                        value={getFieldValue(field._id)}
                        onChange={(e) => setFieldValue(field._id, e.target.value)}
                        placeholder={field.placeholder || "0"}
                        disabled={isSubmitting}
                      />
                    )}

                    {field.fieldType === "currency" && (
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                          ₱
                        </span>
                        <Input
                          id={field._id}
                          type="number"
                          step="0.01"
                          min="0"
                          value={getFieldValue(field._id)}
                          onChange={(e) => setFieldValue(field._id, e.target.value)}
                          placeholder="0.00"
                          className="pl-7"
                          disabled={isSubmitting}
                        />
                      </div>
                    )}

                    {field.fieldType === "date" && (
                      <Input
                        id={field._id}
                        type="date"
                        value={getFieldValue(field._id)}
                        onChange={(e) => setFieldValue(field._id, e.target.value)}
                        disabled={isSubmitting}
                      />
                    )}

                    {field.fieldType === "dropdown" && (
                      <Popover
                        open={openDropdowns[field._id] || false}
                        onOpenChange={(open) => setOpenDropdowns(prev => ({ ...prev, [field._id]: open }))}
                      >
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            role="combobox"
                            disabled={isSubmitting}
                            className={cn(
                              "w-full justify-between",
                              !getFieldValue(field._id) && "text-muted-foreground"
                            )}
                          >
                            {getFieldValue(field._id) || field.placeholder || `Select ${field.name.toLowerCase()}`}
                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-full p-0" align="start">
                          <Command>
                            <CommandInput placeholder={`Search ${field.name.toLowerCase()}...`} />
                            <CommandList>
                              <CommandEmpty>No options found.</CommandEmpty>
                              <CommandGroup>
                                {field.options?.map((option) => (
                                  <CommandItem
                                    key={option}
                                    value={option}
                                    onSelect={() => {
                                      setFieldValue(field._id, option)
                                      setOpenDropdowns(prev => ({ ...prev, [field._id]: false }))
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        getFieldValue(field._id) === option ? "opacity-100" : "opacity-0"
                                      )}
                                    />
                                    {option}
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                    )}

                    {field.fieldType === "checkbox" && (
                      <div className="flex items-center space-x-2 pt-2">
                        <Checkbox
                          id={field._id}
                          checked={getFieldValue(field._id) === "true"}
                          onCheckedChange={(checked) =>
                            setFieldValue(field._id, checked ? "true" : "false")
                          }
                          disabled={isSubmitting}
                        />
                        <label
                          htmlFor={field._id}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {field.placeholder || field.name}
                        </label>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              <Separator />
            </div>
          )}

          {/* Line Items */}
          <LineItemEditor
            billingGroupId={billingGroupId}
            lineItems={lineItems}
            onChange={setLineItems}
            maxLineItems={maxLineItems}
            feeFields={feeFieldsData as FeeField[] | undefined}
            disabled={isSubmitting}
          />
        </div>

        <DialogFooter className="flex items-center justify-between sm:justify-between">
          <div className="text-sm">
            <span className="text-muted-foreground">
              {lineItems.length} item{lineItems.length !== 1 ? "s" : ""}
            </span>
            {total > 0 && (
              <span className="ml-3 font-medium">
                Total: {new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" }).format(total)}
              </span>
            )}
          </div>
          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="button"
              onClick={handleSubmit}
              disabled={isSubmitting || lineItems.length === 0}
            >
              {isSubmitting
                ? "Saving..."
                : isEditing
                  ? "Save Changes"
                  : "Create Transaction"}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
