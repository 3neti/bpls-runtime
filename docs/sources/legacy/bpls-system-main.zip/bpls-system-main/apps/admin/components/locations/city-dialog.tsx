"use client";

import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@repo/ui/components/form";
import { Input } from "@repo/ui/components/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select";
import { Button } from "@repo/ui/components/button";
import { toast } from "sonner";
import type { City } from "@/lib/types/location";
import type { Id } from "@repo/backend/convex/_generated/dataModel";

const citySchema = z.object({
  name: z.string().min(1, "City/Municipality name is required"),
  provinceId: z.string().min(1, "Province is required"),
  code: z.string().optional(),
});

type CityFormValues = z.infer<typeof citySchema>;

interface CityDialogProps {
  mode: "create" | "edit";
  city?: City;
  provinceId?: string;
  provinceName?: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export function CityDialog({ mode, city, provinceId, provinceName, open, onOpenChange, onSuccess }: CityDialogProps) {
  const provinces = useQuery(api.locations.listProvinces);
  const createCity = useMutation(api.locations.createCity);
  const updateCity = useMutation(api.locations.updateCity);

  const form = useForm<CityFormValues>({
    resolver: zodResolver(citySchema),
    defaultValues: {
      name: "",
      provinceId: "",
      code: "",
    },
  });

  // Reset form values when dialog opens or props change
  useEffect(() => {
    if (open) {
      form.reset({
        name: city?.name || "",
        provinceId: provinceId || (city?.provinceId as string) || "",
        code: city?.code || "",
      });
    }
  }, [open, city, provinceId, form]);

  // Determine if we're adding a child location (province is pre-selected)
  const isAddingChild = mode === "create" && provinceId && provinceName;

  const onSubmit = async (values: CityFormValues) => {
    try {
      if (mode === "create") {
        await createCity({
          name: values.name,
          provinceId: values.provinceId as Id<"provinces">,
          code: values.code || undefined,
        });
        toast.success("City/Municipality created successfully");
      } else {
        if (!city?._id) {
          toast.error("City ID is missing");
          return;
        }
        await updateCity({
          id: city._id as Id<"cities">,
          name: values.name,
          provinceId: values.provinceId as Id<"provinces">,
          code: values.code || undefined,
        });
        toast.success("City/Municipality updated successfully");
      }
      form.reset();
      onOpenChange(false);
      onSuccess?.();
    } catch (error) {
      toast.error(mode === "create" ? "Failed to create city/municipality" : "Failed to update city/municipality");
      console.error(error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{mode === "create" ? "Add City/Municipality" : "Edit City/Municipality"}</DialogTitle>
          <DialogDescription>
            {mode === "create"
              ? "Add a new city or municipality to the location hierarchy."
              : "Update city/municipality information."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="provinceId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    Province <span className="text-destructive">*</span>
                  </FormLabel>
                  {isAddingChild ? (
                    <FormControl>
                      <Input
                        value={provinceName}
                        disabled
                        className="bg-muted text-muted-foreground cursor-not-allowed"
                      />
                    </FormControl>
                  ) : (
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select province" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {provinces?.map((province: NonNullable<typeof provinces>[number]) => (
                          <SelectItem key={province._id} value={province._id}>
                            {province.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    City/Municipality Name <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g., Ipil" autoFocus={Boolean(isAddingChild)} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="code"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>PSGC Code </FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g., 097232000" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting
                  ? mode === "create"
                    ? "Creating..."
                    : "Updating..."
                  : mode === "create"
                    ? "Create City/Municipality"
                    : "Update City/Municipality"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
