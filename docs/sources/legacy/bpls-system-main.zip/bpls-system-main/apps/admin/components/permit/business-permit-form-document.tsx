"use client";

import React from "react";
import { Document, Page, Text, View, StyleSheet, Image } from "@react-pdf/renderer";

import type {
  BusinessPermitFormData,
  BusinessActivity,
  AssessmentItem,
  VerificationDocument,
} from "./application-form-pdf";

// Styles
const styles = StyleSheet.create({
  page: {
    padding: 15,
    fontSize: 8,
    fontFamily: "Helvetica",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 5,
  },
  municipalSeal: {
    width: 50,
    height: 50,
    marginRight: 5,
    objectFit: "contain",
  },
  headerText: {
    textAlign: "center",
  },
  headerTitle: {
    fontSize: 12,
    fontWeight: "bold",
    marginBottom: 2,
  },
  headerSubtitle: {
    fontSize: 10,
    marginBottom: 2,
  },
  applicationNoBox: {
    position: "absolute",
    right: 20,
    top: 20,
    border: "1pt solid black",
    padding: 5,
    minWidth: 80,
  },
  applicationNoLabel: {
    fontSize: 7,
    textAlign: "center",
  },
  applicationNoValue: {
    fontSize: 9,
    textAlign: "center",
    marginTop: 3,
  },
  section: {
    marginBottom: 5,
  },
  sectionTitle: {
    fontSize: 9,
    fontWeight: "bold",
    marginBottom: 3,
    backgroundColor: "#1a365d",
    color: "white",
    padding: 3,
  },
  row: {
    flexDirection: "row",
    marginBottom: 1,
  },
  col: {
    flex: 1,
  },
  checkbox: {
    width: 8,
    height: 8,
    border: "1pt solid black",
    marginRight: 2,
    justifyContent: "center",
    alignItems: "center",
  },
  checkboxChecked: {
    width: 8,
    height: 8,
    border: "1pt solid black",
    marginRight: 2,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#000",
  },
  checkmark: {
    fontSize: 6,
    color: "white",
  },
  checkboxLabel: {
    fontSize: 6,
    marginRight: 8,
  },
  checkboxRow: {
    flexDirection: "row",
    alignItems: "center",
    marginRight: 10,
    marginBottom: 1,
  },
  table: {
    border: "1pt solid black",
    marginTop: 3,
  },
  tableRow: {
    flexDirection: "row",
    borderBottom: "0.5pt solid black",
  },
  tableRowLast: {
    flexDirection: "row",
  },
  tableHeader: {
    backgroundColor: "#e2e8f0",
    fontWeight: "bold",
  },
  tableCell: {
    padding: 4,
    borderRight: "0.5pt solid black",
    fontSize: 6,
    minHeight: 14,
  },
  tableCellLast: {
    padding: 4,
    fontSize: 6,
    minHeight: 14,
  },
  fieldRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 1,
    borderBottom: "0.5pt solid #ccc",
    paddingBottom: 1,
  },
  fieldLabel: {
    fontSize: 6,
    width: 100,
    color: "#333",
  },
  fieldValue: {
    flex: 1,
    fontSize: 7,
    minHeight: 10,
    paddingLeft: 3,
  },
  introText: {
    fontSize: 7,
    marginBottom: 5,
    textAlign: "justify",
    lineHeight: 1.3,
  },
  twoColumn: {
    flexDirection: "row",
    gap: 5,
  },
  columnBox: {
    flex: 1,
    border: "0.5pt solid #ccc",
    padding: 3,
  },
  columnTitle: {
    fontSize: 7,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 2,
    backgroundColor: "#f0f0f0",
    padding: 2,
  },
  oathText: {
    fontSize: 6,
    fontStyle: "italic",
    marginTop: 3,
    marginBottom: 2,
  },
  signatureRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 3,
  },
  signatureBox: {
    width: "40%",
    textAlign: "center",
  },
  signatureLine: {
    borderTop: "1pt solid black",
    marginTop: 12,
    paddingTop: 2,
    fontSize: 6,
  },
  approvalText: {
    fontSize: 6,
    textAlign: "justify",
    marginTop: 5,
    marginBottom: 3,
    lineHeight: 1.3,
  },
  mayorSection: {
    marginTop: 8,
    textAlign: "center",
  },
  mayorName: {
    fontSize: 9,
    fontWeight: "bold",
    marginTop: 12,
  },
  mayorTitle: {
    fontSize: 7,
  },
  instructions: {
    marginTop: 3,
    padding: 3,
    backgroundColor: "#f9f9f9",
    border: "0.5pt solid #ccc",
  },
  instructionTitle: {
    fontSize: 7,
    fontWeight: "bold",
    marginBottom: 2,
  },
  instructionText: {
    fontSize: 6,
    marginBottom: 1,
  },
});

// Checkbox Component
const Checkbox: React.FC<{ checked?: boolean; label: string }> = ({ checked, label }) => (
  <View style={styles.checkboxRow}>
    <View style={checked ? styles.checkboxChecked : styles.checkbox}>
      {checked && <Text style={styles.checkmark}>✓</Text>}
    </View>
    <Text style={styles.checkboxLabel}>{label}</Text>
  </View>
);

// Field Row Component
const FieldRow: React.FC<{
  label: string;
  value?: string;
  labelWidth?: number;
}> = ({ label, value, labelWidth }) => (
  <View style={styles.fieldRow}>
    <Text style={[styles.fieldLabel, labelWidth ? { width: labelWidth } : {}]}>{label}</Text>
    <Text style={styles.fieldValue}>{value || ""}</Text>
  </View>
);

// Default values for settings - generic titles only, names/locations must be configured
const DEFAULT_MAYOR_TITLE = "Municipal Mayor";

// Main Component
export const BusinessPermitFormDocument: React.FC<{
  data?: BusinessPermitFormData;
}> = ({ data = {} }) => {
  // Extract settings - values must be configured via platform settings
  const municipalityName = data.municipalityName || "";
  const municipalityShortName = data.municipalityShortName || "";
  const provinceName = data.provinceName || "";
  const municipalSealUrl = data.municipalSealUrl || "";
  const mayorName = data.mayorName || "";
  const mayorTitle = data.mayorTitle || DEFAULT_MAYOR_TITLE;
  // Static 10 blank rows for Lines of Business table
  const activities: BusinessActivity[] = Array.from({ length: 10 }, () => ({
    code: "",
    lineOfBusiness: "",
    noOfUnits: "",
    capitalization: "",
    grossSalesEssential: "",
    grossSalesNonEssential: "",
  }));

  const defaultAssessments: AssessmentItem[] = [
    { description: "BUSINESS TAX" },
    { description: "MAYORS PERMIT FEE" },
    { description: "SOLIDWASTE MANAGEMENT FEE" },
    { description: "SANITARY PERMIT FEE" },
    { description: "HEALTH CERTIFICATE" },
    { description: "OCCUPATIONAL CALLING" },
    { description: "LAMINATED ID" },
  ];

  const assessments = data.assessments && data.assessments.length > 0 ? data.assessments : defaultAssessments;

  const defaultVerificationDocs: VerificationDocument[] = [
    { description: "Barangay Clearance", issuingOffice: "Barangay" },
    { description: "Zoning Clearance (New/Renew)", issuingOffice: "MPDO/Zoning" },
    {
      description: "Building Permit/Occupancy Permit (New/Renew)",
      issuingOffice: "Mun. Engineering",
    },
  ];

  const verificationDocs =
    data.verificationDocuments && data.verificationDocuments.length > 0
      ? data.verificationDocuments
      : defaultVerificationDocs;

  return (
    <Document>
      {/* Page 1 */}
      <Page size="A4" style={styles.page}>
        {/* Header */}
        <View style={styles.header}>
          <Image style={styles.municipalSeal} src={municipalSealUrl} />
          <View style={styles.headerText}>
            <Text style={styles.headerTitle}>APPLICATION FORM FOR BUSINESS PERMIT</Text>
            <Text style={styles.headerSubtitle}>TAX YEAR: {data.taxYear || "_______"}</Text>
            <Text style={styles.headerSubtitle}>{municipalityName}</Text>
          </View>
        </View>

        {/* Application No Box */}
        <View style={styles.applicationNoBox}>
          <Text style={styles.applicationNoLabel}>Application No.</Text>
          <Text style={styles.applicationNoValue}>{data.applicationNo || ""}</Text>
        </View>

        {/* Introduction */}
        <Text style={styles.introText}>
          The Honorable Mayor:{"\n"}
          {"    "}Pursuant to the Revenue Code of the {municipalityName.replace("MUNICIPALITY OF ", "Municipality of ")}
          , Province of {provinceName}, I have the honor to apply for BUSINESS/MAYOR&apos;S PERMIT to conduct/operate at{" "}
          {municipalityShortName}, {provinceName}, subject to existing laws and ordinances.
        </Text>

        {/* Application Type, Amendment, Mode of Payment */}
        <View style={[styles.row, { marginBottom: 5 }]}>
          {/* Application Type */}
          <View style={styles.col}>
            <Checkbox checked={data.isNew} label="New" />
            <Checkbox checked={data.isRenew} label="Renew" />
            <Checkbox checked={data.isAdditional} label="Additional" />
            <View style={{ marginTop: 2 }}>
              <Text style={{ fontSize: 6, fontWeight: "bold" }}>Transfer</Text>
              <Checkbox checked={data.transferOwnership} label="Ownership" />
              <Checkbox checked={data.transferLocation} label="Location" />
            </View>
          </View>

          {/* Amendment */}
          <View style={styles.col}>
            <Text style={{ fontSize: 6, fontWeight: "bold", marginBottom: 1 }}>Amendment</Text>
            <Checkbox checked={data.amendmentFromSingleToPartnership} label="From Single to Partnership" />
            <Checkbox checked={data.amendmentFromSingleToCorporation} label="From Single to Corporation" />
            <Checkbox checked={data.amendmentFromPartnershipToSingle} label="From Partnership to Single" />
            <Checkbox checked={data.amendmentFromPartnershipToCorporation} label="From Partnership to Corporation" />
            <Checkbox checked={data.amendmentFromCorporationToSingle} label="From Corporation to Single" />
            <Checkbox checked={data.amendmentFromCorporationToPartnership} label="From Corporation to Partnership" />
          </View>

          {/* Mode of Payment */}
          <View style={styles.col}>
            <Text style={{ fontSize: 6, fontWeight: "bold", marginBottom: 1 }}>Mode of Payment</Text>
            <Checkbox checked={data.paymentAnnually} label="Annually" />
            <Checkbox checked={data.paymentSemiAnnually} label="Semi-Annually" />
            <Checkbox checked={data.paymentQuarterly} label="Quarterly" />
          </View>
        </View>

        {/* Registration Info */}
        <View style={styles.row}>
          <View style={[styles.col, { marginRight: 10 }]}>
            <FieldRow label="Date of Application:" value={data.dateOfApplication} />
          </View>
          <View style={styles.col}>
            <FieldRow label="DTI/SEC/CDA Registration No:" value={data.dtiSecCdaRegistrationNo} />
          </View>
        </View>

        <View style={styles.row}>
          <View style={[styles.col, { marginRight: 10 }]}>
            <FieldRow label="Reference No:" value={data.referenceNo} />
          </View>
          <View style={styles.col}>
            <FieldRow label="DTI/SEC/CDA Date of Registration:" value={data.dtiSecCdaDateOfRegistration} />
          </View>
        </View>

        {/* Organization Type */}
        <View style={[styles.row, { marginTop: 2, marginBottom: 2 }]}>
          <Text style={{ fontSize: 6, marginRight: 3 }}>Type of Organization:</Text>
          <Checkbox checked={data.isSingle} label="Single" />
          <Checkbox checked={data.isPartnership} label="Partnership" />
          <Checkbox checked={data.isCorporation} label="Corporation" />
          <Checkbox checked={data.isCooperative} label="Cooperative" />
          <Checkbox checked={data.isNonProfit} label="Non-profit Organization" />
        </View>

        <View style={styles.row}>
          <View style={[styles.col, { marginRight: 10 }]}>
            <FieldRow label="CTC No.:" value={data.ctcNo} />
          </View>
          <View style={styles.col}>
            <FieldRow label="TIN:" value={data.tin} />
          </View>
        </View>

        {/* Tax Incentive */}
        <View style={[styles.row, { marginTop: 2, marginBottom: 2 }]}>
          <Text style={{ fontSize: 6, marginRight: 3 }}>
            Are you enjoying tax incentive from any Government Entity?
          </Text>
          <Checkbox checked={data.hasTaxIncentive === true} label="Yes" />
          <Checkbox checked={data.hasTaxIncentive === false} label="No" />
          <Text style={{ fontSize: 6, marginLeft: 5 }}>
            Please specify the entity: {data.taxIncentiveEntity || "________________"}
          </Text>
        </View>

        {/* Taxpayer Name */}
        <Text style={{ fontSize: 6, fontWeight: "bold", marginTop: 2 }}>Name of Tax Payer:</Text>
        <View style={styles.row}>
          <View style={[styles.col, { marginRight: 5 }]}>
            <FieldRow label="Last Name:" value={data.taxpayerLastName} />
          </View>
          <View style={[styles.col, { marginRight: 5 }]}>
            <FieldRow label="First Name:" value={data.taxpayerFirstName} />
          </View>
          <View style={styles.col}>
            <FieldRow label="Middle Name:" value={data.taxpayerMiddleName} />
          </View>
        </View>

        <FieldRow label="Business Name:" value={data.businessName} />
        <FieldRow label="Business Plate No.:" value={data.businessPlateNo} />
        <FieldRow label="Trade Name/Franchise:" value={data.tradeName} />

        {/* Corporation President/Treasurer */}
        <Text style={{ fontSize: 6, fontWeight: "bold", marginTop: 2 }}>
          Name of President/Treasurer of Corporation:
        </Text>
        <View style={styles.row}>
          <View style={[styles.col, { marginRight: 5 }]}>
            <FieldRow label="Last Name:" value={data.presidentLastName} />
          </View>
          <View style={[styles.col, { marginRight: 5 }]}>
            <FieldRow label="First Name:" value={data.presidentFirstName} />
          </View>
          <View style={styles.col}>
            <FieldRow label="Middle Name:" value={data.presidentMiddleName} />
          </View>
        </View>

        {/* Address Section */}
        <View style={styles.twoColumn}>
          {/* Business Address */}
          <View style={styles.columnBox}>
            <Text style={styles.columnTitle}>Business Address</Text>
            <FieldRow label="House No./Bldg. No.:" value={data.businessHouseNo} labelWidth={80} />
            <FieldRow label="Building Name:" value={data.businessBuildingName} labelWidth={80} />
            <FieldRow label="Unit No.:" value={data.businessUnitNo} labelWidth={80} />
            <FieldRow label="Street:" value={data.businessStreet} labelWidth={80} />
            <FieldRow label="Barangay:" value={data.businessBarangay} labelWidth={80} />
            <FieldRow label="Subdivision:" value={data.businessSubdivision} labelWidth={80} />
            <FieldRow label="City/Municipality:" value={data.businessCityMunicipality} labelWidth={80} />
            <FieldRow label="Province:" value={data.businessProvince} labelWidth={80} />
            <FieldRow label="Tel. No.:" value={data.businessTelNo} labelWidth={80} />
            <FieldRow label="Email Address:" value={data.businessEmailAddress} labelWidth={80} />
          </View>

          {/* Owner's Address */}
          <View style={styles.columnBox}>
            <Text style={styles.columnTitle}>Owner&apos;s Address</Text>
            <FieldRow label="House No./Bldg. No.:" value={data.ownerHouseNo} labelWidth={80} />
            <FieldRow label="Building Name:" value={data.ownerBuildingName} labelWidth={80} />
            <FieldRow label="Unit No.:" value={data.ownerUnitNo} labelWidth={80} />
            <FieldRow label="Street:" value={data.ownerStreet} labelWidth={80} />
            <FieldRow label="Barangay:" value={data.ownerBarangay} labelWidth={80} />
            <FieldRow label="Subdivision:" value={data.ownerSubdivision} labelWidth={80} />
            <FieldRow label="City/Municipality:" value={data.ownerCityMunicipality} labelWidth={80} />
            <FieldRow label="Province:" value={data.ownerProvince} labelWidth={80} />
            <FieldRow label="Tel. No.:" value={data.ownerTelNo} labelWidth={80} />
            <FieldRow label="Email Address:" value={data.ownerEmailAddress} labelWidth={80} />
          </View>
        </View>

        {/* Property Info */}
        <View style={[styles.row, { marginTop: 2 }]}>
          <View style={[styles.col, { marginRight: 5 }]}>
            <FieldRow label="Property Index Number (PIN):" value={data.propertyIndexNumber} />
          </View>
        </View>

        <View style={styles.row}>
          <View style={[styles.col, { marginRight: 5 }]}>
            <FieldRow label="Business Area (in sq m):" value={data.businessAreaSqm} />
          </View>
          <View style={[styles.col, { marginRight: 5 }]}>
            <FieldRow label="Total No. of Employees:" value={data.totalEmployees} />
          </View>
          <View style={styles.col}>
            <FieldRow label="Employees Residing in LGU:" value={data.employeesInLgu} />
          </View>
        </View>

        {/* Rental Info */}
        <Text style={{ fontSize: 6, fontWeight: "bold", marginTop: 2 }}>
          If Place of Business is Rented, please identify the following:
        </Text>
        <View style={styles.row}>
          <View style={[styles.col, { marginRight: 5 }]}>
            <FieldRow label="Monthly Rental:" value={data.monthlyRental} />
          </View>
        </View>
        <View style={styles.row}>
          <View style={[styles.col, { marginRight: 5 }]}>
            <FieldRow label="Last Name:" value={data.lessor?.lastName} />
          </View>
          <View style={[styles.col, { marginRight: 5 }]}>
            <FieldRow label="First Name:" value={data.lessor?.firstName} />
          </View>
          <View style={styles.col}>
            <FieldRow label="Middle Name:" value={data.lessor?.middleName} />
          </View>
        </View>

        <Text style={{ fontSize: 6 }}>Lessor&apos;s Address:</Text>
        <View style={styles.row}>
          <View style={[styles.col, { marginRight: 5 }]}>
            <FieldRow label="House No./Bldg. No.:" value={data.lessor?.houseNo} labelWidth={80} />
            <FieldRow label="Street:" value={data.lessor?.street} labelWidth={80} />
            <FieldRow label="Barangay:" value={data.lessor?.barangay} labelWidth={80} />
            <FieldRow label="Subdivision:" value={data.lessor?.subdivision} labelWidth={80} />
          </View>
          <View style={styles.col}>
            <FieldRow label="City/Municipality:" value={data.lessor?.cityMunicipality} labelWidth={80} />
            <FieldRow label="Province:" value={data.lessor?.province} labelWidth={80} />
            <FieldRow label="Tel. No.:" value={data.lessor?.telNo} labelWidth={80} />
            <FieldRow label="Email Address:" value={data.lessor?.emailAddress} labelWidth={80} />
          </View>
        </View>

        {/* Emergency Contact */}
        <View style={[styles.row, { marginTop: 2 }]}>
          <FieldRow
            label="In case of Emergency - Contact Person/Tel No./Mobile Phone No./Email Address:"
            value={data.emergencyContact}
          />
        </View>

        {/* Business Activity Table */}
        <View style={styles.table}>
          <View style={[styles.tableRow, styles.tableHeader]}>
            <Text style={[styles.tableCell, { width: 40 }]}>Code</Text>
            <Text style={[styles.tableCell, { flex: 1 }]}>Line of Business</Text>
            <Text style={[styles.tableCell, { width: 50 }]}>No. of Units</Text>
            <Text style={[styles.tableCell, { width: 70 }]}>Capitalization{"\n"}(for new business)</Text>
            <Text style={[styles.tableCell, { width: 60 }]}>Gross Sales{"\n"}Essential</Text>
            <Text style={[styles.tableCellLast, { width: 60 }]}>Gross Sales{"\n"}Non-Essential</Text>
          </View>
          {activities.map((activity, index) => (
            <View key={index} style={index === activities.length - 1 ? styles.tableRowLast : styles.tableRow}>
              <Text style={[styles.tableCell, { width: 40 }]}>{activity.code}</Text>
              <Text style={[styles.tableCell, { flex: 1 }]}>{activity.lineOfBusiness}</Text>
              <Text style={[styles.tableCell, { width: 50 }]}>{activity.noOfUnits || ""}</Text>
              <Text style={[styles.tableCell, { width: 70 }]}>{activity.capitalization || ""}</Text>
              <Text style={[styles.tableCell, { width: 60 }]}>{activity.grossSalesEssential || ""}</Text>
              <Text style={[styles.tableCellLast, { width: 60 }]}>{activity.grossSalesNonEssential || ""}</Text>
            </View>
          ))}
        </View>

        {/* Oath */}
        <Text style={[styles.oathText, { marginTop: 3, marginBottom: 2 }]}>
          Oath of Undertaking: I undertake to comply with the regulatory requirement and other deficiencies within 30
          days from release of the business permit
        </Text>

        {/* Signature */}
        <View style={[styles.signatureRow, { marginTop: 3 }]}>
          <View style={styles.signatureBox}>
            <Text style={[styles.signatureLine, { marginTop: 10 }]}>SIGNATURE OF APPLICANT OVER PRINTED NAME</Text>
          </View>
          <View style={styles.signatureBox}>
            <Text style={[styles.signatureLine, { marginTop: 10 }]}>POSITION/TITLE</Text>
          </View>
        </View>
      </Page>

      {/* Page 2 - Assessments and Approval */}
      <Page size="A4" style={styles.page}>
        {/* Assessments Section */}
        <Text style={styles.sectionTitle}>ASSESSMENTS</Text>
        <View style={styles.table}>
          <View style={[styles.tableRow, styles.tableHeader]}>
            <Text style={[styles.tableCell, { flex: 2 }]}>LOCAL TAXES</Text>
            <Text style={[styles.tableCell, { width: 60 }]}>REFERENCE</Text>
            <Text style={[styles.tableCell, { width: 60 }]}>AMOUNT DUE</Text>
            <Text style={[styles.tableCell, { width: 60 }]}>PENALTY/{"\n"}SURCHARGE</Text>
            <Text style={[styles.tableCell, { width: 50 }]}>TOTAL</Text>
            <Text style={[styles.tableCellLast, { width: 60 }]}>ASSESSED BY</Text>
          </View>
          {assessments.map((item, index) => (
            <View key={index} style={index === assessments.length - 1 ? styles.tableRowLast : styles.tableRow}>
              <Text style={[styles.tableCell, { flex: 2 }]}>{item.description}</Text>
              <Text style={[styles.tableCell, { width: 60 }]}>{item.reference || ""}</Text>
              <Text style={[styles.tableCell, { width: 60 }]}>{item.amountDue || ""}</Text>
              <Text style={[styles.tableCell, { width: 60 }]}>{item.penaltySurcharge || ""}</Text>
              <Text style={[styles.tableCell, { width: 50 }]}>{item.total || ""}</Text>
              <Text style={[styles.tableCellLast, { width: 60 }]}>{item.assessedBy || ""}</Text>
            </View>
          ))}
        </View>

        {/* Verification of Documents */}
        <Text style={[styles.sectionTitle, { marginTop: 3 }]}>VERIFICATION OF DOCUMENTS</Text>
        <View style={styles.table}>
          <View style={[styles.tableRow, styles.tableHeader]}>
            <Text style={[styles.tableCell, { flex: 2 }]}>Description</Text>
            <Text style={[styles.tableCell, { width: 80 }]}>Issuing Office/{"\n"}Agency</Text>
            <Text style={[styles.tableCell, { width: 80 }]}>Recommending{"\n"}Approval</Text>
            <Text style={[styles.tableCell, { width: 60 }]}>Date Issued</Text>
            <Text style={[styles.tableCellLast, { width: 80 }]}>Verified by:{"\n"}BPLO/BPLO Staff</Text>
          </View>
          {verificationDocs.map((doc, index) => (
            <View key={index} style={index === verificationDocs.length - 1 ? styles.tableRowLast : styles.tableRow}>
              <Text style={[styles.tableCell, { flex: 2 }]}>{doc.description}</Text>
              <Text style={[styles.tableCell, { width: 80 }]}>{doc.issuingOffice || ""}</Text>
              <Text style={[styles.tableCell, { width: 80 }]}>{doc.recommendingApproval || ""}</Text>
              <Text style={[styles.tableCell, { width: 60 }]}>{doc.dateIssued || ""}</Text>
              <Text style={[styles.tableCellLast, { width: 80 }]}>{doc.verifiedBy || ""}</Text>
            </View>
          ))}
        </View>

        {/* Review and Approval */}
        <View style={[styles.signatureRow, { marginTop: 3 }]}>
          <View style={styles.signatureBox}>
            <Text style={{ fontSize: 6, marginBottom: 8 }}>{data.assessmentReviewedBy || ""}</Text>
            <Text style={[styles.signatureLine, { marginTop: 10 }]}>Assessment Reviewed by:</Text>
          </View>
          <View style={styles.signatureBox}>
            <Text style={{ fontSize: 6, marginBottom: 8 }}>{data.approvalRecommendedBy || ""}</Text>
            <Text style={[styles.signatureLine, { marginTop: 10 }]}>Approval Recommended by:</Text>
          </View>
        </View>

        {/* Instructions */}
        <View style={[styles.instructions, { marginTop: 3, padding: 2 }]}>
          <Text style={styles.instructionTitle}>Instruction:</Text>
          <Text style={styles.instructionText}>
            1. Provide accurate information and print legibly to avoid delays. Incomplete form will be returned to the
            applicant
          </Text>
          <Text style={styles.instructionText}>
            2. Ensure that all documents attached to this application form are complete and properly filled out.
          </Text>
        </View>

        {/* Approval Text */}
        <Text style={[styles.approvalText, { marginTop: 3, marginBottom: 2 }]}>
          {"    "}Pursuant to Section 444 b.3iv of RA 7160, otherwise known as the Local Government Code of 1991, PERMIT
          is hereby granted to the person above to engage in business or occupation, PROVIDED, that the corresponding
          Permit Fee/s and Municipal Licenses Fee/s shall be paid in the Office of the Municipal Treasurer prior to the
          operation of the business, SUBJECT HOWEVER, to cancellation of the license, or prosecution in the court or
          both if the applicant made false statements with regard to this business, trade or occupation with intent to
          procure a license that is contrary to the provision of 11-29-2011 ordinance and/or local regulations provided
          in the ordinance mentioned above.
        </Text>

        <Text style={{ fontSize: 6 }}>
          {"    "}Granted this {data.grantedDay || "_______________"} day of {data.grantedMonth || "__________________"}
          , 20{data.grantedYear || "____"} at {municipalityShortName}, {provinceName}, presenting to me his/her CTC No.{" "}
          {data.grantedCtcNo || "___________________"} issued on {data.grantedCtcIssuedOn || "____________________"} at{" "}
          {data.grantedCtcIssuedAt || "____________________________"}.
        </Text>

        {/* Mayor Section */}
        <View style={[styles.mayorSection, { marginTop: 25 }]}>
          <Text style={[styles.mayorName, { marginTop: 10 }]}>{mayorName}</Text>
          <Text style={styles.mayorTitle}>{mayorTitle}</Text>
        </View>
      </Page>
    </Document>
  );
};
