"use client";

import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import {
  RotateCcw,
  Lock,
  Loader2,
} from "lucide-react";
import { usePermissions } from "@/hooks/use-permissions";

import { Button } from "@repo/ui/components/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog";
import { Badge } from "@repo/ui/components/badge";
import { api } from "@repo/backend/convex/_generated/api";
import { PermitLayoutEditor } from "@/components/permit-layout/permit-layout-editor";

interface PermitLayoutSectionProps {
  toast: (props: {
    title: string;
    description?: string;
    variant?: "default" | "destructive";
  }) => void;
}

export function PermitLayoutSection({ toast }: PermitLayoutSectionProps) {
  const { canUpdate, isLoading: permissionsLoading } = usePermissions();
  const canEdit = canUpdate("settings:permit_layout");

  const layout = useQuery(api.permitLayouts.get);
  const initializeLayout = useMutation(api.permitLayouts.initialize);
  const resetLayout = useMutation(api.permitLayouts.resetToDefault);

  // Dialog states
  const [resetDialogOpen, setResetDialogOpen] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);

  const isLoading = layout === undefined;

  // Initialize layout if it doesn't exist
  useEffect(() => {
    if (layout === null && !isInitializing) {
      setIsInitializing(true);
      initializeLayout({})
        .then(() => {
          setIsInitializing(false);
        })
        .catch((error) => {
          console.error("Failed to initialize permit layout:", error);
          setIsInitializing(false);
          toast({
            title: "Error",
            description: "Failed to initialize permit layout",
            variant: "destructive",
          });
        });
    }
  }, [layout, isInitializing, initializeLayout, toast]);

  // Reset to default
  const handleReset = async () => {
    try {
      await resetLayout({});
      toast({
        title: "Layout reset",
        description: "The permit layout has been reset to default values.",
      });
      setResetDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to reset layout",
        variant: "destructive",
      });
    }
  };

  // Loading state
  if (isLoading || isInitializing) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Permit Layout</CardTitle>
          <CardDescription>
            Configure the business permit document design.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  // Layout should exist by now (auto-initialized)
  if (!layout) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Permit Layout</CardTitle>
          <CardDescription>
            Configure the business permit document design.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center py-12">
          <p className="text-muted-foreground">Initializing layout...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                Permit Layout
                {!canEdit && !permissionsLoading && (
                  <Badge variant="secondary" className="ml-2 gap-1">
                    <Lock className="h-3 w-3" />
                    Read Only
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>
                Customize the business permit document using templates with macros
                like {"{{permitNumber}}"} for dynamic content.
              </CardDescription>
            </div>
            {canEdit && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setResetDialogOpen(true)}
              >
                <RotateCcw className="mr-2 h-4 w-4" />
                Reset to Default
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-[calc(100vh-280px)] min-h-[600px]">
            <PermitLayoutEditor
              onSave={() => {
                toast({
                  title: "Layout saved",
                  description: "Your changes have been saved.",
                });
              }}
              readOnly={!canEdit}
            />
          </div>
        </CardContent>
      </Card>

      {/* Reset Confirmation Dialog */}
      <AlertDialog open={resetDialogOpen} onOpenChange={setResetDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reset Permit Layout</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to reset the permit layout to default values?
              This will overwrite all your customizations.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleReset}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Reset to Default
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
