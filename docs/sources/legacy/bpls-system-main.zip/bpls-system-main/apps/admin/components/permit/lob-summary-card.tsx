/**
 * LOBSummaryCard Component
 *
 * A minimal read-only display component for Lines of Business declaration.
 * Used in the releasing detail page to show LOB configuration without edit capabilities.
 *
 * Features:
 * - Displays each LOB with category name, type badge, and financial info
 * - Shows total fees for each LOB
 * - Compact card format
 */

"use client";

import { Briefcase, TrendingUp, DollarSign } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card";
import { Badge } from "@repo/ui/components/badge";
import { formatCurrency } from "@/lib/utils/formatting";

interface LineOfBusiness {
  businessCategory: string;
  capitalInvestment?: string;
  grossSales?: string;
  permitApplicationType: string;
  numberOfEmployees?: number;
}

interface LOBSummaryCardProps {
  /** Array of lines of business to display */
  linesOfBusiness: LineOfBusiness[];
  /** Total calculated fees */
  totalFees?: number;
}

export function LOBSummaryCard({
  linesOfBusiness,
  totalFees,
}: LOBSummaryCardProps) {
  const hasLobs = linesOfBusiness && linesOfBusiness.length > 0;

  /**
   * Format currency with symbol, returning null for empty/zero values
   */
  const formatCurrencyDisplay = (value: string | number | undefined): string | null => {
    if (!value) return null;
    const num = typeof value === "string" ? parseFloat(value) : value;
    if (isNaN(num) || num === 0) return null;
    return formatCurrency(num, { withSymbol: true });
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base">
            <Briefcase className="h-4 w-4" />
            Lines of Business
          </CardTitle>
          {hasLobs && (
            <Badge variant="secondary" className="text-xs">
              {linesOfBusiness.length} {linesOfBusiness.length === 1 ? "LOB" : "LOBs"}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {!hasLobs ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            No lines of business declared
          </p>
        ) : (
          <>
            {linesOfBusiness.map((lob, index) => {
              const isNew = lob.permitApplicationType === "New";
              const isRenewal = lob.permitApplicationType === "Renewal";
              const capitalAmount = formatCurrencyDisplay(lob.capitalInvestment);
              const grossAmount = formatCurrencyDisplay(lob.grossSales);

              return (
                <div
                  key={`${lob.businessCategory}-${index}`}
                  className="p-3 bg-muted/40 rounded-lg space-y-2"
                >
                  {/* Header: Category Name + Type Badge */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-medium text-sm">
                      {lob.businessCategory || `Line of Business #${index + 1}`}
                    </span>
                    <Badge
                      variant="outline"
                      className={
                        isNew
                          ? "bg-blue-50 text-blue-700 border-blue-200"
                          : "bg-green-50 text-green-700 border-green-200"
                      }
                    >
                      {lob.permitApplicationType}
                    </Badge>
                  </div>

                  {/* Financial Info */}
                  <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                    {isNew && capitalAmount && (
                      <div className="flex items-center gap-1">
                        <DollarSign className="h-3 w-3" />
                        <span>Capital: {capitalAmount}</span>
                      </div>
                    )}
                    {isRenewal && grossAmount && (
                      <div className="flex items-center gap-1">
                        <TrendingUp className="h-3 w-3" />
                        <span>Gross Sales: {grossAmount}</span>
                      </div>
                    )}
                    {lob.numberOfEmployees !== undefined && lob.numberOfEmployees > 0 && (
                      <div className="flex items-center gap-1">
                        <span>Employees: {lob.numberOfEmployees}</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Total Fees */}
            {totalFees !== undefined && totalFees > 0 && (
              <div className="pt-3 border-t">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-muted-foreground">
                    Total Fees
                  </span>
                  <span className="font-semibold text-primary">
                    {formatCurrency(totalFees, { withSymbol: true })}
                  </span>
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
