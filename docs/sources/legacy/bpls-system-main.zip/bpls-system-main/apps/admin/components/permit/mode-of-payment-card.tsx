"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";

type ModeOfPayment = "Annually" | "Semi-Annually" | "Quarterly";

interface ModeOfPaymentOption {
  value: ModeOfPayment;
  label: string;
  description: string;
}

const PAYMENT_OPTIONS: ModeOfPaymentOption[] = [
  {
    value: "Annually",
    label: "Annually",
    description: "Pay the full permit fee once per year",
  },
  {
    value: "Semi-Annually",
    label: "Semi-Annually",
    description: "Pay in two installments per year (every 6 months)",
  },
  {
    value: "Quarterly",
    label: "Quarterly",
    description: "Pay in four installments per year (every 3 months)",
  },
];

interface ModeOfPaymentCardProps {
  /**
   * Current selected mode of payment
   */
  value?: ModeOfPayment;
  /**
   * Callback when mode of payment changes (only called when not readonly)
   */
  onChange?: (value: ModeOfPayment) => void;
  /**
   * Whether the component is in readonly/display mode
   */
  readonly?: boolean;
  /**
   * Whether the component is disabled (e.g., after payments have been made)
   * Shows a disabled state with explanation
   */
  disabled?: boolean;
  /**
   * Reason why the component is disabled (shown to user)
   */
  disabledReason?: string;
  /**
   * Custom title for the card
   */
  title?: string;
  /**
   * Custom description for the card
   */
  description?: string;
}

export function ModeOfPaymentCard({
  value,
  onChange,
  readonly = false,
  disabled = false,
  disabledReason,
  title = "Mode of Payment",
  description = "Select your preferred payment frequency for permit fees",
}: ModeOfPaymentCardProps) {
  const isInteractive = !readonly && !disabled;

  const handleSelect = (selectedValue: ModeOfPayment) => {
    if (isInteractive && onChange) {
      onChange(selectedValue);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title} <span className="text-destructive">*</span></CardTitle>
        <CardDescription>
          {readonly
            ? "Payment frequency selected for permit fees"
            : disabled && disabledReason
              ? disabledReason
              : description}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-3">
          {PAYMENT_OPTIONS.map((option) => {
            const isSelected = value === option.value;

            return (
              <div
                key={option.value}
                className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-colors ${
                  isInteractive ? "cursor-pointer" : ""
                } ${
                  isSelected
                    ? disabled
                      ? "border-primary/50 bg-primary/5 opacity-70"
                      : "border-primary bg-primary/5"
                    : readonly || disabled
                      ? "border-border opacity-50"
                      : "border-border hover:bg-accent/50"
                }`}
                onClick={() => handleSelect(option.value)}
                onKeyDown={(e) => {
                  if (isInteractive && (e.key === "Enter" || e.key === " ")) {
                    e.preventDefault();
                    handleSelect(option.value);
                  }
                }}
                role={isInteractive ? "radio" : "presentation"}
                aria-checked={isSelected}
                aria-disabled={disabled}
                tabIndex={isInteractive ? 0 : -1}
              >
                <div
                  className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                    isSelected
                      ? disabled
                        ? "border-primary/50"
                        : "border-primary"
                      : "border-muted-foreground"
                  }`}
                >
                  {isSelected && (
                    <div className={`w-2 h-2 rounded-full ${disabled ? "bg-primary/50" : "bg-primary"}`} />
                  )}
                </div>
                <div className="flex-1">
                  <div className="font-medium">{option.label}</div>
                  <div className="text-sm text-muted-foreground">{option.description}</div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
