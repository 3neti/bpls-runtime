"use client"

import { useState, useMemo, useEffect, useCallback, useRef } from "react"
import { Plus, Trash2, Info, Check, ChevronsUpDown, ChevronRight } from "lucide-react"
import { useQuery } from "convex/react"
import { Controller, type UseFormReturn, type FieldArrayWithId } from "react-hook-form"

import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"
import { Input } from "@repo/ui/components/input"
import { Label } from "@repo/ui/components/label"
import { Progress } from "@repo/ui/components/progress"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@repo/ui/components/command"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@repo/ui/components/popover"
import { FeeManagementModal } from "@/components/fees/fee-management-modal"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { cn, formatCurrency, parseCurrency } from "@/lib/utils"
import { calculateEnterpriseSize, calculateFeeAmount, getFeeCalculationDetails } from "@/lib/utils/fee-calculator"
import type { BusinessData } from "@/lib/types/fees"

// Define types for form values (should match assessment page schema)
interface LineOfBusiness {
  id: string
  businessCategory: string
  groupId: Id<"groups"> | null
  capitalInvestment: string
  grossSales: string
  permitApplicationType: "New" | "Renewal"
  numberOfEmployees?: number
  excludedFees?: Id<"fees">[]
  feeVariableMappings?: { feeId: Id<"fees">; variableName: string }[]
}

interface AssessmentFormValues {
  linesOfBusiness: LineOfBusiness[]
}

// Fee override tracking - GLOBAL by feeId (applies to ALL LOBs with this fee)
export interface FeeOverride {
  feeId: Id<"fees">
  feeName: string
  originalAmount: number
  overriddenAmount: number
}

// Disabled fee tracking - PER LOB by lobId + feeId
// Note: Disabled fees are excluded from the final fee calculation
export interface FeeExclusion {
  lobId: string // Line of Business ID
  feeId: Id<"fees">
  feeName: string
  excludedAmount: number
}

// Fee detail for summary aggregation
export interface LobFeeDetail {
  feeId: Id<"fees">
  feeName: string
  feeCategory: FeeCategory // Added for payment schedule fee splitting
  amount: number
  isExcluded: boolean
}

// Map of LOB ID to its fee details
export interface LobFeesMap {
  [lobId: string]: {
    lobName: string
    fees: LobFeeDetail[]
  }
}

// Unmapped dynamic fee info for validation
export interface UnmappedFeeInfo {
  lobIndex: number
  lobName: string
  feeId: Id<"fees">
  feeName: string
}

interface LOBConfigurationCardProps {
  form: UseFormReturn<AssessmentFormValues>;
  fields: FieldArrayWithId<AssessmentFormValues, "linesOfBusiness", "id">[];
  append: (value: LineOfBusiness) => void;
  remove: (index: number) => void;
  totalEmployees: number;
  applicationId?: Id<"business_permit_applications">; // For asset variables in fee formulas
  onFeeOverridesChange?: (overrides: FeeOverride[]) => void;
  initialFeeOverrides?: FeeOverride[];
  onFeeExclusionsChange?: (exclusions: FeeExclusion[]) => void;
  initialFeeExclusions?: FeeExclusion[];
  validationErrors?: Set<number>;
  onErrorClear?: (index: number) => void;
  businessArea?: number;
  maleEmployeeCount?: number;
  femaleEmployeeCount?: number;
  onUnmappedFeesChange?: (unmappedFees: UnmappedFeeInfo[]) => void;
  // Callback to expose aggregated fee summary for use in PDF generation
  onAggregatedFeesChange?: (aggregatedFees: AggregatedFeeSummary[]) => void;
  // Disable adding new lines of business
  disabled?: boolean;
  // Reason for being disabled (shown in tooltip)
  disabledReason?: string;
  // Permit application type - used to set default Application Type when adding new LOB
  permitApplicationType?: "New" | "Renewal" | "Additional";
  onAutoSave?: () => void;
}

interface LineTotalMap {
  [lobId: string]: number
}

// Fee category type
export type FeeCategory = "Tax" | "Regulatory Fee" | "Other Charges" | "Special Fee";

// Aggregated fee summary for display (exported for use in assessment sheet PDF and payment schedules)
export interface AggregatedFeeSummary {
  feeName: string;
  feeCategory: FeeCategory; // Added for payment schedule fee splitting logic
  totalAmount: number; // Sum of ACTIVE (non-excluded) amounts only
  originalTotalAmount: number; // Sum of ALL amounts (including excluded)
  isFullyExcluded: boolean; // ALL LOBs have this fee excluded
  isPartiallyExcluded: boolean; // SOME (but not all) LOBs have this fee excluded
  breakdown: Array<{
    lobId: string;
    lobName: string;
    feeId: Id<"fees">; // Needed for per-LOB exclusion toggle from Fee Summary
    amount: number;
    isExcluded: boolean; // Per-breakdown-item exclusion state
  }>;
}

// Fee Amount Input - shows raw number while editing, formatted currency on blur
function FeeAmountInput({ value, onChange, onBlur, disabled }: {
  value: number
  onChange: (value: number) => void
  onBlur?: () => void
  disabled?: boolean
}) {
  const [isEditing, setIsEditing] = useState(false)
  const [rawValue, setRawValue] = useState("")

  const handleFocus = () => {
    setIsEditing(true)
    // Show raw number without formatting (no commas), trim trailing zeros for easier editing
    setRawValue(value === 0 ? "" : value.toString())
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const input = e.target.value
    // Allow only digits, decimal point, and empty string
    if (input === "" || /^\d*\.?\d*$/.test(input)) {
      setRawValue(input)
      const numValue = Number.parseFloat(input) || 0
      onChange(numValue)
    }
  }

  const handleBlur = () => {
    setIsEditing(false)
    onBlur?.()
  }

  return (
    <div className="relative">
      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">₱</span>
      <Input
        type="text"
        inputMode="decimal"
        value={isEditing ? rawValue : formatCurrency(value.toString())}
        onChange={handleChange}
        onFocus={handleFocus}
        onBlur={handleBlur}
        className="w-32 pl-6 pr-2 text-right font-semibold"
        disabled={disabled}
      />
    </div>
  )
}

// Fee Summary Section Component - displays aggregated fees with breakdown and 2-way exclusion sync
function FeeSummarySection({ fees, onToggleFee, onToggleBreakdownItem, disabled }: {
  fees: AggregatedFeeSummary[]
  onToggleFee?: (feeName: string) => void
  onToggleBreakdownItem?: (lobId: string, feeId: Id<"fees">, feeName: string, amount: number, isCurrentlyExcluded: boolean) => void
  disabled?: boolean
}) {
  const [expandedFees, setExpandedFees] = useState<Set<string>>(new Set())

  const toggleFeeExpanded = (feeName: string) => {
    setExpandedFees((prev) => {
      const updated = new Set(prev)
      if (updated.has(feeName)) {
        updated.delete(feeName)
      } else {
        updated.add(feeName)
      }
      return updated
    })
  }

  const canToggle = onToggleFee && !disabled

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-base">Fee Summary</h3>
        <p className="text-xs text-muted-foreground">
          Aggregated across all lines of business
          {canToggle && " · Click fee name to toggle"}
        </p>
      </div>
      <div className="space-y-2">
        {fees.map((fee) => {
          const isExpanded = expandedFees.has(fee.feeName)
          const hasMultipleLobs = fee.breakdown.length > 1
          const activeLobCount = fee.breakdown.filter(b => !b.isExcluded).length

          return (
            <div key={fee.feeName} className={cn(
              "bg-muted/30 rounded-lg overflow-hidden",
              fee.isFullyExcluded && "opacity-60"
            )}>
              <div className="flex items-center justify-between p-3">
                <div className="flex items-center gap-2">
                  {hasMultipleLobs && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation()
                        toggleFeeExpanded(fee.feeName)
                      }}
                      className="p-0.5 hover:bg-muted/50 rounded"
                    >
                      <ChevronRight
                        className={cn(
                          "h-4 w-4 text-muted-foreground transition-transform",
                          isExpanded && "rotate-90"
                        )}
                      />
                    </button>
                  )}
                  <span
                    className={cn(
                      "font-medium text-sm",
                      canToggle && "cursor-pointer hover:underline",
                      fee.isFullyExcluded && "line-through text-muted-foreground"
                    )}
                    onClick={() => canToggle && onToggleFee(fee.feeName)}
                    role={canToggle ? "button" : undefined}
                    tabIndex={canToggle ? 0 : undefined}
                    onKeyDown={(e) => {
                      if (canToggle && (e.key === "Enter" || e.key === " ")) {
                        e.preventDefault()
                        onToggleFee(fee.feeName)
                      }
                    }}
                  >
                    {fee.feeName}
                  </span>
                  {hasMultipleLobs && (
                    <Badge variant="secondary" className="text-xs">
                      {activeLobCount}/{fee.breakdown.length} LOBs
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {fee.isFullyExcluded ? (
                    <span className="font-semibold line-through text-muted-foreground">
                      ₱{fee.originalTotalAmount.toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  ) : fee.isPartiallyExcluded ? (
                    <>
                      <span className="font-semibold">
                        ₱{fee.totalAmount.toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                      <span className="text-xs text-muted-foreground line-through">
                        ₱{fee.originalTotalAmount.toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </>
                  ) : (
                    <span className="font-semibold">
                      ₱{fee.totalAmount.toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  )}
                </div>
              </div>

              {/* Breakdown by LOB */}
              {isExpanded && hasMultipleLobs && (
                <div className="border-t border-muted px-3 pb-3 pt-2 space-y-1.5 bg-muted/10">
                  {fee.breakdown.map((item, idx) => {
                    const canToggleItem = onToggleBreakdownItem && !disabled
                    return (
                      <div
                        key={`${item.lobId}-${idx}`}
                        className={cn(
                          "flex items-center justify-between text-sm pl-6 rounded px-2 py-0.5",
                          item.isExcluded && "opacity-50",
                          canToggleItem && "cursor-pointer hover:bg-muted/40"
                        )}
                        onClick={() => canToggleItem && onToggleBreakdownItem(item.lobId, item.feeId, fee.feeName, item.amount, item.isExcluded)}
                        role={canToggleItem ? "button" : undefined}
                        tabIndex={canToggleItem ? 0 : undefined}
                        onKeyDown={(e) => {
                          if (canToggleItem && (e.key === "Enter" || e.key === " ")) {
                            e.preventDefault()
                            onToggleBreakdownItem(item.lobId, item.feeId, fee.feeName, item.amount, item.isExcluded)
                          }
                        }}
                      >
                        <span className={cn(
                          "text-muted-foreground",
                          item.isExcluded && "line-through"
                        )}>
                          {item.lobName}
                        </span>
                        <span className={cn(
                          "text-muted-foreground",
                          item.isExcluded && "line-through"
                        )}>
                          ₱{item.amount.toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

export function LOBConfigurationCard({
  form,
  fields,
  append,
  remove,
  totalEmployees,
  applicationId,
  onFeeOverridesChange,
  initialFeeOverrides = [],
  onFeeExclusionsChange,
  initialFeeExclusions = [],
  validationErrors = new Set(),
  onErrorClear,
  businessArea,
  onUnmappedFeesChange,
  onAggregatedFeesChange,
  disabled = false,
  disabledReason,
  permitApplicationType,
  maleEmployeeCount,
  femaleEmployeeCount,
  onAutoSave,
}: LOBConfigurationCardProps) {
  // Fetch groups from Convex (replaces business categories)
  const groupsResult = useQuery(api.groups.list)
  const groups = groupsResult?.success ? groupsResult.data : []

  const isLoadingCategories = groupsResult === undefined

  // Track line totals from child LOBCard components
  const [lineTotals, setLineTotals] = useState<LineTotalMap>({})

  // Track fee details from each LOB for summary aggregation
  const [lobFeesMap, setLobFeesMap] = useState<LobFeesMap>({})

  // Track unmapped dynamic fees from each LOB for validation
  const [lobUnmappedFeesMap, setLobUnmappedFeesMap] = useState<{
    [lobIndex: number]: Array<{ feeId: Id<"fees">; feeName: string }>
  }>({})

  // ✅ SIMPLIFIED: Use parent prop directly - no local state needed
  // This eliminates all synchronization issues
  const feeOverrides = initialFeeOverrides
  const feeExclusions = initialFeeExclusions

  // Watch form values for reactive updates
  const linesOfBusiness = form.watch("linesOfBusiness")

  const addLineOfBusiness = useCallback(() => {
    const newLOB: LineOfBusiness = {
      id: Date.now().toString(),
      businessCategory: "",
      groupId: null,
      capitalInvestment: "",
      grossSales: "",
      permitApplicationType: permitApplicationType === "Renewal" ? "Renewal" : "New",
      numberOfEmployees: undefined,
    }
    append(newLOB)
    onAutoSave?.()
  }, [append, permitApplicationType, onAutoSave])

  const removeLineOfBusiness = useCallback((index: number) => {
    const removedLob = linesOfBusiness[index]
    // Clean up the line total for removed LOB
    setLineTotals((prev) => {
      const updated = { ...prev }
      delete updated[removedLob.id]
      return updated
    })
    remove(index)
    onAutoSave?.()
  }, [linesOfBusiness, remove, onAutoSave])

  // Handler for LOBCard to report its calculated total
  // ✅ CRITICAL FIX: Memoize this callback to prevent infinite loop
  const handleLineTotalUpdate = useCallback((lobId: string, total: number) => {
    setLineTotals((prev) => ({
      ...prev,
      [lobId]: total,
    }))
  }, []) // Empty deps - this function doesn't depend on external values

  // Handler for fee override updates from LOBCard (GLOBAL by feeId only)
  const handleFeeOverride = useCallback((feeId: Id<"fees">, feeName: string, originalAmount: number, overriddenAmount: number) => {
    if (!onFeeOverridesChange) return

    // ✅ SIMPLIFIED: Update parent directly - override applies to ALL LOBs with this fee
    const updated = [...feeOverrides]

    // Remove existing override if amount is back to original
    if (originalAmount === overriddenAmount) {
      const filtered = updated.filter((o) => o.feeId !== feeId)
      onFeeOverridesChange(filtered)
      return
    }

    // Update existing override or add new one (by feeId only - applies globally)
    const existingIndex = updated.findIndex((o) => o.feeId === feeId)
    if (existingIndex >= 0) {
      updated[existingIndex] = { feeId, feeName, originalAmount, overriddenAmount }
    } else {
      const newOverride = { feeId, feeName, originalAmount, overriddenAmount }
      updated.push(newOverride)
    }

    onFeeOverridesChange(updated)
  }, [feeOverrides, onFeeOverridesChange])

  // Handler for disabling/enabling fees (PER LOB)
  const handleFeeExclusion = useCallback((lobId: string, feeId: Id<"fees">, feeName: string, excludedAmount: number, isExcluded: boolean) => {
    if (!onFeeExclusionsChange) return

    const updated = [...feeExclusions]

    if (!isExcluded) {
      // Enable fee (remove from disabled list)
      const filtered = updated.filter((e) => !(e.lobId === lobId && e.feeId === feeId))
      onFeeExclusionsChange(filtered)
      return
    }

    // Disable fee (add to disabled list)
    const existingIndex = updated.findIndex((e) => e.lobId === lobId && e.feeId === feeId)
    if (existingIndex >= 0) {
      updated[existingIndex] = { lobId, feeId, feeName, excludedAmount }
    } else {
      updated.push({ lobId, feeId, feeName, excludedAmount })
    }

    onFeeExclusionsChange(updated)
  }, [feeExclusions, onFeeExclusionsChange])

  // Handler for toggling fee exclusion from Fee Summary (affects ALL LOBs with this fee)
  const handleFeeSummaryToggle = useCallback((feeName: string) => {
    if (!onFeeExclusionsChange) return

    // Find all LOB+fee combinations for this feeName
    const matchingFees: Array<{ lobId: string; feeId: Id<"fees">; amount: number; isExcluded: boolean }> = []
    Object.entries(lobFeesMap).forEach(([lobId, { fees: lobFees }]) => {
      lobFees.forEach((fee) => {
        if (fee.feeName === feeName) {
          matchingFees.push({ lobId, feeId: fee.feeId, amount: fee.amount, isExcluded: fee.isExcluded })
        }
      })
    })

    if (matchingFees.length === 0) return

    // If ALL are currently excluded, re-enable all; otherwise exclude all
    const allExcluded = matchingFees.every(f => f.isExcluded)
    const shouldExclude = !allExcluded

    let updated = [...feeExclusions]

    for (const mf of matchingFees) {
      if (shouldExclude) {
        const exists = updated.some(e => e.lobId === mf.lobId && e.feeId === mf.feeId)
        if (!exists) {
          updated.push({ lobId: mf.lobId, feeId: mf.feeId, feeName, excludedAmount: mf.amount })
        }
      } else {
        updated = updated.filter(e => !(e.lobId === mf.lobId && e.feeId === mf.feeId))
      }
    }

    onFeeExclusionsChange(updated)
    onAutoSave?.()
  }, [lobFeesMap, feeExclusions, onFeeExclusionsChange, onAutoSave])

  // Handler for toggling a single LOB+fee exclusion from Fee Summary breakdown items
  const handleBreakdownItemToggle = useCallback((lobId: string, feeId: Id<"fees">, feeName: string, amount: number, isCurrentlyExcluded: boolean) => {
    if (!onFeeExclusionsChange) return

    let updated = [...feeExclusions]
    if (isCurrentlyExcluded) {
      // Re-enable: remove from exclusions
      updated = updated.filter(e => !(e.lobId === lobId && e.feeId === feeId))
    } else {
      // Disable: add to exclusions
      const exists = updated.some(e => e.lobId === lobId && e.feeId === feeId)
      if (!exists) {
        updated.push({ lobId, feeId, feeName, excludedAmount: amount })
      }
    }

    onFeeExclusionsChange(updated)
    onAutoSave?.()
  }, [feeExclusions, onFeeExclusionsChange, onAutoSave])

  // Handler for LOBCard to report its fee details for aggregation
  const handleFeesUpdate = useCallback((lobId: string, lobName: string, fees: LobFeeDetail[]) => {
    setLobFeesMap((prev) => ({
      ...prev,
      [lobId]: { lobName, fees },
    }))
  }, [])

  // Handler for LOBCard to report unmapped dynamic fees for validation
  const handleUnmappedFeesUpdate = useCallback((lobIndex: number, unmappedFees: Array<{ feeId: Id<"fees">; feeName: string }>) => {
    setLobUnmappedFeesMap((prev) => ({
      ...prev,
      [lobIndex]: unmappedFees,
    }))
  }, [])

  // Aggregate unmapped fees and report to parent
  const allUnmappedFees = useMemo((): UnmappedFeeInfo[] => {
    const result: UnmappedFeeInfo[] = []
    for (const [lobIndexStr, fees] of Object.entries(lobUnmappedFeesMap)) {
      const lobIndex = Number.parseInt(lobIndexStr, 10)
      const lob = linesOfBusiness[lobIndex]
      if (!lob) continue
      for (const fee of fees) {
        result.push({
          lobIndex,
          lobName: lob.businessCategory || `Line of Business #${lobIndex + 1}`,
          feeId: fee.feeId,
          feeName: fee.feeName,
        })
      }
    }
    return result
  }, [lobUnmappedFeesMap, linesOfBusiness])

  // Create a stable key for unmapped fees to prevent unnecessary updates
  const allUnmappedFeesKey = useMemo(() => {
    return allUnmappedFees.map((f) => `${f.lobIndex}:${f.feeId}`).join(",")
  }, [allUnmappedFees])

  const prevAllUnmappedFeesKeyRef = useRef<string>("")

  // Report aggregated unmapped fees to parent
  useEffect(() => {
    if (!onUnmappedFeesChange) return
    if (prevAllUnmappedFeesKeyRef.current !== allUnmappedFeesKey) {
      prevAllUnmappedFeesKeyRef.current = allUnmappedFeesKey
      onUnmappedFeesChange(allUnmappedFees)
    }
  }, [allUnmappedFeesKey, allUnmappedFees, onUnmappedFeesChange])

  // Calculate total assets (sum of all LOB capital + revenue)
  const totalAssets = useMemo(() => {
    return linesOfBusiness.reduce((total, lob) => {
      const capital = Number.parseFloat(lob.capitalInvestment) || 0
      const revenue = Number.parseFloat(lob.grossSales) || 0
      return total + capital + revenue
    }, 0)
  }, [linesOfBusiness])

  // Calculate enterprise size
  const enterpriseSize = useMemo(() => {
    const size = calculateEnterpriseSize(totalAssets, totalEmployees)

    const sizeInfo = {
      Micro: { progress: 25, color: "bg-green-500", textColor: "text-green-700", bgColor: "bg-green-100" },
      Small: { progress: 50, color: "bg-blue-500", textColor: "text-blue-700", bgColor: "bg-blue-100" },
      Medium: { progress: 75, color: "bg-amber-500", textColor: "text-amber-700", bgColor: "bg-amber-100" },
      Large: { progress: 100, color: "bg-red-500", textColor: "text-red-700", bgColor: "bg-red-100" },
    }

    return {
      size,
      ...sizeInfo[size],
    }
  }, [totalAssets, totalEmployees])

  // Calculate grand total from aggregated line totals
  const grandTotal = useMemo(() => {
    return Object.values(lineTotals).reduce((sum, total) => sum + total, 0)
  }, [lineTotals])

  // Calculate aggregated fee summary (group fees by name across all LOBs, including excluded fees)
  const aggregatedFeeSummary = useMemo((): AggregatedFeeSummary[] => {
    const feeMap = new Map<string, {
      feeName: string
      feeCategory: FeeCategory
      activeTotal: number
      fullTotal: number
      breakdown: Array<{ lobId: string; lobName: string; feeId: Id<"fees">; amount: number; isExcluded: boolean }>
    }>()

    Object.entries(lobFeesMap).forEach(([lobId, { lobName, fees: lobFees }]) => {
      lobFees.forEach((fee) => {
        const breakdownItem = {
          lobId,
          lobName,
          feeId: fee.feeId,
          amount: fee.amount,
          isExcluded: fee.isExcluded,
        }

        const existing = feeMap.get(fee.feeName)
        if (existing) {
          if (!fee.isExcluded) existing.activeTotal += fee.amount
          existing.fullTotal += fee.amount
          existing.breakdown.push(breakdownItem)
        } else {
          feeMap.set(fee.feeName, {
            feeName: fee.feeName,
            feeCategory: fee.feeCategory,
            activeTotal: fee.isExcluded ? 0 : fee.amount,
            fullTotal: fee.amount,
            breakdown: [breakdownItem],
          })
        }
      })
    })

    // Convert to array with exclusion metadata and sort by fee name
    return Array.from(feeMap.values())
      .map(({ feeName, feeCategory, activeTotal, fullTotal, breakdown }) => {
        const allExcluded = breakdown.length > 0 && breakdown.every(b => b.isExcluded)
        const someExcluded = breakdown.some(b => b.isExcluded) && !allExcluded
        return {
          feeName,
          feeCategory,
          totalAmount: activeTotal,
          originalTotalAmount: fullTotal,
          isFullyExcluded: allExcluded,
          isPartiallyExcluded: someExcluded,
          breakdown,
        }
      })
      .sort((a, b) => a.feeName.localeCompare(b.feeName))
  }, [lobFeesMap])

  // Notify parent of aggregated fees changes (for PDF generation)
  useEffect(() => {
    if (onAggregatedFeesChange) {
      onAggregatedFeesChange(aggregatedFeeSummary);
    }
  }, [aggregatedFeeSummary, onAggregatedFeesChange]);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <CardTitle>Lines of Business Declaration</CardTitle>
            <CardDescription>
              Configure business categories and calculate fees for this application
            </CardDescription>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-xs text-muted-foreground mb-1">Enterprise Size</div>
              <Badge className={`${enterpriseSize.bgColor} ${enterpriseSize.textColor} border-0`}>
                {enterpriseSize.size}
              </Badge>
            </div>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="h-4 w-4 text-muted-foreground cursor-help" />
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="font-semibold mb-1">Philippine MSME Standards</p>
                  <ul className="text-xs space-y-1">
                    <li>Micro: Assets ≤ ₱3M, Employees 1-9</li>
                    <li>Small: Assets ₱3M-₱15M, Employees 10-99</li>
                    <li>Medium: Assets ₱15M-₱100M, Employees 100-199</li>
                    <li>Large: Assets &gt; ₱100M, Employees 200+</li>
                  </ul>
                  <p className="text-xs mt-2">
                    Total Assets: ₱{totalAssets.toLocaleString("en-PH", { minimumFractionDigits: 2 })}
                  </p>
                  <p className="text-xs">
                    Total Employees: {totalEmployees}
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
        <div className="mt-4">
          <Progress value={enterpriseSize.progress} className="h-2" indicatorClassName={enterpriseSize.color} />
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {linesOfBusiness.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <p>No lines of business configured yet.</p>
            <p className="text-sm mt-2">Click &quot;Add Line of Business&quot; to get started.</p>
          </div>
        )}

        {fields.map((field, index) => (
          <LOBCard
            key={field.id}
            form={form}
            index={index}
            groups={groups || []}
            isLoadingCategories={isLoadingCategories}
            onRemove={removeLineOfBusiness}
            onLineTotalUpdate={handleLineTotalUpdate}
            onFeeOverride={handleFeeOverride}
            onFeeExclusion={handleFeeExclusion}
            onFeesUpdate={handleFeesUpdate}
            onUnmappedFeesUpdate={handleUnmappedFeesUpdate}
            canRemove={fields.length > 1}
            totalEmployees={totalEmployees}
            applicationId={applicationId}
            allFeeOverrides={feeOverrides}
            allFeeExclusions={feeExclusions}
            hasError={validationErrors.has(index)}
            onErrorClear={onErrorClear}
            businessArea={businessArea}
            maleEmployeeCount={maleEmployeeCount}
            femaleEmployeeCount={femaleEmployeeCount}
            disabled={disabled}
            onAutoSave={onAutoSave}
          />
        ))}

        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <span className="w-full block" tabIndex={disabled ? 0 : undefined}>
                <Button
                  type="button"
                  onClick={addLineOfBusiness}
                  variant="outline"
                  className="w-full"
                  disabled={disabled}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Line of Business
                </Button>
              </span>
            </TooltipTrigger>
            {disabled && disabledReason && (
              <TooltipContent>
                <p>{disabledReason}</p>
              </TooltipContent>
            )}
          </Tooltip>
        </TooltipProvider>

        {linesOfBusiness.length > 0 && (
          <div className="border-t pt-6 space-y-6">
            {/* Fee Summary Section - Aggregate fees by name across all LOBs */}
            {aggregatedFeeSummary.length > 0 && (
              <FeeSummarySection
                fees={aggregatedFeeSummary}
                onToggleFee={onFeeExclusionsChange ? handleFeeSummaryToggle : undefined}
                onToggleBreakdownItem={onFeeExclusionsChange ? handleBreakdownItemToggle : undefined}
                disabled={disabled}
              />
            )}

            {/* Grand Total */}
            <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-lg">Grand Total</h3>
                  <p className="text-sm text-muted-foreground">
                    Total fees for all business categories
                  </p>
                </div>
                <div className="text-right">
                  <div className="font-bold text-2xl text-primary">
                    ₱{grandTotal.toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {linesOfBusiness.length} business {linesOfBusiness.length === 1 ? "category" : "categories"}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

interface LOBCardProps {
  form: UseFormReturn<AssessmentFormValues>
  index: number
  groups: Array<{ _id: Id<"groups">; name: string; description?: string }>
  isLoadingCategories: boolean
  onRemove: (index: number) => void
  onLineTotalUpdate: (lobId: string, total: number) => void
  onFeeOverride: (feeId: Id<"fees">, feeName: string, originalAmount: number, overriddenAmount: number) => void
  onFeeExclusion: (lobId: string, feeId: Id<"fees">, feeName: string, excludedAmount: number, isExcluded: boolean) => void
  onFeesUpdate: (lobId: string, lobName: string, fees: LobFeeDetail[]) => void
  onUnmappedFeesUpdate: (lobIndex: number, unmappedFees: Array<{ feeId: Id<"fees">; feeName: string }>) => void
  canRemove: boolean
  totalEmployees: number
  applicationId?: Id<"business_permit_applications"> // For asset variables in fee formulas
  allFeeOverrides: FeeOverride[]
  allFeeExclusions: FeeExclusion[]
  lobFeeOverrides?: FeeOverride[] // Per-LOB fee overrides (different from global)
  hasError?: boolean
  onErrorClear?: (index: number) => void
  businessArea?: number
  maleEmployeeCount?: number
  femaleEmployeeCount?: number
  disabled?: boolean // Disable all form elements
  onAutoSave?: () => void
}

function LOBCard({
  form,
  index,
  groups,
  isLoadingCategories,
  onRemove,
  onLineTotalUpdate,
  onFeeOverride,
  onFeeExclusion,
  onFeesUpdate,
  onUnmappedFeesUpdate,
  canRemove,
  applicationId,
  totalEmployees,
  allFeeOverrides,
  allFeeExclusions,
  lobFeeOverrides = [],
  hasError = false,
  onErrorClear,
  businessArea,
  maleEmployeeCount,
  femaleEmployeeCount,
  disabled = false,
  onAutoSave,
}: LOBCardProps) {
  // Watch LOB data from form
  const lob = form.watch(`linesOfBusiness.${index}`)

  // State for Add Fee modal
  const [isAddFeeModalOpen, setIsAddFeeModalOpen] = useState(false)
  const [editingFee, setEditingFee] = useState<any | null>(null)

  // State for showing disabled fees
  const [showDisabledFees, setShowDisabledFees] = useState(false)

  // State for category combobox
  const [categoryOpen, setCategoryOpen] = useState(false)
  const [categorySearch, setCategorySearch] = useState("")

  // Fetch fees for this LOB's group (skip if no group selected)
  const groupFees = useQuery(
    api.fees.getByGroup,
    lob.groupId ? { groupId: lob.groupId } : "skip"
  )

  const fees = groupFees || []

  // Fetch fee names for the modal
  const feeNamesResult = useQuery(api.feeNames.list, { activeOnly: true })
  const feeNames = useMemo(
    () => feeNamesResult?.map((fn: NonNullable<typeof feeNamesResult>[number]) => ({ _id: fn._id, name: fn.name, isActive: fn.isActive })) || [],
    [feeNamesResult]
  )

  // Filter business categories for combobox search
  const filteredCategories = useMemo(() => {
    if (!groups) return []
    if (!categorySearch) return groups
    return groups.filter((group) =>
      group.name.toLowerCase().includes(categorySearch.toLowerCase())
    )
  }, [groups, categorySearch])

  // Fetch categories for this business
  const categories = useQuery(api.unitsOfMeasurement.list.list, applicationId ? { applicationId } : "skip") || []

  // Extract primitive values from lob for stable dependencies
  // This ensures useMemo recomputes when these values change
  const lobCapitalInvestment = lob.capitalInvestment
  const lobGrossSales = lob.grossSales
  const lobNumberOfEmployees = lob.numberOfEmployees
  const lobFeeVariableMappings = lob.feeVariableMappings

  // Calculate business data for fee calculation (aligned with BusinessData interface)
  const businessData: BusinessData = useMemo(() => {
    // Initialize with placeholders to prevent ReferenceError in formulas
    const initialVariables: Record<string, number> = {
      unitOfMeasurement: 0,
      assetSize: 0, // Legacy support
    }

    const categoryVariables = (lobFeeVariableMappings || []).reduce((acc, mapping) => {
      // Find the category record that matches the mapped variable name
      const category = categories.find(c => c.variableName === mapping.variableName)

      if (category) {
        // Use the variable name as the key and quantity as the value
        acc[mapping.variableName] = category.quantity
      }
      return acc
    }, initialVariables)

    return {
      numberOfEmployees: lobNumberOfEmployees || totalEmployees,
      maleEmployeeCount: maleEmployeeCount || 0,
      femaleEmployeeCount: femaleEmployeeCount || 0,
      businessArea: businessArea || 0, // Use passed businessArea or default to 0
      capitalInvestment: Number.parseFloat(lobCapitalInvestment) || 0,
      grossSales: Number.parseFloat(lobGrossSales) || 0,
      categoryVariables
    }
  }, [lobCapitalInvestment, lobGrossSales, lobNumberOfEmployees, lobFeeVariableMappings, totalEmployees, categories, businessArea, maleEmployeeCount, femaleEmployeeCount])

  // ✅ REFACTORED: Calculate fees with on-the-fly override lookup by feeId and disabled fee check
  // This eliminates the need for local state synchronization and lobIndex filtering
  const calculatedFees = useMemo(() => {
    return fees.map((fee) => {
      const originalAmount = calculateFeeAmount(
        fee.feeType,
        fee.amount,
        businessData,
        fee.rangeField,
        fee.ranges,
        fee.formula
      )
      const details = getFeeCalculationDetails(
        fee.feeType,
        fee.amount,
        businessData,
        fee.rangeField,
        fee.ranges,
        fee.formula
      )

      // Special handling for Unit of Measurement (Dynamic) fees
      // If the fee requires a category mapping but none is provided, or the mapped category is missing,
      // the calculation might have returned 0 or an error.
      // We need to flag this state to show the dropdown.
      // Note: We check for "assetSize"/"unitOfMeasurement" as range field, or if formula uses dynamic variables
      const isDynamicCategoryFee = fee.rangeField === "assetSize" || fee.rangeField === "unitOfMeasurement" || (fee.feeType === "Formula" && (fee.formula?.includes("assetSize") || fee.formula?.includes("category") || fee.formula?.includes("unitOfMeasurement")))
      const mappedVariable = lob.feeVariableMappings?.find(m => m.feeId === fee._id)?.variableName
      const isMapped = !!mappedVariable
      
      // If it's a dynamic fee and mapped, re-calculate using the specific category variable
      
      let finalOriginalAmount = originalAmount
      let finalDetails = details

      if (isDynamicCategoryFee && isMapped) {
        // Create a specific business data context for this fee
        // We need to inject the 'assetSize' (or 'category') variable with the value of the mapped category
        // so that formulas using 'assetSize' can resolve it.
        const mappedCategoryValue = businessData.categoryVariables?.[mappedVariable] || 0
        
        const feeSpecificBusinessData = {
          ...businessData,
          categoryVariables: {
            ...businessData.categoryVariables,
            assetSize: mappedCategoryValue, // Inject assetSize placeholder for backward compatibility
            unitOfMeasurement: mappedCategoryValue // Inject new placeholder
          }
        }

        // Re-calculate using the MAPPED variable name as the range field (for Range fees)
        // OR using the injected variable (for Formula fees)
        finalOriginalAmount = calculateFeeAmount(
          fee.feeType,
          fee.amount,
          feeSpecificBusinessData,
          mappedVariable, // Use the mapped variable name (e.g. "numberOfHorses") for Range fees
          fee.ranges,
          fee.formula
        )
        
        finalDetails = getFeeCalculationDetails(
          fee.feeType,
          fee.amount,
          feeSpecificBusinessData,
          mappedVariable,
          fee.ranges,
          fee.formula
        )
      } else if (isDynamicCategoryFee && !isMapped) {
        // If not mapped, amount is 0 and we show a warning/prompt
        finalOriginalAmount = 0
        finalDetails = "Select a category to calculate fee"
      }

      // Check if fee is disabled for this LOB
      const isExcluded = allFeeExclusions.some((e) => e.lobId === lob.id && e.feeId === fee._id)

      // Check for per-LOB override first, then global override
      const lobOverride = lobFeeOverrides.find(o => o.feeId === fee._id)
      const globalOverride = allFeeOverrides.find(o => o.feeId === fee._id)

      const override = lobOverride || globalOverride
      const isLobOverride = lobOverride !== undefined
      const isGlobalOverride = !isLobOverride && globalOverride !== undefined

      const hasOverride = override !== undefined
      const finalAmount = hasOverride ? override.overriddenAmount : finalOriginalAmount

      return {
        ...fee,
        calculatedAmount: finalAmount,
        originalAmount: finalOriginalAmount,
        calculationDetails: finalDetails,
        isOverridden: hasOverride,
        isLobOverride,
        isGlobalOverride,
        isExcluded,
        isDynamicCategoryFee,
        mappedVariable,
      }
    })
  }, [fees, businessData, allFeeOverrides, allFeeExclusions, lobFeeOverrides, lob.id, lob.feeVariableMappings])

  const lineTotal = useMemo(() => {
    return calculatedFees
      .filter((fee) => !fee.isExcluded) // Exclude disabled fees from total
      .reduce((total, fee) => total + fee.calculatedAmount, 0)
  }, [calculatedFees])

  // Separate disabled fees for display
  const activeFees = useMemo(() => calculatedFees.filter((fee) => !fee.isExcluded), [calculatedFees])
  const disabledFees = useMemo(() => calculatedFees.filter((fee) => fee.isExcluded), [calculatedFees])

  // Report line total changes to parent component
  useEffect(() => {
    onLineTotalUpdate(lob.id, lineTotal)
  }, [lob.id, lineTotal, onLineTotalUpdate])

  // Create fee details for aggregation - memoized to avoid recreating on each render
  const feeDetails = useMemo((): LobFeeDetail[] => {
    return calculatedFees.map((fee) => ({
      feeId: fee._id,
      feeName: fee.name,
      feeCategory: (fee.feeCategory as FeeCategory) || "Other Charges",
      amount: fee.calculatedAmount,
      isExcluded: fee.isExcluded,
    }))
  }, [calculatedFees])

  // Create a stable string key for dependency comparison to prevent infinite loops
  const feeDetailsKey = useMemo(() => {
    return feeDetails
      .map((fee) => `${fee.feeId}:${fee.feeName}:${fee.feeCategory}:${fee.amount}:${fee.isExcluded}`)
      .join("|")
  }, [feeDetails])

  // Store previous key to compare and prevent unnecessary updates
  const prevFeeDetailsKeyRef = useRef<string>("")

  // Report fee details to parent for aggregation - only when actual values change
  useEffect(() => {
    if (prevFeeDetailsKeyRef.current !== feeDetailsKey) {
      prevFeeDetailsKeyRef.current = feeDetailsKey
      onFeesUpdate(lob.id, lob.businessCategory || `Line of Business #${index + 1}`, feeDetails)
    }
  }, [lob.id, lob.businessCategory, index, feeDetailsKey, feeDetails, onFeesUpdate])

  // Calculate and report unmapped dynamic fees for validation
  const unmappedDynamicFees = useMemo(() => {
    return calculatedFees
      .filter((fee) => fee.isDynamicCategoryFee && !fee.mappedVariable && !fee.isExcluded)
      .map((fee) => ({ feeId: fee._id, feeName: fee.name }))
  }, [calculatedFees])

  // Create a stable key for unmapped fees to prevent unnecessary updates
  const unmappedFeesKey = useMemo(() => {
    return unmappedDynamicFees.map((f) => f.feeId).join(",")
  }, [unmappedDynamicFees])

  const prevUnmappedFeesKeyRef = useRef<string>("")

  // Report unmapped fees to parent for validation
  useEffect(() => {
    if (prevUnmappedFeesKeyRef.current !== unmappedFeesKey) {
      prevUnmappedFeesKeyRef.current = unmappedFeesKey
      onUnmappedFeesUpdate(index, unmappedDynamicFees)
    }
  }, [index, unmappedFeesKey, unmappedDynamicFees, onUnmappedFeesUpdate])

  const isRenewal = lob.permitApplicationType === "Renewal"
  const isNew = lob.permitApplicationType === "New"

  // ✅ SIMPLIFIED: Handle fee amount override - applies globally to all LOBs with this fee
  const handleFeeAmountChange = (feeId: Id<"fees">, feeName: string, originalAmount: number, newAmount: number) => {
    // Notify parent component immediately - parent state is the source of truth
    // No lobIndex needed - override applies to ALL LOBs with this feeId
    onFeeOverride(feeId, feeName, originalAmount, newAmount)
    // Auto-save is triggered on blur, not on every keystroke
  }

  // Handle toggling fee enabled/disabled state
  const handleFeeExclusionToggle = (feeId: Id<"fees">, feeName: string, currentAmount: number, isCurrentlyExcluded: boolean) => {
    onFeeExclusion(lob.id, feeId, feeName, currentAmount, !isCurrentlyExcluded)
    onAutoSave?.()
  }

  // Handle re-enabling a disabled fee
  const handleRestoreFee = (feeId: Id<"fees">, feeName: string, amount: number) => {
    onFeeExclusion(lob.id, feeId, feeName, amount, false)
    onAutoSave?.()
  }

  const handleGroupChange = (groupIdString: string) => {
    // Convex ID comparison - convert both to string for comparison
    const group = groups.find((g) => g._id.toString() === groupIdString)
    if (!group) {
      console.error("Group not found:", groupIdString, "Available groups:", groups.map(g => g._id.toString()))
      return
    }

    // Update both fields using form.setValue
    form.setValue(`linesOfBusiness.${index}.groupId`, group._id, { shouldValidate: true })
    form.setValue(`linesOfBusiness.${index}.businessCategory`, group.name, { shouldValidate: true })

    // Clear error for this LOB when a valid category is selected
    if (onErrorClear && group.name.trim() !== "") {
      onErrorClear(index)
    }
    onAutoSave?.()
  }

  // Track which currency field is being actively edited
  const [editingField, setEditingField] = useState<"capitalInvestment" | "grossSales" | null>(null)
  const [editingValue, setEditingValue] = useState<string>("")

  const handleCurrencyInput = (field: "capitalInvestment" | "grossSales", value: string) => {
    // Allow only numbers, commas, and a single decimal point
    const sanitized = value.replace(/[^0-9.,]/g, "")
    setEditingValue(sanitized)

    // Parse and store the raw numeric value
    const rawValue = parseCurrency(sanitized)
    form.setValue(`linesOfBusiness.${index}.${field}`, rawValue, { shouldValidate: true })
  }

  const handleCurrencyFocus = (field: "capitalInvestment" | "grossSales", currentValue: string) => {
    setEditingField(field)
    // Show the raw value (without forced decimal places) when editing
    const numValue = Number.parseFloat(currentValue) || 0
    setEditingValue(numValue > 0 ? numValue.toString() : "")
  }

  const handleCurrencyBlur = () => {
    setEditingField(null)
    setEditingValue("")
    onAutoSave?.()
  }

  const handleFeeMappingChange = (feeId: Id<"fees">, variableName: string) => {
    const currentMappings = lob.feeVariableMappings || []
    const existingIndex = currentMappings.findIndex(m => m.feeId === feeId)

    let newMappings = [...currentMappings]
    if (existingIndex >= 0) {
      newMappings[existingIndex] = { feeId, variableName }
    } else {
      newMappings.push({ feeId, variableName })
    }

    form.setValue(`linesOfBusiness.${index}.feeVariableMappings`, newMappings, { shouldValidate: true })
    onAutoSave?.()
  }

  return (
    <Card className="border-2">
      <CardContent className="p-6 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h4 className="font-semibold text-lg">Line of Business #{index + 1}</h4>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setEditingFee(null)
                setIsAddFeeModalOpen(true)
              }}
              disabled={disabled || !lob.groupId}
              title={!lob.groupId ? "Select a business category first" : "Add custom fee for this LOB"}
            >
              <Plus className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onRemove(index)}
              disabled={disabled || !canRemove}
            >
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
          </div>
        </div>

        {/* Form Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Business Group (Category) */}
          <Controller
            control={form.control}
            name={`linesOfBusiness.${index}.groupId`}
            render={({ field: groupField, fieldState }) => {
              const selectedCategory = groups?.find(
                (g) => g._id.toString() === groupField.value?.toString()
              )
              return (
                <div className="space-y-2 min-w-0">
                  <Label>Business Category *</Label>
                  <Popover open={categoryOpen} onOpenChange={setCategoryOpen}>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        aria-expanded={categoryOpen}
                        className={cn(
                          "w-full justify-between font-normal overflow-hidden",
                          !groupField.value && "text-muted-foreground",
                          (hasError || fieldState.error) && "border-destructive"
                        )}
                        disabled={disabled || isLoadingCategories}
                      >
                        <span className="truncate">
                          {isLoadingCategories ? (
                            "Loading..."
                          ) : selectedCategory ? (
                            selectedCategory.name
                          ) : (
                            "Select category"
                          )}
                        </span>
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[300px] p-0" align="start">
                      <Command shouldFilter={false}>
                        <CommandInput
                          placeholder="Search categories..."
                          value={categorySearch}
                          onValueChange={setCategorySearch}
                        />
                        <CommandList>
                          <CommandEmpty>No category found.</CommandEmpty>
                          <CommandGroup>
                            {filteredCategories.map((group) => (
                              <CommandItem
                                key={group._id}
                                value={group._id.toString()}
                                onSelect={() => {
                                  handleGroupChange(group._id.toString())
                                  setCategoryOpen(false)
                                  setCategorySearch("")
                                }}
                              >
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    groupField.value?.toString() === group._id.toString()
                                      ? "opacity-100"
                                      : "opacity-0"
                                  )}
                                />
                                {group.name}
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                  {(hasError || fieldState.error) && (
                    <p className="text-xs text-destructive">
                      {fieldState.error?.message || "Please select a business category"}
                    </p>
                  )}
                </div>
              )
            }}
          />

          {/* Application Type */}
          <Controller
            control={form.control}
            name={`linesOfBusiness.${index}.permitApplicationType`}
            render={({ field: typeField }) => (
              <div className="space-y-2 min-w-0">
                <Label>Application Type *</Label>
                <Select
                  value={typeField.value}
                  onValueChange={(value) => {
                    typeField.onChange(value)
                    onAutoSave?.()
                  }}
                  disabled={disabled}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="New">New</SelectItem>
                    <SelectItem value="Renewal">Renewal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          />

          {/* Capital Investment */}
          <Controller
            control={form.control}
            name={`linesOfBusiness.${index}.capitalInvestment`}
            render={({ field: capitalField, fieldState }) => (
              <div className="space-y-2 min-w-0">
                <Label>Capital Investment {isNew ? "*" : ""}</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₱</span>
                  <Input
                    type="text"
                    value={editingField === "capitalInvestment" ? editingValue : (capitalField.value ? formatCurrency(capitalField.value) : "")}
                    onChange={(e) => handleCurrencyInput("capitalInvestment", e.target.value)}
                    onFocus={() => handleCurrencyFocus("capitalInvestment", capitalField.value)}
                    onBlur={handleCurrencyBlur}
                    placeholder="0.00"
                    className={`pl-7 ${fieldState.error && !isRenewal ? "border-destructive" : ""}`}
                    disabled={disabled || isRenewal}
                  />
                </div>
                {fieldState.error && !isRenewal && (
                  <p className="text-xs text-destructive">{fieldState.error.message}</p>
                )}
                {isRenewal && !disabled && (
                  <p className="text-xs text-muted-foreground">Disabled for renewal applications</p>
                )}
              </div>
            )}
          />

          {/* Gross Sales */}
          <Controller
            control={form.control}
            name={`linesOfBusiness.${index}.grossSales`}
            render={({ field: revenueField, fieldState }) => (
              <div className="space-y-2 min-w-0">
                <Label>Gross Sales {isRenewal ? "*" : ""}</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₱</span>
                  <Input
                    type="text"
                    value={editingField === "grossSales" ? editingValue : (revenueField.value ? formatCurrency(revenueField.value) : "")}
                    onChange={(e) => handleCurrencyInput("grossSales", e.target.value)}
                    onFocus={() => handleCurrencyFocus("grossSales", revenueField.value)}
                    onBlur={handleCurrencyBlur}
                    placeholder="0.00"
                    className={`pl-7 ${fieldState.error && !isNew ? "border-destructive" : ""}`}
                    disabled={disabled || isNew}
                  />
                </div>
                {fieldState.error && !isNew && (
                  <p className="text-xs text-destructive">{fieldState.error.message}</p>
                )}
                {isNew && !disabled && (
                  <p className="text-xs text-muted-foreground">Disabled for new applications</p>
                )}
              </div>
            )}
          />
        </div>

        {/* Associated Fees Section */}
        {lob.businessCategory && (
          <div className="border-t pt-4 space-y-3">
            <h5 className="font-semibold text-sm">Associated Fees - {lob.businessCategory}</h5>

            {fees.length === 0 ? (
              <div className="text-sm text-muted-foreground py-2">
                No fees configured for this business category
              </div>
            ) : (
              <>
                {/* Active Fees */}
                <div className="space-y-2">
                  {activeFees.map((fee) => (
                    <div key={fee._id} className="flex items-start justify-between gap-4 p-3 bg-muted/50 rounded-md">
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-sm">{fee.name}</span>
                          <FeeTypeBadge feeType={fee.feeType} />
                          {fee.isLobOverride && (
                            <Badge className="bg-purple-100 text-purple-700 border-purple-200 text-xs" variant="outline">
                              LOB Override
                            </Badge>
                          )}
                          {fee.isGlobalOverride && (
                            <Badge className="bg-amber-100 text-amber-700 border-amber-200 text-xs" variant="outline">
                              Global Override
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">{fee.calculationDetails}</p>
                        
                        {/* Unit of Measurement Mapping Dropdown */}
                        {fee.isDynamicCategoryFee && (
                          <div className="mt-2">
                            <Select
                              value={fee.mappedVariable || ""}
                              onValueChange={(value) => handleFeeMappingChange(fee._id, value)}
                              disabled={disabled}
                            >
                              <SelectTrigger className="h-8 text-xs w-[200px]">
                                <SelectValue placeholder="Select Unit of Measurement" />
                              </SelectTrigger>
                              <SelectContent>
                                {categories.map((asset) => (
                                  <SelectItem key={asset._id} value={asset.variableName}>
                                    {asset.variableName} {asset.description ? `(${asset.description})` : `(${asset.quantity})`}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            {!fee.mappedVariable && (
                              <p className="text-[10px] text-destructive mt-1">
                                * Required for fee calculation
                              </p>
                            )}
                          </div>
                        )}
                      </div>
                      <div className="text-right flex items-center gap-2">
                        <FeeAmountInput
                          value={fee.calculatedAmount}
                          onChange={(numValue) => handleFeeAmountChange(fee._id, fee.name, fee.originalAmount, numValue)}
                          onBlur={() => onAutoSave?.()}
                          disabled={disabled}
                        />
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleFeeExclusionToggle(fee._id, fee.name, fee.calculatedAmount, false)}
                                className="h-8 w-8 p-0 hover:bg-destructive/10"
                                disabled={disabled}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Disable this fee (won't be included in calculation)</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Disabled Fees Section */}
                {disabledFees.length > 0 && (
                  <div className="mt-4 pt-4 border-t space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <h6 className="text-sm font-semibold text-muted-foreground">
                          Disabled Fees (not included in total)
                        </h6>
                        <Badge className="bg-red-100 text-red-700 border-red-200 text-xs" variant="outline">
                          {disabledFees.length}
                        </Badge>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setShowDisabledFees(!showDisabledFees);
                        }}
                        className="text-xs"
                        type="button"
                      >
                        {showDisabledFees ? "Hide" : "Show"}
                      </Button>
                    </div>

                    {showDisabledFees && (
                      <div className="space-y-2">
                        {disabledFees.map((fee) => (
                          <div key={fee._id} className="flex items-start justify-between gap-4 p-3 bg-destructive/5 border border-destructive/20 rounded-md opacity-60">
                            <div className="flex-1 space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="font-medium text-sm line-through text-muted-foreground">{fee.name}</span>
                                <FeeTypeBadge feeType={fee.feeType} />
                                <Badge className="bg-red-100 text-red-700 border-red-200 text-xs font-semibold" variant="outline">
                                  Disabled
                                </Badge>
                              </div>
                              <p className="text-xs text-muted-foreground line-through">{fee.calculationDetails}</p>
                              <p className="text-xs font-medium text-red-600">⚠️ Not included in fee calculation</p>
                            </div>
                            <div className="text-right flex items-center gap-2">
                              <span className="text-sm text-muted-foreground line-through">
                                ₱{fee.calculatedAmount.toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                              </span>
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => handleRestoreFee(fee._id, fee.name, fee.calculatedAmount)}
                                      className="h-8 px-3 text-xs hover:bg-green-50 border border-green-200 bg-green-50/50"
                                      disabled={disabled}
                                    >
                                      Enable
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p>Enable this fee to include it in the calculation</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}

            {/* Line Total */}
            <div className="flex items-center justify-between pt-2 border-t">
              <span className="font-semibold">Line Total</span>
              <span className="font-bold text-lg">
                ₱{lineTotal.toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>
        )}

        {/* Fee Management Modal */}
        {lob.groupId && (
          <FeeManagementModal
            isOpen={isAddFeeModalOpen}
            onOpenChange={setIsAddFeeModalOpen}
            entityId={lob.groupId.toString()}
            entityType="group"
            editingFee={editingFee}
            feeNames={feeNames}
            applicationId={applicationId}
            onSuccess={() => {
              setIsAddFeeModalOpen(false)
              setEditingFee(null)
              // Fees will automatically refresh via Convex reactivity
            }}
          />
        )}
      </CardContent>
    </Card>
  )
}

function FeeTypeBadge({ feeType }: { feeType: "Constant" | "Range" | "Formula" }) {
  const config = {
    Constant: { color: "bg-blue-100 text-blue-700 border-blue-200", label: "Constant" },
    Range: { color: "bg-green-100 text-green-700 border-green-200", label: "Range" },
    Formula: { color: "bg-purple-100 text-purple-700 border-purple-200", label: "Formula" },
  }

  const { color, label } = config[feeType]

  return (
    <Badge className={`${color} text-xs border`} variant="outline">
      {label}
    </Badge>
  )
}
