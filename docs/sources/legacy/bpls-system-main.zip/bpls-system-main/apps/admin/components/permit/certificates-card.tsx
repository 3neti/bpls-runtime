/**
 * CertificatesCard Component
 *
 * Displays required certificates for a permit application with:
 * - List of certificates with upload status
 * - Uploader name and date for uploaded certificates
 * - Progress bar showing completion percentage
 */

import { Shield, FileText, CheckCircle, Clock } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"
import { formatDate } from "@/lib/utils/permit-helpers"

export interface CertificateInfo {
  name: string
  uploaded: boolean
  uploadedBy: string | null
  uploadedDate: string | null
}

export interface CertificatesCardProps {
  requiredCertificates: CertificateInfo[]
}

export function CertificatesCard({ requiredCertificates }: CertificatesCardProps) {
  const uploadedCount = requiredCertificates.filter((cert) => cert.uploaded).length
  const totalCount = requiredCertificates.length
  const progressPercentage = (uploadedCount / totalCount) * 100

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Required Certificates
        </CardTitle>
        <CardDescription>All certificates must be uploaded before approval</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {requiredCertificates.map((cert) => (
            <div key={cert.name} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-full ${cert.uploaded ? "bg-green-100" : "bg-gray-100"}`}>
                  <FileText
                    className={`h-4 w-4 ${cert.uploaded ? "text-green-600" : "text-gray-600"}`}
                  />
                </div>
                <div className="flex-1">
                  <h6 className="font-medium text-sm">{cert.name}</h6>
                  {cert.uploaded && cert.uploadedBy && (
                    <div className="text-xs text-muted-foreground">
                      <p>Uploaded by {cert.uploadedBy}</p>
                      <p>{formatDate(cert.uploadedDate!)}</p>
                    </div>
                  )}
                </div>
              </div>
              <div>
                {cert.uploaded ? (
                  <Badge variant="default" className="bg-green-100 text-green-800">
                    <CheckCircle className="mr-1 h-3 w-3" />
                    Uploaded
                  </Badge>
                ) : (
                  <Badge variant="secondary" className="bg-gray-100 text-gray-600">
                    <Clock className="mr-1 h-3 w-3" />
                    Pending
                  </Badge>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div className="mt-4 p-3 bg-muted/30 rounded-lg">
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium">Progress:</span>
            <span className="font-medium">
              {uploadedCount} of {totalCount} completed
            </span>
          </div>
          <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-green-600 h-2 rounded-full transition-all duration-300"
              style={{
                width: `${progressPercentage}%`,
              }}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
