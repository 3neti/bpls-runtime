"use client";

import React, { useState, useEffect, lazy, Suspense } from "react";
import { FileText, Loader2, ChevronDown, ChevronUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card";
import { Button } from "@repo/ui/components/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@repo/ui/components/collapsible";

// Types for form data
export interface BusinessActivity {
  code: string;
  lineOfBusiness: string;
  noOfUnits?: string;
  capitalization?: string;
  grossSalesEssential?: string;
  grossSalesNonEssential?: string;
}

export interface LessorInfo {
  lastName?: string;
  firstName?: string;
  middleName?: string;
  houseNo?: string;
  street?: string;
  barangay?: string;
  subdivision?: string;
  cityMunicipality?: string;
  province?: string;
  telNo?: string;
  emailAddress?: string;
}

export interface AssessmentItem {
  description: string;
  reference?: string;
  amountDue?: string;
  penaltySurcharge?: string;
  total?: string;
  assessedBy?: string;
}

export interface VerificationDocument {
  description: string;
  issuingOffice?: string;
  recommendingApproval?: string;
  dateIssued?: string;
  verifiedBy?: string;
}

export interface BusinessPermitFormData {
  // Header
  taxYear?: string;
  applicationNo?: string;

  // Application Type
  isNew?: boolean;
  isRenew?: boolean;
  isAdditional?: boolean;

  // Amendment Type
  amendmentFromSingleToPartnership?: boolean;
  amendmentFromSingleToCorporation?: boolean;
  amendmentFromPartnershipToSingle?: boolean;
  amendmentFromPartnershipToCorporation?: boolean;
  amendmentFromCorporationToSingle?: boolean;
  amendmentFromCorporationToPartnership?: boolean;

  // Transfer Type
  transferOwnership?: boolean;
  transferLocation?: boolean;

  // Mode of Payment
  paymentAnnually?: boolean;
  paymentSemiAnnually?: boolean;
  paymentQuarterly?: boolean;

  // Registration Info
  dateOfApplication?: string;
  dtiSecCdaRegistrationNo?: string;
  referenceNo?: string;
  dtiSecCdaDateOfRegistration?: string;

  // Organization Type
  isSingle?: boolean;
  isPartnership?: boolean;
  isCorporation?: boolean;
  isCooperative?: boolean;
  isNonProfit?: boolean;

  ctcNo?: string;
  tin?: string;

  // Tax Incentive
  hasTaxIncentive?: boolean;
  taxIncentiveEntity?: string;

  // Taxpayer Info
  taxpayerLastName?: string;
  taxpayerFirstName?: string;
  taxpayerMiddleName?: string;

  businessName?: string;
  businessPlateNo?: string;
  tradeName?: string;

  // Corporation President/Treasurer
  presidentLastName?: string;
  presidentFirstName?: string;
  presidentMiddleName?: string;

  // Business Address
  businessHouseNo?: string;
  businessBuildingName?: string;
  businessUnitNo?: string;
  businessStreet?: string;
  businessBarangay?: string;
  businessSubdivision?: string;
  businessCityMunicipality?: string;
  businessProvince?: string;
  businessTelNo?: string;
  businessEmailAddress?: string;

  // Owner Address
  ownerHouseNo?: string;
  ownerBuildingName?: string;
  ownerUnitNo?: string;
  ownerStreet?: string;
  ownerBarangay?: string;
  ownerSubdivision?: string;
  ownerCityMunicipality?: string;
  ownerProvince?: string;
  ownerTelNo?: string;
  ownerEmailAddress?: string;

  // Property Info
  propertyIndexNumber?: string;
  businessAreaSqm?: string;
  totalEmployees?: string;
  employeesInLgu?: string;

  // Rental Info
  monthlyRental?: string;
  lessor?: LessorInfo;

  // Emergency Contact
  emergencyContact?: string;

  // Business Activities
  businessActivities?: BusinessActivity[];

  // Signature
  applicantSignature?: string;
  applicantPosition?: string;

  // Page 2 - Assessments
  assessments?: AssessmentItem[];

  // Verification Documents
  verificationDocuments?: VerificationDocument[];

  // Approval
  assessmentReviewedBy?: string;
  approvalRecommendedBy?: string;
  grantedDay?: string;
  grantedMonth?: string;
  grantedYear?: string;
  grantedCtcNo?: string;
  grantedCtcIssuedOn?: string;
  grantedCtcIssuedAt?: string;
  mayorName?: string;
  mayorTitle?: string;

  // Settings - optional, uses defaults if not provided
  municipalityName?: string; // e.g., "MUNICIPALITY OF IPIL"
  municipalityShortName?: string; // e.g., "Ipil"
  provinceName?: string; // e.g., "Zamboanga Sibugay"
  municipalSealUrl?: string; // URL to municipal seal image
}

// Props for the Application Form PDF Card
export interface ApplicationFormPdfProps {
  applicationNumber: string;
  permitApplicationType?: "New" | "Renewal" | "Additional";
  modeOfPayment?: "Annually" | "Semi-Annually" | "Quarterly";
  submittedAt: string;
  businessOwner?: {
    firstName: string;
    middleName?: string;
    lastName: string;
    birthDate: string;
    civilStatus: string;
    gender: string;
    citizenship: string;
    tin?: string;
    mobile: string;
    email: string;
    address?: string;
  } | null;
  business?: {
    name: string;
    establishedDate: string;
    ownershipType: string;
    occupancy: string;
    permitPaymentCadence: string;
    maleEmployeeCount: number;
    femaleEmployeeCount: number;
    contactNumber: string;
    email: string;
    address?: string;
    buildingName?: string;
    businessArea?: number;
    registrationNumber?: string;
    registrationDate?: string;
    propertyIndexNumber?: string;
  } | null;
  linesOfBusiness?: Array<{
    businessCategory: string;
    capitalInvestment: string;
    grossSales?: string;
    permitApplicationType: string;
    numberOfEmployees?: number;
  }>;
  provinceName?: string;
  cityName?: string;
  barangayName?: string;
  ownerProvinceName?: string;
  ownerCityName?: string;
  ownerBarangayName?: string;
  // Platform settings
  mayorName?: string;
}

/**
 * Maps permit application data to BusinessPermitFormData interface
 */
export function mapToFormData(props: ApplicationFormPdfProps): BusinessPermitFormData {
  const {
    applicationNumber,
    permitApplicationType,
    modeOfPayment,
    submittedAt,
    businessOwner,
    business,
    linesOfBusiness,
    provinceName,
    cityName,
    barangayName,
    ownerProvinceName,
    ownerCityName,
    ownerBarangayName,
    mayorName,
  } = props;

  // Extract year from submittedAt
  const taxYear = new Date(submittedAt).getFullYear().toString();
  const dateOfApplication = new Date(submittedAt).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  // Map application type
  const isNew = permitApplicationType === "New";
  const isRenew = permitApplicationType === "Renewal";
  const isAdditional = permitApplicationType === "Additional";

  // Map mode of payment
  const paymentAnnually = modeOfPayment === "Annually";
  const paymentSemiAnnually = modeOfPayment === "Semi-Annually";
  const paymentQuarterly = modeOfPayment === "Quarterly";

  // Map organization type based on ownershipType
  const ownershipType = business?.ownershipType?.toLowerCase() || "";
  const isSingle = ownershipType.includes("sole") || ownershipType.includes("proprietorship");
  const isPartnership = ownershipType.includes("partnership");
  const isCorporation = ownershipType.includes("corporation");
  const isCooperative = ownershipType.includes("cooperative");
  const isNonProfit = ownershipType.includes("non-profit") || ownershipType.includes("nonprofit");

  // Calculate total employees
  const totalEmployees = business ? (business.maleEmployeeCount + business.femaleEmployeeCount).toString() : "";

  // Map business activities from lines of business
  const businessActivities: BusinessActivity[] =
    linesOfBusiness?.map((lob) => ({
      code: "", // No direct mapping for code
      lineOfBusiness: lob.businessCategory,
      noOfUnits: lob.numberOfEmployees?.toString() || "",
      capitalization: lob.permitApplicationType === "New" ? lob.capitalInvestment : "",
      grossSalesEssential: lob.grossSales || "",
      grossSalesNonEssential: "",
    })) || [];

  return {
    // Header
    taxYear,
    applicationNo: applicationNumber,

    // Application Type
    isNew,
    isRenew,
    isAdditional,

    // Amendment Type - NO MAPPING
    amendmentFromSingleToPartnership: false,
    amendmentFromSingleToCorporation: false,
    amendmentFromPartnershipToSingle: false,
    amendmentFromPartnershipToCorporation: false,
    amendmentFromCorporationToSingle: false,
    amendmentFromCorporationToPartnership: false,

    // Transfer Type - NO MAPPING
    transferOwnership: false,
    transferLocation: false,

    // Mode of Payment
    paymentAnnually,
    paymentSemiAnnually,
    paymentQuarterly,

    // Registration Info
    dateOfApplication,
    dtiSecCdaRegistrationNo: business?.registrationNumber || "",
    referenceNo: "",
    dtiSecCdaDateOfRegistration: business?.registrationDate || "",

    // Organization Type
    isSingle,
    isPartnership,
    isCorporation,
    isCooperative,
    isNonProfit,

    ctcNo: "",
    tin: businessOwner?.tin || "",

    // Tax Incentive - NO MAPPING
    hasTaxIncentive: undefined,
    taxIncentiveEntity: "",

    // Taxpayer Info
    taxpayerLastName: businessOwner?.lastName || "",
    taxpayerFirstName: businessOwner?.firstName || "",
    taxpayerMiddleName: businessOwner?.middleName || "",

    businessName: business?.name || "",
    businessPlateNo: "",
    tradeName: "",

    // Corporation President/Treasurer - blank by default
    presidentLastName: "",
    presidentFirstName: "",
    presidentMiddleName: "",

    // Business Address
    businessHouseNo: "",
    businessBuildingName: business?.buildingName || "",
    businessUnitNo: "",
    businessStreet: business?.address || "",
    businessBarangay: barangayName || "",
    businessSubdivision: "",
    businessCityMunicipality: cityName || "",
    businessProvince: provinceName || "",
    businessTelNo: business?.contactNumber || "",
    businessEmailAddress: business?.email || "",

    // Owner Address
    ownerHouseNo: "",
    ownerBuildingName: "",
    ownerUnitNo: "",
    ownerStreet: businessOwner?.address || "",
    ownerBarangay: ownerBarangayName || "",
    ownerSubdivision: "",
    ownerCityMunicipality: ownerCityName || "",
    ownerProvince: ownerProvinceName || "",
    ownerTelNo: businessOwner?.mobile || "",
    ownerEmailAddress: businessOwner?.email || "",

    // Property Info
    propertyIndexNumber: business?.propertyIndexNumber || "",
    businessAreaSqm: business?.businessArea?.toString() || "",
    totalEmployees,
    employeesInLgu: "",

    // Rental Info - auto-fill lessor address from business address if occupancy is "Rented"
    monthlyRental: "",
    lessor:
      business?.occupancy?.toLowerCase() === "rented"
        ? {
            lastName: "",
            firstName: "",
            middleName: "",
            houseNo: "",
            street: business?.address || "",
            barangay: barangayName || "",
            subdivision: "",
            cityMunicipality: cityName || "",
            province: provinceName || "",
            telNo: "",
            emailAddress: "",
          }
        : {
            lastName: "",
            firstName: "",
            middleName: "",
            houseNo: "",
            street: "",
            barangay: "",
            subdivision: "",
            cityMunicipality: "",
            province: "",
            telNo: "",
            emailAddress: "",
          },

    // Emergency Contact - NO MAPPING
    emergencyContact: "",

    // Business Activities
    businessActivities,

    // Signature - NO MAPPING
    applicantSignature: "",
    applicantPosition: "",

    // Page 2 - Assessments - NO MAPPING (empty array for default display)
    assessments: [],

    // Verification Documents - NO MAPPING (empty array for default display)
    verificationDocuments: [],

    // Approval - blank defaults for pen entry
    assessmentReviewedBy: "",
    approvalRecommendedBy: "",
    grantedDay: "",
    grantedMonth: "",
    grantedYear: "",
    grantedCtcNo: "",
    grantedCtcIssuedOn: "",
    grantedCtcIssuedAt: "",
    mayorName: mayorName || "",
  };
}

// Lazy load the PDF viewer component
const PdfViewerContent = lazy(() => import("./pdf-viewer-content"));

export function ApplicationFormPdf(props: ApplicationFormPdfProps) {
  const [isClient, setIsClient] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const formData = mapToFormData(props);

  useEffect(() => {
    setIsClient(true);
  }, []);

  return (
    <Card>
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CardHeader className="pb-3">
          <CollapsibleTrigger asChild>
            <Button
              variant="ghost"
              className="w-full flex items-center justify-between p-0 h-auto hover:bg-transparent"
            >
              <CardTitle className="flex items-center gap-2 text-base">
                <FileText className="h-5 w-5" />
                Application Form PDF
              </CardTitle>
              {isOpen ? (
                <ChevronUp className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              )}
            </Button>
          </CollapsibleTrigger>
          {!isOpen && (
            <p className="text-sm text-muted-foreground mt-1">Click to view and print the application form</p>
          )}
        </CardHeader>
        <CollapsibleContent>
          <CardContent>
            {!isClient ? (
              <div className="h-[600px] flex items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin" />
              </div>
            ) : (
              <Suspense
                fallback={
                  <div className="h-[600px] flex items-center justify-center">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                }
              >
                <PdfViewerContent formData={formData} applicationNumber={props.applicationNumber} />
              </Suspense>
            )}
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}
