"use client";

import type { ReactNode } from "react";
import { ShieldX } from "lucide-react";
import {
  usePermissions,
  type Resource,
  type Action,
} from "@/hooks/use-permissions";
import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card";

interface PermissionGuardProps {
  /**
   * The resource to check permissions for
   */
  resource: Resource;
  /**
   * The action to check (e.g., "create", "read", "update", "delete")
   */
  action: Action;
  /**
   * Content to render if user has permission
   */
  children: ReactNode;
  /**
   * Custom fallback to render if user lacks permission.
   * If not provided, a default "Access Denied" UI is shown.
   * Pass `null` to render nothing when access is denied.
   */
  fallback?: ReactNode;
  /**
   * If true, shows a loading spinner while permissions are being fetched.
   * Default: false (renders nothing during loading)
   */
  showLoading?: boolean;
}

/**
 * Component that conditionally renders children based on user permissions.
 *
 * @example
 * // Hide button if user can't create permits
 * <PermissionGuard resource="permits" action="create" fallback={null}>
 *   <Button>Create Permit</Button>
 * </PermissionGuard>
 *
 * @example
 * // Show access denied message
 * <PermissionGuard resource="users" action="delete">
 *   <DeleteUserDialog />
 * </PermissionGuard>
 */
export function PermissionGuard({
  resource,
  action,
  children,
  fallback,
  showLoading = false,
}: PermissionGuardProps) {
  const { hasPermission, isLoading } = usePermissions();

  // Loading state
  if (isLoading) {
    if (showLoading) {
      return (
        <div className="flex items-center justify-center p-4">
          <div className="h-5 w-5 animate-spin rounded-full border-2 border-primary border-t-transparent" />
        </div>
      );
    }
    return null;
  }

  // Check permission
  if (!hasPermission(resource, action)) {
    // If fallback is null, render nothing
    if (fallback === null) return null;

    // If custom fallback provided, use it
    if (fallback !== undefined) return <>{fallback}</>;

    // Default access denied UI
    return <AccessDenied resource={resource} action={action} />;
  }

  return <>{children}</>;
}

/**
 * Props for checking multiple permissions at once
 */
interface MultiPermissionGuardProps {
  /**
   * Array of permission checks - user must have ALL permissions
   */
  permissions: Array<{ resource: Resource; action: Action }>;
  children: ReactNode;
  fallback?: ReactNode;
  showLoading?: boolean;
}

/**
 * Component that checks multiple permissions (user must have ALL)
 */
export function MultiPermissionGuard({
  permissions,
  children,
  fallback,
  showLoading = false,
}: MultiPermissionGuardProps) {
  const { hasPermission, isLoading } = usePermissions();

  if (isLoading) {
    if (showLoading) {
      return (
        <div className="flex items-center justify-center p-4">
          <div className="h-5 w-5 animate-spin rounded-full border-2 border-primary border-t-transparent" />
        </div>
      );
    }
    return null;
  }

  const hasAllPermissions = permissions.every(({ resource, action }) =>
    hasPermission(resource, action)
  );

  if (!hasAllPermissions) {
    if (fallback === null) return null;
    if (fallback !== undefined) return <>{fallback}</>;
    return <AccessDenied />;
  }

  return <>{children}</>;
}

/**
 * Props for checking any of multiple permissions
 */
interface AnyPermissionGuardProps {
  /**
   * Array of permission checks - user must have AT LEAST ONE permission
   */
  permissions: Array<{ resource: Resource; action: Action }>;
  children: ReactNode;
  fallback?: ReactNode;
  showLoading?: boolean;
}

/**
 * Component that checks if user has ANY of the specified permissions
 */
export function AnyPermissionGuard({
  permissions,
  children,
  fallback,
  showLoading = false,
}: AnyPermissionGuardProps) {
  const { hasPermission, isLoading } = usePermissions();

  if (isLoading) {
    if (showLoading) {
      return (
        <div className="flex items-center justify-center p-4">
          <div className="h-5 w-5 animate-spin rounded-full border-2 border-primary border-t-transparent" />
        </div>
      );
    }
    return null;
  }

  const hasAnyPermission = permissions.some(({ resource, action }) =>
    hasPermission(resource, action)
  );

  if (!hasAnyPermission) {
    if (fallback === null) return null;
    if (fallback !== undefined) return <>{fallback}</>;
    return <AccessDenied />;
  }

  return <>{children}</>;
}

/**
 * Default access denied component
 */
function AccessDenied({
  resource,
  action,
}: {
  resource?: Resource;
  action?: Action;
}) {
  const description =
    resource && action
      ? `You don't have permission to ${action} ${resource.replace("_", " ")}.`
      : "You don't have permission to access this resource.";

  return (
    <Card className="border-destructive/20 bg-destructive/5">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-destructive text-sm">
          <ShieldX className="h-4 w-4" />
          Access Denied
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-xs text-muted-foreground">{description}</p>
        <p className="text-xs text-muted-foreground mt-1">
          Contact your administrator if you believe this is an error.
        </p>
      </CardContent>
    </Card>
  );
}
