/**
 * BusinessInfoCard Component
 *
 * Displays comprehensive business information including:
 * - Business name and ownership details
 * - Business details (occupancy, employees, payment cadence)
 * - Contact information
 * - Business address
 * - Lines of business with expandable accordion showing fee breakdowns
 */

import Link from "next/link";
import { Building2, Phone, Mail, MapPin, ExternalLink } from "lucide-react";
import { useQuery } from "convex/react";

import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@repo/ui/components/tooltip";
import { Badge } from "@repo/ui/components/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@repo/ui/components/accordion";
import { formatDate, formatCurrency, calculateFee, generateFeeCaption } from "@/lib/utils/permit-helpers";
import { businessNatureFees } from "@/lib/data/business-fees";
import { api } from "@repo/backend/convex/_generated/api";
import type { LineOfBusiness } from "@/lib/types/business";
import type { ApplicationType, BusinessData } from "@/lib/types/fees";
import type { Id } from "@repo/backend/convex/_generated/dataModel";

export interface BusinessInfoData {
  name: string;
  dateEstablished: string;
  ownershipType: string;
  occupancy: string;
  permitPaymentCadence: string;
  maleEmployeeCount: number;
  femaleEmployeeCount: number;
  contactNumber: string;
  email: string;
  address?: string; // Optional to allow partial data
  buildingName?: string;
  provinceId?: Id<"provinces">; // Optional to allow partial data
  cityId?: Id<"cities">; // Optional to allow partial data
  barangayId?: Id<"barangays">; // Optional to allow partial data
  linesOfBusiness: Array<
    LineOfBusiness & {
      categoryName: string;
    }
  >;
  businessArea?: number;
  // New fields for link navigation and business details
  businessId?: Id<"businesses">; // For navigation link
  registrationNumber?: string; // DTI/SEC/CDA number
  registrationDate?: string;
  propertyIndexNumber?: string;
  businessScale?: string;
  annualRevenue?: number;
  dateStarted?: string; // Actual operations start date
}

export interface BusinessInfoCardProps {
  business: BusinessInfoData;
  /** Application ID for querying asset variables */
  applicationId?: Id<"business_permit_applications">;
  /** Hide fee details for department reviewers (default: false) */
  hideFeesSection?: boolean;
  /** Application remarks from permit applicant (read-only) */
  remarks?: string;
}

export function BusinessInfoCard({ business, applicationId, hideFeesSection = false, remarks }: BusinessInfoCardProps) {
  // Query category variables for fee calculations
  const categoryVariablesData = useQuery(
    api.unitsOfMeasurement.getVariables.getVariables,
    applicationId ? { applicationId } : "skip"
  );

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Business Information
          </CardTitle>
          {business.businessId && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href={`/dashboard/businesses/${business.businessId}`}>
                    <ExternalLink className="h-4 w-4 text-muted-foreground hover:text-foreground cursor-pointer" />
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>View Business Details</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h3 className="text-xl font-semibold">{business.name}</h3>
          <p className="text-muted-foreground">
            {business.ownershipType} • Established {formatDate(business.dateEstablished)}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-sm text-muted-foreground">Business Details</h4>
              <div className="mt-2 space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Occupancy:</span>
                  <span className="text-sm font-medium capitalize">{business.occupancy}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Employees:</span>
                  <span className="text-sm font-medium">
                    {business.maleEmployeeCount} male, {business.femaleEmployeeCount} female (Total:{" "}
                    {business.maleEmployeeCount + business.femaleEmployeeCount})
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Payment Cadence:</span>
                  <span className="text-sm font-medium">{business.permitPaymentCadence}</span>
                </div>
                {business.businessArea && (
                  <div className="flex justify-between">
                    <span className="text-sm">Business Area:</span>
                    <span className="text-sm font-medium">{business.businessArea} sq.m</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-sm text-muted-foreground">Contact Information</h4>
              <div className="mt-2 space-y-2">
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{business.contactNumber}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{business.email}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Registration & Scale Information - show if any field exists */}
        {(business.registrationNumber || business.businessScale || business.annualRevenue || business.dateStarted) && (
          <div>
            <h4 className="font-medium text-sm text-muted-foreground">Registration & Scale</h4>
            <div className="mt-2 space-y-2">
              {business.registrationNumber && (
                <div className="flex justify-between">
                  <span className="text-sm">Registration No:</span>
                  <span className="text-sm font-medium">{business.registrationNumber}</span>
                </div>
              )}
              {business.registrationDate && (
                <div className="flex justify-between">
                  <span className="text-sm">Registration Date:</span>
                  <span className="text-sm font-medium">{formatDate(business.registrationDate)}</span>
                </div>
              )}
              {business.propertyIndexNumber && (
                <div className="flex justify-between">
                  <span className="text-sm">Property Index No:</span>
                  <span className="text-sm font-medium">{business.propertyIndexNumber}</span>
                </div>
              )}
              {business.businessScale && (
                <div className="flex justify-between">
                  <span className="text-sm">Business Scale:</span>
                  <span className="text-sm font-medium">{business.businessScale}</span>
                </div>
              )}
              {business.annualRevenue !== undefined && business.annualRevenue > 0 && (
                <div className="flex justify-between">
                  <span className="text-sm">Annual Revenue:</span>
                  <span className="text-sm font-medium">{formatCurrency(business.annualRevenue)}</span>
                </div>
              )}
              {business.dateStarted && (
                <div className="flex justify-between">
                  <span className="text-sm">Operations Started:</span>
                  <span className="text-sm font-medium">{formatDate(business.dateStarted)}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {business.address && (
          <div>
            <h4 className="font-medium text-sm text-muted-foreground mb-2">Business Address</h4>
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">
                {business.buildingName && `${business.buildingName}, `}
                {business.address}
              </span>
            </div>
          </div>
        )}

        {/* Lines of Business - Only show if LOBs exist */}
        {business.linesOfBusiness && business.linesOfBusiness.length > 0 && (
          <div>
            <h4 className="font-medium text-sm text-muted-foreground mb-3">Lines of Business</h4>
            {hideFeesSection ? (
              // Simple list view without fees for department reviewers
              <div className="space-y-2">
                {business.linesOfBusiness.map((line) => (
                  <div key={line.id} className="border rounded-lg p-4">
                    <div className="flex items-center gap-3">
                      <h5 className="font-medium">{line.categoryName}</h5>
                      <Badge variant="outline">{line.permitApplicationType}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              // Full accordion with fees for internal staff
              <Accordion type="multiple" className="space-y-3">
                {business.linesOfBusiness.map((line) => {
                  const businessNature = businessNatureFees[line.businessCategory as keyof typeof businessNatureFees];

                  const totalEmployees = business.maleEmployeeCount + business.femaleEmployeeCount;
                  const businessData: BusinessData = {
                    numberOfEmployees: totalEmployees,
                    grossSales: Number.parseFloat(line.grossSales) || 0,
                    businessArea: business.businessArea || 0, // Default value
                    capitalInvestment: Number.parseFloat(line.capitalInvestment) || 0,
                    categoryVariables: categoryVariablesData || {},
                  };

                  const lineTotal = businessNature
                    ? businessNature.fees
                        .filter((fee) =>
                          fee.applicationType.includes((line.permitApplicationType as ApplicationType) || "New")
                        )
                        .reduce((sum, fee) => sum + calculateFee(fee, businessData), 0)
                    : 0;

                  return (
                    <AccordionItem key={line.id} value={line.id} className="border rounded-lg px-4">
                      <AccordionTrigger className="hover:no-underline">
                        <div className="flex items-center justify-between w-full pr-4">
                          <div className="flex items-center gap-3">
                            <h5 className="font-medium">{line.categoryName}</h5>
                            <Badge variant="outline">{line.permitApplicationType}</Badge>
                          </div>
                          <div className="font-semibold text-primary">{formatCurrency(lineTotal)}</div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="pb-4">
                        <div className="space-y-4">
                          {/* Business Line Details */}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm bg-muted/30 p-3 rounded-lg">
                            <div>
                              <span className="text-muted-foreground">Capital Investment:</span>
                              <span className="ml-2 font-medium">{formatCurrency(Number(line.capitalInvestment))}</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Gross Sales:</span>
                              <span className="ml-2 font-medium">{formatCurrency(Number(line.grossSales))}</span>
                            </div>
                          </div>

                          {/* Associated Fees */}
                          {businessNature && (
                            <div>
                              <h6 className="font-medium text-sm mb-3">Associated Fees</h6>
                              <div className="space-y-2">
                                {businessNature.fees
                                  .filter((fee) =>
                                    fee.applicationType.includes(
                                      (line.permitApplicationType as ApplicationType) || "New"
                                    )
                                  )
                                  .map((fee) => {
                                    const calculatedAmount = calculateFee(fee, businessData);
                                    const caption = generateFeeCaption(fee, businessData);

                                    return (
                                      <div
                                        key={fee.id}
                                        className="flex items-center justify-between p-3 bg-muted/30 rounded-lg"
                                      >
                                        <div className="flex-1">
                                          <div className="flex items-center gap-2">
                                            <span className="font-medium text-sm">{fee.name}</span>
                                            <span
                                              className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                                                fee.feeType === "Constant"
                                                  ? "bg-blue-100 text-blue-800"
                                                  : fee.feeType === "Range"
                                                    ? "bg-green-100 text-green-800"
                                                    : "bg-purple-100 text-purple-800"
                                              }`}
                                            >
                                              {fee.feeType}
                                            </span>
                                          </div>
                                          {caption && (
                                            <p className="text-xs text-muted-foreground mt-1 font-mono">{caption}</p>
                                          )}
                                        </div>
                                        <div className="text-right">
                                          <div className="font-semibold text-sm">
                                            {formatCurrency(calculatedAmount)}
                                          </div>
                                          {fee.feeType !== "Constant" && calculatedAmount === 0 && (
                                            <p className="text-xs text-muted-foreground">No data available</p>
                                          )}
                                        </div>
                                      </div>
                                    );
                                  })}
                              </div>

                              {/* Line Total */}
                              <div className="border-t mt-4 pt-3">
                                <div className="flex items-center justify-between">
                                  <span className="font-semibold text-sm">Total for {businessNature.name}:</span>
                                  <span className="font-bold text-base text-primary">{formatCurrency(lineTotal)}</span>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  );
                })}
              </Accordion>
            )}
          </div>
        )}

        {/* Application Remarks - Read-only display */}
        {remarks && (
          <div>
            <h4 className="font-medium text-sm text-muted-foreground mb-2">Application Remarks</h4>
            <div className="p-3 bg-muted/30 rounded-lg border border-muted">
              <p className="text-sm whitespace-pre-wrap">{remarks}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
