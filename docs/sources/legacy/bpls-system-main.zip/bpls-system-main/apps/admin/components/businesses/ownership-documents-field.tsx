"use client"

import { FileText } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Label } from "@repo/ui/components/label"
import { Dropzone } from "@repo/ui/components/dropzone"
import { ExistingDocumentCard } from "@/components/businesses/existing-document-card"

import type { BusinessDocument } from "@/lib/types/business"

interface OwnershipDocumentsFieldProps {
  ownershipType: string
  businessId?: string // For existing document display
  documents?: Record<string, { file: File | null; uploaded: boolean }>
  existingDocuments?: BusinessDocument[] // Existing documents from database
  onFileSelect: (documentType: string, file: File) => void
  onFileRemove: (documentType: string) => void
  onExistingDocumentDeleted?: () => void // Callback when existing document is deleted
  disabled?: boolean
}

/**
 * Reusable component for ownership-specific document uploads
 *
 * Displays document upload fields based on ownership type:
 * - Sole Proprietorship: DTI Certificate
 * - Partnership: SEC Certificate, Articles of Partnership
 * - Corporation: SEC Certificate, Articles of Incorporation, By-Laws, GIS
 * - Cooperative: CDA Certificate, Articles of Cooperation, By-Laws
 * - Religious/Non-Profit: SEC Certificate, Articles of Incorporation, By-Laws, GIS
 */
export function OwnershipDocumentsField({
  ownershipType,
  businessId,
  documents = {},
  existingDocuments = [],
  onFileSelect,
  onFileRemove,
  onExistingDocumentDeleted,
  disabled = false,
}: OwnershipDocumentsFieldProps) {
  // Map document type keys to display names (for matching with existing documents)
  const documentTypeMap: Record<string, string> = {
    dtiCertificate: "DTI Certificate",
    secCertificate: "SEC Certificate",
    articlesOfPartnership: "Articles of Partnership",
    articlesOfIncorporation: "Articles of Incorporation",
    bylaws: "By-Laws",
    gis: "General Information Sheet (GIS)",
    cdaCertificate: "CDA Certificate",
    articlesOfCooperation: "Articles of Cooperation",
  }

  // Check if a document of a specific type already exists
  const hasExistingDocument = (documentTypeKey: string): boolean => {
    const displayName = documentTypeMap[documentTypeKey]
    return existingDocuments.some((doc) => doc.documentType === displayName)
  }

  // Get existing document by type key
  const getExistingDocument = (documentTypeKey: string): BusinessDocument | undefined => {
    const displayName = documentTypeMap[documentTypeKey]
    return existingDocuments.find((doc) => doc.documentType === displayName)
  }

  const getDocumentFile = (documentType: string): File | null => {
    return documents[documentType]?.file || null
  }

  // Render document field: show existing document card OR dropzone
  const renderDocumentField = (
    documentTypeKey: string,
    label: string,
    description: string
  ) => {
    const existingDoc = getExistingDocument(documentTypeKey)

    return (
      <Card key={documentTypeKey}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            {label}
          </CardTitle>
          <CardDescription>{description}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>{`Upload ${label}`}</Label>

            {/* Show existing document if it exists */}
            {existingDoc && businessId ? (
              <ExistingDocumentCard
                businessId={businessId}
                document={existingDoc}
                onDelete={onExistingDocumentDeleted}
                disabled={disabled}
              />
            ) : (
              /* Show dropzone if no existing document */
              <Dropzone
                onFileSelect={(file) => onFileSelect(documentTypeKey, file)}
                onFileRemove={() => onFileRemove(documentTypeKey)}
                selectedFile={getDocumentFile(documentTypeKey)}
                disabled={disabled}
              />
            )}
          </div>
        </CardContent>
      </Card>
    )
  }

  const normalizedOwnershipType = ownershipType?.toLowerCase().replace(/\s+/g, "-")

  if (normalizedOwnershipType === "sole-proprietorship") {
    return renderDocumentField(
      "dtiCertificate",
      "DTI Certificate of Business Name Registration",
      "Upload your Department of Trade and Industry certificate"
    )
  }

  if (normalizedOwnershipType === "partnership") {
    return (
      <>
        {renderDocumentField(
          "secCertificate",
          "SEC Certificate of Registration (Partnership)",
          "Upload your SEC Certificate of Registration for Partnership"
        )}
        {renderDocumentField(
          "articlesOfPartnership",
          "Articles of Partnership",
          "Upload your Articles of Partnership"
        )}
      </>
    )
  }

  if (normalizedOwnershipType === "corporation") {
    return (
      <>
        {renderDocumentField(
          "secCertificate",
          "SEC Certificate of Incorporation/Registration",
          "Upload your SEC Certificate of Incorporation/Registration"
        )}
        {renderDocumentField(
          "articlesOfIncorporation",
          "Articles of Incorporation",
          "Upload your Articles of Incorporation"
        )}
        {renderDocumentField("bylaws", "By-Laws", "Upload your By-Laws")}
        {renderDocumentField(
          "gis",
          "Most Recent General Information Sheet (GIS)",
          "Upload your most recent GIS filed with SEC"
        )}
      </>
    )
  }

  if (normalizedOwnershipType === "cooperative") {
    return (
      <>
        {renderDocumentField(
          "cdaCertificate",
          "CDA Certificate of Registration",
          "Upload your Cooperative Development Authority Certificate of Registration"
        )}
        {renderDocumentField(
          "articlesOfCooperation",
          "Articles of Cooperation",
          "Upload your Articles of Cooperation"
        )}
        {renderDocumentField("bylaws", "By-Laws", "Upload your By-Laws")}
      </>
    )
  }

  if (normalizedOwnershipType === "religious") {
    return (
      <>
        {renderDocumentField(
          "secCertificate",
          "SEC Certificate of Incorporation (Religious Corporation)",
          "Upload your SEC Certificate of Incorporation for Religious Corporation"
        )}
        {renderDocumentField(
          "articlesOfIncorporation",
          "Articles of Incorporation (Religious Corporation)",
          "Upload your Articles of Incorporation for Religious Corporation"
        )}
        {renderDocumentField("bylaws", "By-Laws", "Upload your By-Laws")}
      </>
    )
  }

  if (normalizedOwnershipType === "non-profit") {
    return (
      <>
        {renderDocumentField(
          "secCertificate",
          "SEC Certificate of Incorporation (Non-Stock / Non-Profit)",
          "Upload your SEC Certificate of Incorporation for Non-Stock/Non-Profit Organization"
        )}
        {renderDocumentField(
          "articlesOfIncorporation",
          "Articles of Incorporation",
          "Upload your Articles of Incorporation"
        )}
        {renderDocumentField("bylaws", "By-Laws", "Upload your By-Laws")}
        {renderDocumentField(
          "gis",
          "Most Recent General Information Sheet (GIS)",
          "Upload your most recent GIS filed with SEC"
        )}
      </>
    )
  }

  return null
}
