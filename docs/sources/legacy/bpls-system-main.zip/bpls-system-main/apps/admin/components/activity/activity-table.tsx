"use client";

import Link from "next/link";
import {
  ExternalLink,
  RefreshCw,
  Plus,
  Wallet,
  Check,
  Trash2,
  RotateCcw,
  Pencil,
  type LucideIcon,
} from "lucide-react";
import { format } from "date-fns";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table";
import { Badge } from "@repo/ui/components/badge";
import { Button } from "@repo/ui/components/button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip";

import type { Doc } from "@repo/backend/convex/_generated/dataModel";

type ActivityLog = Doc<"activity_logs">;

// Hidden fields that shouldn't be shown in the changes column
const HIDDEN_CHANGE_FIELDS = new Set([
  "searchText", "isDeleted", "deletedAt", "provinceId", "cityId", "barangayId",
]);

// Human-readable field labels
const CHANGE_FIELD_LABELS: Record<string, string> = {
  firstName: "First Name",
  middleName: "Middle Name",
  lastName: "Last Name",
  birthDate: "Birth Date",
  civilStatus: "Civil Status",
  gender: "Gender",
  citizenship: "Citizenship",
  tin: "TIN",
  mobile: "Mobile",
  email: "Email",
  address: "Address",
  ownerType: "Owner Type",
  groupName: "Group Name",
  isBlacklisted: "Blacklisted",
  blacklistReason: "Blacklist Reason",
  name: "Business Name",
  businessScale: "Business Scale",
  annualRevenue: "Annual Revenue",
  ownershipType: "Ownership Type",
  occupancy: "Occupancy",
  modeOfPayment: "Mode of Payment",
  permitApplicationType: "Permit Type",
  status: "Status",
  contactNumber: "Contact Number",
  numberOfEmployees: "Employees",
  businessArea: "Business Area",
  propertyIndexNumber: "Property Index No.",
};

function formatChangeValue(value: unknown): string {
  if (value === undefined || value === null || value === "") return "—";
  if (typeof value === "boolean") return value ? "Yes" : "No";
  return String(value);
}

function parseChangesForTable(changesStr?: string): { field: string; label: string; before?: unknown; after: unknown }[] {
  if (!changesStr) return [];
  try {
    const parsed = JSON.parse(changesStr) as Record<string, { before?: unknown; after: unknown }>;
    return Object.entries(parsed)
      .filter(([field]) => !HIDDEN_CHANGE_FIELDS.has(field))
      .map(([field, { before, after }]) => ({
        field,
        label: CHANGE_FIELD_LABELS[field] || field,
        before,
        after,
      }));
  } catch {
    return [];
  }
}

// Action display labels, colors, and icons
const ACTION_CONFIG: Record<
  string,
  {
    label: string;
    variant: "default" | "secondary" | "destructive" | "outline";
    icon: LucideIcon;
  }
> = {
  create: { label: "Created", variant: "default", icon: Plus },
  update: { label: "Updated", variant: "secondary", icon: Pencil },
  delete: { label: "Deleted", variant: "destructive", icon: Trash2 },
  restore: { label: "Restored", variant: "outline", icon: RotateCcw },
  status_change: { label: "Status Changed", variant: "secondary", icon: RefreshCw },
  payment: { label: "Payment Recorded", variant: "default", icon: Wallet },
  verification: { label: "Verified", variant: "default", icon: Check },
  issued: { label: "Issued", variant: "default", icon: Plus },
};

// Resource type display labels
const RESOURCE_TYPE_LABELS: Record<string, string> = {
  permit_application: "Document",
  payment: "Document",
  permit: "Document",
  business: "Business",
  business_owner: "Resident",
  clearance: "Document",
  kyc: "KYC",
  official_receipt: "Receipt",
  manual_transaction: "Document",
  resident: "Resident",
  billing_group: "Billing Group",
  billing_group_record: "Billing Record",
  settings: "Settings",
};

// Resource routes for navigation
const RESOURCE_ROUTES: Record<string, (id: string) => string> = {
  permit_application: (id) => `/dashboard/permits/${id}`,
  payment: () => `/dashboard/payments-billing`,
  permit: (id) => `/dashboard/permits/${id}`,
  business: (id) => `/dashboard/businesses/${id}`,
  business_owner: (id) => `/dashboard/business-owners/${id}`,
  clearance: () => `/dashboard/clearances`,
  billing_group: (id) => `/dashboard/billing-groups/${id}`,
  billing_group_record: () => `/dashboard/payments-billing`,
};

interface ActivityTableProps {
  logs: ActivityLog[];
}

export function ActivityTable({ logs }: ActivityTableProps) {
  const formatDate = (timestamp: number) => {
    return format(new Date(timestamp), "MMM d");
  };

  const formatTime = (timestamp: number) => {
    return format(new Date(timestamp), "HH:mm:ss");
  };

  const getActionConfig = (action: string) => {
    return (
      ACTION_CONFIG[action] ?? {
        label: action,
        variant: "outline" as const,
        icon: Pencil,
      }
    );
  };

  const getResourceTypeLabel = (resourceType: string) => {
    return RESOURCE_TYPE_LABELS[resourceType] ?? resourceType;
  };

  const getResourceRoute = (resourceType: string, resourceId: string) => {
    const routeFn = RESOURCE_ROUTES[resourceType];
    return routeFn ? routeFn(resourceId) : null;
  };

  if (logs.length === 0) {
    return null;
  }

  return (
    <TooltipProvider>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-32">Time</TableHead>
            <TableHead className="w-32">Action</TableHead>
            <TableHead className="w-40">Performer</TableHead>
            <TableHead>Details</TableHead>
            <TableHead>Changes</TableHead>
            <TableHead className="w-28">Type</TableHead>
            <TableHead className="w-12">Link</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {logs.map((log) => {
            const actionConfig = getActionConfig(log.action);
            const resourceRoute = getResourceRoute(log.resourceType, log.resourceId);
            const ActionIcon = actionConfig.icon;

            return (
              <TableRow key={log._id}>
                <TableCell className="font-mono text-xs">
                  <div className="flex flex-col">
                    <span>{formatDate(log.timestamp)}</span>
                    <span className="text-muted-foreground">{formatTime(log.timestamp)}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <ActionIcon className="h-4 w-4 text-muted-foreground" />
                    <Badge variant={actionConfig.variant}>{actionConfig.label}</Badge>
                  </div>
                </TableCell>
                <TableCell>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span className="cursor-default truncate block max-w-[140px]">
                        {log.performerName}
                      </span>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{log.performerName}</p>
                      {log.performerPhone && (
                        <p className="text-muted-foreground text-xs">{log.performerPhone}</p>
                      )}
                    </TooltipContent>
                  </Tooltip>
                </TableCell>
                <TableCell>
                  <div className="flex flex-col">
                    <span className="truncate max-w-[400px]">{log.description}</span>
                    {log.resourceLabel && (
                      <span className="text-xs text-muted-foreground">
                        {log.resourceLabel}
                      </span>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  {(() => {
                    const changes = parseChangesForTable(log.changes);
                    if (changes.length === 0) return <span className="text-muted-foreground text-xs">—</span>;
                    return (
                      <div className="space-y-0.5 max-w-[300px]">
                        {changes.map((change) => (
                          <div key={change.field} className="text-xs flex items-center gap-1 flex-wrap">
                            <span className="font-medium text-muted-foreground">{change.label}:</span>
                            {change.before !== undefined && change.before !== null && change.before !== "" && (
                              <>
                                <span className="line-through opacity-50">{formatChangeValue(change.before)}</span>
                                <span className="text-muted-foreground/60">&rarr;</span>
                              </>
                            )}
                            <span className="font-medium">{formatChangeValue(change.after)}</span>
                          </div>
                        ))}
                      </div>
                    );
                  })()}
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="text-xs">
                    {getResourceTypeLabel(log.resourceType)}
                  </Badge>
                </TableCell>
                <TableCell>
                  {resourceRoute ? (
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={resourceRoute}>
                            <ExternalLink className="h-4 w-4" />
                          </Link>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>View resource</TooltipContent>
                    </Tooltip>
                  ) : (
                    <span className="text-muted-foreground text-xs">-</span>
                  )}
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </TooltipProvider>
  );
}
