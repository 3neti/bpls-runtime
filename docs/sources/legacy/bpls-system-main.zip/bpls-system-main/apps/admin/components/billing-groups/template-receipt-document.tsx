"use client"

import { Document, Page, Text, View, StyleSheet } from "@react-pdf/renderer"
import {
  parseBillingGroupTemplate,
  formatCurrency,
  type BillingGroupMacroData,
  type BillingGroupLineItem,
  type BillingGroupFeeField,
} from "@/lib/utils/billing-group-template-renderer"
import type { ReceiptData } from "./receipt-document"

// Paper sizes in points (1 point = 1/72 inch)
const PAPER_SIZES = {
  A4: { width: 595.28, height: 841.89 },
  Letter: { width: 612, height: 792 },
  "Half-Letter": { width: 396, height: 612 },
}

// Fixed table configuration for consistent receipt formatting
const TABLE_FIXED_ROWS = 11
const ROW_HEIGHT = 11 // points (fontSize 10 + marginBottom 1)

// ✅ Module-level base styles (static) - MUST be outside component
// StyleSheet.create() maintains an internal global registry in @react-pdf/renderer.
// When called inside a component, new styles are registered on every render.
// In production (Vercel), module state persists across renders, causing registry corruption
// and the "l1 is not a function" error when viewing receipts multiple times.
const baseStyles = StyleSheet.create({
  page: {
    backgroundColor: "#ffffff",
    color: "#000000",
  },
  text: {
    marginBottom: 2,
  },
  header: {
    marginBottom: 15,
  },
  body: {
    flex: 1,
  },
  footer: {
    marginTop: 15,
  },
  lineItemsTable: {
    marginVertical: 10,
  },
  lineItemRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    height: ROW_HEIGHT,
    marginBottom: 1,
  },
  lineItemName: {
    flex: 1,
    overflow: 'hidden',
  },
  lineItemAmount: {
    width: 80,
    textAlign: "right",
  },
  emptyState: {
    color: "#999999",
    fontStyle: "italic",
  },
})

export interface TemplateReceiptLayout {
  paperSize: "A4" | "Letter" | "Half-Letter"
  orientation: "portrait" | "landscape"
  marginTop: number
  marginRight: number
  marginBottom: number
  marginLeft: number
  fontSize: number
  fontFamily: "Helvetica" | "Times-Roman" | "Courier"
  headerTemplate: string
  bodyTemplate: string
  footerTemplate: string
}

interface TemplateReceiptDocumentProps {
  data: ReceiptData
  layout: TemplateReceiptLayout
}

// Convert mm to points (1mm = 2.83465 points)
const mmToPoints = (mm: number) => mm * 2.83465

/**
 * Truncate text to max characters with ellipsis
 * Ensures text fits in single line within fixed-width table cells
 */
const truncateText = (text: string, maxChars: number): string => {
  if (!text || text.length <= maxChars) return text
  return text.substring(0, maxChars - 3) + "..."
}

// Convert ReceiptData to BillingGroupMacroData
function convertToMacroData(data: ReceiptData): BillingGroupMacroData {
  return {
    transactionNumber: data.transactionNumber,
    date: data.date,
    status: data.status,
    totalAmount: data.totalAmount,
    paymentMethod: data.paymentMethod,
    referenceNumber: data.referenceNumber,
    description: data.description,
    billingGroupName: data.billingGroupName,
    lineItems: data.lineItems.map((item) => ({
      feeCode: item.feeCode,
      feeName: item.feeName,
      amount: item.amount,
      quantity: item.quantity,
      subtotal: item.subtotal,
      customFieldValues: item.customFieldValues?.map((cfv) => ({
        fieldId: cfv.fieldId,
        value: cfv.value,
      })),
    })),
    feeFields: data.feeFields?.map((f) => ({
      fieldId: f.fieldId,
      name: f.name,
      fieldType: f.fieldType,
    })),
    headerFields: data.headerFields?.map((f) => ({
      fieldId: f.fieldId,
      name: f.name,
      value: f.value,
    })),
    currentDate: data.printDate || new Date().toISOString(),
  }
}

export function TemplateReceiptDocument({
  data,
  layout,
}: TemplateReceiptDocumentProps) {
  // Get paper dimensions based on size and orientation
  const size = PAPER_SIZES[layout.paperSize] || PAPER_SIZES.A4
  const dimensions =
    layout.orientation === "landscape"
      ? { width: size.height, height: size.width }
      : size

  // Calculate max characters for line item names based on available width
  // Available width = page width - left margin - right margin - amount column (80pt)
  // Character width ≈ fontSize * 0.5 (conservative estimate for Helvetica)
  const availableWidth = dimensions.width - mmToPoints(layout.marginLeft || 10) - mmToPoints(layout.marginRight || 10) - 80
  const charWidth = (layout.fontSize || 10) * 0.5
  const maxLineItemNameChars = Math.max(40, Math.floor(availableWidth / charWidth))

  // ✅ Dynamic styles as plain objects (NOT StyleSheet.create)
  // These depend on layout props and must be computed per-render
  const dynamicPageStyle = {
    paddingTop: mmToPoints(layout.marginTop || 10),
    paddingRight: mmToPoints(layout.marginRight || 10),
    paddingBottom: mmToPoints(layout.marginBottom || 10),
    paddingLeft: mmToPoints(layout.marginLeft || 10),
    fontSize: layout.fontSize || 10,
    fontFamily: layout.fontFamily || "Helvetica",
  }

  const tableHeightStyle = {
    height: TABLE_FIXED_ROWS * (ROW_HEIGHT + 1), // Account for marginBottom in each row
  }

  // Convert receipt data to macro data
  const macroData = convertToMacroData(data)

  // Parse templates with data - wrap in try-catch for safety
  let parsedHeader = ""
  let parsedBody = ""
  let parsedFooter = ""

  try {
    parsedHeader = parseBillingGroupTemplate(layout.headerTemplate || "", macroData)
    parsedBody = parseBillingGroupTemplate(layout.bodyTemplate || "", macroData)
    parsedFooter = parseBillingGroupTemplate(layout.footerTemplate || "", macroData)
  } catch (e) {
    console.error("Template parsing error:", e)
  }

  // Preserve whitespace by converting spaces to non-breaking spaces
  const preserveWhitespace = (text: string): string => {
    if (!text) return ""
    return text.replace(/ /g, "\u00A0")
  }

  // Helper to get custom field value from line item
  const getCustomFieldValue = (
    item: BillingGroupLineItem,
    fieldId: string
  ): string => {
    if (!item.customFieldValues) return ""
    const fieldValue = item.customFieldValues.find((fv) => fv.fieldId === fieldId)
    return fieldValue?.value || ""
  }

  // Helper to format fee field value for display
  const formatFeeFieldValue = (
    fieldType: BillingGroupFeeField["fieldType"],
    value: string
  ): string => {
    if (!value) return ""

    if (fieldType === "currency") {
      const num = parseFloat(value)
      return isNaN(num) ? value : formatCurrency(num)
    }
    if (fieldType === "checkbox") {
      return value === "true" ? "Yes" : "No"
    }
    if (fieldType === "date") {
      try {
        return new Date(value).toLocaleDateString("en-PH", {
          year: "numeric",
          month: "short",
          day: "numeric",
        })
      } catch {
        return value
      }
    }
    return value
  }

  // Build display name with custom field values appended
  const buildLineItemDisplayName = (
    item: BillingGroupLineItem,
    feeFields: BillingGroupFeeField[] | undefined
  ): string => {
    let displayName = item.feeName

    // Append custom field values if any
    if (feeFields && feeFields.length > 0) {
      const fieldParts: string[] = []
      for (const field of feeFields) {
        const value = getCustomFieldValue(item, field.fieldId)
        if (value) {
          const formattedValue = formatFeeFieldValue(field.fieldType, value)
          fieldParts.push(`${field.name}: ${formattedValue}`)
        }
      }
      if (fieldParts.length > 0) {
        displayName += ` (${fieldParts.join(", ")})`
      }
    }

    return displayName
  }

  // Render line items table with fixed 11 rows
  const renderLineItemsTable = (
    lineItems: BillingGroupLineItem[] | undefined,
    feeFields: BillingGroupFeeField[] | undefined
  ) => {
    const items = lineItems || []
    const emptyRowsCount = Math.max(0, TABLE_FIXED_ROWS - items.length)

    return (
      <View style={[baseStyles.lineItemsTable, tableHeightStyle]}>
        {/* Render actual items (max 11) */}
        {items.slice(0, TABLE_FIXED_ROWS).map((item, index) => {
          const displayName = buildLineItemDisplayName(item, feeFields)
          return (
            <View key={index} style={baseStyles.lineItemRow}>
              <Text style={baseStyles.lineItemName}>{truncateText(displayName, maxLineItemNameChars)}</Text>
              <Text style={baseStyles.lineItemAmount}>{formatCurrency(item.subtotal)}</Text>
            </View>
          )
        })}
        {/* Render empty rows to fill to 11 */}
        {Array.from({ length: emptyRowsCount }).map((_, index) => (
          <View key={`empty-${index}`} style={baseStyles.lineItemRow}>
            <Text style={baseStyles.lineItemName}>{"\u00A0"}</Text>
            <Text style={baseStyles.lineItemAmount}>{"\u00A0"}</Text>
          </View>
        ))}
      </View>
    )
  }

  // Render lines of text
  const renderLines = (content: string) => {
    if (!content) return null

    const lines = content.split("\n")
    return (
      <>
        {lines.map((line, index) => (
          <Text key={index} style={baseStyles.text}>
            {preserveWhitespace(line) || "\u00A0"}
          </Text>
        ))}
      </>
    )
  }

  // Render text with line breaks and handle {{LINE_ITEMS_TABLE}}
  const renderTemplateContent = (content: string) => {
    if (!content) return null

    // Split by LINE_ITEMS_TABLE marker - use regex for robust whitespace handling
    if (/\{\{\s*LINE_ITEMS_TABLE\s*\}\}/.test(content)) {
      const parts = content.split(/\{\{\s*LINE_ITEMS_TABLE\s*\}\}/)
      return (
        <>
          {parts[0] && renderLines(parts[0])}
          {renderLineItemsTable(macroData.lineItems, macroData.feeFields)}
          {parts[1] && renderLines(parts[1])}
        </>
      )
    }

    return renderLines(content)
  }

  // Check if all templates are empty
  const isEmpty = !parsedHeader && !parsedBody && !parsedFooter

  return (
    <Document>
      {/* Combine static baseStyles with dynamic styles */}
      <Page size={dimensions} style={[baseStyles.page, dynamicPageStyle]}>
        {isEmpty ? (
          <View style={baseStyles.body}>
            <Text style={baseStyles.emptyState}>No template content</Text>
          </View>
        ) : (
          <>
            {/* Header */}
            <View style={baseStyles.header}>{renderTemplateContent(parsedHeader)}</View>

            {/* Body */}
            <View style={baseStyles.body}>{renderTemplateContent(parsedBody)}</View>

            {/* Footer */}
            <View style={baseStyles.footer}>{renderTemplateContent(parsedFooter)}</View>
          </>
        )}
      </Page>
    </Document>
  )
}
