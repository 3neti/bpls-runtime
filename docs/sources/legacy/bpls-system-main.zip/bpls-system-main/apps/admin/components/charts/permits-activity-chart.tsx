"use client";
import { Area, AreaChart, CartesianGrid, XAxis } from "recharts";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import {
  type ChartConfig,
  ChartContainer,
  ChartLegend,
  ChartLegendContent,
  ChartTooltip,
  ChartTooltipContent,
} from "@repo/ui/components/chart";
import { Skeleton } from "@repo/ui/components/skeleton";

interface ChartDataPoint {
  date: string;
  new: number;
  renewal: number;
}

interface PermitsActivityChartProps {
  data?: ChartDataPoint[];
  isLoading?: boolean;
}

const chartConfig = {
  applications: {
    label: "Applications",
  },
  new: {
    label: "New Applications",
    color: "hsl(var(--chart-1))",
  },
  renewal: {
    label: "Renewals",
    color: "hsl(var(--chart-2))",
  },
} satisfies ChartConfig;

export function PermitsActivityChart({ data, isLoading }: PermitsActivityChartProps) {
  // Show skeleton while loading
  if (isLoading) {
    return (
      <Card className="pt-0">
        <CardHeader className="flex items-center gap-2 space-y-0 border-b py-5">
          <div className="grid flex-1 gap-1">
            <CardTitle>Permits Activity</CardTitle>
            <CardDescription>Showing permit applications for the selected period</CardDescription>
          </div>
        </CardHeader>
        <CardContent className="px-2 pt-4 sm:px-6 sm:pt-13">
          <Skeleton className="h-[250px] w-full" />
        </CardContent>
      </Card>
    );
  }

  // Use provided data or show empty state
  const chartData = data || [];
  const hasData = chartData.length > 0 && chartData.some((d) => d.new > 0 || d.renewal > 0);

  return (
    <Card className="pt-0">
      <CardHeader className="flex items-center gap-2 space-y-0 border-b py-5">
        <div className="grid flex-1 gap-1">
          <CardTitle>Permits Activity</CardTitle>
          <CardDescription>Showing permit applications for the selected period</CardDescription>
        </div>
      </CardHeader>
      <CardContent className="px-2 pt-4 sm:px-6 sm:pt-13">
        {!hasData ? (
          <div className="flex h-[250px] items-center justify-center text-muted-foreground">
            No application data available for this period
          </div>
        ) : (
          <ChartContainer config={chartConfig} className="aspect-auto h-[250px] w-full">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="fillNew" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="var(--color-new)" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="var(--color-new)" stopOpacity={0.1} />
                </linearGradient>
                <linearGradient id="fillRenewal" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="var(--color-renewal)" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="var(--color-renewal)" stopOpacity={0.1} />
                </linearGradient>
              </defs>
              <CartesianGrid vertical={false} />
              <XAxis
                dataKey="date"
                tickLine={false}
                axisLine={false}
                tickMargin={8}
                minTickGap={32}
                tickFormatter={(value) => {
                  const date = new Date(value);
                  return date.toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                  });
                }}
              />
              <ChartTooltip
                cursor={false}
                content={
                  <ChartTooltipContent
                    label=""
                    payload={[]}
                    labelFormatter={(value: string) => {
                      return new Date(value).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                      });
                    }}
                    indicator="dot"
                  />
                }
              />
              <Area dataKey="renewal" type="natural" fill="url(#fillRenewal)" stroke="var(--color-renewal)" stackId="a" />
              <Area dataKey="new" type="natural" fill="url(#fillNew)" stroke="var(--color-new)" stackId="a" />
              <ChartLegend content={<ChartLegendContent payload={[]} />} />
            </AreaChart>
          </ChartContainer>
        )}
      </CardContent>
    </Card>
  );
}
