"use client"

import React from "react"
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Image,
} from "@react-pdf/renderer"
import { formatDate } from "@/lib/utils/formatting"
import {
  type PermitMacroData,
} from "@/lib/utils/permit-template-renderer"
import { renderTipTapTemplateContent } from "@/lib/utils/permit-tiptap-pdf-renderer"

// Paper sizes in points (1 point = 1/72 inch)
const PAPER_SIZES = {
  LETTER: { width: 612, height: 792 },    // 8.5 x 11 in
  A4: { width: 595.28, height: 841.89 },  // 210 x 297 mm
  LEGAL: { width: 612, height: 1008 },    // 8.5 x 14 in
}

// Types for Mayor's Permit data
export interface MayorsPermitData {
  businessName: string
  ownerName: string
  businessAddress: string
  permitNumber: string
  dateIssued: string
  expirationDate: string
  qrCodeDataUrl: string
  applicationNumber?: string
  orNumber?: string

  // Settings - optional, uses defaults if not provided
  municipalityName?: string // e.g., "MUNICIPALITY OF IPIL"
  mayorName?: string // e.g., "HON. JUAN DELA CRUZ"
  mayorTitle?: string // e.g., "Municipal Mayor"

  // Extended fields for dynamic layout
  businessProvince?: string
  businessCityMunicipality?: string
  businessBarangay?: string
  businessTIN?: string
  businessEmail?: string
  businessContactNumber?: string
  ownershipType?: string
  dateStarted?: string
  registrationNumber?: string
  ownerAddress?: string
  ownerContactNumber?: string
  ownerEmail?: string
  provinceName?: string
  fullAddress?: string
  treasurerName?: string
  linesOfBusiness?: string[]
}

// Layout configuration from permit_layouts table
export interface PermitLayoutConfig {
  paperSize: "LETTER" | "A4" | "LEGAL"
  orientation: "portrait" | "landscape"
  marginTop: number
  marginRight: number
  marginBottom: number
  marginLeft: number
  headerTemplate: string
  bodyTemplate: string
  footerTemplate: string
  qrCodeSize?: number
  logoUrl?: string
  sealUrl?: string
  backgroundImageUrl?: string
  backgroundImageOpacity?: number
  backgroundImageWidth?: number
  backgroundImageHeight?: number
}

// Convert mm to points (1mm = 2.83465 points)
const mmToPoints = (mm: number) => mm * 2.83465

// Hardcoded styles for backward compatibility (when no layout is configured)
const hardcodedStyles = StyleSheet.create({
  page: {
    padding: 50,
    fontFamily: "Helvetica",
    backgroundColor: "#ffffff",
  },
  header: {
    textAlign: "center",
    marginBottom: 20,
    borderBottom: "2px solid #1a365d",
    paddingBottom: 15,
  },
  municipalityName: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#1a365d",
    marginBottom: 4,
  },
  officeName: {
    fontSize: 10,
    color: "#4a5568",
    marginBottom: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#1a365d",
    marginTop: 10,
    letterSpacing: 3,
  },
  permitNumberSection: {
    textAlign: "center",
    marginBottom: 25,
    marginTop: 15,
  },
  permitNumberLabel: {
    fontSize: 10,
    color: "#718096",
    marginBottom: 4,
  },
  permitNumber: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#2d3748",
  },
  certificationText: {
    fontSize: 11,
    textAlign: "center",
    marginBottom: 25,
    lineHeight: 1.5,
    color: "#4a5568",
  },
  detailsSection: {
    marginBottom: 25,
    padding: 15,
    backgroundColor: "#f7fafc",
    borderRadius: 4,
  },
  detailRow: {
    flexDirection: "row",
    marginBottom: 10,
  },
  detailLabel: {
    fontSize: 10,
    color: "#718096",
    width: "30%",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  detailValue: {
    fontSize: 12,
    color: "#2d3748",
    fontWeight: "bold",
    width: "70%",
  },
  validitySection: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 30,
    padding: 15,
    backgroundColor: "#ebf8ff",
    borderRadius: 4,
  },
  validityBox: {
    width: "48%",
    textAlign: "center",
  },
  validityLabel: {
    fontSize: 9,
    color: "#4299e1",
    marginBottom: 4,
    textTransform: "uppercase",
  },
  validityValue: {
    fontSize: 12,
    color: "#2b6cb0",
    fontWeight: "bold",
  },
  qrSection: {
    alignItems: "center",
    marginBottom: 30,
    marginTop: 10,
  },
  qrCode: {
    width: 100,
    height: 100,
    marginBottom: 8,
  },
  qrCaption: {
    fontSize: 8,
    color: "#a0aec0",
    textAlign: "center",
  },
  signatureSection: {
    marginTop: 40,
    alignItems: "center",
  },
  signatureLine: {
    borderTop: "1px solid #2d3748",
    width: 200,
    marginBottom: 8,
  },
  signatureTitle: {
    fontSize: 12,
    fontWeight: "bold",
    color: "#2d3748",
  },
  signatureSubtitle: {
    fontSize: 9,
    color: "#718096",
    marginTop: 2,
  },
  footer: {
    position: "absolute",
    bottom: 30,
    left: 50,
    right: 50,
    textAlign: "center",
    borderTop: "1px solid #e2e8f0",
    paddingTop: 10,
  },
  footerText: {
    fontSize: 8,
    color: "#a0aec0",
  },
})

// Default values for settings - generic titles only, names must be configured
const DEFAULT_MAYOR_TITLE = "Municipal Mayor"

// Hardcoded Mayor's Permit Document (backward compatibility)
function HardcodedMayorsPermitDocument({ data }: { data: MayorsPermitData }) {
  const municipalityName = data.municipalityName || ""
  const mayorTitle = data.mayorTitle || DEFAULT_MAYOR_TITLE

  return (
    <Document>
      <Page size="LETTER" style={hardcodedStyles.page}>
        {/* Header */}
        <View style={hardcodedStyles.header}>
          <Text style={hardcodedStyles.municipalityName}>{municipalityName}</Text>
          <Text style={hardcodedStyles.officeName}>Office of the Mayor</Text>
          <Text style={hardcodedStyles.title}>BUSINESS PERMIT</Text>
        </View>

        {/* Permit Number */}
        <View style={hardcodedStyles.permitNumberSection}>
          <Text style={hardcodedStyles.permitNumberLabel}>Permit Number</Text>
          <Text style={hardcodedStyles.permitNumber}>{data.permitNumber}</Text>
        </View>

        {/* Certification Text */}
        <Text style={hardcodedStyles.certificationText}>
          This is to certify that the business establishment named below has been
          granted permission to operate within the jurisdiction of this municipality,
          subject to existing laws, ordinances, and regulations.
        </Text>

        {/* Business Details */}
        <View style={hardcodedStyles.detailsSection}>
          <View style={hardcodedStyles.detailRow}>
            <Text style={hardcodedStyles.detailLabel}>Business Name</Text>
            <Text style={hardcodedStyles.detailValue}>{data.businessName}</Text>
          </View>
          <View style={hardcodedStyles.detailRow}>
            <Text style={hardcodedStyles.detailLabel}>Owner / Operator</Text>
            <Text style={hardcodedStyles.detailValue}>{data.ownerName}</Text>
          </View>
          <View style={hardcodedStyles.detailRow}>
            <Text style={hardcodedStyles.detailLabel}>Business Address</Text>
            <Text style={hardcodedStyles.detailValue}>{data.businessAddress}</Text>
          </View>
        </View>

        {/* Validity Dates */}
        <View style={hardcodedStyles.validitySection}>
          <View style={hardcodedStyles.validityBox}>
            <Text style={hardcodedStyles.validityLabel}>Date Issued</Text>
            <Text style={hardcodedStyles.validityValue}>{formatDate(data.dateIssued)}</Text>
          </View>
          <View style={hardcodedStyles.validityBox}>
            <Text style={hardcodedStyles.validityLabel}>Valid Until</Text>
            <Text style={hardcodedStyles.validityValue}>{formatDate(data.expirationDate)}</Text>
          </View>
        </View>

        {/* QR Code for Verification */}
        {data.qrCodeDataUrl && (
          <View style={hardcodedStyles.qrSection}>
            <Image src={data.qrCodeDataUrl} style={hardcodedStyles.qrCode} />
            <Text style={hardcodedStyles.qrCaption}>Scan to verify permit authenticity</Text>
          </View>
        )}

        {/* Signature Section */}
        <View style={hardcodedStyles.signatureSection}>
          <View style={hardcodedStyles.signatureLine} />
          <Text style={hardcodedStyles.signatureTitle}>{mayorTitle}</Text>
          <Text style={hardcodedStyles.signatureSubtitle}>Authorizing Official</Text>
        </View>

        {/* Footer */}
        <View style={hardcodedStyles.footer}>
          <Text style={hardcodedStyles.footerText}>
            This permit is non-transferable and must be displayed in a conspicuous place
            within the business premises.
          </Text>
        </View>
      </Page>
    </Document>
  )
}

// Dynamic Mayor's Permit Document (using layout configuration)
function DynamicMayorsPermitDocument({
  data,
  layout,
}: {
  data: MayorsPermitData
  layout: PermitLayoutConfig
}) {
  // Get paper dimensions based on size and orientation
  const size = PAPER_SIZES[layout.paperSize] || PAPER_SIZES.LETTER
  const dimensions = layout.orientation === "landscape"
    ? { width: size.height, height: size.width }
    : size

  const baseFontSize = 12
  const baseFontFamily = "Helvetica"

  // Create dynamic styles - padding on contentWrapper, not page,
  // so background image can fill the entire physical page.
  const dynamicStyles = StyleSheet.create({
    page: {
      fontSize: baseFontSize,
      fontFamily: baseFontFamily,
      backgroundColor: "#ffffff",
      color: "#000000",
    },
    contentWrapper: {
      paddingTop: mmToPoints(layout.marginTop || 15),
      paddingRight: mmToPoints(layout.marginRight || 15),
      paddingBottom: mmToPoints(layout.marginBottom || 15),
      paddingLeft: mmToPoints(layout.marginLeft || 15),
      flex: 1,
    },
    section: {
      marginBottom: 10,
    },
    text: {
      marginBottom: 2,
    },
    header: {
      marginBottom: 15,
    },
    body: {
      flex: 1,
    },
    footer: {
      marginTop: 15,
    },
    logo: {
      width: 60,
      height: 60,
    },
    seal: {
      width: 80,
      height: 80,
    },
    qrCode: {
      width: layout.qrCodeSize || 80,
      height: layout.qrCodeSize || 80,
    },
  })

  // Build macro data from permit data
  const macroData: PermitMacroData = {
    permitNumber: data.permitNumber,
    dateIssued: formatDate(data.dateIssued),
    expirationDate: formatDate(data.expirationDate),
    applicationNumber: data.applicationNumber || "",
    applicationType: "New", // Default, can be extended
    orNumber: data.orNumber || "",
    businessName: data.businessName,
    businessAddress: data.businessAddress,
    businessProvince: data.businessProvince || "",
    businessCityMunicipality: data.businessCityMunicipality || "",
    businessBarangay: data.businessBarangay || "",
    businessTIN: data.businessTIN || "",
    businessEmail: data.businessEmail || "",
    businessContactNumber: data.businessContactNumber || "",
    ownershipType: data.ownershipType || "",
    dateStarted: data.dateStarted || "",
    registrationNumber: data.registrationNumber || "",
    ownerName: data.ownerName,
    ownerAddress: data.ownerAddress || "",
    ownerContactNumber: data.ownerContactNumber || "",
    ownerEmail: data.ownerEmail || "",
    municipalityName: data.municipalityName || "",
    provinceName: data.provinceName || "",
    fullAddress: data.fullAddress || "",
    mayorName: data.mayorName || "",
    mayorTitle: data.mayorTitle || DEFAULT_MAYOR_TITLE,
    treasurerName: data.treasurerName || "",
    currentDate: new Date().toLocaleDateString(),
    currentYear: new Date().getFullYear().toString(),
    linesOfBusiness: data.linesOfBusiness || [],
  }

  // Helper functions for special macro rendering
  const renderLogo = () => {
    if (layout.logoUrl) {
      return <Image src={layout.logoUrl} style={dynamicStyles.logo} />
    }
    return null
  }

  const renderSeal = () => {
    if (layout.sealUrl) {
      return <Image src={layout.sealUrl} style={dynamicStyles.seal} />
    }
    return null
  }

  const renderQrCode = () => {
    if (!data.qrCodeDataUrl) return null
    return <Image src={data.qrCodeDataUrl} style={dynamicStyles.qrCode} />
  }

  const renderLinesOfBusiness = () => {
    const lines = data.linesOfBusiness || []
    if (lines.length === 0) return null
    return <Text>{lines.join(", ")}</Text>
  }

  const templateHelpers = { renderLogo, renderSeal, renderQrCode, renderLinesOfBusiness }

  // Background image fills the entire physical page.
  // Since Page has no padding, top:0/left:0 = physical page origin.
  const bgW = layout.backgroundImageWidth ? mmToPoints(layout.backgroundImageWidth) : dimensions.width
  const bgH = layout.backgroundImageHeight ? mmToPoints(layout.backgroundImageHeight) : dimensions.height
  const bgImageStyles = StyleSheet.create({
    container: {
      position: "absolute" as const,
      top: (dimensions.height - bgH) / 2,
      left: (dimensions.width - bgW) / 2,
      width: bgW,
      height: bgH,
    },
    image: {
      width: "100%",
      height: "100%",
      opacity: layout.backgroundImageOpacity ?? 0.3,
    },
  })

  return (
    <Document>
      <Page size={dimensions} style={dynamicStyles.page}>
        {/* Background image - absolute, fills physical page */}
        {layout.backgroundImageUrl && (
          <View style={bgImageStyles.container}>
            <Image src={layout.backgroundImageUrl} style={bgImageStyles.image} />
          </View>
        )}

        {/* Content wrapper with margins */}
        <View style={dynamicStyles.contentWrapper}>
          {/* Header */}
          <View style={dynamicStyles.header}>
            {renderTipTapTemplateContent(layout.headerTemplate || "", macroData, baseFontFamily, baseFontSize, templateHelpers)}
          </View>

          {/* Body */}
          <View style={dynamicStyles.body}>
            {renderTipTapTemplateContent(layout.bodyTemplate || "", macroData, baseFontFamily, baseFontSize, templateHelpers)}
          </View>

          {/* Footer */}
          <View style={dynamicStyles.footer}>
            {renderTipTapTemplateContent(layout.footerTemplate || "", macroData, baseFontFamily, baseFontSize, templateHelpers)}
          </View>
        </View>
      </Page>
    </Document>
  )
}

// Main export - Mayor's Permit PDF Document Component
export function MayorsPermitDocument({
  data,
  layout,
}: {
  data: MayorsPermitData
  layout?: PermitLayoutConfig | null
}) {
  // If no layout is provided or layout has empty templates, use hardcoded version
  if (!layout || (!layout.headerTemplate && !layout.bodyTemplate && !layout.footerTemplate)) {
    return <HardcodedMayorsPermitDocument data={data} />
  }

  // Use dynamic layout
  return <DynamicMayorsPermitDocument data={data} layout={layout} />
}
