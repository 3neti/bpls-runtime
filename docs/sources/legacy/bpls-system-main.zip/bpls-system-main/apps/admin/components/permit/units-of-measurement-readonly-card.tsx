/**
 * UnitsOfMeasurementReadonlyCard Component
 *
 * A minimal read-only display component for units of measurement (asset variables).
 * Used in the releasing detail page to show configured units without edit capabilities.
 *
 * Features:
 * - Compact table display: Variable | Quantity | Description
 * - No add/edit/delete actions
 * - Shows "No units configured" if empty
 */

"use client";

import { useQuery } from "convex/react";
import { Ruler } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@repo/ui/components/table";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";

interface UnitsOfMeasurementReadonlyCardProps {
  /** Permit application ID to fetch units for */
  applicationId: Id<"business_permit_applications">;
}

export function UnitsOfMeasurementReadonlyCard({
  applicationId,
}: UnitsOfMeasurementReadonlyCardProps) {
  // Fetch units for this application
  const units = useQuery(api.unitsOfMeasurement.list.list, { applicationId });

  // Loading state
  if (units === undefined) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Ruler className="h-4 w-4" />
            Units of Measurement
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-6">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const hasUnits = units && units.length > 0;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Ruler className="h-4 w-4" />
          Units of Measurement
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!hasUnits ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            No units configured
          </p>
        ) : (
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[40%]">Variable</TableHead>
                  <TableHead className="text-right w-[20%]">Quantity</TableHead>
                  <TableHead className="w-[40%]">Description</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {units.map((unit) => (
                  <TableRow key={unit._id}>
                    <TableCell>
                      <code className="text-sm bg-muted px-2 py-0.5 rounded">
                        {unit.variableName}
                      </code>
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      {unit.quantity}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {unit.description || "-"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
