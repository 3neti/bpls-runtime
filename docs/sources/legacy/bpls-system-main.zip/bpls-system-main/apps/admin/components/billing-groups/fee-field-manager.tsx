"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { useMutation } from "convex/react"
import {
  Plus,
  GripVertical,
  MoreHorizontal,
  Pencil,
  Trash2,
  Type,
  Hash,
  DollarSign,
  Calendar,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ToggleLeft,
  Columns,
  Check,
  X,
  Search,
} from "lucide-react"

import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form"
import { Input } from "@repo/ui/components/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import { Switch } from "@repo/ui/components/switch"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import { useToast } from "@/hooks/use-toast"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

type FieldType = "text" | "number" | "currency" | "date" | "dropdown" | "checkbox"

interface Field {
  _id: Id<"billing_group_fee_fields">
  name: string
  fieldType: FieldType
  isRequired: boolean
  includeInReceipt?: boolean
  sortOrder: number
  options?: string[]
  placeholder?: string
  defaultValue?: string
}

interface FeeFieldManagerProps {
  billingGroupId: Id<"billing_groups">
  fields: Field[]
  canCreate?: boolean
  canUpdate?: boolean
  canDelete?: boolean
}

const fieldTypeConfig: Record<FieldType, { label: string; icon: React.ElementType }> = {
  text: { label: "Text", icon: Type },
  number: { label: "Number", icon: Hash },
  currency: { label: "Currency", icon: DollarSign },
  date: { label: "Date", icon: Calendar },
  dropdown: { label: "Dropdown", icon: ChevronDown },
  checkbox: { label: "Checkbox", icon: ToggleLeft },
}

const fieldFormSchema = z.object({
  name: z.string().min(1, "Field name is required"),
  fieldType: z.enum(["text", "number", "currency", "date", "dropdown", "checkbox"]),
  isRequired: z.boolean(),
  includeInReceipt: z.boolean(),
  placeholder: z.string().optional(),
  defaultValue: z.string().optional(),
})

type FieldFormValues = z.infer<typeof fieldFormSchema>

export function FeeFieldManager({ billingGroupId, fields, canCreate = true, canUpdate = true, canDelete = true }: FeeFieldManagerProps) {
  const { toast } = useToast()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingField, setEditingField] = useState<Field | null>(null)
  const [deletingFieldId, setDeletingFieldId] = useState<Id<"billing_group_fee_fields"> | null>(null)

  // Options management state (for dropdown field type)
  const [options, setOptions] = useState<string[]>([])
  const [newOption, setNewOption] = useState("")
  const [optionsPage, setOptionsPage] = useState(1)
  const [editingOptionIndex, setEditingOptionIndex] = useState<number | null>(null)
  const [editingOptionValue, setEditingOptionValue] = useState("")
  const [optionSearch, setOptionSearch] = useState("")
  const ITEMS_PER_PAGE = 5

  // Mutations
  const createField = useMutation(api.billingGroupFeeFields.create)
  const updateField = useMutation(api.billingGroupFeeFields.update)
  const deleteField = useMutation(api.billingGroupFeeFields.softDelete)
  const reorderFields = useMutation(api.billingGroupFeeFields.reorder)

  const form = useForm<FieldFormValues>({
    resolver: zodResolver(fieldFormSchema),
    defaultValues: {
      name: "",
      fieldType: "text",
      isRequired: false,
      includeInReceipt: false,
      placeholder: "",
      defaultValue: "",
    },
  })

  const selectedFieldType = form.watch("fieldType")

  // Reset options state
  const resetOptionsState = () => {
    setOptions([])
    setNewOption("")
    setOptionsPage(1)
    setOptionSearch("")
    setEditingOptionIndex(null)
    setEditingOptionValue("")
  }

  // Add option handler
  const handleAddOption = () => {
    const trimmedOption = newOption.trim()
    if (!trimmedOption) return

    // Check for duplicate (case-insensitive)
    const isDuplicate = options.some(
      (opt) => opt.toLowerCase() === trimmedOption.toLowerCase()
    )

    if (isDuplicate) {
      toast({
        title: "Duplicate Option",
        description: "This option already exists. Dropdown options must be unique.",
        variant: "destructive",
      })
      return
    }

    const newOptions = [...options, trimmedOption]
    setOptions(newOptions)
    setNewOption("")
    setOptionsPage(Math.ceil(newOptions.length / ITEMS_PER_PAGE))
  }

  // Remove option handler
  const handleRemoveOption = (index: number) => {
    const newOptions = options.filter((_, i) => i !== index)
    setOptions(newOptions)
    const maxPage = Math.max(1, Math.ceil(newOptions.length / ITEMS_PER_PAGE))
    if (optionsPage > maxPage) {
      setOptionsPage(maxPage)
    }
    if (editingOptionIndex === index) {
      setEditingOptionIndex(null)
      setEditingOptionValue("")
    } else if (editingOptionIndex !== null && editingOptionIndex > index) {
      setEditingOptionIndex(editingOptionIndex - 1)
    }
  }

  // Start editing option
  const handleStartEditOption = (index: number) => {
    setEditingOptionIndex(index)
    setEditingOptionValue(options[index])
  }

  // Save option edit
  const handleSaveOptionEdit = () => {
    if (editingOptionIndex === null) return

    const trimmedValue = editingOptionValue.trim()
    if (!trimmedValue) {
      setEditingOptionIndex(null)
      setEditingOptionValue("")
      return
    }

    const isDuplicate = options.some(
      (opt, i) => i !== editingOptionIndex && opt.toLowerCase() === trimmedValue.toLowerCase()
    )
    if (isDuplicate) {
      toast({
        title: "Duplicate Option",
        description: "This option already exists",
        variant: "destructive",
      })
      return
    }

    const newOptions = [...options]
    newOptions[editingOptionIndex] = trimmedValue
    setOptions(newOptions)
    setEditingOptionIndex(null)
    setEditingOptionValue("")
  }

  // Cancel option edit
  const handleCancelOptionEdit = () => {
    setEditingOptionIndex(null)
    setEditingOptionValue("")
  }

  const openAddModal = () => {
    setEditingField(null)
    form.reset({
      name: "",
      fieldType: "text",
      isRequired: false,
      includeInReceipt: false,
      placeholder: "",
      defaultValue: "",
    })
    resetOptionsState()
    setIsModalOpen(true)
  }

  const openEditModal = (field: Field) => {
    setEditingField(field)
    form.reset({
      name: field.name,
      fieldType: field.fieldType,
      isRequired: field.isRequired,
      includeInReceipt: field.includeInReceipt ?? false,
      placeholder: field.placeholder || "",
      defaultValue: field.defaultValue || "",
    })
    // Set options state from field
    setOptions(field.options || [])
    setNewOption("")
    setOptionsPage(1)
    setOptionSearch("")
    setEditingOptionIndex(null)
    setEditingOptionValue("")
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setIsModalOpen(false)
    setEditingField(null)
    form.reset()
    resetOptionsState()
  }

  const handleSubmit = async (values: FieldFormValues) => {
    // Validate dropdown fields require at least one option
    if (values.fieldType === "dropdown" && options.length === 0) {
      toast({
        title: "Validation Error",
        description: "Dropdown fields require at least one option",
        variant: "destructive",
      })
      return
    }

    try {
      if (editingField) {
        await updateField({
          id: editingField._id,
          name: values.name,
          fieldType: values.fieldType,
          isRequired: values.isRequired,
          includeInReceipt: values.includeInReceipt,
          options: values.fieldType === "dropdown" ? options : undefined,
          placeholder: values.placeholder || undefined,
          defaultValue: values.defaultValue || undefined,
        })
        toast({
          title: "Field updated",
          description: "The custom field has been updated.",
        })
      } else {
        await createField({
          billingGroupId,
          name: values.name,
          fieldType: values.fieldType,
          isRequired: values.isRequired,
          includeInReceipt: values.includeInReceipt,
          options: values.fieldType === "dropdown" ? options : undefined,
          placeholder: values.placeholder || undefined,
          defaultValue: values.defaultValue || undefined,
        })
        toast({
          title: "Field created",
          description: "A new custom field has been added.",
        })
      }

      closeModal()
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save field",
        variant: "destructive",
      })
    }
  }

  const handleDelete = async () => {
    if (!deletingFieldId) return

    try {
      await deleteField({ id: deletingFieldId })
      toast({
        title: "Field deleted",
        description: "The custom field has been removed.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete field",
        variant: "destructive",
      })
    } finally {
      setDeletingFieldId(null)
    }
  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Custom Columns</CardTitle>
              <CardDescription>
                Add custom columns to fees beyond Name, Code, and Default Amount
              </CardDescription>
            </div>
            {canCreate && (
              <Button onClick={openAddModal}>
                <Plus className="mr-2 h-4 w-4" />
                Add Column
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {fields.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Columns className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No custom columns</h3>
              <p className="text-muted-foreground mb-4 max-w-sm">
                Add custom columns to track additional information for each fee
              </p>
              {canCreate && (
                <Button onClick={openAddModal}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add First Column
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-2">
              {/* System Columns (non-editable) */}
              <div className="text-sm text-muted-foreground mb-4">
                <span className="font-medium">System Columns:</span> Code, Name, Default Amount, Status
              </div>

              {/* Custom Columns */}
              {fields.map((field) => {
                const config = fieldTypeConfig[field.fieldType]
                const Icon = config.icon

                return (
                  <div
                    key={field._id}
                    className="flex items-center gap-3 p-3 rounded-lg border bg-card"
                  >
                    <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
                    <div className="flex items-center gap-2 min-w-[100px]">
                      <Icon className="h-4 w-4 text-muted-foreground" />
                      <Badge variant="secondary" className="text-xs">
                        {config.label}
                      </Badge>
                    </div>
                    <div className="flex-1">
                      <span className="font-medium">{field.name}</span>
                      {field.isRequired && (
                        <span className="text-destructive ml-1">*</span>
                      )}
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        {canUpdate && (
                          <DropdownMenuItem onClick={() => openEditModal(field)}>
                            <Pencil className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                        )}
                        {canDelete && (
                          <>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() => setDeletingFieldId(field._id)}
                              className="text-destructive focus:text-destructive"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Field Modal */}
      <Dialog open={isModalOpen} onOpenChange={(isOpen) => !isOpen && closeModal()}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{editingField ? "Edit Column" : "Add Column"}</DialogTitle>
            <DialogDescription>
              {editingField
                ? "Update the custom column configuration."
                : "Add a new custom column to the fee library."}
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Column Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Category, Notes" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="fieldType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Column Type</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {Object.entries(fieldTypeConfig).map(([type, config]) => {
                          const Icon = config.icon
                          return (
                            <SelectItem key={type} value={type}>
                              <div className="flex items-center gap-2">
                                <Icon className="h-4 w-4" />
                                {config.label}
                              </div>
                            </SelectItem>
                          )
                        })}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="isRequired"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                    <div className="space-y-0.5">
                      <FormLabel>Required</FormLabel>
                      <FormDescription className="text-xs">
                        Must be filled when creating fees
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="includeInReceipt"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                    <div className="space-y-0.5">
                      <FormLabel>Include in Receipt</FormLabel>
                      <FormDescription className="text-xs">
                        Show this column value in the receipt printout
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              {selectedFieldType === "dropdown" && (
                <div className="space-y-2">
                  <FormLabel>Dropdown Options</FormLabel>
                  <div className="flex gap-2">
                    <Input
                      value={newOption}
                      onChange={(e) => setNewOption(e.target.value)}
                      placeholder="Add an option"
                      onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), handleAddOption())}
                    />
                    <Button type="button" variant="outline" onClick={handleAddOption}>
                      Add
                    </Button>
                  </div>
                  {options.length > 0 && (() => {
                    // Filter options based on search
                    const filteredOptions = options
                      .map((option, index) => ({ option, originalIndex: index }))
                      .filter(({ option }) =>
                        option.toLowerCase().includes(optionSearch.toLowerCase())
                      )

                    // Calculate pagination for filtered results
                    const totalPages = Math.max(1, Math.ceil(filteredOptions.length / ITEMS_PER_PAGE))
                    const paginatedOptions = filteredOptions.slice(
                      (optionsPage - 1) * ITEMS_PER_PAGE,
                      optionsPage * ITEMS_PER_PAGE
                    )

                    return (
                      <div className="space-y-2 mt-2">
                        {/* Search input for filtering options */}
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input
                            value={optionSearch}
                            onChange={(e) => {
                              setOptionSearch(e.target.value)
                              setOptionsPage(1) // Reset to first page when searching
                            }}
                            placeholder="Search options..."
                            className="pl-9"
                          />
                        </div>
                        <div className="rounded-md border">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead className="w-[60px]">#</TableHead>
                                <TableHead>Value</TableHead>
                                <TableHead className="w-[100px] text-right">Actions</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {filteredOptions.length === 0 ? (
                                <TableRow>
                                  <TableCell colSpan={3} className="text-center text-muted-foreground py-4">
                                    No options found matching &quot;{optionSearch}&quot;
                                  </TableCell>
                                </TableRow>
                              ) : (
                                paginatedOptions.map(({ option, originalIndex }) => {
                                  const isEditing = editingOptionIndex === originalIndex
                                  return (
                                    <TableRow key={originalIndex}>
                                      <TableCell className="font-medium text-muted-foreground">
                                        {originalIndex + 1}
                                      </TableCell>
                                      <TableCell>
                                        {isEditing ? (
                                          <Input
                                            value={editingOptionValue}
                                            onChange={(e) => setEditingOptionValue(e.target.value)}
                                            onKeyDown={(e) => {
                                              if (e.key === "Enter") {
                                                e.preventDefault()
                                                handleSaveOptionEdit()
                                              } else if (e.key === "Escape") {
                                                handleCancelOptionEdit()
                                              }
                                            }}
                                            className="h-8"
                                            autoFocus
                                          />
                                        ) : (
                                          <span
                                            className="cursor-pointer hover:text-primary"
                                            onDoubleClick={() => handleStartEditOption(originalIndex)}
                                          >
                                            {option}
                                          </span>
                                        )}
                                      </TableCell>
                                      <TableCell className="text-right">
                                        <div className="flex items-center justify-end gap-1">
                                          {isEditing ? (
                                            <>
                                              <Button
                                                type="button"
                                                variant="ghost"
                                                size="sm"
                                                onClick={handleSaveOptionEdit}
                                                className="h-8 w-8 p-0 hover:text-green-600"
                                              >
                                                <Check className="h-4 w-4" />
                                              </Button>
                                              <Button
                                                type="button"
                                                variant="ghost"
                                                size="sm"
                                                onClick={handleCancelOptionEdit}
                                                className="h-8 w-8 p-0 hover:text-muted-foreground"
                                              >
                                                <X className="h-4 w-4" />
                                              </Button>
                                            </>
                                          ) : (
                                            <>
                                              <Button
                                                type="button"
                                                variant="ghost"
                                                size="sm"
                                                onClick={() => handleStartEditOption(originalIndex)}
                                                className="h-8 w-8 p-0 hover:text-primary"
                                              >
                                                <Pencil className="h-4 w-4" />
                                              </Button>
                                              <Button
                                                type="button"
                                                variant="ghost"
                                                size="sm"
                                                onClick={() => handleRemoveOption(originalIndex)}
                                                className="h-8 w-8 p-0 hover:text-destructive"
                                              >
                                                <Trash2 className="h-4 w-4" />
                                              </Button>
                                            </>
                                          )}
                                        </div>
                                      </TableCell>
                                    </TableRow>
                                  )
                                })
                              )}
                            </TableBody>
                          </Table>
                        </div>
                        {/* Pagination controls - show if there are filtered results or total options > page size */}
                        {(filteredOptions.length > ITEMS_PER_PAGE || optionSearch) && (
                          <div className="flex items-center justify-between">
                            <p className="text-sm text-muted-foreground">
                              {optionSearch ? (
                                <>
                                  {filteredOptions.length} of {options.length} option{options.length !== 1 ? "s" : ""}
                                </>
                              ) : (
                                <>
                                  {options.length} option{options.length !== 1 ? "s" : ""} total
                                </>
                              )}
                            </p>
                            {totalPages > 1 && (
                              <div className="flex items-center gap-2">
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => setOptionsPage((p) => Math.max(1, p - 1))}
                                  disabled={optionsPage === 1}
                                >
                                  <ChevronLeft className="h-4 w-4" />
                                </Button>
                                <span className="text-sm text-muted-foreground">
                                  Page {optionsPage} of {totalPages}
                                </span>
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => setOptionsPage((p) => Math.min(totalPages, p + 1))}
                                  disabled={optionsPage >= totalPages}
                                >
                                  <ChevronRight className="h-4 w-4" />
                                </Button>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    )
                  })()}
                </div>
              )}

              <FormField
                control={form.control}
                name="placeholder"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Placeholder (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Placeholder text" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="defaultValue"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Default Value (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Default value" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button type="button" variant="outline" onClick={closeModal}>
                  Cancel
                </Button>
                <Button type="submit" disabled={form.formState.isSubmitting}>
                  {form.formState.isSubmitting
                    ? "Saving..."
                    : editingField
                      ? "Save Changes"
                      : "Add Column"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deletingFieldId !== null} onOpenChange={() => setDeletingFieldId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Column?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the custom column. Existing fee data for this column will be preserved but hidden.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
