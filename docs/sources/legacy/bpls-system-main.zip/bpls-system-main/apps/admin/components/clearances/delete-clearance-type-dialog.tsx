"use client"

import { useState } from "react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import { Loader2 } from "lucide-react"

interface DeleteClearanceTypeDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  clearanceTypeName: string
  onConfirm: () => Promise<void>
}

export function DeleteClearanceTypeDialog({
  open,
  onOpenChange,
  clearanceTypeName,
  onConfirm,
}: DeleteClearanceTypeDialogProps) {
  const [isDeleting, setIsDeleting] = useState(false)

  const handleConfirm = async () => {
    setIsDeleting(true)
    try {
      await onConfirm()
    } finally {
      setIsDeleting(false)
    }
  }

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete Clearance Type</AlertDialogTitle>
          <AlertDialogDescription>
            Are you sure you want to delete <strong>{clearanceTypeName}</strong>?
            <br />
            <br />
            This action cannot be undone. If there are permit clearances linked to this
            clearance type, the deletion will fail. Consider archiving the clearance
            type instead.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleConfirm}
            disabled={isDeleting}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            {isDeleting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
