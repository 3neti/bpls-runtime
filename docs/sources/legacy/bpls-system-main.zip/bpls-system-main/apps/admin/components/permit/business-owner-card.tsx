/**
 * BusinessOwnerCard Component
 *
 * Displays business owner information including:
 * - Profile photo with avatar fallback
 * - Personal information (name, birth date, TIN, civil status, etc.)
 * - Contact information (phone, email)
 * - Address
 */

import Link from "next/link"
import { User, Phone, Mail, MapPin, ExternalLink } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Avatar, AvatarFallback, AvatarImage } from "@repo/ui/components/avatar"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@repo/ui/components/tooltip"
import { formatDate, getInitials } from "@/lib/utils/permit-helpers"

import type { Id } from "@repo/backend/convex/_generated/dataModel"

export interface BusinessOwnerData {
  profilePhoto?: string
  fullName: string
  firstName: string
  middleName?: string
  lastName: string
  birthDate: string
  civilStatus: string
  gender: string
  citizenship: string
  tin?: string // Optional - not all business types require TIN
  mobile: string
  email: string
  address?: string // Optional address field
  provinceId?: Id<"provinces"> // Optional to allow partial data
  cityId?: Id<"cities"> // Optional to allow partial data
  barangayId?: Id<"barangays"> // Optional to allow partial data
  // New fields for link navigation and owner details
  ownerId?: Id<"business_owners"> // For navigation link
  ownerType?: string // "Single" or "Group"
  groupName?: string // Organization name (for Group type)
}

export interface BusinessOwnerCardProps {
  owner: BusinessOwnerData
}

export function BusinessOwnerCard({ owner }: BusinessOwnerCardProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Business Owner Information
          </CardTitle>
          {owner.ownerId && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href={`/dashboard/business-owners/${owner.ownerId}`}>
                    <ExternalLink className="h-4 w-4 text-muted-foreground hover:text-foreground cursor-pointer" />
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>View Business Owner Details</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center gap-4">
          <Avatar className="h-16 w-16">
            <AvatarImage src={owner.profilePhoto} alt={owner.fullName} />
            <AvatarFallback>{getInitials(owner.fullName)}</AvatarFallback>
          </Avatar>
          <div>
            <h3 className="text-xl font-semibold">{owner.fullName}</h3>
            <p className="text-muted-foreground">
              {owner.civilStatus} • {owner.gender} • {owner.citizenship}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-sm text-muted-foreground">Personal Information</h4>
              <div className="mt-2 space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Birth Date:</span>
                  <span className="text-sm font-medium">{formatDate(owner.birthDate)}</span>
                </div>
                {owner.tin && (
                  <div className="flex justify-between">
                    <span className="text-sm">TIN:</span>
                    <span className="text-sm font-medium">{owner.tin}</span>
                  </div>
                )}
                {owner.ownerType && (
                  <div className="flex justify-between">
                    <span className="text-sm">Owner Type:</span>
                    <span className="text-sm font-medium">{owner.ownerType}</span>
                  </div>
                )}
                {owner.ownerType === "Group" && owner.groupName && (
                  <div className="flex justify-between">
                    <span className="text-sm">Group Name:</span>
                    <span className="text-sm font-medium">{owner.groupName}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-sm text-muted-foreground">Contact Information</h4>
              <div className="mt-2 space-y-2">
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{owner.mobile}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{owner.email}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {owner.address && (
          <div>
            <h4 className="font-medium text-sm text-muted-foreground mb-2">Address</h4>
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">{owner.address}</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
