"use client"

import { useState } from "react"
import { useMutation } from "convex/react"
import {
  Plus,
  Trash2,
  GripVertical,
  Type,
  Hash,
  DollarSign,
  Calendar,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ToggleLeft,
  Pencil,
  Check,
  X,
  Search,
} from "lucide-react"

import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@repo/ui/components/table"
import { Input } from "@repo/ui/components/input"
import { Label } from "@repo/ui/components/label"
import { Switch } from "@repo/ui/components/switch"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import { useToast } from "@/hooks/use-toast"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

type FieldType = "text" | "number" | "currency" | "date" | "dropdown" | "checkbox"

interface Field {
  _id: Id<"billing_group_fields">
  name: string
  fieldType: FieldType
  isRequired: boolean
  isUnique?: boolean
  sortOrder: number
  options?: string[]
  placeholder?: string
  defaultValue?: string
}

interface FieldManagerProps {
  billingGroupId: Id<"billing_groups">
  fields: Field[]
  // Deprecated: Field mapping is no longer used - system columns handle amount/description
  amountFieldId?: Id<"billing_group_fields">
  descriptionFieldId?: Id<"billing_group_fields">
  /** Whether the user can create new fields. Defaults to true. */
  canCreate?: boolean
  /** Whether the user can update/edit fields (inline editing, reorder, designation controls). Defaults to true. */
  canUpdate?: boolean
  /** Whether the user can delete fields. Defaults to true. */
  canDelete?: boolean
}

const fieldTypeIcons: Record<FieldType, React.ReactNode> = {
  text: <Type className="h-4 w-4" />,
  number: <Hash className="h-4 w-4" />,
  currency: <DollarSign className="h-4 w-4" />,
  date: <Calendar className="h-4 w-4" />,
  dropdown: <ChevronDown className="h-4 w-4" />,
  checkbox: <ToggleLeft className="h-4 w-4" />,
}

const fieldTypeLabels: Record<FieldType, string> = {
  text: "Text",
  number: "Number",
  currency: "Currency (₱)",
  date: "Date",
  dropdown: "Dropdown",
  checkbox: "Checkbox",
}

export function FieldManager({
  billingGroupId,
  fields,
  canCreate = true,
  canUpdate = true,
  canDelete = true,
}: FieldManagerProps) {
  const { toast } = useToast()
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [editingField, setEditingField] = useState<Field | null>(null)
  const [deletingFieldId, setDeletingFieldId] = useState<Id<"billing_group_fields"> | null>(null)

  // Form state
  const [fieldName, setFieldName] = useState("")
  const [fieldType, setFieldType] = useState<FieldType>("text")
  const [isRequired, setIsRequired] = useState(false)
  const [isUnique, setIsUnique] = useState(false)
  const [placeholder, setPlaceholder] = useState("")
  const [defaultValue, setDefaultValue] = useState("")
  const [options, setOptions] = useState<string[]>([])
  const [newOption, setNewOption] = useState("")
  const [optionsPage, setOptionsPage] = useState(1)
  const [editingOptionIndex, setEditingOptionIndex] = useState<number | null>(null)
  const [editingOptionValue, setEditingOptionValue] = useState("")
  const [optionSearch, setOptionSearch] = useState("")
  const ITEMS_PER_PAGE = 5

  // Mutations
  const createField = useMutation(api.billingGroupFields.create)
  const updateField = useMutation(api.billingGroupFields.update)
  const deleteField = useMutation(api.billingGroupFields.softDelete)

  const resetForm = () => {
    setFieldName("")
    setFieldType("text")
    setIsRequired(false)
    setIsUnique(false)
    setPlaceholder("")
    setDefaultValue("")
    setOptions([])
    setNewOption("")
    setOptionsPage(1)
    setEditingOptionIndex(null)
    setEditingOptionValue("")
    setOptionSearch("")
  }

  const handleOpenAddModal = () => {
    resetForm()
    setIsAddModalOpen(true)
  }

  const handleOpenEditModal = (field: Field) => {
    setEditingField(field)
    setFieldName(field.name)
    setFieldType(field.fieldType)
    setIsRequired(field.isRequired)
    setIsUnique(field.isUnique ?? false)
    setPlaceholder(field.placeholder || "")
    setDefaultValue(field.defaultValue || "")
    setOptions(field.options || [])
  }

  const handleCloseModal = () => {
    setIsAddModalOpen(false)
    setEditingField(null)
    resetForm()
  }

  const handleAddOption = () => {
    const trimmedOption = newOption.trim()
    if (!trimmedOption) return

    // Check for duplicate (case-insensitive comparison)
    const isDuplicate = options.some(
      (opt) => opt.toLowerCase() === trimmedOption.toLowerCase()
    )

    if (isDuplicate) {
      toast({
        title: "Duplicate Option",
        description: "This option already exists. Dropdown options must be unique.",
        variant: "destructive",
      })
      return
    }

    const newOptions = [...options, trimmedOption]
    setOptions(newOptions)
    setNewOption("")
    // Navigate to last page to show the newly added option
    setOptionsPage(Math.ceil(newOptions.length / ITEMS_PER_PAGE))
  }

  const handleRemoveOption = (index: number) => {
    const newOptions = options.filter((_, i) => i !== index)
    setOptions(newOptions)
    // Adjust page if current page becomes empty after deletion
    const maxPage = Math.max(1, Math.ceil(newOptions.length / ITEMS_PER_PAGE))
    if (optionsPage > maxPage) {
      setOptionsPage(maxPage)
    }
    // Clear editing state if we're editing the deleted option
    if (editingOptionIndex === index) {
      setEditingOptionIndex(null)
      setEditingOptionValue("")
    } else if (editingOptionIndex !== null && editingOptionIndex > index) {
      // Adjust editing index if it's after the deleted item
      setEditingOptionIndex(editingOptionIndex - 1)
    }
  }

  const handleStartEditOption = (index: number) => {
    setEditingOptionIndex(index)
    setEditingOptionValue(options[index])
  }

  const handleSaveOptionEdit = () => {
    if (editingOptionIndex === null) return

    const trimmedValue = editingOptionValue.trim()
    if (!trimmedValue) {
      // Don't save empty values
      setEditingOptionIndex(null)
      setEditingOptionValue("")
      return
    }

    // Check for duplicates (excluding current item, case-insensitive)
    const isDuplicate = options.some(
      (opt, i) => i !== editingOptionIndex && opt.toLowerCase() === trimmedValue.toLowerCase()
    )
    if (isDuplicate) {
      toast({
        title: "Duplicate Option",
        description: "This option already exists",
        variant: "destructive",
      })
      return
    }

    const newOptions = [...options]
    newOptions[editingOptionIndex] = trimmedValue
    setOptions(newOptions)
    setEditingOptionIndex(null)
    setEditingOptionValue("")
  }

  const handleCancelOptionEdit = () => {
    setEditingOptionIndex(null)
    setEditingOptionValue("")
  }

  const handleSubmit = async () => {
    if (!fieldName.trim()) {
      toast({
        title: "Validation Error",
        description: "Field name is required",
        variant: "destructive",
      })
      return
    }

    if (fieldType === "dropdown" && options.length === 0) {
      toast({
        title: "Validation Error",
        description: "Dropdown fields require at least one option",
        variant: "destructive",
      })
      return
    }

    try {
      if (editingField) {
        await updateField({
          id: editingField._id,
          name: fieldName.trim(),
          fieldType,
          isRequired,
          isUnique,
          placeholder: placeholder || undefined,
          defaultValue: defaultValue || undefined,
          options: fieldType === "dropdown" ? options : undefined,
        })
        toast({
          title: "Field updated",
          description: `${fieldName} has been updated.`,
        })
      } else {
        await createField({
          billingGroupId,
          name: fieldName.trim(),
          fieldType,
          isRequired,
          isUnique,
          placeholder: placeholder || undefined,
          defaultValue: defaultValue || undefined,
          options: fieldType === "dropdown" ? options : undefined,
        })
        toast({
          title: "Field created",
          description: `${fieldName} has been added.`,
        })
      }
      handleCloseModal()
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save field",
        variant: "destructive",
      })
    }
  }

  const handleDelete = async () => {
    if (!deletingFieldId) return

    try {
      await deleteField({ id: deletingFieldId })
      toast({
        title: "Field deleted",
        description: "The field has been removed.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete field",
        variant: "destructive",
      })
    } finally {
      setDeletingFieldId(null)
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Additional Custom Fields</CardTitle>
            <CardDescription>
              Define custom fields beyond the built-in system columns (Date, Description, Payment Method, Reference Number).
            </CardDescription>
          </div>
          {canCreate && (
            <Button onClick={handleOpenAddModal}>
              <Plus className="mr-2 h-4 w-4" />
              Add Field
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {fields.length === 0 ? (
          <div className="text-center py-8">
            <Type className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No custom fields defined</h3>
            <p className="text-muted-foreground mb-4">
              System columns are already included. Add custom fields only if you need additional data beyond Date, Description, Payment Method, and Reference Number.
            </p>
            {canCreate && (
              <Button onClick={handleOpenAddModal}>
                <Plus className="mr-2 h-4 w-4" />
                Add Custom Field
              </Button>
            )}
          </div>
        ) : (
          <div className="space-y-2">
            {fields.map((field) => (
              <div
                key={field._id}
                className="flex items-center gap-3 p-3 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
              >
                <GripVertical className={`h-4 w-4 text-muted-foreground ${canUpdate ? "cursor-move" : "cursor-not-allowed opacity-50"}`} />

                <div className="flex items-center gap-2 min-w-[100px]">
                  {fieldTypeIcons[field.fieldType]}
                  <Badge variant="outline" className="text-xs">
                    {fieldTypeLabels[field.fieldType]}
                  </Badge>
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{field.name}</span>
                    {field.isRequired && (
                      <Badge variant="secondary" className="text-xs">
                        Required
                      </Badge>
                    )}
                    {field.isUnique && (
                      <Badge variant="outline" className="text-xs">
                        Unique
                      </Badge>
                    )}
                  </div>
                  {field.placeholder && (
                    <span className="text-xs text-muted-foreground">
                      Placeholder: {field.placeholder}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleOpenEditModal(field)}
                    disabled={!canUpdate}
                  >
                    Edit
                  </Button>
                  {canDelete && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setDeletingFieldId(field._id)}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>

      {/* Add/Edit Field Modal */}
      <Dialog open={isAddModalOpen || editingField !== null} onOpenChange={handleCloseModal}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{editingField ? "Edit Field" : "Add Field"}</DialogTitle>
            <DialogDescription>
              {editingField
                ? "Update field properties"
                : "Add a new field to this billing group"}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="fieldName">Field Name</Label>
              <Input
                id="fieldName"
                value={fieldName}
                onChange={(e) => setFieldName(e.target.value)}
                placeholder="e.g., Fee Name, Amount, Description"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="fieldType">Field Type</Label>
              <Select
                value={fieldType}
                onValueChange={(v) => setFieldType(v as FieldType)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(fieldTypeLabels).map(([value, label]) => (
                    <SelectItem key={value} value={value}>
                      <div className="flex items-center gap-2">
                        {fieldTypeIcons[value as FieldType]}
                        {label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Required Field</Label>
                <p className="text-xs text-muted-foreground">
                  User must fill this field when creating records
                </p>
              </div>
              <Switch checked={isRequired} onCheckedChange={setIsRequired} />
            </div>

            {fieldType !== "checkbox" && (
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Unique Field</Label>
                  <p className="text-xs text-muted-foreground">
                    Values must be unique across records in this group
                  </p>
                </div>
                <Switch checked={isUnique} onCheckedChange={setIsUnique} />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="placeholder">Placeholder (Optional)</Label>
              <Input
                id="placeholder"
                value={placeholder}
                onChange={(e) => setPlaceholder(e.target.value)}
                placeholder="Hint text shown when field is empty"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="defaultValue">Default Value (Optional)</Label>
              <Input
                id="defaultValue"
                value={defaultValue}
                onChange={(e) => setDefaultValue(e.target.value)}
                placeholder="Pre-filled value for new records"
              />
            </div>

            {fieldType === "dropdown" && (
              <div className="space-y-2">
                <Label>Dropdown Options</Label>
                <div className="flex gap-2">
                  <Input
                    value={newOption}
                    onChange={(e) => setNewOption(e.target.value)}
                    placeholder="Add an option"
                    onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), handleAddOption())}
                  />
                  <Button type="button" variant="outline" onClick={handleAddOption}>
                    Add
                  </Button>
                </div>
                {options.length > 0 && (() => {
                  // Filter options based on search
                  const filteredOptions = options
                    .map((option, index) => ({ option, originalIndex: index }))
                    .filter(({ option }) =>
                      option.toLowerCase().includes(optionSearch.toLowerCase())
                    )

                  // Calculate pagination for filtered results
                  const totalPages = Math.max(1, Math.ceil(filteredOptions.length / ITEMS_PER_PAGE))
                  const paginatedOptions = filteredOptions.slice(
                    (optionsPage - 1) * ITEMS_PER_PAGE,
                    optionsPage * ITEMS_PER_PAGE
                  )

                  return (
                    <div className="space-y-2 mt-2">
                      {/* Search input for filtering options */}
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          value={optionSearch}
                          onChange={(e) => {
                            setOptionSearch(e.target.value)
                            setOptionsPage(1) // Reset to first page when searching
                          }}
                          placeholder="Search options..."
                          className="pl-9"
                        />
                      </div>
                      <div className="rounded-md border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-[60px]">#</TableHead>
                              <TableHead>Value</TableHead>
                              <TableHead className="w-[100px] text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {filteredOptions.length === 0 ? (
                              <TableRow>
                                <TableCell colSpan={3} className="text-center text-muted-foreground py-4">
                                  No options found matching &quot;{optionSearch}&quot;
                                </TableCell>
                              </TableRow>
                            ) : (
                              paginatedOptions.map(({ option, originalIndex }) => {
                                const isEditing = editingOptionIndex === originalIndex
                                return (
                                  <TableRow key={originalIndex}>
                                    <TableCell className="font-medium text-muted-foreground">
                                      {originalIndex + 1}
                                    </TableCell>
                                    <TableCell>
                                      {isEditing ? (
                                        <Input
                                          value={editingOptionValue}
                                          onChange={(e) => setEditingOptionValue(e.target.value)}
                                          onKeyDown={(e) => {
                                            if (e.key === "Enter") {
                                              e.preventDefault()
                                              handleSaveOptionEdit()
                                            } else if (e.key === "Escape") {
                                              handleCancelOptionEdit()
                                            }
                                          }}
                                          className="h-8"
                                          autoFocus
                                        />
                                      ) : (
                                        <span
                                          className="cursor-pointer hover:text-primary"
                                          onDoubleClick={() => handleStartEditOption(originalIndex)}
                                        >
                                          {option}
                                        </span>
                                      )}
                                    </TableCell>
                                    <TableCell className="text-right">
                                      <div className="flex items-center justify-end gap-1">
                                        {isEditing ? (
                                          <>
                                            <Button
                                              type="button"
                                              variant="ghost"
                                              size="sm"
                                              onClick={handleSaveOptionEdit}
                                              className="h-8 w-8 p-0 hover:text-green-600"
                                            >
                                              <Check className="h-4 w-4" />
                                            </Button>
                                            <Button
                                              type="button"
                                              variant="ghost"
                                              size="sm"
                                              onClick={handleCancelOptionEdit}
                                              className="h-8 w-8 p-0 hover:text-muted-foreground"
                                            >
                                              <X className="h-4 w-4" />
                                            </Button>
                                          </>
                                        ) : (
                                          <>
                                            <Button
                                              type="button"
                                              variant="ghost"
                                              size="sm"
                                              onClick={() => handleStartEditOption(originalIndex)}
                                              className="h-8 w-8 p-0 hover:text-primary"
                                            >
                                              <Pencil className="h-4 w-4" />
                                            </Button>
                                            <Button
                                              type="button"
                                              variant="ghost"
                                              size="sm"
                                              onClick={() => handleRemoveOption(originalIndex)}
                                              className="h-8 w-8 p-0 hover:text-destructive"
                                            >
                                              <Trash2 className="h-4 w-4" />
                                            </Button>
                                          </>
                                        )}
                                      </div>
                                    </TableCell>
                                  </TableRow>
                                )
                              })
                            )}
                          </TableBody>
                        </Table>
                      </div>
                      {/* Pagination controls - show if there are filtered results or total options > page size */}
                      {(filteredOptions.length > ITEMS_PER_PAGE || optionSearch) && (
                        <div className="flex items-center justify-between">
                          <p className="text-sm text-muted-foreground">
                            {optionSearch ? (
                              <>
                                {filteredOptions.length} of {options.length} option{options.length !== 1 ? "s" : ""}
                              </>
                            ) : (
                              <>
                                {options.length} option{options.length !== 1 ? "s" : ""} total
                              </>
                            )}
                          </p>
                          {totalPages > 1 && (
                            <div className="flex items-center gap-2">
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => setOptionsPage((p) => Math.max(1, p - 1))}
                                disabled={optionsPage === 1}
                              >
                                <ChevronLeft className="h-4 w-4" />
                              </Button>
                              <span className="text-sm text-muted-foreground">
                                Page {optionsPage} of {totalPages}
                              </span>
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => setOptionsPage((p) => Math.min(totalPages, p + 1))}
                                disabled={optionsPage >= totalPages}
                              >
                                <ChevronRight className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )
                })()}
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={handleCloseModal}>
              Cancel
            </Button>
            <Button onClick={handleSubmit}>
              {editingField ? "Save Changes" : "Add Field"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deletingFieldId !== null} onOpenChange={() => setDeletingFieldId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Field?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the field from the billing group. Existing records will retain
              their data but the field will no longer be editable.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  )
}
