"use client"

import * as React from "react"
import { ChevronDown, RotateCcw } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@repo/ui/components/button"
import { Badge } from "@repo/ui/components/badge"
import { Checkbox } from "@repo/ui/components/checkbox"
import { Label } from "@repo/ui/components/label"
import { ScrollArea } from "@repo/ui/components/scroll-area"
import { Separator } from "@repo/ui/components/separator"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@repo/ui/components/collapsible"
import { ResourceSelector } from "./resource-selector"
import { DateRangePicker } from "./date-range-picker"
import { FilterBuilder } from "./filter-builder"
import { RESOURCE_CONFIGS, getAllDimensions } from "@/lib/config/report-resources"
import {
  useReportBuilderStore,
  useCurrentResourceConfig,
} from "@/lib/stores/report-builder-store"
import type { ResourceType, FilterGroup, DateRange } from "@/lib/types/report-builder"

interface ReportFiltersSidebarProps {
  onReset?: () => void
}

export function ReportFiltersSidebar({ onReset }: ReportFiltersSidebarProps) {
  const {
    resourceType,
    selectedDimensions,
    selectedMetrics,
    filters,
    dateRange,
    setResourceType,
    toggleDimension,
    setDimensions,
    clearDimensions,
    toggleMetric,
    setMetrics,
    clearMetrics,
    setFilters,
    setDateRange,
    resetAll,
  } = useReportBuilderStore()

  const currentConfig = useCurrentResourceConfig()

  // Collapsible section states
  const [columnsOpen, setColumnsOpen] = React.useState(true)
  const [metricsOpen, setMetricsOpen] = React.useState(true)
  const [dateRangeOpen, setDateRangeOpen] = React.useState(true)
  const [filtersOpen, setFiltersOpen] = React.useState(true)

  // Track expanded dimension groups
  const [expandedDimGroups, setExpandedDimGroups] = React.useState<Set<string>>(
    () => new Set()
  )

  // Track expanded metric groups
  const [expandedMetricGroups, setExpandedMetricGroups] = React.useState<Set<string>>(
    () => new Set()
  )

  // Initialize expanded groups when resource type changes
  React.useEffect(() => {
    if (currentConfig) {
      const defaultExpanded = new Set<string>()
      currentConfig.dimensionGroups.forEach((group) => {
        if (group.defaultExpanded) {
          defaultExpanded.add(group.id)
        }
      })
      setExpandedDimGroups(defaultExpanded)

      // Expand first metric group by default
      if (currentConfig.metricGroups.length > 0) {
        setExpandedMetricGroups(new Set([currentConfig.metricGroups[0].id]))
      }
    }
  }, [currentConfig])

  const toggleDimGroup = (groupId: string) => {
    setExpandedDimGroups((prev) => {
      const next = new Set(prev)
      if (next.has(groupId)) {
        next.delete(groupId)
      } else {
        next.add(groupId)
      }
      return next
    })
  }

  const toggleMetricGroup = (groupId: string) => {
    setExpandedMetricGroups((prev) => {
      const next = new Set(prev)
      if (next.has(groupId)) {
        next.delete(groupId)
      } else {
        next.add(groupId)
      }
      return next
    })
  }

  const handleResourceChange = (type: ResourceType) => {
    setResourceType(type)
  }

  const handleReset = () => {
    resetAll()
    onReset?.()
  }

  // Get date dimensions for date range picker
  const dateDimensions = React.useMemo(() => {
    if (!resourceType) return []
    return getAllDimensions(resourceType).filter((d) => d.type === "date")
  }, [resourceType])

  // Get filterable dimensions for filter builder
  const filterableDimensions = React.useMemo(() => {
    if (!resourceType) return []
    return getAllDimensions(resourceType).filter((d) => d.filterable)
  }, [resourceType])

  // Count active filters
  const activeFilterCount = React.useMemo(() => {
    let count = 0
    if (dateRange) count++
    if (filters?.conditions.length) count += filters.conditions.length
    return count
  }, [dateRange, filters])

  // Group selection helpers
  const getGroupSelectedCount = (
    groupDimensionIds: string[],
    selected: string[]
  ) => {
    return groupDimensionIds.filter((id) => selected.includes(id)).length
  }

  const isGroupFullySelected = (
    groupDimensionIds: string[],
    selected: string[]
  ) => {
    return groupDimensionIds.every((id) => selected.includes(id))
  }

  const handleSelectAllInGroup = (groupDimensionIds: string[]) => {
    const allSelected = isGroupFullySelected(groupDimensionIds, selectedDimensions)

    if (allSelected) {
      // Deselect all in group
      const newSelection = selectedDimensions.filter(
        (id) => !groupDimensionIds.includes(id)
      )
      setDimensions(newSelection)
    } else {
      // Select all in group
      const newSelection = [
        ...new Set([...selectedDimensions, ...groupDimensionIds]),
      ]
      setDimensions(newSelection)
    }
  }

  return (
    <div className="h-full bg-background">
      <ScrollArea className="h-full">
        <div className="p-3 space-y-3">
          {/* Header */}
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">
              Report Builder
            </h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleReset}
              className="h-6 px-2 text-xs"
            >
              <RotateCcw className="size-3 mr-1" />
              Reset
            </Button>
          </div>

          <Separator />

          {/* Data Source */}
          <div className="space-y-2">
            <ResourceSelector
              value={resourceType}
              onChange={handleResourceChange}
            />
          </div>

          {currentConfig && (
            <>
              <Separator />

              {/* Columns (Dimensions) */}
              <Collapsible open={columnsOpen} onOpenChange={setColumnsOpen}>
                <CollapsibleTrigger className="flex items-center justify-between w-full py-1">
                  <div className="flex items-center gap-2">
                    <Label className="text-xs font-medium text-muted-foreground cursor-pointer">
                      Columns
                    </Label>
                    {selectedDimensions.length > 0 && (
                      <Badge variant="secondary" className="h-5 text-xs">
                        {selectedDimensions.length}
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    {selectedDimensions.length > 0 && (
                      <span
                        role="button"
                        tabIndex={0}
                        onClick={(e) => {
                          e.stopPropagation()
                          clearDimensions()
                        }}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" || e.key === " ") {
                            e.stopPropagation()
                            e.preventDefault()
                            clearDimensions()
                          }
                        }}
                        className="h-5 px-1 text-xs text-muted-foreground hover:text-foreground cursor-pointer"
                      >
                        Clear
                      </span>
                    )}
                    <ChevronDown
                      className={cn(
                        "h-4 w-4 text-muted-foreground transition-transform",
                        columnsOpen && "rotate-180"
                      )}
                    />
                  </div>
                </CollapsibleTrigger>
                <CollapsibleContent className="pt-2">
                  <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                    {currentConfig.dimensionGroups.map((group) => {
                      const groupDimIds = group.dimensions.map((d) => d.id)
                      const selectedCount = getGroupSelectedCount(
                        groupDimIds,
                        selectedDimensions
                      )

                      return (
                        <Collapsible
                          key={group.id}
                          open={expandedDimGroups.has(group.id)}
                          onOpenChange={() => toggleDimGroup(group.id)}
                        >
                          <CollapsibleTrigger className="flex items-center justify-between w-full px-2 py-1.5 rounded-md hover:bg-accent text-sm">
                            <span className="font-medium truncate">
                              {group.name}
                            </span>
                            <div className="flex items-center gap-1">
                              {selectedCount > 0 && (
                                <Badge
                                  variant="outline"
                                  className="h-4 text-[10px] px-1"
                                >
                                  {selectedCount}
                                </Badge>
                              )}
                              <ChevronDown
                                className={cn(
                                  "h-3 w-3 text-muted-foreground transition-transform",
                                  expandedDimGroups.has(group.id) && "rotate-180"
                                )}
                              />
                            </div>
                          </CollapsibleTrigger>
                          <CollapsibleContent>
                            <div className="ml-2 space-y-0.5 py-1">
                              {/* Select all in group */}
                              <button
                                type="button"
                                onClick={() =>
                                  handleSelectAllInGroup(groupDimIds)
                                }
                                className="flex items-center gap-2 px-2 py-1 text-xs text-muted-foreground hover:text-foreground"
                              >
                                {isGroupFullySelected(
                                  groupDimIds,
                                  selectedDimensions
                                )
                                  ? "Deselect all"
                                  : "Select all"}
                              </button>
                              {group.dimensions.map((dimension) => (
                                <label
                                  key={dimension.id}
                                  className={cn(
                                    "flex items-center gap-2 px-2 py-1 rounded-md cursor-pointer hover:bg-accent transition-colors",
                                    selectedDimensions.includes(dimension.id) &&
                                      "bg-accent/50"
                                  )}
                                >
                                  <Checkbox
                                    checked={selectedDimensions.includes(
                                      dimension.id
                                    )}
                                    onCheckedChange={() =>
                                      toggleDimension(dimension.id)
                                    }
                                    className="h-3.5 w-3.5"
                                  />
                                  <span className="text-xs truncate">
                                    {dimension.name}
                                  </span>
                                </label>
                              ))}
                            </div>
                          </CollapsibleContent>
                        </Collapsible>
                      )
                    })}
                  </div>
                </CollapsibleContent>
              </Collapsible>

              <Separator />

              {/* Metrics */}
              <Collapsible open={metricsOpen} onOpenChange={setMetricsOpen}>
                <CollapsibleTrigger className="flex items-center justify-between w-full py-1">
                  <div className="flex items-center gap-2">
                    <Label className="text-xs font-medium text-muted-foreground cursor-pointer">
                      Metrics
                    </Label>
                    {selectedMetrics.length > 0 && (
                      <Badge variant="secondary" className="h-5 text-xs">
                        {selectedMetrics.length}
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    {selectedMetrics.length > 0 && (
                      <span
                        role="button"
                        tabIndex={0}
                        onClick={(e) => {
                          e.stopPropagation()
                          clearMetrics()
                        }}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" || e.key === " ") {
                            e.stopPropagation()
                            e.preventDefault()
                            clearMetrics()
                          }
                        }}
                        className="h-5 px-1 text-xs text-muted-foreground hover:text-foreground cursor-pointer"
                      >
                        Clear
                      </span>
                    )}
                    <ChevronDown
                      className={cn(
                        "h-4 w-4 text-muted-foreground transition-transform",
                        metricsOpen && "rotate-180"
                      )}
                    />
                  </div>
                </CollapsibleTrigger>
                <CollapsibleContent className="pt-2">
                  <div className="space-y-2 max-h-[250px] overflow-y-auto pr-1">
                    {currentConfig.metricGroups.map((group) => {
                      const selectedCount = group.metrics.filter((m) =>
                        selectedMetrics.includes(m.id)
                      ).length

                      return (
                        <Collapsible
                          key={group.id}
                          open={expandedMetricGroups.has(group.id)}
                          onOpenChange={() => toggleMetricGroup(group.id)}
                        >
                          <CollapsibleTrigger className="flex items-center justify-between w-full px-2 py-1.5 rounded-md hover:bg-accent text-sm">
                            <span className="font-medium truncate">
                              {group.name}
                            </span>
                            <div className="flex items-center gap-1">
                              {selectedCount > 0 && (
                                <Badge
                                  variant="outline"
                                  className="h-4 text-[10px] px-1"
                                >
                                  {selectedCount}
                                </Badge>
                              )}
                              <ChevronDown
                                className={cn(
                                  "h-3 w-3 text-muted-foreground transition-transform",
                                  expandedMetricGroups.has(group.id) &&
                                    "rotate-180"
                                )}
                              />
                            </div>
                          </CollapsibleTrigger>
                          <CollapsibleContent>
                            <div className="ml-2 space-y-0.5 py-1">
                              {group.metrics.map((metric) => (
                                <label
                                  key={metric.id}
                                  className={cn(
                                    "flex items-center gap-2 px-2 py-1 rounded-md cursor-pointer hover:bg-accent transition-colors",
                                    selectedMetrics.includes(metric.id) &&
                                      "bg-accent/50"
                                  )}
                                  title={metric.description}
                                >
                                  <Checkbox
                                    checked={selectedMetrics.includes(metric.id)}
                                    onCheckedChange={() => toggleMetric(metric.id)}
                                    className="h-3.5 w-3.5"
                                  />
                                  <span className="text-xs truncate flex-1">
                                    {metric.name}
                                  </span>
                                  <Badge
                                    variant="outline"
                                    className="h-4 text-[9px] px-1"
                                  >
                                    {metric.aggregation === "count"
                                      ? "#"
                                      : metric.aggregation === "sum"
                                        ? "Σ"
                                        : metric.aggregation === "average"
                                          ? "Avg"
                                          : metric.aggregation}
                                  </Badge>
                                </label>
                              ))}
                            </div>
                          </CollapsibleContent>
                        </Collapsible>
                      )
                    })}
                  </div>
                </CollapsibleContent>
              </Collapsible>

              <Separator />

              {/* Date Range */}
              <Collapsible open={dateRangeOpen} onOpenChange={setDateRangeOpen}>
                <CollapsibleTrigger className="flex items-center justify-between w-full py-1">
                  <div className="flex items-center gap-2">
                    <Label className="text-xs font-medium text-muted-foreground cursor-pointer">
                      Date Range
                    </Label>
                    {dateRange && (
                      <Badge variant="secondary" className="h-5 text-xs">
                        1
                      </Badge>
                    )}
                  </div>
                  <ChevronDown
                    className={cn(
                      "h-4 w-4 text-muted-foreground transition-transform",
                      dateRangeOpen && "rotate-180"
                    )}
                  />
                </CollapsibleTrigger>
                <CollapsibleContent className="pt-2">
                  <DateRangePicker
                    value={dateRange}
                    onChange={setDateRange}
                    dateDimensions={dateDimensions}
                    primaryDimensionId={currentConfig.primaryDateDimension}
                  />
                </CollapsibleContent>
              </Collapsible>

              <Separator />

              {/* Filters */}
              <Collapsible open={filtersOpen} onOpenChange={setFiltersOpen}>
                <CollapsibleTrigger className="flex items-center justify-between w-full py-1">
                  <div className="flex items-center gap-2">
                    <Label className="text-xs font-medium text-muted-foreground cursor-pointer">
                      Filters
                    </Label>
                    {filters?.conditions.length ? (
                      <Badge variant="secondary" className="h-5 text-xs">
                        {filters.conditions.length}
                      </Badge>
                    ) : null}
                  </div>
                  <ChevronDown
                    className={cn(
                      "h-4 w-4 text-muted-foreground transition-transform",
                      filtersOpen && "rotate-180"
                    )}
                  />
                </CollapsibleTrigger>
                <CollapsibleContent className="pt-2">
                  <FilterBuilder
                    dimensions={filterableDimensions}
                    filterGroup={filters}
                    onChange={setFilters}
                    maxHeight="200px"
                  />
                </CollapsibleContent>
              </Collapsible>
            </>
          )}
        </div>
      </ScrollArea>
    </div>
  )
}
