"use client"

import { PDFViewer as ReactPDFViewer, PDFDownloadLink as ReactPDFDownloadLink } from "@react-pdf/renderer"
import { ReactElement } from "react"

// Cast to any to work around React 19 typing incompatibility with @react-pdf/renderer
const PDFViewer = ReactPDFViewer as any
const PDFDownloadLink = ReactPDFDownloadLink as any

interface PDFViewerWrapperProps {
  children: ReactElement
  width?: string | number
  height?: string | number
  showToolbar?: boolean
  className?: string
}

export function PDFViewerWrapper({
  children,
  width = "100%",
  height = "100%",
  showToolbar = false,
  className,
}: PDFViewerWrapperProps) {
  return (
    <PDFViewer
      width={width}
      height={height}
      showToolbar={showToolbar}
      className={className}
    >
      {children}
    </PDFViewer>
  )
}

interface PDFDownloadLinkWrapperProps {
  document: ReactElement
  fileName: string
  children: (props: { loading: boolean }) => ReactElement
}

export function PDFDownloadLinkWrapper({
  document,
  fileName,
  children,
}: PDFDownloadLinkWrapperProps) {
  return (
    <PDFDownloadLink document={document} fileName={fileName}>
      {children}
    </PDFDownloadLink>
  )
}
