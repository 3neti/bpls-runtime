"use client"

import type { ColumnDef } from "@tanstack/react-table"
import { ArrowUpDown, Settings, Trash2, Archive } from "lucide-react"

import { Button } from "@repo/ui/components/button"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import { Badge } from "@repo/ui/components/badge"
import { getIconComponent } from "@/lib/utils/icon-mapper"
import type { Doc, Id } from "@repo/backend/convex/_generated/dataModel"
import { formatDate } from "@/lib/utils/formatting"

type ClearanceType = Doc<"clearance_types">

interface ClearanceActionsProps {
  clearanceType: ClearanceType
  onEdit: (clearanceType: ClearanceType) => void
  onDelete: (id: Id<"clearance_types">, name: string) => void
  onArchive: (id: Id<"clearance_types">, name: string) => void
  hasUpdatePermission: boolean
  hasDeletePermission: boolean
}

function ClearanceActionsCell({ clearanceType, onEdit, onDelete, onArchive, hasUpdatePermission, hasDeletePermission }: ClearanceActionsProps) {
  return (
    <div onClick={(e) => e.stopPropagation()} className="flex items-center gap-1">
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <span tabIndex={hasUpdatePermission ? -1 : 0}>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-muted-foreground hover:text-primary hover:bg-primary/10"
                disabled={!hasUpdatePermission}
                onClick={(e) => {
                  e.stopPropagation()
                  onEdit(clearanceType)
                }}
              >
                <Settings className="h-4 w-4" />
              </Button>
            </span>
          </TooltipTrigger>
          <TooltipContent>
            <p>{hasUpdatePermission ? "Edit Clearance Type" : "You don't have permission to edit"}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      {clearanceType.isActive && (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <span tabIndex={hasUpdatePermission ? -1 : 0}>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-amber-600 hover:text-amber-700 hover:bg-amber-100"
                  disabled={!hasUpdatePermission}
                  onClick={(e) => {
                    e.stopPropagation()
                    onArchive(clearanceType._id, clearanceType.name)
                  }}
                >
                  <Archive className="h-4 w-4" />
                </Button>
              </span>
            </TooltipTrigger>
            <TooltipContent>
              <p>{hasUpdatePermission ? "Archive Clearance Type" : "You don't have permission to archive"}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}

      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <span tabIndex={hasDeletePermission ? -1 : 0}>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                disabled={!hasDeletePermission}
                onClick={(e) => {
                  e.stopPropagation()
                  onDelete(clearanceType._id, clearanceType.name)
                }}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </span>
          </TooltipTrigger>
          <TooltipContent>
            <p>{hasDeletePermission ? "Delete Clearance Type" : "You don't have permission to delete"}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  )
}

export const createColumns = (
  onEdit: (clearanceType: ClearanceType) => void,
  onDelete: (id: Id<"clearance_types">, name: string) => void,
  onArchive: (id: Id<"clearance_types">, name: string) => void,
  hasUpdatePermission: boolean = true,
  hasDeletePermission: boolean = true
): ColumnDef<ClearanceType>[] => [
  {
    id: "icon",
    header: "",
    cell: ({ row }) => {
      const clearanceType = row.original
      const Icon = getIconComponent(clearanceType.icon)
      return (
        <div className="p-2 rounded-lg bg-primary/10 w-fit">
          <Icon className="h-5 w-5 text-primary" />
        </div>
      )
    },
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "shortName",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Short Name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      return (
        <div className="font-medium">{row.getValue("shortName")}</div>
      )
    },
  },
  {
    accessorKey: "name",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Full Name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      return (
        <div className="text-sm text-muted-foreground">{row.getValue("name")}</div>
      )
    },
  },
  {
    accessorKey: "certificateName",
    header: "Certificate",
    cell: ({ row }) => {
      const certificateName = row.getValue("certificateName") as string
      return (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="text-sm max-w-[200px] truncate cursor-help">
                {certificateName}
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>{certificateName}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )
    },
  },
  {
    accessorKey: "isActive",
    header: "Status",
    cell: ({ row }) => {
      const isActive = row.getValue("isActive") as boolean
      return (
        <Badge variant={isActive ? "default" : "secondary"}>
          {isActive ? "Active" : "Archived"}
        </Badge>
      )
    },
  },
  {
    accessorKey: "_creationTime",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Created
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const timestamp = row.getValue("_creationTime") as number
      return <span className="text-sm">{formatDate(timestamp, "short") || "-"}</span>
    },
  },
  {
    id: "actions",
    header: "Actions",
    cell: ({ row }) => {
      const clearanceType = row.original
      return (
        <ClearanceActionsCell
          clearanceType={clearanceType}
          onEdit={onEdit}
          onDelete={(id, name) => onDelete(id, name)}
          onArchive={onArchive}
          hasUpdatePermission={hasUpdatePermission}
          hasDeletePermission={hasDeletePermission}
        />
      )
    },
    enableSorting: false,
    enableHiding: false,
  },
]
