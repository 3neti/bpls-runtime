"use client"

import { useState } from "react"
import { ColumnDef } from "@tanstack/react-table"
import { ArrowUpDown, Ban, CheckCircle2, FileText, Lock, Trash2 } from "lucide-react"
import { useMutation, useQuery } from "convex/react"

import { Button } from "@repo/ui/components/button"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import { Checkbox } from "@repo/ui/components/checkbox"
import { Badge } from "@repo/ui/components/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@repo/ui/components/avatar"
import { BlacklistDialog } from "@/components/blacklist-dialog"
import { useToast } from "@/hooks/use-toast"
import { usePermissions } from "@/hooks/use-permissions"

import { api } from "@repo/backend/convex/_generated/api"
import type { Doc, Id } from "@repo/backend/convex/_generated/dataModel"
import { formatCurrency, formatDate } from "@/lib/utils/formatting"

type Business = Doc<"businesses"> & {
  ownerName?: string
  owner?: {
    _id: string
    firstName: string
    middleName?: string
    lastName: string
    email: string
    mobile: string
    avatar?: string
    isBlacklisted?: boolean
  } | null
}

const formatRevenueDisplay = (amount: string): string => {
  // If already formatted or a range, return as-is
  if (amount.includes("-") || amount.includes("₱")) {
    return amount
  }
  // Try to parse as number and format with currency symbol
  const num = parseFloat(amount)
  if (!isNaN(num)) {
    return formatCurrency(num, { withSymbol: true })
  }
  return amount
}

// Component for displaying location hierarchy
function LocationCell({
  provinceId,
  cityId,
  barangayId
}: {
  provinceId?: Id<"provinces">
  cityId?: Id<"cities">
  barangayId?: Id<"barangays">
}) {
  const locations = useQuery(
    api.locations.getLocationHierarchy,
    provinceId || cityId || barangayId
      ? { provinceId, cityId, barangayId }
      : "skip"
  )

  if (!locations) {
    return <span className="text-sm text-muted-foreground">-</span>
  }

  const parts = [
    locations.barangay?.name,
    locations.city?.name,
    locations.province?.name,
  ].filter(Boolean)

  if (parts.length === 0) {
    return <span className="text-sm text-muted-foreground">-</span>
  }

  return (
    <div className="text-sm max-w-[200px]">
      <div className="truncate">{parts.join(", ")}</div>
    </div>
  )
}

// Separate component for the actions cell to properly use hooks
function BusinessActionsCell({ business, onDelete }: { business: Business; onDelete?: (businessId: string) => void }) {
  const [blacklistDialogOpen, setBlacklistDialogOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()
  const { canUpdate, canDelete, isLoading: permissionsLoading } = usePermissions()
  const canModifyBusiness = canUpdate("businesses")
  const canDeleteBusiness = canDelete("businesses")

  const blacklistMutation = useMutation(api.businesses.blacklist)
  const unblacklistMutation = useMutation(api.businesses.unblacklist)

  const handleBlacklistConfirm = async (reason?: string) => {
    if (!canModifyBusiness) {
      toast({
        title: "Error",
        description: "You don't have permission to modify businesses",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      if (business.isBlacklisted) {
        // Remove blacklist
        await unblacklistMutation({
          businessId: business._id,
        })
        toast({
          title: "Success",
          description: "Business has been removed from blacklist",
        })
      } else {
        // Add to blacklist
        if (!reason) {
          toast({
            title: "Error",
            description: "Reason is required for blacklisting",
            variant: "destructive",
          })
          setIsLoading(false)
          return
        }
        await blacklistMutation({
          businessId: business._id,
          reason,
          // blacklistedBy auto-filled by backend from authenticated user
        })
        toast({
          title: "Success",
          description: "Business has been blacklisted",
        })
      }
      setBlacklistDialogOpen(false)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update blacklist status",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div onClick={(e) => e.stopPropagation()} className="flex items-center gap-1">
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <span tabIndex={0} className="inline-block">
              <Button
                variant="ghost"
                size="icon"
                className={`h-8 w-8 ${business.isBlacklisted ? "" : "text-destructive hover:text-destructive"}`}
                onClick={(e) => {
                  e.stopPropagation()
                  setBlacklistDialogOpen(true)
                }}
                disabled={!canModifyBusiness || isLoading || permissionsLoading}
              >
                {business.isBlacklisted ? (
                  <CheckCircle2 className="h-4 w-4" />
                ) : (
                  <Ban className="h-4 w-4" />
                )}
              </Button>
            </span>
          </TooltipTrigger>
          <TooltipContent>
            {!canModifyBusiness && !permissionsLoading ? (
              <div className="flex items-center gap-2">
                <Lock className="h-4 w-4" />
                <p>You don't have permission to modify businesses</p>
              </div>
            ) : isLoading ? (
              <p>Processing...</p>
            ) : permissionsLoading ? (
              <p>Loading permissions...</p>
            ) : (
              <p>{business.isBlacklisted ? "Remove Blacklist" : "Blacklist Business"}</p>
            )}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <BlacklistDialog
        open={blacklistDialogOpen}
        onOpenChange={setBlacklistDialogOpen}
        entityType="business"
        entityName={business.name}
        isCurrentlyBlacklisted={business.isBlacklisted ?? false}
        onConfirm={handleBlacklistConfirm}
        onCancel={() => setBlacklistDialogOpen(false)}
      />

      {/* Delete button */}
      {onDelete && canDeleteBusiness && (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <span tabIndex={0} className="inline-block">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                  onClick={(e) => {
                    e.stopPropagation()
                    onDelete(business._id)
                  }}
                  disabled={permissionsLoading}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </span>
            </TooltipTrigger>
            <TooltipContent>
              <p>Delete business</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}
    </div>
  )
}

interface BusinessColumnsProps {
  onDelete?: (businessId: string) => void
}

export const createBusinessColumns = (props?: BusinessColumnsProps): ColumnDef<Business>[] => [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && "indeterminate")
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "name",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Business Name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const business = row.original
      return (
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
            <span className="text-xs font-semibold text-primary">
              {business.name.charAt(0).toUpperCase()}
            </span>
          </div>
          <div>
            <div className="font-medium">{business.name}</div>
            <div className="text-xs text-muted-foreground">{business.email}</div>
          </div>
        </div>
      )
    },
  },
  {
    accessorKey: "ownerName",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Owner
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const business = row.original
      const owner = business.owner

      if (!owner) {
        return <div className="text-sm text-muted-foreground">No owner</div>
      }

      return (
        <div className="flex items-center gap-3">
          <Avatar className="h-8 w-8">
            <AvatarImage
              src={owner.avatar || "/placeholder.svg"}
              alt={`${owner.firstName} ${owner.lastName}`}
            />
            <AvatarFallback>
              {owner.firstName.charAt(0)}
              {owner.lastName.charAt(0)}
            </AvatarFallback>
          </Avatar>
          <div>
            <div className="font-medium text-sm">
              {owner.firstName} {owner.lastName}
            </div>
            <div className="text-xs text-muted-foreground">{owner.mobile}</div>
          </div>
        </div>
      )
    },
  },
  {
    accessorKey: "businessScale",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Scale
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const scale = row.getValue("businessScale") as string
      const variantMap: Record<string, "default" | "outline" | "secondary"> = {
        micro: "outline",
        small: "default",
        medium: "secondary",
        large: "default",
      }
      return (
        <Badge variant={variantMap[scale.toLowerCase()] || "outline"} className="capitalize">
          {scale}
        </Badge>
      )
    },
  },
  {
    accessorKey: "ownershipType",
    header: "Ownership Type",
    cell: ({ row }) => {
      const ownershipType = row.getValue("ownershipType") as string
      return (
        <Badge variant="outline" className="capitalize whitespace-nowrap">
          {ownershipType.replace(/-/g, " ")}
        </Badge>
      )
    },
  },
  {
    accessorKey: "groupName",
    header: "Group/Company Name",
    cell: ({ row }) => {
      const groupName = row.getValue("groupName") as string | undefined
      return <span className="text-sm">{groupName || "-"}</span>
    },
  },
  {
    accessorKey: "annualRevenue",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Annual Revenue
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const revenue = row.getValue("annualRevenue") as string
      return <span className="text-sm font-mono">{formatRevenueDisplay(revenue)}</span>
    },
  },
  {
    accessorKey: "numberOfEmployees",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Employees
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const total = row.getValue("numberOfEmployees") as number
      const business = row.original
      return (
        <div className="text-sm">
          <div className="font-medium">{total}</div>
          <div className="text-xs text-muted-foreground">
            M: {business.maleEmployeeCount} / F: {business.femaleEmployeeCount}
          </div>
        </div>
      )
    },
  },
  {
    accessorKey: "contactNumber",
    header: "Contact",
    cell: ({ row }) => {
      return <span className="text-sm">{row.getValue("contactNumber")}</span>
    },
  },
  {
    id: "address",
    header: "Street Address",
    cell: ({ row }) => {
      const business = row.original
      return (
        <div className="text-sm max-w-[200px]">
          <div className="truncate">{business.address || "-"}</div>
          {business.buildingName && (
            <div className="text-xs text-muted-foreground truncate">{business.buildingName}</div>
          )}
        </div>
      )
    },
  },
  {
    id: "location",
    header: "Location",
    cell: ({ row }) => {
      const business = row.original
      return (
        <LocationCell
          provinceId={business.provinceId}
          cityId={business.cityId}
          barangayId={business.barangayId}
        />
      )
    },
  },
  {
    accessorKey: "occupancy",
    header: "Occupancy",
    cell: ({ row }) => {
      const occupancy = row.getValue("occupancy") as string
      return (
        <Badge variant="outline" className="capitalize">
          {occupancy}
        </Badge>
      )
    },
  },
  {
    accessorKey: "businessArea",
    header: "Business Area",
    cell: ({ row }) => {
      const area = row.getValue("businessArea") as number | undefined
      if (!area) return <span className="text-sm text-muted-foreground">-</span>
      return <span className="text-sm">{area} m²</span>
    },
  },
  {
    accessorKey: "permitPaymentCadence",
    header: "Payment Cadence",
    cell: ({ row }) => {
      const cadence = row.getValue("permitPaymentCadence") as string
      return (
        <Badge variant="secondary" className="capitalize">
          {cadence}
        </Badge>
      )
    },
  },
  {
    accessorKey: "establishedDate",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Established
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const date = row.getValue("establishedDate") as string
      return <span className="text-sm">{formatDate(date, "short")}</span>
    },
  },
  {
    accessorKey: "dateStarted",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Date Started
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const date = row.getValue("dateStarted") as string
      return <span className="text-sm">{formatDate(date, "short")}</span>
    },
  },
  {
    accessorKey: "registrationDate",
    header: "Registration Date",
    cell: ({ row }) => {
      const date = row.getValue("registrationDate") as string | undefined
      if (!date) return <span className="text-sm text-muted-foreground">-</span>
      return <span className="text-sm">{formatDate(date, "short")}</span>
    },
  },
  {
    accessorKey: "registrationNumber",
    header: "Registration No.",
    cell: ({ row }) => {
      const regNo = row.getValue("registrationNumber") as string | undefined
      return <span className="font-mono text-sm">{regNo || "-"}</span>
    },
  },
  {
    id: "documents",
    header: "Documents",
    cell: ({ row }) => {
      const business = row.original
      const docCount = business.documents?.length || 0

      if (docCount === 0) {
        return <span className="text-sm text-muted-foreground">-</span>
      }

      const pendingCount = business.documents?.filter(d => d.status === "pending").length || 0
      const approvedCount = business.documents?.filter(d => d.status === "approved").length || 0
      const rejectedCount = business.documents?.filter(d => d.status === "rejected").length || 0

      return (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="flex items-center gap-2 cursor-help">
                <FileText className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">{docCount}</span>
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <div className="text-xs space-y-1">
                <div>Total: {docCount}</div>
                {approvedCount > 0 && <div className="text-green-600">Approved: {approvedCount}</div>}
                {pendingCount > 0 && <div className="text-yellow-600">Pending: {pendingCount}</div>}
                {rejectedCount > 0 && <div className="text-red-600">Rejected: {rejectedCount}</div>}
              </div>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )
    },
  },
  {
    id: "status",
    header: "Status",
    cell: ({ row }) => {
      const business = row.original

      if (business.isBlacklisted) {
        return (
          <Badge variant="destructive" className="gap-1">
            <Ban className="h-3 w-3" />
            Blacklisted
          </Badge>
        )
      }

      return (
        <Badge className="bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300">
          Active
        </Badge>
      )
    },
  },
  {
    id: "blacklistReason",
    header: "Blacklist Reason",
    cell: ({ row }) => {
      const business = row.original
      if (!business.isBlacklisted || !business.blacklistReason) {
        return <span className="text-sm text-muted-foreground">-</span>
      }
      return (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="text-sm max-w-[150px] truncate cursor-help">
                {business.blacklistReason}
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p className="max-w-xs">{business.blacklistReason}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )
    },
  },
  {
    id: "blacklistedAt",
    header: "Blacklisted Date",
    cell: ({ row }) => {
      const business = row.original
      if (!business.blacklistedAt) {
        return <span className="text-sm text-muted-foreground">-</span>
      }
      return <span className="text-sm">{formatDate(business.blacklistedAt, "short")}</span>
    },
  },
  {
    id: "blacklistedBy",
    header: "Blacklisted By",
    cell: ({ row }) => {
      const business = row.original
      return <span className="text-sm">{business.blacklistedBy || "-"}</span>
    },
  },
  {
    id: "actions",
    header: "Actions",
    cell: ({ row }) => {
      const business = row.original
      return <BusinessActionsCell business={business} onDelete={props?.onDelete} />
    },
    enableSorting: false,
    enableHiding: false,
  },
]

// Backward compatibility - default columns without delete handler
export const columns = createBusinessColumns()
