"use client";

import { useEffect, useCallback, useRef, useState } from "react";
import { useEditor, EditorContent, type Editor } from "@tiptap/react";
import { Extension } from "@tiptap/core";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import { TextStyle } from "@tiptap/extension-text-style";
import { FontFamily } from "@tiptap/extension-font-family";
import { Color } from "@tiptap/extension-color";
import TextAlign from "@tiptap/extension-text-align";
import Placeholder from "@tiptap/extension-placeholder";
import {
  Bold,
  Italic,
  Underline as UnderlineIcon,
  Strikethrough,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Type,
  ALargeSmall,
  Palette,
  RemoveFormatting,
} from "lucide-react";
import { Button } from "@repo/ui/components/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@repo/ui/components/popover";
import type { TipTapDoc } from "@/lib/utils/permit-tiptap-converter";

const FontSize = Extension.create({
  name: "fontSize",
  addGlobalAttributes() {
    return [
      {
        types: ["textStyle"],
        attributes: {
          fontSize: {
            default: null,
            parseHTML: (el: HTMLElement) =>
              el.style.fontSize?.replace(/['"]+/g, ""),
            renderHTML: (attrs: Record<string, unknown>) => {
              if (!attrs.fontSize) return {};
              return { style: `font-size: ${attrs.fontSize}` };
            },
          },
        },
      },
    ];
  },
});

const FONT_SIZE_OPTIONS = ["8", "9", "10", "11", "12", "14", "16", "18", "20", "24"];

const COLOR_PRESETS = [
  "#000000", "#374151", "#6B7280", "#9CA3AF",
  "#DC2626", "#EA580C", "#CA8A04", "#16A34A",
  "#2563EB", "#7C3AED", "#DB2777", "#0891B2",
  "#1E3A5F", "#7F1D1D", "#14532D", "#312E81",
];

interface PermitTipTapEditorProps {
  content: TipTapDoc | null;
  onChange: (json: string) => void;
  placeholder?: string;
  disabled?: boolean;
  editorRef?: React.MutableRefObject<Editor | null>;
}

export default function PermitTipTapEditor({
  content,
  onChange,
  placeholder = "Enter template content...",
  disabled = false,
  editorRef,
}: PermitTipTapEditorProps) {
  const editor = useEditor({
    immediatelyRender: false,
    extensions: [
      StarterKit.configure({
        heading: false,
        blockquote: false,
        codeBlock: false,
        code: false,
        horizontalRule: false,
        bulletList: false,
        orderedList: false,
        listItem: false,
      }),
      Underline,
      TextStyle,
      FontSize,
      FontFamily.configure({ types: ["textStyle"] }),
      Color.configure({ types: ["textStyle"] }),
      TextAlign.configure({ types: ["paragraph"], alignments: ["left", "center", "right", "justify"] }),
      Placeholder.configure({ placeholder }),
    ],
    content: content || undefined,
    editable: !disabled,
    onUpdate: ({ editor: e }) => {
      onChange(JSON.stringify(e.getJSON()));
    },
  });

  // Sync editorRef
  useEffect(() => {
    if (editorRef && editor) {
      editorRef.current = editor;
    }
  }, [editor, editorRef]);

  // Update editable state when disabled prop changes
  useEffect(() => {
    if (editor) {
      editor.setEditable(!disabled);
    }
  }, [editor, disabled]);

  if (!editor) {
    return (
      <div className="h-full w-full flex items-center justify-center text-muted-foreground text-sm">
        Loading editor...
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      {!disabled && <EditorToolbar editor={editor} />}

      {/* Editor content */}
      <div className="flex-1 overflow-auto">
        <EditorContent
          editor={editor}
          className="permit-tiptap-editor h-full"
        />
      </div>

      {/* Scoped styles */}
      <style jsx global>{`
        .permit-tiptap-editor .ProseMirror {
          min-height: 100%;
          padding: 8px 12px;
          outline: none;
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas,
            monospace;
          font-size: 0.875rem;
          line-height: 1.5;
        }
        .permit-tiptap-editor .ProseMirror p {
          margin: 0;
        }
        .permit-tiptap-editor .ProseMirror p.is-editor-empty:first-child::before {
          content: attr(data-placeholder);
          float: left;
          color: #9ca3af;
          pointer-events: none;
          height: 0;
        }
        .permit-tiptap-editor .ProseMirror:focus {
          outline: none;
        }
      `}</style>
    </div>
  );
}

function EditorToolbar({ editor }: { editor: Editor }) {
  const [colorOpen, setColorOpen] = useState(false);
  const toolbarRef = useRef<HTMLDivElement>(null);

  const setFontFamily = useCallback(
    (font: string) => {
      editor.chain().focus().setFontFamily(font).run();
    },
    [editor]
  );

  const setFontSize = useCallback(
    (size: string) => {
      editor.chain().focus().setMark("textStyle", { fontSize: `${size}pt` }).run();
    },
    [editor]
  );

  // Get current font family from editor state
  const currentFont =
    (editor.getAttributes("textStyle").fontFamily as string) || "";

  // Get current font size from editor state
  const rawFontSize = (editor.getAttributes("textStyle").fontSize as string) || "";
  const currentFontSize = rawFontSize ? rawFontSize.replace(/pt$/i, "") : "";

  // Get current color from editor state
  const currentColor = (editor.getAttributes("textStyle").color as string) || "#000000";

  return (
    <div
      ref={toolbarRef}
      className="flex items-center gap-1 px-2 py-1.5 border-b bg-muted/30 flex-shrink-0 overflow-x-auto scrollbar-thin"
    >
      {/* Bold */}
      <Button
        type="button"
        variant={editor.isActive("bold") ? "default" : "ghost"}
        size="sm"
        className="h-7 w-7 p-0 flex-shrink-0"
        onClick={() => editor.chain().focus().toggleBold().run()}
        title="Bold"
      >
        <Bold className="h-3.5 w-3.5" />
      </Button>

      {/* Italic */}
      <Button
        type="button"
        variant={editor.isActive("italic") ? "default" : "ghost"}
        size="sm"
        className="h-7 w-7 p-0 flex-shrink-0"
        onClick={() => editor.chain().focus().toggleItalic().run()}
        title="Italic"
      >
        <Italic className="h-3.5 w-3.5" />
      </Button>

      {/* Underline */}
      <Button
        type="button"
        variant={editor.isActive("underline") ? "default" : "ghost"}
        size="sm"
        className="h-7 w-7 p-0 flex-shrink-0"
        onClick={() => editor.chain().focus().toggleUnderline().run()}
        title="Underline"
      >
        <UnderlineIcon className="h-3.5 w-3.5" />
      </Button>

      {/* Strikethrough */}
      <Button
        type="button"
        variant={editor.isActive("strike") ? "default" : "ghost"}
        size="sm"
        className="h-7 w-7 p-0 flex-shrink-0"
        onClick={() => editor.chain().focus().toggleStrike().run()}
        title="Strikethrough"
      >
        <Strikethrough className="h-3.5 w-3.5" />
      </Button>

      <div className="w-px h-5 bg-border mx-1 flex-shrink-0" />

      {/* Font Family */}
      <div className="flex items-center gap-1 flex-shrink-0">
        <Type className="h-3.5 w-3.5 text-muted-foreground" />
        <Select value={currentFont || "Helvetica"} onValueChange={(val) => {
          setFontFamily(val);
        }}>
          <SelectTrigger className="h-7 w-[120px] text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Helvetica">Helvetica</SelectItem>
            <SelectItem value="Times-Roman">Times Roman</SelectItem>
            <SelectItem value="Courier">Courier</SelectItem>
            <SelectItem value="Century Gothic">Century Gothic</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Font Size */}
      <div className="flex items-center gap-1 flex-shrink-0">
        <ALargeSmall className="h-3.5 w-3.5 text-muted-foreground" />
        <Select value={currentFontSize || "12"} onValueChange={(val) => {
          setFontSize(val);
        }}>
          <SelectTrigger className="h-7 w-[80px] text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {FONT_SIZE_OPTIONS.map((size) => (
              <SelectItem key={size} value={size}>{size}pt</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Font Color */}
      <Popover open={colorOpen} onOpenChange={setColorOpen}>
        <PopoverTrigger asChild>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0 flex-shrink-0"
            title="Font Color"
          >
            <div className="flex flex-col items-center gap-0.5">
              <Palette className="h-3 w-3" />
              <div
                className="h-0.5 w-3.5 rounded-full"
                style={{ backgroundColor: currentColor }}
              />
            </div>
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-2" align="start">
          <div className="grid grid-cols-4 gap-1">
            {COLOR_PRESETS.map((color) => (
              <button
                key={color}
                type="button"
                className="h-6 w-6 rounded border border-border hover:scale-110 transition-transform"
                style={{ backgroundColor: color }}
                onClick={() => {
                  editor.chain().focus().setColor(color).run();
                  setColorOpen(false);
                }}
                title={color}
              />
            ))}
          </div>
        </PopoverContent>
      </Popover>

      <div className="w-px h-5 bg-border mx-1 flex-shrink-0" />

      {/* Text Align */}
      <Button
        type="button"
        variant={editor.isActive({ textAlign: "left" }) ? "default" : "ghost"}
        size="sm"
        className="h-7 w-7 p-0 flex-shrink-0"
        onClick={() => editor.chain().focus().setTextAlign("left").run()}
        title="Align Left"
      >
        <AlignLeft className="h-3.5 w-3.5" />
      </Button>
      <Button
        type="button"
        variant={editor.isActive({ textAlign: "center" }) ? "default" : "ghost"}
        size="sm"
        className="h-7 w-7 p-0 flex-shrink-0"
        onClick={() => editor.chain().focus().setTextAlign("center").run()}
        title="Align Center"
      >
        <AlignCenter className="h-3.5 w-3.5" />
      </Button>
      <Button
        type="button"
        variant={editor.isActive({ textAlign: "right" }) ? "default" : "ghost"}
        size="sm"
        className="h-7 w-7 p-0 flex-shrink-0"
        onClick={() => editor.chain().focus().setTextAlign("right").run()}
        title="Align Right"
      >
        <AlignRight className="h-3.5 w-3.5" />
      </Button>
      <Button
        type="button"
        variant={editor.isActive({ textAlign: "justify" }) ? "default" : "ghost"}
        size="sm"
        className="h-7 w-7 p-0 flex-shrink-0"
        onClick={() => editor.chain().focus().setTextAlign("justify").run()}
        title="Justify"
      >
        <AlignJustify className="h-3.5 w-3.5" />
      </Button>

      <div className="w-px h-5 bg-border mx-1 flex-shrink-0" />

      {/* Clear Formatting */}
      <Button
        type="button"
        variant="ghost"
        size="sm"
        className="h-7 w-7 p-0 flex-shrink-0"
        onClick={() => editor.chain().focus().unsetAllMarks().run()}
        title="Clear Formatting"
      >
        <RemoveFormatting className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}
