"use client"

import { ColumnDef } from "@tanstack/react-table"
import { ArrowUpDown, Pencil, Archive, ArchiveRestore } from "lucide-react"

import { Button } from "@repo/ui/components/button"
import { Checkbox } from "@repo/ui/components/checkbox"
import { Badge } from "@repo/ui/components/badge"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

export type FeeName = {
  _id: Id<"fee_names">
  name: string
  description?: string
  isActive: boolean
}

// We need to use a wrapper component for actions since we can't pass callbacks directly in column definitions
interface ActionsContextValue {
  onEdit?: (fee: FeeName) => void
  onToggleActive?: (id: Id<"fee_names">, currentStatus: boolean) => void
}

// Create a context-like pattern using cell meta
export const createColumns = (
  onEdit?: (fee: FeeName) => void,
  onToggleActive?: (id: Id<"fee_names">, currentStatus: boolean) => void,
  hasUpdatePermission: boolean = true,
  hasDeletePermission: boolean = true
): ColumnDef<FeeName>[] => [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && "indeterminate")
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "name",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      return <span className="font-medium">{row.getValue("name")}</span>
    },
  },
  {
    accessorKey: "description",
    header: "Description",
    cell: ({ row }) => {
      const description = row.getValue("description") as string | undefined
      return (
        <span className="text-muted-foreground max-w-md truncate block">
          {description || "-"}
        </span>
      )
    },
  },
  {
    accessorKey: "isActive",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Status
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const isActive = row.getValue("isActive") as boolean
      return (
        <Badge
          variant={isActive ? "default" : "secondary"}
          className={
            isActive
              ? "bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300"
              : "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300"
          }
        >
          {isActive ? "Active" : "Archived"}
        </Badge>
      )
    },
  },
  {
    id: "actions",
    header: "Actions",
    cell: ({ row }) => {
      const feeName = row.original
      return (
        <div className="flex items-center gap-1">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={hasUpdatePermission ? -1 : 0}>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    disabled={!hasUpdatePermission}
                    onClick={(e) => {
                      e.stopPropagation()
                      onEdit?.(feeName)
                    }}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                </span>
              </TooltipTrigger>
              <TooltipContent>
                <p>{hasUpdatePermission ? "Edit" : "You don't have permission to edit"}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={hasDeletePermission ? -1 : 0}>
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`h-8 w-8 ${
                      feeName.isActive
                        ? "text-orange-600 hover:text-orange-700"
                        : "text-green-600 hover:text-green-700"
                    }`}
                    disabled={!hasDeletePermission}
                    onClick={(e) => {
                      e.stopPropagation()
                      onToggleActive?.(feeName._id, feeName.isActive)
                    }}
                  >
                    {feeName.isActive ? (
                      <Archive className="h-4 w-4" />
                    ) : (
                      <ArchiveRestore className="h-4 w-4" />
                    )}
                  </Button>
                </span>
              </TooltipTrigger>
              <TooltipContent>
                <p>{hasDeletePermission ? (feeName.isActive ? "Archive" : "Restore") : "You don't have permission"}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      )
    },
    enableSorting: false,
    enableHiding: false,
  },
]

// Default columns export (without callbacks - used for type checking)
export const columns: ColumnDef<FeeName>[] = createColumns()
