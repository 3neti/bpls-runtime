"use client";

import React, { useState, useEffect, lazy, Suspense, useMemo } from "react";
import { useQuery } from "convex/react";
import { FileText, Loader2, ClipboardList } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import { usePlatformSettings } from "@/hooks/use-platform-settings";
import { mapToFormData, type ApplicationFormPdfProps } from "./application-form-pdf";
import {
  mapToAssessmentData,
  type AssessmentSheetPdfProps,
  type PaymentScheduleSection,
} from "./assessment-sheet-pdf";

// Lazy load the PDF viewer component
const PdfViewerContent = lazy(() => import("./pdf-viewer-content"));

type FormType = "application" | "assessment";

interface FormCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  onClick: () => void;
}

function FormCard({ title, description, icon, onClick }: FormCardProps) {
  return (
    <Card
      className="cursor-pointer hover:bg-accent/50 transition-colors"
      onClick={onClick}
    >
      <CardContent className="flex items-center gap-4 p-4">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
          {icon}
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="text-sm font-medium leading-none">{title}</h4>
          <p className="text-xs text-muted-foreground mt-1">{description}</p>
        </div>
      </CardContent>
    </Card>
  );
}

/**
 * Get section label based on section number and total sections
 */
function getSectionLabel(sectionNumber: number, total: number): string {
  if (total === 1) return "Full Payment";
  if (total === 2) return sectionNumber === 1 ? "1st Semester" : "2nd Semester";
  return `Q${sectionNumber}`;
}

// Extended props interface that includes assessment data
export interface BplsFormsCardProps extends ApplicationFormPdfProps {
  // Application ID for fetching payment schedules
  applicationId?: Id<"business_permit_applications">;
  // Aggregated fees for the assessment sheet (optional - if not provided, assessment sheet won't show fees)
  aggregatedFees?: Array<{
    feeName: string;
    totalAmount: number;
    breakdown: Array<{
      lobId: string;
      lobName: string;
      amount: number;
    }>;
  }>;
  // Assessment sheet footer fields
  preparedBy?: string;
  preparedDate?: string;
  approvedByName?: string;
  approvedByTitle?: string;
}

export function BplsFormsCard(props: BplsFormsCardProps) {
  const [isClient, setIsClient] = useState(false);
  const [selectedForm, setSelectedForm] = useState<FormType | null>(null);

  // Fetch platform settings for Mayor, Treasurer, and Municipality info
  const {
    mayorName,
    mayorTitle,
    treasurerName,
    treasurerTitle,
    provinceName: platformProvinceName,
    municipalityName,
    effectiveMunicipalSealUrl,
  } = usePlatformSettings();

  // Map form data and inject mayor name/title from settings
  const formData = useMemo(() => {
    const data = mapToFormData(props);
    return {
      ...data,
      mayorName: mayorName || data.mayorName,
      mayorTitle: mayorTitle || data.mayorTitle,
    };
  }, [props, mayorName, mayorTitle]);

  // Fetch payment schedules for this application
  const paymentSchedules = useQuery(
    api.paymentSchedules.getByApplication,
    props.applicationId ? { applicationId: props.applicationId } : "skip"
  );

  // Transform payment schedules to PaymentScheduleSection format
  const paymentScheduleData: PaymentScheduleSection[] = useMemo(() => {
    if (!paymentSchedules || paymentSchedules.length === 0) {
      return [];
    }

    const totalSections = paymentSchedules.length;

    return paymentSchedules.map((schedule: NonNullable<typeof paymentSchedules>[number]) => ({
      sectionNumber: schedule.sectionNumber,
      sectionLabel: getSectionLabel(schedule.sectionNumber, totalSections),
      dueDate: schedule.dueDate,
      totalAmount: schedule.totalAmount,
      paidAmount: schedule.paidAmount,
      balance: schedule.totalAmount - schedule.paidAmount,
      status: schedule.status,
    }));
  }, [paymentSchedules]);

  // Build assessment sheet props from the main props
  // Use treasurer name/title from settings as fallback for approval fields
  const assessmentSheetProps: AssessmentSheetPdfProps = useMemo(
    () => ({
      applicationNumber: props.applicationNumber,
      permitApplicationType: props.permitApplicationType,
      modeOfPayment: props.modeOfPayment,
      businessOwner: props.businessOwner,
      business: props.business,
      provinceName: props.provinceName,
      cityName: props.cityName,
      barangayName: props.barangayName,
      linesOfBusiness: props.linesOfBusiness,
      aggregatedFees: props.aggregatedFees,
      paymentSchedule: paymentScheduleData,
      preparedBy: props.preparedBy,
      preparedDate: props.preparedDate,
      approvedByName: props.approvedByName || treasurerName,
      approvedByTitle: props.approvedByTitle || treasurerTitle,
      // Platform settings for PDF header
      platformProvinceName,
      municipalityName,
      municipalSealUrl: effectiveMunicipalSealUrl,
    }),
    [props, paymentScheduleData, treasurerName, treasurerTitle, platformProvinceName, municipalityName, effectiveMunicipalSealUrl]
  );

  const assessmentData = useMemo(
    () => mapToAssessmentData(assessmentSheetProps),
    [assessmentSheetProps]
  );

  useEffect(() => {
    setIsClient(true);
  }, []);

  const handleOpenForm = (formType: FormType) => {
    setSelectedForm(formType);
  };

  const handleCloseModal = () => {
    setSelectedForm(null);
  };

  const getFormTitle = (formType: FormType) => {
    switch (formType) {
      case "application":
        return "Application Form";
      case "assessment":
        return "Assessment Sheet";
      default:
        return "";
    }
  };

  const getFileName = (formType: FormType) => {
    switch (formType) {
      case "application":
        return `application-form-${props.applicationNumber}.pdf`;
      case "assessment":
        return `assessment-sheet-${props.applicationNumber}.pdf`;
      default:
        return "document.pdf";
    }
  };

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <FileText className="h-5 w-5" />
            BPLS Forms
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <FormCard
            title="Application Form"
            description="Business permit application form"
            icon={<FileText className="h-5 w-5" />}
            onClick={() => handleOpenForm("application")}
          />
          <FormCard
            title="Assessment Sheet"
            description="Fee assessment and computation slip"
            icon={<ClipboardList className="h-5 w-5" />}
            onClick={() => handleOpenForm("assessment")}
          />
        </CardContent>
      </Card>

      {/* Full-width PDF Modal */}
      <Dialog open={selectedForm !== null} onOpenChange={handleCloseModal}>
        <DialogContent className="sm:max-w-[95vw] w-full h-[90vh] flex flex-col p-0">
          <DialogHeader className="px-6 py-4 border-b flex-shrink-0">
            <div className="flex items-center justify-between">
              <DialogTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                {selectedForm && getFormTitle(selectedForm)}
              </DialogTitle>
            </div>
          </DialogHeader>
          <div className="flex-1 overflow-hidden p-6">
            {!isClient ? (
              <div className="h-full flex items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin" />
              </div>
            ) : (
              <Suspense
                fallback={
                  <div className="h-full flex items-center justify-center">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                }
              >
                {selectedForm && (
                  <PdfViewerContent
                    formData={formData}
                    assessmentData={assessmentData}
                    applicationNumber={props.applicationNumber}
                    fileName={getFileName(selectedForm)}
                    fullHeight={true}
                    documentType={selectedForm}
                  />
                )}
              </Suspense>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
