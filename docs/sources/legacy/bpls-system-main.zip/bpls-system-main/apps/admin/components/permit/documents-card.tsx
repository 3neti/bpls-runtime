/**
 * DocumentsCard Component
 *
 * Displays required documents for a permit application with:
 * - Document name (formatted from key)
 * - File name
 * - Upload status badge
 */

import { FileText, CheckCircle } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"

export interface DocumentInfo {
  uploaded: boolean
  fileName: string
}

export interface DocumentsCardProps {
  documents: Record<string, DocumentInfo>
}

export function DocumentsCard({ documents }: DocumentsCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Required Documents
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {Object.entries(documents).map(([key, doc]) => (
            <div key={key} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-full bg-green-100">
                  <FileText className="h-4 w-4 text-green-600" />
                </div>
                <div>
                  <h6 className="font-medium capitalize">
                    {key.replace(/([A-Z])/g, " $1").trim()}
                  </h6>
                  <p className="text-sm text-muted-foreground">{doc.fileName}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="default" className="bg-green-100 text-green-800">
                  <CheckCircle className="mr-1 h-3 w-3" />
                  Uploaded
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
