"use client";

import type React from "react";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useConvexAuth, useConvex } from "convex/react";
import { useAuthActions } from "@convex-dev/auth/react";
import { Loader2, Eye, EyeOff } from "lucide-react";
import { cn } from "@/lib/utils";
import { api } from "@repo/backend/convex/_generated/api";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";

interface LoginFormProps extends React.ComponentProps<"form"> {
  platformName?: string;
  platformTitle?: string;
  tagline?: string;
}

export function LoginForm({
  className,
  platformName = "BPLS",
  platformTitle = "Business Permit and Licensing System",
  tagline,
  ...props
}: LoginFormProps) {
  const router = useRouter();
  const { isAuthenticated } = useConvexAuth();
  const { signIn, signOut } = useAuthActions();
  const convex = useConvex();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Redirect to dashboard if already authenticated (use effect to avoid setState during render)
  useEffect(() => {
    if (isAuthenticated) {
      router.push("/dashboard");
    }
  }, [isAuthenticated, router]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      const formData = new FormData();
      formData.append("email", email);
      formData.append("password", password);
      formData.append("flow", "signIn");

      await signIn("password", formData);

      // After successful sign in, check if user is active
      // We need a small delay to allow the auth state to propagate
      await new Promise((resolve) => setTimeout(resolve, 500));

      const user = await convex.query(api.users.getCurrentUser);

      if (user?.status === "Inactive") {
        // User is deactivated - sign them out and show error
        await signOut();
        setError("Your account has been deactivated. Please contact an administrator.");
        setIsSubmitting(false);
        return;
      }

      // If sign in is successful and user is active, the useConvexAuth hook will update
      // and the redirect logic above will handle navigation
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Authentication failed";
      const errorString = errorMessage.toLowerCase();

      // Simplified error handling - no pending credential checks needed
      if (
        errorString.includes("invalid email or password") ||
        errorString.includes("invalid password") ||
        errorString.includes("incorrect password") ||
        errorString.includes("wrong password") ||
        errorString.includes("invalidaccountid") ||
        errorString.includes("invalid account") ||
        errorString.includes("account not found") ||
        errorString.includes("user not found") ||
        errorString.includes("no account") ||
        errorString.includes("retrieveaccount")
      ) {
        setError("Invalid email or password. Please try again.");
      } else if (
        errorString.includes("already exists") ||
        errorString.includes("email in use") ||
        errorString.includes("duplicate")
      ) {
        setError("Please try signing in with your existing account.");
      } else if (
        errorString.includes("network") ||
        errorString.includes("connection") ||
        errorString.includes("timeout")
      ) {
        setError(
          "Connection error. Please check your internet connection and try again."
        );
      } else if (
        errorString.includes("rate limit") ||
        errorString.includes("too many")
      ) {
        setError("Too many attempts. Please wait a moment and try again.");
      } else if (
        errorString.includes("deactivated") ||
        errorString.includes("inactive") ||
        errorString.includes("disabled")
      ) {
        setError("Your account has been deactivated. Please contact an administrator.");
      } else {
        // Generic fallback - don't expose technical details
        console.error("Authentication error:", errorMessage);
        setError(
          "Unable to sign in. Please check your credentials and try again."
        );
      }
      setIsSubmitting(false);
    }
  };

  // Use tagline if available, otherwise show platform title
  const description =
    tagline || `Enter your credentials to access the ${platformTitle}`;

  return (
    <form
      className={cn("flex flex-col gap-6", className)}
      onSubmit={handleSubmit}
      {...props}
    >
      <div className="flex flex-col items-center gap-2 text-center">
        <h1 className="text-2xl font-bold">Login to {platformName}</h1>
        <p className="text-muted-foreground text-sm text-balance">
          {description}
        </p>
      </div>

      {error && (
        <div className="p-3 text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-md">
          {error}
        </div>
      )}

      <div className="grid gap-6">
        <div className="grid gap-3">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            placeholder="user@example.gov.ph"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            disabled={isSubmitting}
            autoComplete="email"
          />
        </div>
        <div className="grid gap-3">
          <div className="flex items-center">
            <Label htmlFor="password">Password</Label>
            <a
              href="#"
              className="ml-auto text-sm underline-offset-4 hover:underline"
              onClick={(e) => e.preventDefault()}
            >
              Forgot your password?
            </a>
          </div>
          <div className="relative">
            <Input
              id="password"
              type={showPassword ? "text" : "password"}
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              disabled={isSubmitting}
              autoComplete="current-password"
              className="pr-10"
            />
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
              onClick={() => setShowPassword(!showPassword)}
              disabled={isSubmitting}
            >
              {showPassword ? (
                <EyeOff className="h-4 w-4 text-muted-foreground" />
              ) : (
                <Eye className="h-4 w-4 text-muted-foreground" />
              )}
              <span className="sr-only">
                {showPassword ? "Hide password" : "Show password"}
              </span>
            </Button>
          </div>
        </div>
        <Button type="submit" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Signing in...
            </>
          ) : (
            "Login"
          )}
        </Button>

        <div className="text-center text-sm text-muted-foreground">
          Need help?{" "}
          <a href="#" className="underline underline-offset-4 hover:text-foreground">
            Contact IT Support
          </a>
        </div>
      </div>
    </form>
  );
}
