import type { ReactNode } from "react"
import { Bell } from "lucide-react"
import { Button } from "@repo/ui/components/button"
import { ThemeToggle } from "@/components/theme-toggle"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@repo/ui/components/avatar"
import type { DepartmentConfig } from "@/lib/types/department"

// No default values - must be passed as props from settings

interface ReviewLayoutProps {
  /** Child components to render in the main content area */
  children: ReactNode
  /** Department configuration for branding and user info */
  config: DepartmentConfig
  /** Municipal seal image URL - defaults to Ipil seal if not provided */
  municipalSealUrl?: string
  /** Municipality short name for alt text - defaults to "Ipil" if not provided */
  municipalityShortName?: string
}

/**
 * ReviewLayout Component
 *
 * Reusable layout wrapper for all department review pages.
 * Provides consistent header with department branding, search, theme toggle, and user info.
 *
 * @example
 * ```tsx
 * <ReviewLayout config={sanitaryConfig}>
 *   <ReviewPageContent />
 * </ReviewLayout>
 * ```
 */
export function ReviewLayout({
  children,
  config,
  municipalSealUrl,
  municipalityShortName,
}: ReviewLayoutProps) {
  const Icon = config.icon
  const initials = config.shortName
    .split(" ")
    .map((word) => word[0])
    .join("")
    .toUpperCase()
    .slice(0, 2)

  return (
    <div className="min-h-screen bg-background">
      {/* Header with Logo, Search, Theme Toggle, and User Info */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-16 items-center gap-2 px-4 lg:gap-4 lg:px-6">
          {/* Logo Section */}
          <div className="flex items-center gap-2 lg:gap-3">
            <img
              src={municipalSealUrl}
              alt={`Bayan ng ${municipalityShortName} Seal`}
              className="h-8 w-8 object-contain lg:h-10 lg:w-10"
            />
            <div className="hidden sm:block">
              <div className="flex items-center gap-2">
                <Icon className="h-5 w-5 text-primary" />
                <div>
                  <h1 className="text-sm font-semibold lg:text-base">{config.name}</h1>
                  <p className="text-xs text-muted-foreground">Permit Approval System</p>
                </div>
              </div>
            </div>
          </div>

          {/* Spacer */}
          <div className="flex-1" />

          {/* Right Section - Theme Toggle and User Info */}
          <div className="flex items-center gap-2">
            {/* Theme Toggle */}
            <ThemeToggle />

            {/* Notifications Button - Hidden on small screens */}
            <Button variant="outline" size="icon" className="hidden sm:flex">
              <Bell className="h-4 w-4" />
              <span className="sr-only">Notifications</span>
            </Button>

            {/* User Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 w-auto px-2">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={config.user.avatar || "/placeholder.svg"} alt={config.user.name} />
                      <AvatarFallback>{initials}</AvatarFallback>
                    </Avatar>
                    <div className="hidden lg:grid text-left text-sm leading-tight">
                      <span className="truncate font-semibold">{config.user.name}</span>
                      <span className="truncate text-xs text-muted-foreground">{config.user.email}</span>
                    </div>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{config.user.name}</p>
                    <p className="text-xs leading-none text-muted-foreground">{config.user.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>Account Settings</DropdownMenuItem>
                <DropdownMenuItem>Notifications</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>Log out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-7xl mx-auto py-4 px-4 lg:py-6 lg:px-6">
        {children}
      </main>
    </div>
  )
}
