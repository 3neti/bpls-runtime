"use client"

import * as React from "react"
import {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table"
import { Search, Download, ChevronDown } from "lucide-react"

import { Button } from "@repo/ui/components/button"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import {
  convertToCSV,
  downloadCSV,
  generateExportFilename,
  type CSVColumn,
} from "@/lib/utils/csv-export"
import { Input } from "@repo/ui/components/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"
import { useColumnVisibilityStore } from "@/lib/stores/column-visibility-store"
import {
  TableFilterPopover,
  createDefaultFilterState,
  applyFilters,
  type FilterConfig,
  type FilterState,
  type StatusOption,
} from "@/components/permits/table-filter-popover"
import { STATUS_LABELS } from "@/lib/types/permit-application"
import { PermissionGuard } from "@/components/permission-guard"

type TableType = "assessment" | "payment"

interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[]
  data: TData[]
  tableType: TableType
  searchKey?: string
  searchPlaceholder?: string
  searchValue?: string
  onSearchChange?: (value: string) => void
  onRowClick?: (row: TData) => void
  exportEnabled?: boolean
  exportFilename?: string
  exportColumns?: CSVColumn<TData>[]
  filterConfig?: FilterConfig
}

// Column name formatting helper
function formatColumnName(id: string): string {
  return id
    .replace(/([A-Z])/g, " $1")
    .replace(/^./, (str) => str.toUpperCase())
    .trim()
}

// Default status options for permit application tables
const DEFAULT_STATUS_OPTIONS: StatusOption[] = [
  { value: "Assessment", label: STATUS_LABELS["Assessment"] },
  { value: "Pending Payment", label: STATUS_LABELS["Pending Payment"] },
  { value: "Released", label: STATUS_LABELS["Released"] },
]

export function AssessmentDataTable<TData extends Record<string, unknown>, TValue>({
  columns,
  data,
  tableType,
  searchKey = "applicationNumber",
  searchPlaceholder = "Search by application number...",
  searchValue,
  onSearchChange,
  onRowClick,
  exportEnabled = false,
  exportFilename = "export",
  exportColumns,
  filterConfig,
}: DataTableProps<TData, TValue>) {
  const [sorting, setSorting] = React.useState<SortingState>([
    { id: "submittedAt", desc: true },
  ])
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
  const [rowSelection, setRowSelection] = React.useState({})
  const [filters, setFilters] = React.useState<FilterState>(createDefaultFilterState())

  // Get column visibility from Zustand store based on table type
  const store = useColumnVisibilityStore()

  const columnVisibility = tableType === "assessment"
    ? store.assessmentColumns
    : store.paymentColumns

  const setColumnVisibility = tableType === "assessment"
    ? store.setAssessmentColumns
    : store.setPaymentColumns

  // Apply custom filters to data
  const filteredData = React.useMemo(() => {
    return applyFilters(data, filters, {
      statusKey: "status" as keyof TData,
      dateKey: "submittedAt" as keyof TData,
      typeKey: "permitApplicationType" as keyof TData,
    })
  }, [data, filters])

  const table = useReactTable({
    data: filteredData,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onColumnVisibilityChange: setColumnVisibility,
    onRowSelectionChange: setRowSelection,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    initialState: {
      pagination: {
        pageSize: 10,
      },
    },
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      rowSelection,
    },
  })

  // Handle export functionality
  const handleExport = React.useCallback(() => {
    if (!exportColumns || exportColumns.length === 0) return

    const filteredRows = table.getFilteredRowModel().rows
    const exportData = filteredRows.map((row) => row.original)

    const csv = convertToCSV(exportData, exportColumns)
    const filename = generateExportFilename(exportFilename)
    downloadCSV(csv, filename)
  }, [table, exportColumns, exportFilename])

  // Default filter config if not provided
  const effectiveFilterConfig: FilterConfig = filterConfig ?? {
    statusOptions: DEFAULT_STATUS_OPTIONS,
    showDateRange: true,
    showTypeFilter: true,
  }

  return (
    <div className="w-full space-y-4">
      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={searchPlaceholder}
            value={
              searchValue !== undefined
                ? searchValue
                : ((table.getColumn(searchKey)?.getFilterValue() as string) ?? "")
            }
            onChange={(event) => {
              if (onSearchChange) {
                // Use external search handler (server-side search)
                onSearchChange(event.target.value)
              } else {
                // Fall back to client-side filtering
                table.getColumn(searchKey)?.setFilterValue(event.target.value)
              }
            }}
            className="pl-8"
          />
        </div>

        {/* Columns Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline">
              Columns <ChevronDown className="ml-2 h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-[200px]">
            {table
              .getAllColumns()
              .filter((column) => column.getCanHide())
              .map((column) => {
                const displayName = formatColumnName(column.id)
                return (
                  <DropdownMenuCheckboxItem
                    key={column.id}
                    className="capitalize"
                    checked={column.getIsVisible()}
                    onCheckedChange={(value) =>
                      column.toggleVisibility(!!value)
                    }
                  >
                    {displayName}
                  </DropdownMenuCheckboxItem>
                )
              })}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Filter Popover */}
        <TableFilterPopover
          config={effectiveFilterConfig}
          filters={filters}
          onFiltersChange={setFilters}
        />

        {/* Export Button */}
        {exportEnabled && exportColumns && exportColumns.length > 0 && (
          <PermissionGuard resource="reports" action="read" fallback={null}>
            <Button variant="outline" onClick={handleExport}>
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </PermissionGuard>
        )}
      </div>

      <div className="overflow-hidden rounded-md border">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id}>
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                    </TableHead>
                  )
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow
                  key={row.id}
                  data-state={row.getIsSelected() && "selected"}
                  onClick={() => {
                    if (onRowClick) {
                      onRowClick(row.original)
                    }
                  }}
                  className={onRowClick ? "cursor-pointer hover:bg-muted/50 transition-colors" : undefined}
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center"
                >
                  No applications found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <div className="flex items-center justify-end space-x-2">
        <div className="text-muted-foreground flex-1 text-sm">
          {table.getFilteredSelectedRowModel().rows.length} of{" "}
          {table.getFilteredRowModel().rows.length} row(s) selected.
        </div>
        <div className="flex items-center space-x-2">
          <p className="text-sm text-muted-foreground">
            Page {table.getState().pagination.pageIndex + 1} of{" "}
            {table.getPageCount()}
          </p>
          <div className="space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => table.previousPage()}
              disabled={!table.getCanPreviousPage()}
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => table.nextPage()}
              disabled={!table.getCanNextPage()}
            >
              Next
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
