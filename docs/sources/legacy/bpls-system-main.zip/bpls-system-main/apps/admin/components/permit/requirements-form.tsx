"use client"
import { useState } from "react"
import { Download, FileText, AlertCircle } from "lucide-react"
import { Button } from "@repo/ui/components/button"
import { Label } from "@repo/ui/components/label"
import { Alert, AlertDescription } from "@repo/ui/components/alert"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Dropzone } from "@repo/ui/components/dropzone"

interface RequirementsFormProps {
  onBack: () => void
  ownershipType?: string
}

interface DocumentUpload {
  file: File | null
  uploaded: boolean
}

export function RequirementsForm({ onBack, ownershipType }: RequirementsFormProps) {
  const [documents, setDocuments] = useState<{
    applicationForm: DocumentUpload
    barangayClearance: DocumentUpload
    dtiCertificate: DocumentUpload
    secCertificate: DocumentUpload
    articlesOfIncorporation: DocumentUpload
    bylaws: DocumentUpload
    articlesOfPartnership: DocumentUpload
    articlesOfCooperation: DocumentUpload
    cdaCertificate: DocumentUpload
    gis: DocumentUpload
  }>({
    applicationForm: { file: null, uploaded: false },
    barangayClearance: { file: null, uploaded: false },
    dtiCertificate: { file: null, uploaded: false },
    secCertificate: { file: null, uploaded: false },
    articlesOfIncorporation: { file: null, uploaded: false },
    bylaws: { file: null, uploaded: false },
    articlesOfPartnership: { file: null, uploaded: false },
    articlesOfCooperation: { file: null, uploaded: false },
    cdaCertificate: { file: null, uploaded: false },
    gis: { file: null, uploaded: false },
  })

  const handleFileSelect = (documentType: keyof typeof documents, file: File) => {
    setDocuments((prev) => ({
      ...prev,
      [documentType]: { file, uploaded: true },
    }))
  }

  const handleFileRemove = (documentType: keyof typeof documents) => {
    setDocuments((prev) => ({
      ...prev,
      [documentType]: { file: null, uploaded: false },
    }))
  }

  const handleDownloadForm = () => {
    const link = document.createElement("a")
    link.href = "/placeholder.pdf"
    link.download = "Business-Permit-Application-Form.pdf"
    link.click()
  }

  const renderConditionalDocuments = () => {
    console.log("[v0] Current ownership type:", ownershipType)

    const normalizedOwnershipType = ownershipType?.toLowerCase().replace(/\s+/g, "-")

    if (normalizedOwnershipType === "sole-proprietorship") {
      return (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Document 3: DTI Certificate of Business Name Registration
            </CardTitle>
            <CardDescription>Upload your Department of Trade and Industry certificate</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Upload DTI Certificate of Business Name Registration</Label>
              <Dropzone
                onFileSelect={(file) => handleFileSelect("dtiCertificate", file)}
                onFileRemove={() => handleFileRemove("dtiCertificate")}
                selectedFile={documents.dtiCertificate.file}
              />
            </div>
          </CardContent>
        </Card>
      )
    }

    if (normalizedOwnershipType === "partnership") {
      return (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 3: SEC Certificate of Registration (Partnership)
              </CardTitle>
              <CardDescription>Upload your SEC Certificate of Registration for Partnership</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload SEC Certificate of Registration (Partnership)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("secCertificate", file)}
                  onFileRemove={() => handleFileRemove("secCertificate")}
                  selectedFile={documents.secCertificate.file}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 4: Articles of Partnership
              </CardTitle>
              <CardDescription>Upload your Articles of Partnership</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Articles of Partnership</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("articlesOfPartnership", file)}
                  onFileRemove={() => handleFileRemove("articlesOfPartnership")}
                  selectedFile={documents.articlesOfPartnership.file}
                />
              </div>
            </CardContent>
          </Card>
        </>
      )
    }

    if (normalizedOwnershipType === "corporation") {
      return (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 3: SEC Certificate of Incorporation/Registration
              </CardTitle>
              <CardDescription>Upload your SEC Certificate of Incorporation/Registration</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload SEC Certificate of Incorporation/Registration</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("secCertificate", file)}
                  onFileRemove={() => handleFileRemove("secCertificate")}
                  selectedFile={documents.secCertificate.file}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 4: Articles of Incorporation
              </CardTitle>
              <CardDescription>Upload your Articles of Incorporation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Articles of Incorporation</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("articlesOfIncorporation", file)}
                  onFileRemove={() => handleFileRemove("articlesOfIncorporation")}
                  selectedFile={documents.articlesOfIncorporation.file}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 5: By-Laws
              </CardTitle>
              <CardDescription>Upload your By-Laws</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload By-Laws</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("bylaws", file)}
                  onFileRemove={() => handleFileRemove("bylaws")}
                  selectedFile={documents.bylaws.file}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 6: Most Recent General Information Sheet (GIS)
              </CardTitle>
              <CardDescription>Upload your most recent GIS filed with SEC</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Most Recent General Information Sheet (GIS)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("gis", file)}
                  onFileRemove={() => handleFileRemove("gis")}
                  selectedFile={documents.gis.file}
                />
              </div>
            </CardContent>
          </Card>
        </>
      )
    }

    if (normalizedOwnershipType === "cooperative") {
      return (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 3: CDA Certificate of Registration
              </CardTitle>
              <CardDescription>
                Upload your Cooperative Development Authority Certificate of Registration
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload CDA Certificate of Registration</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("cdaCertificate", file)}
                  onFileRemove={() => handleFileRemove("cdaCertificate")}
                  selectedFile={documents.cdaCertificate.file}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 4: Articles of Cooperation
              </CardTitle>
              <CardDescription>Upload your Articles of Cooperation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Articles of Cooperation</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("articlesOfCooperation", file)}
                  onFileRemove={() => handleFileRemove("articlesOfCooperation")}
                  selectedFile={documents.articlesOfCooperation.file}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 5: By-Laws
              </CardTitle>
              <CardDescription>Upload your By-Laws</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload By-Laws</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("bylaws", file)}
                  onFileRemove={() => handleFileRemove("bylaws")}
                  selectedFile={documents.bylaws.file}
                />
              </div>
            </CardContent>
          </Card>
        </>
      )
    }

    if (normalizedOwnershipType === "religious") {
      return (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 3: SEC Certificate of Incorporation (Religious Corporation)
              </CardTitle>
              <CardDescription>Upload your SEC Certificate of Incorporation for Religious Corporation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload SEC Certificate of Incorporation (Religious Corporation)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("secCertificate", file)}
                  onFileRemove={() => handleFileRemove("secCertificate")}
                  selectedFile={documents.secCertificate.file}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 4: Articles of Incorporation (Religious Corporation)
              </CardTitle>
              <CardDescription>Upload your Articles of Incorporation for Religious Corporation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Articles of Incorporation (Religious Corporation)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("articlesOfIncorporation", file)}
                  onFileRemove={() => handleFileRemove("articlesOfIncorporation")}
                  selectedFile={documents.articlesOfIncorporation.file}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 5: By-Laws
              </CardTitle>
              <CardDescription>Upload your By-Laws</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload By-Laws</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("bylaws", file)}
                  onFileRemove={() => handleFileRemove("bylaws")}
                  selectedFile={documents.bylaws.file}
                />
              </div>
            </CardContent>
          </Card>
        </>
      )
    }

    if (normalizedOwnershipType === "non-profit") {
      return (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 3: SEC Certificate of Incorporation (Non-Stock / Non-Profit)
              </CardTitle>
              <CardDescription>
                Upload your SEC Certificate of Incorporation for Non-Stock/Non-Profit Organization
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload SEC Certificate of Incorporation (Non-Stock / Non-Profit)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("secCertificate", file)}
                  onFileRemove={() => handleFileRemove("secCertificate")}
                  selectedFile={documents.secCertificate.file}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 4: Articles of Incorporation
              </CardTitle>
              <CardDescription>Upload your Articles of Incorporation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Articles of Incorporation</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("articlesOfIncorporation", file)}
                  onFileRemove={() => handleFileRemove("articlesOfIncorporation")}
                  selectedFile={documents.articlesOfIncorporation.file}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 5: By-Laws
              </CardTitle>
              <CardDescription>Upload your By-Laws</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload By-Laws</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("bylaws", file)}
                  onFileRemove={() => handleFileRemove("bylaws")}
                  selectedFile={documents.bylaws.file}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Document 6: Most Recent General Information Sheet (GIS)
              </CardTitle>
              <CardDescription>Upload your most recent GIS filed with SEC</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Most Recent General Information Sheet (GIS)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("gis", file)}
                  onFileRemove={() => handleFileRemove("gis")}
                  selectedFile={documents.gis.file}
                />
              </div>
            </CardContent>
          </Card>
        </>
      )
    }

    return null
  }

  return (
    <div className="space-y-6">
      {/* Document 1: Permit Application Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Document 1: Permit Application Form
          </CardTitle>
          <CardDescription>Download, fill out, and upload the completed application form</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Please download the official application form first, fill it out completely, then upload the completed
              form below.
            </AlertDescription>
          </Alert>

          <div className="flex items-center gap-4">
            <Button onClick={handleDownloadForm} variant="outline" className="flex items-center gap-2 bg-transparent">
              <Download className="h-4 w-4" />
              Download Application Form
            </Button>
          </div>

          <div className="space-y-2">
            <Label>Upload Completed Application Form</Label>
            <Dropzone
              onFileSelect={(file) => handleFileSelect("applicationForm", file)}
              onFileRemove={() => handleFileRemove("applicationForm")}
              selectedFile={documents.applicationForm.file}
            />
          </div>
        </CardContent>
      </Card>

      {/* Document 2: Barangay Clearance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Document 2: Barangay Clearance
          </CardTitle>
          <CardDescription>Upload your valid Barangay Clearance certificate</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Upload Barangay Clearance</Label>
            <Dropzone
              onFileSelect={(file) => handleFileSelect("barangayClearance", file)}
              onFileRemove={() => handleFileRemove("barangayClearance")}
              selectedFile={documents.barangayClearance.file}
            />
          </div>
        </CardContent>
      </Card>

      {renderConditionalDocuments()}
    </div>
  )
}
