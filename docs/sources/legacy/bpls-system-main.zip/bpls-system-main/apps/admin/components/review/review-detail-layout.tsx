"use client";

import Link from "next/link";
import { Button } from "@repo/ui/components/button";
import { Card, CardContent } from "@repo/ui/components/card";
import { ArrowLeft } from "lucide-react";
import { PermitApplicationHeader } from "@/components/permit/permit-application-header";
import { BusinessOwnerCard } from "@/components/permit/business-owner-card";
import { BusinessInfoCard } from "@/components/permit/business-info-card";
import { DocumentsCard } from "@/components/permit/documents-card";
import { ApplicationTimelineCard } from "@/components/permit/application-timeline-card";

interface ReviewDetailLayoutProps {
  /** Application data to display */
  application: {
    applicationNumber: string;
    status: string;
    submittedOn: string;
    owner: {
      profilePhoto?: string;
      firstName: string;
      middleName?: string;
      lastName: string;
      fullName: string;
      birthDate: string;
      civilStatus: string;
      gender: string;
      citizenship: string;
      tin: string;
      mobile: string;
      email: string;
      address: {
        houseNo: string;
        street: string;
        city: string;
        district: string;
        barangay: string;
        zone: string;
      };
    };
    business: {
      name: string;
      dateEstablished: string;
      ownershipType: string;
      occupancy: string;
      permitPaymentCadence: string;
      maleEmployeeCount: number;
      femaleEmployeeCount: number;
      contactNumber: string;
      email: string;
      address: {
        houseNo: string;
        street: string;
        city: string;
        district: string;
        barangay: string;
        zone: string;
      };
      linesOfBusiness: Array<{
        id: string;
        businessCategory: string;
        categoryName: string;
        capitalInvestment: string;
        businessAnnualRevenue: string;
        permitApplicationType: string;
      }>;
    };
    prerequisites: {
      ownershipType: string;
      documents: Record<string, { uploaded: boolean; fileName: string }>;
    };
  } | null;
  /** Department name for branding */
  departmentName: string;
  /** Department route prefix (e.g., "sanitary", "bfp") */
  departmentRoute: string;
  /** Application ID */
  applicationId: string;
  /** Optional callback when approve button is clicked */
  onApprove?: () => void;
}

/**
 * ReviewDetailLayout Component
 *
 * Reusable layout for department review detail pages.
 * Displays permit application details with approval actions.
 *
 * Features:
 * - Application header with status and actions
 * - Business owner information card
 * - Business details card
 * - Document uploads card
 * - Application timeline sidebar
 * - Not found state for invalid applications
 *
 * @example
 * ```tsx
 * <ReviewDetailLayout
 *   application={applicationData}
 *   departmentName="Sanitary Department"
 *   departmentRoute="sanitary"
 *   applicationId="1"
 *   onApprove={() => console.log('Approved')}
 * />
 * ```
 */
export function ReviewDetailLayout({
  application,
  departmentName,
  departmentRoute,
  applicationId,
  onApprove,
}: ReviewDetailLayoutProps) {
  if (!application) {
    return (
      <div className="flex-1 space-y-4 p-4 pt-6">
        <div className="flex items-center gap-4">
          <Link href={`/${departmentRoute}/review`}>
            <Button variant="outline" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to {departmentName}
            </Button>
          </Link>
        </div>
        <Card>
          <CardContent className="flex items-center justify-center py-8">
            <div className="text-center">
              <h3 className="text-lg font-semibold">Application Not Found</h3>
              <p className="text-muted-foreground">The application with ID "{applicationId}" could not be found.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const defaultHandleApprove = () => {
    console.log(`Approving ${departmentName} certificate for:`, applicationId);
  };

  return (
    <div className="flex-1 space-y-6 p-4 pt-6">
      {/* Header */}
      <PermitApplicationHeader
        applicationNumber={application.applicationNumber}
        submittedOn={application.submittedOn}
        status={application.status}
        backUrl={`/${departmentRoute}/review`}
        onApprove={onApprove || defaultHandleApprove}
        showActions={true}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Business Owner Information */}
          <BusinessOwnerCard
            owner={{
              ...application.owner,
              address: `${application.owner.address.houseNo} ${application.owner.address.street}, ${application.owner.address.barangay}, ${application.owner.address.city}, ${application.owner.address.district}`,
            }}
          />

          {/* Business Information */}
          <BusinessInfoCard business={{
            ...application.business,
            address: `${application.business.address.houseNo} ${application.business.address.street}, ${application.business.address.barangay}, ${application.business.address.city}, ${application.business.address.district}`,
          } as any} />

          {/* Documents */}
          <DocumentsCard documents={application.prerequisites.documents} />
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Application Timeline */}
          <ApplicationTimelineCard resourceId={applicationId} resourceType="permit_application" />
        </div>
      </div>
    </div>
  );
}
