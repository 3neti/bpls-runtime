/**
 * UnitsOfMeasurementCard Component
 *
 * A shared component for managing units of measurement (asset variables) for a permit application.
 * Used in:
 * - /dashboard/permit-applications/assessment/[id] - During permit assessment (edit mode or read-only)
 *
 * Units of measurement are tied to a permit application and used in formula-based fee calculations.
 */

"use client";

import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { Ruler, Plus, Trash2, Pencil, X, Check, AlertCircle } from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@repo/ui/components/table";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";

interface UnitOfMeasurement {
  _id: Id<"unitsOfMeasurement">;
  applicationId: Id<"business_permit_applications">;
  variableName: string;
  quantity: number;
  description?: string;
  createdAt: string;
  updatedAt: string;
}

export interface UnitsOfMeasurementCardProps {
  /** Permit application ID to fetch/manage units for */
  applicationId: Id<"business_permit_applications">;
  /** Read-only mode - hides add/edit/delete actions */
  readOnly?: boolean;
  /** Compact mode for embedded use */
  compact?: boolean;
  /** Custom title override */
  title?: string;
  /** Custom description override */
  description?: string;
  /** Disable adding new units */
  disabled?: boolean;
  /** Reason for being disabled (shown in tooltip) */
  disabledReason?: string;
}

export function UnitsOfMeasurementCard({
  applicationId,
  readOnly = false,
  compact = false,
  title = "Units of Measurement",
  description = "Manage unit quantities used for fee calculations (e.g., number of horses, tables, parking spaces)",
  disabled = false,
  disabledReason,
}: UnitsOfMeasurementCardProps) {
  const { toast } = useToast();

  // Fetch units for this application
  const units = useQuery(api.unitsOfMeasurement.list.list, { applicationId });

  // Mutations
  const createUnit = useMutation(api.unitsOfMeasurement.create.create);
  const updateUnit = useMutation(api.unitsOfMeasurement.update.update);
  const removeUnit = useMutation(api.unitsOfMeasurement.remove.remove);

  // Dialog states
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [editingId, setEditingId] = useState<Id<"unitsOfMeasurement"> | null>(null);
  const [deletingUnit, setDeletingUnit] = useState<UnitOfMeasurement | null>(null);

  // Form states
  const [newVariableName, setNewVariableName] = useState("");
  const [newQuantity, setNewQuantity] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [editVariableName, setEditVariableName] = useState("");
  const [editQuantity, setEditQuantity] = useState("");
  const [editDescription, setEditDescription] = useState("");

  // Loading states
  const [isCreating, setIsCreating] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Reset form
  const resetForm = () => {
    setNewVariableName("");
    setNewQuantity("");
    setNewDescription("");
  };

  // Handle create
  const handleCreate = async () => {
    if (!newVariableName.trim()) {
      toast({
        title: "Validation Error",
        description: "Variable name is required",
        variant: "destructive",
      });
      return;
    }

    const quantity = Number.parseFloat(newQuantity);
    if (Number.isNaN(quantity) || quantity < 0) {
      toast({
        title: "Validation Error",
        description: "Quantity must be a non-negative number",
        variant: "destructive",
      });
      return;
    }

    setIsCreating(true);
    try {
      await createUnit({
        applicationId,
        variableName: newVariableName.trim(),
        quantity,
        description: newDescription.trim() || undefined,
      });

      toast({
        title: "Success",
        description: "Unit of measurement added successfully",
      });

      setShowAddDialog(false);
      resetForm();
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add unit",
        variant: "destructive",
      });
    } finally {
      setIsCreating(false);
    }
  };

  // Handle start edit
  const handleStartEdit = (unit: UnitOfMeasurement) => {
    setEditingId(unit._id);
    setEditVariableName(unit.variableName);
    setEditQuantity(unit.quantity.toString());
    setEditDescription(unit.description || "");
  };

  // Handle cancel edit
  const handleCancelEdit = () => {
    setEditingId(null);
    setEditVariableName("");
    setEditQuantity("");
    setEditDescription("");
  };

  // Handle save edit
  const handleSaveEdit = async (unitId: Id<"unitsOfMeasurement">) => {
    if (!editVariableName.trim()) {
      toast({
        title: "Validation Error",
        description: "Variable name is required",
        variant: "destructive",
      });
      return;
    }

    const quantity = Number.parseFloat(editQuantity);
    if (Number.isNaN(quantity) || quantity < 0) {
      toast({
        title: "Validation Error",
        description: "Quantity must be a non-negative number",
        variant: "destructive",
      });
      return;
    }

    setIsUpdating(true);
    try {
      await updateUnit({
        id: unitId,
        variableName: editVariableName.trim(),
        quantity,
        description: editDescription.trim() || undefined,
      });

      toast({
        title: "Success",
        description: "Unit of measurement updated successfully",
      });

      handleCancelEdit();
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update unit",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  // Handle delete
  const handleDelete = async () => {
    if (!deletingUnit) return;

    setIsDeleting(true);
    try {
      await removeUnit({ id: deletingUnit._id });

      toast({
        title: "Success",
        description: "Unit of measurement deleted successfully",
      });

      setShowDeleteDialog(false);
      setDeletingUnit(null);
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete unit",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  // Loading state
  if (units === undefined) {
    return (
      <Card>
        <CardHeader className={compact ? "pb-3" : undefined}>
          <CardTitle className={`flex items-center gap-2 ${compact ? "text-base" : ""}`}>
            <Ruler className={compact ? "h-4 w-4" : "h-5 w-5"} />
            {title}
          </CardTitle>
          {!compact && <CardDescription>{description}</CardDescription>}
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const hasUnits = units && units.length > 0;

  return (
    <>
      <Card>
        <CardHeader className={compact ? "pb-3" : undefined}>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className={`flex items-center gap-2 ${compact ? "text-base" : ""}`}>
                <Ruler className={compact ? "h-4 w-4" : "h-5 w-5"} />
                {title}
              </CardTitle>
              {!compact && <CardDescription className="mt-1.5">{description}</CardDescription>}
            </div>
            {!readOnly && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span tabIndex={disabled ? 0 : undefined}>
                      <Button
                        size={compact ? "sm" : "default"}
                        onClick={() => setShowAddDialog(true)}
                        disabled={disabled}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Unit
                      </Button>
                    </span>
                  </TooltipTrigger>
                  {disabled && disabledReason && (
                    <TooltipContent>
                      <p>{disabledReason}</p>
                    </TooltipContent>
                  )}
                </Tooltip>
              </TooltipProvider>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {!hasUnits ? (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <AlertCircle className="h-10 w-10 text-muted-foreground mb-3" />
              <p className="text-muted-foreground">No units of measurement configured</p>
              {!readOnly && (
                <p className="text-sm text-muted-foreground mt-1">Add units to enable formula-based fee calculations</p>
              )}
            </div>
          ) : (
            <div className="border rounded-lg">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Variable Name</TableHead>
                    <TableHead className="text-right">Quantity</TableHead>
                    <TableHead>Description</TableHead>
                    {!readOnly && <TableHead className="w-[100px]">Actions</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {units.map((unit) => {
                    const isEditing = editingId === unit._id;

                    return (
                      <TableRow key={unit._id}>
                        <TableCell className="font-medium">
                          {isEditing ? (
                            <Input
                              value={editVariableName}
                              onChange={(e) => setEditVariableName(e.target.value)}
                              placeholder="e.g., numberOfHorses"
                              className="h-8"
                            />
                          ) : (
                            <code className="text-sm bg-muted px-2 py-1 rounded">{unit.variableName}</code>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          {isEditing ? (
                            <Input
                              type="number"
                              min="0"
                              value={editQuantity}
                              onChange={(e) => setEditQuantity(e.target.value)}
                              className="h-8 w-24 ml-auto"
                            />
                          ) : (
                            <span className="font-mono">{unit.quantity}</span>
                          )}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {isEditing ? (
                            <Input
                              value={editDescription}
                              onChange={(e) => setEditDescription(e.target.value)}
                              placeholder="Optional description"
                              className="h-8"
                            />
                          ) : (
                            unit.description || "-"
                          )}
                        </TableCell>
                        {!readOnly && (
                          <TableCell>
                            {isEditing ? (
                              <div className="flex items-center gap-1">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => handleSaveEdit(unit._id)}
                                  disabled={isUpdating}
                                >
                                  <Check className="h-4 w-4 text-green-600" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={handleCancelEdit}
                                  disabled={isUpdating}
                                >
                                  <X className="h-4 w-4 text-muted-foreground" />
                                </Button>
                              </div>
                            ) : (
                              <div className="flex items-center gap-1">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => handleStartEdit(unit as UnitOfMeasurement)}
                                >
                                  <Pencil className="h-4 w-4 text-muted-foreground" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => {
                                    setDeletingUnit(unit as UnitOfMeasurement);
                                    setShowDeleteDialog(true);
                                  }}
                                >
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        )}
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add Unit Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Unit of Measurement</DialogTitle>
            <DialogDescription>
              Add a new unit variable for fee calculations. Variable names should be descriptive and follow camelCase
              convention.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="variableName">Variable Name *</Label>
              <Input
                id="variableName"
                placeholder="e.g., numberOfHorses, parkingSpaces, numberOfTables"
                value={newVariableName}
                onChange={(e) => setNewVariableName(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                This name will be used in fee formulas. Use alphanumeric characters only.
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="quantity">Quantity *</Label>
              <Input
                id="quantity"
                type="number"
                min="0"
                placeholder="0"
                value={newQuantity}
                onChange={(e) => setNewQuantity(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description (Optional)</Label>
              <Input
                id="description"
                placeholder="e.g., Number of horses for stabling fee"
                value={newDescription}
                onChange={(e) => setNewDescription(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowAddDialog(false);
                resetForm();
              }}
              disabled={isCreating}
            >
              Cancel
            </Button>
            <Button onClick={handleCreate} disabled={isCreating}>
              {isCreating ? "Adding..." : "Add Unit"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Unit of Measurement</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deletingUnit?.variableName}"? This action cannot be undone and may
              affect fee calculations that depend on this variable.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel
              disabled={isDeleting}
              onClick={() => {
                setShowDeleteDialog(false);
                setDeletingUnit(null);
              }}
            >
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
