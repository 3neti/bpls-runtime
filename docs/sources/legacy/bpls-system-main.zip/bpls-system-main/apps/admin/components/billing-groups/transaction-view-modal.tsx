"use client"

import { useQuery } from "convex/react"
import { Eye, ChevronDown } from "lucide-react"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { Button } from "@repo/ui/components/button"
import { Input } from "@repo/ui/components/input"
import { Label } from "@repo/ui/components/label"
import { Badge } from "@repo/ui/components/badge"
import { Separator } from "@repo/ui/components/separator"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card"
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import { Skeleton } from "@repo/ui/components/skeleton"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { formatCurrency } from "@/lib/utils"
import { useColumnVisibilityStore, isLineItemsColumnVisible } from "@/lib/stores/column-visibility-store"

// Static column definitions for line items table
const STATIC_COLUMNS = [
  { id: "fee", label: "Fee", alwaysVisible: true },
  { id: "amount", label: "Amount", alwaysVisible: false },
  { id: "qty", label: "Qty", alwaysVisible: false },
  { id: "subtotal", label: "Subtotal", alwaysVisible: false },
] as const

type FieldType = "text" | "number" | "currency" | "date" | "dropdown" | "checkbox"

interface Field {
  _id: Id<"billing_group_fields">
  name: string
  fieldType: FieldType
  isRequired: boolean
  sortOrder: number
  options?: string[]
  placeholder?: string
  defaultValue?: string
}

interface FeeCustomFieldValue {
  fieldId: Id<"billing_group_fee_fields">
  value: string
}

interface LineItemWithFee {
  _id: Id<"billing_group_line_items">
  feeId: Id<"billing_group_fees">
  amount: number
  quantity?: number
  fee?: {
    _id: Id<"billing_group_fees">
    name: string
    code: string
    defaultAmount: number
    customFieldValues?: FeeCustomFieldValue[]
  }
}

type FeeFieldType = "text" | "number" | "currency" | "date" | "dropdown" | "checkbox"

interface FeeField {
  _id: Id<"billing_group_fee_fields">
  name: string
  fieldType: FeeFieldType
  isRequired: boolean
  includeInReceipt?: boolean
  sortOrder: number
  options?: string[]
}

interface TransactionViewModalProps {
  open: boolean
  onClose: () => void
  billingGroupId: Id<"billing_groups">
  recordId: Id<"billing_group_records"> | null
}

const statusConfig = {
  pending: {
    label: "Pending",
    variant: "outline" as const,
    className: "text-yellow-600 border-yellow-300",
  },
  completed: {
    label: "Completed",
    variant: "outline" as const,
    className: "text-green-600 border-green-300",
  },
  cancelled: {
    label: "Cancelled",
    variant: "outline" as const,
    className: "text-red-600 border-red-300",
  },
}

export function TransactionViewModal({
  open,
  onClose,
  billingGroupId,
  recordId,
}: TransactionViewModalProps) {
  // Column visibility from store
  const { lineItemsColumns, toggleLineItemsColumn } = useColumnVisibilityStore()

  // Helper to check if a column is visible
  const isColumnVisible = (columnId: string) => isLineItemsColumnVisible(lineItemsColumns, columnId)

  // Fetch billing group with fields
  const billingGroup = useQuery(api.billingGroups.getById, { id: billingGroupId })

  // Fetch record data with line items
  const recordData = useQuery(
    api.billingGroupRecords.getByIdWithLineItems,
    recordId ? { id: recordId } : "skip"
  )

  // Get fields sorted by sortOrder (exclude amount fields since line items handle amounts)
  const fields: Field[] = (billingGroup?.fields || [])
    .filter((f) => f._id !== billingGroup?.amountFieldId)
    .sort((a, b) => a.sortOrder - b.sortOrder)

  // Helper to get field value
  const getFieldValue = (fieldId: Id<"billing_group_fields">): string => {
    const fv = recordData?.fieldValues?.find((f: { fieldId: Id<"billing_group_fields">; value: string }) => f.fieldId === fieldId)
    return fv?.value || "—"
  }

  // Format field value for display
  const formatFieldValue = (field: Field, value: string): string => {
    if (!value || value === "—") return "—"

    if (field.fieldType === "currency") {
      const num = parseFloat(value)
      return isNaN(num) ? value : formatCurrency(num)
    }
    if (field.fieldType === "checkbox") {
      return value === "true" ? "Yes" : "No"
    }
    if (field.fieldType === "date") {
      try {
        return new Date(value).toLocaleDateString("en-US", {
          year: "numeric",
          month: "short",
          day: "numeric",
        })
      } catch {
        return value
      }
    }
    return value
  }

  // Get fee fields from recordData
  const feeFields: FeeField[] = (recordData?.feeFields || []) as FeeField[]

  // Helper to get custom field value from fee
  const getFeeFieldValue = (
    fee: LineItemWithFee["fee"],
    fieldId: Id<"billing_group_fee_fields">
  ): string => {
    if (!fee?.customFieldValues) return "—"
    const fieldValue = fee.customFieldValues.find(
      (fv) => fv.fieldId === fieldId
    )
    return fieldValue?.value || "—"
  }

  // Format fee field value for display
  const formatFeeFieldValue = (fieldType: FeeFieldType, value: string): string => {
    if (!value || value === "—") return "—"

    if (fieldType === "currency") {
      const num = parseFloat(value)
      return isNaN(num) ? value : formatCurrency(num)
    }
    if (fieldType === "checkbox") {
      return value === "true" ? "Yes" : "No"
    }
    if (fieldType === "date") {
      try {
        return new Date(value).toLocaleDateString("en-US", {
          year: "numeric",
          month: "short",
          day: "numeric",
        })
      } catch {
        return value
      }
    }
    return value
  }

  // Calculate total
  const total = recordData?.lineItems?.reduce(
    (sum: number, item: { amount: number; quantity?: number }) => sum + item.amount * (item.quantity || 1),
    0
  ) || 0

  const isLoading = !recordData || !billingGroup
  const status = (recordData?.status || "pending") as keyof typeof statusConfig
  const statusInfo = statusConfig[status]

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-[850px] max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Eye className="h-5 w-5 text-muted-foreground" />
              <div>
                <DialogTitle>View Transaction</DialogTitle>
                <DialogDescription>
                  {isLoading ? (
                    <Skeleton className="h-4 w-48 mt-1" />
                  ) : (
                    <>Transaction #{recordData.transactionNumber}</>
                  )}
                </DialogDescription>
              </div>
            </div>
            {!isLoading && (
              <Badge variant={statusInfo.variant} className={statusInfo.className}>
                {statusInfo.label}
              </Badge>
            )}
          </div>
        </DialogHeader>

        {isLoading ? (
          <div className="py-4 space-y-6">
            <div className="space-y-4">
              <Skeleton className="h-5 w-32" />
              <div className="grid gap-4 sm:grid-cols-2">
                <Skeleton className="h-10" />
                <Skeleton className="h-10" />
                <Skeleton className="h-10" />
                <Skeleton className="h-10" />
              </div>
            </div>
            <Separator />
            <div className="space-y-4">
              <Skeleton className="h-5 w-24" />
              <Skeleton className="h-32" />
            </div>
          </div>
        ) : (
          <div className="py-4 space-y-6">
            {/* System Columns (Transaction Details) */}
            <div className="space-y-4">
              <h3 className="font-medium text-sm">Transaction Details</h3>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label className="text-muted-foreground">Date</Label>
                  <Input
                    value={recordData.date || recordData.createdAt?.split("T")[0] || "—"}
                    readOnly
                    className="bg-muted cursor-default"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-muted-foreground">Payment Method</Label>
                  <Input
                    value={recordData.paymentMethod || "Cash"}
                    readOnly
                    className="bg-muted cursor-default"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-muted-foreground">Reference Number</Label>
                  <Input
                    value={recordData.referenceNumber || "—"}
                    readOnly
                    className="bg-muted cursor-default"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-muted-foreground">Payor Name</Label>
                  <Input
                    value={recordData.payorName || "—"}
                    readOnly
                    className="bg-muted cursor-default"
                  />
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label className="text-muted-foreground">Description</Label>
                  <Input
                    value={recordData.description || "—"}
                    readOnly
                    className="bg-muted cursor-default"
                  />
                </div>
              </div>
              <Separator />
            </div>

            {/* Dynamic Header Fields (Custom Fields) */}
            {fields.length > 0 && (
              <div className="space-y-4">
                <h3 className="font-medium text-sm text-muted-foreground">Additional Fields</h3>
                <div className="grid gap-4 sm:grid-cols-2">
                  {fields.map((field) => {
                    const value = getFieldValue(field._id)
                    const displayValue = formatFieldValue(field, value)

                    return (
                      <div key={field._id} className="space-y-2">
                        <Label className="text-muted-foreground">{field.name}</Label>
                        <Input
                          value={displayValue}
                          readOnly
                          className="bg-muted cursor-default"
                        />
                      </div>
                    )
                  })}
                </div>
                <Separator />
              </div>
            )}

            {/* Line Items */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base">Line Items</CardTitle>
                    <CardDescription>
                      {recordData.lineItems?.length || 0} item{(recordData.lineItems?.length || 0) !== 1 ? "s" : ""} in this transaction
                    </CardDescription>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm">
                        Columns
                        <ChevronDown className="ml-2 h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-[200px]">
                      <DropdownMenuLabel>Static Columns</DropdownMenuLabel>
                      {STATIC_COLUMNS.map((column) => (
                        <DropdownMenuCheckboxItem
                          key={column.id}
                          checked={isColumnVisible(column.id)}
                          onCheckedChange={() => toggleLineItemsColumn(column.id)}
                          disabled={column.alwaysVisible}
                        >
                          {column.label}
                        </DropdownMenuCheckboxItem>
                      ))}
                      {feeFields.length > 0 && (
                        <>
                          <DropdownMenuSeparator />
                          <DropdownMenuLabel>Fee Fields</DropdownMenuLabel>
                          {feeFields.map((field) => (
                            <DropdownMenuCheckboxItem
                              key={field._id}
                              checked={isColumnVisible(`feeField_${field._id}`)}
                              onCheckedChange={() => toggleLineItemsColumn(`feeField_${field._id}`)}
                            >
                              {field.name}
                            </DropdownMenuCheckboxItem>
                          ))}
                        </>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent>
                {!recordData.lineItems || recordData.lineItems.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    No line items found
                  </div>
                ) : (
                  <div className="rounded-md border overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[40px]">#</TableHead>
                          <TableHead className="whitespace-nowrap">Fee</TableHead>
                          {feeFields.map((field) =>
                            isColumnVisible(`feeField_${field._id}`) && (
                              <TableHead key={field._id} className="min-w-[100px] whitespace-nowrap">
                                {field.name}
                              </TableHead>
                            )
                          )}
                          {isColumnVisible("amount") && (
                            <TableHead className="min-w-[130px] shrink-0 text-right whitespace-nowrap px-3">
                              Amount
                            </TableHead>
                          )}
                          {isColumnVisible("qty") && (
                            <TableHead className="min-w-[90px] shrink-0 text-center whitespace-nowrap px-3">
                              Qty
                            </TableHead>
                          )}
                          {isColumnVisible("subtotal") && (
                            <TableHead className="min-w-[120px] shrink-0 text-right whitespace-nowrap">
                              Subtotal
                            </TableHead>
                          )}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {recordData.lineItems.map((item: LineItemWithFee, index: number) => (
                          <TableRow key={item._id}>
                            <TableCell className="text-muted-foreground text-center">
                              {index + 1}
                            </TableCell>
                            <TableCell>
                              <div>
                                <span className="font-medium">{item.fee?.name || "Unknown Fee"}</span>
                                {item.fee?.code && (
                                  <span className="ml-2 text-xs text-muted-foreground">
                                    ({item.fee.code})
                                  </span>
                                )}
                              </div>
                            </TableCell>
                            {feeFields.map((field) =>
                              isColumnVisible(`feeField_${field._id}`) && (
                                <TableCell key={field._id} className="whitespace-nowrap">
                                  {formatFeeFieldValue(
                                    field.fieldType,
                                    getFeeFieldValue(item.fee, field._id)
                                  )}
                                </TableCell>
                              )
                            )}
                            {isColumnVisible("amount") && (
                              <TableCell className="text-right whitespace-nowrap px-3">
                                {formatCurrency(item.amount)}
                              </TableCell>
                            )}
                            {isColumnVisible("qty") && (
                              <TableCell className="text-center whitespace-nowrap px-3">
                                {item.quantity || 1}
                              </TableCell>
                            )}
                            {isColumnVisible("subtotal") && (
                              <TableCell className="text-right font-medium whitespace-nowrap">
                                {formatCurrency(item.amount * (item.quantity || 1))}
                              </TableCell>
                            )}
                          </TableRow>
                        ))}
                      </TableBody>
                      <TableFooter>
                        <TableRow>
                          <TableCell
                            colSpan={
                              2 + // # column + Fee column
                              feeFields.filter((f) => isColumnVisible(`feeField_${f._id}`)).length +
                              (isColumnVisible("amount") ? 1 : 0) +
                              (isColumnVisible("qty") ? 1 : 0)
                            }
                            className="text-right font-medium"
                          >
                            Total
                          </TableCell>
                          {isColumnVisible("subtotal") && (
                            <TableCell className="text-right font-bold text-lg whitespace-nowrap">
                              {formatCurrency(total)}
                            </TableCell>
                          )}
                        </TableRow>
                      </TableFooter>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        <DialogFooter>
          <Button type="button" variant="outline" onClick={onClose}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
