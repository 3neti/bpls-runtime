"use client"

import { useState, useEffect, useMemo } from "react"
import dynamic from "next/dynamic"
import { useQuery } from "convex/react"
import { Download, Printer, ChevronDown, Check, FileText, LayoutTemplate } from "lucide-react"

import { Skeleton } from "@repo/ui/components/skeleton"

// Dynamic imports for PDF components to avoid SSR issues with @react-pdf/renderer
const PDFViewerWrapper = dynamic(
  () => import("./pdf-components").then((mod) => mod.PDFViewerWrapper),
  { ssr: false, loading: () => <Skeleton className="w-full h-full" /> }
)

const PDFDownloadLinkWrapper = dynamic(
  () => import("./pdf-components").then((mod) => mod.PDFDownloadLinkWrapper),
  { ssr: false }
)

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { Button } from "@repo/ui/components/button"
import { Badge } from "@repo/ui/components/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { type ReceiptData, type LineItemData, type FeeFieldData, type FeeFieldValueData } from "./receipt-document"
import { TemplateReceiptDocument, type TemplateReceiptLayout } from "./template-receipt-document"

// Default hardcoded layout when no layouts exist in database
const DEFAULT_LAYOUT: TemplateReceiptLayout = {
  paperSize: "A4",
  orientation: "portrait",
  marginTop: 10,
  marginRight: 10,
  marginBottom: 10,
  marginLeft: 10,
  fontSize: 10,
  fontFamily: "Helvetica",
  headerTemplate: `{{billingGroupName}}
Official Receipt

Transaction No: {{transactionNumber}}
Status: {{status}}`,
  bodyTemplate: `Date: {{date}}

{{LINE_ITEMS_TABLE}}

TOTAL: {{totalAmount}}

AMOUNT IN WORDS:
{{totalInWords}}`,
  footerTemplate: `_________________________          _________________________
      Prepared By                        Received By

Printed: {{currentDate}}
This document is computer-generated`,
}

interface ReceiptPreviewModalProps {
  open: boolean
  onClose: () => void
  recordId: Id<"billing_group_records">
  billingGroupId: Id<"billing_groups">
  billingGroupName: string
}

export function ReceiptPreviewModal({
  open,
  onClose,
  recordId,
  billingGroupId,
  billingGroupName,
}: ReceiptPreviewModalProps) {
  const [isClient, setIsClient] = useState(false)
  const [selectedLayoutId, setSelectedLayoutId] = useState<Id<"billing_group_print_layouts"> | null>(null)
  // ✅ Force remount key - increments each time modal opens to ensure fresh PDF state
  const [mountKey, setMountKey] = useState(0)

  // Fetch record with line items
  const recordData = useQuery(
    api.billingGroupRecords.getByIdWithLineItems,
    open ? { id: recordId } : "skip"
  )

  // Fetch available print layouts
  const layouts = useQuery(
    api.billingGroupPrintLayouts.listByGroup,
    open ? { billingGroupId } : "skip"
  )

  // Fetch default layout
  const defaultLayout = useQuery(
    api.billingGroupPrintLayouts.getDefault,
    open ? { billingGroupId } : "skip"
  )

  // Fetch selected layout details
  const selectedLayout = useQuery(
    api.billingGroupPrintLayouts.getById,
    selectedLayoutId ? { id: selectedLayoutId } : "skip"
  )

  // Set client-side rendering flag
  useEffect(() => {
    setIsClient(true)
  }, [])

  // Auto-select default layout when modal opens
  useEffect(() => {
    if (open && defaultLayout && !selectedLayoutId) {
      setSelectedLayoutId(defaultLayout._id)
    }
  }, [open, defaultLayout, selectedLayoutId])

  // Reset selection and increment mount key when modal closes/opens
  // This forces a complete remount of PDF components to prevent stale state
  useEffect(() => {
    if (!open) {
      setSelectedLayoutId(null)
    } else {
      // Increment mount key when modal opens to force fresh PDF component state
      setMountKey((prev) => prev + 1)
    }
  }, [open])

  if (!open) return null

  const isLoading = recordData === undefined || layouts === undefined
  const hasLayouts = layouts && layouts.length > 0
  const currentLayout = selectedLayout || defaultLayout

  // Filter fee fields where includeInReceipt is true
  const receiptFeeFields: FeeFieldData[] = (recordData?.feeFields || [])
    .filter((field: { includeInReceipt?: boolean }) => field.includeInReceipt === true)
    .map((field: { _id: string; name: string; fieldType: string }): FeeFieldData => ({
      fieldId: field._id,
      name: field.name,
      fieldType: field.fieldType as FeeFieldData["fieldType"],
    }))

  // Prepare receipt data
  const receiptData: ReceiptData | null = recordData
    ? {
        transactionNumber: recordData.transactionNumber,
        date: recordData.createdAt,
        billingGroupName,
        status: recordData.status,
        lineItems: (recordData.lineItems || []).map((item: {
          fee?: {
            code?: string
            name?: string
            customFieldValues?: Array<{ fieldId: string; value: string }>
          }
          amount: number
          quantity?: number
        }): LineItemData => ({
          feeCode: item.fee?.code || "N/A",
          feeName: item.fee?.name || "Unknown Fee",
          amount: item.amount,
          quantity: item.quantity || 1,
          subtotal: item.amount * (item.quantity || 1),
          customFieldValues: (item.fee?.customFieldValues || []).map(
            (cfv: { fieldId: string; value: string }): FeeFieldValueData => ({
              fieldId: cfv.fieldId,
              value: cfv.value,
            })
          ),
        })),
        totalAmount: recordData.totalAmount || 0,
        paymentMethod: recordData.paymentMethod,
        referenceNumber: recordData.referenceNumber,
        description: recordData.description,
        headerFields: (recordData.resolvedFields || [])
          .filter((fv: { fieldName?: string; value?: unknown; isDeleted?: boolean }) => fv.fieldName && fv.value && !fv.isDeleted)
          .map((fv: { fieldId?: string; fieldName?: string; value: unknown }) => ({
            fieldId: fv.fieldId,
            name: fv.fieldName,
            value: String(fv.value),
          })),
        feeFields: receiptFeeFields,
        printDate: new Date().toLocaleDateString(),
      }
    : null

  // Get the document to render based on whether we have a custom layout
  const getReceiptDocument = () => {
    if (!receiptData) return null

    // Check if current layout has template fields (new template-based layout)
    if (currentLayout && currentLayout.headerTemplate !== undefined) {
      // Use template-based document with database layout
      const layout: TemplateReceiptLayout = {
        paperSize: currentLayout.paperSize as "A4" | "Letter" | "Half-Letter",
        orientation: currentLayout.orientation,
        marginTop: currentLayout.marginTop ?? 10,
        marginRight: currentLayout.marginRight ?? 10,
        marginBottom: currentLayout.marginBottom ?? 10,
        marginLeft: currentLayout.marginLeft ?? 10,
        fontSize: currentLayout.fontSize ?? 10,
        fontFamily: (currentLayout.fontFamily as "Helvetica" | "Times-Roman" | "Courier") ?? "Helvetica",
        headerTemplate: currentLayout.headerTemplate,
        bodyTemplate: currentLayout.bodyTemplate ?? "",
        footerTemplate: currentLayout.footerTemplate ?? "",
      }
      return <TemplateReceiptDocument data={receiptData} layout={layout} />
    }

    // Fall back to hardcoded default layout (no database required)
    return <TemplateReceiptDocument data={receiptData} layout={DEFAULT_LAYOUT} />
  }

  const receiptDocument = getReceiptDocument()

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-[95vw] max-w-[95vw] w-full h-[90vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <DialogTitle>Receipt Preview</DialogTitle>
              {hasLayouts && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-2">
                      <LayoutTemplate className="h-4 w-4" />
                      {currentLayout?.name || "Default Layout"}
                      <ChevronDown className="h-3 w-3" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" className="w-56">
                    <DropdownMenuLabel>Select Layout</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    {layouts?.map((layout: { _id: Id<"billing_group_print_layouts">; name: string; isDefault?: boolean }) => (
                      <DropdownMenuItem
                        key={layout._id}
                        onClick={() => setSelectedLayoutId(layout._id)}
                        className="flex items-center justify-between"
                      >
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4" />
                          <span>{layout.name}</span>
                          {layout.isDefault && (
                            <Badge variant="secondary" className="text-xs">
                              Default
                            </Badge>
                          )}
                        </div>
                        {(selectedLayoutId === layout._id || (!selectedLayoutId && layout.isDefault)) && (
                          <Check className="h-4 w-4 text-primary" />
                        )}
                      </DropdownMenuItem>
                    ))}
                    {layouts && layouts.length === 0 && (
                      <div className="px-2 py-4 text-sm text-muted-foreground text-center">
                        No custom layouts available.
                        <br />
                        Using default receipt format.
                      </div>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
            {receiptData && isClient && receiptDocument && (
              <div className="flex items-center gap-2">
                <PDFDownloadLinkWrapper
                  document={receiptDocument}
                  fileName={`receipt-${receiptData.transactionNumber}.pdf`}
                >
                  {({ loading }) => (
                    <Button variant="outline" size="sm" disabled={loading}>
                      <Download className="mr-2 h-4 w-4" />
                      {loading ? "Preparing..." : "Download PDF"}
                    </Button>
                  )}
                </PDFDownloadLinkWrapper>
                <Button variant="outline" size="sm" onClick={() => window.print()}>
                  <Printer className="mr-2 h-4 w-4" />
                  Print
                </Button>
              </div>
            )}
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-hidden">
          {isLoading ? (
            <div className="h-full flex items-center justify-center">
              <Skeleton className="w-full h-full" />
            </div>
          ) : receiptData && isClient && receiptDocument ? (
            <PDFViewerWrapper
              key={`pdf-viewer-${recordId}-${mountKey}`}
              width="100%"
              height="100%"
              showToolbar={false}
              className="border rounded-md"
            >
              {receiptDocument}
            </PDFViewerWrapper>
          ) : (
            <div className="h-full flex items-center justify-center text-muted-foreground">
              Unable to load receipt data
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
