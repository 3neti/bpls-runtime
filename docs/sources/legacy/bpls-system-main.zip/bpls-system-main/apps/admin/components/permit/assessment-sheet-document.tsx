"use client";

import React from "react";
import { Document, Page, Text, View, StyleSheet, Image } from "@react-pdf/renderer";
import { formatCurrency, formatDate } from "@/lib/utils/formatting";

// Types for assessment sheet data
export interface FeeBreakdownItem {
  lobId: string;
  lobName: string;
  amount: number;
  isExcluded?: boolean;
}

export interface AggregatedFee {
  feeName: string;
  totalAmount: number;
  breakdown: FeeBreakdownItem[];
}

// New: LOB-grouped fee structure (fees grouped by Line of Business)
export interface LobGroupedFee {
  lobName: string;
  fees: Array<{
    feeName: string;
    amount: number;
  }>;
  subtotal: number;
}

// New: Payment schedule section for the PDF
export interface PaymentScheduleSection {
  sectionNumber: number;
  sectionLabel: string; // "Full Payment", "1st Semester", "Q1", etc.
  dueDate: string;
  totalAmount: number;
  paidAmount: number;
  balance: number;
  status: "pending" | "partial" | "paid";
}

export interface AssessmentSheetData {
  applicationNumber?: string;
  transactionType?: "ReNew" | "New" | "Renewal" | "Additional";
  ownerName?: string;
  businessName?: string;
  businessAddress?: string;
  paymentMode?: "Annually" | "Semi-Annually" | "Quarterly" | "ANNUALLY" | "SEMI-ANNUALLY" | "QUARTERLY";
  linesOfBusiness?: string[];
  aggregatedFees?: AggregatedFee[];
  lobGroupedFees?: LobGroupedFee[]; // New: fees grouped by LOB
  paymentSchedule?: PaymentScheduleSection[]; // New: payment schedule sections
  grandTotal?: number;
  // Footer fields
  preparedBy?: string;
  preparedDate?: string;
  approvedByName?: string;
  approvedByTitle?: string;

  // Settings - optional, uses defaults if not provided
  municipalityName?: string; // e.g., "MUNICIPALITY OF IPIL"
  provinceName?: string; // e.g., "Zamboanga Sibugay"
  municipalSealUrl?: string; // URL to municipal seal image
  treasurerName?: string; // e.g., "MARIA LUZ F. PULMANO"
  treasurerTitle?: string; // e.g., "Municipal Treasurer"
}

// Styles
const styles = StyleSheet.create({
  page: {
    padding: 20,
    fontSize: 9,
    fontFamily: "Helvetica",
  },
  headerContainer: {
    position: "relative",
    marginBottom: 10,
    paddingTop: 5,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
  },
  municipalSeal: {
    width: 55,
    height: 55,
    objectFit: "contain",
    marginRight: 12,
  },
  headerText: {
    textAlign: "center",
  },
  headerTitle: {
    fontSize: 12,
    fontWeight: "bold",
  },
  headerSubtitle: {
    fontSize: 10,
    marginTop: 2,
  },
  documentTitle: {
    fontSize: 12,
    fontWeight: "bold",
    textAlign: "center",
    marginTop: 12,
    marginBottom: 12,
    textDecoration: "underline",
  },
  applicationNoBox: {
    position: "absolute",
    right: 0,
    top: 0,
    textAlign: "right",
  },
  applicationNoLabel: {
    fontSize: 10,
    fontWeight: "bold",
  },
  infoSection: {
    marginBottom: 12,
  },
  infoRow: {
    flexDirection: "row",
    marginBottom: 3,
  },
  infoLabel: {
    width: 120,
    fontSize: 9,
  },
  infoValue: {
    flex: 1,
    fontSize: 9,
    fontWeight: "bold",
  },
  lobSection: {
    marginBottom: 10,
  },
  lobTitle: {
    fontSize: 9,
    marginBottom: 4,
  },
  lobList: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 20,
    marginLeft: 10,
  },
  lobItem: {
    fontSize: 9,
    fontWeight: "bold",
  },
  computationsSection: {
    marginTop: 8,
  },
  computationsTitle: {
    fontSize: 9,
    fontWeight: "bold",
    marginBottom: 8,
  },
  feeGroup: {
    marginBottom: 10,
  },
  feeGroupTitle: {
    fontSize: 9,
    fontWeight: "bold",
    marginBottom: 4,
  },
  feeBreakdownRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginLeft: 15,
    marginBottom: 2,
  },
  feeBreakdownLabel: {
    fontSize: 8,
    flex: 1,
  },
  feeBreakdownAmount: {
    fontSize: 8,
    width: 80,
    textAlign: "right",
  },
  subtotalRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginLeft: 15,
    marginTop: 4,
    paddingTop: 3,
    borderTopWidth: 0.5,
    borderTopColor: "#666",
  },
  subtotalLabel: {
    fontSize: 8,
    fontStyle: "italic",
  },
  subtotalAmount: {
    fontSize: 8,
    fontWeight: "bold",
    width: 100,
    textAlign: "right",
  },
  grandTotalSection: {
    marginTop: 10,
    paddingTop: 6,
    borderTopWidth: 1,
    borderTopColor: "#000",
  },
  grandTotalRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  grandTotalLabel: {
    fontSize: 11,
    fontWeight: "bold",
  },
  grandTotalAmount: {
    fontSize: 11,
    fontWeight: "bold",
    width: 120,
    textAlign: "right",
  },
  inWordsSection: {
    flexDirection: "row",
    marginTop: 4,
    alignItems: "flex-start",
  },
  inWordsLabel: {
    fontSize: 9,
    fontWeight: "bold",
    width: 70,
  },
  inWordsValue: {
    fontSize: 9,
    fontStyle: "italic",
    flex: 1,
  },
  footerSection: {
    marginTop: 15,
  },
  preparedBySection: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
  },
  preparedByLabel: {
    fontSize: 9,
    width: 80,
  },
  preparedByValue: {
    fontSize: 9,
    fontWeight: "bold",
    marginRight: 20,
  },
  preparedByDate: {
    fontSize: 9,
  },
  approvalSection: {
    flexDirection: "row",
    marginBottom: 15,
  },
  approvalColumn: {
    flex: 1,
  },
  approvalLabel: {
    fontSize: 9,
    marginBottom: 5,
  },
  signatureLine: {
    borderTopWidth: 1,
    borderTopColor: "#000",
    width: 200,
    marginTop: 15,
    marginBottom: 3,
  },
  signatureName: {
    fontSize: 10,
    fontWeight: "bold",
    textAlign: "center",
    width: 200,
  },
  signatureTitle: {
    fontSize: 8,
    textAlign: "center",
    width: 200,
  },
  acknowledgeSection: {
    marginTop: 10,
  },
  acknowledgeRow: {
    flexDirection: "row",
    justifyContent: "flex-end",
    alignItems: "flex-start",
  },
  acknowledgeColumn: {
    width: 250,
  },
  acknowledgeLabel: {
    fontSize: 9,
    marginBottom: 5,
  },
  acknowledgeLine: {
    borderTopWidth: 1,
    borderTopColor: "#000",
    width: "100%",
    marginTop: 15,
    marginBottom: 3,
  },
  acknowledgeHint: {
    fontSize: 8,
    textAlign: "center",
    marginBottom: 15,
  },
  dateLabel: {
    fontSize: 9,
    textAlign: "left",
    marginTop: 5,
  },
  pageNumber: {
    position: "absolute",
    bottom: 20,
    right: 20,
    fontSize: 8,
  },
  // Schedule of Payments styles
  scheduleSection: {
    marginTop: 10,
    paddingTop: 4,
  },
  scheduleSectionTitle: {
    fontSize: 10,
    fontWeight: "bold",
    marginBottom: 4,
    textDecoration: "underline",
  },
  scheduleModeLabel: {
    fontSize: 9,
    marginBottom: 4,
  },
  scheduleTable: {
    marginTop: 2,
  },
  scheduleTableHeader: {
    flexDirection: "row",
    backgroundColor: "#f3f4f6",
    borderBottomWidth: 1,
    borderBottomColor: "#000",
    paddingVertical: 4,
  },
  scheduleTableRow: {
    flexDirection: "row",
    borderBottomWidth: 0.5,
    borderBottomColor: "#ccc",
    paddingVertical: 3,
  },
  scheduleColSection: {
    width: "20%",
    fontSize: 8,
    paddingLeft: 4,
  },
  scheduleColDueDate: {
    width: "25%",
    fontSize: 8,
  },
  scheduleColAmount: {
    width: "27.5%",
    fontSize: 8,
    textAlign: "right",
    paddingRight: 8,
  },
  scheduleColBalance: {
    width: "27.5%",
    fontSize: 8,
    textAlign: "right",
    paddingRight: 4,
  },
  scheduleHeaderText: {
    fontSize: 8,
    fontWeight: "bold",
  },
});

// Format currency helper for PDF (plain number format without symbol)
const formatCurrencyForPDF = (amount: number): string => {
  return formatCurrency(amount);
};

// Convert number to words helper
const numberToWords = (amount: number): string => {
  const ones = [
    "",
    "One",
    "Two",
    "Three",
    "Four",
    "Five",
    "Six",
    "Seven",
    "Eight",
    "Nine",
    "Ten",
    "Eleven",
    "Twelve",
    "Thirteen",
    "Fourteen",
    "Fifteen",
    "Sixteen",
    "Seventeen",
    "Eighteen",
    "Nineteen",
  ];
  const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

  const convertHundreds = (num: number): string => {
    if (num === 0) return "";
    if (num < 20) return ones[num];
    if (num < 100) {
      return tens[Math.floor(num / 10)] + (num % 10 !== 0 ? " " + ones[num % 10] : "");
    }
    return ones[Math.floor(num / 100)] + " Hundred" + (num % 100 !== 0 ? " " + convertHundreds(num % 100) : "");
  };

  const convertThousands = (num: number): string => {
    if (num === 0) return "Zero";
    if (num < 1000) return convertHundreds(num);
    if (num < 1000000) {
      return (
        convertHundreds(Math.floor(num / 1000)) +
        " Thousand" +
        (num % 1000 !== 0 ? " " + convertHundreds(num % 1000) : "")
      );
    }
    if (num < 1000000000) {
      return (
        convertThousands(Math.floor(num / 1000000)) +
        " Million" +
        (num % 1000000 !== 0 ? " " + convertThousands(num % 1000000) : "")
      );
    }
    return (
      convertThousands(Math.floor(num / 1000000000)) +
      " Billion" +
      (num % 1000000000 !== 0 ? " " + convertThousands(num % 1000000000) : "")
    );
  };

  const pesos = Math.floor(amount);
  const centavos = Math.round((amount - pesos) * 100);

  let result = convertThousands(pesos) + " Pesos";
  if (centavos > 0) {
    result += " And " + convertThousands(centavos) + " Cents";
  }

  return result;
};

// Format payment mode for display
const formatPaymentMode = (mode?: string): string => {
  if (!mode) return "";
  const normalized = mode.toUpperCase();
  switch (normalized) {
    case "ANNUALLY":
      return "ANNUALLY";
    case "SEMI-ANNUALLY":
      return "SEMI-ANNUALLY";
    case "QUARTERLY":
      return "QUARTERLY";
    default:
      return mode.toUpperCase();
  }
};

// Format transaction type for display
const formatTransactionType = (type?: string): string => {
  if (!type) return "";
  switch (type) {
    case "New":
      return "New";
    case "ReNew":
    case "Renewal":
      return "ReNew";
    case "Additional":
      return "Additional";
    default:
      return type;
  }
};

// Default values for settings - generic titles only, names/locations must be configured
const DEFAULT_TREASURER_TITLE = "Municipal Treasurer";

// Main Assessment Sheet Document Component
export const AssessmentSheetDocument: React.FC<{
  data?: AssessmentSheetData;
}> = ({ data }) => {
  const {
    applicationNumber = "",
    transactionType,
    ownerName = "",
    businessName = "",
    businessAddress = "",
    paymentMode,
    linesOfBusiness = [],
    aggregatedFees = [],
    lobGroupedFees = [],
    paymentSchedule = [],
    grandTotal = 0,
    preparedBy = "",
    preparedDate = "",
    approvedByName,
    approvedByTitle,
    // Settings - values must be configured via platform settings
    municipalityName = "",
    provinceName = "",
    municipalSealUrl = "",
    treasurerName = "",
    treasurerTitle = DEFAULT_TREASURER_TITLE,
  } = data || {};

  // Use treasurer info if approver not specified
  const effectiveApproverName = approvedByName || treasurerName;
  const effectiveApproverTitle = approvedByTitle || treasurerTitle;

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* Header Container with Application No positioned absolutely */}
        <View style={styles.headerContainer}>
          {/* Application No - positioned top right */}
          <View style={styles.applicationNoBox}>
            <Text style={styles.applicationNoLabel}>No. {applicationNumber}</Text>
          </View>

          {/* Centered Header with Logo and Text */}
          <View style={styles.header}>
            <Image style={styles.municipalSeal} src={municipalSealUrl} />
            <View style={styles.headerText}>
              <Text style={styles.headerTitle}>Republic of the Philippines</Text>
              <Text style={styles.headerSubtitle}>Province of {provinceName}</Text>
              <Text style={styles.headerSubtitle}>{municipalityName}</Text>
            </View>
          </View>
        </View>

        {/* Document Title */}
        <Text style={styles.documentTitle}>COMPUTATION/ASSESSMENT SLIP</Text>

        {/* Business Information Section */}
        <View style={styles.infoSection}>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Transaction Type:</Text>
            <Text style={styles.infoValue}>{formatTransactionType(transactionType)}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Owner/Proprietor:</Text>
            <Text style={styles.infoValue}>{ownerName}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Name of Business:</Text>
            <Text style={styles.infoValue}>{businessName}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Address of Business:</Text>
            <Text style={styles.infoValue}>{businessAddress}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Payment Mode:</Text>
            <Text style={styles.infoValue}>{formatPaymentMode(paymentMode)}</Text>
          </View>
        </View>

        {/* Lines of Business */}
        {linesOfBusiness.length > 0 && (
          <View style={styles.lobSection}>
            <Text style={styles.lobTitle}>Line of Business</Text>
            <View style={styles.lobList}>
              {linesOfBusiness.map((lob, index) => (
                <Text key={index} style={styles.lobItem}>
                  {lob}
                </Text>
              ))}
            </View>
          </View>
        )}

        {/* Computations Section - Grouped by Line of Business */}
        <View style={styles.computationsSection}>
          <Text style={styles.computationsTitle}>COMPUTATIONS:</Text>

          {lobGroupedFees.length > 0
            ? // Use LOB-grouped fees (new format)
              lobGroupedFees.map((lob, lobIndex) => (
                <View key={lobIndex} style={styles.feeGroup}>
                  {/* LOB Name Header */}
                  <Text style={styles.feeGroupTitle}>{lob.lobName}</Text>

                  {/* Fees for this LOB */}
                  {lob.fees.map((fee, feeIndex) => (
                    <View key={feeIndex} style={styles.feeBreakdownRow}>
                      <Text style={styles.feeBreakdownLabel}>{fee.feeName}</Text>
                      <Text style={styles.feeBreakdownAmount}>{formatCurrencyForPDF(fee.amount)}</Text>
                    </View>
                  ))}

                  {/* LOB Subtotal */}
                  <View style={styles.subtotalRow}>
                    <Text style={styles.subtotalLabel}>SUBTOTAL</Text>
                    <Text style={styles.subtotalAmount}>Php. {formatCurrencyForPDF(lob.subtotal)}</Text>
                  </View>
                </View>
              ))
            : // Fallback to old format (fee-grouped) for backwards compatibility
              aggregatedFees.map((fee, feeIndex) => (
                <View key={feeIndex} style={styles.feeGroup}>
                  {/* Fee Name Header */}
                  <Text style={styles.feeGroupTitle}>{fee.feeName}</Text>

                  {/* Breakdown by LOB */}
                  {fee.breakdown.map((item, itemIndex) => (
                    <View key={itemIndex} style={styles.feeBreakdownRow}>
                      <Text style={styles.feeBreakdownLabel}>{item.lobName}</Text>
                      <Text style={styles.feeBreakdownAmount}>{formatCurrencyForPDF(item.amount)}</Text>
                    </View>
                  ))}

                  {/* Fee Subtotal */}
                  <View style={styles.subtotalRow}>
                    <Text style={styles.subtotalLabel}>SUBTOTAL</Text>
                    <Text style={styles.subtotalAmount}>Php. {formatCurrencyForPDF(fee.totalAmount)}</Text>
                  </View>
                </View>
              ))}
        </View>

        {/* Grand Total */}
        <View style={styles.grandTotalSection}>
          <View style={styles.grandTotalRow}>
            <Text style={styles.grandTotalLabel}>GRAND TOTAL</Text>
            <Text style={styles.grandTotalAmount}>Php. {formatCurrencyForPDF(grandTotal)}</Text>
          </View>
          {/* IN WORDS */}
          <View style={styles.inWordsSection}>
            <Text style={styles.inWordsLabel}>IN WORDS:</Text>
            <Text style={styles.inWordsValue}>{numberToWords(grandTotal)}</Text>
          </View>
        </View>

        {/* Schedule of Payments Section */}
        {paymentSchedule.length > 0 && (
          <View style={styles.scheduleSection}>
            <Text style={styles.scheduleSectionTitle}>SCHEDULE OF PAYMENTS</Text>
            <Text style={styles.scheduleModeLabel}>Mode of Payment: {formatPaymentMode(paymentMode)}</Text>

            {/* Schedule Table */}
            <View style={styles.scheduleTable}>
              {/* Table Header */}
              <View style={styles.scheduleTableHeader}>
                <Text style={[styles.scheduleColSection, styles.scheduleHeaderText]}>Section</Text>
                <Text style={[styles.scheduleColDueDate, styles.scheduleHeaderText]}>Due Date</Text>
                <Text style={[styles.scheduleColAmount, styles.scheduleHeaderText]}>Amount</Text>
                <Text style={[styles.scheduleColBalance, styles.scheduleHeaderText]}>Balance</Text>
              </View>

              {/* Table Rows */}
              {paymentSchedule.map((section, index) => (
                <View key={index} style={styles.scheduleTableRow}>
                  <Text style={styles.scheduleColSection}>{section.sectionLabel}</Text>
                  <Text style={styles.scheduleColDueDate}>{formatDate(section.dueDate, "short")}</Text>
                  <Text style={styles.scheduleColAmount}>{formatCurrencyForPDF(section.totalAmount)}</Text>
                  <Text style={styles.scheduleColBalance}>{formatCurrencyForPDF(section.balance)}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Footer Section - Prepared By, Approved By, Acknowledge By */}
        <View style={styles.footerSection}>
          {/* Prepared By */}
          <View style={styles.preparedBySection}>
            <Text style={styles.preparedByLabel}>Prepared By :</Text>
            <Text style={styles.preparedByValue}>{preparedBy || "______________________"}</Text>
            <Text style={styles.preparedByDate}>{preparedDate || new Date().toISOString().split("T")[0]}</Text>
          </View>

          {/* Approved By */}
          <View style={styles.approvalSection}>
            <View style={styles.approvalColumn}>
              <Text style={styles.approvalLabel}>Approved by:</Text>
              <View style={styles.signatureLine} />
              <Text style={styles.signatureName}>{effectiveApproverName}</Text>
              <Text style={styles.signatureTitle}>{effectiveApproverTitle}</Text>
            </View>
          </View>

          {/* Acknowledge By */}
          <View style={styles.acknowledgeSection}>
            <View style={styles.acknowledgeRow}>
              <View style={styles.acknowledgeColumn}>
                <Text style={styles.acknowledgeLabel}>Acknowledge by:</Text>
                <View style={styles.acknowledgeLine} />
                <Text style={styles.acknowledgeHint}>Signature over printed name</Text>
                <Text style={styles.dateLabel}>Date:</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Page Number */}
        <Text
          style={styles.pageNumber}
          render={({ pageNumber, totalPages }) => `Page ${pageNumber}/${totalPages}`}
          fixed
        />
      </Page>
    </Document>
  );
};
