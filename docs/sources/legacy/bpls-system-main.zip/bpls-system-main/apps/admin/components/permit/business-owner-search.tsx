"use client";

import { useState, useRef, useEffect, useMemo } from "react";
import { ArrowLeft, Search, Ban, Loader2 } from "lucide-react";
import { usePaginatedQuery } from "convex/react";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Avatar, AvatarFallback, AvatarImage } from "@repo/ui/components/avatar";
import { Badge } from "@repo/ui/components/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@repo/ui/components/tooltip";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select";

import { api } from "@repo/backend/convex/_generated/api";
import type { Doc } from "@repo/backend/convex/_generated/dataModel";
import type { BusinessOwner } from "@/lib/types/business-owners";
import { getInitials } from "@/lib/utils/formatting";
import { useDebouncedValue } from "@/hooks/use-debounced-value";

const PAGE_SIZE = 25;

interface BusinessOwnerSearchProps {
  selectedOwnerId?: string;
  onOwnerSelect: (owner: BusinessOwner) => void;
  onBack: () => void;
}

/**
 * Transform Convex business owner data to match the UI interface
 */
function transformBusinessOwner(convexOwner: Doc<"business_owners">): BusinessOwner {
  return {
    id: convexOwner._id,
    firstName: convexOwner.firstName,
    middleName: convexOwner.middleName,
    lastName: convexOwner.lastName,
    birthDate: convexOwner.birthDate,
    civilStatus: convexOwner.civilStatus,
    gender: convexOwner.gender,
    citizenship: convexOwner.citizenship,
    tin: convexOwner.tin,
    mobile: convexOwner.mobile,
    email: convexOwner.email,
    address: convexOwner.address,
    provinceId: convexOwner.provinceId ?? "",
    cityId: convexOwner.cityId ?? "",
    barangayId: convexOwner.barangayId ?? "",
    avatar: convexOwner.avatar,
    ownerType: convexOwner.ownerType ?? "Single",
    groupName: convexOwner.groupName,
    isBlacklisted: convexOwner.isBlacklisted ?? false,
    blacklistReason: convexOwner.blacklistReason,
    blacklistedAt: convexOwner.blacklistedAt,
    blacklistedBy: convexOwner.blacklistedBy,
  };
}

export function BusinessOwnerSearch({ selectedOwnerId, onOwnerSelect, onBack }: BusinessOwnerSearchProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [ownerTypeFilter, setOwnerTypeFilter] = useState<"all" | "Single" | "Group">("all");
  const debouncedSearch = useDebouncedValue(searchTerm, 300);

  const scrollRef = useRef<HTMLDivElement>(null);
  const sentinelRef = useRef<HTMLDivElement>(null);

  const trimmedSearch = debouncedSearch.trim();
  const searchArg = trimmedSearch.length >= 2 ? trimmedSearch : undefined;
  const ownerTypeArg = ownerTypeFilter === "all" ? undefined : ownerTypeFilter;

  // Server-side pagination + search (infinite scroll). usePaginatedQuery automatically
  // resets to page 1 whenever the args (search term / owner-type) change.
  const { results, status, loadMore } = usePaginatedQuery(
    api.businessOwners.listPaginated,
    { includeBlacklisted: true, search: searchArg, ownerType: ownerTypeArg },
    { initialNumItems: PAGE_SIZE }
  );

  const owners = useMemo(() => results.map(transformBusinessOwner), [results]);

  // Infinite scroll: load the next page when the sentinel scrolls into view.
  useEffect(() => {
    const rootEl = scrollRef.current;
    const target = sentinelRef.current;
    if (!rootEl || !target) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting && status === "CanLoadMore") {
          loadMore(PAGE_SIZE);
        }
      },
      { root: rootEl, rootMargin: "200px" }
    );
    observer.observe(target);
    return () => observer.disconnect();
  }, [status, loadMore]);

  const isInitialLoading = status === "LoadingFirstPage";
  const isEmpty = !isInitialLoading && owners.length === 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="outline" size="sm" className="cursor-pointer bg-transparent" onClick={onBack}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Back to Options</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <h3 className="text-lg font-semibold">Select Existing Business Owner</h3>
      </div>

      {/* Owner Type Filter */}
      <div>
        <Label>Filter by Owner Type</Label>
        <Select value={ownerTypeFilter} onValueChange={(value: "all" | "Single" | "Group") => setOwnerTypeFilter(value)}>
          <SelectTrigger className="mt-2">
            <SelectValue placeholder="All Owners" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Owners</SelectItem>
            <SelectItem value="Single">Single Owner</SelectItem>
            <SelectItem value="Group">Group Owner</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Search Input (server-side) */}
      <div>
        <Label>Search Business Owner</Label>
        <div className="relative mt-2">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by name, email, or TIN..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8"
          />
        </div>
      </div>

      <div ref={scrollRef} className="space-y-2 max-h-[600px] overflow-y-auto">
        {isInitialLoading && (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        )}

        {isEmpty && (
          <div className="text-center py-12 text-muted-foreground">
            {searchArg ? "No business owners found matching your search." : "No business owners found."}
          </div>
        )}

        {owners.map((owner) => {
          const isBlacklisted = owner.isBlacklisted;

          return (
            <TooltipProvider key={owner.id}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div
                    className={`p-4 border rounded-lg transition-colors ${
                      isBlacklisted
                        ? "opacity-60 cursor-not-allowed border-destructive/50"
                        : `cursor-pointer hover:bg-muted ${
                            selectedOwnerId === owner.id ? "border-primary bg-primary/5" : "border-border"
                          }`
                    }`}
                    onClick={() => {
                      if (!isBlacklisted) {
                        onOwnerSelect(owner);
                      }
                    }}
                  >
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={owner.avatar || "/placeholder.svg"} alt={`${owner.firstName} ${owner.lastName}`} />
                        <AvatarFallback>{getInitials(owner.firstName, owner.lastName)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <div className="font-medium">{`${owner.firstName} ${owner.lastName}`}</div>
                          {isBlacklisted && (
                            <Badge variant="destructive" className="gap-1 text-xs shrink-0">
                              <Ban className="h-3 w-3" />
                              Blacklisted
                            </Badge>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground">{owner.email}</div>
                        <div className="text-sm text-muted-foreground">{owner.mobile}</div>
                      </div>
                    </div>
                  </div>
                </TooltipTrigger>
                {isBlacklisted && (
                  <TooltipContent side="right" className="max-w-xs">
                    <div className="space-y-1">
                      <p className="font-semibold">Cannot select blacklisted business owner</p>
                      <p className="text-xs">{owner.blacklistReason}</p>
                    </div>
                  </TooltipContent>
                )}
              </Tooltip>
            </TooltipProvider>
          );
        })}

        {/* Infinite-scroll sentinel + load-more indicator */}
        <div ref={sentinelRef} className="h-px" />
        {status === "LoadingMore" && (
          <div className="flex items-center justify-center py-4">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        )}
        {status === "Exhausted" && owners.length > 0 && (
          <p className="text-center text-xs text-muted-foreground py-3">
            {owners.length} owner{owners.length === 1 ? "" : "s"} shown
          </p>
        )}
      </div>
    </div>
  );
}
