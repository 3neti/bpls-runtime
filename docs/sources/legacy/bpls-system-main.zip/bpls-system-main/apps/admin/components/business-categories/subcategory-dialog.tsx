"use client";

import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@repo/ui/components/form";
import { Input } from "@repo/ui/components/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select";
import { Button } from "@repo/ui/components/button";
import { toast } from "sonner";
import type { Id } from "@repo/backend/convex/_generated/dataModel";

const subCategorySchema = z.object({
  name: z.string().min(1, "Sub-category name is required"),
  categoryId: z.string().min(1, "Category is required"),
  description: z.string().optional(),
  code: z.string().optional(),
});

type SubCategoryFormValues = z.infer<typeof subCategorySchema>;

interface SubCategory {
  _id: string;
  name: string;
  categoryId: string;
  description?: string;
  code?: string;
}

interface SubCategoryDialogProps {
  mode: "create" | "edit";
  subCategory?: SubCategory;
  categoryId?: string;
  categoryName?: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export function SubCategoryDialog({
  mode,
  subCategory,
  categoryId,
  categoryName,
  open,
  onOpenChange,
  onSuccess,
}: SubCategoryDialogProps) {
  const categories = useQuery(api.businessCategories.listCategories);
  const createSubCategory = useMutation(api.businessCategories.createSubCategory);
  const updateSubCategory = useMutation(api.businessCategories.updateSubCategory);

  const form = useForm<SubCategoryFormValues>({
    resolver: zodResolver(subCategorySchema),
    defaultValues: {
      name: "",
      categoryId: "",
      description: "",
      code: "",
    },
  });

  // Reset form values when dialog opens or props change
  useEffect(() => {
    if (open) {
      form.reset({
        name: subCategory?.name || "",
        categoryId: categoryId || (subCategory?.categoryId as string) || "",
        description: subCategory?.description || "",
        code: subCategory?.code || "",
      });
    }
  }, [open, subCategory, categoryId, form]);

  // Determine if we're adding a child (category is pre-selected)
  const isAddingChild = mode === "create" && categoryId && categoryName;

  const onSubmit = async (values: SubCategoryFormValues) => {
    try {
      if (mode === "create") {
        await createSubCategory({
          name: values.name,
          categoryId: values.categoryId as Id<"business_categories">,
          description: values.description || undefined,
          code: values.code || undefined,
        });
        toast.success("Sub-category created successfully");
      } else {
        if (!subCategory?._id) {
          toast.error("Sub-category ID is missing");
          return;
        }
        await updateSubCategory({
          id: subCategory._id as Id<"business_subcategories">,
          name: values.name,
          categoryId: values.categoryId as Id<"business_categories">,
          description: values.description || undefined,
          code: values.code || undefined,
        });
        toast.success("Sub-category updated successfully");
      }
      form.reset();
      onOpenChange(false);
      onSuccess?.();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "An error occurred";
      toast.error(
        mode === "create"
          ? `Failed to create sub-category: ${errorMessage}`
          : `Failed to update sub-category: ${errorMessage}`
      );
      console.error(error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{mode === "create" ? "Add Sub-Category" : "Edit Sub-Category"}</DialogTitle>
          <DialogDescription>
            {mode === "create"
              ? "Add a new sub-category to the business classification hierarchy."
              : "Update sub-category information."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="categoryId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    Category <span className="text-destructive">*</span>
                  </FormLabel>
                  {isAddingChild ? (
                    <FormControl>
                      <Input
                        value={categoryName}
                        disabled
                        className="bg-muted text-muted-foreground cursor-not-allowed"
                      />
                    </FormControl>
                  ) : (
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categories?.map((cat: NonNullable<typeof categories>[number]) => (
                          <SelectItem key={cat._id} value={cat._id}>
                            {cat.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    Sub-Category Name <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="e.g., Pawnshop"
                      autoFocus={Boolean(isAddingChild)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Brief description of this sub-category" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="code"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Code</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g., RT-001-A" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting
                  ? mode === "create"
                    ? "Creating..."
                    : "Updating..."
                  : mode === "create"
                    ? "Create Sub-Category"
                    : "Update Sub-Category"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
