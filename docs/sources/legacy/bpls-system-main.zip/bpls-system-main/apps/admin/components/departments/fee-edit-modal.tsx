/**
 * Fee Edit Modal Component
 *
 * Modal dialog for editing department fee configurations.
 * Allows staff to modify fee name, description, default amount, and active status.
 */

"use client"

import { useEffect } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form"
import { Input } from "@repo/ui/components/input"
import { Textarea } from "@repo/ui/components/textarea"
import { Button } from "@repo/ui/components/button"
import { Switch } from "@repo/ui/components/switch"
import { useToast } from "@/hooks/use-toast"
import { formatCurrency } from "@/lib/utils/formatting"
import type { DepartmentFee } from "@/lib/types/fees"

/**
 * Zod validation schema for fee editing
 */
const feeEditSchema = z.object({
  name: z
    .string()
    .min(3, "Name must be at least 3 characters")
    .max(100, "Name cannot exceed 100 characters"),
  description: z
    .string()
    .max(500, "Description cannot exceed 500 characters")
    .default(""),
  defaultAmount: z.coerce
    .number({
      message: "Amount must be a valid number",
    })
    .min(0, "Amount must be positive")
    .max(1000000, "Amount cannot exceed ₱1,000,000"),
  isActive: z.boolean().default(true),
})

type FeeEditSchema = z.infer<typeof feeEditSchema>

export interface FeeEditModalProps {
  /** Fee to edit (null when modal is closed) */
  fee: DepartmentFee | null
  /** Whether modal is open */
  open: boolean
  /** Callback to close modal */
  onClose: () => void
  /** Callback when fee is saved */
  onSave: (updatedFee: DepartmentFee) => void
}


export function FeeEditModal({ fee, open, onClose, onSave }: FeeEditModalProps) {
  const { toast } = useToast()

  const form = useForm<FeeEditSchema>({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    resolver: zodResolver(feeEditSchema) as any,
    mode: "onChange",
    defaultValues: {
      name: "",
      description: "",
      defaultAmount: 0,
      isActive: true,
    },
  })

  // Reset form when fee changes
  useEffect(() => {
    if (fee) {
      form.reset({
        name: fee.name,
        description: fee.description || "",
        defaultAmount: fee.defaultAmount,
        isActive: fee.isActive ?? true,
      })
    }
  }, [fee, form])

  const handleSubmit = (values: FeeEditSchema) => {
    if (!fee) return

    try {
      const updatedFee: DepartmentFee = {
        ...fee,
        name: values.name,
        description: values.description,
        defaultAmount: values.defaultAmount,
        isActive: values.isActive,
        updatedAt: new Date().toISOString(),
      }

      onSave(updatedFee)

      toast({
        title: "Fee updated successfully",
        description: `${updatedFee.name} has been updated.`,
        variant: "default",
      })

      onClose()
    } catch (error) {
      toast({
        title: "Failed to update fee",
        description: error instanceof Error ? error.message : "An unexpected error occurred",
        variant: "destructive",
      })
    }
  }

  const handleCancel = () => {
    form.reset()
    onClose()
  }

  // Handle ESC key to close modal
  const handleOpenChange = (isOpen: boolean) => {
    if (!isOpen) {
      handleCancel()
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[500px]" aria-describedby="fee-edit-description">
        <DialogHeader>
          <DialogTitle>Edit Fee</DialogTitle>
          <DialogDescription id="fee-edit-description">
            Update fee details and configuration. Changes will be reflected in the fee library.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            {/* Fee Name */}
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Fee Name</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter fee name"
                      maxLength={100}
                      autoFocus
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    {field.value.length} / 100 characters
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Description */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Brief description of this fee"
                      className="min-h-[80px] resize-none"
                      maxLength={500}
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    {field.value?.length || 0} / 500 characters
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Default Amount */}
            <FormField
              control={form.control}
              name="defaultAmount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Default Amount</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">
                        ₱
                      </span>
                      <Input
                        type="number"
                        placeholder="0.00"
                        className="pl-7"
                        step="0.01"
                        min="0"
                        max="1000000"
                        {...field}
                      />
                    </div>
                  </FormControl>
                  <FormDescription>
                    {field.value ? formatCurrency(Number(field.value), { withSymbol: true }) : "Enter the default fee amount"}
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Active Status */}
            <FormField
              control={form.control}
              name="isActive"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                  <div className="space-y-0.5">
                    <FormLabel>Active Status</FormLabel>
                    <FormDescription className="text-xs">
                      {field.value
                        ? "Fee is active and available for selection"
                        : "Fee is inactive and hidden from selection"}
                    </FormDescription>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      aria-label="Toggle fee active status"
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            {/* Action Buttons */}
            <DialogFooter className="gap-2 sm:gap-0">
              <Button
                type="button"
                variant="outline"
                onClick={handleCancel}
                disabled={form.formState.isSubmitting}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={form.formState.isSubmitting || !form.formState.isValid}
              >
                {form.formState.isSubmitting ? "Saving..." : "Save Changes"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
