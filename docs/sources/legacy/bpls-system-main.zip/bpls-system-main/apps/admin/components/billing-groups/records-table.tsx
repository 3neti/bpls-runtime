"use client"

import { useState, useCallback, useMemo, useEffect, useRef } from "react"
import { useMutation, useQuery, useConvex } from "convex/react"
import {
  MoreHorizontal,
  Pencil,
  Trash2,
  CheckCircle,
  XCircle,
  Clock,
  FileText,
  Printer,
  Plus,
  Download,
  Search,
  ChevronDown,
  Loader2,
} from "lucide-react"

import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"
import { Input } from "@repo/ui/components/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { Textarea } from "@repo/ui/components/textarea"
import { Progress } from "@repo/ui/components/progress"
import { Label } from "@repo/ui/components/label"
import { useToast } from "@/hooks/use-toast"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { formatCurrency } from "@/lib/utils"
import { ReceiptPreviewModal } from "./receipt-preview-modal"
import { TransactionViewModal } from "./transaction-view-modal"
import {
  downloadCSV,
  generateExportFilename,
} from "@/lib/utils/csv-export"
import {
  TableFilterPopover,
  type FilterConfig,
  type FilterState,
  type CustomFilterField,
} from "@/components/permits/table-filter-popover"
import { useColumnVisibilityStore } from "@/lib/stores/column-visibility-store"
import { PermissionGuard } from "@/components/permission-guard"
import { useDebouncedValue } from "@/hooks/use-debounced-value"

// Status options for records table
const STATUS_OPTIONS = [
  { value: "pending", label: "Pending" },
  { value: "completed", label: "Completed" },
  { value: "cancelled", label: "Cancelled" },
]

// Column definitions for visibility toggle
const COLUMN_DEFINITIONS = [
  { id: "transactionNumber", label: "Transaction #" },
  { id: "date", label: "Date" },
  { id: "description", label: "Remarks" },
  { id: "amount", label: "Amount" },
  { id: "paymentMethod", label: "Payment Method" },
  { id: "referenceNumber", label: "Reference" },
  { id: "status", label: "Status" },
]

type FieldType = "text" | "number" | "currency" | "date" | "dropdown" | "checkbox"

interface Field {
  _id: Id<"billing_group_fields">
  name: string
  fieldType: FieldType
  isRequired: boolean
  isUnique?: boolean
  sortOrder: number
  options?: string[]
  placeholder?: string
  defaultValue?: string
}

interface FieldValue {
  fieldId: Id<"billing_group_fields">
  value: string
}

interface Record {
  _id: Id<"billing_group_records">
  transactionNumber: string
  amount: number
  status: "pending" | "completed" | "cancelled"
  fieldValues?: FieldValue[]
  totalAmount?: number
  lineItemCount?: number
  createdAt: string
  updatedAt: string
  // System columns
  description?: string
  date?: string
  paymentMethod?: "Cash" | "Credit Card" | "Bank Transfer" | "GCash" | "PayMaya" | "Check"
  referenceNumber?: string
}

// Page size constant
const PAGE_SIZE = 10

interface RecordsTableProps {
  fields: Field[]
  descriptionFieldId?: Id<"billing_group_fields">
  billingGroupId: Id<"billing_groups">
  billingGroupName?: string
  onEdit: (recordId: Id<"billing_group_records">) => void
  onAddTransaction?: () => void
  canAddTransaction?: boolean
  canEdit?: boolean
  canUpdateAfterPayment?: boolean
  canDelete?: boolean
  filters: FilterState
  onFiltersChange: (filters: FilterState) => void
}

const statusConfig = {
  pending: {
    label: "Pending",
    icon: Clock,
    variant: "outline" as const,
    className: "text-yellow-600 border-yellow-300",
  },
  completed: {
    label: "Completed",
    icon: CheckCircle,
    variant: "outline" as const,
    className: "text-green-600 border-green-300",
  },
  cancelled: {
    label: "Cancelled",
    icon: XCircle,
    variant: "outline" as const,
    className: "text-red-600 border-red-300",
  },
}

// Helper to format custom field values based on field type
const formatFieldValue = (value: string | undefined, fieldType: FieldType): React.ReactNode => {
  if (!value) return "—"
  switch (fieldType) {
    case "currency":
      return formatCurrency(parseFloat(value) || 0)
    case "date":
      return new Date(value).toLocaleDateString()
    case "checkbox":
      return value === "true" ? "Yes" : "No"
    case "number":
      return value
    default:
      return value
  }
}

// Extended column definition type for custom fields
interface CustomColumnDefinition {
  id: string
  label: string
  fieldId?: Id<"billing_group_fields">
  fieldType?: FieldType
}

export function RecordsTable({
  fields,
  descriptionFieldId,
  billingGroupId,
  billingGroupName,
  onEdit,
  onAddTransaction,
  canAddTransaction = true,
  canEdit = true,
  canUpdateAfterPayment = false,
  canDelete = true,
  filters,
  onFiltersChange,
}: RecordsTableProps) {
  const { toast } = useToast()
  const [deletingRecordId, setDeletingRecordId] = useState<Id<"billing_group_records"> | null>(null)
  const [updatingStatusId, setUpdatingStatusId] = useState<Id<"billing_group_records"> | null>(null)
  const [newStatus, setNewStatus] = useState<"pending" | "completed" | "cancelled" | null>(null)
  const [printingRecordId, setPrintingRecordId] = useState<Id<"billing_group_records"> | null>(null)
  const [cancellingRecordId, setCancellingRecordId] = useState<Id<"billing_group_records"> | null>(null)
  const [cancellationReason, setCancellationReason] = useState("")
  const [cancellationError, setCancellationError] = useState("")
  const [viewingRecordId, setViewingRecordId] = useState<Id<"billing_group_records"> | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const debouncedSearch = useDebouncedValue(searchTerm, 300)

  // Export state
  const convex = useConvex()
  const [exportProgress, setExportProgress] = useState<{
    isExporting: boolean
    current: number
    total: number
  } | null>(null)
  const exportCancelRef = useRef(false)

  // Pagination state - track current page and cursors for each page
  const [currentPage, setCurrentPage] = useState(0)
  const [pageCursors, setPageCursors] = useState<(string | null)[]>([null]) // null for first page

  // Determine if we're in search mode
  const isSearchMode = debouncedSearch.length >= 2

  // Get status filter for server-side filtering (only if single status selected)
  const statusFilter = filters.statuses.length === 1
    ? filters.statuses[0] as "pending" | "completed" | "cancelled"
    : undefined

  // Date filters for server-side filtering
  const dateFrom = filters.dateRange.from?.toISOString().split('T')[0]
  const dateTo = filters.dateRange.to?.toISOString().split('T')[0]

  // Server-side paginated list query (uses regular useQuery with cursor)
  const paginatedList = useQuery(
    api.billingGroupRecords.listByGroupPaginated,
    !isSearchMode
      ? {
          billingGroupId,
          paginationOpts: {
            numItems: PAGE_SIZE,
            cursor: pageCursors[currentPage],
          },
          status: statusFilter,
          dateFrom,
          dateTo,
        }
      : "skip"
  )

  // Server-side search query with pagination
  const searchResults = useQuery(
    api.billingGroupRecords.searchByGroupPaginated,
    isSearchMode
      ? {
          billingGroupId,
          query: debouncedSearch,
          status: statusFilter,
          cursor: pageCursors[currentPage] ? Number(pageCursors[currentPage]) : undefined,
          pageSize: PAGE_SIZE,
        }
      : "skip"
  )

  // Get total count for pagination UI
  const totalCount = useQuery(
    api.billingGroupRecords.getRecordCount,
    {
      billingGroupId,
      status: statusFilter,
      dateFrom,
      dateTo,
      searchQuery: isSearchMode ? debouncedSearch : undefined,
    }
  )

  // Reset pagination when search term or filters change
  useEffect(() => {
    setCurrentPage(0)
    setPageCursors([null])
  }, [debouncedSearch, filters])

  // Determine loading states
  const isLoading = isSearchMode
    ? searchResults === undefined
    : paginatedList === undefined

  // Get current page data (only the current page, not accumulated)
  const records = useMemo(() => {
    if (isSearchMode) {
      return (searchResults?.page || []) as Record[]
    }
    return (paginatedList?.page || []) as Record[]
  }, [isSearchMode, searchResults, paginatedList])

  // Pagination controls - check if we can go to next/prev page
  const canGoNext = isSearchMode
    ? searchResults?.hasMore ?? false
    : paginatedList ? !paginatedList.isDone : false

  const canGoPrev = currentPage > 0

  const handleNextPage = () => {
    if (!canGoNext) return

    // Get the cursor for the next page
    const nextCursor = isSearchMode
      ? searchResults?.nextCursor?.toString()
      : paginatedList?.continueCursor

    if (nextCursor) {
      // Store cursor for next page
      setPageCursors(prev => {
        const newCursors = [...prev]
        newCursors[currentPage + 1] = nextCursor
        return newCursors
      })
      setCurrentPage(prev => prev + 1)
    }
  }

  const handlePrevPage = () => {
    if (!canGoPrev) return
    setCurrentPage(prev => prev - 1)
  }

  // Calculate total pages
  const totalPages = totalCount !== undefined
    ? Math.ceil(totalCount / PAGE_SIZE)
    : undefined

  // Use Zustand store for column visibility
  const { recordsColumns, setRecordsColumns } = useColumnVisibilityStore()

  // Build dynamic filter config with custom text/number fields
  const filterConfig = useMemo<FilterConfig>(() => {
    const systemFieldNames = ["description", "date", "paymentmethod", "referencenumber"]
    const customFilterFields: CustomFilterField[] = [
      { key: "transactionNumber", label: "Transaction #", type: "text", placeholder: "Search transaction #..." },
      { key: "payorName", label: "Payor Name", type: "text", placeholder: "Search payor name..." },
    ]
    // Add custom text/number/currency fields from billing group definition
    for (const field of fields) {
      if (systemFieldNames.includes(field.name.toLowerCase().replace(/\s+/g, ""))) continue
      if (field.fieldType === "text") {
        customFilterFields.push({
          key: `custom_${field._id}`,
          label: field.name,
          type: "text",
          placeholder: `Search ${field.name.toLowerCase()}...`,
        })
      } else if (field.fieldType === "number" || field.fieldType === "currency") {
        customFilterFields.push({
          key: `custom_${field._id}`,
          label: field.name,
          type: "number",
        })
      }
    }
    return {
      statusOptions: STATUS_OPTIONS,
      showDateRange: true,
      showTypeFilter: false,
      customFilterFields,
    }
  }, [fields])

  // Combine static columns with dynamic custom field columns
  const allColumnDefinitions = useMemo<CustomColumnDefinition[]>(() => {
    // Filter out system fields that are already handled by static columns
    const systemFieldNames = ["description", "date", "paymentmethod", "referencenumber"]
    const customFieldColumns = fields
      .filter(f => !systemFieldNames.includes(f.name.toLowerCase().replace(/\s+/g, "")))
      .sort((a, b) => a.sortOrder - b.sortOrder)
      .map(field => ({
        id: `custom_${field._id}`,
        label: field.name,
        fieldId: field._id,
        fieldType: field.fieldType,
      }))

    return [...COLUMN_DEFINITIONS, ...customFieldColumns]
  }, [fields])

  // Get custom field columns only (for rendering)
  const customFieldColumns = useMemo(() => {
    return allColumnDefinitions.filter(col => col.id.startsWith("custom_"))
  }, [allColumnDefinitions])

  const deleteRecord = useMutation(api.billingGroupRecords.softDelete)
  const updateStatus = useMutation(api.billingGroupRecords.updateStatus)

  // Apply client-side filtering for multi-status, text, and numeric filters
  // Date range and single status are handled server-side
  const filteredRecords = useMemo(() => {
    let result = [...records]

    // Multi-status filter (client-side when more than one status selected)
    if (filters.statuses.length > 1) {
      result = result.filter((record) => filters.statuses.includes(record.status))
    }

    // Text filters (case-insensitive contains)
    if (filters.textFilters) {
      for (const [key, searchValue] of Object.entries(filters.textFilters)) {
        if (!searchValue || searchValue.trim() === "") continue
        const lowerSearch = searchValue.toLowerCase()
        result = result.filter((record) => {
          // System fields
          if (key === "transactionNumber") {
            return record.transactionNumber?.toLowerCase().includes(lowerSearch)
          }
          if (key === "payorName") {
            return ((record as any).payorName || "").toLowerCase().includes(lowerSearch)
          }
          // Custom fields (key format: custom_{fieldId})
          if (key.startsWith("custom_")) {
            const fieldId = key.replace("custom_", "")
            const fv = record.fieldValues?.find((f) => f.fieldId === fieldId)
            return (fv?.value || "").toLowerCase().includes(lowerSearch)
          }
          return true
        })
      }
    }

    // Numeric filters (operator-based comparison)
    if (filters.numericFilters) {
      for (const [key, filter] of Object.entries(filters.numericFilters)) {
        if (filter.value === null && filter.operator !== "between") continue
        if (filter.operator === "between" && (filter.value === null || filter.valueTo === null)) continue
        result = result.filter((record) => {
          let rawValue: number | undefined
          // Custom fields (key format: custom_{fieldId})
          if (key.startsWith("custom_")) {
            const fieldId = key.replace("custom_", "")
            const fv = record.fieldValues?.find((f) => f.fieldId === fieldId)
            rawValue = fv?.value ? parseFloat(fv.value) : undefined
          }
          if (rawValue === undefined || isNaN(rawValue)) return false
          const filterVal = filter.value!
          switch (filter.operator) {
            case "equals": return rawValue === filterVal
            case "gt": return rawValue > filterVal
            case "gte": return rawValue >= filterVal
            case "lt": return rawValue < filterVal
            case "lte": return rawValue <= filterVal
            case "between": return rawValue >= filterVal && rawValue <= (filter.valueTo ?? filterVal)
            default: return true
          }
        })
      }
    }

    return result
  }, [records, filters.statuses, filters.textFilters, filters.numericFilters])

  // Column visibility helpers
  const isColumnVisible = (columnId: string) => {
    return recordsColumns[columnId] !== false
  }

  const toggleColumn = (columnId: string) => {
    setRecordsColumns((prev) => ({
      ...prev,
      [columnId]: !prev[columnId],
    }))
  }

  const handleDelete = async () => {
    if (!deletingRecordId) return

    try {
      await deleteRecord({ id: deletingRecordId })
      toast({
        title: "Record deleted",
        description: "The record has been removed.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete record",
        variant: "destructive",
      })
    } finally {
      setDeletingRecordId(null)
    }
  }

  const handleStatusUpdate = async () => {
    if (!updatingStatusId || !newStatus) return

    try {
      await updateStatus({ id: updatingStatusId, status: newStatus })
      toast({
        title: "Status updated",
        description: `Record status changed to ${newStatus}.`,
      })

      // Auto-open receipt preview when payment is marked as completed
      if (newStatus === "completed") {
        setPrintingRecordId(updatingStatusId)
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update status",
        variant: "destructive",
      })
    } finally {
      setUpdatingStatusId(null)
      setNewStatus(null)
    }
  }

  const openStatusDialog = (recordId: Id<"billing_group_records">, status: "pending" | "completed" | "cancelled") => {
    setUpdatingStatusId(recordId)
    setNewStatus(status)
  }

  const openCancellationDialog = (recordId: Id<"billing_group_records">) => {
    setCancellingRecordId(recordId)
    setCancellationReason("")
    setCancellationError("")
  }

  const handleCancellation = async () => {
    if (!cancellingRecordId) return

    if (!cancellationReason.trim()) {
      setCancellationError("Please provide a reason for cancellation")
      return
    }

    try {
      await updateStatus({
        id: cancellingRecordId,
        status: "cancelled",
        cancellationReason: cancellationReason.trim(),
      })
      toast({
        title: "Record cancelled",
        description: "The record has been cancelled with the provided reason.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to cancel record",
        variant: "destructive",
      })
    } finally {
      setCancellingRecordId(null)
      setCancellationReason("")
      setCancellationError("")
    }
  }

  // Calculate visible column count for proper colspan during loading
  const visibleColumnCount = useMemo(() => {
    let count = 0
    COLUMN_DEFINITIONS.forEach(col => {
      if (isColumnVisible(col.id)) count++
    })
    customFieldColumns.forEach(col => {
      if (isColumnVisible(col.id)) count++
    })
    return count
  }, [recordsColumns, customFieldColumns])

  // Export handler - fetches ALL records with flattened line items (CSV built server-side)
  const handleExport = useCallback(async () => {
    exportCancelRef.current = false
    setExportProgress({ isExporting: true, current: 0, total: 0 })

    try {
      // Build text filters for server-side filtering
      const activeTextFilters: globalThis.Record<string, string> = {}
      if (filters.textFilters) {
        for (const [key, val] of Object.entries(filters.textFilters)) {
          if (val && val.trim() !== "") activeTextFilters[key] = val.trim()
        }
      }
      // Build numeric filters for server-side filtering
      const activeNumericFilters: globalThis.Record<string, { operator: string; value: number; valueTo?: number }> = {}
      if (filters.numericFilters) {
        for (const [key, val] of Object.entries(filters.numericFilters)) {
          if (val.value === null) continue
          // Skip incomplete "between" filters
          if (val.operator === "between" && (val.valueTo === null || val.valueTo === undefined)) continue
          activeNumericFilters[key] = {
            operator: val.operator,
            value: val.value,
            ...(val.valueTo !== null && val.valueTo !== undefined ? { valueTo: val.valueTo } : {}),
          }
        }
      }

      const result: any = await convex.action(
        api.billingGroupRecords.exportRecordsWithLineItems,
        {
          billingGroupId,
          status: statusFilter,
          statuses: filters.statuses.length > 1 ? filters.statuses : undefined,
          dateFrom,
          dateTo,
          textFilters: Object.keys(activeTextFilters).length > 0 ? activeTextFilters : undefined,
          numericFilters: Object.keys(activeNumericFilters).length > 0 ? activeNumericFilters : undefined,
        }
      )

      if (exportCancelRef.current) return

      setExportProgress({
        isExporting: true,
        current: result.totalCount,
        total: result.totalCount,
      })

      // CSV is built server-side, download directly
      const filename = generateExportFilename(
        billingGroupName
          ? `${billingGroupName.toLowerCase().replace(/\s+/g, "-")}-records`
          : "billing-group-records"
      )
      downloadCSV(result.csv, filename)

      toast({
        title: "Export complete",
        description: `Exported ${result.totalCount} rows to CSV.`,
      })
    } catch (error) {
      if (!exportCancelRef.current) {
        toast({
          title: "Export failed",
          description: error instanceof Error ? error.message : "Failed to export records",
          variant: "destructive",
        })
      }
    } finally {
      setExportProgress(null)
    }
  }, [convex, billingGroupId, statusFilter, dateFrom, dateTo, billingGroupName, toast, filters.statuses, filters.textFilters, filters.numericFilters])

  const handleCancelExport = useCallback(() => {
    exportCancelRef.current = true
    setExportProgress(null)
    toast({
      title: "Export cancelled",
      description: "The export has been cancelled.",
    })
  }, [toast])

  // Show empty state only when no records exist, not searching, and no filters active
  const hasActiveTextFilters = filters.textFilters ? Object.values(filters.textFilters).some(v => v.trim() !== "") : false
  const hasActiveNumericFilters = filters.numericFilters ? Object.values(filters.numericFilters).some(v => v.value !== null) : false
  const hasActiveFilters = filters.statuses.length > 0 || !!filters.dateRange.from || !!filters.dateRange.to || hasActiveTextFilters || hasActiveNumericFilters
  if (totalCount === 0 && !isSearchMode && !hasActiveFilters) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle>Records</CardTitle>
            <CardDescription>
              No records have been created yet. Add your first record to get started.
            </CardDescription>
          </div>
          {onAddTransaction && (
            <Button
              onClick={onAddTransaction}
              disabled={!canAddTransaction}
              title={!canAddTransaction ? "Add fees to the fee library first" : undefined}
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Transaction
            </Button>
          )}
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <FileText className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No records yet</h3>
            <p className="text-muted-foreground mb-4 max-w-sm">
              Create records to track transactions for this billing group
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle>
              Records {totalCount !== undefined && `(${totalCount})`}
            </CardTitle>
            <CardDescription>
              {isSearchMode
                ? `Showing ${filteredRecords.length} results for "${debouncedSearch}"`
                : "All records for this billing group"}
            </CardDescription>
          </div>
          {onAddTransaction && (
            <Button
              onClick={onAddTransaction}
              disabled={!canAddTransaction}
              title={!canAddTransaction ? "Add fees to the fee library first" : undefined}
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Transaction
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {/* Toolbar */}
          <div className="flex items-center space-x-2 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by transaction #, description, reference, or custom fields..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 pr-8"
              />
              {(isSearchMode && searchResults === undefined) && (
                <Loader2 className="absolute right-2 top-2.5 h-4 w-4 animate-spin text-muted-foreground" />
              )}
            </div>

            {/* Columns Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  Columns <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[200px] max-h-[400px] overflow-y-auto">
                <DropdownMenuLabel className="text-xs text-muted-foreground">
                  System Columns
                </DropdownMenuLabel>
                {COLUMN_DEFINITIONS.map((column) => (
                  <DropdownMenuCheckboxItem
                    key={column.id}
                    checked={isColumnVisible(column.id)}
                    onCheckedChange={() => toggleColumn(column.id)}
                  >
                    {column.label}
                  </DropdownMenuCheckboxItem>
                ))}
                {customFieldColumns.length > 0 && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuLabel className="text-xs text-muted-foreground">
                      Custom Fields
                    </DropdownMenuLabel>
                    {customFieldColumns.map((column) => (
                      <DropdownMenuCheckboxItem
                        key={column.id}
                        checked={isColumnVisible(column.id)}
                        onCheckedChange={() => toggleColumn(column.id)}
                      >
                        {column.label}
                      </DropdownMenuCheckboxItem>
                    ))}
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Filter Popover */}
            <TableFilterPopover
              config={filterConfig}
              filters={filters}
              onFiltersChange={onFiltersChange}
            />

            {/* Export Button */}
            <PermissionGuard resource="reports" action="read" fallback={null}>
              <Button
                variant="outline"
                onClick={handleExport}
                disabled={!!exportProgress?.isExporting}
              >
                {exportProgress?.isExporting ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Download className="mr-2 h-4 w-4" />
                )}
                Export
              </Button>
            </PermissionGuard>
          </div>

          <div className="rounded-md border overflow-x-auto">
            <Table className="min-w-max">
              <TableHeader>
                <TableRow>
                  {isColumnVisible("transactionNumber") && <TableHead className="whitespace-nowrap min-w-[120px]">Transaction #</TableHead>}
                  {isColumnVisible("date") && <TableHead className="whitespace-nowrap min-w-[100px]">Date</TableHead>}
                  {isColumnVisible("description") && <TableHead className="whitespace-nowrap min-w-[150px]">Remarks</TableHead>}
                  {isColumnVisible("amount") && <TableHead className="text-right whitespace-nowrap min-w-[100px]">Amount</TableHead>}
                  {isColumnVisible("paymentMethod") && <TableHead className="whitespace-nowrap min-w-[130px]">Payment Method</TableHead>}
                  {isColumnVisible("referenceNumber") && <TableHead className="whitespace-nowrap min-w-[100px]">Reference</TableHead>}
                  {isColumnVisible("status") && <TableHead className="whitespace-nowrap min-w-[100px]">Status</TableHead>}
                  {customFieldColumns.map((col) => (
                    isColumnVisible(col.id) && (
                      <TableHead key={col.id} className="whitespace-nowrap min-w-[120px]">
                        {col.label}
                      </TableHead>
                    )
                  ))}
                  <TableHead className="w-[50px] sticky right-0 bg-card"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell
                      colSpan={visibleColumnCount + 1}
                      className="h-32 text-center"
                    >
                      <div className="flex items-center justify-center">
                        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground mr-2" />
                        <span className="text-muted-foreground">Loading records...</span>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : filteredRecords.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={visibleColumnCount + 1}
                      className="h-32 text-center"
                    >
                      <span className="text-muted-foreground">
                        {isSearchMode ? `No results found for "${debouncedSearch}"` : "No records found"}
                      </span>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredRecords.map((record) => {
                    const status = statusConfig[record.status]
                    const StatusIcon = status.icon

                    return (
                      <TableRow
                        key={record._id}
                        className="cursor-pointer hover:bg-muted/50"
                        onClick={() => setViewingRecordId(record._id)}
                      >
                        {isColumnVisible("transactionNumber") && (
                          <TableCell className="font-mono text-sm">
                            {record.transactionNumber}
                          </TableCell>
                        )}
                        {isColumnVisible("date") && (
                          <TableCell className="text-muted-foreground text-sm">
                            {record.date ? new Date(record.date).toLocaleDateString() : "—"}
                          </TableCell>
                        )}
                        {isColumnVisible("description") && (
                          <TableCell>
                            <span className="text-sm text-muted-foreground truncate max-w-[200px] block">
                              {record.description || "—"}
                            </span>
                          </TableCell>
                        )}
                        {isColumnVisible("amount") && (
                          <TableCell className="text-right font-medium">
                            {formatCurrency(record.amount)}
                          </TableCell>
                        )}
                        {isColumnVisible("paymentMethod") && (
                          <TableCell>
                            <Badge variant="outline" className="text-xs">
                              {record.paymentMethod || "Cash"}
                            </Badge>
                          </TableCell>
                        )}
                        {isColumnVisible("referenceNumber") && (
                          <TableCell className="text-muted-foreground text-sm">
                            {record.referenceNumber || "—"}
                          </TableCell>
                        )}
                        {isColumnVisible("status") && (
                          <TableCell>
                            <Badge variant={status.variant} className={status.className}>
                              <StatusIcon className="h-3 w-3 mr-1" />
                              {status.label}
                            </Badge>
                          </TableCell>
                        )}
                        {customFieldColumns.map((col) => {
                          if (!isColumnVisible(col.id)) return null
                          const fieldValue = record.fieldValues?.find(
                            (fv) => fv.fieldId === col.fieldId
                          )
                          return (
                            <TableCell key={col.id} className="text-sm whitespace-nowrap">
                              {formatFieldValue(fieldValue?.value, col.fieldType || "text")}
                            </TableCell>
                          )
                        })}
                        <TableCell
                          className="sticky right-0 bg-card"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              {canEdit && (
                                <DropdownMenuItem
                                  onClick={() => onEdit(record._id)}
                                  disabled={record.status === "cancelled" || (record.status === "completed" && !canUpdateAfterPayment)}
                                  className={record.status === "cancelled" || (record.status === "completed" && !canUpdateAfterPayment) ? "opacity-50 cursor-not-allowed" : ""}
                                >
                                  <Pencil className="h-4 w-4 mr-2" />
                                  Edit Record
                                  {(record.status === "cancelled" || (record.status === "completed" && !canUpdateAfterPayment)) && (
                                    <span className="ml-auto text-xs text-muted-foreground">
                                      ({record.status})
                                    </span>
                                  )}
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem
                                onClick={() => setPrintingRecordId(record._id)}
                                disabled={record.status !== "completed"}
                                className={record.status !== "completed" ? "opacity-50 cursor-not-allowed" : ""}
                              >
                                <Printer className="h-4 w-4 mr-2" />
                                Print Receipt
                                {record.status !== "completed" && (
                                  <span className="ml-auto text-xs text-muted-foreground">
                                    (unpaid)
                                  </span>
                                )}
                              </DropdownMenuItem>
                              {record.status !== "cancelled" && (
                                <>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuLabel className="text-xs text-muted-foreground">
                                    Change Status
                                  </DropdownMenuLabel>
                                  {record.status !== "pending" && (
                                    <DropdownMenuItem
                                      onClick={() => openStatusDialog(record._id, "pending")}
                                      disabled={record.status === "completed" && !canUpdateAfterPayment}
                                      className={record.status === "completed" && !canUpdateAfterPayment ? "opacity-50 cursor-not-allowed" : ""}
                                    >
                                      <Clock className="h-4 w-4 mr-2 text-yellow-600" />
                                      Mark Pending
                                    </DropdownMenuItem>
                                  )}
                                  {record.status !== "completed" && (
                                    <DropdownMenuItem onClick={() => openStatusDialog(record._id, "completed")}>
                                      <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                                      Paid
                                    </DropdownMenuItem>
                                  )}
                                  <DropdownMenuItem
                                    onClick={() => openCancellationDialog(record._id)}
                                    disabled={record.status === "completed" && !canUpdateAfterPayment}
                                    className={record.status === "completed" && !canUpdateAfterPayment ? "opacity-50 cursor-not-allowed" : ""}
                                  >
                                    <XCircle className="h-4 w-4 mr-2 text-red-600" />
                                    Mark Cancelled
                                  </DropdownMenuItem>
                                </>
                              )}
                              {canDelete && (
                                <>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem
                                    onClick={() => setDeletingRecordId(record._id)}
                                    disabled={record.status === "completed" && !canUpdateAfterPayment}
                                    className={record.status === "completed" && !canUpdateAfterPayment ? "opacity-50 cursor-not-allowed" : "text-destructive focus:text-destructive"}
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete Record
                                    {record.status === "completed" && !canUpdateAfterPayment && (
                                      <span className="ml-auto text-xs text-muted-foreground">
                                        (paid)
                                      </span>
                                    )}
                                  </DropdownMenuItem>
                                </>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    )
                  })
                )}
              </TableBody>
            </Table>
          </div>

          {/* Pagination Controls */}
          <div className="flex items-center justify-between px-2 pt-4">
            <div className="flex-1 text-sm text-muted-foreground">
              {isLoading ? (
                "Loading..."
              ) : (
                `Showing ${filteredRecords.length} of ${totalCount ?? "..."} ${isSearchMode ? "results" : "records"}`
              )}
            </div>
            <div className="flex items-center space-x-6 lg:space-x-8">
              <div className="flex items-center space-x-2">
                <p className="text-sm font-medium">
                  Page {currentPage + 1} of {totalPages ?? "..."}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handlePrevPage}
                  disabled={!canGoPrev || isLoading}
                >
                  Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleNextPage}
                  disabled={!canGoNext || isLoading}
                >
                  Next
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Delete Confirmation */}
      <AlertDialog open={deletingRecordId !== null} onOpenChange={() => setDeletingRecordId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Record?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the record from this billing group. This action can be undone by an administrator.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Status Update Confirmation */}
      <AlertDialog open={updatingStatusId !== null} onOpenChange={() => {
        setUpdatingStatusId(null)
        setNewStatus(null)
      }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Update Status?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to change the status to "{newStatus}"? This action will be logged.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleStatusUpdate}>
              Update Status
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Cancellation Dialog with Reason Input */}
      <Dialog
        open={cancellingRecordId !== null}
        onOpenChange={(open) => {
          if (!open) {
            setCancellingRecordId(null)
            setCancellationReason("")
            setCancellationError("")
          }
        }}
      >
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <XCircle className="h-5 w-5 text-destructive" />
              Cancel Record
            </DialogTitle>
            <DialogDescription>
              This action will mark the record as cancelled. Once cancelled, the status cannot be changed.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="cancellation-reason">
                Reason for Cancellation <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="cancellation-reason"
                placeholder="Enter the reason for cancelling this record..."
                value={cancellationReason}
                onChange={(e) => {
                  setCancellationReason(e.target.value)
                  if (cancellationError) setCancellationError("")
                }}
                maxLength={500}
                rows={4}
                className={cancellationError ? "border-destructive" : ""}
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                {cancellationError && (
                  <span className="text-destructive">{cancellationError}</span>
                )}
                <span className="ml-auto">{cancellationReason.length}/500 characters</span>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setCancellingRecordId(null)
                setCancellationReason("")
                setCancellationError("")
              }}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleCancellation}
            >
              Confirm Cancellation
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Receipt Preview Modal - key prop for hard reset */}
      {printingRecordId && (
        <ReceiptPreviewModal
          key={printingRecordId}
          open={printingRecordId !== null}
          onClose={() => setPrintingRecordId(null)}
          recordId={printingRecordId}
          billingGroupId={billingGroupId}
          billingGroupName={billingGroupName || "Billing Group"}
        />
      )}

      {/* Transaction View Modal */}
      <TransactionViewModal
        open={viewingRecordId !== null}
        onClose={() => setViewingRecordId(null)}
        billingGroupId={billingGroupId}
        recordId={viewingRecordId}
      />

      {/* Export Progress Dialog */}
      <Dialog open={!!exportProgress?.isExporting} onOpenChange={() => {}}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Exporting Records</DialogTitle>
            <DialogDescription>
              Please wait while your records are being exported with line items...
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <Progress value={undefined} />
            <p className="text-sm text-center text-muted-foreground">
              {exportProgress?.total
                ? `Processed ${exportProgress.current.toLocaleString()} of ${exportProgress.total.toLocaleString()} rows...`
                : "Fetching records..."}
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={handleCancelExport}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
