"use client"

import { useState, useEffect, useMemo } from "react"
import { PDFViewer, PDFDownloadLink } from "@react-pdf/renderer"
import { useQuery } from "convex/react"
import Link from "next/link"
import { Download, Printer, ChevronDown, ExternalLink } from "lucide-react"

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { Button } from "@repo/ui/components/button"
import { Skeleton } from "@repo/ui/components/skeleton"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import { Badge } from "@repo/ui/components/badge"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { PaymentReceiptDocument, type PaymentReceiptData, type PaymentReceiptFee } from "./payment-receipt-document"
import { TemplateBasedReceiptDocument } from "./template-based-receipt-document"

// Schedule fee type from backend
interface ScheduleFee {
  feeId?: Id<"fees">
  feeName: string
  feeCategory: string
  originalAmount: number
  sectionAmount: number
  isEdited?: boolean
  editedAt?: string
  editedBy?: string
}

interface PaymentReceiptModalProps {
  open: boolean
  onClose: () => void
  payment: {
    _id: Id<"payments">
    receiptNumber?: string
    transactionNumber: string
    amount: number
    paymentMethod: string
    referenceNumber?: string
    paidAt: string
  } | null
  schedule: {
    _id: Id<"payment_schedules">
    sectionNumber: number
    dueDate: string
    fees: ScheduleFee[]
    totalAmount: number
    surcharge?: number
    penalty?: number
  } | null
  applicationNumber: string
  businessName?: string
  businessOwnerName?: string
  businessAddress?: string
  totalSections: number
}

export function PaymentReceiptModal({
  open,
  onClose,
  payment,
  schedule,
  applicationNumber,
  businessName,
  businessOwnerName,
  businessAddress,
  totalSections,
}: PaymentReceiptModalProps) {
  const [isClient, setIsClient] = useState(false)
  const [selectedLayoutId, setSelectedLayoutId] = useState<Id<"receipt_layouts"> | "default" | undefined>(undefined)

  // Query available layouts and default layout
  const layouts = useQuery(api.receiptLayouts.list)
  const defaultLayout = useQuery(api.receiptLayouts.getDefault)
  const selectedLayout = useQuery(
    api.receiptLayouts.getById,
    selectedLayoutId && selectedLayoutId !== "default" ? { id: selectedLayoutId } : "skip"
  )
  const platformSettings = useQuery(api.platformSettings.get)

  // Set client-side rendering flag
  useEffect(() => {
    setIsClient(true)
  }, [])

  // Auto-select default layout when modal opens
  useEffect(() => {
    if (open && selectedLayoutId === undefined) {
      if (defaultLayout) {
        setSelectedLayoutId(defaultLayout._id)
      } else if (defaultLayout === null) {
        setSelectedLayoutId("default")
      }
    }
  }, [open, defaultLayout, selectedLayoutId])

  // Reset selection when modal closes (hard reset)
  useEffect(() => {
    if (!open) {
      setSelectedLayoutId(undefined)
    }
  }, [open])

  // Get period label based on section number and total sections
  const getPeriodLabel = (sectionNumber: number, total: number): string => {
    if (total === 1) return "Full Payment"
    if (total === 2) return sectionNumber === 1 ? "1st Semester" : "2nd Semester"
    return `Q${sectionNumber}`
  }

  // Get the selected layout name for display
  const selectedLayoutName = useMemo(() => {
    if (selectedLayoutId === undefined) return "Loading..."
    if (selectedLayoutId === "default") return "Default Layout"
    const layout = layouts?.find(l => l._id === selectedLayoutId)
    return layout?.name || "Custom Layout"
  }, [selectedLayoutId, layouts])

  // Prepare receipt data
  const receiptData: PaymentReceiptData | null = useMemo(() => {
    if (!payment || !schedule) return null

    const fees: PaymentReceiptFee[] = schedule.fees.map((fee) => ({
      feeName: fee.feeName,
      feeCategory: fee.feeCategory,
      amount: fee.sectionAmount,
    }))

    return {
      receiptNumber: payment.receiptNumber || payment.transactionNumber,
      transactionNumber: payment.transactionNumber,
      date: payment.paidAt,
      paidAt: payment.paidAt,
      amount: payment.amount,
      paymentMethod: payment.paymentMethod,
      referenceNumber: payment.referenceNumber,
      periodLabel: getPeriodLabel(schedule.sectionNumber, totalSections),
      dueDate: schedule.dueDate,
      fees,
      totalAmount: schedule.totalAmount,
      surcharge: schedule.surcharge,
      penalty: schedule.penalty,
      applicationNumber,
      businessName,
      businessOwnerName,
      printDate: new Date().toLocaleDateString(),
      fullAddress: platformSettings?.fullAddress,
    }
  }, [payment, schedule, totalSections, applicationNumber, businessName, businessOwnerName, platformSettings])

  // Prepare template data (extended with system fields)
  const templateData = useMemo(() => {
    if (!receiptData) return null

    return {
      ...receiptData,
      municipalityName: platformSettings?.municipalityName || "",
      provinceName: platformSettings?.provinceName || "",
      mayorName: platformSettings?.mayorName || "",
      treasurerName: platformSettings?.treasurerName || "",
      fullAddress: businessAddress || platformSettings?.fullAddress || "",
      sectionNumber: schedule?.sectionNumber,
    }
  }, [receiptData, platformSettings, businessAddress, schedule])

  // Check if we can render a document (have required data)
  const canRenderDocument = selectedLayoutId !== undefined && (
    selectedLayoutId === "default"
      ? !!receiptData
      : !!(selectedLayout && templateData)
  )

  // Create document function - returns a new element each time to avoid sharing issues
  const createDocument = () => {
    if (selectedLayoutId === "default" || !selectedLayout) {
      return receiptData ? <PaymentReceiptDocument data={receiptData} /> : null
    }
    return templateData ? (
      <TemplateBasedReceiptDocument
        layout={selectedLayout}
        data={templateData}
      />
    ) : null
  }

  if (!open) return null

  const isLoading = !payment || !schedule

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-[75vw] max-w-[75vw] w-[75vw] h-[90vh] flex flex-col p-0">
        <DialogHeader className="flex-shrink-0 px-6 pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <DialogTitle>Payment Receipt Preview</DialogTitle>

              {/* Layout Selector Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    {selectedLayoutName}
                    <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-56">
                  <DropdownMenuLabel>Select Layout</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => setSelectedLayoutId("default")}
                    className="flex items-center justify-between"
                  >
                    Default Layout
                    {selectedLayoutId === "default" && (
                      <Badge variant="secondary" className="text-xs">Active</Badge>
                    )}
                  </DropdownMenuItem>
                  {layouts && layouts.length > 0 && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuLabel className="text-xs text-muted-foreground">
                        Custom Layouts
                      </DropdownMenuLabel>
                      {layouts.map((layout) => (
                        <DropdownMenuItem
                          key={layout._id}
                          onClick={() => setSelectedLayoutId(layout._id)}
                          className="flex items-center justify-between"
                        >
                          <span className="flex items-center gap-2">
                            {layout.name}
                            {layout.isDefault && (
                              <Badge variant="outline" className="text-xs">Default</Badge>
                            )}
                          </span>
                          {selectedLayoutId === layout._id && (
                            <Badge variant="secondary" className="text-xs">Active</Badge>
                          )}
                        </DropdownMenuItem>
                      ))}
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Create New Layout Link */}
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Link href="/dashboard/settings/receipting">
                      <ExternalLink className="h-4 w-4 text-muted-foreground hover:text-foreground cursor-pointer" />
                    </Link>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Create new receipt layout</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>

            {receiptData && isClient && canRenderDocument && (
              <div className="flex items-center gap-2">
                <PDFDownloadLink
                  document={createDocument()!}
                  fileName={`receipt-${receiptData.receiptNumber}.pdf`}
                >
                  {({ loading }) => (
                    <Button variant="outline" size="sm" disabled={loading}>
                      <Download className="mr-2 h-4 w-4" />
                      {loading ? "Preparing..." : "Download PDF"}
                    </Button>
                  )}
                </PDFDownloadLink>
                <Button variant="outline" size="sm" onClick={() => window.print()}>
                  <Printer className="mr-2 h-4 w-4" />
                  Print
                </Button>
              </div>
            )}
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-hidden p-6 pt-4">
          {isLoading ? (
            <div className="h-full flex items-center justify-center">
              <Skeleton className="w-full h-full" />
            </div>
          ) : receiptData && isClient && canRenderDocument ? (
            <PDFViewer
              width="100%"
              height="100%"
              showToolbar={false}
              className="border rounded-md"
            >
              {createDocument()!}
            </PDFViewer>
          ) : (
            <div className="h-full flex items-center justify-center text-muted-foreground">
              Unable to load receipt data
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
