"use client";

import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { CheckCircle2, XCircle, AlertCircle } from "lucide-react";
import { Textarea } from "@repo/ui/components/textarea";
import { Label } from "@repo/ui/components/label";
import { cn } from "@/lib/utils";

/**
 * Standard variables available for all fee formulas
 */
const STANDARD_VARIABLES = [
  "numberOfEmployees",
  "maleEmployeeCount",
  "femaleEmployeeCount",
  "businessArea",
  "floorArea",
  "capitalInvestment",
  "grossSales",
  "businessAnnualRevenue",
] as const;

/**
 * Math operators and functions allowed in formulas
 */
const ALLOWED_TOKENS = [
  "+",
  "-",
  "*",
  "/",
  "(",
  ")",
  ".",
  " ",
  "Math",
  "min",
  "max",
  "floor",
  "ceil",
  "round",
  "abs",
  "pow",
  "sqrt",
] as const;

interface CategoryVariable {
  variableName: string;
  assetClass?: string;
  quantity?: number;
  description?: string;
}

interface FormulaInputProps {
  /**
   * Current formula value
   */
  value: string;
  /**
   * Callback when formula changes
   */
  onChange: (value: string) => void;
  /**
   * Placeholder text
   */
  placeholder?: string;
  /**
   * Additional CSS classes
   */
  className?: string;
  /**
   * Number of visible rows
   */
  rows?: number;
  /**
   * Dynamic category variables (e.g., numberOfHorses, numberOfTables)
   */
  categoryVariables?: CategoryVariable[];
  /**
   * Range field for Range fee types (adds special variable like assetSize)
   */
  rangeField?: string;
  /**
   * Whether the input is disabled
   */
  disabled?: boolean;
  /**
   * Label text (optional)
   */
  label?: string;
  /**
   * Whether to show inline validation status
   */
  showValidation?: boolean;
  /**
   * Callback with validation result
   */
  onValidationChange?: (result: FormulaValidationResult) => void;
}

export interface FormulaValidationResult {
  valid: boolean;
  error?: string;
  evaluatedResult?: number;
}

/**
 * Validates a formula string in real-time
 * Returns validation result with error message if invalid
 */
export function validateFormulaRealTime(
  formula: string,
  categoryVariables?: CategoryVariable[],
  rangeField?: string
): FormulaValidationResult {
  // Empty formula is not valid but not an error (user hasn't typed yet)
  if (!formula || formula.trim() === "") {
    return { valid: false, error: "Formula is required" };
  }

  // Build allowed variables list
  const allowedVariables: string[] = [...STANDARD_VARIABLES];

  // Add category variables
  if (categoryVariables && categoryVariables.length > 0) {
    for (const cv of categoryVariables) {
      if (cv.variableName && !allowedVariables.includes(cv.variableName)) {
        allowedVariables.push(cv.variableName);
      }
    }
  }

  // Add special range field variables
  if (rangeField === "assetSize") {
    allowedVariables.push("assetSize");
  }
  if (rangeField === "unitOfMeasurement") {
    allowedVariables.push("unitOfMeasurement");
  }

  // Extract all word tokens from formula (potential variables)
  const variablePattern = /[a-zA-Z_][a-zA-Z0-9_]*/g;
  const tokens = formula.match(variablePattern) || [];

  // Check each token
  for (const token of tokens) {
    // Skip allowed tokens (Math functions, etc.)
    if (ALLOWED_TOKENS.includes(token as any)) {
      continue;
    }
    // Check if it's an allowed variable
    if (!allowedVariables.includes(token)) {
      return {
        valid: false,
        error: `Unknown variable: "${token}". Available: ${allowedVariables.join(", ")}`,
      };
    }
  }

  // Try to evaluate with sample data
  try {
    // Build sample data for evaluation
    const sampleData: Record<string, number> = {
      numberOfEmployees: 10,
      maleEmployeeCount: 6,
      femaleEmployeeCount: 4,
      businessArea: 200,
      floorArea: 200,
      capitalInvestment: 500000,
      grossSales: 1000000,
      businessAnnualRevenue: 1000000,
      assetSize: 100,
      unitOfMeasurement: 50,
    };

    // Add category variables with sample values
    if (categoryVariables) {
      for (const cv of categoryVariables) {
        sampleData[cv.variableName] = cv.quantity ?? 10;
      }
    }

    // Replace variables with values
    let expression = formula;
    for (const [varName, value] of Object.entries(sampleData)) {
      const regex = new RegExp(`\\b${varName}\\b`, "g");
      expression = expression.replace(regex, value.toString());
    }

    // Check for invalid characters (security)
    const sanitized = expression.replace(/[0-9\s+\-*/().Math\w]/g, "");
    if (sanitized.length > 0) {
      return {
        valid: false,
        error: `Invalid characters in formula: "${sanitized}"`,
      };
    }

    // Evaluate the expression
    const result = Function(`"use strict"; return (${expression})`)();

    if (typeof result !== "number" || isNaN(result)) {
      return {
        valid: false,
        error: "Formula must evaluate to a valid number",
      };
    }

    if (!isFinite(result)) {
      return {
        valid: false,
        error: "Formula results in infinity (division by zero?)",
      };
    }

    return {
      valid: true,
      evaluatedResult: result,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    // Simplify common syntax errors
    if (errorMessage.includes("Unexpected")) {
      return {
        valid: false,
        error: "Syntax error: Check for missing operators or parentheses",
      };
    }
    return {
      valid: false,
      error: `Syntax error: ${errorMessage}`,
    };
  }
}

/**
 * FormulaInput Component
 *
 * A textarea component with real-time formula validation.
 * Shows validation state (valid/invalid) as the user types.
 */
export function FormulaInput({
  value,
  onChange,
  placeholder = "e.g., numberOfEmployees * 100 + businessArea * 50",
  className,
  rows = 3,
  categoryVariables,
  rangeField,
  disabled = false,
  label,
  showValidation = true,
  onValidationChange,
}: FormulaInputProps) {
  const [validation, setValidation] = useState<FormulaValidationResult>({
    valid: false,
    error: undefined,
  });
  const [hasInteracted, setHasInteracted] = useState(false);

  // Use ref to store the callback to avoid infinite loops
  const onValidationChangeRef = useRef(onValidationChange);
  onValidationChangeRef.current = onValidationChange;

  // Memoize the allowed variables for display
  const allowedVariables = useMemo(() => {
    const vars = [...STANDARD_VARIABLES];
    if (categoryVariables) {
      for (const cv of categoryVariables) {
        if (cv.variableName && !vars.includes(cv.variableName as any)) {
          vars.push(cv.variableName as any);
        }
      }
    }
    if (rangeField === "assetSize") vars.push("assetSize" as any);
    if (rangeField === "unitOfMeasurement") vars.push("unitOfMeasurement" as any);
    return vars;
  }, [categoryVariables, rangeField]);

  // Validate immediately on value change
  useEffect(() => {
    const result = value
      ? validateFormulaRealTime(value, categoryVariables, rangeField)
      : { valid: false, error: "Formula is required" };

    setValidation(result);
    // Use ref to call callback without causing re-renders
    onValidationChangeRef.current?.(result);
  }, [value, categoryVariables, rangeField]);

  // Determine validation state styling
  const getValidationState = () => {
    if (!hasInteracted && !value) {
      return "neutral"; // Initial state
    }
    if (validation.valid) {
      return "valid";
    }
    return "invalid";
  };

  const validationState = getValidationState();

  return (
    <div className="space-y-2">
      {label && <Label>{label}</Label>}
      <div className="relative">
        <Textarea
          value={value}
          onChange={(e) => {
            setHasInteracted(true);
            onChange(e.target.value);
          }}
          onFocus={() => setHasInteracted(true)}
          placeholder={placeholder}
          disabled={disabled}
          rows={rows}
          className={cn(
            "font-mono pr-10 transition-colors",
            validationState === "valid" && "border-green-500 focus-visible:ring-green-500",
            validationState === "invalid" && hasInteracted && "border-red-500 focus-visible:ring-red-500",
            className
          )}
        />
        {/* Validation Icon */}
        {showValidation && hasInteracted && value && (
          <div className="absolute right-3 top-3">
            {validationState === "valid" ? (
              <CheckCircle2 className="h-5 w-5 text-green-500" />
            ) : (
              <XCircle className="h-5 w-5 text-red-500" />
            )}
          </div>
        )}
      </div>

      {/* Validation Message */}
      {showValidation && hasInteracted && (
        <div
          className={cn(
            "text-xs flex items-start gap-1.5",
            validationState === "valid" ? "text-green-600" : "text-red-600"
          )}
        >
          {validationState === "valid" ? (
            <>
              <CheckCircle2 className="h-3.5 w-3.5 mt-0.5 flex-shrink-0" />
              <span>Valid formula</span>
            </>
          ) : validation.error ? (
            <>
              <AlertCircle className="h-3.5 w-3.5 mt-0.5 flex-shrink-0" />
              <span>{validation.error}</span>
            </>
          ) : null}
        </div>
      )}
    </div>
  );
}

/**
 * Hook for formula validation
 * Use this when you need validation state without the full input component
 */
export function useFormulaValidation(
  formula: string,
  categoryVariables?: CategoryVariable[],
  rangeField?: string
) {
  const [validation, setValidation] = useState<FormulaValidationResult>({
    valid: false,
    error: undefined,
  });

  useEffect(() => {
    const result = validateFormulaRealTime(formula, categoryVariables, rangeField);
    setValidation(result);
  }, [formula, categoryVariables, rangeField]);

  return validation;
}
