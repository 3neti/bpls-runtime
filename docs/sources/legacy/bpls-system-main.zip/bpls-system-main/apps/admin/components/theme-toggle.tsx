"use client"
import { Moon, Sun } from "lucide-react"
import { useTheme } from "next-themes"
import { useEffect, useState } from "react"

import { Button } from "@repo/ui/components/button"

export function ThemeToggle() {
  const { theme, setTheme, resolvedTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <Button variant="outline" size="icon">
        <Sun className="h-[1.2rem] w-[1.2rem]" />
        <span className="sr-only">Toggle theme</span>
      </Button>
    )
  }

  return (
    <Button
      variant="outline"
      size="icon"
      onClick={() => {
        const currentTheme = theme || resolvedTheme || "system"
        console.log("[v0] Current theme:", currentTheme)
        console.log("[v0] Resolved theme:", resolvedTheme)

        if (currentTheme === "light") {
          console.log("[v0] Setting theme to: dark")
          setTheme("dark")
        } else if (currentTheme === "dark") {
          console.log("[v0] Setting theme to: light")
          setTheme("light")
        } else {
          console.log("[v0] Setting theme to: light")
          setTheme("light")
        }
      }}
    >
      <Sun className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
      <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
      <span className="sr-only">Toggle theme</span>
    </Button>
  )
}
