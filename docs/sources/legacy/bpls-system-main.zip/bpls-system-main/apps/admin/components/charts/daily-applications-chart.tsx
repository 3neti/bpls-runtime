"use client";

import { Bar, BarChart, CartesianGrid, XAxis } from "recharts";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import { type ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from "@repo/ui/components/chart";
import { Skeleton } from "@repo/ui/components/skeleton";

interface ChartDataPoint {
  day: string;
  new: number;
  renewal: number;
}

interface DailyApplicationsChartProps {
  data?: ChartDataPoint[];
  isLoading?: boolean;
}

const chartConfig = {
  new: {
    label: "New Applications",
    color: "hsl(var(--chart-1))",
  },
  renewal: {
    label: "Renewals",
    color: "hsl(var(--chart-2))",
  },
} satisfies ChartConfig;

export function DailyApplicationsChart({ data, isLoading }: DailyApplicationsChartProps) {
  // Show skeleton while loading
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Daily Applications</CardTitle>
          <CardDescription>This Week&apos;s Application Activity</CardDescription>
        </CardHeader>
        <CardContent className="p-0 pt-6">
          <Skeleton className="mx-6 h-[300px]" />
        </CardContent>
      </Card>
    );
  }

  // Use provided data or show empty state
  const chartData = data || [];
  const hasData = chartData.length > 0 && chartData.some((d) => d.new > 0 || d.renewal > 0);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Daily Applications</CardTitle>
        <CardDescription>This Week&apos;s Application Activity</CardDescription>
      </CardHeader>
      <CardContent className="p-0 pt-6">
        {!hasData ? (
          <div className="flex h-[300px] items-center justify-center px-6 text-muted-foreground">
            No applications this week
          </div>
        ) : (
          <ChartContainer config={chartConfig} className="h-[300px] w-full px-6">
            <BarChart
              accessibilityLayer
              data={chartData}
              margin={{
                top: 20,
                right: 20,
                left: 20,
                bottom: 20,
              }}
            >
              <CartesianGrid vertical={false} />
              <XAxis
                dataKey="day"
                tickLine={false}
                tickMargin={10}
                axisLine={false}
                tickFormatter={(value) => value.slice(0, 3)}
              />
              <ChartTooltip cursor={false} content={<ChartTooltipContent indicator="dashed" label="" payload={[]} />} />
              <Bar dataKey="new" fill="var(--color-new)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="renewal" fill="var(--color-renewal)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ChartContainer>
        )}
      </CardContent>
    </Card>
  );
}
