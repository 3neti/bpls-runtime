"use client"

import { ColumnDef } from "@tanstack/react-table"
import { ArrowUpDown, Trash2, Eye } from "lucide-react"

import { Button } from "@repo/ui/components/button"
import { Badge } from "@repo/ui/components/badge"
import { Checkbox } from "@repo/ui/components/checkbox"
import { Avatar, AvatarFallback, AvatarImage } from "@repo/ui/components/avatar"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import type { Doc } from "@repo/backend/convex/_generated/dataModel"
import { STATUS_COLORS, STATUS_LABELS } from "@/lib/types/permit-application"

type PermitApplicationRow = Doc<"business_permit_applications"> & {
  ownerName: string
  businessName: string
  businessOwner: Doc<"business_owners"> | null
  business: Doc<"businesses"> | null
}

interface AssessmentColumnsProps {
  onView?: (applicationId: string) => void
  onDelete?: (applicationId: string) => void
}

export const createAssessmentColumns = (
  props?: AssessmentColumnsProps
): ColumnDef<PermitApplicationRow>[] => [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={
          table.getIsAllPageRowsSelected() ||
          (table.getIsSomePageRowsSelected() && "indeterminate")
        }
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "applicationNumber",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Application Number
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const application = row.original
      return (
        <div className="flex flex-col gap-1">
          <div className="font-mono font-semibold text-sm">
            {application.applicationNumber}
          </div>
          <div className="text-xs text-muted-foreground">
            ID: {application._id.slice(-8)}
          </div>
        </div>
      )
    },
  },
  {
    accessorKey: "ownerName",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Business Owner
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const owner = row.original.businessOwner
      const ownerName = row.original.ownerName

      if (!owner) {
        return <span className="text-muted-foreground text-sm">N/A</span>
      }

      const initials = `${owner.firstName[0]}${owner.lastName[0]}`.toUpperCase()

      return (
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8">
            <AvatarImage src={owner.avatar} alt={ownerName} />
            <AvatarFallback className="text-xs">
              {initials}
            </AvatarFallback>
          </Avatar>
          <span className="font-medium text-sm">{ownerName}</span>
        </div>
      )
    },
  },
  {
    accessorKey: "businessName",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Business Name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      return <div className="text-sm">{row.original.businessName}</div>
    },
  },
  {
    accessorKey: "submittedAt",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Submitted Date
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const date = new Date(row.original.submittedAt)
      return (
        <div className="text-sm">
          {date.toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric",
          })}
        </div>
      )
    },
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.original.status
      return (
        <Badge className={STATUS_COLORS[status]} variant="outline">
          {STATUS_LABELS[status]}
        </Badge>
      )
    },
  },
  {
    id: "actions",
    header: "Actions",
    cell: ({ row }) => {
      const application = row.original
      return (
        <div className="flex items-center gap-1">
          <TooltipProvider>
            {props?.onView && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation()
                      props.onView?.(application._id)
                    }}
                    className="h-8 w-8"
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>View application</p>
                </TooltipContent>
              </Tooltip>
            )}
            {props?.onDelete && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation()
                      props.onDelete?.(application._id)
                    }}
                    className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Delete application</p>
                </TooltipContent>
              </Tooltip>
            )}
          </TooltipProvider>
        </div>
      )
    },
    enableSorting: false,
    enableHiding: false,
  },
  // Additional columns (hidden by default, can be toggled via Columns dropdown)
  {
    id: "lineOfBusiness",
    accessorFn: (row) => {
      // Get the first line of business from the application
      const lobs = row.linesOfBusiness
      if (lobs && lobs.length > 0) {
        return lobs[0].businessCategory || "N/A"
      }
      return null
    },
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Line of Business
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const lobs = row.original.linesOfBusiness
      if (!lobs || lobs.length === 0) {
        return <span className="text-muted-foreground text-sm">N/A</span>
      }
      const primaryLob = lobs[0].businessCategory || "Unknown"
      const additionalCount = lobs.length > 1 ? ` +${lobs.length - 1} more` : ""
      return (
        <div className="text-sm">
          {primaryLob}
          {additionalCount && (
            <span className="text-muted-foreground">{additionalCount}</span>
          )}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "businessScale",
    accessorFn: (row) => row.business?.businessScale,
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Business Scale
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const scale = row.original.business?.businessScale
      return (
        <Badge variant="outline" className="text-xs">
          {scale || "N/A"}
        </Badge>
      )
    },
    enableHiding: true,
  },
  {
    id: "ownershipType",
    accessorFn: (row) => row.business?.ownershipType,
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Ownership Type
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const ownershipType = row.original.business?.ownershipType
      return (
        <div className="text-sm">
          {ownershipType || <span className="text-muted-foreground">N/A</span>}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "businessAddress",
    accessorFn: (row) => row.business?.address,
    header: "Business Address",
    cell: ({ row }) => {
      const address = row.original.business?.address
      return (
        <div className="text-sm max-w-[200px] truncate" title={address || undefined}>
          {address || <span className="text-muted-foreground">N/A</span>}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "ownerEmail",
    accessorFn: (row) => row.businessOwner?.email,
    header: "Owner Email",
    cell: ({ row }) => {
      const email = row.original.businessOwner?.email
      return (
        <div className="text-sm text-muted-foreground">
          {email || "N/A"}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "ownerContact",
    accessorFn: (row) => row.businessOwner?.mobile,
    header: "Owner Contact",
    cell: ({ row }) => {
      const mobile = row.original.businessOwner?.mobile
      return (
        <div className="text-sm font-mono">
          {mobile || <span className="text-muted-foreground">N/A</span>}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "ownerTin",
    accessorFn: (row) => row.businessOwner?.tin,
    header: "TIN",
    cell: ({ row }) => {
      const tin = row.original.businessOwner?.tin
      return (
        <div className="text-sm font-mono">
          {tin || <span className="text-muted-foreground">N/A</span>}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "applicationType",
    accessorKey: "permitApplicationType",
    header: "Application Type",
    cell: ({ row }) => {
      const type = row.original.permitApplicationType
      return (
        <Badge variant="outline" className={type === "Renewal" ? "bg-blue-50 text-blue-700 border-blue-200" : "bg-green-50 text-green-700 border-green-200"}>
          {type || "New"}
        </Badge>
      )
    },
    enableHiding: true,
  },
  {
    id: "createdAt",
    accessorKey: "_creationTime",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Created Date
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const date = new Date(row.original._creationTime)
      return (
        <div className="text-sm text-muted-foreground">
          {date.toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric",
          })}
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "assessedAt",
    accessorKey: "assessedAt",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Assessed At
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const assessedAt = row.original.assessedAt
      if (!assessedAt) {
        return <span className="text-sm text-muted-foreground">Not assessed</span>
      }
      const date = new Date(assessedAt)
      return (
        <div className="text-sm text-muted-foreground">
          {date.toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric",
          })}
        </div>
      )
    },
    enableHiding: true,
  },
]

// Backward compatibility - default columns without delete handler
export const assessmentColumns = createAssessmentColumns()
