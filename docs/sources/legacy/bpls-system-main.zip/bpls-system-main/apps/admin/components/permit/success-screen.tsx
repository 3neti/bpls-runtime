"use client"

import { CheckCircle, Download, FileText, Home } from "lucide-react"
import Link from "next/link"
import { Button } from "@repo/ui/components/button"
import { Card, CardContent } from "@repo/ui/components/card"

interface SuccessScreenProps {
  applicationNumber?: string
}

export function SuccessScreen({ applicationNumber = "BPLS-2024-001234" }: SuccessScreenProps) {
  return (
    <div className="flex flex-col items-center justify-center py-12 space-y-6">
      <div className="flex items-center justify-center w-20 h-20 bg-green-100 rounded-full">
        <CheckCircle className="w-12 h-12 text-green-600" />
      </div>

      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-green-600">Application Submitted Successfully!</h2>
        <p className="text-muted-foreground max-w-md">
          Your business permit application has been submitted and is now under review.
        </p>
      </div>

      <Card className="w-full max-w-md">
        <CardContent className="p-6 space-y-4">
          <div className="flex items-center space-x-3">
            <FileText className="w-5 h-5 text-blue-600" />
            <div>
              <p className="font-medium">Application Number</p>
              <p className="text-sm text-muted-foreground">{applicationNumber}</p>
            </div>
          </div>

          <div className="border-t pt-4">
            <h4 className="font-medium mb-2">What's Next?</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Your application will be reviewed within 3-5 business days</li>
              <li>• You'll receive email updates on the status</li>
              <li>• Payment instructions will be sent once approved</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-col sm:flex-row gap-3">
        <Button variant="outline" className="flex items-center space-x-2 bg-transparent">
          <Download className="w-4 h-4" />
          <span>Download Receipt</span>
        </Button>

        <Link href="/dashboard/permit-applications">
          <Button className="flex items-center space-x-2">
            <Home className="w-4 h-4" />
            <span>Back to Permit Applications</span>
          </Button>
        </Link>
      </div>
    </div>
  )
}
