"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import { useDebouncedValue } from "@/hooks/use-debounced-value";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@repo/ui/components/command";
import {
  FileText,
  Users,
  Building2,
  Award,
  CreditCard,
  User,
  Loader2,
} from "lucide-react";
import { Badge } from "@repo/ui/components/badge";

interface GlobalSearchPaletteProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function GlobalSearchPalette({
  open,
  onOpenChange,
}: GlobalSearchPaletteProps) {
  const router = useRouter();
  const [search, setSearch] = React.useState("");
  const debouncedSearch = useDebouncedValue(search, 300);

  // Only query when we have at least 2 characters
  const results = useQuery(
    api.search.globalSearch,
    debouncedSearch.length >= 2 ? { query: debouncedSearch, limit: 5 } : "skip"
  );

  // Reset search when dialog closes
  React.useEffect(() => {
    if (!open) {
      setSearch("");
    }
  }, [open]);

  const handleSelect = (type: string, id: string, status?: string) => {
    onOpenChange(false);
    setSearch("");

    switch (type) {
      case "permit":
        router.push(`/dashboard/permits/${id}`);
        break;
      case "application":
        // Route based on status
        if (status === "Assessment") {
          router.push(`/dashboard/permit-applications/assessment/${id}`);
        } else if (status === "Approval") {
          router.push(`/dashboard/permit-applications/approval/${id}`);
        } else if (status === "Pending Payment") {
          router.push(`/dashboard/permit-applications/payment/${id}`);
        } else if (status === "Released") {
          router.push(`/dashboard/permit-applications/released/${id}`);
        } else if (status === "Draft") {
          router.push(`/dashboard/permit-applications/drafts`);
        } else {
          router.push(`/dashboard/permit-applications/assessment/${id}`);
        }
        break;
      case "owner":
        router.push(`/dashboard/business-owners/${id}`);
        break;
      case "business":
        router.push(`/dashboard/businesses/${id}`);
        break;
      case "user":
        // User management has no detail page, redirect to list
        router.push(`/dashboard/user-management`);
        break;
      case "payment":
        // Payments has no detail page, redirect to list
        router.push(`/dashboard/payments-billing`);
        break;
    }
  };

  const isLoading = debouncedSearch.length >= 2 && results === undefined;
  const hasResults =
    results &&
    (results.permits.length > 0 ||
      results.applications.length > 0 ||
      results.owners.length > 0 ||
      results.businesses.length > 0 ||
      results.users.length > 0 ||
      results.payments.length > 0);

  const getStatusVariant = (
    status: string
  ): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case "Active":
      case "Released":
      case "completed":
        return "default";
      case "Pending":
      case "Pending Payment":
      case "Assessment":
      case "Approval":
      case "pending":
        return "secondary";
      case "Rejected":
      case "Expired":
      case "failed":
      case "cancelled":
        return "destructive";
      default:
        return "outline";
    }
  };

  return (
    <CommandDialog
      open={open}
      onOpenChange={onOpenChange}
      title="Global Search"
      description="Search across permits, applications, businesses, and more..."
    >
      <CommandInput
        placeholder="Type to search permits, users, or documents..."
        value={search}
        onValueChange={setSearch}
      />
      <CommandList className="max-h-[400px]">
        {debouncedSearch.length < 2 && (
          <CommandEmpty>
            <div className="text-muted-foreground">
              Type at least 2 characters to search...
            </div>
          </CommandEmpty>
        )}

        {isLoading && (
          <div className="flex items-center justify-center py-6">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        )}

        {debouncedSearch.length >= 2 && results && !hasResults && (
          <CommandEmpty>No results found for "{debouncedSearch}"</CommandEmpty>
        )}

        {/* Applications */}
        {results?.applications && results.applications.length > 0 && (
          <>
            <CommandGroup heading="Applications">
              {results.applications.map((app) => (
                <CommandItem
                  key={app._id}
                  value={`application ${app.applicationNumber} ${app.ownerName} ${app.businessName}`}
                  onSelect={() =>
                    handleSelect("application", app._id, app.status)
                  }
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <div className="flex flex-col">
                      <span className="font-medium">
                        {app.applicationNumber}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {app.ownerName} • {app.businessName}
                      </span>
                    </div>
                  </div>
                  <Badge variant={getStatusVariant(app.status)} className="ml-2">
                    {app.status}
                  </Badge>
                </CommandItem>
              ))}
            </CommandGroup>
            <CommandSeparator />
          </>
        )}

        {/* Permits */}
        {results?.permits && results.permits.length > 0 && (
          <>
            <CommandGroup heading="Permits">
              {results.permits.map((permit) => (
                <CommandItem
                  key={permit._id}
                  value={`permit ${permit.permitNumber} ${permit.ownerName} ${permit.businessName}`}
                  onSelect={() => handleSelect("permit", permit._id)}
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <Award className="h-4 w-4 text-muted-foreground" />
                    <div className="flex flex-col">
                      <span className="font-medium">
                        {permit.permitNumber || "No Permit Number"}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {permit.ownerName} • {permit.businessName}
                      </span>
                    </div>
                  </div>
                  <Badge
                    variant={getStatusVariant(permit.status)}
                    className="ml-2"
                  >
                    {permit.status}
                  </Badge>
                </CommandItem>
              ))}
            </CommandGroup>
            <CommandSeparator />
          </>
        )}

        {/* Business Owners */}
        {results?.owners && results.owners.length > 0 && (
          <>
            <CommandGroup heading="Business Owners">
              {results.owners.map((owner) => (
                <CommandItem
                  key={owner._id}
                  value={`owner ${owner.firstName} ${owner.lastName} ${owner.email} ${owner.mobile}`}
                  onSelect={() => handleSelect("owner", owner._id)}
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <div className="flex flex-col">
                      <span className="font-medium">
                        {owner.firstName} {owner.lastName}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {owner.email} • {owner.mobile}
                      </span>
                    </div>
                  </div>
                  {owner.isBlacklisted && (
                    <Badge variant="destructive" className="ml-2">
                      Blacklisted
                    </Badge>
                  )}
                </CommandItem>
              ))}
            </CommandGroup>
            <CommandSeparator />
          </>
        )}

        {/* Businesses */}
        {results?.businesses && results.businesses.length > 0 && (
          <>
            <CommandGroup heading="Businesses">
              {results.businesses.map((business) => (
                <CommandItem
                  key={business._id}
                  value={`business ${business.name} ${business.ownerName} ${business.email}`}
                  onSelect={() => handleSelect("business", business._id)}
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4 text-muted-foreground" />
                    <div className="flex flex-col">
                      <span className="font-medium">{business.name}</span>
                      <span className="text-xs text-muted-foreground">
                        {business.ownerName} • {business.email}
                      </span>
                    </div>
                  </div>
                  {business.isBlacklisted && (
                    <Badge variant="destructive" className="ml-2">
                      Blacklisted
                    </Badge>
                  )}
                </CommandItem>
              ))}
            </CommandGroup>
            <CommandSeparator />
          </>
        )}

        {/* Users */}
        {results?.users && results.users.length > 0 && (
          <>
            <CommandGroup heading="Users">
              {results.users.map((user) => (
                <CommandItem
                  key={user._id}
                  value={`user ${user.firstName} ${user.lastName} ${user.email} ${user.role} ${user.department}`}
                  onSelect={() => handleSelect("user", user._id)}
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <div className="flex flex-col">
                      <span className="font-medium">
                        {user.firstName} {user.lastName}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {user.role} • {user.department}
                      </span>
                    </div>
                  </div>
                  <Badge
                    variant={getStatusVariant(user.status)}
                    className="ml-2"
                  >
                    {user.status}
                  </Badge>
                </CommandItem>
              ))}
            </CommandGroup>
            <CommandSeparator />
          </>
        )}

        {/* Payments */}
        {results?.payments && results.payments.length > 0 && (
          <CommandGroup heading="Payments">
            {results.payments.map((payment) => (
              <CommandItem
                key={payment._id}
                value={`payment ${payment.transactionNumber} ${payment.paymentMethod}`}
                onSelect={() => handleSelect("payment", payment._id)}
                className="flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <CreditCard className="h-4 w-4 text-muted-foreground" />
                  <div className="flex flex-col">
                    <span className="font-medium">
                      {payment.transactionNumber}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {payment.paymentMethod} •{" "}
                      {new Date(payment.paidAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                <Badge
                  variant={getStatusVariant(payment.status)}
                  className="ml-2"
                >
                  {payment.status}
                </Badge>
              </CommandItem>
            ))}
          </CommandGroup>
        )}
      </CommandList>
    </CommandDialog>
  );
}
