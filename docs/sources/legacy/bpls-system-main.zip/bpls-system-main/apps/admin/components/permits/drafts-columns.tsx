"use client"

import { ColumnDef } from "@tanstack/react-table"
import { ArrowUpDown, Eye, Edit, Trash2, Clock, MessageSquare } from "lucide-react"

import { Button } from "@repo/ui/components/button"
import { Badge } from "@repo/ui/components/badge"
import { Progress } from "@repo/ui/components/progress"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import { formatDate } from "@/lib/utils/formatting"

// Type for draft application
export interface DraftRow {
  id: string
  name: string
  comments: string
  createdAt: string
  updatedAt: string
  currentStep: number
  totalSteps: number
  stepName: string
  formData: {
    ownerName: string
    businessName: string
    businessType: string
  }
}

interface DraftsColumnsProps {
  onContinue?: (draftId: string) => void
  onDelete?: (draftId: string) => void
  onViewComments?: (comments: string) => void
}

// Helper function
const getProgressPercentage = (currentStep: number, totalSteps: number) => {
  return (currentStep / totalSteps) * 100
}

export const createDraftsColumns = (
  props?: DraftsColumnsProps
): ColumnDef<DraftRow>[] => [
  {
    id: "name",
    accessorKey: "name",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Draft Name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const draft = row.original
      return (
        <div className="flex flex-col">
          <span className="font-semibold">{draft.name}</span>
          <span className="text-xs text-muted-foreground">
            Step {draft.currentStep} of {draft.totalSteps} - {draft.stepName}
          </span>
        </div>
      )
    },
    enableHiding: false,
  },
  {
    id: "ownerName",
    accessorFn: (row) => row.formData.ownerName,
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Owner
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      return <div className="text-sm">{row.original.formData.ownerName}</div>
    },
  },
  {
    id: "businessName",
    accessorFn: (row) => row.formData.businessName,
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Business
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      return <div className="text-sm">{row.original.formData.businessName}</div>
    },
  },
  {
    id: "type",
    accessorFn: (row) => row.formData.businessType,
    header: "Type",
    cell: ({ row }) => {
      const type = row.original.formData.businessType
      return (
        <Badge
          variant="outline"
          className={`text-xs ${
            type === "new"
              ? "bg-blue-100 text-blue-800 border-blue-200"
              : "bg-green-100 text-green-800 border-green-200"
          }`}
        >
          {type === "new" ? "New Application" : "Renewal"}
        </Badge>
      )
    },
  },
  {
    id: "progress",
    accessorFn: (row) => getProgressPercentage(row.currentStep, row.totalSteps),
    header: "Progress",
    cell: ({ row }) => {
      const draft = row.original
      const percentage = getProgressPercentage(draft.currentStep, draft.totalSteps)
      return (
        <div className="flex items-center gap-2 min-w-[120px]">
          <Progress value={percentage} className="h-2 flex-1" />
          <span className="text-xs text-muted-foreground whitespace-nowrap">
            {Math.round(percentage)}%
          </span>
        </div>
      )
    },
  },
  {
    id: "comments",
    accessorKey: "comments",
    header: "Comments",
    cell: ({ row }) => {
      const comments = row.original.comments
      return (
        <div className="flex items-center gap-2 max-w-[200px]">
          <span className="text-sm text-muted-foreground truncate">{comments || "N/A"}</span>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 w-6 p-0 flex-shrink-0"
            onClick={(e) => {
              e.stopPropagation()
              props?.onViewComments?.(comments)
            }}
          >
            <MessageSquare className="h-3 w-3" />
            <span className="sr-only">View full comments</span>
          </Button>
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "updatedAt",
    accessorKey: "updatedAt",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Updated
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      return (
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <Clock className="h-3 w-3" />
          <span className="whitespace-nowrap">{formatDate(row.original.updatedAt, "full")}</span>
        </div>
      )
    },
  },
  {
    id: "actions",
    header: "Actions",
    cell: ({ row }) => {
      const draft = row.original
      return (
        <div className="flex items-center gap-1">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={(e) => {
                    e.stopPropagation()
                    props?.onContinue?.(draft.id)
                  }}
                  className="h-8 w-8"
                >
                  <Eye className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Continue editing</p>
              </TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                >
                  <Edit className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Rename draft</p>
              </TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={(e) => {
                    e.stopPropagation()
                    props?.onDelete?.(draft.id)
                  }}
                  className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Delete draft</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      )
    },
    enableSorting: false,
    enableHiding: false,
  },
  // Additional columns (hidden by default)
  {
    id: "createdAt",
    accessorKey: "createdAt",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Created
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      return (
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <Clock className="h-3 w-3" />
          <span className="whitespace-nowrap">{formatDate(row.original.createdAt, "full")}</span>
        </div>
      )
    },
    enableHiding: true,
  },
  {
    id: "stepName",
    accessorKey: "stepName",
    header: "Current Step",
    cell: ({ row }) => {
      return <div className="text-sm">{row.original.stepName}</div>
    },
    enableHiding: true,
  },
]
