"use client";

import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { useQuery, useMutation } from "convex/react";
import { Save, Eye, EyeOff, Loader2, Upload, Trash2 } from "lucide-react";
import dynamic from "next/dynamic";
import type { Editor } from "@tiptap/react";

import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@repo/ui/components/tabs";
import { Skeleton } from "@repo/ui/components/skeleton";
import { Badge } from "@repo/ui/components/badge";
import { Separator } from "@repo/ui/components/separator";
import { api } from "@repo/backend/convex/_generated/api";
import {
  getSamplePermitData,
  validatePermitTemplate,
} from "@/lib/utils/permit-template-renderer";
import {
  parseTipTapContent,
  tipTapToPlainText,
  type TipTapDoc,
} from "@/lib/utils/permit-tiptap-converter";
import { PermitMacroPicker } from "./permit-macro-picker";

// Dynamically import PDF components and TipTap editor to avoid SSR issues
const PermitLayoutPreview = dynamic(() => import("./permit-layout-preview"), {
  ssr: false,
  loading: () => <Skeleton className="h-full w-full" />,
});

const PermitTipTapEditor = dynamic(() => import("./permit-tiptap-editor"), {
  ssr: false,
  loading: () => <Skeleton className="h-full w-full" />,
});

interface PermitLayoutEditorProps {
  onSave: () => void;
  readOnly?: boolean;
}

export function PermitLayoutEditor({
  onSave,
  readOnly = false,
}: PermitLayoutEditorProps) {
  const layout = useQuery(api.permitLayouts.get);
  const platformSettings = useQuery(api.platformSettings.get);
  const backgroundImageUrl = useQuery(api.permitLayouts.getBackgroundImageUrl);
  const updateLayout = useMutation(api.permitLayouts.update);
  const generateUploadUrl = useMutation(api.permitLayouts.generateUploadUrl);

  // Form state
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [paperSize, setPaperSize] = useState<"LETTER" | "A4" | "LEGAL">("LETTER");
  const [orientation, setOrientation] = useState<"portrait" | "landscape">("portrait");
  const [marginTop, setMarginTop] = useState(15);
  const [marginRight, setMarginRight] = useState(15);
  const [marginBottom, setMarginBottom] = useState(15);
  const [marginLeft, setMarginLeft] = useState(15);
  const [headerTemplate, setHeaderTemplate] = useState("");
  const [bodyTemplate, setBodyTemplate] = useState("");
  const [footerTemplate, setFooterTemplate] = useState("");
  // TipTap parsed content for editor initialization
  const [headerContent, setHeaderContent] = useState<TipTapDoc | null>(null);
  const [bodyContent, setBodyContent] = useState<TipTapDoc | null>(null);
  const [footerContent, setFooterContent] = useState<TipTapDoc | null>(null);
  const [contentInitialized, setContentInitialized] = useState(false);
  // TipTap editor refs for macro insertion
  const headerEditorRef = useRef<Editor | null>(null);
  const bodyEditorRef = useRef<Editor | null>(null);
  const footerEditorRef = useRef<Editor | null>(null);

  // Background image state
  const [backgroundImageStorageId, setBackgroundImageStorageId] = useState<string | null>(null);
  const [backgroundImageOpacity, setBackgroundImageOpacity] = useState(0.3);
  const [backgroundImageWidth, setBackgroundImageWidth] = useState<number | undefined>(undefined);
  const [backgroundImageHeight, setBackgroundImageHeight] = useState<number | undefined>(undefined);
  const [isUploadingBackground, setIsUploadingBackground] = useState(false);
  const [localBackgroundPreviewUrl, setLocalBackgroundPreviewUrl] = useState<string | null>(null);
  const backgroundFileInputRef = useRef<HTMLInputElement>(null);

  // Effective background image URL: prefer DB URL (persisted), fall back to local blob URL (pre-save)
  const effectiveBackgroundImageUrl = backgroundImageUrl ?? localBackgroundPreviewUrl;

  // UI state
  const [showPreview, setShowPreview] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const [activeTab, setActiveTab] = useState("header");

  // Debounced templates for preview
  const [debouncedHeader, setDebouncedHeader] = useState("");
  const [debouncedBody, setDebouncedBody] = useState("");
  const [debouncedFooter, setDebouncedFooter] = useState("");

  // Debounce template updates for preview
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedHeader(headerTemplate);
      setDebouncedBody(bodyTemplate);
      setDebouncedFooter(footerTemplate);
    }, 300);
    return () => clearTimeout(timer);
  }, [headerTemplate, bodyTemplate, footerTemplate]);

  // Initialize form from layout data
  useEffect(() => {
    if (layout) {
      setName(layout.name);
      setDescription(layout.description || "");
      setPaperSize(layout.paperSize);
      setOrientation(layout.orientation);
      setMarginTop(layout.marginTop);
      setMarginRight(layout.marginRight);
      setMarginBottom(layout.marginBottom);
      setMarginLeft(layout.marginLeft);
      setHeaderTemplate(layout.headerTemplate);
      setBodyTemplate(layout.bodyTemplate);
      setFooterTemplate(layout.footerTemplate);
      // Parse TipTap content from templates (auto-detects plain text vs TipTap JSON)
      setHeaderContent(parseTipTapContent(layout.headerTemplate));
      setBodyContent(parseTipTapContent(layout.bodyTemplate));
      setFooterContent(parseTipTapContent(layout.footerTemplate));
      setContentInitialized(true);
      setBackgroundImageStorageId(layout.backgroundImageStorageId ?? null);
      setBackgroundImageOpacity(layout.backgroundImageOpacity ?? 0.3);
      setBackgroundImageWidth(layout.backgroundImageWidth);
      setBackgroundImageHeight(layout.backgroundImageHeight);
      setHasChanges(false);
    }
  }, [layout]);

  // Track changes
  const markChanged = useCallback(() => {
    if (!readOnly) {
      setHasChanges(true);
    }
  }, [readOnly]);

  // Sample data for preview
  const sampleData = useMemo(() => {
    const data = getSamplePermitData();
    // Add platform settings data
    if (platformSettings) {
      data.municipalityName = platformSettings.municipalityName || "Municipality";
      data.provinceName = platformSettings.provinceName || "Province";
      data.fullAddress = platformSettings.fullAddress || "";
      data.mayorName = platformSettings.mayorName || "Mayor";
      data.mayorTitle = platformSettings.mayorTitle || "Municipal Mayor";
      data.treasurerName = platformSettings.treasurerName || "Treasurer";
    }
    return data;
  }, [platformSettings]);

  // Validate templates - extract plain text from TipTap JSON for macro validation
  const headerPlainText = useMemo(
    () => {
      try { return tipTapToPlainText(parseTipTapContent(headerTemplate)); } catch { return headerTemplate; }
    },
    [headerTemplate]
  );
  const bodyPlainText = useMemo(
    () => {
      try { return tipTapToPlainText(parseTipTapContent(bodyTemplate)); } catch { return bodyTemplate; }
    },
    [bodyTemplate]
  );
  const footerPlainText = useMemo(
    () => {
      try { return tipTapToPlainText(parseTipTapContent(footerTemplate)); } catch { return footerTemplate; }
    },
    [footerTemplate]
  );
  const headerValidation = useMemo(
    () => validatePermitTemplate(headerPlainText),
    [headerPlainText]
  );
  const bodyValidation = useMemo(
    () => validatePermitTemplate(bodyPlainText),
    [bodyPlainText]
  );
  const footerValidation = useMemo(
    () => validatePermitTemplate(footerPlainText),
    [footerPlainText]
  );

  // Handle save
  const handleSave = async () => {
    if (readOnly) return;
    setIsSaving(true);
    try {
      const updateArgs: Parameters<typeof updateLayout>[0] = {
        name,
        description: description || undefined,
        paperSize,
        orientation,
        marginTop,
        marginRight,
        marginBottom,
        marginLeft,
        fontSize: 12,
        fontFamily: "Helvetica",
        headerTemplate,
        bodyTemplate,
        footerTemplate,
        showLogo: true,
        showMunicipalSeal: true,
        showQrCode: true,
        qrCodeSize: 80,
      };

      // Handle background image
      if (backgroundImageStorageId) {
        updateArgs.backgroundImageStorageId = backgroundImageStorageId as Parameters<typeof updateLayout>[0]["backgroundImageStorageId"];
        updateArgs.backgroundImageOpacity = backgroundImageOpacity;
        updateArgs.backgroundImageWidth = backgroundImageWidth;
        updateArgs.backgroundImageHeight = backgroundImageHeight;
      } else if (layout?.backgroundImageStorageId && !backgroundImageStorageId) {
        updateArgs.clearBackgroundImage = true;
      }

      await updateLayout(updateArgs);
      setHasChanges(false);
      onSave();
    } catch (error) {
      console.error("Failed to save layout:", error);
    } finally {
      setIsSaving(false);
    }
  };

  // Insert macro into the active TipTap editor
  const insertMacro = (macro: string) => {
    if (readOnly) return;
    const macroText = `{{${macro}}}`;

    let editorRef: React.MutableRefObject<Editor | null> | null = null;
    if (activeTab === "header") editorRef = headerEditorRef;
    else if (activeTab === "body") editorRef = bodyEditorRef;
    else if (activeTab === "footer") editorRef = footerEditorRef;

    if (editorRef?.current) {
      editorRef.current.chain().focus().insertContent(macroText).run();
      markChanged();
    }
  };

  // Background image upload handler
  const handleBackgroundUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type and size
    if (!file.type.startsWith("image/")) {
      alert("Please select an image file.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      alert("Image must be less than 5MB.");
      return;
    }

    setIsUploadingBackground(true);
    try {
      // Create local preview URL immediately for instant feedback
      if (localBackgroundPreviewUrl) {
        URL.revokeObjectURL(localBackgroundPreviewUrl);
      }
      setLocalBackgroundPreviewUrl(URL.createObjectURL(file));

      const uploadUrl = await generateUploadUrl();
      const result = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });
      const { storageId } = await result.json();
      setBackgroundImageStorageId(storageId);
      markChanged();
    } catch (error) {
      console.error("Failed to upload background image:", error);
    } finally {
      setIsUploadingBackground(false);
      // Reset file input
      if (backgroundFileInputRef.current) {
        backgroundFileInputRef.current.value = "";
      }
    }
  };

  // Remove background image handler
  const handleRemoveBackground = () => {
    setBackgroundImageStorageId(null);
    setBackgroundImageOpacity(0.3);
    setBackgroundImageWidth(undefined);
    setBackgroundImageHeight(undefined);
    if (localBackgroundPreviewUrl) {
      URL.revokeObjectURL(localBackgroundPreviewUrl);
      setLocalBackgroundPreviewUrl(null);
    }
    markChanged();
  };

  if (!layout) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center justify-between pb-4 border-b">
        <div className="flex items-center gap-4">
          <div className="space-y-1">
            <Input
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                markChanged();
              }}
              className="font-medium text-lg h-8 w-64"
              placeholder="Layout name"
              disabled={readOnly}
            />
          </div>
          {hasChanges && (
            <Badge variant="outline" className="text-yellow-600">
              Unsaved changes
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowPreview(!showPreview)}
          >
            {showPreview ? (
              <>
                <EyeOff className="mr-2 h-4 w-4" />
                Hide Preview
              </>
            ) : (
              <>
                <Eye className="mr-2 h-4 w-4" />
                Show Preview
              </>
            )}
          </Button>
          {!readOnly && (
            <Button
              size="sm"
              onClick={handleSave}
              disabled={isSaving || !hasChanges}
            >
              {isSaving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save
                </>
              )}
            </Button>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-1 gap-4 pt-4 overflow-hidden">
        {/* Editor Panel */}
        <div className={`flex flex-col ${showPreview ? "w-1/2" : "w-full"} overflow-hidden`}>
          {/* Settings - Fixed height section */}
          <div className="flex-shrink-0 space-y-4 pr-4 pb-4 overflow-y-auto max-h-[300px]">
            {/* Paper & Font Settings */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Paper Size</Label>
                <Select
                  value={paperSize}
                  onValueChange={(value: "LETTER" | "A4" | "LEGAL") => {
                    setPaperSize(value);
                    markChanged();
                  }}
                  disabled={readOnly}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="LETTER">Letter (8.5 x 11 in)</SelectItem>
                    <SelectItem value="A4">A4 (210 x 297 mm)</SelectItem>
                    <SelectItem value="LEGAL">Legal (8.5 x 14 in)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Orientation</Label>
                <Select
                  value={orientation}
                  onValueChange={(value: "portrait" | "landscape") => {
                    setOrientation(value);
                    markChanged();
                  }}
                  disabled={readOnly}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="portrait">Portrait</SelectItem>
                    <SelectItem value="landscape">Landscape</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Margins */}
            <div className="space-y-2">
              <Label>Margins (mm)</Label>
              <div className="grid grid-cols-4 gap-2">
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Top</span>
                  <Input
                    type="number"
                    min={0}
                    max={100}
                    value={marginTop}
                    onChange={(e) => {
                      setMarginTop(Number(e.target.value));
                      markChanged();
                    }}
                    disabled={readOnly}
                  />
                </div>
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Right</span>
                  <Input
                    type="number"
                    min={0}
                    max={100}
                    value={marginRight}
                    onChange={(e) => {
                      setMarginRight(Number(e.target.value));
                      markChanged();
                    }}
                    disabled={readOnly}
                  />
                </div>
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Bottom</span>
                  <Input
                    type="number"
                    min={0}
                    max={100}
                    value={marginBottom}
                    onChange={(e) => {
                      setMarginBottom(Number(e.target.value));
                      markChanged();
                    }}
                    disabled={readOnly}
                  />
                </div>
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Left</span>
                  <Input
                    type="number"
                    min={0}
                    max={100}
                    value={marginLeft}
                    onChange={(e) => {
                      setMarginLeft(Number(e.target.value));
                      markChanged();
                    }}
                    disabled={readOnly}
                  />
                </div>
              </div>
            </div>

            {/* Background Image */}
            <div className="space-y-3">
              <div>
                <Label>Background Image</Label>
                <p className="text-xs text-muted-foreground mt-1">
                  Add a background image (pre-printed form, watermark, decorative border) behind the permit content.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <input
                  ref={backgroundFileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleBackgroundUpload}
                  className="hidden"
                  disabled={readOnly || isUploadingBackground}
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => backgroundFileInputRef.current?.click()}
                  disabled={readOnly || isUploadingBackground}
                >
                  {isUploadingBackground ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Upload className="mr-2 h-4 w-4" />
                      {backgroundImageStorageId || effectiveBackgroundImageUrl ? "Replace" : "Upload"}
                    </>
                  )}
                </Button>
                {(backgroundImageStorageId || effectiveBackgroundImageUrl) && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleRemoveBackground}
                    disabled={readOnly}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Remove
                  </Button>
                )}
              </div>
              {effectiveBackgroundImageUrl && (
                <div className="flex items-start gap-3">
                  <img
                    src={effectiveBackgroundImageUrl}
                    alt="Background preview"
                    className="w-16 h-16 object-cover rounded border"
                  />
                  <div className="flex-1 space-y-2">
                    <div>
                      <Label className="text-xs text-muted-foreground">Opacity: {Math.round(backgroundImageOpacity * 100)}%</Label>
                      <input
                        type="range"
                        min={0}
                        max={100}
                        value={Math.round(backgroundImageOpacity * 100)}
                        onChange={(e) => {
                          setBackgroundImageOpacity(Number(e.target.value) / 100);
                          markChanged();
                        }}
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-primary"
                        disabled={readOnly}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">Width (mm)</Label>
                        <Input
                          type="number"
                          min={10}
                          max={500}
                          value={backgroundImageWidth ?? ""}
                          onChange={(e) => {
                            const val = e.target.value;
                            setBackgroundImageWidth(val ? Number(val) : undefined);
                            markChanged();
                          }}
                          placeholder="Auto (fill page)"
                          className="h-8 text-xs"
                          disabled={readOnly}
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">Height (mm)</Label>
                        <Input
                          type="number"
                          min={10}
                          max={500}
                          value={backgroundImageHeight ?? ""}
                          onChange={(e) => {
                            const val = e.target.value;
                            setBackgroundImageHeight(val ? Number(val) : undefined);
                            markChanged();
                          }}
                          placeholder="Auto (fill page)"
                          className="h-8 text-xs"
                          disabled={readOnly}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          <Separator className="flex-shrink-0" />

          {/* Template Sections - Fills remaining space */}
          <div className="flex-1 flex flex-col min-h-0 pt-4 pr-4">
            <div className="flex items-center justify-between flex-shrink-0 mb-2">
              <Label>Template Sections</Label>
              {!readOnly && <PermitMacroPicker onSelect={insertMacro} />}
            </div>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col min-h-0">
              <TabsList className="grid w-full grid-cols-3 flex-shrink-0">
                <TabsTrigger value="header">Header</TabsTrigger>
                <TabsTrigger value="body">Body</TabsTrigger>
                <TabsTrigger value="footer">Footer</TabsTrigger>
              </TabsList>
              <TabsContent value="header" className="flex-1 flex flex-col min-h-0 mt-2">
                <div className="flex-1 overflow-hidden rounded-md border">
                  {contentInitialized && (
                    <PermitTipTapEditor
                      content={headerContent}
                      onChange={(json) => {
                        setHeaderTemplate(json);
                        markChanged();
                      }}
                      placeholder="Enter header template..."
                      disabled={readOnly}
                      editorRef={headerEditorRef}
                    />
                  )}
                </div>
                {headerValidation.warnings.length > 0 && (
                  <p className="text-xs text-yellow-600 mt-1 flex-shrink-0">
                    {headerValidation.warnings.join(", ")}
                  </p>
                )}
              </TabsContent>
              <TabsContent value="body" className="flex-1 flex flex-col min-h-0 mt-2">
                <div className="flex-1 overflow-hidden rounded-md border">
                  {contentInitialized && (
                    <PermitTipTapEditor
                      content={bodyContent}
                      onChange={(json) => {
                        setBodyTemplate(json);
                        markChanged();
                      }}
                      placeholder="Enter body template (use {{LINES_OF_BUSINESS}} for business activities)..."
                      disabled={readOnly}
                      editorRef={bodyEditorRef}
                    />
                  )}
                </div>
                {bodyValidation.warnings.length > 0 && (
                  <p className="text-xs text-yellow-600 mt-1 flex-shrink-0">
                    {bodyValidation.warnings.join(", ")}
                  </p>
                )}
              </TabsContent>
              <TabsContent value="footer" className="flex-1 flex flex-col min-h-0 mt-2">
                <div className="flex-1 overflow-hidden rounded-md border">
                  {contentInitialized && (
                    <PermitTipTapEditor
                      content={footerContent}
                      onChange={(json) => {
                        setFooterTemplate(json);
                        markChanged();
                      }}
                      placeholder="Enter footer template..."
                      disabled={readOnly}
                      editorRef={footerEditorRef}
                    />
                  )}
                </div>
                {footerValidation.warnings.length > 0 && (
                  <p className="text-xs text-yellow-600 mt-1 flex-shrink-0">
                    {footerValidation.warnings.join(", ")}
                  </p>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Preview Panel */}
        {showPreview && (
          <div className="w-1/2 border rounded-lg overflow-hidden bg-muted/30">
            <div className="p-2 border-b bg-muted/50 flex items-center justify-between">
              <span className="text-sm font-medium">Preview (Sample Data)</span>
              <Badge variant="outline" className="text-xs">
                {paperSize} • {orientation}
              </Badge>
            </div>
            <div className="h-[calc(100%-40px)]">
              <PermitLayoutPreview
                headerTemplate={debouncedHeader}
                bodyTemplate={debouncedBody}
                footerTemplate={debouncedFooter}
                paperSize={paperSize}
                orientation={orientation}
                marginTop={marginTop}
                marginRight={marginRight}
                marginBottom={marginBottom}
                marginLeft={marginLeft}
                data={sampleData}
                backgroundImageUrl={effectiveBackgroundImageUrl ?? undefined}
                backgroundImageOpacity={backgroundImageOpacity}
                backgroundImageWidth={backgroundImageWidth}
                backgroundImageHeight={backgroundImageHeight}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
