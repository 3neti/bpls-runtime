"use client"

import { Code, ChevronDown } from "lucide-react"
import { useQuery } from "convex/react"

import { Button } from "@repo/ui/components/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import { Skeleton } from "@repo/ui/components/skeleton"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

interface BillingGroupMacroPickerProps {
  billingGroupId: Id<"billing_groups">
  onSelect: (macro: string) => void
}

export function BillingGroupMacroPicker({
  billingGroupId,
  onSelect,
}: BillingGroupMacroPickerProps) {
  // Fetch available macros including custom fields
  const macros = useQuery(api.billingGroupPrintLayouts.getAvailableMacros, {
    billingGroupId,
  })

  // Group macros by category
  type MacroItem = NonNullable<typeof macros>[number];
  type MacroRecord = Record<string, MacroItem[]>;
  const groupedMacros = macros?.reduce(
    (acc: MacroRecord, macro: MacroItem) => {
      if (!acc[macro.category]) {
        acc[macro.category] = []
      }
      acc[macro.category].push(macro)
      return acc
    },
    {} as MacroRecord
  )

  // Order of categories to display
  const categories = [
    "Transaction",
    "Billing Group",
    "Line Items",
    "Custom Fields",
    "System",
  ] as const

  if (!macros) {
    return (
      <Button variant="outline" size="sm" disabled>
        <Skeleton className="h-4 w-4 mr-2" />
        Loading...
      </Button>
    )
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm">
          <Code className="mr-2 h-4 w-4" />
          Insert Macro
          <ChevronDown className="ml-2 h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-80 max-h-[400px] overflow-y-auto" align="end">
        <DropdownMenuLabel>Available Macros</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {categories.map((category, idx) => {
          const categoryMacros = groupedMacros?.[category]
          if (!categoryMacros || categoryMacros.length === 0) return null

          return (
            <div key={category}>
              {idx > 0 && <DropdownMenuSeparator />}
              <DropdownMenuGroup>
                <DropdownMenuLabel className="text-xs text-muted-foreground">
                  {category === "Line Items" ? "Line Items" : `${category} Fields`}
                </DropdownMenuLabel>
                {categoryMacros.map((macro: MacroItem) => (
                  <DropdownMenuItem
                    key={macro.key}
                    onClick={() => onSelect(macro.key)}
                    className="flex flex-col items-start"
                  >
                    <div className="flex items-center gap-2">
                      <code className="text-xs bg-muted px-1.5 py-0.5 rounded font-mono">
                        {`{{${macro.key}}}`}
                      </code>
                    </div>
                    <span className="text-xs text-muted-foreground mt-0.5">
                      {macro.description}
                    </span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuGroup>
            </div>
          )
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
