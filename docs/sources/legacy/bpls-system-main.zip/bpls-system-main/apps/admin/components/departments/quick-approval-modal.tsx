/**
 * Quick Approval Modal
 *
 * Modal dialog for quick permit approvals/rejections from the table view.
 * Wraps the ClearanceMultiFeeApprovalForm for inline approvals without navigating to detail page.
 */

"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { ClearanceMultiFeeApprovalForm } from "./clearance-multi-fee-approval-form"
import { getFeesByDepartment } from "@/lib/data/department-fees"
import type { ClearanceMultiFeeApprovalFormValues } from "./clearance-multi-fee-approval-form"
import type { DepartmentPermit } from "@/lib/types/department"
import type { ClearanceConfig } from "@/lib/types/clearance"

interface QuickApprovalModalProps {
  /** Modal open state */
  open: boolean
  /** Callback to close modal */
  onClose: () => void
  /** Permit being reviewed */
  permit: DepartmentPermit | null
  /** Clearance configuration */
  clearanceConfig: ClearanceConfig
  /** Action mode: approve or reject */
  mode: "approve" | "reject"
  /** Callback when approval is submitted */
  onApproveSubmit?: (permitId: string, values: ClearanceMultiFeeApprovalFormValues) => void
  /** Callback when rejection is submitted */
  onRejectSubmit?: (permitId: string) => void
}

/**
 * Quick Approval Modal Component
 *
 * Provides inline approval/rejection interface without leaving the table view.
 * Reuses the ClearanceMultiFeeApprovalForm component.
 */
export function QuickApprovalModal({
  open,
  onClose,
  permit,
  clearanceConfig,
  mode,
  onApproveSubmit,
  onRejectSubmit,
}: QuickApprovalModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)

  if (!permit) return null

  // Get available fees for this department
  const availableFees = getFeesByDepartment(clearanceConfig.department.id)

  const handleApprove = (values: ClearanceMultiFeeApprovalFormValues) => {
    setIsSubmitting(true)
    try {
      if (onApproveSubmit) {
        onApproveSubmit(permit.id, values)
      }
      onClose()
    } catch (error) {
      console.error("Approval failed:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleReject = () => {
    setIsSubmitting(true)
    try {
      if (onRejectSubmit) {
        onRejectSubmit(permit.id)
      }
      onClose()
    } catch (error) {
      console.error("Rejection failed:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {mode === "approve" ? "Quick Approval" : "Reject Application"}
          </DialogTitle>
          <DialogDescription>
            {mode === "approve"
              ? `Review and approve ${clearanceConfig.certificateName} for ${permit.businessName}`
              : `Reject ${clearanceConfig.certificateName} for ${permit.businessName}`}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Permit Information */}
          <div className="bg-muted/50 rounded-lg p-4 space-y-2">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Owner:</span>
                <p className="font-medium">{permit.ownerName}</p>
              </div>
              <div>
                <span className="text-muted-foreground">Business:</span>
                <p className="font-medium">{permit.businessName}</p>
              </div>
              <div>
                <span className="text-muted-foreground">Application Date:</span>
                <p className="font-medium">
                  {new Date(permit.applicationDate!).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
              </div>
              <div>
                <span className="text-muted-foreground">Status:</span>
                <p className="font-medium">{permit.status}</p>
              </div>
            </div>
          </div>

          {/* Approval Form */}
          {mode === "approve" ? (
            <ClearanceMultiFeeApprovalForm
              departmentName={clearanceConfig.department.name}
              certificateName={clearanceConfig.certificateName}
              applicationNumber={permit.id}
              availableFees={availableFees}
              onApprove={handleApprove}
              onReject={mode === "approve" ? handleReject : undefined}
              feeLibraryUrl={`/${clearanceConfig.route}/fees`}
            />
          ) : (
            <div className="p-6 text-center">
              <p className="text-muted-foreground mb-4">
                Are you sure you want to reject this application?
              </p>
              <div className="flex gap-2 justify-center">
                <button
                  onClick={onClose}
                  className="px-4 py-2 border rounded-md hover:bg-muted"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button
                  onClick={handleReject}
                  className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Rejecting..." : "Confirm Rejection"}
                </button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
