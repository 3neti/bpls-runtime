"use client";

import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "convex/react";

import { api } from "@repo/backend/convex/_generated/api";
import { BusinessForm } from "@/components/permit/business-form";
import { Button } from "@repo/ui/components/button";
import { Form } from "@repo/ui/components/form";
import { useToast } from "@/hooks/use-toast";
import { useDefaultLocations } from "@/hooks/use-default-locations";
import { permitFormSchema, permitFormDefaultValues } from "@/lib/schemas/permit-form";
import { Alert, AlertDescription } from "@repo/ui/components/alert";
import { AlertCircle } from "lucide-react";

import type { Doc, Id } from "@repo/backend/convex/_generated/dataModel";
import type { PermitFormSchema } from "@/lib/schemas/permit-form";

interface BusinessFormWrapperProps {
  mode: "create" | "edit";
  initialData?: Doc<"businesses"> & { ownerName?: string };
  ownerId?: Id<"business_owners"> | null;
  onSuccess: () => void;
  onCancel: () => void;
}

export function BusinessFormWrapper({ mode, initialData, ownerId, onSuccess, onCancel }: BusinessFormWrapperProps) {
  const { toast } = useToast();
  const createBusiness = useMutation(api.businesses.create);
  const updateBusiness = useMutation(api.businesses.update);

  // Get default locations for new resources
  const {
    defaultProvinceId,
    defaultCityId,
    defaultBarangayId,
    isLoading: isLoadingDefaults,
  } = useDefaultLocations();

  // Fetch all business owners for selection
  const owners = useQuery(api.businessOwners.list, { includeBlacklisted: false });

  const form = useForm<PermitFormSchema>({
    resolver: zodResolver(permitFormSchema),
    defaultValues: initialData
      ? {
          ...permitFormDefaultValues,
          selectedBusinessId: initialData._id,
          businessName: initialData.name,
          maleEmployeeCount: initialData.maleEmployeeCount,
          femaleEmployeeCount: initialData.femaleEmployeeCount,
          businessContactNumber: initialData.contactNumber,
          dateEstablished: initialData.establishedDate,
          occupancy: initialData.occupancy,
          ownershipType: initialData.ownershipType,
          businessEmail: initialData.email,
          businessAddress: initialData.address,
          businessBuildingName: initialData.buildingName || "",
          businessProvinceId: initialData.provinceId,
          businessCityId: initialData.cityId,
          businessBarangayId: initialData.barangayId,
        }
      : {
          ...permitFormDefaultValues,
        },
    mode: "onChange",
  });

  // Apply default locations when they finish loading (for create mode only)
  useEffect(() => {
    if (mode === "create" && !isLoadingDefaults && !initialData) {
      // Update province if default is available and field is empty
      if (defaultProvinceId && !form.getValues("businessProvinceId")) {
        form.setValue("businessProvinceId", defaultProvinceId);
      }
      // Update city if default is available and field is empty
      if (defaultCityId && !form.getValues("businessCityId")) {
        form.setValue("businessCityId", defaultCityId);
      }
      // Update barangay if default is available and field is empty
      if (defaultBarangayId && !form.getValues("businessBarangayId")) {
        form.setValue("businessBarangayId", defaultBarangayId);
      }
    }
  }, [mode, isLoadingDefaults, defaultProvinceId, defaultCityId, defaultBarangayId, initialData, form]);

  const handleSubmit = async (values: PermitFormSchema) => {
    console.log("handleSubmit", values);
    try {
      // Validate required fields for business creation
      if (!values.businessName?.trim()) {
        toast({
          title: "Error",
          description: "Business name is required",
          variant: "destructive",
        });
        return;
      }

      if (mode === "create") {
        console.log("Creating a business");
        if (!ownerId) {
          toast({
            title: "Error",
            description: "Please select a business owner first",
            variant: "destructive",
          });
          return;
        }

        // Validate business address fields
        if (
          !values.businessAddress?.trim() ||
          !values.businessProvinceId?.trim() ||
          !values.businessCityId?.trim() ||
          !values.businessBarangayId?.trim()
        ) {
          toast({
            title: "Error",
            description: "Business address is required (Address, Province, City, Barangay)",
            variant: "destructive",
          });
          return;
        }

        // Validate ownership type
        if (!values.ownershipType) {
          toast({
            title: "Error",
            description: "Ownership type is required",
            variant: "destructive",
          });
          return;
        }

        // Calculate business scale based on employees (simplified version)
        const employeeCount = (values.maleEmployeeCount || 0) + (values.femaleEmployeeCount || 0) || 1;
        let businessScale = "Micro";
        if (employeeCount >= 200) {
          businessScale = "Large";
        } else if (employeeCount >= 100) {
          businessScale = "Medium";
        } else if (employeeCount >= 10) {
          businessScale = "Small";
        }

        await createBusiness({
          name: values.businessName.trim(),
          ownerId: ownerId,
          businessScale: businessScale,
          annualRevenue: "0-100000", // Default value (linesOfBusiness removed from form)
          establishedDate: values.dateEstablished || new Date().toISOString().split("T")[0],
          dateStarted: values.dateEstablished || new Date().toISOString().split("T")[0],
          address: values.businessAddress.trim(),
          buildingName: values.businessBuildingName?.trim() || undefined,
          provinceId: values.businessProvinceId as Id<"provinces">,
          cityId: values.businessCityId as Id<"cities">,
          barangayId: values.businessBarangayId as Id<"barangays">,
          lineOfBusiness: "retail-trade", // Default value (linesOfBusiness removed from form)
          ownershipType: values.ownershipType,
          occupancy: values.occupancy || "rented",
          permitPaymentCadence: values.permitPaymentCadence || "annual",
          maleEmployeeCount: values.maleEmployeeCount || 0,
          femaleEmployeeCount: values.femaleEmployeeCount || 0,
          contactNumber: values.businessContactNumber || "",
          email: values.businessEmail || "",
          isBlacklisted: false,
        });

        toast({
          title: "Success",
          description: `Business "${values.businessName}" created successfully`,
        });
      } else {
        if (!initialData?._id) {
          throw new Error("Business ID is required for update");
        }

        await updateBusiness({
          id: initialData._id as Id<"businesses">,
          name: values.businessName,
          maleEmployeeCount: values.maleEmployeeCount,
          femaleEmployeeCount: values.femaleEmployeeCount,
          contactNumber: values.businessContactNumber,
          email: values.businessEmail,
          address: values.businessAddress,
          buildingName: values.businessBuildingName?.trim() || undefined,
          provinceId: values.businessProvinceId as Id<"provinces">,
          cityId: values.businessCityId as Id<"cities">,
          barangayId: values.businessBarangayId as Id<"barangays">,
        });

        toast({
          title: "Success",
          description: `Business "${values.businessName}" updated successfully`,
        });
      }

      onSuccess();
    } catch (error) {
      console.error("Business submission error:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "An error occurred while saving the business",
        variant: "destructive",
      });
    }
  };

  // Loading state
  if (owners === undefined) {
    return <div className="p-4">Loading business owners...</div>;
  }

  // No owners available
  if (owners.length === 0 && mode === "create") {
    return (
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          No business owners available. Please create a business owner first before creating a business.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
        <BusinessForm form={form} selectedBusinessId={initialData?._id} onBack={onCancel} />
        <div className="flex justify-end gap-2 pt-4 border-t">
          {/* <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button> */}
          <Button type="submit" disabled={form.formState.isSubmitting}>
            {form.formState.isSubmitting ? "Saving..." : mode === "create" ? "Create Businessx" : "Update Business"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
