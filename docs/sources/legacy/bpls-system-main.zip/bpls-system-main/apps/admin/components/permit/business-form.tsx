"use client";

import { useEffect, useState } from "react";
import type { UseFormReturn } from "react-hook-form";
import type { Id } from "@repo/backend/convex/_generated/dataModel";

import { ArrowLeft, FileText, Check, ChevronsUpDown } from "lucide-react";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@repo/ui/components/tooltip";
import { Popover, PopoverContent, PopoverTrigger } from "@repo/ui/components/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@repo/ui/components/command";
import { Dropzone } from "@repo/ui/components/dropzone";
import { DatePicker } from "@repo/ui/components/date-picker";
import { useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import { cn } from "@/lib/utils";
import { useDefaultLocations } from "@/hooks/use-default-locations";

import type { PermitFormSchema } from "@/lib/schemas/permit-form";
import { FormControl, FormField, FormItem, FormLabel, FormMessage } from "@repo/ui/components/form";

interface BusinessFormProps {
  form: UseFormReturn<PermitFormSchema>;
  selectedBusinessId?: string;
  onBack: () => void;
  ownerType?: "Single" | "Group"; // NEW: Owner type for filtering ownership options
}

export function BusinessForm({ form, selectedBusinessId, onBack, ownerType }: BusinessFormProps) {
  // Lines of Business field array removed - no longer required

  const formValues = form.watch();
  const ownershipType = formValues.ownershipType;

  // Get default locations for new businesses
  const {
    defaultProvinceId,
    defaultCityId,
    defaultBarangayId,
    isLoading: isLoadingDefaults,
  } = useDefaultLocations();

  // Determine if this is a new business (no existing business selected)
  const isNewBusiness = !selectedBusinessId;

  // Location selector state - initialize with defaults for new businesses
  const [selectedProvinceId, setSelectedProvinceId] = useState<string>(
    formValues.businessProvinceId || (isNewBusiness && defaultProvinceId ? defaultProvinceId : "")
  );
  const [selectedCityId, setSelectedCityId] = useState<string>(
    formValues.businessCityId || (isNewBusiness && defaultCityId ? defaultCityId : "")
  );
  const [openProvinceCombobox, setOpenProvinceCombobox] = useState(false);
  const [openCityCombobox, setOpenCityCombobox] = useState(false);
  const [openBarangayCombobox, setOpenBarangayCombobox] = useState(false);

  // Location data queries
  const provinces = useQuery(api.locations.listProvinces);
  const cities = useQuery(
    api.locations.listCitiesByProvince,
    selectedProvinceId ? { provinceId: selectedProvinceId as Id<"provinces"> } : "skip"
  );
  const barangays = useQuery(
    api.locations.listBarangaysByCity,
    selectedCityId ? { cityId: selectedCityId as Id<"cities"> } : "skip"
  );

  // Update local state when form values change
  useEffect(() => {
    setSelectedProvinceId(formValues.businessProvinceId || "");
  }, [formValues.businessProvinceId]);

  useEffect(() => {
    setSelectedCityId(formValues.businessCityId || "");
  }, [formValues.businessCityId]);

  // Clear dependent fields when parent changes
  useEffect(() => {
    if (formValues.businessProvinceId && selectedProvinceId !== formValues.businessProvinceId) {
      // Province changed, reset city and barangay
      form.setValue("businessCityId", "");
      form.setValue("businessBarangayId", "");
      setSelectedCityId("");
    }
  }, [formValues.businessProvinceId, selectedProvinceId, form]);

  useEffect(() => {
    if (formValues.businessCityId && selectedCityId !== formValues.businessCityId) {
      // City changed, reset barangay
      form.setValue("businessBarangayId", "");
    }
  }, [formValues.businessCityId, selectedCityId, form]);

  // Apply all default locations at once when they finish loading (for new businesses only)
  // This sets province, city, and barangay together to avoid issues with cascade clearing
  useEffect(() => {
    if (isNewBusiness && !isLoadingDefaults && defaultProvinceId && !formValues.businessProvinceId) {
      // Set local state FIRST to prevent the clearing useEffect from triggering
      setSelectedProvinceId(defaultProvinceId);
      if (defaultCityId) {
        setSelectedCityId(defaultCityId);
      }

      // Then set form values
      form.setValue("businessProvinceId", defaultProvinceId);
      if (defaultCityId) {
        form.setValue("businessCityId", defaultCityId);
      }
      if (defaultBarangayId) {
        form.setValue("businessBarangayId", defaultBarangayId);
      }
    }
  }, [isNewBusiness, isLoadingDefaults, defaultProvinceId, defaultCityId, defaultBarangayId, formValues.businessProvinceId, form]);

  // Apply default city when cities are loaded (for new businesses only)
  // This handles the case where city wasn't set initially because cities hadn't loaded yet
  useEffect(() => {
    if (isNewBusiness && !isLoadingDefaults && cities && cities.length > 0 && defaultCityId) {
      // Apply default city if province matches and city not already set
      if (!formValues.businessCityId && formValues.businessProvinceId === defaultProvinceId) {
        // Verify the city belongs to the selected province
        const cityExists = cities.some((c: { _id: string }) => c._id === defaultCityId);
        if (cityExists) {
          form.setValue("businessCityId", defaultCityId);
          setSelectedCityId(defaultCityId);
        }
      }
    }
  }, [isNewBusiness, isLoadingDefaults, cities, defaultCityId, defaultProvinceId, formValues.businessCityId, formValues.businessProvinceId, form]);

  // Apply default barangay when barangays are loaded (for new businesses only)
  useEffect(() => {
    if (isNewBusiness && !isLoadingDefaults && barangays && barangays.length > 0 && defaultBarangayId) {
      // Apply default barangay if city matches and barangay not already set
      if (!formValues.businessBarangayId && formValues.businessCityId === defaultCityId) {
        // Verify the barangay belongs to the selected city
        const barangayExists = barangays.some((b: { _id: string }) => b._id === defaultBarangayId);
        if (barangayExists) {
          form.setValue("businessBarangayId", defaultBarangayId);
        }
      }
    }
  }, [isNewBusiness, isLoadingDefaults, barangays, defaultBarangayId, defaultCityId, formValues.businessBarangayId, formValues.businessCityId, form]);

  // Helper function to filter ownership type options based on owner type
  const getOwnershipTypeOptions = () => {
    if (ownerType === "Single") {
      // Single owners can only have Sole Proprietorship
      return [
        <SelectItem key="sole-proprietorship" value="sole-proprietorship">
          Sole Proprietorship
        </SelectItem>,
      ];
    }

    // For "Group" or undefined, show all options
    return [
      <SelectItem key="sole-proprietorship" value="sole-proprietorship">
        Sole Proprietorship
      </SelectItem>,
      <SelectItem key="partnership" value="partnership">
        Partnership
      </SelectItem>,
      <SelectItem key="corporation" value="corporation">
        Corporation
      </SelectItem>,
      <SelectItem key="cooperative" value="cooperative">
        Cooperative
      </SelectItem>,
      <SelectItem key="religious" value="religious">
        Religious Organization
      </SelectItem>,
      <SelectItem key="non-profit" value="non-profit">
        Non-Profit / Non-Stock Organization
      </SelectItem>,
    ];
  };

  // Helper function to get registration date description based on ownership type
  const getRegistrationDateDescription = (ownershipType?: string): string => {
    const normalizedOwnershipType = ownershipType?.toLowerCase().replace(/\s+/g, "-");

    switch (normalizedOwnershipType) {
      case "sole-proprietorship":
        return "DTI Registration Date";
      case "partnership":
        return "CDA Registration Date";
      case "corporation":
        return "SEC Registration Date";
      case "cooperative":
        return "CDA Registration Date";
      case "religious":
        return "SEC Registration Date";
      case "non-profit":
        return "SEC Registration Date";
      default:
        return "Registration Date";
    }
  };

  // Clear groupName when ownership type changes to types that don't require it
  useEffect(() => {
    const requiresGroupName = ["partnership", "corporation", "cooperative"].includes(ownershipType || "");
    if (!requiresGroupName && formValues.groupName) {
      form.setValue("groupName", "");
    }
  }, [ownershipType, formValues.groupName, form]);

  const handleFileSelect = (documentType: string, file: File) => {
    const currentDocuments = formValues.documents || {};
    form.setValue("documents", {
      ...currentDocuments,
      [documentType]: { file, uploaded: true },
    });
  };

  const handleFileRemove = (documentType: string) => {
    const currentDocuments = formValues.documents || {};
    form.setValue("documents", {
      ...currentDocuments,
      [documentType]: { file: null, uploaded: false },
    });
  };

  const getDocumentFile = (documentType: string): File | null => {
    const documents = formValues.documents || {};
    return documents[documentType]?.file || null;
  };

  const renderConditionalDocuments = (ownershipType?: string) => {
    const normalizedOwnershipType = ownershipType?.toLowerCase().replace(/\s+/g, "-");

    if (normalizedOwnershipType === "sole-proprietorship") {
      return (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              DTI Certificate of Business Name Registration
            </CardTitle>
            <CardDescription>Upload your Department of Trade and Industry certificate</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Upload DTI Certificate of Business Name Registration</Label>
              <Dropzone
                onFileSelect={(file) => handleFileSelect("dtiCertificate", file)}
                onFileRemove={() => handleFileRemove("dtiCertificate")}
                selectedFile={getDocumentFile("dtiCertificate")}
              />
            </div>
          </CardContent>
        </Card>
      );
    }

    if (normalizedOwnershipType === "partnership") {
      return (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                SEC Certificate of Registration (Partnership)
              </CardTitle>
              <CardDescription>Upload your SEC Certificate of Registration for Partnership</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload SEC Certificate of Registration (Partnership)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("secCertificate", file)}
                  onFileRemove={() => handleFileRemove("secCertificate")}
                  selectedFile={getDocumentFile("secCertificate")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Articles of Partnership
              </CardTitle>
              <CardDescription>Upload your Articles of Partnership</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Articles of Partnership</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("articlesOfPartnership", file)}
                  onFileRemove={() => handleFileRemove("articlesOfPartnership")}
                  selectedFile={getDocumentFile("articlesOfPartnership")}
                />
              </div>
            </CardContent>
          </Card>
        </>
      );
    }

    if (normalizedOwnershipType === "corporation") {
      return (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                SEC Certificate of Incorporation/Registration
              </CardTitle>
              <CardDescription>Upload your SEC Certificate of Incorporation/Registration</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload SEC Certificate of Incorporation/Registration</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("secCertificate", file)}
                  onFileRemove={() => handleFileRemove("secCertificate")}
                  selectedFile={getDocumentFile("secCertificate")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Articles of Incorporation
              </CardTitle>
              <CardDescription>Upload your Articles of Incorporation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Articles of Incorporation</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("articlesOfIncorporation", file)}
                  onFileRemove={() => handleFileRemove("articlesOfIncorporation")}
                  selectedFile={getDocumentFile("articlesOfIncorporation")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                By-Laws
              </CardTitle>
              <CardDescription>Upload your By-Laws</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload By-Laws</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("bylaws", file)}
                  onFileRemove={() => handleFileRemove("bylaws")}
                  selectedFile={getDocumentFile("bylaws")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Most Recent General Information Sheet (GIS)
              </CardTitle>
              <CardDescription>Upload your most recent GIS filed with SEC</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Most Recent General Information Sheet (GIS)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("gis", file)}
                  onFileRemove={() => handleFileRemove("gis")}
                  selectedFile={getDocumentFile("gis")}
                />
              </div>
            </CardContent>
          </Card>
        </>
      );
    }

    if (normalizedOwnershipType === "cooperative") {
      return (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                CDA Certificate of Registration
              </CardTitle>
              <CardDescription>
                Upload your Cooperative Development Authority Certificate of Registration
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload CDA Certificate of Registration</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("cdaCertificate", file)}
                  onFileRemove={() => handleFileRemove("cdaCertificate")}
                  selectedFile={getDocumentFile("cdaCertificate")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Articles of Cooperation
              </CardTitle>
              <CardDescription>Upload your Articles of Cooperation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Articles of Cooperation</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("articlesOfCooperation", file)}
                  onFileRemove={() => handleFileRemove("articlesOfCooperation")}
                  selectedFile={getDocumentFile("articlesOfCooperation")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                By-Laws
              </CardTitle>
              <CardDescription>Upload your By-Laws</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload By-Laws</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("bylaws", file)}
                  onFileRemove={() => handleFileRemove("bylaws")}
                  selectedFile={getDocumentFile("bylaws")}
                />
              </div>
            </CardContent>
          </Card>
        </>
      );
    }

    if (normalizedOwnershipType === "religious") {
      return (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                SEC Certificate of Incorporation (Religious Corporation)
              </CardTitle>
              <CardDescription>Upload your SEC Certificate of Incorporation for Religious Corporation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload SEC Certificate of Incorporation (Religious Corporation)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("secCertificate", file)}
                  onFileRemove={() => handleFileRemove("secCertificate")}
                  selectedFile={getDocumentFile("secCertificate")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Articles of Incorporation (Religious Corporation)
              </CardTitle>
              <CardDescription>Upload your Articles of Incorporation for Religious Corporation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Articles of Incorporation (Religious Corporation)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("articlesOfIncorporation", file)}
                  onFileRemove={() => handleFileRemove("articlesOfIncorporation")}
                  selectedFile={getDocumentFile("articlesOfIncorporation")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                By-Laws
              </CardTitle>
              <CardDescription>Upload your By-Laws</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload By-Laws</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("bylaws", file)}
                  onFileRemove={() => handleFileRemove("bylaws")}
                  selectedFile={getDocumentFile("bylaws")}
                />
              </div>
            </CardContent>
          </Card>
        </>
      );
    }

    if (normalizedOwnershipType === "non-profit") {
      return (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                SEC Certificate of Incorporation (Non-Stock / Non-Profit)
              </CardTitle>
              <CardDescription>
                Upload your SEC Certificate of Incorporation for Non-Stock/Non-Profit Organization
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload SEC Certificate of Incorporation (Non-Stock / Non-Profit)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("secCertificate", file)}
                  onFileRemove={() => handleFileRemove("secCertificate")}
                  selectedFile={getDocumentFile("secCertificate")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Articles of Incorporation
              </CardTitle>
              <CardDescription>Upload your Articles of Incorporation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Articles of Incorporation</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("articlesOfIncorporation", file)}
                  onFileRemove={() => handleFileRemove("articlesOfIncorporation")}
                  selectedFile={getDocumentFile("articlesOfIncorporation")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                By-Laws
              </CardTitle>
              <CardDescription>Upload your By-Laws</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload By-Laws</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("bylaws", file)}
                  onFileRemove={() => handleFileRemove("bylaws")}
                  selectedFile={getDocumentFile("bylaws")}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Most Recent General Information Sheet (GIS)
              </CardTitle>
              <CardDescription>Upload your most recent GIS filed with SEC</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Upload Most Recent General Information Sheet (GIS)</Label>
                <Dropzone
                  onFileSelect={(file) => handleFileSelect("gis", file)}
                  onFileRemove={() => handleFileRemove("gis")}
                  selectedFile={getDocumentFile("gis")}
                />
              </div>
            </CardContent>
          </Card>
        </>
      );
    }

    return null;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="sm" onClick={onBack} className="cursor-pointer">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Back to Options</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <h3 className="text-lg font-semibold">
          {selectedBusinessId ? "Business Information" : "New Business Information"}
        </h3>
      </div>

      <div className="grid gap-6">
        {/* Business Information Section */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Business Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Row 1: Business Name */}
            <FormField
              control={form.control}
              name="businessName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    Business Name <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Enter business name" required />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Row 1b: Floor Area and Property Index Number (Side by Side) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="businessArea"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Floor Area (sq.m)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="1"
                        step="0.01"
                        placeholder="Enter floor area in square meters"
                        {...field}
                        value={field.value ?? ""}
                        onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="propertyIndexNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Property Index Number</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Enter property index number " />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Row 2: Date Established and Date Started (Two Columns) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="dateEstablished"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date Established</FormLabel>
                    <FormControl>
                      <DatePicker value={field.value} onChange={field.onChange} placeholder="Select date established" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="dateStarted"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Date Started <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <DatePicker value={field.value} onChange={field.onChange} placeholder="Select date started" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Row 2: Occupancy and Ownership Type (Side by Side) */}
            <div className="flex gap-4">
              <FormField
                control={form.control}
                name="occupancy"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormLabel>Occupancy</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select occupancy type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="rented">Rented</SelectItem>
                        <SelectItem value="owned">Owned</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="ownershipType"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormLabel>
                      Ownership Type <span className="text-destructive">*</span>
                    </FormLabel>
                    <Select value={field.value} onValueChange={field.onChange} required>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select ownership type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>{getOwnershipTypeOptions()}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Conditional Group Name Field - Only for Partnership, Corporation, Cooperative */}
            {["partnership", "corporation", "cooperative"].includes(formValues.ownershipType || "") && (
              <FormField
                control={form.control}
                name="groupName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Company/Organization Name <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Enter company or organization name" required />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            {/* Row 3-5: Employee Count */}
            <div className="space-y-3">
              <Label className="text-sm font-medium">Employee Count</Label>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="maleEmployeeCount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Male Employees</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min="0"
                          placeholder="0"
                          {...field}
                          value={field.value ?? 0}
                          onChange={(e) => field.onChange(Number(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="femaleEmployeeCount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Female Employees</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min="0"
                          placeholder="0"
                          {...field}
                          value={field.value ?? 0}
                          onChange={(e) => field.onChange(Number(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="bg-muted px-4 py-2 rounded-lg">
                <p className="text-sm font-medium">
                  Total Employees: {(formValues.maleEmployeeCount || 0) + (formValues.femaleEmployeeCount || 0)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Lines of Business Section - HIDDEN (No longer required) */}
        {/* This section has been removed as Lines of Business is now optional */}

        {/* Contact & Address Information Section */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Contact & Address Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="businessContactNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Business Contact Number</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="+63 912 345 6789" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="businessEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address</FormLabel>
                    <FormControl>
                      <Input {...field} type="email" placeholder="business@example.com" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="businessAddress"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    Street Address <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="House No., Street Name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="businessBuildingName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Building Name <span className="text-destructive">*</span></FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Enter building name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Location Selectors */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Province Selector */}
              <div className="space-y-2 min-w-0">
                <Label>
                  Province <span className="text-destructive">*</span>
                </Label>
                <Popover open={openProvinceCombobox} onOpenChange={setOpenProvinceCombobox}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={openProvinceCombobox}
                      className="w-full justify-between overflow-hidden"
                    >
                      <span className="truncate">
                        {formValues.businessProvinceId
                          ? provinces?.find((p: { _id: string; name: string }) => p._id === formValues.businessProvinceId)?.name
                          : "Select province"}
                      </span>
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-full p-0" align="start">
                    <Command>
                      <CommandInput placeholder="Search province..." />
                      <CommandList>
                        <CommandEmpty>No province found.</CommandEmpty>
                        <CommandGroup>
                          {provinces?.map((province: { _id: string; name: string }) => (
                            <CommandItem
                              key={province._id}
                              value={province.name}
                              onSelect={() => {
                                form.setValue("businessProvinceId", province._id);
                                setSelectedProvinceId(province._id);
                                form.setValue("businessCityId", "");
                                form.setValue("businessBarangayId", "");
                                setSelectedCityId("");
                                setOpenProvinceCombobox(false);
                              }}
                            >
                              <Check
                                className={cn(
                                  "mr-2 h-4 w-4",
                                  formValues.businessProvinceId === province._id ? "opacity-100" : "opacity-0"
                                )}
                              />
                              {province.name}
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
                {form.formState.errors.businessProvinceId && (
                  <p className="text-sm text-red-600">{form.formState.errors.businessProvinceId.message}</p>
                )}
              </div>

              {/* City/Municipality Selector */}
              <div className="space-y-2 min-w-0">
                <Label>
                  City/Municipality <span className="text-destructive">*</span>
                </Label>
                <Popover open={openCityCombobox} onOpenChange={setOpenCityCombobox}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={openCityCombobox}
                      className="w-full justify-between overflow-hidden"
                      disabled={!selectedProvinceId}
                    >
                      <span className="truncate">
                        {formValues.businessCityId
                          ? cities?.find((c: { _id: string; name: string }) => c._id === formValues.businessCityId)?.name
                          : "Select city/municipality"}
                      </span>
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-full p-0" align="start">
                    <Command>
                      <CommandInput placeholder="Search city/municipality..." />
                      <CommandList>
                        <CommandEmpty>No city/municipality found.</CommandEmpty>
                        <CommandGroup>
                          {cities?.map((city: { _id: string; name: string }) => (
                            <CommandItem
                              key={city._id}
                              value={city.name}
                              onSelect={() => {
                                form.setValue("businessCityId", city._id);
                                setSelectedCityId(city._id);
                                form.setValue("businessBarangayId", "");
                                setOpenCityCombobox(false);
                              }}
                            >
                              <Check
                                className={cn(
                                  "mr-2 h-4 w-4",
                                  formValues.businessCityId === city._id ? "opacity-100" : "opacity-0"
                                )}
                              />
                              {city.name}
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
                {form.formState.errors.businessCityId && (
                  <p className="text-sm text-red-600">{form.formState.errors.businessCityId.message}</p>
                )}
              </div>

              {/* Barangay Selector */}
              <div className="space-y-2 min-w-0">
                <Label>
                  Barangay <span className="text-destructive">*</span>
                </Label>
                <Popover open={openBarangayCombobox} onOpenChange={setOpenBarangayCombobox}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={openBarangayCombobox}
                      className="w-full justify-between overflow-hidden"
                      disabled={!selectedCityId}
                    >
                      <span className="truncate">
                        {formValues.businessBarangayId
                          ? barangays?.find((b: { _id: string; name: string }) => b._id === formValues.businessBarangayId)?.name
                          : "Select barangay"}
                      </span>
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-full p-0" align="start">
                    <Command>
                      <CommandInput placeholder="Search barangay..." />
                      <CommandList>
                        <CommandEmpty>No barangay found.</CommandEmpty>
                        <CommandGroup>
                          {barangays?.map((barangay: { _id: string; name: string }) => (
                            <CommandItem
                              key={barangay._id}
                              value={barangay.name}
                              onSelect={() => {
                                form.setValue("businessBarangayId", barangay._id);
                                setOpenBarangayCombobox(false);
                              }}
                            >
                              <Check
                                className={cn(
                                  "mr-2 h-4 w-4",
                                  formValues.businessBarangayId === barangay._id ? "opacity-100" : "opacity-0"
                                )}
                              />
                              {barangay.name}
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
                {form.formState.errors.businessBarangayId && (
                  <p className="text-sm text-red-600">{form.formState.errors.businessBarangayId.message}</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Ownership-Specific Documents Section */}
        <div className="space-y-6 pt-6 border-t">
          <div>
            <h3 className="text-lg font-semibold mb-2">Ownership-Specific Documents</h3>
            <p className="text-muted-foreground mb-6">
              Additional documents required based on your selected ownership type
            </p>
          </div>

          {/* Registration Date and Number Fields - Related to ownership documents */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{getRegistrationDateDescription(ownershipType)}</Label>
              <DatePicker
                value={formValues.registrationDate}
                onChange={(date) => form.setValue("registrationDate", date)}
                placeholder="Select or type date (MM/DD/YYYY)"
              />
            </div>

            <FormField
              control={form.control}
              name="registrationNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Registration Number</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Enter registration number " />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {renderConditionalDocuments(formValues.ownershipType)}
        </div>
      </div>
    </div>
  );
}
