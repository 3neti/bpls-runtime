"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "convex/react";
import { Users, Save, Loader2, Lock } from "lucide-react";
import { Button } from "@repo/ui/components/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form";
import { Input } from "@repo/ui/components/input";
import { Separator } from "@repo/ui/components/separator";
import { Badge } from "@repo/ui/components/badge";
import { api } from "@repo/backend/convex/_generated/api";
import {
  officialsSettingsSchema,
  officialsSettingsDefaultValues,
  type OfficialsSettingsSchema,
} from "@/lib/schemas/settings";
import { usePermissions } from "@/hooks/use-permissions";

interface OfficialsSectionProps {
  settings: NonNullable<ReturnType<typeof useQuery<typeof api.platformSettings.get>>>;
  toast: (options: { title: string; description: string; variant?: "default" | "destructive" }) => void;
}

export function OfficialsSection({ settings, toast }: OfficialsSectionProps) {
  const { canUpdate, isLoading: permissionsLoading } = usePermissions();
  const canEdit = canUpdate("settings:officials");
  const updateSettings = useMutation(api.platformSettings.update);

  const form = useForm<OfficialsSettingsSchema>({
    resolver: zodResolver(officialsSettingsSchema),
    defaultValues: {
      mayorName: settings?.mayorName ?? officialsSettingsDefaultValues.mayorName,
      mayorTitle: settings?.mayorTitle ?? officialsSettingsDefaultValues.mayorTitle,
      treasurerName: settings?.treasurerName ?? officialsSettingsDefaultValues.treasurerName,
      treasurerTitle: settings?.treasurerTitle ?? officialsSettingsDefaultValues.treasurerTitle,
    },
  });

  const onSubmit = async (values: OfficialsSettingsSchema) => {
    try {
      await updateSettings(values);
      toast({
        title: "Settings saved",
        description: "Government officials information has been updated successfully.",
      });
    } catch {
      toast({
        title: "Error",
        description: "Failed to save settings. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Government Officials
              {!canEdit && !permissionsLoading && (
                <Badge variant="secondary" className="ml-2 gap-1">
                  <Lock className="h-3 w-3" />
                  Read Only
                </Badge>
              )}
              {canEdit && (
                <Badge variant="outline" className="ml-2">
                  Admin Only
                </Badge>
              )}
            </CardTitle>
            <CardDescription>
              Configure names and titles of government officials that appear in official documents
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <h4 className="font-medium text-sm text-muted-foreground">Mayor Information</h4>
              <div className="grid gap-4 sm:grid-cols-2">
                <FormField
                  control={form.control}
                  name="mayorName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Mayor Name</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="RAMSES TROY D. OLEGARIO" disabled={!canEdit || permissionsLoading} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="mayorTitle"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Mayor Title</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Municipal Mayor" disabled={!canEdit || permissionsLoading} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <h4 className="font-medium text-sm text-muted-foreground">Treasurer Information</h4>
              <div className="grid gap-4 sm:grid-cols-2">
                <FormField
                  control={form.control}
                  name="treasurerName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Treasurer Name</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="MARIA LUZ F. PULMANO" disabled={!canEdit || permissionsLoading} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="treasurerTitle"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Treasurer Title</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Municipal Treasurer" disabled={!canEdit || permissionsLoading} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {canEdit && (
          <div className="flex justify-end">
            <Button type="submit" disabled={form.formState.isSubmitting}>
              {form.formState.isSubmitting ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Save className="mr-2 h-4 w-4" />
              )}
              Save Changes
            </Button>
          </div>
        )}
      </form>
    </Form>
  );
}
