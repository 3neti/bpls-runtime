/**
 * FeesSummaryCard Component
 *
 * Displays a summary of all fees for a permit application with:
 * - Individual fee breakdowns with descriptions
 * - Total fee amount
 */

import { DollarSign } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Separator } from "@repo/ui/components/separator"
import { formatCurrency } from "@/lib/utils/permit-helpers"

export interface FeeBreakdown {
  name: string
  amount: number
  description: string
}

export interface FeesSummaryCardProps {
  feesBreakdown: FeeBreakdown[]
  feesTotal: number
}

export function FeesSummaryCard({ feesBreakdown, feesTotal }: FeesSummaryCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <DollarSign className="h-5 w-5" />
          Fees Summary
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {feesBreakdown.map((fee, index) => (
            <div key={index} className="flex items-center justify-between text-sm">
              <div>
                <div className="font-medium">{fee.name}</div>
                <div className="text-xs text-muted-foreground">{fee.description}</div>
              </div>
              <div className="font-medium">{formatCurrency(fee.amount)}</div>
            </div>
          ))}
        </div>
        <Separator />
        <div className="flex items-center justify-between font-semibold text-lg">
          <span>Total:</span>
          <span className="text-primary">{formatCurrency(feesTotal)}</span>
        </div>
      </CardContent>
    </Card>
  )
}
