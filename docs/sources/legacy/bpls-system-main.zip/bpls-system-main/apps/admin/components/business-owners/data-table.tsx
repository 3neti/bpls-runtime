"use client"

import { useState, useMemo, useCallback } from "react"
import { useQuery } from "convex/react"
import {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table"
import { ChevronDown, Search, Download, Loader2 } from "lucide-react"

import { Button } from "@repo/ui/components/button"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import { Input } from "@repo/ui/components/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"
import { cn } from "@/lib/utils"
import { useColumnVisibilityStore } from "@/lib/stores/column-visibility-store"
import {
  TableFilterPopover,
  createDefaultFilterState,
  type FilterConfig,
  type FilterState,
} from "@/components/permits/table-filter-popover"
import {
  convertToCSV,
  downloadCSV,
  generateExportFilename,
  formatDateForCSV,
  type CSVColumn,
} from "@/lib/utils/csv-export"
import { PermissionGuard } from "@/components/permission-guard"
import { useDebouncedValue } from "@/hooks/use-debounced-value"
import { api } from "@repo/backend/convex/_generated/api"

// Status options for business owners
const STATUS_OPTIONS = [
  { value: "Active", label: "Active" },
  { value: "Blacklisted", label: "Blacklisted" },
]

// Owner type options
const OWNER_TYPE_OPTIONS = [
  { value: "Individual", label: "Individual" },
  { value: "Corporation", label: "Corporation" },
]

// Filter config for business owners table
const FILTER_CONFIG: FilterConfig = {
  statusOptions: STATUS_OPTIONS,
  showDateRange: true,
  showTypeFilter: false, // We'll use custom filter for owner type
}

interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[]
  data: TData[]
  onRowClick?: (row: TData) => void
  searchPlaceholder?: string
  isLoading?: boolean
}

export function DataTable<TData, TValue>({
  columns,
  data,
  onRowClick,
  searchPlaceholder = "Search by name, mobile, email, location...",
  isLoading = false,
}: DataTableProps<TData, TValue>) {
  const [sorting, setSorting] = useState<SortingState>([])
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([])
  const [rowSelection, setRowSelection] = useState({})
  const [filters, setFilters] = useState<FilterState>(createDefaultFilterState())
  const [searchQuery, setSearchQuery] = useState("")
  const debouncedSearch = useDebouncedValue(searchQuery, 300)

  // Use Zustand store for column visibility
  const { businessOwnersColumns, setBusinessOwnersColumns } = useColumnVisibilityStore()

  // Server-side search query (conditionally skip when search is too short)
  const searchResults = useQuery(
    api.search.searchBusinessOwners,
    debouncedSearch.length >= 2
      ? { query: debouncedSearch, includeBlacklisted: true, limit: 100 }
      : "skip"
  )

  // Determine if we're searching and loading
  const isSearching = debouncedSearch.length >= 2
  const isSearchLoading = isSearching && searchResults === undefined

  // Apply custom filters to data - use search results when searching, otherwise use props data
  const filteredData = useMemo(() => {
    // Use search results when available, otherwise use props data
    const sourceData = isSearching && searchResults ? searchResults : data
    let result = [...sourceData] as Record<string, unknown>[]

    // Status filter (Active/Blacklisted)
    if (filters.statuses.length > 0) {
      result = result.filter((item) => {
        const isBlacklisted = item.isBlacklisted as boolean
        const status = isBlacklisted ? "Blacklisted" : "Active"
        return filters.statuses.includes(status)
      })
    }

    // Date range filter (using birthDate)
    if (filters.dateRange.from || filters.dateRange.to) {
      result = result.filter((item) => {
        const birthDate = item.birthDate as string | undefined
        if (!birthDate) return true
        const itemDate = new Date(birthDate)
        if (filters.dateRange.from && itemDate < filters.dateRange.from) return false
        if (filters.dateRange.to && itemDate > filters.dateRange.to) return false
        return true
      })
    }

    return result as TData[]
  }, [data, filters, isSearching, searchResults])

  // Export handler
  const handleExport = useCallback(() => {
    type OwnerRow = Record<string, unknown>

    const exportColumns: CSVColumn<OwnerRow>[] = [
      {
        header: "Full Name",
        accessor: (row) =>
          `${row.firstName}${row.middleName ? " " + row.middleName : ""} ${row.lastName}`,
      },
      { header: "Owner Type", accessor: (row) => row.ownerType as string },
      { header: "Group Name", accessor: (row) => (row.groupName as string) || "" },
      { header: "Email", accessor: (row) => row.email as string },
      { header: "Mobile", accessor: (row) => row.mobile as string },
      { header: "TIN", accessor: (row) => (row.tin as string) || "" },
      { header: "Birth Date", accessor: (row) => formatDateForCSV(row.birthDate as string) },
      { header: "Civil Status", accessor: (row) => row.civilStatus as string },
      { header: "Gender", accessor: (row) => row.gender as string },
      { header: "Citizenship", accessor: (row) => row.citizenship as string },
      { header: "Address", accessor: (row) => (row.address as string) || "" },
      { header: "Status", accessor: (row) => ((row.isBlacklisted as boolean) ? "Blacklisted" : "Active") },
    ]

    const csv = convertToCSV(filteredData as OwnerRow[], exportColumns)
    downloadCSV(csv, generateExportFilename("business-owners"))
  }, [filteredData])

  const table = useReactTable({
    data: filteredData,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onColumnVisibilityChange: setBusinessOwnersColumns,
    onRowSelectionChange: setRowSelection,
    state: {
      sorting,
      columnFilters,
      columnVisibility: businessOwnersColumns,
      rowSelection,
    },
  })

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          {isSearchLoading ? (
            <Loader2 className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground animate-spin" />
          ) : (
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          )}
          <Input
            placeholder={searchPlaceholder}
            value={searchQuery}
            onChange={(event) => setSearchQuery(event.target.value)}
            className="pl-8"
          />
        </div>

        {/* Columns Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline">
              Columns <ChevronDown className="ml-2 h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-[200px]">
            {table
              .getAllColumns()
              .filter((column) => column.getCanHide())
              .map((column) => {
                // Format column display name
                const displayName = column.id
                  .replace(/([A-Z])/g, ' $1')
                  .replace(/^./, str => str.toUpperCase())
                  .trim()

                return (
                  <DropdownMenuCheckboxItem
                    key={column.id}
                    className="capitalize"
                    checked={column.getIsVisible()}
                    onCheckedChange={(value) =>
                      column.toggleVisibility(!!value)
                    }
                  >
                    {displayName}
                  </DropdownMenuCheckboxItem>
                )
              })}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Filter Popover */}
        <TableFilterPopover
          config={FILTER_CONFIG}
          filters={filters}
          onFiltersChange={setFilters}
        />

        {/* Export Button */}
        <PermissionGuard resource="reports" action="read" fallback={null}>
          <Button variant="outline" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </PermissionGuard>
      </div>

      <div className="rounded-lg border bg-card">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id}>
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                    </TableHead>
                  )
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center"
                >
                  <div className="flex items-center justify-center gap-2">
                    <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                    <span className="text-muted-foreground">Loading...</span>
                  </div>
                </TableCell>
              </TableRow>
            ) : table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow
                  key={row.id}
                  data-state={row.getIsSelected() && "selected"}
                  className={cn(
                    "hover:bg-muted/50 transition-colors",
                    onRowClick && "cursor-pointer"
                  )}
                  onClick={() => onRowClick?.(row.original)}
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center"
                >
                  No results.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Note: Pagination is now handled by the parent component with server-side pagination */}
    </div>
  )
}
