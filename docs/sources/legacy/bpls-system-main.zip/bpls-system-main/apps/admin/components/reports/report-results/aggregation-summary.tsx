"use client"

import * as React from "react"
import { TrendingUp, TrendingDown, Minus, Calculator } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Skeleton } from "@repo/ui/components/skeleton"
import { cn } from "@/lib/utils"
import type { Metric, MetricFormat } from "@/lib/types/report-builder"

interface AggregationResult {
  metricId: string
  value: number
  previousValue?: number
}

interface AggregationSummaryProps {
  aggregations: AggregationResult[]
  metrics: Metric[]
  selectedMetrics: string[]
  isLoading?: boolean
}

export function AggregationSummary({
  aggregations,
  metrics,
  selectedMetrics,
  isLoading = false,
}: AggregationSummaryProps) {
  if (isLoading) {
    return (
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
        {[1, 2, 3].map((i) => (
          <Card key={i}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-32" />
              <Skeleton className="mt-2 h-3 w-20" />
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  // Filter to only show selected metrics that have aggregation results
  const displayMetrics = selectedMetrics
    .map((metricId) => {
      const metric = metrics.find((m) => m.id === metricId)
      const aggregation = aggregations.find((a) => a.metricId === metricId)
      return metric && aggregation ? { metric, aggregation } : null
    })
    .filter(Boolean) as { metric: Metric; aggregation: AggregationResult }[]

  if (displayMetrics.length === 0) {
    return (
      <div className="rounded-md border border-dashed p-8 text-center">
        <Calculator className="mx-auto h-8 w-8 text-muted-foreground" />
        <h3 className="mt-2 text-sm font-medium">No metrics selected</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Select metrics in the report builder to see aggregations here.
        </p>
      </div>
    )
  }

  return (
    <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
      {displayMetrics.map(({ metric, aggregation }) => (
        <MetricCard
          key={metric.id}
          metric={metric}
          aggregation={aggregation}
        />
      ))}
    </div>
  )
}

interface MetricCardProps {
  metric: Metric
  aggregation: AggregationResult
}

function MetricCard({ metric, aggregation }: MetricCardProps) {
  const formattedValue = formatMetricValue(aggregation.value, metric.format)
  const trend = calculateTrend(aggregation.value, aggregation.previousValue)

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{metric.name}</CardTitle>
        <MetricIcon aggregation={metric.aggregation} />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{formattedValue}</div>
        {trend && (
          <div
            className={cn(
              "flex items-center text-xs mt-1",
              trend.direction === "up"
                ? "text-green-600"
                : trend.direction === "down"
                  ? "text-red-600"
                  : "text-muted-foreground"
            )}
          >
            {trend.direction === "up" ? (
              <TrendingUp className="mr-1 h-3 w-3" />
            ) : trend.direction === "down" ? (
              <TrendingDown className="mr-1 h-3 w-3" />
            ) : (
              <Minus className="mr-1 h-3 w-3" />
            )}
            <span>
              {trend.percentage > 0 ? "+" : ""}
              {trend.percentage.toFixed(1)}% from previous
            </span>
          </div>
        )}
        {metric.description && (
          <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
            {metric.description}
          </p>
        )}
      </CardContent>
    </Card>
  )
}

function MetricIcon({ aggregation }: { aggregation: string }) {
  const iconClass = "h-4 w-4 text-muted-foreground"

  const icons: Record<string, React.ReactNode> = {
    sum: <span className="font-mono text-xs">Σ</span>,
    count: <span className="font-mono text-xs">#</span>,
    average: <span className="font-mono text-xs">μ</span>,
    min: <span className="font-mono text-xs">↓</span>,
    max: <span className="font-mono text-xs">↑</span>,
    countDistinct: <span className="font-mono text-xs">n</span>,
  }

  return (
    <div className={iconClass}>
      {icons[aggregation] || <Calculator className="h-4 w-4" />}
    </div>
  )
}

function formatMetricValue(value: number, format: MetricFormat): string {
  switch (format) {
    case "currency":
      return new Intl.NumberFormat("en-PH", {
        style: "currency",
        currency: "PHP",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(value)

    case "percentage":
      return `${value.toFixed(1)}%`

    case "number":
    default:
      return new Intl.NumberFormat("en-PH").format(value)
  }
}

function calculateTrend(
  current: number,
  previous?: number
): { direction: "up" | "down" | "neutral"; percentage: number } | null {
  if (previous === undefined || previous === 0) return null

  const percentage = ((current - previous) / previous) * 100

  return {
    direction:
      percentage > 0.5 ? "up" : percentage < -0.5 ? "down" : "neutral",
    percentage,
  }
}
