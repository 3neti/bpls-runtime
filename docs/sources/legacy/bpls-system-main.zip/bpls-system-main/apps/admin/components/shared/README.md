# Shared Form Components

This directory contains reusable form components that support both **create** and **update** modes for business and business owner management.

## Components

### 1. BusinessDetailsForm

A unified form component for creating and updating business information with full validation and document management.

#### Features

- **Dual Mode Support**: Works seamlessly in both create and update modes
- **Complete Field Coverage**: All business fields from schema including:
  - Basic business information (name, area, dates)
  - Ownership details (type, group name, registration)
  - Employee counts with automatic totals
  - Contact information (phone, email)
  - Hierarchical address fields (province, city, barangay)
  - Line of business
- **Document Management**: Ownership-specific document uploads based on business type
- **Cascading Dropdowns**: Province → City → Barangay selection
- **Conditional Fields**: Group name requirement based on ownership type
- **Validation**: Comprehensive Zod schema validation
- **Error Handling**: User-friendly error messages

#### Usage

**Create Mode:**
```tsx
import { BusinessDetailsForm } from "@/components/shared/business-details-form";

<BusinessDetailsForm
  mode="create"
  ownerId={selectedOwnerId}
  onSuccess={() => {
    toast({ title: "Business created successfully" });
    router.push("/dashboard/businesses");
  }}
  onCancel={() => router.back()}
  showCancelButton={true}
/>
```

**Update Mode:**
```tsx
import { BusinessDetailsForm } from "@/components/shared/business-details-form";

<BusinessDetailsForm
  mode="update"
  businessId={business.id}
  initialData={{
    name: business.name,
    businessArea: business.businessArea,
    dateStarted: business.dateStarted,
    ownershipType: business.ownershipType,
    address: business.address,
    provinceId: business.provinceId,
    cityId: business.cityId,
    barangayId: business.barangayId,
    lineOfBusiness: business.lineOfBusiness,
    maleEmployeeCount: business.maleEmployeeCount,
    femaleEmployeeCount: business.femaleEmployeeCount,
    // ... all other fields
  }}
  existingDocuments={business.documents}
  onSuccess={() => {
    toast({ title: "Business updated successfully" });
    router.refresh();
  }}
/>
```

#### Props

| Prop | Type | Required | Description |
|------|------|----------|-------------|
| `mode` | `"create" \| "update"` | Yes | Operating mode of the form |
| `ownerId` | `Id<"business_owners"> \| string` | Required for create | Owner ID when creating a business |
| `businessId` | `Id<"businesses">` | Required for update | Business ID when updating |
| `initialData` | `Partial<BusinessDetailsFormSchema>` | No | Pre-fill form with existing data |
| `existingDocuments` | `Array<Document>` | No | Existing uploaded documents |
| `onSuccess` | `() => void` | No | Callback after successful submission |
| `onCancel` | `() => void` | No | Callback when cancel is clicked |
| `showCancelButton` | `boolean` | No | Show/hide cancel button (default: false) |

#### Schema

The component uses a discriminated union schema that validates differently based on mode:

- **Create Mode**: Requires `ownerId`, validates all business fields
- **Update Mode**: Requires `id`, validates all business fields
- **Both Modes**:
  - Employee count validation (at least 1 employee required)
  - Conditional group name validation (required for Partnership, Corporation, Cooperative)
  - Address hierarchy validation

---

### 2. BusinessOwnerForm

A unified form component for creating and updating business owner information with profile photo management.

#### Features

- **Dual Mode Support**: Create new owners or update existing ones
- **Complete Field Coverage**: All owner fields from schema including:
  - Personal information (name, birth date, civil status, gender)
  - Contact details (mobile, email)
  - Address information (hierarchical)
  - Optional TIN
  - Owner classification (Single/Group) - only in create mode
- **Profile Photo Management**:
  - File upload support
  - Camera capture integration
  - Preview functionality
- **Cascading Dropdowns**: Province → City → Barangay selection
- **Validation**: Comprehensive Zod schema validation
- **Conditional Fields**: Group name required for Group owner type

#### Usage

**Create Mode:**
```tsx
import { BusinessOwnerForm } from "@/components/shared/business-owner-form";

<BusinessOwnerForm
  mode="create"
  onSuccess={() => {
    toast({ title: "Business owner created successfully" });
    router.push("/dashboard/business-owners");
  }}
  onCancel={() => router.back()}
  showCancelButton={true}
/>
```

**Update Mode:**
```tsx
import { BusinessOwnerForm } from "@/components/shared/business-owner-form";

<BusinessOwnerForm
  mode="update"
  ownerId={owner.id}
  initialData={{
    firstName: owner.firstName,
    middleName: owner.middleName,
    lastName: owner.lastName,
    birthDate: owner.birthDate,
    civilStatus: owner.civilStatus,
    gender: owner.gender,
    citizenship: owner.citizenship,
    tin: owner.tin,
    mobile: owner.mobile,
    email: owner.email,
    address: owner.address,
    provinceId: owner.provinceId,
    cityId: owner.cityId,
    barangayId: owner.barangayId,
    avatar: owner.avatar,
    ownerType: owner.ownerType,
    groupName: owner.groupName,
  }}
  onSuccess={() => {
    toast({ title: "Business owner updated successfully" });
    router.refresh();
  }}
/>
```

#### Props

| Prop | Type | Required | Description |
|------|------|----------|-------------|
| `mode` | `"create" \| "update"` | Yes | Operating mode of the form |
| `ownerId` | `Id<"business_owners">` | Required for update | Owner ID when updating |
| `initialData` | `Partial<BusinessOwnerFormSchema>` | No | Pre-fill form with existing data |
| `onSuccess` | `() => void` | No | Callback after successful submission |
| `onCancel` | `() => void` | No | Callback when cancel is clicked |
| `showCancelButton` | `boolean` | No | Show/hide cancel button (default: false) |

#### Schema

The component uses a discriminated union schema:

- **Create Mode**: Validates all fields, includes owner type classification
- **Update Mode**: Requires `id`, validates all fields except owner type (read-only)
- **Both Modes**:
  - Email validation
  - Required personal information
  - Conditional group name validation (required for Group owner type)
  - Address hierarchy validation

---

## Technical Implementation

### Architecture Patterns

1. **Discriminated Unions**: Both components use TypeScript discriminated unions to ensure type safety across modes
2. **React Hook Form**: Form state management with Zod validation
3. **Convex Mutations**: Backend integration for CRUD operations
4. **Cascading Selects**: Province → City → Barangay with automatic clearing
5. **Conditional Rendering**: Fields appear/disappear based on selections
6. **Document Management**: File upload with storage integration

### Validation Strategy

- **Client-side**: Zod schemas provide immediate feedback
- **Field-level**: Validation on change for responsive UX
- **Form-level**: Comprehensive validation on submit
- **Custom Rules**: Superrefine for complex conditional logic

### State Management

- Form state: React Hook Form
- Location cascading: Local state + useEffect
- File uploads: Controlled components with preview
- Loading states: Form submission tracking

---

## Benefits of Shared Components

### Code Reusability
- **Single Source of Truth**: One component handles both create and update
- **Consistent UX**: Same interface across all usage contexts
- **Reduced Duplication**: No need for separate create/update forms

### Maintainability
- **Centralized Logic**: Business rules in one place
- **Easier Updates**: Changes propagate everywhere
- **Type Safety**: Full TypeScript support with discriminated unions

### Developer Experience
- **Clear API**: Simple prop interface
- **Flexible Usage**: Works in dialogs, pages, or embedded contexts
- **Self-documenting**: TypeScript types serve as documentation

---

## Integration Examples

### In a Modal Dialog

```tsx
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { BusinessDetailsForm } from "@/components/shared/business-details-form";

function CreateBusinessDialog({ open, onOpenChange, ownerId }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Business</DialogTitle>
        </DialogHeader>
        <BusinessDetailsForm
          mode="create"
          ownerId={ownerId}
          onSuccess={() => {
            onOpenChange(false);
            toast({ title: "Business created successfully" });
          }}
          onCancel={() => onOpenChange(false)}
          showCancelButton={true}
        />
      </DialogContent>
    </Dialog>
  );
}
```

### In a Dedicated Page

```tsx
import { BusinessOwnerForm } from "@/components/shared/business-owner-form";

export default function NewBusinessOwnerPage() {
  const router = useRouter();

  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6">Create New Business Owner</h1>
      <BusinessOwnerForm
        mode="create"
        onSuccess={() => {
          router.push("/dashboard/business-owners");
          toast({ title: "Owner created successfully" });
        }}
        onCancel={() => router.back()}
        showCancelButton={true}
      />
    </div>
  );
}
```

### In a Multi-Step Wizard

```tsx
function PermitApplicationWizard() {
  const [step, setStep] = useState(1);
  const [ownerId, setOwnerId] = useState<Id<"business_owners"> | null>(null);

  return (
    <div>
      {step === 1 && (
        <BusinessOwnerForm
          mode="create"
          onSuccess={(newOwnerId) => {
            setOwnerId(newOwnerId);
            setStep(2);
          }}
        />
      )}
      {step === 2 && ownerId && (
        <BusinessDetailsForm
          mode="create"
          ownerId={ownerId}
          onSuccess={() => setStep(3)}
        />
      )}
    </div>
  );
}
```

---

## Testing Considerations

### Unit Tests
- Schema validation logic
- Conditional field rendering
- Form submission handlers
- Error message display

### Integration Tests
- Create workflow end-to-end
- Update workflow end-to-end
- File upload functionality
- Cascading dropdown behavior

### Accessibility Tests
- Keyboard navigation
- Screen reader compatibility
- Error message announcement
- Focus management

---

## Performance Optimizations

1. **Lazy Loading**: Large components loaded on demand
2. **Memoization**: Form values memoized to prevent unnecessary re-renders
3. **Debouncing**: Validation debounced for better UX
4. **Efficient Queries**: Location data fetched only when needed
5. **Optimistic Updates**: UI updates before server confirmation

---

## Migration Guide

### From Separate Create/Update Forms

**Before:**
```tsx
// Two separate components
<BusinessCreateForm />
<BusinessUpdateForm />
```

**After:**
```tsx
// One unified component
<BusinessDetailsForm mode="create" />
<BusinessDetailsForm mode="update" />
```

### Key Changes
1. Add `mode` prop to all usage
2. Pass `ownerId` for create mode
3. Pass `businessId` and `initialData` for update mode
4. Update success callbacks to handle both modes
5. Remove duplicate validation logic

---

## Future Enhancements

- [ ] Draft saving functionality
- [ ] Offline support with local storage
- [ ] Bulk operations support
- [ ] Advanced search and filter
- [ ] Export/import functionality
- [ ] Audit trail integration
- [ ] Real-time collaboration
- [ ] Version history

---

## Support

For questions or issues related to these shared components:

1. Check the TypeScript types for prop definitions
2. Review the schema files for validation rules
3. Examine usage examples in this README
4. Consult the Convex API documentation for backend integration

---

## Related Files

- `/lib/schemas/business-form.ts` - Create schema
- `/lib/schemas/business-update.ts` - Update schema
- `/lib/schemas/business-owner-form.ts` - Owner create schema
- `/lib/schemas/business-owner-update.ts` - Owner update schema
- `/convex/schema.ts` - Database schema
- `/lib/types/business.ts` - Business type definitions
- `/lib/types/business-owners.ts` - Owner type definitions
