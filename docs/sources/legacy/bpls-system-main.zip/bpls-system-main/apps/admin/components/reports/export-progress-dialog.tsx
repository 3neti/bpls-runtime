"use client"

import { Download, Loader2, X, AlertCircle, CheckCircle2, Info } from "lucide-react"
import { Button } from "@repo/ui/components/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { Progress } from "@repo/ui/components/progress"
import type { ExportProgress } from "@/hooks/use-report-export"

interface ExportProgressDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  progress: ExportProgress
  onCancel: () => void
  onDownload: () => void
  onClose: () => void
}

export function ExportProgressDialog({
  open,
  onOpenChange,
  progress,
  onCancel,
  onDownload,
  onClose,
}: ExportProgressDialogProps) {
  const { status, totalRecords, processedRecords, currentBatch, totalBatches } = progress
  const progressPercent = totalRecords && processedRecords
    ? Math.round((processedRecords / totalRecords) * 100)
    : 0

  const isInProgress = status === "pending" || status === "processing" || status === "generating_csv"
  const isCompleted = status === "completed"
  const isFailed = status === "failed"
  const isCancelled = status === "cancelled"

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {isInProgress && <Loader2 className="h-4 w-4 animate-spin" />}
            {isCompleted && <CheckCircle2 className="h-4 w-4 text-green-500" />}
            {isFailed && <AlertCircle className="h-4 w-4 text-destructive" />}
            {isCancelled && <X className="h-4 w-4 text-muted-foreground" />}
            {isInProgress ? "Exporting Report" : isCompleted ? "Export Complete" : isFailed ? "Export Failed" : "Export Cancelled"}
          </DialogTitle>
          <DialogDescription>
            {isInProgress && "Your report is being generated. You can navigate away and come back."}
            {isCompleted && "Your report is ready for download."}
            {isFailed && (progress.errorMessage || "An error occurred during export.")}
            {isCancelled && "The export was cancelled."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {isInProgress && (
            <>
              <Progress value={progressPercent} className="h-2" />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>
                  {status === "pending" && "Starting..."}
                  {status === "processing" && (
                    processedRecords !== undefined && totalRecords
                      ? `Processing ${processedRecords.toLocaleString()} of ${totalRecords.toLocaleString()} records`
                      : "Processing..."
                  )}
                  {status === "generating_csv" && "Generating CSV file..."}
                </span>
                {currentBatch !== undefined && totalBatches !== undefined && (
                  <span>Batch {currentBatch} of {totalBatches}</span>
                )}
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground bg-muted/50 rounded-md p-2">
                <Info className="h-3 w-3 shrink-0" />
                <span>You can navigate away from this page. The export will continue in the background.</span>
              </div>
            </>
          )}

          {isCompleted && progress.downloadUrl && (
            <Button onClick={onDownload} className="w-full">
              <Download className="h-4 w-4 mr-2" />
              Download CSV
            </Button>
          )}
        </div>

        <DialogFooter>
          {isInProgress && (
            <Button variant="outline" onClick={onCancel}>
              Cancel Export
            </Button>
          )}
          {(isCompleted || isFailed || isCancelled) && (
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
