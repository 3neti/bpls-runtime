"use client";

import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import { Calculator, DollarSign, TrendingUp, Plus, Trash2, Info } from "lucide-react";
import { Button } from "@repo/ui/components/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog";
import { Input } from "@repo/ui/components/input";
import { Textarea } from "@repo/ui/components/textarea";
import { Checkbox } from "@repo/ui/components/checkbox";
import { Label } from "@repo/ui/components/label";
import { Alert, AlertDescription } from "@repo/ui/components/alert";
import { Popover, PopoverContent, PopoverTrigger } from "@repo/ui/components/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@repo/ui/components/command";
import { Check, ChevronsUpDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { formatCurrency } from "@/lib/utils/formatting";
import { validateRanges, validateFormula, calculateFeeAmount } from "@/lib/utils/fee-calculator";
import type { FeeType, ApplicationType, BusinessField, FeeRange, BusinessData } from "@/lib/types/fees";
import { AvailableVariablesCard } from "@/components/fees/available-variables-card";
import { FormulaInput, type FormulaValidationResult } from "@/components/fees/formula-input";

interface Fee {
  _id: string;
  name: string;
  amount: number;
  applicationType: string[];
  feeType: string;
  feeCategory?: string;
  divisionId?: string;
  groupId?: string;
  rangeField?: string;
  ranges?: FeeRange[];
  formula?: string;
}

interface FeeNameOption {
  _id: string;
  name: string;
  isActive?: boolean;
}

interface FeeManagementModalProps {
  // Modal state
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;

  // Entity information (division, line-of-business group, or lob)
  entityId: string; // divisionId or groupId
  entityType: "division" | "group" | "lob";

  // Existing fee (for edit mode)
  editingFee?: Fee | null;

  // Available fee names (with IDs for unique keys)
  feeNames: FeeNameOption[];

  // Application ID for asset variable integration (optional)
  applicationId?: Id<"business_permit_applications">;

  // Callbacks
  onSuccess?: () => void;
  onAddFeeName?: (name: string) => Promise<void>;
}

export function FeeManagementModal({
  isOpen,
  onOpenChange,
  entityId,
  entityType,
  editingFee,
  feeNames,
  applicationId,
  onSuccess,
  onAddFeeName,
}: FeeManagementModalProps) {
  const { toast } = useToast();

  // Query asset variables for dynamic formula variables
  const categoryVariables = useQuery(
    api.unitsOfMeasurement.getVariables.getVariablesWithMetadata,
    applicationId ? { applicationId } : "skip"
  );

  // Convex mutations based on entity type
  const createDivisionFee = useMutation(api.fees.create);
  const updateDivisionFee = useMutation(api.fees.update);
  const createGroupFee = useMutation(api.groups.createCustomFee);
  const updateGroupFee = useMutation(api.groups.updateCustomFee);
  const createFeeName = useMutation(api.feeNames.create);

  // Filter out archived (inactive) fee names, but always include the editing fee's name if present
  const allFeeNames = useMemo(() => {
    // Filter to only active fee names
    const activeFeeNames = feeNames.filter((fn) => fn.isActive !== false);

    // If editing a fee and its name isn't in the active list, add it
    if (editingFee?.name && !activeFeeNames.some((fn) => fn.name === editingFee.name)) {
      return [...activeFeeNames, { _id: editingFee._id, name: editingFee.name, isActive: true }];
    }

    return activeFeeNames;
  }, [feeNames, editingFee]);

  // Custom fee form state
  const [customFeeForm, setCustomFeeForm] = useState<Partial<Fee>>({
    name: "",
    amount: 0,
    applicationType: ["New"],
    feeType: "Constant",
    feeCategory: undefined,
  });
  const [customFeeRanges, setCustomFeeRanges] = useState<FeeRange[]>([{ min: 0, max: 0, fee: 0 }]);
  const [customFeeFormula, setCustomFeeFormula] = useState("");
  const [sandboxValues, setSandboxValues] = useState<BusinessData>({
    numberOfEmployees: 50,
    maleEmployeeCount: 30,
    femaleEmployeeCount: 20,
    businessArea: 100,
    capitalInvestment: 500000,
    grossSales: 1000000,
    categoryVariables: {},
  });
  const [isAddingNewFeeName, setIsAddingNewFeeName] = useState(false);
  const [newFeeName, setNewFeeName] = useState("");
  const [openFeeNameCombobox, setOpenFeeNameCombobox] = useState(false);
  const [openFeeTypeCombobox, setOpenFeeTypeCombobox] = useState(false);
  const [openFeeCategoryCombobox, setOpenFeeCategoryCombobox] = useState(false);
  const [openRangeFieldCombobox, setOpenRangeFieldCombobox] = useState(false);
  const [formulaValidation, setFormulaValidation] = useState<FormulaValidationResult>({ valid: false });
  const [rangeFormulaValidations, setRangeFormulaValidations] = useState<Record<number, FormulaValidationResult>>({});

  // Memoize empty array to prevent re-renders
  const emptyArray = useMemo(() => [], []);
  const memoizedCategoryVariables = categoryVariables ?? emptyArray;

  // Fix 1: Auto-update subsequent ranges when a range's max value changes
  // Using a ref to track the previous max values to avoid infinite loops
  const previousMaxValuesRef = useRef<string>("");

  useEffect(() => {
    // Skip if no ranges or only one range
    if (customFeeRanges.length <= 1) return;

    // Create a stable key from current max values
    const currentMaxKey = customFeeRanges.map((r, i) => `${i}:${r.max}`).join("|");

    // Skip if max values haven't actually changed
    if (currentMaxKey === previousMaxValuesRef.current) return;
    previousMaxValuesRef.current = currentMaxKey;

    // Cascade min values based on previous range's max value
    let needsUpdate = false;
    const updatedRanges = customFeeRanges.map((range, index) => {
      if (index === 0) return range; // First range doesn't need min adjustment

      const previousMax = customFeeRanges[index - 1].max;
      const expectedMin = previousMax + 1;

      if (range.min !== expectedMin) {
        needsUpdate = true;
        return { ...range, min: expectedMin };
      }
      return range;
    });

    if (needsUpdate) {
      console.log("🔄 Auto-updating range min values:", updatedRanges);
      setCustomFeeRanges(updatedRanges);
    }
  }, [customFeeRanges]); // Runs when ranges change, but ref prevents infinite loop

  // Reset form when dialog closes or when editing fee changes
  useEffect(() => {
    if (!isOpen) {
      // Reset form when dialog closes
      resetCustomFeeForm();
    } else if (editingFee) {
      // Populate form when editing
      setCustomFeeForm({
        name: editingFee.name,
        amount: editingFee.amount,
        applicationType: editingFee.applicationType,
        feeType: editingFee.feeType,
        feeCategory: editingFee.feeCategory,
        rangeField: editingFee.rangeField,
      });
      if (editingFee.feeType === "Range" && editingFee.ranges) {
        setCustomFeeRanges(editingFee.ranges);
      } else {
        setCustomFeeRanges([{ min: 0, max: 0, fee: 0 }]);
      }
      if (editingFee.feeType === "Formula" && editingFee.formula) {
        setCustomFeeFormula(editingFee.formula);
      } else {
        setCustomFeeFormula("");
      }
    } else if (isOpen && !editingFee) {
      // Reset form when opening in create mode (not editing)
      resetCustomFeeForm();
    }
  }, [isOpen, editingFee]);

  const resetCustomFeeForm = () => {
    setCustomFeeForm({
      name: "",
      amount: 0,
      applicationType: ["New"],
      feeType: "Constant",
      feeCategory: undefined,
    });
    setCustomFeeRanges([{ min: 0, max: 0, fee: 0 }]);
    setCustomFeeFormula("");
    setIsAddingNewFeeName(false);
    setNewFeeName("");
    setFormulaValidation({ valid: false });
    setRangeFormulaValidations({});
    previousMaxValuesRef.current = ""; // Reset the ref to avoid stale comparisons
  };

  const handleApplicationTypeChange = (type: ApplicationType, checked: boolean) => {
    const currentTypes = customFeeForm.applicationType || [];
    if (checked) {
      if (!currentTypes.includes(type)) {
        setCustomFeeForm({ ...customFeeForm, applicationType: [...currentTypes, type] });
      }
    } else {
      setCustomFeeForm({ ...customFeeForm, applicationType: currentTypes.filter((t) => t !== type) });
    }
  };

  const addCustomFeeRange = () => {
    const lastRange = customFeeRanges[customFeeRanges.length - 1];
    const newMin = lastRange ? lastRange.max + 1 : 0;
    const newMax = lastRange ? lastRange.max + 2 : 0;
    setCustomFeeRanges([...customFeeRanges, { min: newMin, max: newMax, fee: 0 }]);
  };

  const updateCustomFeeRange = (index: number, field: keyof FeeRange, value: number | string) => {
    const updatedRanges = customFeeRanges.map((range, i) => {
      if (i === index) {
        return { ...range, [field]: value };
      }
      return range;
    });

    // Note: The useEffect hook will automatically cascade min values when max changes
    setCustomFeeRanges(updatedRanges);
  };

  const toggleRangeType = (index: number, useFormula: boolean) => {
    const updatedRanges = customFeeRanges.map((range, i) => {
      if (i === index) {
        if (useFormula) {
          // Switch to formula: clear fee, keep/initialize formula
          return { ...range, fee: undefined, formula: range.formula || "" };
        } else {
          // Switch to fee: clear formula, keep/initialize fee
          // Also clear the validation for this range
          setRangeFormulaValidations((prev) => {
            const updated = { ...prev };
            delete updated[index];
            return updated;
          });
          return { ...range, formula: undefined, fee: range.fee || 0 };
        }
      }
      return range;
    });
    setCustomFeeRanges(updatedRanges);
  };

  const updateRangeFormulaValidation = useCallback((index: number, validation: FormulaValidationResult) => {
    setRangeFormulaValidations((prev) => ({
      ...prev,
      [index]: validation,
    }));
  }, []);

  const removeCustomFeeRange = (index: number) => {
    setCustomFeeRanges(customFeeRanges.filter((_, i) => i !== index));
  };

  // Sync asset variables into sandboxValues when they change
  useEffect(() => {
    if (categoryVariables && categoryVariables.length > 0) {
      const assetVarMap = categoryVariables.reduce((acc, asset) => {
        acc[asset.variableName] = asset.quantity;
        return acc;
      }, {} as Record<string, number>);

      setSandboxValues(prev => ({
        ...prev,
        categoryVariables: assetVarMap,
      }));
    }
  }, [categoryVariables]);

  const handleCreateCustomFee = async () => {
    if (
      !customFeeForm.name ||
      !customFeeForm.feeType ||
      !customFeeForm.applicationType ||
      customFeeForm.applicationType.length === 0
    ) {
      toast({
        title: "Error",
        description: "Please fill in all required fields (Fee Name, Fee Type, and Application Type).",
        variant: "destructive",
      });
      return;
    }

    if (customFeeForm.feeType === "Range") {
      if (!customFeeForm.rangeField) {
        toast({
          title: "Error",
          description: "Please select a business field for range-based calculation.",
          variant: "destructive",
        });
        return;
      }

      const processedRanges = customFeeRanges.map((range, index) => {
        const isLastRange = index === customFeeRanges.length - 1;
        if (isLastRange && range.formula) {
          const previousRanges = customFeeRanges.slice(0, -1);
          const maxPreviousValue = previousRanges.length > 0 ? Math.max(...previousRanges.map((r) => r.max)) : 0;

          return {
            ...range,
            min: maxPreviousValue + 1,
            max: Number.MAX_SAFE_INTEGER,
          };
        }
        return range;
      });

      // Build asset variables map for range formula validation
      const assetVarMap = categoryVariables?.reduce((acc, asset) => {
        acc[asset.variableName] = asset.quantity;
        return acc;
      }, {} as Record<string, number>) || {};

      // Conditionally allow unitOfMeasurement if selected as the range field
      if (customFeeForm.rangeField === "unitOfMeasurement") {
        assetVarMap["unitOfMeasurement"] = 0; // Dummy value for validation
      }

      const rangeValidation = validateRanges(processedRanges, assetVarMap);
      if (!rangeValidation.valid) {
        toast({
          title: "Range Validation Error",
          description: rangeValidation.error,
          variant: "destructive",
        });
        return;
      }
    }

    if (customFeeForm.feeType === "Formula") {
      if (!customFeeFormula || customFeeFormula.trim() === "") {
        toast({
          title: "Error",
          description: "Please enter a formula for fee calculation.",
          variant: "destructive",
        });
        return;
      }

      // Build asset variables map for validation
      const assetVarMap = categoryVariables?.reduce((acc, asset) => {
        acc[asset.variableName] = asset.quantity;
        return acc;
      }, {} as Record<string, number>) || {};

      // Allow unitOfMeasurement if there are asset variables available
      if (categoryVariables && categoryVariables.length > 0) {
        assetVarMap["unitOfMeasurement"] = 0; // Dummy value for validation
      }

      const formulaValidation = validateFormula(customFeeFormula, assetVarMap);
      if (!formulaValidation.valid) {
        toast({
          title: "Formula Validation Error",
          description: formulaValidation.error,
          variant: "destructive",
        });
        return;
      }
    }

    try {
      let finalRanges = customFeeRanges;
      if (customFeeForm.feeType === "Range" && customFeeRanges.length > 0) {
        finalRanges = customFeeRanges.map((range, index) => {
          const isLastRange = index === customFeeRanges.length - 1;
          if (isLastRange && range.formula) {
            const previousRanges = customFeeRanges.slice(0, -1);
            const maxPreviousValue = previousRanges.length > 0 ? Math.max(...previousRanges.map((r) => r.max)) : 0;

            return {
              ...range,
              min: maxPreviousValue + 1,
              max: Number.MAX_SAFE_INTEGER,
            };
          }
          return range;
        });
      }

      const feeData = {
        ...(entityType === "division"
          ? { divisionId: entityId as Id<"divisions"> }
          : { groupId: entityId as Id<"groups"> }),
        name: customFeeForm.name,
        amount: customFeeForm.amount || 0,
        applicationType: customFeeForm.applicationType,
        feeType: customFeeForm.feeType as "Constant" | "Range" | "Formula",
        feeCategory: customFeeForm.feeCategory as
          | "Tax"
          | "Regulatory Fee"
          | "Other Charges"
          | "Special Fee"
          | undefined,
        ...(customFeeForm.feeType === "Range" && {
          rangeField: customFeeForm.rangeField,
          ranges: finalRanges,
        }),
        ...(customFeeForm.feeType === "Formula" && {
          formula: customFeeFormula,
        }),
      };

      if (editingFee) {
        // Update existing fee - "lob" and "group" both use group mutations
        const mutation = entityType === "division" ? updateDivisionFee : updateGroupFee;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        await mutation({
          ...(entityType === "division"
            ? { id: editingFee._id as Id<"fees"> }
            : { feeId: editingFee._id as Id<"fees"> }),
          ...feeData,
        } as any);
        toast({
          title: "Success",
          description: `Fee "${customFeeForm.name}" has been updated successfully.`,
        });
      } else {
        // Create new fee - "lob" and "group" both use group mutations
        const mutation = entityType === "division" ? createDivisionFee : createGroupFee;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        await mutation(feeData as any);
        toast({
          title: "Success",
          description: `Fee "${customFeeForm.name}" has been created successfully.`,
        });
      }

      onOpenChange(false);
      resetCustomFeeForm();
      onSuccess?.();
    } catch (error) {
      console.error("Failed to save fee:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save fee. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleAddNewFeeName = async () => {
    const trimmedName = newFeeName.trim();

    if (!trimmedName) {
      toast({
        title: "Error",
        description: "Fee name cannot be empty.",
        variant: "destructive",
      });
      return;
    }

    if (allFeeNames.some((fn) => fn.name === trimmedName)) {
      toast({
        title: "Error",
        description: "A fee name with this name already exists.",
        variant: "destructive",
      });
      return;
    }

    try {
      if (onAddFeeName) {
        await onAddFeeName(trimmedName);
      } else {
        await createFeeName({
          name: trimmedName,
          description: "",
          isActive: true,
        });
      }

      setCustomFeeForm({ ...customFeeForm, name: trimmedName });
      setNewFeeName("");
      setIsAddingNewFeeName(false);

      toast({
        title: "Success",
        description: `Fee name "${trimmedName}" has been created successfully.`,
      });
    } catch (error) {
      console.error("Failed to create fee name:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create fee name. Please try again.",
        variant: "destructive",
      });
    }
  };

  const getBusinessFieldOptions = () => {
    const baseOptions = [
      { value: "numberOfEmployees", label: "Number of Employees" },
      { value: "maleEmployeeCount", label: "Male Employee Count" },
      { value: "femaleEmployeeCount", label: "Female Employee Count" },
      { value: "businessArea", label: "Business Area (sq.m)" },
      { value: "capitalInvestment", label: "Capital Investment (from LOB)" },
      { value: "grossSales", label: "Gross Sales (from LOB)" },
      { value: "unitOfMeasurement", label: "Unit of Measurement (Dynamic)" },
    ];

    // Add asset variables dynamically
    if (categoryVariables && categoryVariables.length > 0) {
      const assetOptions = categoryVariables.map((asset) => ({
        value: asset.variableName,
        label: asset.description || asset.variableName,
      }));
      return [...baseOptions, ...assetOptions];
    }

    return baseOptions;
  };


  return (
    <>
      <Dialog open={isOpen} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle>{editingFee ? "Edit Fee" : "Add New Fee"}</DialogTitle>
            <DialogDescription>
              {editingFee
                ? "Update the fee configuration"
                : `Configure a new fee for this ${entityType === "division" ? "division" : "line of business"}`}
            </DialogDescription>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto pr-2 space-y-4">
            {/* Fee Name and Application Type */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Fee Name</Label>
                <Popover open={openFeeNameCombobox} onOpenChange={setOpenFeeNameCombobox}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={openFeeNameCombobox}
                      className="w-full justify-between"
                    >
                      {customFeeForm.name || "Select fee name..."}
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-full p-0" align="start">
                    <Command>
                      <CommandInput placeholder="Search fee name..." />
                      <CommandList>
                        <CommandEmpty>No fee name found.</CommandEmpty>
                        <CommandGroup>
                          {allFeeNames.map((feeNameOption) => (
                            <CommandItem
                              key={feeNameOption._id}
                              value={feeNameOption.name}
                              onSelect={(value) => {
                                setCustomFeeForm({ ...customFeeForm, name: value });
                                setOpenFeeNameCombobox(false);
                              }}
                            >
                              <Check
                                className={cn(
                                  "mr-2 h-4 w-4",
                                  customFeeForm.name === feeNameOption.name ? "opacity-100" : "opacity-0"
                                )}
                              />
                              {feeNameOption.name}
                            </CommandItem>
                          ))}
                          <CommandItem
                            value="add-new"
                            onSelect={() => {
                              setIsAddingNewFeeName(true);
                              setOpenFeeNameCombobox(false);
                            }}
                            className="border-t text-primary"
                          >
                            <Plus className="mr-2 h-4 w-4" />
                            Add new fee name
                          </CommandItem>
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>
              <div>
                <Label>Application Type</Label>
                <div className="space-y-2 mt-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="new-type"
                      checked={customFeeForm.applicationType?.includes("New") || false}
                      onCheckedChange={(checked) => handleApplicationTypeChange("New", checked as boolean)}
                    />
                    <Label htmlFor="new-type" className="text-sm font-normal">
                      New Application
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="renewal-type"
                      checked={customFeeForm.applicationType?.includes("Renewal") || false}
                      onCheckedChange={(checked) => handleApplicationTypeChange("Renewal", checked as boolean)}
                    />
                    <Label htmlFor="renewal-type" className="text-sm font-normal">
                      Renewal Application
                    </Label>
                  </div>
                </div>
              </div>
            </div>

            {/* Fee Type */}
            <div>
              <Label htmlFor="feeType">Fee Type</Label>
              <Popover open={openFeeTypeCombobox} onOpenChange={setOpenFeeTypeCombobox}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={openFeeTypeCombobox}
                    className="w-full justify-between"
                  >
                    {customFeeForm.feeType === "Constant" && "Constant - Fixed amount"}
                    {customFeeForm.feeType === "Range" && "Range - Based on value ranges"}
                    {customFeeForm.feeType === "Formula" && "Formula - Calculated from business data"}
                    {!customFeeForm.feeType && "Select fee type..."}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0" align="start">
                  <Command>
                    <CommandList>
                      <CommandGroup>
                        <CommandItem
                          value="Constant"
                          onSelect={() => {
                            setCustomFeeForm({ ...customFeeForm, feeType: "Constant" });
                            setOpenFeeTypeCombobox(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              customFeeForm.feeType === "Constant" ? "opacity-100" : "opacity-0"
                            )}
                          />
                          Constant - Fixed amount
                        </CommandItem>
                        <CommandItem
                          value="Range"
                          onSelect={() => {
                            setCustomFeeForm({ ...customFeeForm, feeType: "Range" });
                            setOpenFeeTypeCombobox(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              customFeeForm.feeType === "Range" ? "opacity-100" : "opacity-0"
                            )}
                          />
                          Range - Based on value ranges
                        </CommandItem>
                        <CommandItem
                          value="Formula"
                          onSelect={() => {
                            setCustomFeeForm({ ...customFeeForm, feeType: "Formula" });
                            setOpenFeeTypeCombobox(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              customFeeForm.feeType === "Formula" ? "opacity-100" : "opacity-0"
                            )}
                          />
                          Formula - Calculated from business data
                        </CommandItem>
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>

            {/* Fee Category */}
            <div>
              <Label htmlFor="feeCategory">Fee Category</Label>
              <Popover open={openFeeCategoryCombobox} onOpenChange={setOpenFeeCategoryCombobox}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={openFeeCategoryCombobox}
                    className="w-full justify-between"
                  >
                    {customFeeForm.feeCategory || "Select fee category..."}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0" align="start">
                  <Command>
                    <CommandList>
                      <CommandGroup>
                        {["Tax", "Regulatory Fee", "Other Charges", "Special Fee"].map((category) => (
                          <CommandItem
                            key={category}
                            value={category}
                            onSelect={() => {
                              setCustomFeeForm({
                                ...customFeeForm,
                                feeCategory: category as "Tax" | "Regulatory Fee" | "Other Charges" | "Special Fee",
                              });
                              setOpenFeeCategoryCombobox(false);
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                customFeeForm.feeCategory === category ? "opacity-100" : "opacity-0"
                              )}
                            />
                            {category}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>

            {/* Constant Fee Type */}
            {customFeeForm.feeType === "Constant" && (
              <div>
                <Label htmlFor="amount">Amount (₱)</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  min="0"
                  value={customFeeForm.amount}
                  onChange={(e) =>
                    setCustomFeeForm({ ...customFeeForm, amount: Math.max(0, Number.parseFloat(e.target.value) || 0) })
                  }
                  placeholder="0.00"
                />
              </div>
            )}

            {/* Range Fee Type */}
            {customFeeForm.feeType === "Range" && (
              <div className="space-y-3">
                <div>
                  <Label htmlFor="rangeField">Business Field</Label>
                  <Popover open={openRangeFieldCombobox} onOpenChange={setOpenRangeFieldCombobox}>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        aria-expanded={openRangeFieldCombobox}
                        className="w-full justify-between"
                      >
                        {customFeeForm.rangeField
                          ? getBusinessFieldOptions().find((opt) => opt.value === customFeeForm.rangeField)?.label
                          : "Select business field for range calculation"}
                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0" align="start">
                      <Command>
                        <CommandInput placeholder="Search business field..." />
                        <CommandList>
                          <CommandEmpty>No business field found.</CommandEmpty>
                          <CommandGroup>
                            {getBusinessFieldOptions().map((option) => (
                              <CommandItem
                                key={option.value}
                                value={option.value}
                                onSelect={() => {
                                  setCustomFeeForm({
                                    ...customFeeForm,
                                    rangeField: option.value as BusinessField,
                                  });
                                  setOpenRangeFieldCombobox(false);
                                }}
                              >
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    customFeeForm.rangeField === option.value ? "opacity-100" : "opacity-0"
                                  )}
                                />
                                {option.label}
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                  <p className="text-xs text-muted-foreground mt-1">
                    Select which business information field to use for range-based fee calculation
                  </p>
                  {customFeeForm.rangeField === "assetSize" && (
                    <Alert className="mt-2 border-yellow-500/50 bg-yellow-500/10 text-yellow-600 dark:text-yellow-400">
                      <Info className="h-4 w-4" />
                      <AlertDescription>
                        Warning: This fee will not be applied unless an Asset Size is mapped to it on the Business
                        Dashboard.
                      </AlertDescription>
                    </Alert>
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <Label>Value Ranges</Label>
                  <Button type="button" variant="outline" size="sm" onClick={addCustomFeeRange}>
                    <Plus className="h-4 w-4 mr-1" />
                    Add Range
                  </Button>
                </div>
                <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                  {customFeeRanges.map((range, index) => {
                    const isLastRange = index === customFeeRanges.length - 1;
                    const previousRanges = customFeeRanges.slice(0, -1);
                    const maxPreviousValue =
                      previousRanges.length > 0 ? Math.max(...previousRanges.map((r) => r.max)) : 0;

                    return (
                      <div
                        key={index}
                        className={cn(
                          "p-3 border rounded-lg space-y-3",
                          isLastRange && "bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800"
                        )}
                      >
                        {/* Range Number Header */}
                        <div className="flex items-center justify-between">
                          <h4 className="text-sm font-semibold text-primary flex items-center gap-2">
                            <span className="bg-primary/10 px-2 py-1 rounded text-xs">Range #{index + 1}</span>
                          </h4>
                          {customFeeRanges.length > 1 && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => removeCustomFeeRange(index)}
                              className="h-7"
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          )}
                        </div>

                        {isLastRange ? (
                          <>
                            <div className="flex items-center space-x-2">
                              <Calculator className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                              <Label className="text-xs font-medium text-blue-600 dark:text-blue-400">
                                Final Range &gt; {maxPreviousValue}
                              </Label>
                            </div>
                            <div className="space-y-3">
                              {/* Fee Type Toggle - Same as non-final ranges */}
                              <div>
                                <Label className="text-xs mb-2 block">Fee Calculation</Label>
                                <div className="flex space-x-2">
                                  <Button
                                    type="button"
                                    variant={range.formula === undefined ? "default" : "outline"}
                                    size="sm"
                                    onClick={() => toggleRangeType(index, false)}
                                    className="flex-1"
                                  >
                                    <DollarSign className="h-3 w-3 mr-1" />
                                    Fixed Amount
                                  </Button>
                                  <Button
                                    type="button"
                                    variant={range.formula !== undefined ? "default" : "outline"}
                                    size="sm"
                                    onClick={() => toggleRangeType(index, true)}
                                    className="flex-1"
                                  >
                                    <Calculator className="h-3 w-3 mr-1" />
                                    Formula
                                  </Button>
                                </div>
                              </div>

                              {/* Conditional Fee Amount or Formula */}
                              {range.formula !== undefined ? (
                                <div>
                                  <FormulaInput
                                    label="Fee Formula"
                                    value={range.formula || ""}
                                    onChange={(value) => updateCustomFeeRange(index, "formula", value)}
                                    placeholder="e.g., numberOfEmployees * 50 + businessArea * 50"
                                    categoryVariables={memoizedCategoryVariables}
                                    rangeField={customFeeForm.rangeField}
                                    onValidationChange={(result) => updateRangeFormulaValidation(index, result)}
                                    showValidation={true}
                                    rows={2}
                                  />
                                </div>
                              ) : (
                                <div>
                                  <Label className="text-xs">Fee Amount (₱)</Label>
                                  <Input
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    value={range.fee || 0}
                                    onChange={(e) =>
                                      updateCustomFeeRange(index, "fee", Math.max(0, Number.parseFloat(e.target.value) || 0))
                                    }
                                    placeholder="0.00"
                                  />
                                </div>
                              )}
                            </div>
                          </>
                        ) : (
                          <div className="space-y-3">
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <Label className="text-xs">Min Value</Label>
                                <Input
                                  type="number"
                                  min="0"
                                  value={range.min}
                                  onChange={(e) =>
                                    updateCustomFeeRange(index, "min", Math.max(0, Number.parseFloat(e.target.value) || 0))
                                  }
                                  placeholder="0"
                                />
                              </div>
                              <div>
                                <Label className="text-xs">Max Value</Label>
                                <Input
                                  type="number"
                                  min="0"
                                  value={range.max}
                                  onChange={(e) =>
                                    updateCustomFeeRange(index, "max", Math.max(0, Number.parseFloat(e.target.value) || 0))
                                  }
                                  placeholder="0"
                                />
                              </div>
                            </div>

                            {/* Fee Type Toggle */}
                            <div>
                              <Label className="text-xs mb-2 block">Fee Calculation</Label>
                              <div className="flex space-x-2">
                                <Button
                                  type="button"
                                  variant={range.formula === undefined ? "default" : "outline"}
                                  size="sm"
                                  onClick={() => toggleRangeType(index, false)}
                                  className="flex-1"
                                >
                                  <DollarSign className="h-3 w-3 mr-1" />
                                  Fixed Amount
                                </Button>
                                <Button
                                  type="button"
                                  variant={range.formula !== undefined ? "default" : "outline"}
                                  size="sm"
                                  onClick={() => toggleRangeType(index, true)}
                                  className="flex-1"
                                >
                                  <Calculator className="h-3 w-3 mr-1" />
                                  Formula
                                </Button>
                              </div>
                            </div>

                            {/* Conditional Fee Amount or Formula */}
                            {range.formula !== undefined ? (
                              <div>
                                <FormulaInput
                                  label="Fee Formula"
                                  value={range.formula || ""}
                                  onChange={(value) => updateCustomFeeRange(index, "formula", value)}
                                  placeholder="e.g., numberOfEmployees * 50 + grossSales * 0.02"
                                  categoryVariables={memoizedCategoryVariables}
                                  rangeField={customFeeForm.rangeField}
                                  onValidationChange={(result) => updateRangeFormulaValidation(index, result)}
                                  showValidation={true}
                                  rows={2}
                                />
                                <AvailableVariablesCard
                                  categoryVariables={memoizedCategoryVariables}
                                  rangeField={customFeeForm.rangeField}
                                  compact
                                />
                              </div>
                            ) : (
                              <div>
                                <Label className="text-xs">Fee Amount (₱)</Label>
                                <Input
                                  type="number"
                                  step="0.01"
                                  min="0"
                                  value={range.fee || 0}
                                  onChange={(e) =>
                                    updateCustomFeeRange(index, "fee", Math.max(0, Number.parseFloat(e.target.value) || 0))
                                  }
                                  placeholder="0.00"
                                />
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Available Variables Section - Moved to Bottom */}
                <AvailableVariablesCard
                  categoryVariables={memoizedCategoryVariables}
                  rangeField={customFeeForm.rangeField}
                />

                {customFeeForm.rangeField && customFeeRanges.length > 0 && (
                  <div className="border-t pt-4">
                    <div className="flex items-center space-x-2 mb-3">
                      <TrendingUp className="h-4 w-4" />
                      <Label className="text-base font-medium">Sandbox</Label>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      Test your range configuration with different business values to see the calculated fee.
                    </p>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div>
                        <Label className="text-xs">Number of Employees</Label>
                        <Input
                          type="number"
                          value={sandboxValues.numberOfEmployees}
                          onChange={(e) =>
                            setSandboxValues({
                              ...sandboxValues,
                              numberOfEmployees: Number.parseInt(e.target.value) || 0,
                            })
                          }
                          className="h-8"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Male Employee Count</Label>
                        <Input
                          type="number"
                          value={sandboxValues.maleEmployeeCount}
                          onChange={(e) =>
                            setSandboxValues({
                              ...sandboxValues,
                              maleEmployeeCount: Number.parseInt(e.target.value) || 0,
                            })
                          }
                          className="h-8"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Female Employee Count</Label>
                        <Input
                          type="number"
                          value={sandboxValues.femaleEmployeeCount}
                          onChange={(e) =>
                            setSandboxValues({
                              ...sandboxValues,
                              femaleEmployeeCount: Number.parseInt(e.target.value) || 0,
                            })
                          }
                          className="h-8"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Business Area (sq.m)</Label>
                        <Input
                          type="number"
                          value={sandboxValues.businessArea}
                          onChange={(e) =>
                            setSandboxValues({
                              ...sandboxValues,
                              businessArea: Number.parseFloat(e.target.value) || 0,
                            })
                          }
                          className="h-8"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Capital Investment (₱)</Label>
                        <Input
                          type="number"
                          value={sandboxValues.capitalInvestment}
                          onChange={(e) =>
                            setSandboxValues({
                              ...sandboxValues,
                              capitalInvestment: Number.parseFloat(e.target.value) || 0,
                            })
                          }
                          className="h-8"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Gross Sales (₱)</Label>
                        <Input
                          type="number"
                          value={sandboxValues.grossSales}
                          onChange={(e) =>
                            setSandboxValues({
                              ...sandboxValues,
                              grossSales: Number.parseFloat(e.target.value) || 0,
                            })
                          }
                          className="h-8"
                        />
                      </div>

                      {/* Dynamic Asset Variables */}
                      {categoryVariables && categoryVariables.length > 0 && categoryVariables.map((asset) => (
                        <div key={asset.variableName}>
                          <Label className="text-xs">{asset.description || asset.assetClass || asset.variableName}</Label>
                          <Input
                            type="number"
                            value={sandboxValues.categoryVariables?.[asset.variableName] || 0}
                            onChange={(e) =>
                              setSandboxValues({
                                ...sandboxValues,
                                categoryVariables: {
                                  ...sandboxValues.categoryVariables,
                                  [asset.variableName]: Number.parseFloat(e.target.value) || 0,
                                },
                              })
                            }
                            className="h-8"
                          />
                        </div>
                      ))}
                    </div>

                    <div className="bg-muted/50 p-3 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Calculated Fee:</span>
                        <span className="text-lg font-bold text-primary">
                          {(() => {
                            // Get field value from either standard fields or asset variables
                            let fieldValue = 0;
                            const rangeField = customFeeForm.rangeField;

                            if (rangeField && sandboxValues.categoryVariables && rangeField in sandboxValues.categoryVariables) {
                              // Asset variable
                              fieldValue = sandboxValues.categoryVariables[rangeField] ?? 0;
                            } else if (rangeField) {
                              // Standard field
                              fieldValue = (sandboxValues[rangeField as keyof typeof sandboxValues] ?? 0) as number;
                            }

                            // Debug logs
                            console.log("🔍 Range Calculation Debug:", {
                              fieldValue,
                              rangeField,
                              isAssetVariable: rangeField && sandboxValues.categoryVariables && rangeField in sandboxValues.categoryVariables,
                              categoryVariables: sandboxValues.categoryVariables,
                              totalRanges: customFeeRanges.length,
                              ranges: customFeeRanges,
                            });

                            // Find matching range
                            const matchingRange = customFeeRanges.find(
                              (range) => fieldValue >= range.min && fieldValue <= range.max
                            );

                            if (matchingRange) {
                              console.log("✅ Matching range found:", matchingRange);

                              // Check if this range uses a formula
                              if (matchingRange.formula && matchingRange.formula.trim() !== "") {
                                try {
                                  console.log("🧮 Calculating formula:", matchingRange.formula);
                                  const calculatedFee = calculateFeeAmount("Formula", 0, sandboxValues, undefined, undefined, matchingRange.formula);
                                  console.log("✅ Formula result:", calculatedFee);
                                  return formatCurrency(calculatedFee, { withSymbol: true });
                                } catch (error) {
                                  console.error("❌ Formula calculation error:", error);
                                  return formatCurrency(0, { withSymbol: true });
                                }
                              }

                              // Use fixed fee
                              return formatCurrency(matchingRange.fee ?? 0, { withSymbol: true });
                            }

                            // Check if value exceeds all ranges and last range has a formula (catch-all)
                            const lastRange = customFeeRanges[customFeeRanges.length - 1];
                            const hasFormula = lastRange?.formula && lastRange.formula.trim() !== "";

                            console.log("🔎 Catch-all check:", {
                              lastRange,
                              hasFormula,
                              fieldValue,
                              exceedsMax: lastRange ? fieldValue > lastRange.max : false,
                            });

                            if (lastRange && fieldValue > lastRange.max && hasFormula && lastRange.formula) {
                              try {
                                console.log("🧮 Calculating catch-all formula:", lastRange.formula);
                                const calculatedFee = calculateFeeAmount("Formula", 0, sandboxValues, undefined, undefined, lastRange.formula);
                                console.log("✅ Formula result:", calculatedFee);
                                return formatCurrency(calculatedFee, { withSymbol: true });
                              } catch (error) {
                                console.error("❌ Formula calculation error:", error);
                                return formatCurrency(0, { withSymbol: true });
                              }
                            }

                            console.log("⚠️ No matching range or formula");
                            return formatCurrency(0, { withSymbol: true });
                          })()}
                        </span>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {(() => {
                          // Get field value from either standard fields or asset variables
                          let fieldValue = 0;
                          const rangeField = customFeeForm.rangeField;

                          if (rangeField && sandboxValues.categoryVariables && rangeField in sandboxValues.categoryVariables) {
                            // Asset variable
                            fieldValue = sandboxValues.categoryVariables[rangeField] ?? 0;
                          } else if (rangeField) {
                            // Standard field
                            fieldValue = (sandboxValues[rangeField as keyof typeof sandboxValues] ?? 0) as number;
                          }

                          const matchingRange = customFeeRanges.find(
                            (range) => fieldValue >= range.min && fieldValue <= range.max
                          );

                          if (matchingRange) {
                            const calculationType = matchingRange.formula ? "formula" : "fixed fee";
                            return `Value ${fieldValue} falls in range ${matchingRange.min} - ${matchingRange.max} (${calculationType})`;
                          }

                          // Check for catch-all formula
                          const lastRange = customFeeRanges[customFeeRanges.length - 1];
                          const hasFormula = lastRange?.formula && lastRange.formula.trim() !== "";

                          if (lastRange && fieldValue > lastRange.max && hasFormula) {
                            return `Value ${fieldValue} exceeds max range - using catch-all formula`;
                          }

                          return `Value ${fieldValue} does not match any configured range`;
                        })()}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Formula Fee Type */}
            {customFeeForm.feeType === "Formula" && (
              <div className="space-y-3">
                <FormulaInput
                  label="Formula"
                  value={customFeeFormula}
                  onChange={setCustomFeeFormula}
                  placeholder="e.g., numberOfEmployees * 50 + businessArea * 50"
                  categoryVariables={memoizedCategoryVariables}
                  onValidationChange={setFormulaValidation}
                  showValidation={true}
                />

                {/* Available Variables Card - Same as Range fee type for consistency */}
                <AvailableVariablesCard
                  categoryVariables={memoizedCategoryVariables}
                />

                <div className="border-t pt-4">
                  <div className="flex items-center space-x-2 mb-3">
                    <Calculator className="h-4 w-4" />
                    <Label className="text-base font-medium">Sandbox</Label>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    Test your formula with mock business values to see the calculated result.
                  </p>

                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div>
                      <Label className="text-xs">Number of Employees</Label>
                      <Input
                        type="number"
                        value={sandboxValues.numberOfEmployees}
                        onChange={(e) =>
                          setSandboxValues({
                            ...sandboxValues,
                            numberOfEmployees: Number.parseInt(e.target.value) || 0,
                          })
                        }
                        className="h-8"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Male Employee Count</Label>
                      <Input
                        type="number"
                        value={sandboxValues.maleEmployeeCount}
                        onChange={(e) =>
                          setSandboxValues({
                            ...sandboxValues,
                            maleEmployeeCount: Number.parseInt(e.target.value) || 0,
                          })
                        }
                        className="h-8"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Female Employee Count</Label>
                      <Input
                        type="number"
                        value={sandboxValues.femaleEmployeeCount}
                        onChange={(e) =>
                          setSandboxValues({
                            ...sandboxValues,
                            femaleEmployeeCount: Number.parseInt(e.target.value) || 0,
                          })
                        }
                        className="h-8"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Business Area (sq.m)</Label>
                      <Input
                        type="number"
                        value={sandboxValues.businessArea}
                        onChange={(e) =>
                          setSandboxValues({
                            ...sandboxValues,
                            businessArea: Number.parseFloat(e.target.value) || 0,
                          })
                        }
                        className="h-8"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Capital Investment (₱)</Label>
                      <Input
                        type="number"
                        value={sandboxValues.capitalInvestment}
                        onChange={(e) =>
                          setSandboxValues({
                            ...sandboxValues,
                            capitalInvestment: Number.parseFloat(e.target.value) || 0,
                          })
                        }
                        className="h-8"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Gross Sales (₱)</Label>
                      <Input
                        type="number"
                        value={sandboxValues.grossSales}
                        onChange={(e) =>
                          setSandboxValues({
                            ...sandboxValues,
                            grossSales: Number.parseFloat(e.target.value) || 0,
                          })
                        }
                        className="h-8"
                      />
                    </div>

                    {/* Dynamic Asset Variables */}
                    {categoryVariables && categoryVariables.length > 0 && categoryVariables.map((asset) => (
                      <div key={asset.variableName}>
                        <Label className="text-xs">{asset.description || asset.assetClass || asset.variableName}</Label>
                        <Input
                          type="number"
                          value={sandboxValues.categoryVariables?.[asset.variableName] || 0}
                          onChange={(e) =>
                            setSandboxValues({
                              ...sandboxValues,
                              categoryVariables: {
                                ...sandboxValues.categoryVariables,
                                [asset.variableName]: Number.parseFloat(e.target.value) || 0,
                              },
                            })
                          }
                          className="h-8"
                        />
                      </div>
                    ))}
                  </div>

                  <div className="bg-muted/50 p-3 rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Calculated Result:</span>
                      <span className="text-lg font-bold text-primary">
                        {formatCurrency(calculateFeeAmount("Formula", 0, sandboxValues, undefined, undefined, customFeeFormula), { withSymbol: true })}
                      </span>
                    </div>
                    {customFeeFormula && (
                      <div className="text-xs text-muted-foreground mt-2">
                        <span className="font-mono">{customFeeFormula}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          <DialogFooter className="flex-shrink-0 mt-4">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateCustomFee}>{editingFee ? "Update Fee" : "Add Fee"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add New Fee Name Dialog */}
      <Dialog open={isAddingNewFeeName} onOpenChange={setIsAddingNewFeeName}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add New Fee Name</DialogTitle>
            <DialogDescription>Enter a new fee name to add to the list of available options.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="newFeeName">Fee Name</Label>
              <Input
                id="newFeeName"
                value={newFeeName}
                onChange={(e) => setNewFeeName(e.target.value)}
                placeholder="Enter new fee name"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    handleAddNewFeeName();
                  }
                }}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsAddingNewFeeName(false);
                setNewFeeName("");
              }}
            >
              Cancel
            </Button>
            <Button onClick={handleAddNewFeeName} disabled={!newFeeName.trim()}>
              Add Fee Name
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
