"use client"

import { lazy, Suspense, useState, useEffect } from "react"
import { FileText, Loader2 } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@repo/ui/components/dialog"
import { mapToFormData, type ApplicationFormPdfProps } from "./application-form-pdf"

const PdfViewerContent = lazy(() => import("./pdf-viewer-content"))

interface ApplicationFormModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  applicationData: ApplicationFormPdfProps
}

export function ApplicationFormModal({ open, onOpenChange, applicationData }: ApplicationFormModalProps) {
  const [isClient, setIsClient] = useState(false)
  const formData = mapToFormData(applicationData)

  useEffect(() => {
    setIsClient(true)
  }, [])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[95vw] w-full h-[90vh] flex flex-col p-0">
        <DialogHeader className="px-6 py-4 border-b flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Application Form
          </DialogTitle>
        </DialogHeader>
        <div className="flex-1 overflow-hidden p-6">
          {!isClient ? (
            <div className="h-full flex items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
          ) : (
            <Suspense
              fallback={
                <div className="h-full flex items-center justify-center">
                  <Loader2 className="h-8 w-8 animate-spin" />
                </div>
              }
            >
              <PdfViewerContent
                formData={formData}
                applicationNumber={applicationData.applicationNumber}
                fileName={`application-form-${applicationData.applicationNumber}.pdf`}
                fullHeight={true}
              />
            </Suspense>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
