/**
 * Delete Department Dialog Component
 *
 * Confirmation dialog for deleting departments with slug verification.
 * Requires user to type the department's slug exactly to confirm deletion,
 * preventing accidental deletions of critical department configurations.
 *
 * Features:
 * - Slug-based confirmation (case-sensitive)
 * - Destructive styling with warning indicators
 * - Loading state during deletion
 * - Auto-clears input on close
 * - Proper accessibility with auto-focus
 */

"use client"

import { useState, useEffect } from "react"
import { AlertTriangle } from "lucide-react"
import { Button } from "@repo/ui/components/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { Input } from "@repo/ui/components/input"
import { Label } from "@repo/ui/components/label"

interface DeleteDepartmentDialogProps {
  /** Whether the dialog is open */
  open: boolean
  /** Dialog state handler */
  onOpenChange: (open: boolean) => void
  /** Full department name for display */
  departmentName: string
  /** Department slug that user must type to confirm */
  departmentSlug: string
  /** Delete confirmation handler */
  onConfirm: () => void | Promise<void>
}

export function DeleteDepartmentDialog({
  open,
  onOpenChange,
  departmentName,
  departmentSlug,
  onConfirm,
}: DeleteDepartmentDialogProps) {
  const [inputValue, setInputValue] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)

  // Check if input matches slug exactly (case-sensitive)
  const isSlugMatch = inputValue === departmentSlug

  // Clear input when dialog closes
  useEffect(() => {
    if (!open) {
      setInputValue("")
      setIsDeleting(false)
    }
  }, [open])

  const handleConfirm = async () => {
    if (!isSlugMatch) return

    setIsDeleting(true)
    try {
      await onConfirm()
      // Dialog will be closed by parent component after successful deletion
    } catch (error) {
      // Error handling is done by parent component
      setIsDeleting(false)
    }
  }

  const handleCancel = () => {
    setInputValue("")
    setIsDeleting(false)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            Delete Department
          </DialogTitle>
          <DialogDescription>
            This action cannot be undone. This will permanently delete the department and all associated
            configurations.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Department Name Display */}
          <div className="rounded-md border border-destructive/50 bg-destructive/10 p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-destructive mt-0.5 flex-shrink-0" />
              <div className="space-y-1 flex-1 min-w-0">
                <p className="text-sm font-medium text-destructive">Warning</p>
                <p className="text-sm text-muted-foreground">
                  You are about to permanently delete:
                </p>
                <p className="text-base font-semibold text-foreground break-words">
                  {departmentName}
                </p>
              </div>
            </div>
          </div>

          {/* Slug Confirmation Input */}
          <div className="space-y-2">
            <Label htmlFor="slug-confirm" className="text-sm font-medium">
              Type <code className="px-1.5 py-0.5 rounded bg-muted font-mono text-sm text-destructive">{departmentSlug}</code> to confirm deletion:
            </Label>
            <Input
              id="slug-confirm"
              type="text"
              placeholder={departmentSlug}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              disabled={isDeleting}
              autoFocus
              autoComplete="off"
              className={inputValue && !isSlugMatch ? "border-destructive focus-visible:ring-destructive" : ""}
              aria-label="Type department slug to confirm deletion"
            />
            {inputValue && !isSlugMatch && (
              <p className="text-xs text-destructive">
                Slug does not match. Please type exactly: <span className="font-mono font-semibold">{departmentSlug}</span>
              </p>
            )}
          </div>

          {/* Additional Warning */}
          <div className="rounded-md bg-muted p-3">
            <p className="text-xs text-muted-foreground">
              <span className="font-semibold text-foreground">Note:</span> Deleting this department will remove:
            </p>
            <ul className="mt-2 space-y-1 text-xs text-muted-foreground ml-4 list-disc">
              <li>All department configurations</li>
              <li>Associated fee structures</li>
              <li>Certificate requirements</li>
              <li>Department portal access</li>
            </ul>
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button
            variant="outline"
            onClick={handleCancel}
            disabled={isDeleting}
          >
            Cancel
          </Button>
          <Button
            variant="destructive"
            onClick={handleConfirm}
            disabled={!isSlugMatch || isDeleting}
          >
            {isDeleting ? (
              <>
                <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-transparent inline-block" />
                Deleting...
              </>
            ) : (
              "Delete Department"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
