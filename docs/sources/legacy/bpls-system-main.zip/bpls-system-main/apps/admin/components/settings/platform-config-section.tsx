"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "convex/react";
import { useState, useMemo } from "react";
import { Settings as SettingsIcon, Save, RotateCcw, Loader2, Lock, Calendar, CalendarClock, Hash, Plus } from "lucide-react";
import { Button } from "@repo/ui/components/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form";
import { Input } from "@repo/ui/components/input";
import { Textarea } from "@repo/ui/components/textarea";
import { Badge } from "@repo/ui/components/badge";
import { RadioGroup, RadioGroupItem } from "@repo/ui/components/radio-group";
import { Label } from "@repo/ui/components/label";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@repo/ui/components/alert-dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip";
import { api } from "@repo/backend/convex/_generated/api";
import {
  platformSettingsSchema,
  platformSettingsDefaultValues,
  type PlatformSettingsSchema,
} from "@/lib/schemas/settings";
import { usePermissions } from "@/hooks/use-permissions";

interface PlatformConfigSectionProps {
  settings: NonNullable<ReturnType<typeof useQuery<typeof api.platformSettings.get>>>;
  toast: (options: { title: string; description: string; variant?: "default" | "destructive" }) => void;
}

export function PlatformConfigSection({ settings, toast }: PlatformConfigSectionProps) {
  const { canUpdate, isLoading: permissionsLoading } = usePermissions();
  const canEdit = canUpdate("settings:platform_configuration");
  const updateSettings = useMutation(api.platformSettings.update);
  const resetSettings = useMutation(api.platformSettings.reset);

  const form = useForm<PlatformSettingsSchema>({
    resolver: zodResolver(platformSettingsSchema),
    defaultValues: {
      platformName: settings?.platformName ?? platformSettingsDefaultValues.platformName,
      platformTitle: settings?.platformTitle ?? platformSettingsDefaultValues.platformTitle,
      tagline: settings?.tagline ?? platformSettingsDefaultValues.tagline,
      currencyFormat: (settings?.currencyFormat as "PHP" | "USD") ?? platformSettingsDefaultValues.currencyFormat,
      fiscalYearStart:
        (settings?.fiscalYearStart as "january" | "april" | "july" | "october") ??
        platformSettingsDefaultValues.fiscalYearStart,
      permitExpiryMode:
        (settings?.permitExpiryMode as "one_year" | "end_of_year") ??
        "end_of_year", // Default to end of calendar year
      permitNumberFormat: settings?.permitNumberFormat ?? "BP-{{YEAR}}-{{SEQUENCE}}",
    },
  });

  // Permit number format preview
  const watchedFormat = form.watch("permitNumberFormat");
  const formatPreview = useMemo(() => {
    const format = watchedFormat || "BP-{{YEAR}}-{{SEQUENCE}}";
    const now = new Date();
    const year = now.getFullYear();
    const yearShort = String(year).slice(-2);
    const month = String(now.getMonth() + 1).padStart(2, "0");

    let preview = format;
    preview = preview.replace(/\{\{YEAR\}\}/g, String(year));
    preview = preview.replace(/\{\{YEAR_SHORT\}\}/g, yearShort);
    preview = preview.replace(/\{\{MONTH\}\}/g, month);
    preview = preview.replace(/\{\{SEQUENCE(?::(\d+))?\}\}/g, (_match: string, digits: string) => {
      const pad = digits ? parseInt(digits, 10) : 5;
      return "1".padStart(pad, "0");
    });
    return preview;
  }, [watchedFormat]);

  const FORMAT_VARIABLES = [
    { variable: "{{YEAR}}", description: "4-digit year (e.g., 2026)" },
    { variable: "{{YEAR_SHORT}}", description: "2-digit year (e.g., 26)" },
    { variable: "{{MONTH}}", description: "2-digit month (e.g., 02)" },
    { variable: "{{SEQUENCE}}", description: "Sequential number (5 digits)" },
    { variable: "{{SEQUENCE:3}}", description: "Sequential number (3 digits)" },
  ];

  const insertVariable = (variable: string) => {
    const currentValue = form.getValues("permitNumberFormat") || "";
    form.setValue("permitNumberFormat", currentValue + variable, { shouldDirty: true });
  };

  const onSubmit = async (values: PlatformSettingsSchema) => {
    try {
      await updateSettings(values);
      toast({
        title: "Settings saved",
        description: "Platform configuration has been updated successfully.",
      });
    } catch {
      toast({
        title: "Error",
        description: "Failed to save settings. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleReset = async () => {
    try {
      await resetSettings({});
      form.reset(platformSettingsDefaultValues);
      toast({
        title: "Settings reset",
        description: "Platform settings have been reset to defaults.",
      });
    } catch {
      toast({
        title: "Error",
        description: "Failed to reset settings. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <SettingsIcon className="h-5 w-5" />
              Platform Configuration
              {!canEdit && !permissionsLoading && (
                <Badge variant="secondary" className="ml-2 gap-1">
                  <Lock className="h-3 w-3" />
                  Read Only
                </Badge>
              )}
              {canEdit && (
                <Badge variant="outline" className="ml-2">
                  Admin Only
                </Badge>
              )}
            </CardTitle>
            <CardDescription>Configure platform-wide settings that apply across the system</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="platformName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Platform Name</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="BPLS Portal" disabled={!canEdit || permissionsLoading} />
                  </FormControl>
                  <FormDescription>
                    Short name displayed in the navigation bar and headers
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="platformTitle"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Platform Title</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Business Permit & Licensing System" disabled={!canEdit || permissionsLoading} />
                  </FormControl>
                  <FormDescription>Full descriptive title for the platform</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="tagline"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tagline</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      placeholder="Streamlining business permit applications for local government"
                      rows={2}
                      disabled={!canEdit || permissionsLoading}
                    />
                  </FormControl>
                  <FormDescription>
                    A short description or tagline for the platform (shown on login page)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Permit Expiration Setting */}
            <FormField
              control={form.control}
              name="permitExpiryMode"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormLabel>Permit Expiration</FormLabel>
                  <FormDescription>
                    Configure how business permit expiration dates are calculated when issuing permits
                  </FormDescription>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      value={field.value}
                      className="space-y-3"
                      disabled={!canEdit || permissionsLoading}
                    >
                      <div className={`flex items-start space-x-3 p-4 border rounded-lg transition-colors ${field.value === "one_year" ? "border-primary bg-primary/5" : "border-border"}`}>
                        <RadioGroupItem value="one_year" id="one_year" className="mt-0.5" />
                        <div className="flex-1">
                          <Label htmlFor="one_year" className="font-medium flex items-center gap-2 cursor-pointer">
                            <CalendarClock className="h-4 w-4 text-muted-foreground" />
                            1 Year from Release Date
                          </Label>
                          <p className="text-sm text-muted-foreground mt-1">
                            Permit expires exactly 1 year after the permit is issued
                          </p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Example: Issued Jan 4, 2026 → Expires Jan 4, 2027
                          </p>
                        </div>
                      </div>
                      <div className={`flex items-start space-x-3 p-4 border rounded-lg transition-colors ${field.value === "end_of_year" ? "border-primary bg-primary/5" : "border-border"}`}>
                        <RadioGroupItem value="end_of_year" id="end_of_year" className="mt-0.5" />
                        <div className="flex-1">
                          <Label htmlFor="end_of_year" className="font-medium flex items-center gap-2 cursor-pointer">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            End of Calendar Year (December 31)
                          </Label>
                          <p className="text-sm text-muted-foreground mt-1">
                            Permit expires on December 31st of the current year
                          </p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            Example: Issued Jan 4, 2026 → Expires Dec 31, 2026
                          </p>
                        </div>
                      </div>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

          </CardContent>
        </Card>

        {/* Permit Number Format Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Hash className="h-5 w-5" />
              Permit Number Format
            </CardTitle>
            <CardDescription>
              Configure how permit numbers are auto-generated when issuing new business permits
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <FormField
              control={form.control}
              name="permitNumberFormat"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Format Template</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      value={field.value ?? ""}
                      placeholder="BP-{{YEAR}}-{{SEQUENCE}}"
                      disabled={!canEdit || permissionsLoading}
                    />
                  </FormControl>
                  <FormDescription>
                    Use variables below to build your format. The permit number can still be overridden during issuance.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Available Variables */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Available Variables</Label>
              <TooltipProvider>
                <div className="flex flex-wrap gap-2">
                  {FORMAT_VARIABLES.map((v) => (
                    <Tooltip key={v.variable}>
                      <TooltipTrigger asChild>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          className="h-7 text-xs font-mono"
                          onClick={() => insertVariable(v.variable)}
                          disabled={!canEdit || permissionsLoading}
                        >
                          <Plus className="h-3 w-3 mr-1" />
                          {v.variable}
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{v.description}</p>
                      </TooltipContent>
                    </Tooltip>
                  ))}
                </div>
              </TooltipProvider>
            </div>

            {/* Live Preview */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Preview</Label>
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-sm font-mono font-medium">{formatPreview}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Next permit number will look like this
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {canEdit && (
          <div className="flex justify-end gap-2">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button type="button" variant="outline">
                  <RotateCcw className="mr-2 h-4 w-4" />
                  Reset to Defaults
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Reset platform settings?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will reset all platform settings to their default values. This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleReset}>Reset</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>

            <Button type="submit" disabled={form.formState.isSubmitting}>
              {form.formState.isSubmitting ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Save className="mr-2 h-4 w-4" />
              )}
              Save Changes
            </Button>
          </div>
        )}
      </form>
    </Form>
  );
}
