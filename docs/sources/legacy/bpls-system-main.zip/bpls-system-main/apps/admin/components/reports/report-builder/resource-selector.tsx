"use client"

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import { Label } from "@repo/ui/components/label"
import {
  FileText,
  Receipt,
  CreditCard,
  BadgeCheck,
  Building2,
  Users,
  FileEdit,
} from "lucide-react"
import { RESOURCE_META } from "@/lib/config/report-resources"
import type { ResourceType } from "@/lib/types/report-builder"

const ICON_MAP: Record<string, React.ReactNode> = {
  FileText: <FileText className="size-4" />,
  Receipt: <Receipt className="size-4" />,
  CreditCard: <CreditCard className="size-4" />,
  BadgeCheck: <BadgeCheck className="size-4" />,
  Building2: <Building2 className="size-4" />,
  Users: <Users className="size-4" />,
  FileEdit: <FileEdit className="size-4" />,
}

interface ResourceSelectorProps {
  value: ResourceType | null
  onChange: (value: ResourceType) => void
  disabled?: boolean
}

export function ResourceSelector({
  value,
  onChange,
  disabled,
}: ResourceSelectorProps) {
  const resources = Object.values(RESOURCE_META)

  return (
    <div className="space-y-1.5">
      <Label htmlFor="resource-selector" className="text-xs">Data Source</Label>
      <Select
        value={value || ""}
        onValueChange={(val) => onChange(val as ResourceType)}
        disabled={disabled}
      >
        <SelectTrigger id="resource-selector" className="w-full h-8 text-xs">
          <SelectValue placeholder="Select a data source..." />
        </SelectTrigger>
        <SelectContent>
          {resources.map((resource) => (
            <SelectItem key={resource.type} value={resource.type}>
              <div className="flex items-center gap-2">
                <span className="[&>svg]:size-3.5">{ICON_MAP[resource.icon]}</span>
                <span className="text-xs">{resource.name}</span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      {value && (
        <p className="text-[11px] text-muted-foreground line-clamp-2">
          {RESOURCE_META[value].description}
        </p>
      )}
    </div>
  )
}
