/**
 * Add Department Fee Dialog Component
 *
 * Dialog form for adding new fees to a department's fee library.
 * Features:
 * - Fee name and description
 * - Default amount configuration
 * - Active/inactive status toggle
 * - Form validation with Zod
 */

"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@repo/ui/components/form";
import { Input } from "@repo/ui/components/input";
import { Textarea } from "@repo/ui/components/textarea";
import { Button } from "@repo/ui/components/button";
import { Checkbox } from "@repo/ui/components/checkbox";
import type { DepartmentFee } from "@/lib/types/fees";

// Schema for fee form
const feeFormSchema = z.object({
  name: z.string().min(1, "Fee name is required").min(3, "Fee name must be at least 3 characters"),
  description: z.string(),
  defaultAmount: z.number().min(0, "Amount must be positive").max(1000000, "Amount cannot exceed ₱1,000,000"),
  isActive: z.boolean(),
});

type FeeFormSchema = z.infer<typeof feeFormSchema>;

interface AddDepartmentFeeDialogProps {
  /** Whether the dialog is open */
  open: boolean;
  /** Callback when dialog close state changes */
  onOpenChange: (open: boolean) => void;
  /** Department ID this fee belongs to */
  departmentId: string;
  /** Department name for display */
  departmentName: string;
  /** Callback when form is submitted successfully */
  onSubmit: (fee: Omit<DepartmentFee, "id">) => void;
}

export function AddDepartmentFeeDialog({
  open,
  onOpenChange,
  departmentId,
  departmentName,
  onSubmit,
}: AddDepartmentFeeDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<FeeFormSchema>({
    resolver: zodResolver(feeFormSchema),
    defaultValues: {
      name: "",
      description: "",
      defaultAmount: 0,
      isActive: true,
    },
    mode: "onChange",
  });

  const handleSubmit = async (values: FeeFormSchema) => {
    setIsSubmitting(true);
    try {
      onSubmit({
        name: values.name,
        description: values.description || "",
        defaultAmount: values.defaultAmount,
        departmentId,
        isActive: values.isActive,
      });

      form.reset();
      onOpenChange(false);
    } catch (error) {
      console.error("Failed to add fee:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Add Fee</DialogTitle>
          <DialogDescription>Add a new fee to {departmentName} fee library</DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Fee Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Inspection Fee" {...field} />
                  </FormControl>
                  <FormDescription>Display name for this fee</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description </FormLabel>
                  <FormControl>
                    <Textarea placeholder="Brief description of the fee" className="resize-none" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="defaultAmount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Default Amount</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₱</span>
                      <Input
                        type="number"
                        placeholder="0.00"
                        className="pl-7"
                        step="0.01"
                        min="0"
                        {...field}
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        value={field.value}
                      />
                    </div>
                  </FormControl>
                  <FormDescription>Default fee amount in Philippine Pesos</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="isActive"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                  <FormControl>
                    <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Active</FormLabel>
                    <FormDescription>Active fees can be selected when approving clearances</FormDescription>
                  </div>
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting || !form.formState.isValid}>
                {isSubmitting ? "Adding..." : "Add Fee"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
