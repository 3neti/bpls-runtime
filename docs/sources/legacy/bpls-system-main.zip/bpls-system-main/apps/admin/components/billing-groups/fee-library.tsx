"use client"

import { useState } from "react"
import { useMutation, useQuery } from "convex/react"
import {
  Plus,
  MoreHorizontal,
  Pencil,
  Trash2,
  ToggleLeft,
  ToggleRight,
  Library,
  Settings,
} from "lucide-react"

import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@repo/ui/components/tabs"
import { useToast } from "@/hooks/use-toast"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { formatCurrency } from "@/lib/utils"
import { FeeModal } from "./fee-modal"
import { FeeFieldManager } from "./fee-field-manager"

interface FeeLibraryProps {
  billingGroupId: Id<"billing_groups">
  canCreate?: boolean
  canUpdate?: boolean
  canDelete?: boolean
}

export function FeeLibrary({
  billingGroupId,
  canCreate = true,
  canUpdate = true,
  canDelete = true,
}: FeeLibraryProps) {
  const { toast } = useToast()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingFeeId, setEditingFeeId] = useState<Id<"billing_group_fees"> | null>(null)
  const [deletingFeeId, setDeletingFeeId] = useState<Id<"billing_group_fees"> | null>(null)
  const [showInactive, setShowInactive] = useState(false)

  // Fetch fees
  const fees = useQuery(api.billingGroupFees.listByGroup, {
    billingGroupId,
    includeInactive: showInactive,
  })

  // Fetch custom fields
  const customFields = useQuery(api.billingGroupFeeFields.listByGroup, {
    billingGroupId,
  })

  // Fetch fee count
  const feeCount = useQuery(api.billingGroupFees.getCount, { billingGroupId })

  // Mutations
  const deleteFee = useMutation(api.billingGroupFees.softDelete)
  const toggleActive = useMutation(api.billingGroupFees.toggleActive)

  const handleDelete = async () => {
    if (!deletingFeeId) return

    try {
      await deleteFee({ id: deletingFeeId })
      toast({
        title: "Fee deleted",
        description: "The fee has been removed from the library.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete fee",
        variant: "destructive",
      })
    } finally {
      setDeletingFeeId(null)
    }
  }

  const handleToggleActive = async (feeId: Id<"billing_group_fees">) => {
    try {
      await toggleActive({ id: feeId })
      toast({
        title: "Status updated",
        description: "Fee status has been updated.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update status",
        variant: "destructive",
      })
    }
  }

  const openEditModal = (feeId: Id<"billing_group_fees">) => {
    setEditingFeeId(feeId)
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setIsModalOpen(false)
    setEditingFeeId(null)
  }

  return (
    <>
      <Tabs defaultValue="fees" className="space-y-4">
        <TabsList>
          <TabsTrigger value="fees">
            <Library className="mr-2 h-4 w-4" />
            Line Items ({feeCount?.total || 0})
          </TabsTrigger>
          <TabsTrigger value="columns">
            <Settings className="mr-2 h-4 w-4" />
            Custom Columns ({customFields?.length || 0})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="fees">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Line Items</CardTitle>
                  <CardDescription>
                    Manage line items available for transactions in this billing group
                  </CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowInactive(!showInactive)}
                  >
                    {showInactive ? (
                      <>
                        <ToggleRight className="mr-2 h-4 w-4" />
                        Hide Inactive
                      </>
                    ) : (
                      <>
                        <ToggleLeft className="mr-2 h-4 w-4" />
                        Show Inactive
                      </>
                    )}
                  </Button>
                  {canCreate && (
                    <Button onClick={() => setIsModalOpen(true)}>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Fee
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {!fees || fees.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Library className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No fees in library</h3>
                  <p className="text-muted-foreground mb-4 max-w-sm">
                    Add fees to the library to use them in transactions
                  </p>
                  {canCreate && (
                    <Button onClick={() => setIsModalOpen(true)}>
                      <Plus className="mr-2 h-4 w-4" />
                      Add First Fee
                    </Button>
                  )}
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Code</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead className="text-right">Default Amount</TableHead>
                        {customFields?.map((field: NonNullable<typeof customFields>[number]) => (
                          <TableHead key={field._id}>{field.name}</TableHead>
                        ))}
                        <TableHead>Status</TableHead>
                        <TableHead className="w-[50px]"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {fees.map((fee: NonNullable<typeof fees>[number]) => (
                        <TableRow key={fee._id} className={!fee.isActive ? "opacity-50" : ""}>
                          <TableCell className="font-mono text-sm">
                            {fee.code}
                          </TableCell>
                          <TableCell className="font-medium">{fee.name}</TableCell>
                          <TableCell className="text-right">
                            {formatCurrency(fee.defaultAmount)}
                          </TableCell>
                          {customFields?.map((field: NonNullable<typeof customFields>[number]) => {
                            const fieldValue = fee.customFieldValues?.find(
                              (fv: { fieldId: string; value: string }) => fv.fieldId === field._id
                            )
                            return (
                              <TableCell key={field._id}>
                                {formatCustomFieldValue(fieldValue?.value, field.fieldType)}
                              </TableCell>
                            )
                          })}
                          <TableCell>
                            <Badge
                              variant={fee.isActive ? "default" : "secondary"}
                              className={fee.isActive ? "bg-green-100 text-green-800" : ""}
                            >
                              {fee.isActive ? "Active" : "Inactive"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                {canUpdate && (
                                  <DropdownMenuItem onClick={() => openEditModal(fee._id)}>
                                    <Pencil className="h-4 w-4 mr-2" />
                                    Edit Fee
                                  </DropdownMenuItem>
                                )}
                                {canUpdate && (
                                  <DropdownMenuItem onClick={() => handleToggleActive(fee._id)}>
                                    {fee.isActive ? (
                                      <>
                                        <ToggleLeft className="h-4 w-4 mr-2" />
                                        Deactivate
                                      </>
                                    ) : (
                                      <>
                                        <ToggleRight className="h-4 w-4 mr-2" />
                                        Activate
                                      </>
                                    )}
                                  </DropdownMenuItem>
                                )}
                                {canDelete && (
                                  <>
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem
                                      onClick={() => setDeletingFeeId(fee._id)}
                                      className="text-destructive focus:text-destructive"
                                    >
                                      <Trash2 className="h-4 w-4 mr-2" />
                                      Delete Fee
                                    </DropdownMenuItem>
                                  </>
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="columns">
          <FeeFieldManager billingGroupId={billingGroupId} fields={customFields || []} canCreate={canCreate} canUpdate={canUpdate} canDelete={canDelete} />
        </TabsContent>
      </Tabs>

      {/* Fee Modal */}
      <FeeModal
        open={isModalOpen}
        onClose={closeModal}
        billingGroupId={billingGroupId}
        editingFeeId={editingFeeId}
        customFields={customFields || []}
      />

      {/* Delete Confirmation */}
      <AlertDialog open={deletingFeeId !== null} onOpenChange={() => setDeletingFeeId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Fee?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the fee from the library. Fees that are used in existing
              transactions cannot be deleted.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}

// Helper function to format custom field values
function formatCustomFieldValue(
  value: string | undefined,
  fieldType: string
): string {
  if (!value) return "—"

  switch (fieldType) {
    case "currency":
      const num = parseFloat(value)
      return isNaN(num) ? value : formatCurrency(num)
    case "date":
      try {
        return new Date(value).toLocaleDateString()
      } catch {
        return value
      }
    case "checkbox":
      return value === "true" ? "Yes" : "No"
    case "number":
      const numVal = parseFloat(value)
      return isNaN(numVal) ? value : numVal.toLocaleString()
    default:
      return value
  }
}
