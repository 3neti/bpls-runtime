"use client"

import { useState, useEffect } from "react"
import { Document, Page, Text, View, StyleSheet, PDFViewer } from "@react-pdf/renderer"
import {
  parseBillingGroupTemplate,
  formatCurrency,
  type BillingGroupMacroData,
  type BillingGroupLineItem,
} from "@/lib/utils/billing-group-template-renderer"

// Paper sizes in points (1 point = 1/72 inch)
const PAPER_SIZES = {
  A4: { width: 595.28, height: 841.89 },
  Letter: { width: 612, height: 792 },
  "Half-Letter": { width: 396, height: 612 },
}

// Fixed table configuration for consistent receipt formatting
const TABLE_FIXED_ROWS = 11
const ROW_HEIGHT = 11 // points (fontSize 10 + marginBottom 1)

// Static sample line items for preview - always displayed
const SAMPLE_LINE_ITEMS: BillingGroupLineItem[] = [
  { feeCode: "FEE-001", feeName: "Registration Fee", amount: 500.0, quantity: 1, subtotal: 500.0 },
  { feeCode: "FEE-002", feeName: "Processing Fee", amount: 750.0, quantity: 2, subtotal: 1500.0 },
  { feeCode: "FEE-003", feeName: "Documentary Stamp", amount: 500.0, quantity: 1, subtotal: 500.0 },
]

// ✅ Module-level base styles (static) - MUST be outside component
// StyleSheet.create() maintains an internal global registry in @react-pdf/renderer.
// When called inside a component, new styles are registered on every render.
// In production (Vercel), module state persists across renders, causing registry corruption
// and the "l1 is not a function" error when viewing receipts multiple times.
const baseStyles = StyleSheet.create({
  page: {
    backgroundColor: "#ffffff",
    color: "#000000",
  },
  section: {
    marginBottom: 10,
  },
  text: {
    marginBottom: 2,
  },
  header: {
    marginBottom: 15,
  },
  body: {
    flex: 1,
  },
  footer: {
    marginTop: 15,
  },
  lineItemsTable: {
    marginVertical: 10,
  },
  lineItemRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    height: ROW_HEIGHT,
    marginBottom: 1,
  },
  lineItemName: {
    flex: 1,
  },
  lineItemAmount: {
    width: 80,
    textAlign: "right",
  },
  separator: {
    borderBottomWidth: 1,
    borderBottomColor: "#000000",
    marginVertical: 5,
  },
  emptyState: {
    color: "#999999",
    fontStyle: "italic",
  },
})

interface BillingGroupLayoutPreviewProps {
  headerTemplate: string
  bodyTemplate: string
  footerTemplate: string
  paperSize: "A4" | "Letter" | "Half-Letter"
  orientation: "portrait" | "landscape"
  marginTop: number
  marginRight: number
  marginBottom: number
  marginLeft: number
  fontSize: number
  fontFamily: "Helvetica" | "Times-Roman" | "Courier"
  data: BillingGroupMacroData
}

// Convert mm to points (1mm = 2.83465 points)
const mmToPoints = (mm: number) => mm * 2.83465

// Inner document component that doesn't use hooks
function BillingGroupReceiptDocument({
  headerTemplate,
  bodyTemplate,
  footerTemplate,
  paperSize,
  orientation,
  marginTop,
  marginRight,
  marginBottom,
  marginLeft,
  fontSize,
  fontFamily,
  data,
}: BillingGroupLayoutPreviewProps) {
  // Get paper dimensions based on size and orientation
  const size = PAPER_SIZES[paperSize] || PAPER_SIZES.A4
  const dimensions =
    orientation === "landscape"
      ? { width: size.height, height: size.width }
      : size

  // ✅ Dynamic styles as plain objects (NOT StyleSheet.create)
  // These depend on layout props and must be computed per-render
  const dynamicPageStyle = {
    paddingTop: mmToPoints(marginTop || 10),
    paddingRight: mmToPoints(marginRight || 10),
    paddingBottom: mmToPoints(marginBottom || 10),
    paddingLeft: mmToPoints(marginLeft || 10),
    fontSize: fontSize || 10,
    fontFamily: fontFamily || "Helvetica",
  }

  const tableHeightStyle = {
    height: TABLE_FIXED_ROWS * (ROW_HEIGHT + 1), // Account for marginBottom in each row
  }

  // Parse templates with data - wrap in try-catch for safety
  let parsedHeader = ""
  let parsedBody = ""
  let parsedFooter = ""

  try {
    parsedHeader = parseBillingGroupTemplate(headerTemplate || "", data)
    parsedBody = parseBillingGroupTemplate(bodyTemplate || "", data)
    parsedFooter = parseBillingGroupTemplate(footerTemplate || "", data)
  } catch (e) {
    console.error("Template parsing error:", e)
  }

  // Preserve whitespace by converting spaces to non-breaking spaces
  const preserveWhitespace = (text: string): string => {
    if (!text) return ""
    return text.replace(/ /g, "\u00A0")
  }

  // Render line items table with fixed 11 rows - always use static sample data for preview
  const renderLineItemsTable = (_lineItems: BillingGroupLineItem[] | undefined) => {
    // Always use static sample data for consistent preview display
    const items = SAMPLE_LINE_ITEMS
    const emptyRowsCount = Math.max(0, TABLE_FIXED_ROWS - items.length)

    return (
      <View style={[baseStyles.lineItemsTable, tableHeightStyle]}>
        {/* Render actual items (max 11) */}
        {items.slice(0, TABLE_FIXED_ROWS).map((item, index) => (
          <View key={index} style={baseStyles.lineItemRow}>
            <Text style={baseStyles.lineItemName}>{item.feeName}</Text>
            <Text style={baseStyles.lineItemAmount}>{formatCurrency(item.subtotal)}</Text>
          </View>
        ))}
        {/* Render empty rows to fill to 11 */}
        {Array.from({ length: emptyRowsCount }).map((_, index) => (
          <View key={`empty-${index}`} style={baseStyles.lineItemRow}>
            <Text style={baseStyles.lineItemName}>{"\u00A0"}</Text>
            <Text style={baseStyles.lineItemAmount}>{"\u00A0"}</Text>
          </View>
        ))}
      </View>
    )
  }

  // Render lines of text
  const renderLines = (content: string) => {
    if (!content) return null

    const lines = content.split("\n")
    return (
      <>
        {lines.map((line, index) => (
          <Text key={index} style={baseStyles.text}>
            {preserveWhitespace(line) || "\u00A0"}
          </Text>
        ))}
      </>
    )
  }

  // Render text with line breaks and handle {{LINE_ITEMS_TABLE}}
  const renderTemplateContent = (content: string) => {
    if (!content) return null

    // Split by LINE_ITEMS_TABLE marker - use regex for robust whitespace handling
    if (/\{\{\s*LINE_ITEMS_TABLE\s*\}\}/.test(content)) {
      const parts = content.split(/\{\{\s*LINE_ITEMS_TABLE\s*\}\}/)
      return (
        <>
          {parts[0] && renderLines(parts[0])}
          {renderLineItemsTable(data.lineItems)}
          {parts[1] && renderLines(parts[1])}
        </>
      )
    }

    return renderLines(content)
  }

  // Check if all templates are empty
  const isEmpty = !parsedHeader && !parsedBody && !parsedFooter

  return (
    <Document>
      {/* Combine static baseStyles with dynamic styles */}
      <Page size={dimensions} style={[baseStyles.page, dynamicPageStyle]}>
        {isEmpty ? (
          <View style={baseStyles.body}>
            <Text style={baseStyles.emptyState}>
              Enter template content to see preview...
            </Text>
          </View>
        ) : (
          <>
            {/* Header */}
            <View style={baseStyles.header}>{renderTemplateContent(parsedHeader)}</View>

            {/* Body */}
            <View style={baseStyles.body}>{renderTemplateContent(parsedBody)}</View>

            {/* Footer */}
            <View style={baseStyles.footer}>{renderTemplateContent(parsedFooter)}</View>
          </>
        )}
      </Page>
    </Document>
  )
}

// Simple hash function for string content
const hashContent = (str: string): number => {
  let hash = 0
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i)
    hash = (hash << 5) - hash + char
    hash = hash & hash // Convert to 32bit integer
  }
  return hash
}

export default function BillingGroupLayoutPreview(props: BillingGroupLayoutPreviewProps) {
  const [isReady, setIsReady] = useState(false)

  // Delay rendering to ensure PDF library is fully loaded
  useEffect(() => {
    const timer = setTimeout(() => setIsReady(true), 50)
    return () => clearTimeout(timer)
  }, [])

  // Generate a key that includes content hash to force remount when content changes
  // This prevents @react-pdf/renderer bugs with in-place updates when structure changes
  const contentHash = hashContent(
    props.headerTemplate + props.bodyTemplate + props.footerTemplate
  )
  const key = `${props.paperSize}-${props.orientation}-${props.fontFamily}-${contentHash}`

  if (!isReady) {
    return (
      <div className="flex items-center justify-center h-full bg-muted/30 text-muted-foreground">
        <p className="text-sm">Loading preview...</p>
      </div>
    )
  }

  // Check if we have content to render
  const hasContent =
    props.headerTemplate || props.bodyTemplate || props.footerTemplate

  if (!hasContent) {
    return (
      <div className="flex items-center justify-center h-full bg-muted/30 text-muted-foreground">
        <p className="text-sm">Enter template content to see preview...</p>
      </div>
    )
  }

  return (
    <PDFViewer key={key} width="100%" height="100%" showToolbar={false}>
      <BillingGroupReceiptDocument {...props} />
    </PDFViewer>
  )
}
