"use client"

import { useState } from "react"
import { useQuery } from "convex/react"
import { Check, ChevronsUpDown, Search } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@repo/ui/components/button"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@repo/ui/components/command"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@repo/ui/components/popover"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { formatCurrency } from "@/lib/utils"

interface FeeCustomFieldValue {
  fieldId: Id<"billing_group_fee_fields">
  value: string
}

interface Fee {
  _id: Id<"billing_group_fees">
  name: string
  code: string
  defaultAmount: number
  isActive: boolean
  customFieldValues?: FeeCustomFieldValue[]
}

interface FeeSelectorProps {
  billingGroupId: Id<"billing_groups">
  value?: Id<"billing_group_fees">
  onSelect: (fee: Fee | null) => void
  disabled?: boolean
  placeholder?: string
  excludeIds?: Id<"billing_group_fees">[]
}

export function FeeSelector({
  billingGroupId,
  value,
  onSelect,
  disabled = false,
  placeholder = "Select a fee...",
  excludeIds = [],
}: FeeSelectorProps) {
  const [open, setOpen] = useState(false)

  // Fetch fees for this billing group
  const fees = useQuery(api.billingGroupFees.listByGroup, {
    billingGroupId,
    includeInactive: false,
  })

  // Filter out excluded fees
  const availableFees = fees?.filter(
    (fee: Fee) => !excludeIds.includes(fee._id)
  ) || []

  // Find selected fee
  const selectedFee = fees?.find((f: Fee) => f._id === value)

  const handleSelect = (feeId: string) => {
    const fee = fees?.find((f: Fee) => f._id === feeId)
    onSelect(fee || null)
    setOpen(false)
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          disabled={disabled || !fees}
          className={cn(
            "w-full justify-between overflow-hidden",
            !value && "text-muted-foreground"
          )}
        >
          {selectedFee ? (
            <span className="flex items-center gap-2 truncate">
              <span className="font-mono text-xs text-muted-foreground">
                {selectedFee.code}
              </span>
              <span className="truncate">{selectedFee.name}</span>
            </span>
          ) : (
            placeholder
          )}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[400px] p-0" align="start">
        <Command>
          <CommandInput placeholder="Search fees..." />
          <CommandList>
            <CommandEmpty>No fees found.</CommandEmpty>
            <CommandGroup>
              {availableFees.map((fee: Fee) => (
                <CommandItem
                  key={fee._id}
                  value={`${fee.code} ${fee.name}`}
                  onSelect={() => handleSelect(fee._id)}
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <Check
                      className={cn(
                        "h-4 w-4",
                        value === fee._id ? "opacity-100" : "opacity-0"
                      )}
                    />
                    <span className="font-mono text-xs text-muted-foreground">
                      {fee.code}
                    </span>
                    <span>{fee.name}</span>
                  </div>
                  <span className="text-muted-foreground">
                    {formatCurrency(fee.defaultAmount)}
                  </span>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  )
}
