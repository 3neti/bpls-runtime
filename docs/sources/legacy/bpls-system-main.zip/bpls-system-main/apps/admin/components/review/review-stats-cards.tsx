import type { DepartmentStats } from "@/lib/types/department"

interface ReviewStatsCardsProps {
  /** Statistics to display in the cards */
  stats: DepartmentStats
}

/**
 * ReviewStatsCards Component
 *
 * Displays three statistics cards showing clearance review metrics:
 * - Total Pending: Total number of pending clearances
 * - Awaiting Review: Number of clearances awaiting approval
 * - Approved Today: Number of clearances approved today
 *
 * Used in clearance approval workflows to show progress and workload.
 *
 * Mobile responsive with grid layout that stacks on small screens.
 *
 * @example
 * ```tsx
 * <ReviewStatsCards
 *   stats={{
 *     totalPending: 25,
 *     awaitingReview: 18,
 *     approvedToday: 7
 *   }}
 * />
 * ```
 */
export function ReviewStatsCards({ stats }: ReviewStatsCardsProps) {
  return (
    <div className="grid gap-3 grid-cols-1 sm:grid-cols-3 lg:gap-4">
      <div className="rounded-lg border bg-card p-4 lg:p-6">
        <div className="text-xs font-medium text-muted-foreground sm:text-sm">Total Pending</div>
        <div className="text-xl font-bold sm:text-2xl lg:text-3xl mt-1">{stats.totalPending}</div>
      </div>
      <div className="rounded-lg border bg-card p-4 lg:p-6">
        <div className="text-xs font-medium text-muted-foreground sm:text-sm">Awaiting Review</div>
        <div className="text-xl font-bold sm:text-2xl lg:text-3xl mt-1">{stats.awaitingReview}</div>
      </div>
      <div className="rounded-lg border bg-card p-4 lg:p-6">
        <div className="text-xs font-medium text-muted-foreground sm:text-sm">Approved Today</div>
        <div className="text-xl font-bold sm:text-2xl lg:text-3xl mt-1">{stats.approvedToday}</div>
      </div>
    </div>
  )
}
