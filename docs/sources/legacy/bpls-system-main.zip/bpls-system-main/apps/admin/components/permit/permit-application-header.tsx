/**
 * PermitApplicationHeader Component
 *
 * Displays the header section of a permit application with:
 * - Back button navigation
 * - Application number and submission date
 * - Status badge
 * - Action buttons (Approve/Reject) - optional
 */

import { ArrowLeft, CheckCircle, XCircle, Clock, Eye } from "lucide-react"
import Link from "next/link"

import { Button } from "@repo/ui/components/button"
import { Badge } from "@repo/ui/components/badge"
import { formatDate } from "@/lib/utils/permit-helpers"
import { ApplicationStatusSelect } from "@/components/permit/application-status-select"
import type { PermitApplicationStatus } from "@/lib/types/permit-application"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

export interface PermitApplicationHeaderProps {
  applicationNumber: string
  submittedOn: string
  status: string
  backUrl: string
  onApprove?: () => void
  onReject?: () => void
  showActions?: boolean
  /** Enable status dropdown editing */
  enableStatusEdit?: boolean
  /** Application ID for status updates */
  applicationId?: Id<"business_permit_applications">
  /** Whether the status select should be disabled */
  statusSelectDisabled?: boolean
}

const getStatusBadge = (status: string) => {
  switch (status) {
    case "pending":
      return (
        <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
          <Clock className="mr-1 h-3 w-3" />
          Pending Review
        </Badge>
      )
    case "under_review":
      return (
        <Badge variant="secondary" className="bg-blue-100 text-blue-800 hover:bg-blue-100">
          <Eye className="mr-1 h-3 w-3" />
          Under Review
        </Badge>
      )
    case "approved":
      return (
        <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-100">
          <CheckCircle className="mr-1 h-3 w-3" />
          Approved
        </Badge>
      )
    case "rejected":
      return (
        <Badge variant="destructive">
          <XCircle className="mr-1 h-3 w-3" />
          Rejected
        </Badge>
      )
    default:
      return <Badge variant="secondary">{status}</Badge>
  }
}

export function PermitApplicationHeader({
  applicationNumber,
  submittedOn,
  status,
  backUrl,
  onApprove,
  onReject,
  showActions = true,
  enableStatusEdit = false,
  applicationId,
  statusSelectDisabled = false,
}: PermitApplicationHeaderProps) {
  const canShowActionButtons = showActions && (status === "pending" || status === "under_review")

  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-4">
        <Link href={backUrl}>
          <Button variant="ghost" size="sm" className="p-2">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Application Details</h2>
          <p className="text-muted-foreground">
            {applicationNumber} • Submitted {formatDate(submittedOn)}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-4">
        {enableStatusEdit && applicationId ? (
          <ApplicationStatusSelect
            applicationId={applicationId}
            currentStatus={status as PermitApplicationStatus}
            disabled={statusSelectDisabled}
          />
        ) : (
          getStatusBadge(status)
        )}
        {canShowActionButtons && (
          <div className="flex gap-2">
            {onApprove && (
              <Button
                variant="outline"
                className="text-green-600 border-green-600 hover:bg-green-50"
                onClick={onApprove}
              >
                <CheckCircle className="mr-2 h-4 w-4" />
                Approve
              </Button>
            )}
            {onReject && (
              <Button
                variant="outline"
                className="text-red-600 border-red-600 hover:bg-red-50"
                onClick={onReject}
              >
                <XCircle className="mr-2 h-4 w-4" />
                Reject
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
