"use client"

import { useState } from "react"
import { AlertTriangle, Ban, CheckCircle2 } from "lucide-react"
import { Button } from "@repo/ui/components/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { Label } from "@repo/ui/components/label"
import { Textarea } from "@repo/ui/components/textarea"
import { Checkbox } from "@repo/ui/components/checkbox"
import { Alert, AlertDescription } from "@repo/ui/components/alert"

interface BlacklistDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  entityType: "business" | "business-owner"
  entityName: string
  isCurrentlyBlacklisted: boolean
  onConfirm: (reason?: string) => void
  onCancel: () => void
}

export function BlacklistDialog({
  open,
  onOpenChange,
  entityType,
  entityName,
  isCurrentlyBlacklisted,
  onConfirm,
  onCancel,
}: BlacklistDialogProps) {
  const [reason, setReason] = useState("")
  const [confirmed, setConfirmed] = useState(false)
  const [error, setError] = useState("")

  const handleConfirm = () => {
    // If blacklisting, require reason
    if (!isCurrentlyBlacklisted && !reason.trim()) {
      setError("Please provide a reason for blacklisting")
      return
    }

    // Require confirmation checkbox
    if (!confirmed) {
      setError("Please confirm your action by checking the box")
      return
    }

    // Clear errors and proceed
    setError("")
    onConfirm(isCurrentlyBlacklisted ? undefined : reason.trim())
    handleClose()
  }

  const handleClose = () => {
    setReason("")
    setConfirmed(false)
    setError("")
    onOpenChange(false)
  }

  const handleCancel = () => {
    handleClose()
    onCancel()
  }

  const displayEntityType = entityType === "business-owner" ? "business owner" : "business"

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {isCurrentlyBlacklisted ? (
              <>
                <CheckCircle2 className="h-5 w-5 text-green-600" />
                Remove Blacklist
              </>
            ) : (
              <>
                <AlertTriangle className="h-5 w-5 text-destructive" />
                Blacklist {displayEntityType.charAt(0).toUpperCase() + displayEntityType.slice(1)}
              </>
            )}
          </DialogTitle>
          <DialogDescription>
            {isCurrentlyBlacklisted
              ? `Remove blacklist status from this ${displayEntityType}?`
              : `This action will prevent this ${displayEntityType} from being selected in new permit applications.`}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Entity Name Display */}
          <div className="rounded-md border border-border bg-muted/50 p-3">
            <div className="flex items-center gap-2">
              <Ban className="h-4 w-4 text-muted-foreground" />
              <span className="font-medium">{entityName}</span>
            </div>
          </div>

          {/* Reason Input (only for blacklisting) */}
          {!isCurrentlyBlacklisted && (
            <div className="space-y-2">
              <Label htmlFor="reason">
                Reason for Blacklisting <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="reason"
                placeholder="Enter detailed reason for blacklisting this entity..."
                value={reason}
                onChange={(e) => {
                  setReason(e.target.value)
                  if (error) setError("")
                }}
                maxLength={500}
                rows={4}
                className={error && !reason.trim() ? "border-destructive" : ""}
              />
              <p className="text-xs text-muted-foreground text-right">
                {reason.length}/500 characters
              </p>
            </div>
          )}

          {/* Confirmation Checkbox */}
          <div className="flex items-start space-x-3 rounded-md border border-border p-3">
            <Checkbox
              id="confirm"
              checked={confirmed}
              onCheckedChange={(checked) => {
                setConfirmed(checked as boolean)
                if (error) setError("")
              }}
            />
            <div className="grid gap-1.5 leading-none">
              <label
                htmlFor="confirm"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
              >
                {isCurrentlyBlacklisted
                  ? "I confirm that I want to remove the blacklist status"
                  : "I confirm that I want to blacklist this entity"}
              </label>
              <p className="text-xs text-muted-foreground">
                {isCurrentlyBlacklisted
                  ? "This entity will be able to be selected for new permits again."
                  : "This is a permanent action and should only be done after careful consideration."}
              </p>
            </div>
          </div>

          {/* Error Alert */}
          {error && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
          <Button
            variant={isCurrentlyBlacklisted ? "default" : "destructive"}
            onClick={handleConfirm}
          >
            {isCurrentlyBlacklisted ? "Remove Blacklist" : "Confirm Blacklist"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
