"use client";

import { useState, useMemo } from "react";
import { useQuery, useMutation } from "convex/react";
import {
  Plus,
  Edit,
  Trash2,
  Copy,
  Star,
  MoreHorizontal,
  FileText,
  AlertCircle,
  ArrowLeft,
  Lock,
} from "lucide-react";
import { usePermissions } from "@/hooks/use-permissions";

import { Button } from "@repo/ui/components/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Textarea } from "@repo/ui/components/textarea";
import { Badge } from "@repo/ui/components/badge";
import { Skeleton } from "@repo/ui/components/skeleton";
import { Alert, AlertDescription } from "@repo/ui/components/alert";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import { ReceiptLayoutEditor } from "@/components/receipting/receipt-layout-editor";

interface ReceiptingSectionProps {
  toast: (props: {
    title: string;
    description?: string;
    variant?: "default" | "destructive";
  }) => void;
}

const MAX_LAYOUTS = 10;

export function ReceiptingSection({ toast }: ReceiptingSectionProps) {
  const { canUpdate, isLoading: permissionsLoading } = usePermissions();
  const canEdit = canUpdate("settings:receipting");

  const layouts = useQuery(api.receiptLayouts.list);
  const layoutCount = useQuery(api.receiptLayouts.getCount);

  const createLayout = useMutation(api.receiptLayouts.create);
  const deleteLayout = useMutation(api.receiptLayouts.softDelete);
  const duplicateLayout = useMutation(api.receiptLayouts.duplicate);
  const setDefaultLayout = useMutation(api.receiptLayouts.setDefault);

  // View state: "list" or "editor"
  const [view, setView] = useState<"list" | "editor">("list");
  const [editingLayoutId, setEditingLayoutId] = useState<Id<"receipt_layouts"> | null>(null);

  // Dialog states
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  // Form states
  const [newLayoutName, setNewLayoutName] = useState("");
  const [newLayoutDescription, setNewLayoutDescription] = useState("");
  const [layoutToDelete, setLayoutToDelete] = useState<Id<"receipt_layouts"> | null>(null);

  const isLoading = layouts === undefined;
  const isAtLimit = (layoutCount ?? 0) >= MAX_LAYOUTS;

  // Create new layout
  const handleCreate = async () => {
    if (!newLayoutName.trim()) {
      toast({
        title: "Error",
        description: "Please enter a layout name",
        variant: "destructive",
      });
      return;
    }

    try {
      const layoutId = await createLayout({
        name: newLayoutName.trim(),
        description: newLayoutDescription.trim() || undefined,
      });
      toast({
        title: "Layout created",
        description: "Your new receipt layout has been created.",
      });
      setCreateDialogOpen(false);
      setNewLayoutName("");
      setNewLayoutDescription("");
      // Open editor for the new layout
      setEditingLayoutId(layoutId);
      setView("editor");
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create layout",
        variant: "destructive",
      });
    }
  };

  // Delete layout
  const handleDelete = async () => {
    if (!layoutToDelete) return;

    try {
      await deleteLayout({ id: layoutToDelete });
      toast({
        title: "Layout deleted",
        description: "The receipt layout has been deleted.",
      });
      setDeleteDialogOpen(false);
      setLayoutToDelete(null);
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete layout",
        variant: "destructive",
      });
    }
  };

  // Duplicate layout
  const handleDuplicate = async (id: Id<"receipt_layouts">) => {
    try {
      await duplicateLayout({ id });
      toast({
        title: "Layout duplicated",
        description: "A copy of the layout has been created.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to duplicate layout",
        variant: "destructive",
      });
    }
  };

  // Set as default
  const handleSetDefault = async (id: Id<"receipt_layouts">) => {
    try {
      await setDefaultLayout({ id });
      toast({
        title: "Default updated",
        description: "This layout is now the default.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to set default",
        variant: "destructive",
      });
    }
  };

  // Open editor view
  const handleEdit = (id: Id<"receipt_layouts">) => {
    setEditingLayoutId(id);
    setView("editor");
  };

  // Go back to list view
  const handleBack = () => {
    setView("list");
    setEditingLayoutId(null);
  };

  // Confirm delete
  const confirmDelete = (id: Id<"receipt_layouts">) => {
    setLayoutToDelete(id);
    setDeleteDialogOpen(true);
  };

  // Editor View
  if (view === "editor" && editingLayoutId) {
    return (
      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleBack}
              className="h-8 w-8"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <CardTitle>Edit Receipt Layout</CardTitle>
              <CardDescription>
                Customize your receipt template using macros for dynamic content.
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-[calc(100vh-180px)] min-h-[600px]">
            <ReceiptLayoutEditor
              layoutId={editingLayoutId}
              onSave={() => {
                toast({
                  title: "Layout saved",
                  description: "Your changes have been saved.",
                });
              }}
              onClose={handleBack}
            />
          </div>
        </CardContent>
      </Card>
    );
  }

  // List View
  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                Receipt Layouts
                {!canEdit && !permissionsLoading && (
                  <Badge variant="secondary" className="ml-2 gap-1">
                    <Lock className="h-3 w-3" />
                    Read Only
                  </Badge>
                )}
                {canEdit && (
                  <Badge variant="outline" className="ml-2">
                    Admin Only
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>
                Configure custom receipt layouts for payment receipt previews.
                Use templates with macros like {"{{receiptNumber}}"} for dynamic content.
              </CardDescription>
            </div>
            {canEdit && (
              <Button
                onClick={() => setCreateDialogOpen(true)}
                disabled={isAtLimit || permissionsLoading}
              >
                <Plus className="mr-2 h-4 w-4" />
                New Layout
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {/* Limit warning */}
          {isAtLimit && (
            <Alert className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                You have reached the maximum of {MAX_LAYOUTS} receipt layouts.
                Delete an existing layout to create a new one.
              </AlertDescription>
            </Alert>
          )}

          {/* Layout count */}
          {!isLoading && layouts && (
            <p className="text-sm text-muted-foreground mb-4">
              {layouts.length} of {MAX_LAYOUTS} layouts used
            </p>
          )}

          {/* Loading state */}
          {isLoading ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-32 w-full" />
              ))}
            </div>
          ) : layouts && layouts.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {layouts.map((layout) => (
                <LayoutCard
                  key={layout._id}
                  layout={layout}
                  onEdit={() => handleEdit(layout._id)}
                  onDelete={() => confirmDelete(layout._id)}
                  onDuplicate={() => handleDuplicate(layout._id)}
                  onSetDefault={() => handleSetDefault(layout._id)}
                  canEdit={canEdit}
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <FileText className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No receipt layouts yet</h3>
              <p className="text-sm text-muted-foreground mt-1 mb-4">
                {canEdit
                  ? "Create your first custom receipt layout to get started."
                  : "No receipt layouts have been created yet."}
              </p>
              {canEdit && (
                <Button onClick={() => setCreateDialogOpen(true)}>
                  <Plus className="mr-2 h-4 w-4" />
                  Create Layout
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Layout Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Receipt Layout</DialogTitle>
            <DialogDescription>
              Create a new receipt layout template. You can customize it after creation.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Layout Name</Label>
              <Input
                id="name"
                placeholder="e.g., Standard Receipt, Detailed Receipt"
                value={newLayoutName}
                onChange={(e) => setNewLayoutName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description (optional)</Label>
              <Textarea
                id="description"
                placeholder="Describe what this layout is for..."
                value={newLayoutDescription}
                onChange={(e) => setNewLayoutDescription(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreate}>Create Layout</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Receipt Layout</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this receipt layout? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setLayoutToDelete(null)}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

// Layout Card Component
interface LayoutCardProps {
  layout: {
    _id: Id<"receipt_layouts">;
    name: string;
    description?: string;
    isDefault: boolean;
    isActive: boolean;
    paperSize: string;
    orientation: string;
    headerTemplate: string;
    bodyTemplate: string;
    footerTemplate: string;
    createdAt: string;
    updatedAt: string;
  };
  onEdit: () => void;
  onDelete: () => void;
  onDuplicate: () => void;
  onSetDefault: () => void;
  canEdit: boolean;
}

function LayoutCard({
  layout,
  onEdit,
  onDelete,
  onDuplicate,
  onSetDefault,
  canEdit,
}: LayoutCardProps) {
  // Generate preview content with sample data
  const previewContent = useMemo(() => {
    const sampleData: Record<string, string> = {
      receiptNumber: "OR-2024-000123",
      transactionNumber: "TXN-2024-000456",
      amount: "5,250.00",
      amountInWords: "Five Thousand Two Hundred Fifty Pesos Only",
      paymentMethod: "Cash",
      referenceNumber: "REF-123456",
      paidAt: "2024-12-31 10:30:00",
      businessName: "Sample Business Inc.",
      businessOwnerName: "Juan Dela Cruz",
      fullAddress: "123 Main St., Barangay Sample",
      applicationNumber: "BPA-2024-000789",
      periodLabel: "Q1",
      dueDate: "January 31, 2025",
      sectionNumber: "1",
      surcharge: "0.00",
      penalty: "0.00",
      totalAmount: "5,250.00",
      currentDate: "December 31, 2024",
      municipalityName: "Municipality of Sample",
      provinceName: "Sample Province",
      mayorName: "Hon. Mayor Sample",
      treasurerName: "Municipal Treasurer",
    };

    // Replace macros with sample data
    const replaceMacros = (template: string) => {
      return template.replace(/\{\{(\w+)\}\}/g, (match, key) => {
        if (key === "FEES_TABLE") {
          return "[Fees Table]";
        }
        return sampleData[key] || match;
      });
    };

    const header = replaceMacros(layout.headerTemplate || "");
    const body = replaceMacros(layout.bodyTemplate || "");
    const footer = replaceMacros(layout.footerTemplate || "");

    return [header, body, footer].filter(Boolean).join("\n");
  }, [layout.headerTemplate, layout.bodyTemplate, layout.footerTemplate]);

  return (
    <Card className="relative group flex flex-col">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <CardTitle className="text-base flex items-center gap-2">
              {layout.name}
              {layout.isDefault && (
                <Badge variant="secondary" className="text-xs">
                  <Star className="h-3 w-3 mr-1 fill-current" />
                  Default
                </Badge>
              )}
            </CardTitle>
            {layout.description && (
              <CardDescription className="text-xs line-clamp-2">
                {layout.description}
              </CardDescription>
            )}
          </div>
          {canEdit && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={onEdit}>
                  <Edit className="mr-2 h-4 w-4" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onDuplicate}>
                  <Copy className="mr-2 h-4 w-4" />
                  Duplicate
                </DropdownMenuItem>
                {!layout.isDefault && (
                  <DropdownMenuItem onClick={onSetDefault}>
                    <Star className="mr-2 h-4 w-4" />
                    Set as Default
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={onDelete}
                  className="text-destructive focus:text-destructive"
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </CardHeader>
      <CardContent className="pt-2 flex-1 flex flex-col">
        {/* Preview Area */}
        <div
          className={`flex-1 min-h-[120px] max-h-[180px] mb-3 p-2 bg-white dark:bg-zinc-900 border rounded-md overflow-hidden transition-colors ${
            canEdit ? "cursor-pointer hover:border-primary/50" : ""
          }`}
          onClick={canEdit ? onEdit : undefined}
        >
          <div className="h-full overflow-hidden">
            <pre className="text-[6px] leading-tight font-mono text-foreground whitespace-pre-wrap break-words">
              {previewContent}
            </pre>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
          <span>{layout.paperSize}</span>
          <span>•</span>
          <span className="capitalize">{layout.orientation}</span>
        </div>
        {canEdit && (
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            onClick={onEdit}
          >
            <Edit className="mr-2 h-3 w-3" />
            Edit Template
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
