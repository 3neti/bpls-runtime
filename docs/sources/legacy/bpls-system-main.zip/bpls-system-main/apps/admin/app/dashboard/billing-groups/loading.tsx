import { Skeleton } from "@repo/ui/components/skeleton"
import { Card, CardContent } from "@repo/ui/components/card"

/**
 * Loading Skeleton for Billing Groups Page
 *
 * Matches the layout with:
 * - Header: Title, subtitle, Create button
 * - Card list items with icon, text, stats
 */
export default function BillingGroupsLoading() {
  return (
    <div className="flex-1 space-y-6 p-4 pt-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <Skeleton className="h-9 w-[180px]" /> {/* Title */}
          <Skeleton className="h-4 w-[380px]" /> {/* Description */}
        </div>
        <Skeleton className="h-10 w-[180px]" /> {/* Create button */}
      </div>

      {/* Card List */}
      <div className="space-y-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i}>
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                {/* Icon */}
                <Skeleton className="h-12 w-12 rounded-lg" />

                {/* Content */}
                <div className="flex-1 min-w-0 space-y-2">
                  <Skeleton className="h-5 w-[200px]" /> {/* Title */}
                  <Skeleton className="h-4 w-[280px]" /> {/* Description */}
                </div>

                {/* Stats */}
                <div className="hidden sm:flex items-center gap-6">
                  <div className="text-center space-y-1">
                    <Skeleton className="h-5 w-[40px] mx-auto" />
                    <Skeleton className="h-3 w-[50px]" />
                  </div>
                  <div className="text-center space-y-1">
                    <Skeleton className="h-5 w-[40px] mx-auto" />
                    <Skeleton className="h-3 w-[60px]" />
                  </div>
                  <div className="text-center space-y-1">
                    <Skeleton className="h-5 w-[70px] mx-auto" />
                    <Skeleton className="h-3 w-[60px]" />
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2">
                  <Skeleton className="h-8 w-8 rounded-md" />
                  <Skeleton className="h-5 w-5" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
