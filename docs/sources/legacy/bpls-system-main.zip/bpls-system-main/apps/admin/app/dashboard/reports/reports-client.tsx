"use client"

import { useState } from "react"
import { usePreloadedQuery, useMutation } from "convex/react"
import {
  Plus,
  FileText,
  Trash2,
  Copy,
  Edit2,
  Globe,
  Lock,
  MoreHorizontal,
  Calendar,
  User,
  BarChart3,
  Receipt,
  CreditCard,
  BadgeCheck,
  Building2,
  Users,
  FileEdit,
  LucideIcon,
} from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

import { usePermissions } from "@/hooks/use-permissions"
import { PermissionGuard } from "@/components/permission-guard"
import { PermissionDenied } from "@/components/permission-error-states"
import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"
import { Input } from "@repo/ui/components/input"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import { useToast } from "@/hooks/use-toast"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import type { Preloaded } from "convex/react"
import { RESOURCE_META } from "@/lib/config/report-resources"
import type { ResourceType } from "@/lib/types/report-builder"

// Map icon names from RESOURCE_META to actual Lucide components
const ICON_MAP: Record<string, LucideIcon> = {
  FileText,
  Receipt,
  CreditCard,
  BadgeCheck,
  Building2,
  Users,
  FileEdit,
}

type SavedReportListItem = Awaited<ReturnType<typeof api.savedReports.list._returnType>>[number]

interface ReportsClientProps {
  preloadedReports: Preloaded<typeof api.savedReports.list>
}

export function ReportsClient({ preloadedReports }: ReportsClientProps) {
  const { toast } = useToast()
  const router = useRouter()
  const { canCreate, canUpdate, canDelete, isLoading: permissionsLoading } = usePermissions()

  // Permission checks
  const hasCreatePermission = canCreate("reports")
  const hasUpdatePermission = canUpdate("reports")
  const hasDeletePermission = canDelete("reports")

  const [searchQuery, setSearchQuery] = useState("")
  const [resourceFilter, setResourceFilter] = useState<string>("all")
  const [deletingReportId, setDeletingReportId] = useState<Id<"saved_reports"> | null>(null)

  // Use preloaded query data
  const reports = usePreloadedQuery(preloadedReports)

  // Mutations
  const softDeleteReport = useMutation(api.savedReports.softDelete)
  const duplicateReport = useMutation(api.savedReports.duplicate)
  const togglePublic = useMutation(api.savedReports.togglePublic)

  // Filter reports
  const filteredReports = reports.filter((report: SavedReportListItem) => {
    const matchesSearch =
      report.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.description?.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesResource =
      resourceFilter === "all" || report.resourceType === resourceFilter
    return matchesSearch && matchesResource
  })

  const handleDelete = async () => {
    if (!deletingReportId) return

    try {
      await softDeleteReport({ id: deletingReportId })
      toast({
        title: "Report deleted",
        description: "The report has been deleted.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete report",
        variant: "destructive",
      })
    } finally {
      setDeletingReportId(null)
    }
  }

  const handleDuplicate = async (id: Id<"saved_reports">, name: string) => {
    try {
      const newId = await duplicateReport({ id, newName: `${name} (Copy)` })
      toast({
        title: "Report duplicated",
        description: "A copy of the report has been created.",
      })
      router.push(`/dashboard/reports/${newId}`)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to duplicate report",
        variant: "destructive",
      })
    }
  }

  const handleTogglePublic = async (id: Id<"saved_reports">) => {
    try {
      await togglePublic({ id })
      toast({
        title: "Visibility updated",
        description: "Report visibility has been changed.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update visibility",
        variant: "destructive",
      })
    }
  }

  const getResourceLabel = (resourceType: string) => {
    return RESOURCE_META[resourceType as ResourceType]?.name || resourceType
  }

  const getResourceIcon = (resourceType: string) => {
    const iconName = RESOURCE_META[resourceType as ResourceType]?.icon
    return ICON_MAP[iconName] || FileText
  }

  if (permissionsLoading) {
    return (
      <div className="container mx-auto py-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="h-8 w-48 bg-muted animate-pulse rounded" />
          <div className="h-10 w-32 bg-muted animate-pulse rounded" />
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-5 w-32 bg-muted rounded" />
                <div className="h-4 w-48 bg-muted rounded" />
              </CardHeader>
              <CardContent>
                <div className="h-4 w-full bg-muted rounded" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <PermissionGuard
      resource="reports"
      action="read"
      fallback={<PermissionDenied title="Reports" resourceName="report" />}
    >
      <div className="container mx-auto py-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Reports</h1>
            <p className="text-muted-foreground">
              Create and manage dynamic reports across all resources.
            </p>
          </div>
          {hasCreatePermission && (
            <Button asChild>
              <Link href="/dashboard/reports/new">
                <Plus className="mr-2 h-4 w-4" />
                New Report
              </Link>
            </Button>
          )}
        </div>

        {/* Filters */}
        <div className="flex items-center gap-4">
          <Input
            placeholder="Search reports..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="max-w-sm"
          />
          <Select value={resourceFilter} onValueChange={setResourceFilter}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Filter by resource" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Resources</SelectItem>
              {Object.entries(RESOURCE_META).map(([key, meta]) => (
                <SelectItem key={key} value={key}>
                  {meta.icon} {meta.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Reports Grid */}
        {filteredReports.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <BarChart3 className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No reports found</h3>
              <p className="text-muted-foreground text-center max-w-sm mt-1">
                {searchQuery || resourceFilter !== "all"
                  ? "Try adjusting your search or filters."
                  : "Create your first report to start analyzing your data."}
              </p>
              {hasCreatePermission && !searchQuery && resourceFilter === "all" && (
                <Button asChild className="mt-4">
                  <Link href="/dashboard/reports/new">
                    <Plus className="mr-2 h-4 w-4" />
                    Create Report
                  </Link>
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredReports.map((report: SavedReportListItem) => (
              <Card key={report._id} className="group hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      {(() => {
                        const IconComponent = getResourceIcon(report.resourceType)
                        return <IconComponent className="h-4 w-4 text-muted-foreground" />
                      })()}
                      <CardTitle className="text-base">{report.name}</CardTitle>
                    </div>
                    <div className="flex items-center gap-1">
                      {report.isPublic ? (
                        <Badge variant="outline" className="text-xs">
                          <Globe className="mr-1 h-3 w-3" />
                          Public
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="text-xs">
                          <Lock className="mr-1 h-3 w-3" />
                          Private
                        </Badge>
                      )}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild>
                            <Link href={`/dashboard/reports/${report._id}`}>
                              <FileText className="mr-2 h-4 w-4" />
                              Open
                            </Link>
                          </DropdownMenuItem>
                          {hasUpdatePermission && (
                            <>
                              <DropdownMenuItem asChild>
                                <Link href={`/dashboard/reports/${report._id}?edit=true`}>
                                  <Edit2 className="mr-2 h-4 w-4" />
                                  Edit
                                </Link>
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleTogglePublic(report._id)}>
                                {report.isPublic ? (
                                  <>
                                    <Lock className="mr-2 h-4 w-4" />
                                    Make Private
                                  </>
                                ) : (
                                  <>
                                    <Globe className="mr-2 h-4 w-4" />
                                    Make Public
                                  </>
                                )}
                              </DropdownMenuItem>
                            </>
                          )}
                          {hasCreatePermission && (
                            <DropdownMenuItem
                              onClick={() => handleDuplicate(report._id, report.name)}
                            >
                              <Copy className="mr-2 h-4 w-4" />
                              Duplicate
                            </DropdownMenuItem>
                          )}
                          {hasDeletePermission && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                className="text-destructive focus:text-destructive"
                                onClick={() => setDeletingReportId(report._id)}
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                  {report.description && (
                    <CardDescription className="line-clamp-2">
                      {report.description}
                    </CardDescription>
                  )}
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <FileText className="h-3 w-3" />
                      {getResourceLabel(report.resourceType)}
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {new Date(report.updatedAt).toLocaleDateString("en-PH", {
                        month: "short",
                        day: "numeric",
                        year: "numeric",
                      })}
                    </div>
                    {report.creatorName && (
                      <div className="flex items-center gap-1">
                        <User className="h-3 w-3" />
                        {report.creatorName}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Delete Confirmation Dialog */}
        <AlertDialog
          open={!!deletingReportId}
          onOpenChange={(open) => !open && setDeletingReportId(null)}
        >
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Report</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete this report? This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </PermissionGuard>
  )
}
