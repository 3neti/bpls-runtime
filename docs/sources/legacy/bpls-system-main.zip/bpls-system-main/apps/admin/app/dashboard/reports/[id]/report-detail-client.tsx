"use client"

import { useState, useEffect, useCallback, useRef, useMemo } from "react"
import { usePreloadedQuery, useMutation, useQuery, useConvex } from "convex/react"
import { ArrowLeft, Save, Download, Loader2, FileBarChart, X, Info } from "lucide-react"
import Link from "next/link"
import { Table as TanstackTable } from "@tanstack/react-table"

import { usePermissions } from "@/hooks/use-permissions"
import { PermissionGuard } from "@/components/permission-guard"
import { PermissionDenied } from "@/components/permission-error-states"
import { Button } from "@repo/ui/components/button"
import { Badge } from "@repo/ui/components/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { Input } from "@repo/ui/components/input"
import { Label } from "@repo/ui/components/label"
import { Textarea } from "@repo/ui/components/textarea"
import { Switch } from "@repo/ui/components/switch"
import { Progress } from "@repo/ui/components/progress"
import { Card, CardContent } from "@repo/ui/components/card"
import { useToast } from "@/hooks/use-toast"
import { useDebouncedValue } from "@/hooks/use-debounced-value"
import {
  convertToCSV,
  downloadCSV,
  generateExportFilename,
  type CSVColumn,
} from "@/lib/utils/csv-export"

import { api } from "@repo/backend/convex/_generated/api"
import type { Preloaded } from "convex/react"
import { ReportFiltersSidebar } from "@/components/reports/report-builder"
import { DynamicDataTable, AggregationSummary, ColumnsDropdown } from "@/components/reports/report-results"
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@repo/ui/components/resizable"
import { ExportProgressDialog } from "@/components/reports/export-progress-dialog"
import { useReportExport } from "@/hooks/use-report-export"
import {
  useReportBuilderStore,
  useCurrentResourceConfig,
  useCanGenerateReport,
} from "@/lib/stores/report-builder-store"
import { getAllDimensions, getAllMetrics } from "@/lib/config/report-resources"
import type { ReportConfiguration } from "@/lib/types/report-builder"

const PREVIEW_PAGE_SIZE = 25
const EXPORT_BATCH_SIZE = 500

interface ReportDetailClientProps {
  preloadedReport: Preloaded<typeof api.savedReports.get>
}

export function ReportDetailClient({ preloadedReport }: ReportDetailClientProps) {
  const { toast } = useToast()
  const { canUpdate, isLoading: permissionsLoading } = usePermissions()
  const hasUpdatePermission = canUpdate("reports")

  // Preloaded report data
  const report = usePreloadedQuery(preloadedReport)

  // Track if initial config has been loaded
  const [configLoaded, setConfigLoaded] = useState(false)

  // Track when we're using the action instead of the reactive query
  const [isActionLoading, setIsActionLoading] = useState(false)

  // Preview state
  const [isLoadingPreview, setIsLoadingPreview] = useState(false)
  const [previewData, setPreviewData] = useState<{
    rows: Record<string, unknown>[]
    aggregations: { metricId: string; value: number }[]
    totalCount: number
    continueCursor?: string
    isDone?: boolean
  } | null>(null)

  // Export state
  const [exportProgress, setExportProgress] = useState<{
    isExporting: boolean
    current: number
    total: number
    isCancelled: boolean
  } | null>(null)
  const exportCancelRef = useRef(false)

  // Workflow-based export (for permit_applications)
  const workflowExport = useReportExport()
  const [showWorkflowDialog, setShowWorkflowDialog] = useState(false)

  // Save dialog state
  const [isSaveDialogOpen, setIsSaveDialogOpen] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [reportName, setReportName] = useState("")
  const [reportDescription, setReportDescription] = useState("")
  const [isPublic, setIsPublic] = useState(false)

  // Table reference for columns dropdown
  const [tableRef, setTableRef] = useState<TanstackTable<Record<string, unknown>> | null>(null)

  // Report builder state
  const {
    resourceType,
    selectedDimensions,
    selectedMetrics,
    filters,
    dateRange,
    loadConfiguration,
    getConfiguration,
  } = useReportBuilderStore()

  const currentConfig = useCurrentResourceConfig()
  const canGenerate = useCanGenerateReport()

  // Convex client for imperative queries
  const convex = useConvex()

  // Mutations
  const updateReport = useMutation(api.savedReports.update)

  // Load saved configuration when report loads
  useEffect(() => {
    if (report && !configLoaded) {
      try {
        const config = JSON.parse(report.configuration) as ReportConfiguration
        loadConfiguration(config)
        setReportName(report.name)
        setReportDescription(report.description || "")
        setIsPublic(report.isPublic)
        setConfigLoaded(true)
      } catch {
        toast({
          title: "Error",
          description: "Failed to load report configuration",
          variant: "destructive",
        })
      }
    }
  }, [report, loadConfiguration, toast, configLoaded])

  // Get all dimensions and metrics for current resource
  const allDimensions = resourceType ? getAllDimensions(resourceType) : []
  const allMetrics = resourceType ? getAllMetrics(resourceType) : []

  // Build full metric objects from selected metric IDs
  const buildMetricsArg = useCallback(() => {
    return selectedMetrics.map((metricId) => {
      const metric = allMetrics.find((m) => m.id === metricId)
      if (!metric) {
        return {
          id: metricId,
          name: metricId,
          aggregation: "count",
          format: "number",
        }
      }
      return {
        id: metric.id,
        name: metric.name,
        aggregation: metric.aggregation,
        format: metric.format,
        field: metric.field,
      }
    })
  }, [selectedMetrics, allMetrics])

  // Create a stable config object for debouncing
  const configForDebounce = useMemo(() => ({
    resourceType,
    selectedDimensions: [...selectedDimensions].sort().join(","),
    selectedMetrics: [...selectedMetrics].sort().join(","),
    filters: JSON.stringify(filters),
    dateRange: JSON.stringify(dateRange),
    configLoaded,
  }), [resourceType, selectedDimensions, selectedMetrics, filters, dateRange, configLoaded])

  // Debounced config - triggers auto-preview after 500ms of no changes
  const debouncedConfig = useDebouncedValue(configForDebounce, 500)

  // Preview query - conditional on canGenerate and isLoadingPreview
  const previewQueryArgs = canGenerate && isLoadingPreview ? {
    dimensions: selectedDimensions,
    metrics: buildMetricsArg(),
    filters: filters || undefined,
    dateRange: dateRange || undefined,
    page: 1,
    pageSize: PREVIEW_PAGE_SIZE,
  } : "skip" as const

  // Permit applications: use reactive query for unfiltered preview, action for filtered preview
  const hasActivePermitFilters = resourceType === "permit_applications" &&
    ((filters?.conditions?.length ?? 0) > 0 || !!dateRange)
  const permitAppPreviewArgs = canGenerate && isLoadingPreview && !hasActivePermitFilters ? {
    dimensions: selectedDimensions,
    metrics: buildMetricsArg(),
    filters: filters || undefined,
    dateRange: dateRange || undefined,
    paginationOpts: { numItems: PREVIEW_PAGE_SIZE, cursor: null },
  } : "skip" as const

  const permitApplicationsPreview = useQuery(
    api.reports.generatePermitApplicationsReport,
    resourceType === "permit_applications" ? permitAppPreviewArgs : "skip"
  )

  const billingGroupsPreview = useQuery(
    api.reports.generateBillingGroupsReport,
    resourceType === "billing_groups" ? previewQueryArgs : "skip"
  )

  const paymentsPreview = useQuery(
    api.reports.generatePaymentsReport,
    resourceType === "payments" ? previewQueryArgs : "skip"
  )

  const permitsPreview = useQuery(
    api.reports.generatePermitsReport,
    resourceType === "permits" ? previewQueryArgs : "skip"
  )

  const businessesPreview = useQuery(
    api.reports.generateBusinessesReport,
    resourceType === "businesses" ? previewQueryArgs : "skip"
  )

  const businessOwnersPreview = useQuery(
    api.reports.generateBusinessOwnersReport,
    resourceType === "business_owners" ? previewQueryArgs : "skip"
  )

  // Get current preview based on resource type
  const getCurrentPreview = useCallback(() => {
    switch (resourceType) {
      case "permit_applications":
        return permitApplicationsPreview
      case "billing_groups":
        return billingGroupsPreview
      case "payments":
        return paymentsPreview
      case "permits":
        return permitsPreview
      case "businesses":
        return businessesPreview
      case "business_owners":
        return businessOwnersPreview
      default:
        return null
    }
  }, [
    resourceType,
    permitApplicationsPreview,
    billingGroupsPreview,
    paymentsPreview,
    permitsPreview,
    businessesPreview,
    businessOwnersPreview,
  ])

  const currentPreview = getCurrentPreview()

  // Auto-generate preview when config changes.
  // For filtered permit reports, use the action with maxRows limit (preview only).
  // For unfiltered/other types, use the reactive paginated query.
  // Full export always goes through the workflow pipeline.
  useEffect(() => {
    if (canGenerate && configLoaded) {
      const hasActiveFilters = (filters?.conditions?.length ?? 0) > 0 || !!dateRange
      if (resourceType === "permit_applications" && hasActiveFilters) {
        setIsActionLoading(true)
        setIsLoadingPreview(true)
        const callPreview = async () => {
          try {
            const result = await convex.action(api.reports.generatePermitApplicationsReportFull, {
              dimensions: selectedDimensions,
              metrics: buildMetricsArg(),
              filters: filters || undefined,
              dateRange: dateRange || undefined,
              sort: undefined,
              maxRows: 100,
            })
            setPreviewData({
              rows: result.rows as Record<string, unknown>[],
              aggregations: result.aggregations,
              totalCount: result.totalCount,
            })
          } catch (error) {
            toast({
              title: "Report preview failed",
              description: error instanceof Error ? error.message : "Failed to generate preview",
              variant: "destructive",
            })
          } finally {
            setIsLoadingPreview(false)
            setIsActionLoading(false)
          }
        }
        callPreview()
      } else {
        setIsLoadingPreview(true)
      }
    } else if (!canGenerate) {
      setPreviewData(null)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedConfig, canGenerate, configLoaded])

  // Update preview data when query returns
  useEffect(() => {
    if (currentPreview && isLoadingPreview) {
      setPreviewData({
        rows: currentPreview.rows as Record<string, unknown>[],
        aggregations: currentPreview.aggregations,
        totalCount: currentPreview.totalCount,
        continueCursor: (currentPreview as any).continueCursor,
        isDone: (currentPreview as any).isDone,
      })
      setIsLoadingPreview(false)
    }
  }, [currentPreview, isLoadingPreview])

  // Get the report query function based on resource type
  const getReportQueryFn = useCallback(() => {
    switch (resourceType) {
      case "permit_applications":
        return api.reports.generatePermitApplicationsReport
      case "billing_groups":
        return api.reports.generateBillingGroupsReport
      case "payments":
        return api.reports.generatePaymentsReport
      case "permits":
        return api.reports.generatePermitsReport
      case "businesses":
        return api.reports.generateBusinessesReport
      case "business_owners":
        return api.reports.generateBusinessOwnersReport
      default:
        return null
    }
  }, [resourceType])

  // Export handler - workflow-based for permit_applications, paginated for others
  const handleExport = useCallback(async () => {
    if (!previewData || !resourceType) return

    // Workflow-based export for all report types
    try {
      const dimensionNames: Record<string, string> = {}
      for (const dim of allDimensions) {
        dimensionNames[dim.id] = dim.name
      }
      await workflowExport.startExport(resourceType, {
        dimensions: selectedDimensions,
        dimensionNames,
        metrics: buildMetricsArg(),
        filters: filters || undefined,
        dateRange: dateRange || undefined,
        sort: undefined,
      })
      setShowWorkflowDialog(true)
    } catch (error) {
      toast({
        title: "Export failed to start",
        description: error instanceof Error ? error.message : "Failed to start export",
        variant: "destructive",
      })
    }
  }, [previewData, resourceType, workflowExport, selectedDimensions, buildMetricsArg, filters, dateRange, toast])

  const handleCancelExport = () => {
    exportCancelRef.current = true
    setExportProgress((prev) => prev ? { ...prev, isCancelled: true } : null)
  }

  const handleSave = () => {
    if (!hasUpdatePermission) return
    setIsSaveDialogOpen(true)
  }

  const handleSaveConfirm = async () => {
    if (!reportName.trim() || !report) {
      toast({
        title: "Error",
        description: "Please enter a report name.",
        variant: "destructive",
      })
      return
    }

    setIsSaving(true)

    try {
      const config = getConfiguration()
      if (!config) {
        throw new Error("No configuration available")
      }

      await updateReport({
        id: report._id,
        name: reportName.trim(),
        description: reportDescription.trim() || undefined,
        configuration: JSON.stringify(config),
        isPublic,
      })

      toast({
        title: "Report updated",
        description: "Your changes have been saved.",
      })

      setIsSaveDialogOpen(false)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update report",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleReset = () => {
    // Reload original configuration
    if (report) {
      try {
        const config = JSON.parse(report.configuration) as ReportConfiguration
        loadConfiguration(config)
      } catch {
        // Ignore parse errors
      }
    }
  }

  if (permissionsLoading) {
    return (
      <div className="flex h-[calc(100vh-4rem)]">
        <div className="w-72 border-r bg-muted/10 animate-pulse" />
        <div className="flex-1 p-6">
          <div className="h-8 w-48 bg-muted animate-pulse rounded mb-6" />
          <div className="h-[600px] bg-muted animate-pulse rounded" />
        </div>
      </div>
    )
  }

  if (!report) {
    return (
      <div className="flex h-[calc(100vh-4rem)] items-center justify-center">
        <Card className="border-dashed max-w-md">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <FileBarChart className="h-12 w-12 text-muted-foreground/50" />
            <h3 className="mt-4 text-lg font-medium">Report not found</h3>
            <p className="text-muted-foreground text-center max-w-sm mt-1">
              The report you're looking for doesn't exist or has been deleted.
            </p>
            <Button asChild className="mt-4">
              <Link href="/dashboard/reports">Back to Reports</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <PermissionGuard
      resource="reports"
      action="read"
      fallback={<PermissionDenied title="Reports" resourceName="report" />}
    >
      <ResizablePanelGroup orientation="horizontal" className="h-[calc(100vh-4rem)]">
        {/* Sidebar */}
        <ResizablePanel defaultSize="25%" minSize="10%" maxSize="50%" className="border-r">
          <ReportFiltersSidebar onReset={handleReset} />
        </ResizablePanel>
        <ResizableHandle withHandle />
        {/* Main Content */}
        <ResizablePanel defaultSize="75%">
        <div className="flex-1 p-6 space-y-4 overflow-auto h-full">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" asChild>
                <Link href="/dashboard/reports">
                  <ArrowLeft className="h-4 w-4" />
                </Link>
              </Button>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl font-bold tracking-tight">{report.name}</h1>
                  <Badge variant={report.isPublic ? "outline" : "secondary"}>
                    {report.isPublic ? "Public" : "Private"}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  {currentConfig
                    ? `Data Source: ${currentConfig.meta.name}`
                    : "Loading configuration..."}
                  {previewData && (
                    <span className="ml-2">
                      • Showing {previewData.rows.length} of {previewData.totalCount.toLocaleString()} records
                    </span>
                  )}
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2">
              {/* Columns dropdown - moved from table */}
              <ColumnsDropdown table={tableRef} dimensions={allDimensions} />

              {hasUpdatePermission && (
                <Button
                  variant="outline"
                  onClick={handleSave}
                  disabled={!canGenerate || isSaving}
                >
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </Button>
              )}

              <Button
                onClick={handleExport}
                disabled={!previewData?.rows.length || exportProgress?.isExporting || workflowExport.isStarting || workflowExport.isExporting}
              >
                {(exportProgress?.isExporting || workflowExport.isStarting || workflowExport.isExporting) ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Download className="h-4 w-4 mr-2" />
                )}
                Export Full Report
              </Button>
            </div>
          </div>

          {/* Preview Info Banner */}
          <div className="flex items-center gap-2 px-3 py-2 border rounded-md text-sm text-muted-foreground bg-muted/30">
            <Info className="h-4 w-4 shrink-0 text-blue-500" />
            <span>
              This table shows a <span className="font-medium text-foreground">preview</span> of your report data.
              {previewData && (
                <> Showing {previewData.rows.length} of {previewData.totalCount.toLocaleString()} records. </>
              )}
              To get the complete dataset, click <span className="font-medium text-foreground">Export Full Report</span>.
            </span>
          </div>

          {/* Results Section */}
          {(previewData || isLoadingPreview) && (
            <div className="space-y-4">

              {/* Aggregations Summary */}
              {selectedMetrics.length > 0 && (
                <AggregationSummary
                  aggregations={previewData?.aggregations || []}
                  metrics={allMetrics}
                  selectedMetrics={selectedMetrics}
                  isLoading={isLoadingPreview}
                />
              )}

              {/* Data Table */}
              <div className="border rounded-lg">
                <DynamicDataTable
                  data={previewData?.rows || []}
                  dimensions={allDimensions}
                  selectedDimensions={selectedDimensions}
                  isLoading={isLoadingPreview}
                  totalCount={previewData?.totalCount}
                  onTableReady={setTableRef}
                />
              </div>
            </div>
          )}

          {/* Empty State - only show if config is loaded but can't generate */}
          {!previewData && !isLoadingPreview && configLoaded && (
            <div className="flex-1 flex items-center justify-center min-h-[400px]">
              <div className="text-center">
                <FileBarChart className="h-12 w-12 mx-auto text-muted-foreground/50" />
                <h3 className="mt-4 text-lg font-medium">
                  {!resourceType
                    ? "Select a data source"
                    : selectedDimensions.length === 0
                      ? "Select at least one column"
                      : "Configure your report"}
                </h3>
                <p className="text-muted-foreground mt-1 max-w-sm">
                  {!resourceType
                    ? "Choose a data source from the sidebar to configure your report"
                    : selectedDimensions.length === 0
                      ? "Select the columns you want to include in your report"
                      : "Your report will auto-generate as you make changes"}
                </p>
              </div>
            </div>
          )}

          {/* Loading state while config is being loaded */}
          {!configLoaded && (
            <div className="flex-1 flex items-center justify-center min-h-[400px]">
              <div className="text-center">
                <Loader2 className="h-8 w-8 mx-auto text-muted-foreground animate-spin" />
                <p className="text-muted-foreground mt-4">Loading report configuration...</p>
              </div>
            </div>
          )}
        </div>
        </ResizablePanel>
      </ResizablePanelGroup>

        {/* Save Dialog */}
        <Dialog open={isSaveDialogOpen} onOpenChange={setIsSaveDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Save Changes</DialogTitle>
              <DialogDescription>
                Update the report name, description, or visibility.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={reportName}
                  onChange={(e) => setReportName(e.target.value)}
                  placeholder="e.g., Monthly Permit Applications"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description (optional)</Label>
                <Textarea
                  id="description"
                  value={reportDescription}
                  onChange={(e) => setReportDescription(e.target.value)}
                  placeholder="Describe what this report shows..."
                  rows={3}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="public">Make public</Label>
                  <p className="text-xs text-muted-foreground">
                    Allow other users to view this report
                  </p>
                </div>
                <Switch
                  id="public"
                  checked={isPublic}
                  onCheckedChange={setIsPublic}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsSaveDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button onClick={handleSaveConfirm} disabled={isSaving}>
                <Save className="mr-2 h-4 w-4" />
                {isSaving ? "Saving..." : "Save Changes"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Export Progress Dialog */}
        <Dialog open={!!exportProgress?.isExporting} onOpenChange={() => {}}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Exporting Report</DialogTitle>
              <DialogDescription>
                Please wait while your report is being exported...
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-4">
              <Progress
                value={exportProgress ? (exportProgress.current / exportProgress.total) * 100 : 0}
              />
              <p className="text-sm text-center text-muted-foreground">
                Processing {exportProgress?.current.toLocaleString() || 0} of{" "}
                {exportProgress?.total.toLocaleString() || 0} records...
              </p>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={handleCancelExport}>
                <X className="mr-2 h-4 w-4" />
                Cancel
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Workflow Export Progress Dialog */}
        <ExportProgressDialog
          open={showWorkflowDialog}
          onOpenChange={setShowWorkflowDialog}
          progress={workflowExport.progress}
          onCancel={async () => {
            await workflowExport.cancelExport()
            setShowWorkflowDialog(false)
            workflowExport.reset()
          }}
          onDownload={() => {
            if (workflowExport.progress.downloadUrl) {
              window.open(workflowExport.progress.downloadUrl, "_blank")
            }
          }}
          onClose={() => {
            setShowWorkflowDialog(false)
            workflowExport.reset()
          }}
        />
    </PermissionGuard>
  )
}
