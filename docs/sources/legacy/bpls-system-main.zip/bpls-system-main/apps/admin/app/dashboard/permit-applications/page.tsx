import { preloadQuery, fetchQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { ConvexError } from "convex/values"
import { api } from "@repo/backend/convex/_generated/api"
import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"
import { PermitApplicationsClient } from "./permit-applications-client"

// Page size constant - should match the client component
const PAGE_SIZE = 20

export default async function PermitApplicationsPage() {
  const token = await convexAuthNextjsToken()

  try {
    // Check if user has permission to view all applications
    const hasAllApplicationsPermission = await fetchQuery(
      api.permissions.hasPermission,
      { resource: "permit_applications:all_applications", action: "read" },
      { token }
    )

    // If user doesn't have permission, show permission denied
    if (!hasAllApplicationsPermission) {
      return (
        <PermissionDenied
          title="All Permit Applications"
          description="View all permit applications"
          message="You don't have permission to view all permit applications"
          details={{
            resource: "permit_applications:all_applications",
            action: "read",
            requiredPermission: "permit_applications:all_applications:read",
          }}
          resourceName="all applications"
          backLink="/dashboard"
          backLinkText="Back to Dashboard"
        />
      )
    }

    // Default statuses to filter by
    const statuses = ["Assessment", "Approval", "Pending Payment", "Released"] as const

    // Preload paginated permit applications
    const preloadedApplications = await preloadQuery(
      api.businessPermitApplications.listByStatusesPaginated,
      { statuses: [...statuses], pageSize: PAGE_SIZE },
      { token }
    )

    // Preload count for pagination UI
    const preloadedCount = await preloadQuery(
      api.businessPermitApplications.getApplicationsCountByStatuses,
      { statuses: [...statuses] },
      { token }
    )

    return (
      <PermitApplicationsClient
        preloadedApplications={preloadedApplications}
        preloadedCount={preloadedCount}
      />
    )
  } catch (error) {
    if (error instanceof ConvexError) {
      const errorData = error.data as {
        code?: string
        message?: string
        details?: {
          resource?: string
          action?: string
          userRole?: string
          requiredPermission?: string
        }
      }

      if (errorData.code === "PERMISSION_DENIED") {
        return (
          <PermissionDenied
            title="All Permit Applications"
            description="View all permit applications"
            message={errorData.message}
            details={errorData.details}
            resourceName="all applications"
            backLink="/dashboard"
            backLinkText="Back to Dashboard"
          />
        )
      }

      if (errorData.code === "UNAUTHENTICATED") {
        return <AuthenticationRequired />
      }
    }

    throw error
  }
}
