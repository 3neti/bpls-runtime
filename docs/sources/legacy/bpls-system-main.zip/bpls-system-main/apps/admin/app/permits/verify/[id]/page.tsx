import { VerifyClient } from "./verify-client"

interface VerifyPageProps {
  params: Promise<{
    id: string
  }>
}

export const metadata = {
  title: "Verify Permit | BPLS",
  description: "Verify the authenticity of a Business Permit",
}

export default async function VerifyPage({ params }: VerifyPageProps) {
  const { id } = await params

  return <VerifyClient permitId={id} />
}
