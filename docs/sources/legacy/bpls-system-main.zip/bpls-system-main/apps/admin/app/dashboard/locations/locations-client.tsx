"use client"

import { useState } from "react"
import { usePreloadedQuery, useMutation } from "convex/react"
import type { Preloaded } from "convex/react"
import { Plus, Edit, Trash2, MapPin } from "lucide-react"
import { usePermissions } from "@/hooks/use-permissions"
import { PermissionGuard } from "@/components/permission-guard"
import { PermissionDenied } from "@/components/permission-error-states"
import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@repo/ui/components/card"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@repo/ui/components/accordion"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import { ProvinceDialog } from "@/components/locations/province-dialog"
import { CityDialog } from "@/components/locations/city-dialog"
import { BarangayDialog } from "@/components/locations/barangay-dialog"
import { toast } from "sonner"
import { api } from "@repo/backend/convex/_generated/api"
import type { Province, City, Barangay } from "@/lib/types/location"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

interface LocationsClientProps {
  preloadedProvinces: Preloaded<typeof api.locations.listProvinces>
  preloadedCities: Preloaded<typeof api.locations.listCities>
  preloadedBarangays: Preloaded<typeof api.locations.listBarangays>
}

export default function LocationsClient({
  preloadedProvinces,
  preloadedCities,
  preloadedBarangays,
}: LocationsClientProps) {
  const provinces = usePreloadedQuery(preloadedProvinces)
  const cities = usePreloadedQuery(preloadedCities)
  const barangays = usePreloadedQuery(preloadedBarangays)
  const { canCreate, canUpdate, canDelete, isLoading: permissionsLoading } = usePermissions()

  // Permission checks
  const hasCreatePermission = canCreate("locations")
  const hasUpdatePermission = canUpdate("locations")
  const hasDeletePermission = canDelete("locations")

  const deleteProvince = useMutation(api.locations.deleteProvince)
  const deleteCity = useMutation(api.locations.deleteCity)
  const deleteBarangay = useMutation(api.locations.deleteBarangay)

  // Dialog states
  const [provinceDialog, setProvinceDialog] = useState<{
    open: boolean
    mode: "create" | "edit"
    province?: Province
  }>({ open: false, mode: "create" })

  const [cityDialog, setCityDialog] = useState<{
    open: boolean
    mode: "create" | "edit"
    city?: City
    provinceId?: string
    provinceName?: string
  }>({ open: false, mode: "create" })

  const [barangayDialog, setBarangayDialog] = useState<{
    open: boolean
    mode: "create" | "edit"
    barangay?: Barangay
    cityId?: string
    cityName?: string
  }>({ open: false, mode: "create" })

  // Delete confirmation states
  const [deleteDialog, setDeleteDialog] = useState<{
    open: boolean
    type: "province" | "city" | "barangay"
    id?: string
    name?: string
  }>({ open: false, type: "province" })

  const handleDelete = async () => {
    try {
      if (!deleteDialog.id) return

      switch (deleteDialog.type) {
        case "province":
          await deleteProvince({ id: deleteDialog.id as Id<"provinces"> })
          toast.success("Province deleted successfully")
          break
        case "city":
          await deleteCity({ id: deleteDialog.id as Id<"cities"> })
          toast.success("City/Municipality deleted successfully")
          break
        case "barangay":
          await deleteBarangay({ id: deleteDialog.id as Id<"barangays"> })
          toast.success("Barangay deleted successfully")
          break
      }
      setDeleteDialog({ open: false, type: "province" })
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : "An error occurred"
      toast.error(`Failed to delete: ${errorMessage}`)
    }
  }

  const getCitiesByProvince = (provinceId: string) => {
    return cities?.filter((city: { _id: string; name: string; provinceId: string }) => city.provinceId === provinceId) || []
  }

  const getBarangaysByCity = (cityId: string) => {
    return barangays?.filter((barangay: { _id: string; name: string; cityId: string }) => barangay.cityId === cityId) || []
  }

  return (
    <PermissionGuard
      resource="locations"
      action="read"
      showLoading
      fallback={
        <PermissionDenied
          title="Location Management"
          description="Manage provinces, cities/municipalities, and barangays"
          resourceName="locations"
          backLink="/dashboard"
          backLinkText="Back to Dashboard"
        />
      }
    >
    <div className="flex-1 space-y-4 p-4 pt-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Location Management</h1>
          <p className="text-muted-foreground mt-2">
            Manage provinces, cities/municipalities, and barangays for address hierarchy
          </p>
        </div>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <span tabIndex={hasCreatePermission ? -1 : 0}>
                <Button
                  onClick={() => setProvinceDialog({ open: true, mode: "create" })}
                  size="sm"
                  className="gap-2"
                  disabled={!hasCreatePermission || permissionsLoading}
                >
                  <Plus className="h-4 w-4" />
                  Add Province
                </Button>
              </span>
            </TooltipTrigger>
            {!hasCreatePermission && !permissionsLoading && (
              <TooltipContent>
                <p>You don't have permission to create locations</p>
              </TooltipContent>
            )}
          </Tooltip>
        </TooltipProvider>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Provinces
            </CardTitle>
            <CardDescription>Total: {provinces.length}</CardDescription>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Cities/Municipalities
            </CardTitle>
            <CardDescription>Total: {cities.length}</CardDescription>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Barangays
            </CardTitle>
            <CardDescription>Total: {barangays.length}</CardDescription>
          </CardHeader>
        </Card>
      </div>

      {/* Location Hierarchy */}
      <Card>
        <CardHeader>
          <CardTitle>Location Hierarchy</CardTitle>
          <CardDescription>
            Expand provinces to view cities/municipalities and barangays. Click icons to edit or
            delete.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {provinces.map((province: Province) => {
              const provinceCities = getCitiesByProvince(province._id)
              return (
                <AccordionItem key={province._id} value={province._id}>
                  <div className="flex items-center justify-between gap-4">
                    <AccordionTrigger className="hover:no-underline flex-1">
                      <div className="flex w-full items-center gap-2 pr-4">
                        <span className="font-medium">{province.name}</span>
                        <span className="text-muted-foreground text-sm">
                          - {provinceCities.length} {provinceCities.length === 1 ? "city" : "cities"}
                        </span>
                      </div>
                    </AccordionTrigger>
                    <div className="flex items-center gap-1">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span tabIndex={hasUpdatePermission ? -1 : 0}>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  setProvinceDialog({ open: true, mode: "edit", province })
                                }}
                                disabled={!hasUpdatePermission || permissionsLoading}
                                className="inline-flex h-8 w-8 items-center justify-center rounded-md hover:bg-accent hover:text-accent-foreground disabled:opacity-50 disabled:pointer-events-none"
                                aria-label="Edit province"
                              >
                                <Edit className="h-4 w-4" />
                              </button>
                            </span>
                          </TooltipTrigger>
                          <TooltipContent>
                            {hasUpdatePermission ? "Edit province" : "You don't have permission to edit"}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span tabIndex={hasDeletePermission ? -1 : 0}>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  setDeleteDialog({
                                    open: true,
                                    type: "province",
                                    id: province._id,
                                    name: province.name,
                                  })
                                }}
                                disabled={!hasDeletePermission || permissionsLoading}
                                className="inline-flex h-8 w-8 items-center justify-center rounded-md hover:bg-accent hover:text-destructive disabled:opacity-50 disabled:pointer-events-none"
                                aria-label="Delete province"
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </button>
                            </span>
                          </TooltipTrigger>
                          <TooltipContent>
                            {hasDeletePermission ? "Delete province" : "You don't have permission to delete"}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </div>
                  <AccordionContent>
                    <div className="ml-6 space-y-2">
                      <div className="flex items-center justify-between mb-2">
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span tabIndex={hasCreatePermission ? -1 : 0}>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() =>
                                    setCityDialog({
                                      open: true,
                                      mode: "create",
                                      provinceId: province._id,
                                      provinceName: province.name
                                    })
                                  }
                                  disabled={!hasCreatePermission || permissionsLoading}
                                  className="gap-2 h-8 text-muted-foreground hover:text-foreground"
                                >
                                  <Plus className="h-3.5 w-3.5" />
                                  Add City/Municipality
                                </Button>
                              </span>
                            </TooltipTrigger>
                            {!hasCreatePermission && !permissionsLoading && (
                              <TooltipContent>
                                <p>You don't have permission to create locations</p>
                              </TooltipContent>
                            )}
                          </Tooltip>
                        </TooltipProvider>
                      </div>

                      <Accordion type="single" collapsible>
                        {provinceCities.map((city: City) => {
                          const cityBarangays = getBarangaysByCity(city._id)
                          return (
                            <AccordionItem key={city._id} value={city._id}>
                              <div className="flex items-center justify-between gap-4">
                                <AccordionTrigger className="hover:no-underline flex-1">
                                  <div className="flex w-full items-center gap-2 pr-4">
                                    <span className="font-medium">{city.name}</span>
                                    <span className="text-muted-foreground text-sm">
                                      - {cityBarangays.length}{" "}
                                      {cityBarangays.length === 1 ? "barangay" : "barangays"}
                                    </span>
                                  </div>
                                </AccordionTrigger>
                                <div className="flex items-center gap-1">
                                  <TooltipProvider>
                                    <Tooltip>
                                      <TooltipTrigger asChild>
                                        <span tabIndex={hasUpdatePermission ? -1 : 0}>
                                          <button
                                            onClick={(e) => {
                                              e.stopPropagation()
                                              setCityDialog({ open: true, mode: "edit", city })
                                            }}
                                            disabled={!hasUpdatePermission || permissionsLoading}
                                            className="inline-flex h-8 w-8 items-center justify-center rounded-md hover:bg-accent hover:text-accent-foreground disabled:opacity-50 disabled:pointer-events-none"
                                            aria-label="Edit city"
                                          >
                                            <Edit className="h-4 w-4" />
                                          </button>
                                        </span>
                                      </TooltipTrigger>
                                      <TooltipContent>
                                        {hasUpdatePermission ? "Edit city" : "You don't have permission to edit"}
                                      </TooltipContent>
                                    </Tooltip>
                                  </TooltipProvider>
                                  <TooltipProvider>
                                    <Tooltip>
                                      <TooltipTrigger asChild>
                                        <span tabIndex={hasDeletePermission ? -1 : 0}>
                                          <button
                                            onClick={(e) => {
                                              e.stopPropagation()
                                              setDeleteDialog({
                                                open: true,
                                                type: "city",
                                                id: city._id,
                                                name: city.name,
                                              })
                                            }}
                                            disabled={!hasDeletePermission || permissionsLoading}
                                            className="inline-flex h-8 w-8 items-center justify-center rounded-md hover:bg-accent hover:text-destructive disabled:opacity-50 disabled:pointer-events-none"
                                            aria-label="Delete city"
                                          >
                                            <Trash2 className="h-4 w-4 text-destructive" />
                                          </button>
                                        </span>
                                      </TooltipTrigger>
                                      <TooltipContent>
                                        {hasDeletePermission ? "Delete city" : "You don't have permission to delete"}
                                      </TooltipContent>
                                    </Tooltip>
                                  </TooltipProvider>
                                </div>
                              </div>
                              <AccordionContent>
                                <div className="ml-6 space-y-2">
                                  <div className="flex items-center justify-between mb-2">
                                    <TooltipProvider>
                                      <Tooltip>
                                        <TooltipTrigger asChild>
                                          <span tabIndex={hasCreatePermission ? -1 : 0}>
                                            <Button
                                              size="sm"
                                              variant="ghost"
                                              onClick={() =>
                                                setBarangayDialog({
                                                  open: true,
                                                  mode: "create",
                                                  cityId: city._id,
                                                  cityName: city.name
                                                })
                                              }
                                              disabled={!hasCreatePermission || permissionsLoading}
                                              className="gap-2 h-8 text-muted-foreground hover:text-foreground"
                                            >
                                              <Plus className="h-3.5 w-3.5" />
                                              Add Barangay
                                            </Button>
                                          </span>
                                        </TooltipTrigger>
                                        {!hasCreatePermission && !permissionsLoading && (
                                          <TooltipContent>
                                            <p>You don't have permission to create locations</p>
                                          </TooltipContent>
                                        )}
                                      </Tooltip>
                                    </TooltipProvider>
                                  </div>

                                  {cityBarangays.length > 0 ? (
                                    <ul className="space-y-1">
                                      {cityBarangays.map((barangay: Barangay) => (
                                        <li
                                          key={barangay._id}
                                          className="flex items-center justify-between rounded-md py-2 px-3 hover:bg-muted"
                                        >
                                          <span>{barangay.name}</span>
                                          <div className="flex items-center gap-1">
                                            <TooltipProvider>
                                              <Tooltip>
                                                <TooltipTrigger asChild>
                                                  <span tabIndex={hasUpdatePermission ? -1 : 0}>
                                                    <Button
                                                      size="icon"
                                                      variant="ghost"
                                                      className="h-8 w-8"
                                                      disabled={!hasUpdatePermission || permissionsLoading}
                                                      onClick={() =>
                                                        setBarangayDialog({
                                                          open: true,
                                                          mode: "edit",
                                                          barangay,
                                                        })
                                                      }
                                                    >
                                                      <Edit className="h-4 w-4" />
                                                    </Button>
                                                  </span>
                                                </TooltipTrigger>
                                                <TooltipContent>
                                                  {hasUpdatePermission ? "Edit barangay" : "You don't have permission to edit"}
                                                </TooltipContent>
                                              </Tooltip>
                                            </TooltipProvider>
                                            <TooltipProvider>
                                              <Tooltip>
                                                <TooltipTrigger asChild>
                                                  <span tabIndex={hasDeletePermission ? -1 : 0}>
                                                    <Button
                                                      size="icon"
                                                      variant="ghost"
                                                      className="h-8 w-8"
                                                      disabled={!hasDeletePermission || permissionsLoading}
                                                      onClick={() =>
                                                        setDeleteDialog({
                                                          open: true,
                                                          type: "barangay",
                                                          id: barangay._id,
                                                          name: barangay.name,
                                                        })
                                                      }
                                                    >
                                                      <Trash2 className="h-4 w-4 text-destructive" />
                                                    </Button>
                                                  </span>
                                                </TooltipTrigger>
                                                <TooltipContent>
                                                  {hasDeletePermission ? "Delete barangay" : "You don't have permission to delete"}
                                                </TooltipContent>
                                              </Tooltip>
                                            </TooltipProvider>
                                          </div>
                                        </li>
                                      ))}
                                    </ul>
                                  ) : (
                                    <p className="text-muted-foreground text-sm">
                                      No barangays yet. Click "Add Barangay" to create one.
                                    </p>
                                  )}
                                </div>
                              </AccordionContent>
                            </AccordionItem>
                          )
                        })}
                      </Accordion>

                      {provinceCities.length === 0 && (
                        <p className="text-muted-foreground text-sm">
                          No cities/municipalities yet. Click "Add City/Municipality" to create one.
                        </p>
                      )}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              )
            })}
          </Accordion>

          {provinces.length === 0 && (
            <p className="text-muted-foreground text-center py-8">
              No provinces yet. Click "Add Province" to create one.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Dialogs */}
      <ProvinceDialog
        mode={provinceDialog.mode}
        province={provinceDialog.province}
        open={provinceDialog.open}
        onOpenChange={(open) => setProvinceDialog({ ...provinceDialog, open })}
        onSuccess={() => setProvinceDialog({ open: false, mode: "create" })}
      />

      <CityDialog
        mode={cityDialog.mode}
        city={cityDialog.city}
        provinceId={cityDialog.provinceId}
        provinceName={cityDialog.provinceName}
        open={cityDialog.open}
        onOpenChange={(open) => setCityDialog({ ...cityDialog, open })}
        onSuccess={() => setCityDialog({ open: false, mode: "create" })}
      />

      <BarangayDialog
        mode={barangayDialog.mode}
        barangay={barangayDialog.barangay}
        cityId={barangayDialog.cityId}
        cityName={barangayDialog.cityName}
        open={barangayDialog.open}
        onOpenChange={(open) => setBarangayDialog({ ...barangayDialog, open })}
        onSuccess={() => setBarangayDialog({ open: false, mode: "create" })}
      />

      <AlertDialog open={deleteDialog.open} onOpenChange={(open) => setDeleteDialog({ ...deleteDialog, open })}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete <strong>{deleteDialog.name}</strong>.
              {deleteDialog.type !== "barangay" && (
                <span className="block mt-2 text-destructive font-semibold">
                  Warning: This action will fail if there are related{" "}
                  {deleteDialog.type === "province" ? "cities/municipalities" : "barangays"}.
                </span>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
    </PermissionGuard>
  )
}
