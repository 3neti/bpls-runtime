import { redirect } from "next/navigation"

export default function TaxesAndFeesPage() {
  redirect("/dashboard/taxes-and-fees/major")
}
