"use client"

import { useRouter } from "next/navigation"
import { ArrowLeft } from "lucide-react"

import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { BusinessOwnerFormWrapper } from "@/components/business-owners/business-owner-form-wrapper"

export default function NewBusinessOwnerPage() {
  const router = useRouter()

  return (
    <div className="flex-1 space-y-6 p-4 pt-6">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => router.push("/dashboard/business-owners")}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Create Business Owner</h2>
          <p className="text-muted-foreground">
            Add a new business owner to the system
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Business Owner Information</CardTitle>
          <CardDescription>Enter the personal and contact information for the new business owner</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <BusinessOwnerFormWrapper
            mode="create"
            onSuccess={() => {
              router.push("/dashboard/business-owners")
            }}
            onCancel={() => {
              router.push("/dashboard/business-owners")
            }}
          />
        </CardContent>
      </Card>
    </div>
  )
}
