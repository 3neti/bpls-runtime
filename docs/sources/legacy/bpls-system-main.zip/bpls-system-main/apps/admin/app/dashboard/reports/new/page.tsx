import { NewReportClient } from "./new-report-client"

/**
 * New Report Page (Server Component)
 *
 * Interface for creating new dynamic reports using the report builder.
 *
 * Features:
 * - Select resource type (data source)
 * - Choose dimensions (columns) and metrics
 * - Configure filters and date ranges
 * - Preview report results
 * - Save report configuration
 *
 * Architecture:
 * - Minimal server component, most logic in client component
 * - Uses Zustand store for report builder state
 * - Report generation via Convex queries
 */
export default function NewReportPage() {
  return <NewReportClient />
}
