import { preloadQuery, fetchQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { ConvexError } from "convex/values"
import { api } from "@repo/backend/convex/_generated/api"
import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"
import ReleasedClient from "./released-client"

export default async function ReleasedPage() {
  const token = await convexAuthNextjsToken()

  try {
    // Check if user has permission to view releasing page
    const hasReleasingPermission = await fetchQuery(
      api.permissions.hasPermission,
      { resource: "permit_applications:releasing", action: "read" },
      { token }
    )

    // If user doesn't have permission, show permission denied
    if (!hasReleasingPermission) {
      return (
        <PermissionDenied
          title="Releasing"
          description="View released permit applications"
          message="You don't have permission to view the releasing page"
          details={{
            resource: "permit_applications:releasing",
            action: "read",
            requiredPermission: "permit_applications:releasing:read",
          }}
          resourceName="releasing page"
          backLink="/dashboard/permit-applications"
          backLinkText="Back to Permit Applications"
        />
      )
    }

    // Preload applications with "Released" status including payment summary data
    // Using paginated query to avoid "Too many reads" error
    const preloadedApplications = await preloadQuery(
      api.businessPermitApplications.listReleasedWithPaymentSummaryPaginated,
      { paginationOpts: { numItems: 20, cursor: null } },
      { token }
    )

    // Preload the count for pagination UI
    const preloadedCount = await preloadQuery(
      api.businessPermitApplications.getReleasedCount,
      {},
      { token }
    )

    return (
      <ReleasedClient
        preloadedApplications={preloadedApplications}
        preloadedCount={preloadedCount}
      />
    )
  } catch (error) {
    if (error instanceof ConvexError) {
      const errorData = error.data as {
        code?: string
        message?: string
        details?: {
          resource?: string
          action?: string
          userRole?: string
          requiredPermission?: string
        }
      }

      if (errorData.code === "PERMISSION_DENIED") {
        return (
          <PermissionDenied
            title="Releasing"
            description="View released permit applications"
            message={errorData.message}
            details={errorData.details}
            resourceName="releasing page"
            backLink="/dashboard/permit-applications"
            backLinkText="Back to Permit Applications"
          />
        )
      }

      if (errorData.code === "UNAUTHENTICATED") {
        return <AuthenticationRequired />
      }
    }

    throw error
  }
}
