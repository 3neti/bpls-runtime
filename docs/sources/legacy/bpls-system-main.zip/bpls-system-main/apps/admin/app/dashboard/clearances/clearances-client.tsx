"use client"

import { useState, useMemo } from "react"
import { Plus } from "lucide-react"
import { usePermissions } from "@/hooks/use-permissions"
import { PermissionGuard } from "@/components/permission-guard"
import { PermissionDenied } from "@/components/permission-error-states"
import { Button } from "@repo/ui/components/button"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import { AddClearanceTypeDialog } from "@/components/clearances/add-clearance-type-dialog"
import { EditClearanceTypeDialog } from "@/components/clearances/edit-clearance-type-dialog"
import { DeleteClearanceTypeDialog } from "@/components/clearances/delete-clearance-type-dialog"
import { ClearancesDataTable } from "@/components/clearances/data-table"
import { createColumns } from "@/components/clearances/columns"
import { useToast } from "@/hooks/use-toast"
import { usePreloadedQuery, useMutation } from "convex/react"
import { api } from "@repo/backend/convex/_generated/api"
import type { Preloaded } from "convex/react"
import type { Doc, Id } from "@repo/backend/convex/_generated/dataModel"

interface ClearancesClientProps {
  preloadedClearanceTypes: Preloaded<typeof api.clearanceTypes.listClearanceTypes>
}

/**
 * Client Component for Clearance Types Management Page
 *
 * Handles all client-side interactions:
 * - Data table display with sorting, filtering, pagination
 * - Dialog states (add, edit, delete)
 * - Clearance type CRUD operations
 * - Toast notifications
 */
export function ClearancesClient({ preloadedClearanceTypes }: ClearancesClientProps) {
  const { canCreate, canUpdate, canDelete, isLoading: permissionsLoading } = usePermissions()

  // Permission checks
  const hasCreatePermission = canCreate("clearances")
  const hasUpdatePermission = canUpdate("clearances")
  const hasDeletePermission = canDelete("clearances")

  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [selectedClearanceType, setSelectedClearanceType] = useState<Doc<"clearance_types"> | null>(null)
  const [clearanceTypeToDelete, setClearanceTypeToDelete] = useState<{
    id: Id<"clearance_types">
    name: string
  } | null>(null)
  const { toast } = useToast()

  // Use preloaded query data
  const clearanceTypesData = usePreloadedQuery(preloadedClearanceTypes)

  // Mutations
  const deleteClearanceType = useMutation(api.clearanceTypes.deleteClearanceType)
  const updateClearanceType = useMutation(api.clearanceTypes.updateClearanceType)

  const handleEditClearanceType = (clearanceTypeData: Doc<"clearance_types">) => {
    setSelectedClearanceType(clearanceTypeData)
    setIsEditDialogOpen(true)
  }

  const handleDeleteClearanceType = (
    clearanceTypeId: Id<"clearance_types">,
    clearanceTypeName: string
  ) => {
    setClearanceTypeToDelete({
      id: clearanceTypeId,
      name: clearanceTypeName,
    })
  }

  const handleArchiveClearanceType = async (
    clearanceTypeId: Id<"clearance_types">,
    clearanceTypeName: string
  ) => {
    try {
      await updateClearanceType({ id: clearanceTypeId, isActive: false })

      toast({
        title: "Clearance Type Archived",
        description: `${clearanceTypeName} has been archived successfully.`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to archive clearance type",
        variant: "destructive",
      })
    }
  }

  const confirmDeleteClearanceType = async () => {
    if (!clearanceTypeToDelete) return

    try {
      await deleteClearanceType({ id: clearanceTypeToDelete.id })

      toast({
        title: "Clearance Type Deleted",
        description: `${clearanceTypeToDelete.name} has been deleted successfully.`,
      })

      setClearanceTypeToDelete(null)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete clearance type",
        variant: "destructive",
      })
    }
  }

  // Memoize columns to prevent unnecessary re-renders
  const columns = useMemo(
    () => createColumns(
      handleEditClearanceType,
      handleDeleteClearanceType,
      handleArchiveClearanceType,
      hasUpdatePermission && !permissionsLoading,
      hasDeletePermission && !permissionsLoading
    ),
    [hasUpdatePermission, hasDeletePermission, permissionsLoading]
  )

  // Loading state
  if (clearanceTypesData === undefined) {
    return (
      <div className="flex-1 space-y-4 p-4 pt-6">
        <div className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">Loading clearance types...</p>
        </div>
      </div>
    )
  }

  // Error state
  if (clearanceTypesData === null) {
    return (
      <div className="flex-1 space-y-4 p-4 pt-6">
        <div className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">Failed to load clearance types</p>
        </div>
      </div>
    )
  }

  return (
    <PermissionGuard
      resource="clearances"
      action="read"
      showLoading
      fallback={
        <PermissionDenied
          title="Clearance Types"
          description="Manage clearance types for business permit approvals"
          resourceName="clearance types"
          backLink="/dashboard"
          backLinkText="Back to Dashboard"
        />
      }
    >
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Clearance Types</h2>
          <p className="text-muted-foreground">
            Manage clearance types for business permit approvals (Sanitary, BFP, MPDC, etc.)
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={hasCreatePermission ? -1 : 0}>
                  <Button
                    onClick={() => setIsDialogOpen(true)}
                    disabled={!hasCreatePermission || permissionsLoading}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add Clearance Type
                  </Button>
                </span>
              </TooltipTrigger>
              {!hasCreatePermission && !permissionsLoading && (
                <TooltipContent>
                  <p>You don't have permission to create clearance types</p>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      {/* Add Clearance Type Dialog */}
      <AddClearanceTypeDialog
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
      />

      {/* Edit Clearance Type Dialog */}
      <EditClearanceTypeDialog
        open={isEditDialogOpen}
        onOpenChange={setIsEditDialogOpen}
        clearanceTypeData={selectedClearanceType}
        onSuccess={() => {
          toast({
            title: "Clearance Type Updated",
            description: "The clearance type has been updated successfully.",
          })
          setIsEditDialogOpen(false)
          setSelectedClearanceType(null)
        }}
      />

      {/* Delete Clearance Type Dialog */}
      <DeleteClearanceTypeDialog
        open={clearanceTypeToDelete !== null}
        onOpenChange={(open) => !open && setClearanceTypeToDelete(null)}
        clearanceTypeName={clearanceTypeToDelete?.name ?? ""}
        onConfirm={confirmDeleteClearanceType}
      />

      {/* Data Table */}
      <ClearancesDataTable
        columns={columns}
        data={clearanceTypesData}
      />
    </div>
    </PermissionGuard>
  )
}
