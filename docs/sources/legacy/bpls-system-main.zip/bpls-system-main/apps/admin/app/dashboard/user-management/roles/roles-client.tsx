"use client"

import { Fragment, useState, useMemo } from "react"
import { usePreloadedQuery, useQuery, useMutation } from "convex/react"
import { Plus, Edit, Trash2, Shield, Check, X, Loader2, Lock, Copy } from "lucide-react"

import { api } from "@repo/backend/convex/_generated/api"
import type { Preloaded } from "convex/react"
import type { Id, Doc } from "@repo/backend/convex/_generated/dataModel"
import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"
import { Input } from "@repo/ui/components/input"
import { Label } from "@repo/ui/components/label"
import { Switch } from "@repo/ui/components/switch"
import { Checkbox } from "@repo/ui/components/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@repo/ui/components/table"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import { PermissionGuard } from "@/components/permission-guard"
import { useToast } from "@/hooks/use-toast"

type RoleWithCount = Doc<"roles"> & { userCount: number }

interface RolesClientProps {
  preloadedRoles: Preloaded<typeof api.permissions.listRolesWithUserCount>
  preloadedPermissions: Preloaded<typeof api.permissions.listPermissions>
}

// Custom display names for resources
const RESOURCE_DISPLAY_NAMES: Record<string, string> = {
  // Permit Applications sub-resources
  "permit_applications": "Permit Applications",
  "permit_applications:new": "New Application",
  "permit_applications:all_applications": "All Applications",
  "permit_applications:assessment": "Assessment",
  "permit_applications:approval": "Approval",
  "permit_applications:payment": "Payment",
  "permit_applications:releasing": "Releasing",
  "permit_applications:schedule_of_payments": "Schedule of Payments",
  "permit_applications:fees_override": "Fees Override",
  "permit_applications:status_update": "Status Update",
  "new": "New Application",
  "all_applications": "All Applications",
  "assessment": "Assessment",
  "approval": "Approval",
  "payment": "Payment",
  "releasing": "Releasing",
  "schedule_of_payments": "Schedule of Payments",
  "fees_override": "Fees Override",
  "status_update": "Status Update",

  // Other parent resources
  "permits": "Permits",
  "business_owners": "Business Owners",
  "businesses": "Businesses",
  "billing_groups": "Billing Groups",
  "billing_groups:records": "Records",
  "billing_groups:records_update_after_payment": "Update After Payment",
  "billing_groups:line_items": "Line Items",
  "billing_groups:custom_fields": "Custom Fields",
  "billing_groups:receipt": "Receipt",
  "payments_billing": "Payments & Billing",
  "clearances": "Clearances",
  "users": "Users",
  "roles": "Roles",
  "locations": "Locations",
  "reports": "Reports",

  // Taxes & Fees sub-resources
  "taxes_and_fees": "Taxes and Fees",
  "taxes_and_fees:major": "Majors",
  "taxes_and_fees:division": "Divisions",
  "taxes_and_fees:line_of_business": "Line of Business",
  "taxes_and_fees:fees": "Fee Names",
  "taxes_and_fees:surcharge_penalty": "Surcharge & Penalty",
  "major": "Majors",
  "division": "Divisions",
  "line_of_business": "Line of Business",
  "fees": "Fee Names",
  "surcharge_penalty": "Surcharge & Penalty",

  // Settings sub-resources
  "settings": "Settings",
  "settings:platform_configuration": "Platform Configuration",
  "settings:municipality": "Municipality",
  "settings:officials": "Government Officials",
  "settings:branding": "Branding",
  "settings:receipting": "Receipting",
  "platform_configuration": "Platform Configuration",
  "municipality": "Municipality",
  "officials": "Government Officials",
  "branding": "Branding",
  "receipting": "Receipting",
  "settings:permit_layout": "Permit Layout",
  "permit_layout": "Permit Layout",

  // Billing Groups sub-resources (child-only names)
  "records": "Records",
  "line_items": "Line Items",
  "custom_fields": "Custom Fields",
  "receipt": "Receipt",

  // Activity Logs
  "activity_logs": "Activity Logs",
}

// Order matching sidebar navigation
const RESOURCES_ORDER = [
  "permit_applications",
  "permits",
  "business_owners",
  "businesses",
  "billing_groups",
  "payments_billing",
  "clearances",
  "users",
  "roles",
  "taxes_and_fees",
  "locations",
  "settings",
  "reports",
  "activity_logs",
]

// Order of sub-resources (children) within each parent group.
// Controls the row order under e.g. "Permit Applications" in the matrix
// (workflow order: Assessment -> Approval -> Payment). Unlisted children keep
// their original relative order and render after the listed ones.
const CHILD_RESOURCES_ORDER = [
  "permit_applications:schedule_of_payments",
  "permit_applications:new",
  "permit_applications:all_applications",
  "permit_applications:assessment",
  "permit_applications:approval",
  "permit_applications:payment",
  "permit_applications:releasing",
  "permit_applications:status_update",
  "permit_applications:fees_override",
  // Billing Groups children (order within the Billing Groups group)
  "billing_groups:records",
  "billing_groups:records_update_after_payment",
  "billing_groups:line_items",
  "billing_groups:custom_fields",
  "billing_groups:receipt",
]

// Configuration for resources with restricted actions
// Resources NOT in this map have ALL actions (create, read, update, delete) available
const ALLOWED_ACTIONS: Record<string, readonly string[]> = {
  // Parent resources with sub-resources - no direct actions
  "permit_applications": [],
  "taxes_and_fees": [],
  "settings": [],
  "billing_groups": [],

  // Billing Groups sub-resources
  "billing_groups:records": ["create", "read", "update", "delete"],
  "billing_groups:records_update_after_payment": ["update"],
  "billing_groups:line_items": ["create", "read", "update", "delete"],
  "billing_groups:custom_fields": ["create", "read", "update", "delete"],
  "billing_groups:receipt": ["create", "read", "update", "delete"],

  // Permit Applications sub-resources
  "permit_applications:new": ["create"],
  "permit_applications:all_applications": ["read", "update", "delete"],
  "permit_applications:assessment": ["read", "update", "delete"],
  "permit_applications:approval": ["read", "update"],
  "permit_applications:payment": ["read", "update", "delete"],
  "permit_applications:releasing": ["read", "update", "delete"],
  "permit_applications:schedule_of_payments": ["create", "read", "update", "delete"],
  "permit_applications:fees_override": ["update"],
  "permit_applications:status_update": ["update"],

  // Taxes & Fees sub-resources
  "taxes_and_fees:surcharge_penalty": ["read", "update"],

  // Settings sub-resources (all config pages - read/update only)
  "settings:platform_configuration": ["read", "update"],
  "settings:municipality": ["read", "update"],
  "settings:officials": ["read", "update"],
  "settings:branding": ["read", "update"],
  "settings:receipting": ["read", "update"],
  "settings:permit_layout": ["read", "update"],

  // Reports
  "reports": ["read"],

  // Activity Logs - read-only
  "activity_logs": ["read"],
} as const

// Helper function to check if an action is allowed for a resource
function isActionAllowed(resource: string, action: string): boolean {
  if (resource in ALLOWED_ACTIONS) {
    return ALLOWED_ACTIONS[resource].includes(action)
  }
  return true // Default: all actions allowed
}

// Helper function to format resource names
function formatResourceName(resource: string): string {
  // Check if there's a custom display name
  if (RESOURCE_DISPLAY_NAMES[resource]) {
    return RESOURCE_DISPLAY_NAMES[resource]
  }

  // Default formatting: replace underscores with spaces and capitalize
  return resource.replace(/_/g, " ")
}

// Component to display permissions for a role
function RolePermissionMatrix({
  roleId,
  allPermissions,
}: {
  roleId: Id<"roles">
  allPermissions: Doc<"permissions">[]
}) {
  const rolePermissions = useQuery(api.permissions.getRolePermissions, { roleId })

  // Group permissions by parent resource and sort by sidebar order
  const groupedPermissions = useMemo(() => {
    const groups: Record<string, {
      parent: string;
      displayName: string;
      children: Array<{ resource: string; displayName: string }>;
    }> = {}

    // Get unique resources
    const resources = new Set(allPermissions.map((p) => p.resource))

    resources.forEach((resource) => {
      const parts = resource.split(":")

      if (parts.length === 1) {
        // Flat resource (e.g., "permits")
        if (!groups[resource]) {
          groups[resource] = {
            parent: resource,
            displayName: formatResourceName(resource),
            children: [],
          }
        }
      } else if (parts.length === 2) {
        // Hierarchical (e.g., "permit_applications:payments")
        const parent = parts[0]
        const child = parts[1]

        if (!groups[parent]) {
          groups[parent] = {
            parent,
            displayName: formatResourceName(parent),
            children: [],
          }
        }

        // Only add child if not already present
        if (!groups[parent].children.some(c => c.resource === resource)) {
          groups[parent].children.push({
            resource,
            displayName: formatResourceName(child),
          })
        }
      }
    })

    // Sort sub-resources within each group by CHILD_RESOURCES_ORDER (workflow order)
    Object.values(groups).forEach((group) => {
      group.children.sort((a, b) => {
        const ia = CHILD_RESOURCES_ORDER.indexOf(a.resource)
        const ib = CHILD_RESOURCES_ORDER.indexOf(b.resource)
        if (ia === -1 && ib === -1) return 0
        if (ia === -1) return 1
        if (ib === -1) return -1
        return ia - ib
      })
    })

    // Sort groups by RESOURCES_ORDER to match sidebar navigation
    const sortedGroups: typeof groups = {}
    RESOURCES_ORDER.forEach((key) => {
      if (groups[key]) {
        sortedGroups[key] = groups[key]
      }
    })
    // Add any remaining groups not in RESOURCES_ORDER
    Object.keys(groups).forEach((key) => {
      if (!sortedGroups[key]) {
        sortedGroups[key] = groups[key]
      }
    })

    return sortedGroups
  }, [allPermissions])

  if (rolePermissions === undefined) {
    return (
      <div className="flex items-center justify-center py-4">
        <Loader2 className="h-4 w-4 animate-spin" />
      </div>
    )
  }

  // Create a set of permission strings for quick lookup
  type RolePermissionItem = NonNullable<typeof rolePermissions>[number];
  const permissionSet = new Set(
    rolePermissions.map((p: RolePermissionItem) => `${p.resource}:${p.action}`)
  )

  const hasPermission = (resource: string, action: string) => {
    return permissionSet.has(`${resource}:${action}`)
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[200px]">Resource</TableHead>
            <TableHead className="text-center w-24">Create</TableHead>
            <TableHead className="text-center w-24">Read</TableHead>
            <TableHead className="text-center w-24">Update</TableHead>
            <TableHead className="text-center w-24">Delete</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {Object.values(groupedPermissions).map((group) => (
            <Fragment key={group.parent}>
              {/* Parent resource row */}
              <TableRow>
                <TableCell className="font-medium capitalize">
                  {group.displayName}
                </TableCell>
                {["create", "read", "update", "delete"].map((action) => (
                  <TableCell key={action} className="text-center">
                    {!isActionAllowed(group.parent, action) ? (
                      <span className="text-muted-foreground">-</span>
                    ) : hasPermission(group.parent, action) ? (
                      <Check className="h-4 w-4 text-green-600 mx-auto" />
                    ) : (
                      <X className="h-4 w-4 text-muted-foreground/30 mx-auto" />
                    )}
                  </TableCell>
                ))}
              </TableRow>

              {/* Child sub-resource rows (indented) */}
              {group.children.map((child) => (
                <TableRow key={child.resource} className="bg-muted/30">
                  <TableCell className="pl-8 text-sm capitalize">
                    <span className="text-muted-foreground mr-1">↳</span>
                    {child.displayName}
                  </TableCell>
                  {["create", "read", "update", "delete"].map((action) => (
                    <TableCell key={action} className="text-center">
                      {!isActionAllowed(child.resource, action) ? (
                        <span className="text-muted-foreground">-</span>
                      ) : hasPermission(child.resource, action) ? (
                        <Check className="h-4 w-4 text-green-600 mx-auto" />
                      ) : (
                        <X className="h-4 w-4 text-muted-foreground/30 mx-auto" />
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </Fragment>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

// Component to edit permissions
function PermissionEditor({
  roleId,
  allPermissions,
}: {
  roleId: Id<"roles">
  allPermissions: Doc<"permissions">[]
}) {
  const { toast } = useToast()
  const rolePermissions = useQuery(api.permissions.getRolePermissions, { roleId })
  const assignPermission = useMutation(api.permissions.assignPermissionToRole)
  const removePermission = useMutation(api.permissions.removePermissionFromRole)
  const [isUpdating, setIsUpdating] = useState<string | null>(null)

  // Group permissions by parent resource and sort by sidebar order
  const groupedPermissions = useMemo(() => {
    const groups: Record<string, {
      parent: string;
      displayName: string;
      children: Array<{ resource: string; displayName: string }>;
    }> = {}

    // Get unique resources
    const resources = new Set(allPermissions.map((p) => p.resource))

    resources.forEach((resource) => {
      const parts = resource.split(":")

      if (parts.length === 1) {
        // Flat resource (e.g., "permits")
        if (!groups[resource]) {
          groups[resource] = {
            parent: resource,
            displayName: formatResourceName(resource),
            children: [],
          }
        }
      } else if (parts.length === 2) {
        // Hierarchical (e.g., "permit_applications:payments")
        const parent = parts[0]
        const child = parts[1]

        if (!groups[parent]) {
          groups[parent] = {
            parent,
            displayName: formatResourceName(parent),
            children: [],
          }
        }

        // Only add child if not already present
        if (!groups[parent].children.some(c => c.resource === resource)) {
          groups[parent].children.push({
            resource,
            displayName: formatResourceName(child),
          })
        }
      }
    })

    // Sort sub-resources within each group by CHILD_RESOURCES_ORDER (workflow order)
    Object.values(groups).forEach((group) => {
      group.children.sort((a, b) => {
        const ia = CHILD_RESOURCES_ORDER.indexOf(a.resource)
        const ib = CHILD_RESOURCES_ORDER.indexOf(b.resource)
        if (ia === -1 && ib === -1) return 0
        if (ia === -1) return 1
        if (ib === -1) return -1
        return ia - ib
      })
    })

    // Sort groups by RESOURCES_ORDER to match sidebar navigation
    const sortedGroups: typeof groups = {}
    RESOURCES_ORDER.forEach((key) => {
      if (groups[key]) {
        sortedGroups[key] = groups[key]
      }
    })
    // Add any remaining groups not in RESOURCES_ORDER
    Object.keys(groups).forEach((key) => {
      if (!sortedGroups[key]) {
        sortedGroups[key] = groups[key]
      }
    })

    return sortedGroups
  }, [allPermissions])

  if (rolePermissions === undefined) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    )
  }

  type RolePermItem = NonNullable<typeof rolePermissions>[number];
  const permissionSet = new Set(
    rolePermissions.map((p: RolePermItem) => `${p.resource}:${p.action}`)
  )

  const hasPermission = (resource: string, action: string) => {
    return permissionSet.has(`${resource}:${action}`)
  }

  const togglePermission = async (resource: string, action: string) => {
    const permission = allPermissions.find(
      (p) => p.resource === resource && p.action === action
    )
    if (!permission) return

    const key = `${resource}:${action}`
    const isChecked = hasPermission(resource, action)
    setIsUpdating(key)

    try {
      if (isChecked) {
        await removePermission({ roleId, permissionId: permission._id })
      } else {
        await assignPermission({ roleId, permissionId: permission._id })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update permission",
        variant: "destructive",
      })
    } finally {
      setIsUpdating(null)
    }
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[200px]">Resource</TableHead>
            <TableHead className="text-center w-24">Create</TableHead>
            <TableHead className="text-center w-24">Read</TableHead>
            <TableHead className="text-center w-24">Update</TableHead>
            <TableHead className="text-center w-24">Delete</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {Object.values(groupedPermissions).map((group) => (
            <Fragment key={group.parent}>
              {/* Parent resource row */}
              <TableRow>
                <TableCell className="font-medium capitalize">
                  {group.displayName}
                </TableCell>
                {["create", "read", "update", "delete"].map((action) => {
                  const key = `${group.parent}:${action}`
                  const isLoading = isUpdating === key
                  const actionAllowed = isActionAllowed(group.parent, action)

                  return (
                    <TableCell key={action} className="text-center">
                      {!actionAllowed ? (
                        <span className="text-muted-foreground">-</span>
                      ) : isLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin mx-auto" />
                      ) : (
                        <Checkbox
                          checked={hasPermission(group.parent, action)}
                          onCheckedChange={() => togglePermission(group.parent, action)}
                        />
                      )}
                    </TableCell>
                  )
                })}
              </TableRow>

              {/* Child sub-resource rows (indented) */}
              {group.children.map((child) => (
                <TableRow key={child.resource} className="bg-muted/30">
                  <TableCell className="pl-8 text-sm capitalize">
                    <span className="text-muted-foreground mr-1">↳</span>
                    {child.displayName}
                  </TableCell>
                  {["create", "read", "update", "delete"].map((action) => {
                    const key = `${child.resource}:${action}`
                    const isLoading = isUpdating === key
                    const actionAllowed = isActionAllowed(child.resource, action)

                    return (
                      <TableCell key={action} className="text-center">
                        {!actionAllowed ? (
                          <span className="text-muted-foreground">-</span>
                        ) : isLoading ? (
                          <Loader2 className="h-4 w-4 animate-spin mx-auto" />
                        ) : (
                          <Checkbox
                            checked={hasPermission(child.resource, action)}
                            onCheckedChange={() => togglePermission(child.resource, action)}
                          />
                        )}
                      </TableCell>
                    )
                  })}
                </TableRow>
              ))}
            </Fragment>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

export function RolesClient({ preloadedRoles, preloadedPermissions }: RolesClientProps) {
  const { toast } = useToast()
  const roles = usePreloadedQuery(preloadedRoles)
  const permissions = usePreloadedQuery(preloadedPermissions)
  const createRoleMutation = useMutation(api.permissions.createRole)
  const updateRoleMutation = useMutation(api.permissions.updateRole)
  const deleteRoleMutation = useMutation(api.permissions.deleteRole)
  const duplicateRoleMutation = useMutation(api.permissions.duplicateRole)

  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [editingRole, setEditingRole] = useState<RoleWithCount | null>(null)
  const [deletingRoleId, setDeletingRoleId] = useState<Id<"roles"> | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [newRoleName, setNewRoleName] = useState("")
  const [newRoleDescription, setNewRoleDescription] = useState("")
  const [editName, setEditName] = useState("")
  const [editDescription, setEditDescription] = useState("")

  // Handle undefined data (should not happen with preloaded query, but type safety)
  if (roles === undefined || permissions === undefined) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  const handleCreateRole = async () => {
    if (!newRoleName.trim()) return

    setIsSubmitting(true)
    try {
      await createRoleMutation({
        name: newRoleName.trim(),
        description: newRoleDescription.trim(),
      })
      toast({
        title: "Role created",
        description: `${newRoleName} has been created. You can now assign permissions.`,
      })
      setNewRoleName("")
      setNewRoleDescription("")
      setIsCreateDialogOpen(false)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create role",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleUpdateRole = async () => {
    if (!editingRole || !editName.trim()) return

    setIsSubmitting(true)
    try {
      await updateRoleMutation({
        id: editingRole._id,
        name: editName.trim(),
        description: editDescription.trim(),
      })
      toast({
        title: "Role updated",
        description: "Role information has been updated.",
      })
      setEditingRole(null)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update role",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteRole = async () => {
    if (!deletingRoleId) return

    setIsSubmitting(true)
    try {
      await deleteRoleMutation({ id: deletingRoleId })
      toast({
        title: "Role deleted",
        description: "The role has been removed from the system.",
      })
      setDeletingRoleId(null)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete role",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDuplicateRole = async (roleId: Id<"roles">) => {
    try {
      await duplicateRoleMutation({ sourceRoleId: roleId })
      toast({
        title: "Role duplicated",
        description: "A copy of the role has been created with all its permissions.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to duplicate role",
        variant: "destructive",
      })
    }
  }

  const openEditDialog = (role: RoleWithCount) => {
    setEditingRole(role)
    setEditName(role.name)
    setEditDescription(role.description)
  }

  return (
    <PermissionGuard resource="roles" action="read" showLoading>
      <div className="flex-1 space-y-4 p-4 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Role Management</h1>
            <p className="text-muted-foreground">
              Manage system roles and their permissions for different resources
            </p>
          </div>
          <PermissionGuard resource="roles" action="create" fallback={null}>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Create Role
            </Button>
          </PermissionGuard>
        </div>

        <div className="grid gap-6">
          {roles.map((role: (typeof roles)[number]) => (
            <Card key={role._id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="h-5 w-5" />
                      {role.name}
                      {role.isSystem && (
                        <span title="System role">
                          <Lock className="h-4 w-4 text-muted-foreground" />
                        </span>
                      )}
                    </CardTitle>
                    <CardDescription>{role.description}</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{role.userCount} users</Badge>
                    <PermissionGuard resource="roles" action="update" fallback={null}>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openEditDialog(role)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    </PermissionGuard>
                    <PermissionGuard resource="roles" action="create" fallback={null}>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDuplicateRole(role._id)}
                        title="Duplicate role"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </PermissionGuard>
                    {!role.isSystem && (
                      <PermissionGuard resource="roles" action="delete" fallback={null}>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setDeletingRoleId(role._id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </PermissionGuard>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Label className="text-sm font-medium">Resource Permissions</Label>
                  <RolePermissionMatrix roleId={role._id} allPermissions={permissions} />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Create Role Dialog */}
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Create New Role</DialogTitle>
              <DialogDescription>
                Define a new role. You can assign permissions after creating it.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="role-name">Role Name</Label>
                <Input
                  id="role-name"
                  value={newRoleName}
                  onChange={(e) => setNewRoleName(e.target.value)}
                  placeholder="e.g., Inspector"
                  disabled={isSubmitting}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="role-description">Description</Label>
                <Input
                  id="role-description"
                  value={newRoleDescription}
                  onChange={(e) => setNewRoleDescription(e.target.value)}
                  placeholder="Brief description of this role"
                  disabled={isSubmitting}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsCreateDialogOpen(false)}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button onClick={handleCreateRole} disabled={isSubmitting || !newRoleName.trim()}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating...
                  </>
                ) : (
                  "Create Role"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Role Dialog */}
        <Dialog open={!!editingRole} onOpenChange={(open) => !open && setEditingRole(null)}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Role: {editingRole?.name}</DialogTitle>
              <DialogDescription>
                Modify role information and permissions
              </DialogDescription>
            </DialogHeader>
            {editingRole && (
              <div className="space-y-6 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-role-name">Role Name</Label>
                    <Input
                      id="edit-role-name"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      disabled={isSubmitting || editingRole.isSystem}
                    />
                    {editingRole.isSystem && (
                      <p className="text-xs text-muted-foreground">
                        System roles cannot be renamed
                      </p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-role-description">Description</Label>
                    <Input
                      id="edit-role-description"
                      value={editDescription}
                      onChange={(e) => setEditDescription(e.target.value)}
                      disabled={isSubmitting}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-medium">Resource Permissions</Label>
                  <p className="text-xs text-muted-foreground">
                    Toggle permissions for this role. Changes are saved immediately.
                  </p>
                </div>

                <PermissionEditor
                  roleId={editingRole._id}
                  allPermissions={permissions}
                />
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditingRole(null)} disabled={isSubmitting}>
                Cancel
              </Button>
              <Button onClick={handleUpdateRole} disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={!!deletingRoleId} onOpenChange={(open) => !open && setDeletingRoleId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Role</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete this role? This action cannot be undone.
                Make sure no users are assigned to this role before deleting.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={isSubmitting}>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDeleteRole}
                disabled={isSubmitting}
                className="bg-destructive text-white hover:bg-destructive/90"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Deleting...
                  </>
                ) : (
                  "Delete"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </PermissionGuard>
  )
}
