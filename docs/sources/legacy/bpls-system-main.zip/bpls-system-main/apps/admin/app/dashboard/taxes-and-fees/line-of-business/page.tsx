import { Suspense } from "react"
import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import { LineOfBusinessClient } from "./line-of-business-client"
import { Skeleton } from "@repo/ui/components/skeleton"

export default async function LineOfBusinessPage() {
  const token = await convexAuthNextjsToken()

  const preloadedGroups = await preloadQuery(api.groups.list, {}, { token })

  return (
    <Suspense fallback={<LineOfBusinessPageSkeleton />}>
      <LineOfBusinessClient preloadedGroups={preloadedGroups} />
    </Suspense>
  )
}

function LineOfBusinessPageSkeleton() {
  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center justify-between">
        <Skeleton className="h-9 w-[200px]" />
        <Skeleton className="h-10 w-[120px]" />
      </div>
      <Skeleton className="h-[500px] w-full" />
    </div>
  )
}
