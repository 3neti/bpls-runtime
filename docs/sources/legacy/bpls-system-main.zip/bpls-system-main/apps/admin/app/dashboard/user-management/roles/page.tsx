import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { ConvexError } from "convex/values"
import { api } from "@repo/backend/convex/_generated/api"
import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"
import { RolesClient } from "./roles-client"

/**
 * Role Management Page (Server Component)
 *
 * Admin interface for managing system roles and their permissions.
 *
 * Features:
 * - View all system roles with permission matrices
 * - Create, edit, and delete custom roles
 * - Toggle individual permissions per role
 * - View user count per role
 *
 * Architecture:
 * - Server-side rendering with preloaded Convex queries
 * - Loading state handled by loading.tsx skeleton
 * - Client interactions delegated to RolesClient component
 */
export default async function RolesPage() {
  const token = await convexAuthNextjsToken()

  try {
    // Preload roles and permissions data on the server
    const [preloadedRoles, preloadedPermissions] = await Promise.all([
      preloadQuery(api.permissions.listRolesWithUserCount, {}, { token }),
      preloadQuery(api.permissions.listPermissions, {}, { token }),
    ])

    return (
      <RolesClient
        preloadedRoles={preloadedRoles}
        preloadedPermissions={preloadedPermissions}
      />
    )
  } catch (error) {
    // Handle permission denied errors gracefully
    if (error instanceof ConvexError) {
      const errorData = error.data as {
        code?: string
        message?: string
        details?: {
          resource?: string
          action?: string
          userRole?: string
          requiredPermission?: string
        }
      }

      if (errorData.code === "PERMISSION_DENIED") {
        return (
          <PermissionDenied
            title="Roles"
            description="Manage system roles and permissions"
            message={errorData.message}
            details={errorData.details}
            resourceName="roles"
          />
        )
      }

      if (errorData.code === "UNAUTHENTICATED") {
        return <AuthenticationRequired />
      }
    }

    // Re-throw other errors
    throw error
  }
}
