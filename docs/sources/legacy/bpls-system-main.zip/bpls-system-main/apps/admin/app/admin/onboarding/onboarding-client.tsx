"use client";

import { useState, useCallback, useEffect, useMemo } from "react";
import { useRouter } from "next/navigation";
import { useMutation, usePreloadedQuery } from "convex/react";
import type { Preloaded } from "convex/react";
import { useAuthActions } from "@convex-dev/auth/react";
import { useForm, FormProvider } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Building2, Loader2, CheckCircle2 } from "lucide-react";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import { Button } from "@repo/ui/components/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card";
import { useToast } from "@/hooks/use-toast";
import {
  onboardingSchema,
  onboardingDefaults,
  ONBOARDING_STEPS,
  type OnboardingData,
} from "@/lib/schemas/onboarding";

// Step components
import { MunicipalityStep } from "./steps/municipality-step";
import { OfficialsStep } from "./steps/officials-step";
import { BrandingStep } from "./steps/branding-step";
import { ReviewStep } from "./steps/review-step";
import { AdminUserStep } from "./steps/admin-user-step";

interface OnboardingClientProps {
  preloadedSettings: Preloaded<typeof api.platformSettings.get>;
  preloadedLogoUrl: Preloaded<typeof api.platformSettings.getLogoUrl>;
  preloadedLandingImageUrl: Preloaded<typeof api.platformSettings.getLandingImageUrl>;
  preloadedMunicipalSealUrl: Preloaded<typeof api.platformSettings.getMunicipalSealUrl>;
  isReturningUser: boolean;
}

// Progress indicator component
function StepProgress({ currentStep }: { currentStep: number }) {
  return (
    <div className="flex items-center justify-center gap-2 mb-8">
      {ONBOARDING_STEPS.map((step, index) => {
        const isCompleted = currentStep > step.id;
        const isCurrent = currentStep === step.id;

        return (
          <div key={step.id} className="flex items-center">
            <div
              className={`
                flex items-center justify-center w-8 h-8 rounded-full text-sm font-medium
                transition-colors duration-200
                ${isCompleted ? "bg-primary text-primary-foreground" : ""}
                ${isCurrent ? "bg-primary text-primary-foreground ring-2 ring-primary ring-offset-2" : ""}
                ${!isCompleted && !isCurrent ? "bg-muted text-muted-foreground" : ""}
              `}
            >
              {isCompleted ? <CheckCircle2 className="h-4 w-4" /> : step.id}
            </div>
            {index < ONBOARDING_STEPS.length - 1 && (
              <div
                className={`w-12 h-0.5 mx-2 transition-colors duration-200 ${
                  isCompleted ? "bg-primary" : "bg-muted"
                }`}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}

export function OnboardingClient({
  preloadedSettings,
  preloadedLogoUrl,
  preloadedLandingImageUrl,
  preloadedMunicipalSealUrl,
  isReturningUser,
}: OnboardingClientProps) {
  const router = useRouter();
  const { toast } = useToast();
  const { signIn } = useAuthActions();

  // Get preloaded data
  const settings = usePreloadedQuery(preloadedSettings);
  const logoUrl = usePreloadedQuery(preloadedLogoUrl);
  const landingImageUrl = usePreloadedQuery(preloadedLandingImageUrl);
  const municipalSealUrl = usePreloadedQuery(preloadedMunicipalSealUrl);

  // Compute initial form values from existing settings
  const initialFormValues = useMemo<OnboardingData>(() => {
    if (!settings) return onboardingDefaults;

    return {
      // Municipality step
      municipalityName: settings.municipalityName || onboardingDefaults.municipalityName,
      municipalityShortName: settings.municipalityShortName || onboardingDefaults.municipalityShortName,
      provinceName: settings.provinceName || onboardingDefaults.provinceName,
      fullAddress: settings.fullAddress || onboardingDefaults.fullAddress,
      permitExpiryMode: (settings.permitExpiryMode as "one_year" | "end_of_year") || onboardingDefaults.permitExpiryMode,
      // Officials step
      mayorName: settings.mayorName || onboardingDefaults.mayorName,
      mayorTitle: settings.mayorTitle || onboardingDefaults.mayorTitle,
      treasurerName: settings.treasurerName || onboardingDefaults.treasurerName,
      treasurerTitle: settings.treasurerTitle || onboardingDefaults.treasurerTitle,
      // Branding step (storage IDs are handled separately)
      municipalSealStorageId: settings.municipalSealStorageId?.toString(),
      logoStorageId: settings.logoStorageId?.toString(),
      landingImageStorageId: settings.landingImageStorageId?.toString(),
      // Admin user step (always start fresh)
      adminEmail: "",
      adminPassword: "",
      adminConfirmPassword: "",
      adminFirstName: "",
      adminLastName: "",
    };
  }, [settings]);

  // If returning user (onboarded but no users), start at admin account step (4)
  const initialStep = isReturningUser ? 4 : 1;
  const [currentStep, setCurrentStep] = useState(initialStep);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initialize uploaded images from existing settings
  const initialUploadedImages = useMemo(() => {
    const images: {
      municipalSeal?: { storageId: Id<"_storage">; url: string };
      logo?: { storageId: Id<"_storage">; url: string };
      landingImage?: { storageId: Id<"_storage">; url: string };
    } = {};

    if (settings?.municipalSealStorageId && municipalSealUrl) {
      images.municipalSeal = {
        storageId: settings.municipalSealStorageId,
        url: municipalSealUrl,
      };
    }
    if (settings?.logoStorageId && logoUrl) {
      images.logo = {
        storageId: settings.logoStorageId,
        url: logoUrl,
      };
    }
    if (settings?.landingImageStorageId && landingImageUrl) {
      images.landingImage = {
        storageId: settings.landingImageStorageId,
        url: landingImageUrl,
      };
    }

    return images;
  }, [settings, logoUrl, landingImageUrl, municipalSealUrl]);

  const [uploadedImages, setUploadedImages] = useState(initialUploadedImages);

  // Update uploaded images when initial values change (for SSR hydration)
  useEffect(() => {
    if (Object.keys(initialUploadedImages).length > 0) {
      setUploadedImages(initialUploadedImages);
    }
  }, [initialUploadedImages]);

  const completeOnboarding = useMutation(api.platformSettings.completeOnboarding);
  const initializeRolesAndPermissions = useMutation(
    api.permissions.initializeRolesAndPermissions
  );
  const initializeDefaultClearanceTypes = useMutation(
    api.clearanceTypes.initializeDefaultClearanceTypes
  );
  const seedDefaultBusinessCategories = useMutation(
    api.businessCategories.seedDefaultBusinessCategories
  );

  const form = useForm<OnboardingData>({
    resolver: zodResolver(onboardingSchema),
    defaultValues: initialFormValues,
    mode: "onChange",
  });

  // Reset form when initial values change (for SSR hydration)
  useEffect(() => {
    if (settings) {
      form.reset(initialFormValues);
    }
  }, [settings, initialFormValues, form]);

  const stepSchema = ONBOARDING_STEPS[currentStep - 1]?.schema;
  const currentStepInfo = ONBOARDING_STEPS[currentStep - 1];

  const validateCurrentStep = useCallback(async () => {
    if (!stepSchema) return true; // No validation for review step

    const fieldsToValidate = Object.keys(
      stepSchema.shape || {}
    ) as (keyof OnboardingData)[];
    const isValid = await form.trigger(fieldsToValidate);
    return isValid;
  }, [form, stepSchema]);

  const handleNext = async () => {
    const isValid = await validateCurrentStep();
    if (isValid) {
      setCurrentStep((prev) => Math.min(prev + 1, ONBOARDING_STEPS.length));
    }
  };

  const handleBack = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1));
  };

  const handleComplete = async () => {
    setIsSubmitting(true);

    try {
      const data = form.getValues();

      // Step 1: Create admin user via Convex Auth signUp
      const formData = new FormData();
      formData.append("email", data.adminEmail);
      formData.append("password", data.adminPassword);
      formData.append("name", `${data.adminFirstName} ${data.adminLastName}`);
      formData.append("flow", "signUp");

      await signIn("password", formData);

      // Step 2: Initialize default roles and permissions
      await initializeRolesAndPermissions({});

      // Step 3: Initialize default clearance types and business categories
      await initializeDefaultClearanceTypes({});
      await seedDefaultBusinessCategories({});

      // Step 4: Complete the platform onboarding
      await completeOnboarding({
        municipalityName: data.municipalityName,
        municipalityShortName: data.municipalityShortName,
        provinceName: data.provinceName,
        fullAddress: data.fullAddress,
        permitExpiryMode: data.permitExpiryMode,
        mayorName: data.mayorName,
        mayorTitle: data.mayorTitle,
        treasurerName: data.treasurerName,
        treasurerTitle: data.treasurerTitle,
        municipalSealStorageId: uploadedImages.municipalSeal?.storageId,
        logoStorageId: uploadedImages.logo?.storageId,
        landingImageStorageId: uploadedImages.landingImage?.storageId,
      });

      toast({
        title: "Setup Complete!",
        description:
          "Your platform has been configured and you are now signed in.",
      });

      // Redirect to dashboard (user is already authenticated)
      router.push("/dashboard");
    } catch (error) {
      console.error("Onboarding error:", error);
      toast({
        title: "Setup Failed",
        description:
          error instanceof Error
            ? error.message
            : "There was an error completing the setup. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <MunicipalityStep />;
      case 2:
        return <OfficialsStep />;
      case 3:
        return (
          <BrandingStep
            uploadedImages={uploadedImages}
            setUploadedImages={setUploadedImages}
          />
        );
      case 4:
        return <AdminUserStep />;
      case 5:
        return (
          <ReviewStep
            formData={form.getValues()}
            uploadedImages={uploadedImages}
          />
        );
      default:
        return null;
    }
  };

  return (
    <FormProvider {...form}>
      <div className="space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
              <Building2 className="h-8 w-8 text-primary" />
            </div>
          </div>
          <h1 className="text-3xl font-bold">Welcome to BPLS Portal</h1>
          <p className="text-muted-foreground max-w-md mx-auto">
            Let's set up your Business Permit & Licensing System. This will
            only take a few minutes.
          </p>
        </div>

        {/* Progress */}
        <StepProgress currentStep={currentStep} />

        {/* Step Content */}
        <Card>
          <CardHeader>
            <CardTitle>{currentStepInfo?.title}</CardTitle>
            <CardDescription>{currentStepInfo?.description}</CardDescription>
          </CardHeader>
          <CardContent>{renderStep()}</CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={currentStep === 1 || isSubmitting}
          >
            Back
          </Button>

          {currentStep < ONBOARDING_STEPS.length ? (
            <Button onClick={handleNext} disabled={isSubmitting}>
              Next
            </Button>
          ) : (
            <Button onClick={handleComplete} disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Completing Setup...
                </>
              ) : (
                "Complete Setup"
              )}
            </Button>
          )}
        </div>
      </div>
    </FormProvider>
  );
}
