"use client"

import { useState, useMemo, useEffect, useCallback } from "react"
import { usePreloadedQuery } from "convex/react"
import { useMutation } from "convex/react"
import type { Preloaded } from "convex/react"
import { format } from "date-fns"
import {
  Calculator,
  Info,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Save,
  Calendar,
  ChevronDown,
  XCircle,
  AlertCircle,
  Eye,
  Pencil,
  Undo2,
} from "lucide-react"

import { api } from "@repo/backend/convex/_generated/api"
import { usePermissions } from "@/hooks/use-permissions"
import { PermissionGuard } from "@/components/permission-guard"
import { PermissionDenied } from "@/components/permission-error-states"
import { Button } from "@repo/ui/components/button"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import { Badge } from "@repo/ui/components/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Input } from "@repo/ui/components/input"
import { Label } from "@repo/ui/components/label"
import { Textarea } from "@repo/ui/components/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import { Alert, AlertDescription } from "@repo/ui/components/alert"
import { Separator } from "@repo/ui/components/separator"
import { Calendar as CalendarComponent } from "@repo/ui/components/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@repo/ui/components/popover"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@repo/ui/components/collapsible"
import { useToast } from "@/hooks/use-toast"
import { cn } from "@/lib/utils"
import { formatCurrency } from "@/lib/utils/formatting"
import {
  calculateSurchargeAndPenalty,
  getPeriodsForMode,
  getDefaultDueDates,
  validateSurchargeFormula,
  SURCHARGE_PENALTY_VARIABLES,
  DEFAULT_QUARTERLY_DUE_DATES,
  DEFAULT_SEMI_ANNUAL_DUE_DATES,
  DEFAULT_ANNUAL_DUE_DATE,
} from "@/lib/utils/surcharge-penalty-calculator"

interface SurchargePenaltyClientProps {
  preloadedConfig: Preloaded<typeof api.surchargeConfig.getWithDefaults>
}

function parseCurrencyInput(value: string): number {
  const cleaned = value.replace(/[^0-9.]/g, "")
  return parseFloat(cleaned) || 0
}

const VARIABLE_DESCRIPTIONS: Record<string, string> = {
  periodFee: "Tax / periodToPay",
  Tax: "Total of all Tax-category fees",
  monthsMissed: "Months late (rounded up)",
  monthsMissedInPeriod: "Months late, capped at period length",
  quartersMissed: "Quarters late (rounded up)",
  daysDiff: "Days after due date",
  periodToPay: "1, 2, or 4 (payment periods)",
  totalFees: "Total fees from schedule",
}

const CATEGORY_COLORS: Record<string, string> = {
  "Tax": "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
  "Regulatory Fee": "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  "Other Charges": "bg-gray-100 text-gray-800 dark:bg-gray-800/50 dark:text-gray-400",
}

const MONTHS = [
  { value: "01", label: "Jan" },
  { value: "02", label: "Feb" },
  { value: "03", label: "Mar" },
  { value: "04", label: "Apr" },
  { value: "05", label: "May" },
  { value: "06", label: "Jun" },
  { value: "07", label: "Jul" },
  { value: "08", label: "Aug" },
  { value: "09", label: "Sep" },
  { value: "10", label: "Oct" },
  { value: "11", label: "Nov" },
  { value: "12", label: "Dec" },
]

// Default months for each term (used to compute dates from root day)
const DEFAULT_TERM_MONTHS: Record<string, string> = {
  Q1: "01", Q2: "04", Q3: "07", Q4: "10",
  S1: "01", S2: "07",
  A1: "01",
}

interface MockFee {
  name: string
  category: "Tax" | "Regulatory Fee" | "Other Charges"
  amount: number
}

// Variables Info Popover
function VariablesInfoPopover() {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="h-6 px-2 text-xs gap-1">
          <Info className="h-3 w-3" />
          Variables
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80" align="start">
        <div className="space-y-3">
          <div>
            <p className="font-medium text-sm">Available Variables</p>
            <p className="text-xs text-muted-foreground">Use these in your formulas</p>
          </div>
          <div className="space-y-1.5">
            {SURCHARGE_PENALTY_VARIABLES.map((variable) => (
              <div key={variable} className="flex items-center justify-between text-xs">
                <code className="px-1.5 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 rounded font-mono">
                  {variable}
                </code>
                <span className="text-muted-foreground">{VARIABLE_DESCRIPTIONS[variable]}</span>
              </div>
            ))}
          </div>
          <Separator />
          <p className="text-xs text-muted-foreground">
            Supports: <code>Math.min()</code>, <code>Math.max()</code>, <code>Math.floor()</code>, <code>Math.ceil()</code>
          </p>
        </div>
      </PopoverContent>
    </Popover>
  )
}

function ExamplesPopover({ type }: { type: "surcharge" | "penalty" }) {
  const examples = type === "surcharge" ? [
    { formula: "periodFee * 0.25", description: "25% of period fee" },
    { formula: "periodFee * 0.50", description: "50% of period fee" },
    { formula: "periodFee * 0.10 * Math.min(monthsMissed, 5)", description: "10% per month, max 5 months" },
    { formula: "Tax * 0.25 * quartersMissed", description: "25% of tax per quarter" },
  ] : [
    { formula: "Tax * 0.02 * monthsMissed", description: "2% of tax per month" },
    { formula: "Tax * Math.min(0.02 * monthsMissed, 0.24)", description: "2% per month, max 24%" },
    { formula: "periodFee * 0.01 * daysDiff", description: "1% of period fee per day" },
    { formula: "Tax * 0.05 * quartersMissed", description: "5% of tax per quarter" },
  ]

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="h-6 px-2 text-xs gap-1">
          <Calculator className="h-3 w-3" />
          Examples
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80" align="start">
        <div className="space-y-3">
          <p className="font-medium text-sm">Example Formulas</p>
          <div className="space-y-2">
            {examples.map((ex, i) => (
              <div key={i} className="text-xs">
                <code className="block px-2 py-1 bg-muted rounded font-mono text-xs mb-0.5">
                  {ex.formula}
                </code>
                <span className="text-muted-foreground">{ex.description}</span>
              </div>
            ))}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  )
}

interface MockScheduleSection {
  sectionNumber: number
  label: string
  termKey: string // e.g., "Q1", "S1", "A1"
  dueDate: Date
  dueDateMMDD: string // the MM-DD stored value
  fees: MockFee[]
  surcharge: number
  penalty: number
  total: number
  isPastDue: boolean
  daysDiff: number
  monthsMissed: number
  quartersMissed: number
}

// Generate mock schedule sections
function generateMockScheduleSections(
  mode: "Annually" | "Semi-Annually" | "Quarterly",
  totalTax: number,
  simulationDate: Date,
  surchargeFormula: string,
  penaltyFormula: string,
  dueDatesConfig: {
    quarterlyDueDates?: { Q1: string; Q2: string; Q3: string; Q4: string }
    semiAnnualDueDates?: { S1: string; S2: string }
    annualDueDate?: { A1: string }
  }
): MockScheduleSection[] {
  const periods = getPeriodsForMode(mode)
  const year = simulationDate.getFullYear()
  const dueDates = getDefaultDueDates(mode, year, dueDatesConfig)
  const periodTax = totalTax / periods
  const regulatoryFee = totalTax * 0.10

  const termKeys: Record<number, string[]> = {
    1: ["A1"],
    2: ["S1", "S2"],
    4: ["Q1", "Q2", "Q3", "Q4"],
  }
  const labels: Record<number, string[]> = {
    1: ["Full Payment"],
    2: ["1st Semester", "2nd Semester"],
    4: ["Q1", "Q2", "Q3", "Q4"],
  }

  // Get the MM-DD values for each term
  const mmddValues: string[] = (() => {
    switch (mode) {
      case "Quarterly": {
        const d = dueDatesConfig.quarterlyDueDates || DEFAULT_QUARTERLY_DUE_DATES
        return [d.Q1, d.Q2, d.Q3, d.Q4]
      }
      case "Semi-Annually": {
        const d = dueDatesConfig.semiAnnualDueDates || DEFAULT_SEMI_ANNUAL_DUE_DATES
        return [d.S1, d.S2]
      }
      case "Annually": {
        const d = dueDatesConfig.annualDueDate || DEFAULT_ANNUAL_DUE_DATE
        return [d.A1]
      }
    }
  })()

  return dueDates.map((dueDate, index) => {
    const config = { surchargeFormula, penaltyFormula }
    const result = calculateSurchargeAndPenalty(config, {
      Tax: totalTax,
      periodToPay: periods,
      dueDate,
      paymentDate: simulationDate,
    })

    const fees: MockFee[] = [
      { name: "Business Tax", category: "Tax", amount: periodTax },
    ]
    if (index === 0) {
      fees.push({ name: "Mayor's Permit", category: "Regulatory Fee", amount: regulatoryFee })
    }
    const feesTotal = fees.reduce((sum, f) => sum + f.amount, 0)

    return {
      sectionNumber: index + 1,
      label: labels[periods][index],
      termKey: termKeys[periods][index],
      dueDate,
      dueDateMMDD: mmddValues[index],
      fees,
      surcharge: result.surcharge,
      penalty: result.penalty,
      total: feesTotal + result.surcharge + result.penalty,
      isPastDue: result.isPastDueDate,
      daysDiff: result.daysDiff,
      monthsMissed: result.monthsMissed,
      quartersMissed: result.quartersMissed,
    }
  })
}

// Section Component with inline due date editing
function MockScheduleSectionComponent({
  section,
  isExpanded,
  onToggle,
  isOverridden,
  onEditDueDate,
  onResetDueDate,
  disabled,
}: {
  section: MockScheduleSection
  isExpanded: boolean
  onToggle: () => void
  isOverridden: boolean
  onEditDueDate: (termKey: string, mmdd: string) => void
  onResetDueDate: (termKey: string) => void
  disabled: boolean
}) {
  const [editing, setEditing] = useState(false)
  const [month, day] = section.dueDateMMDD.split("-")

  return (
    <Collapsible open={isExpanded} onOpenChange={onToggle}>
      <div className="border rounded-lg">
        <CollapsibleTrigger asChild>
          <div className="flex items-center justify-between p-3 cursor-pointer hover:bg-muted/50 transition-colors">
            <div className="flex items-center gap-2">
              <ChevronDown
                className={cn(
                  "h-4 w-4 transition-transform",
                  isExpanded && "rotate-180"
                )}
              />
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm">{section.label}</span>
                  {section.isPastDue ? (
                    <Badge variant="secondary" className="text-xs bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400">
                      <AlertTriangle className="h-3 w-3 mr-1" />
                      Past Due
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="text-xs bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                      <CheckCircle2 className="h-3 w-3 mr-1" />
                      On Time
                    </Badge>
                  )}
                  {isOverridden && (
                    <Badge variant="outline" className="text-xs">
                      Custom
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-1">
                  <p className="text-xs text-muted-foreground">
                    Due: {format(section.dueDate, "MMM d, yyyy")}
                  </p>
                </div>
              </div>
            </div>
            <span className="font-semibold text-sm">
              {formatCurrency(section.total, { withSymbol: true })}
            </span>
          </div>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <Separator />
          <div className="p-3 space-y-2">
            {/* Inline due date editor */}
            {!disabled && (
              <div className="flex items-center gap-2 py-1.5 px-2 bg-blue-50 dark:bg-blue-900/20 rounded border border-blue-200 dark:border-blue-800">
                <Calendar className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                <span className="text-xs font-medium text-blue-700 dark:text-blue-400">Due Date:</span>
                {editing ? (
                  <>
                    <Select
                      value={month}
                      onValueChange={(m) => {
                        onEditDueDate(section.termKey, `${m}-${day}`)
                      }}
                    >
                      <SelectTrigger className="h-6 w-[66px] text-xs" onClick={(e) => e.stopPropagation()}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {MONTHS.map((m) => (
                          <SelectItem key={m.value} value={m.value} className="text-xs">{m.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select
                      value={day}
                      onValueChange={(d) => {
                        onEditDueDate(section.termKey, `${month}-${d}`)
                      }}
                    >
                      <SelectTrigger className="h-6 w-[52px] text-xs" onClick={(e) => e.stopPropagation()}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 31 }, (_, i) => {
                          const d = (i + 1).toString().padStart(2, "0")
                          return <SelectItem key={d} value={d} className="text-xs">{i + 1}</SelectItem>
                        })}
                      </SelectContent>
                    </Select>
                    <Button variant="ghost" size="sm" className="h-6 px-1.5 text-xs" onClick={(e) => { e.stopPropagation(); setEditing(false) }}>
                      Done
                    </Button>
                    {isOverridden && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 px-1.5 text-xs text-muted-foreground"
                        onClick={(e) => { e.stopPropagation(); onResetDueDate(section.termKey); setEditing(false) }}
                      >
                        <Undo2 className="h-3 w-3 mr-1" />
                        Reset
                      </Button>
                    )}
                  </>
                ) : (
                  <>
                    <span className="text-xs text-blue-700 dark:text-blue-400">
                      {format(section.dueDate, "MMM d, yyyy")}
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 px-1.5 text-xs text-blue-600 dark:text-blue-400"
                      onClick={(e) => { e.stopPropagation(); setEditing(true) }}
                    >
                      <Pencil className="h-3 w-3" />
                    </Button>
                    {isOverridden && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 px-1.5 text-xs text-muted-foreground"
                        onClick={(e) => { e.stopPropagation(); onResetDueDate(section.termKey) }}
                      >
                        <Undo2 className="h-3 w-3 mr-1" />
                        Reset
                      </Button>
                    )}
                  </>
                )}
              </div>
            )}

            {section.fees.map((fee, index) => (
              <div key={index} className="flex items-center justify-between py-1.5 px-2 bg-muted/30 rounded text-sm">
                <div className="flex items-center gap-2">
                  <span>{fee.name}</span>
                  <Badge variant="secondary" className={cn("text-xs", CATEGORY_COLORS[fee.category])}>
                    {fee.category}
                  </Badge>
                </div>
                <span className="font-medium">{formatCurrency(fee.amount, { withSymbol: true })}</span>
              </div>
            ))}

            <div className="flex items-center justify-between py-1.5 px-2 bg-orange-50 dark:bg-orange-900/20 rounded border border-orange-200 dark:border-orange-800 text-sm">
              <span className="font-medium text-orange-700 dark:text-orange-400">Surcharge</span>
              <span className="font-medium text-orange-700 dark:text-orange-400">
                {formatCurrency(section.surcharge, { withSymbol: true })}
              </span>
            </div>

            <div className="flex items-center justify-between py-1.5 px-2 bg-red-50 dark:bg-red-900/20 rounded border border-red-200 dark:border-red-800 text-sm">
              <span className="font-medium text-red-700 dark:text-red-400">Penalty</span>
              <span className="font-medium text-red-700 dark:text-red-400">
                {formatCurrency(section.penalty, { withSymbol: true })}
              </span>
            </div>

            <Separator />
            <div className="flex items-center justify-between font-semibold text-sm">
              <span>Section Total:</span>
              <span>{formatCurrency(section.total, { withSymbol: true })}</span>
            </div>
          </div>
        </CollapsibleContent>
      </div>
    </Collapsible>
  )
}

// Helper to extract the day portion from an MM-DD string
function extractDay(mmdd: string): string {
  return mmdd.split("-")[1]
}

// Helper to check if a term is overridden (its day differs from root day)
function isTermOverridden(mmdd: string, rootDay: string, termKey: string): boolean {
  const [month] = mmdd.split("-")
  const defaultMonth = DEFAULT_TERM_MONTHS[termKey]
  return month !== defaultMonth || extractDay(mmdd) !== rootDay
}

// Schedule Preview Card with integrated due date configuration
function SchedulePreviewCard({
  mode,
  sections,
  expandedSections,
  onToggleSection,
  rootDay,
  onRootDayChange,
  onTermDueDateChange,
  onTermReset,
  disabled,
}: {
  mode: "Annually" | "Semi-Annually" | "Quarterly"
  sections: MockScheduleSection[]
  expandedSections: Set<number>
  onToggleSection: (sectionNumber: number) => void
  rootDay: string // day portion, e.g., "20"
  onRootDayChange: (day: string) => void
  onTermDueDateChange: (termKey: string, mmdd: string) => void
  onTermReset: (termKey: string) => void
  disabled: boolean
}) {
  const totals = useMemo(() => {
    const totalFees = sections.reduce((sum, s) => sum + s.fees.reduce((fSum, f) => fSum + f.amount, 0), 0)
    const totalSurcharge = sections.reduce((sum, s) => sum + s.surcharge, 0)
    const totalPenalty = sections.reduce((sum, s) => sum + s.penalty, 0)
    const grandTotal = sections.reduce((sum, s) => sum + s.total, 0)
    return { totalFees, totalSurcharge, totalPenalty, grandTotal }
  }, [sections])

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-semibold">{mode}</CardTitle>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Due Day:</span>
            <Select value={rootDay} onValueChange={onRootDayChange} disabled={disabled}>
              <SelectTrigger className="h-8 w-[80px] text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Array.from({ length: 31 }, (_, i) => {
                  const d = (i + 1).toString().padStart(2, "0")
                  return (
                    <SelectItem key={d} value={d} className="text-xs">
                      {i + 1}{i === 0 ? "st" : i === 1 ? "nd" : i === 2 ? "rd" : "th"}
                    </SelectItem>
                  )
                })}
              </SelectContent>
            </Select>
            <span className="text-xs text-muted-foreground">of each period</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        {sections.map((section) => (
          <MockScheduleSectionComponent
            key={section.sectionNumber}
            section={section}
            isExpanded={expandedSections.has(section.sectionNumber)}
            onToggle={() => onToggleSection(section.sectionNumber)}
            isOverridden={isTermOverridden(section.dueDateMMDD, rootDay, section.termKey)}
            onEditDueDate={onTermDueDateChange}
            onResetDueDate={onTermReset}
            disabled={disabled}
          />
        ))}

        <Separator />

        <div className="space-y-1.5">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Annual Total:</span>
            <span className="font-medium">{formatCurrency(totals.grandTotal, { withSymbol: true })}</span>
          </div>
          <div className="flex justify-between text-xs text-orange-600 dark:text-orange-400">
            <span>Total Surcharge:</span>
            <span className="font-medium">{formatCurrency(totals.totalSurcharge, { withSymbol: true })}</span>
          </div>
          <div className="flex justify-between text-xs text-red-600 dark:text-red-400">
            <span>Total Penalty:</span>
            <span className="font-medium">{formatCurrency(totals.totalPenalty, { withSymbol: true })}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// FormulaInput component
interface FormulaInputProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
  label: string
  disabled?: boolean
  type: "surcharge" | "penalty"
}

function FormulaInput({ value, onChange, placeholder, label, disabled, type }: FormulaInputProps) {
  const [hasInteracted, setHasInteracted] = useState(false)
  const [validation, setValidation] = useState<{ valid: boolean; error?: string }>({ valid: true })

  useEffect(() => {
    if (value) {
      const result = validateSurchargeFormula(value)
      setValidation(result)
    } else {
      setValidation({ valid: true })
    }
  }, [value])

  const validationState = (() => {
    if (!hasInteracted && !value) return "neutral"
    return validation.valid ? "valid" : "invalid"
  })()

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <Label className="text-sm">{label}</Label>
        <div className="flex items-center gap-1">
          <VariablesInfoPopover />
          <ExamplesPopover type={type} />
        </div>
      </div>
      <div className="relative">
        <Textarea
          value={value}
          onChange={(e) => { setHasInteracted(true); onChange(e.target.value) }}
          onFocus={() => setHasInteracted(true)}
          placeholder={placeholder}
          disabled={disabled}
          rows={1}
          className={cn(
            "font-mono pr-10 transition-colors min-h-[38px] resize-none",
            validationState === "valid" && value && "border-green-500 focus-visible:ring-green-500",
            validationState === "invalid" && hasInteracted && "border-red-500 focus-visible:ring-red-500"
          )}
        />
        {hasInteracted && value && (
          <div className="absolute right-3 top-2">
            {validationState === "valid" ? (
              <CheckCircle2 className="h-4 w-4 text-green-500" />
            ) : (
              <XCircle className="h-4 w-4 text-red-500" />
            )}
          </div>
        )}
      </div>
      {hasInteracted && validationState === "invalid" && validation.error && (
        <div className="text-xs flex items-start gap-1.5 text-red-600">
          <AlertCircle className="h-3.5 w-3.5 mt-0.5 flex-shrink-0" />
          <span>{validation.error}</span>
        </div>
      )}
    </div>
  )
}

export default function SurchargePenaltyClient({ preloadedConfig }: SurchargePenaltyClientProps) {
  const config = usePreloadedQuery(preloadedConfig)
  const upsertConfig = useMutation(api.surchargeConfig.upsert)
  const { toast } = useToast()
  const { canUpdate, isLoading: permissionsLoading } = usePermissions()

  const hasUpdatePermission = canUpdate("taxes_and_fees:surcharge_penalty")

  // Form state - formulas
  const [surchargeFormula, setSurchargeFormula] = useState(config.surchargeFormula || "")
  const [penaltyFormula, setPenaltyFormula] = useState(config.penaltyFormula || "")
  const [isSaving, setIsSaving] = useState(false)

  // Per-mode due date state
  const [quarterlyDueDates, setQuarterlyDueDates] = useState<{ Q1: string; Q2: string; Q3: string; Q4: string }>(
    config.quarterlyDueDates || DEFAULT_QUARTERLY_DUE_DATES
  )
  const [semiAnnualDueDates, setSemiAnnualDueDates] = useState<{ S1: string; S2: string }>(
    config.semiAnnualDueDates || DEFAULT_SEMI_ANNUAL_DUE_DATES
  )
  const [annualDueDate, setAnnualDueDate] = useState<{ A1: string }>(
    config.annualDueDate || DEFAULT_ANNUAL_DUE_DATE
  )

  // Root day per mode (derived from first term's day)
  const quarterlyRootDay = extractDay(quarterlyDueDates.Q1)
  const semiAnnualRootDay = extractDay(semiAnnualDueDates.S1)
  const annualRootDay = extractDay(annualDueDate.A1)

  // Root day change handlers - update all non-overridden terms
  const handleQuarterlyRootDayChange = useCallback((newDay: string) => {
    setQuarterlyDueDates(prev => ({
      Q1: isTermOverridden(prev.Q1, quarterlyRootDay, "Q1") ? prev.Q1 : `${DEFAULT_TERM_MONTHS.Q1}-${newDay}`,
      Q2: isTermOverridden(prev.Q2, quarterlyRootDay, "Q2") ? prev.Q2 : `${DEFAULT_TERM_MONTHS.Q2}-${newDay}`,
      Q3: isTermOverridden(prev.Q3, quarterlyRootDay, "Q3") ? prev.Q3 : `${DEFAULT_TERM_MONTHS.Q3}-${newDay}`,
      Q4: isTermOverridden(prev.Q4, quarterlyRootDay, "Q4") ? prev.Q4 : `${DEFAULT_TERM_MONTHS.Q4}-${newDay}`,
    }))
  }, [quarterlyRootDay])

  const handleSemiAnnualRootDayChange = useCallback((newDay: string) => {
    setSemiAnnualDueDates(prev => ({
      S1: isTermOverridden(prev.S1, semiAnnualRootDay, "S1") ? prev.S1 : `${DEFAULT_TERM_MONTHS.S1}-${newDay}`,
      S2: isTermOverridden(prev.S2, semiAnnualRootDay, "S2") ? prev.S2 : `${DEFAULT_TERM_MONTHS.S2}-${newDay}`,
    }))
  }, [semiAnnualRootDay])

  const handleAnnualRootDayChange = useCallback((newDay: string) => {
    setAnnualDueDate({ A1: `${DEFAULT_TERM_MONTHS.A1}-${newDay}` })
  }, [])

  // Per-term due date change handlers
  const handleQuarterlyTermChange = useCallback((termKey: string, mmdd: string) => {
    setQuarterlyDueDates(prev => ({ ...prev, [termKey]: mmdd }))
  }, [])

  const handleSemiAnnualTermChange = useCallback((termKey: string, mmdd: string) => {
    setSemiAnnualDueDates(prev => ({ ...prev, [termKey]: mmdd }))
  }, [])

  const handleAnnualTermChange = useCallback((_termKey: string, mmdd: string) => {
    setAnnualDueDate({ A1: mmdd })
  }, [])

  // Reset term to root day
  const handleQuarterlyTermReset = useCallback((termKey: string) => {
    const defaultMonth = DEFAULT_TERM_MONTHS[termKey]
    setQuarterlyDueDates(prev => ({ ...prev, [termKey]: `${defaultMonth}-${quarterlyRootDay}` }))
  }, [quarterlyRootDay])

  const handleSemiAnnualTermReset = useCallback((termKey: string) => {
    const defaultMonth = DEFAULT_TERM_MONTHS[termKey]
    setSemiAnnualDueDates(prev => ({ ...prev, [termKey]: `${defaultMonth}-${semiAnnualRootDay}` }))
  }, [semiAnnualRootDay])

  const handleAnnualTermReset = useCallback((_termKey: string) => {
    setAnnualDueDate({ A1: `${DEFAULT_TERM_MONTHS.A1}-${annualRootDay}` })
  }, [annualRootDay])

  // Preview state
  const [previewTax, setPreviewTax] = useState("50000")
  const [simulationDate, setSimulationDate] = useState<Date>(() => {
    const date = new Date()
    date.setMonth(date.getMonth() + 4)
    return date
  })

  const [expandedQuarterly, setExpandedQuarterly] = useState<Set<number>>(new Set([1]))
  const [expandedSemiAnnual, setExpandedSemiAnnual] = useState<Set<number>>(new Set([1]))
  const [expandedAnnual, setExpandedAnnual] = useState<Set<number>>(new Set([1]))

  const toggleSection = (setter: React.Dispatch<React.SetStateAction<Set<number>>>) => (sectionNumber: number) => {
    setter((prev) => {
      const next = new Set(prev)
      if (next.has(sectionNumber)) { next.delete(sectionNumber) } else { next.add(sectionNumber) }
      return next
    })
  }

  const dueDatesConfig = useMemo(() => ({
    quarterlyDueDates,
    semiAnnualDueDates,
    annualDueDate,
  }), [quarterlyDueDates, semiAnnualDueDates, annualDueDate])

  const quarterlySections = useMemo(() => generateMockScheduleSections(
    "Quarterly", parseCurrencyInput(previewTax), simulationDate, surchargeFormula, penaltyFormula, dueDatesConfig
  ), [previewTax, simulationDate, surchargeFormula, penaltyFormula, dueDatesConfig])

  const semiAnnualSections = useMemo(() => generateMockScheduleSections(
    "Semi-Annually", parseCurrencyInput(previewTax), simulationDate, surchargeFormula, penaltyFormula, dueDatesConfig
  ), [previewTax, simulationDate, surchargeFormula, penaltyFormula, dueDatesConfig])

  const annualSections = useMemo(() => generateMockScheduleSections(
    "Annually", parseCurrencyInput(previewTax), simulationDate, surchargeFormula, penaltyFormula, dueDatesConfig
  ), [previewTax, simulationDate, surchargeFormula, penaltyFormula, dueDatesConfig])

  const surchargeValidation = useMemo(() => validateSurchargeFormula(surchargeFormula), [surchargeFormula])
  const penaltyValidation = useMemo(() => validateSurchargeFormula(penaltyFormula), [penaltyFormula])

  const hasChanges = useMemo(() => {
    return (
      surchargeFormula !== (config.surchargeFormula || "") ||
      penaltyFormula !== (config.penaltyFormula || "") ||
      JSON.stringify(quarterlyDueDates) !== JSON.stringify(config.quarterlyDueDates || DEFAULT_QUARTERLY_DUE_DATES) ||
      JSON.stringify(semiAnnualDueDates) !== JSON.stringify(config.semiAnnualDueDates || DEFAULT_SEMI_ANNUAL_DUE_DATES) ||
      JSON.stringify(annualDueDate) !== JSON.stringify(config.annualDueDate || DEFAULT_ANNUAL_DUE_DATE)
    )
  }, [surchargeFormula, penaltyFormula, quarterlyDueDates, semiAnnualDueDates, annualDueDate, config])

  const canSave = surchargeValidation.valid && penaltyValidation.valid

  const handleSave = async () => {
    if (!canSave) {
      toast({ title: "Validation Error", description: "Please fix the formula errors before saving.", variant: "destructive" })
      return
    }
    setIsSaving(true)
    try {
      await upsertConfig({
        surchargeFormula: surchargeFormula || undefined,
        penaltyFormula: penaltyFormula || undefined,
        quarterlyDueDates,
        semiAnnualDueDates,
        annualDueDate,
      })
      toast({ title: "Configuration saved", description: "Surcharge and penalty configuration has been updated." })
    } catch (error) {
      toast({ title: "Error", description: error instanceof Error ? error.message : "Failed to save configuration", variant: "destructive" })
    } finally {
      setIsSaving(false)
    }
  }

  const resetPreview = () => {
    setPreviewTax("50000")
    const date = new Date()
    date.setMonth(date.getMonth() + 4)
    setSimulationDate(date)
    setExpandedQuarterly(new Set([1]))
    setExpandedSemiAnnual(new Set([1]))
    setExpandedAnnual(new Set([1]))
  }

  const isDisabled = !hasUpdatePermission || permissionsLoading

  return (
    <PermissionGuard
      resource="taxes_and_fees:surcharge_penalty"
      action="read"
      showLoading
      fallback={
        <PermissionDenied
          title="Surcharge & Penalty Configuration"
          description="Configure surcharge and penalty formulas for late payments"
          resourceName="surcharge and penalty configuration"
          backLink="/dashboard"
          backLinkText="Back to Dashboard"
        />
      }
    >
    <div className="flex-1 space-y-6 p-4 pt-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Surcharge & Penalty</h2>
            <p className="text-muted-foreground">
              Configure custom formulas for calculating surcharges and penalties on late payments.
            </p>
          </div>
          {!hasUpdatePermission && !permissionsLoading && (
            <Badge variant="secondary" className="h-6">Read Only</Badge>
          )}
        </div>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <span tabIndex={hasUpdatePermission ? -1 : 0}>
                <Button
                  onClick={handleSave}
                  disabled={isSaving || !hasChanges || !canSave || !hasUpdatePermission || permissionsLoading}
                >
                  <Save className="mr-2 h-4 w-4" />
                  {isSaving ? "Saving..." : "Save Configuration"}
                </Button>
              </span>
            </TooltipTrigger>
            {!hasUpdatePermission && !permissionsLoading && (
              <TooltipContent>
                <p>You don&apos;t have permission to update surcharge & penalty configuration</p>
              </TooltipContent>
            )}
          </Tooltip>
        </TooltipProvider>
      </div>

      {!config.isConfigured && (
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            No configuration has been set yet. Surcharge and penalty will remain at 0 until you configure and save the formulas below.
          </AlertDescription>
        </Alert>
      )}

      {/* Formula Configuration */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Formula Configuration
          </CardTitle>
          <CardDescription>
            Configure formulas for calculating late payment fees
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-orange-500" />
              <span className="text-sm font-medium">Surcharge</span>
            </div>
            <FormulaInput
              value={surchargeFormula}
              onChange={setSurchargeFormula}
              placeholder="e.g., periodFee * 0.25"
              label="Surcharge Formula"
              disabled={isDisabled}
              type="surcharge"
            />
          </div>

          <Separator />

          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-red-500" />
              <span className="text-sm font-medium">Penalty</span>
            </div>
            <FormulaInput
              value={penaltyFormula}
              onChange={setPenaltyFormula}
              placeholder="e.g., Tax * 0.02 * monthsMissed"
              label="Penalty Formula"
              disabled={isDisabled}
              type="penalty"
            />
          </div>
        </CardContent>
      </Card>

      {/* Schedule Previews with integrated due date config */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" />
              Schedule Previews
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={resetPreview}>
              <RotateCcw className="mr-2 h-4 w-4" />
              Reset
            </Button>
          </div>
          <CardDescription>
            Configure due dates and preview surcharge & penalty for each mode of payment. Set the root due day per mode, and override individual terms as needed.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Shared Preview Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="previewTax" className="text-xs">Annual Tax Amount</Label>
              <div className="relative">
                <span className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">&#8369;</span>
                <Input
                  id="previewTax"
                  type="text"
                  value={previewTax}
                  onChange={(e) => setPreviewTax(e.target.value)}
                  className="pl-6 h-9"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Simulate as of</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal h-9">
                    <Calendar className="mr-2 h-4 w-4" />
                    {format(simulationDate, "MMMM d, yyyy")}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={simulationDate}
                    onSelect={(date) => date && setSimulationDate(date)}
                    autoFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <p className="text-xs text-muted-foreground">
            Shows what fees would be if payment is made on the selected date. Surcharge applies on the due date.
          </p>

          <Separator />

          {/* 3 Stacked Previews with integrated due dates */}
          <div className="space-y-4">
            <SchedulePreviewCard
              mode="Quarterly"
              sections={quarterlySections}
              expandedSections={expandedQuarterly}
              onToggleSection={toggleSection(setExpandedQuarterly)}
              rootDay={quarterlyRootDay}
              onRootDayChange={handleQuarterlyRootDayChange}
              onTermDueDateChange={handleQuarterlyTermChange}
              onTermReset={handleQuarterlyTermReset}
              disabled={isDisabled}
            />
            <SchedulePreviewCard
              mode="Semi-Annually"
              sections={semiAnnualSections}
              expandedSections={expandedSemiAnnual}
              onToggleSection={toggleSection(setExpandedSemiAnnual)}
              rootDay={semiAnnualRootDay}
              onRootDayChange={handleSemiAnnualRootDayChange}
              onTermDueDateChange={handleSemiAnnualTermChange}
              onTermReset={handleSemiAnnualTermReset}
              disabled={isDisabled}
            />
            <SchedulePreviewCard
              mode="Annually"
              sections={annualSections}
              expandedSections={expandedAnnual}
              onToggleSection={toggleSection(setExpandedAnnual)}
              rootDay={annualRootDay}
              onRootDayChange={handleAnnualRootDayChange}
              onTermDueDateChange={handleAnnualTermChange}
              onTermReset={handleAnnualTermReset}
              disabled={isDisabled}
            />
          </div>
        </CardContent>
      </Card>
    </div>
    </PermissionGuard>
  )
}
