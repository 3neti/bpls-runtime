"use client";

import { useToast } from "@/hooks/use-toast";
import { PermitLayoutSection } from "@/components/settings/permit-layout-section";
import { PermissionGuard } from "@/components/permission-guard";

export default function PermitLayoutPage() {
  const { toast } = useToast();

  return (
    <PermissionGuard resource="settings:permit_layout" action="read" showLoading>
      <PermitLayoutSection toast={toast} />
    </PermissionGuard>
  );
}
