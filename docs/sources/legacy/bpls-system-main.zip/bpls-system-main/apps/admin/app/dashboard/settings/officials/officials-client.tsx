"use client"

import { usePreloadedQuery } from "convex/react"
import { api } from "@repo/backend/convex/_generated/api"
import { useToast } from "@/hooks/use-toast"
import { OfficialsSection } from "@/components/settings/officials-section"
import { PermissionGuard } from "@/components/permission-guard"
import type { Preloaded } from "convex/react"

interface OfficialsClientProps {
  preloadedSettings: Preloaded<typeof api.platformSettings.get>
}

export function OfficialsClient({
  preloadedSettings,
}: OfficialsClientProps) {
  const { toast } = useToast()
  const settings = usePreloadedQuery(preloadedSettings)

  return (
    <PermissionGuard resource="settings:officials" action="read" showLoading>
      <OfficialsSection settings={settings} toast={toast} />
    </PermissionGuard>
  )
}
