import { preloadQuery } from "convex/nextjs";
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server";
import { api } from "@repo/backend/convex/_generated/api";
import DashboardClient from "./dashboard-client";

// Calculate default date range (last 7 days) - must match client-side calculation
function getDefaultDateRange() {
  const now = new Date();
  const end = new Date(now);
  end.setHours(23, 59, 59, 999);

  const start = new Date(now);
  start.setDate(start.getDate() - 6); // 7 days including today
  start.setHours(0, 0, 0, 0);

  return {
    startDate: start.toISOString(),
    endDate: end.toISOString(),
  };
}

export default async function DashboardPage() {
  const token = await convexAuthNextjsToken();

  // Get default date range for SSR preload
  const { startDate, endDate } = getDefaultDateRange();

  // Preload all dashboard data for SSR with default date range
  const [
    preloadedStats,
    preloadedActivity,
    preloadedWeekly,
    preloadedDistribution,
    preloadedTransactions,
  ] = await Promise.all([
    preloadQuery(api.dashboard.getDashboardStats, { startDate, endDate }, { token }),
    preloadQuery(api.dashboard.getPermitsActivityTimeSeries, { startDate, endDate }, { token }),
    preloadQuery(api.dashboard.getDailyApplicationsBreakdown, { startDate, endDate }, { token }),
    preloadQuery(api.dashboard.getPermitApplicationsDistribution, { startDate, endDate }, { token }),
    preloadQuery(api.dashboard.getRecentTransactions, { limit: 10, startDate, endDate }, { token }),
  ]);

  return (
    <DashboardClient
      preloadedStats={preloadedStats}
      preloadedActivity={preloadedActivity}
      preloadedWeekly={preloadedWeekly}
      preloadedDistribution={preloadedDistribution}
      preloadedTransactions={preloadedTransactions}
    />
  );
}
