import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import LocationsClient from "./locations-client"

export default async function LocationsPage() {
  const token = await convexAuthNextjsToken()

  const preloadedProvinces = await preloadQuery(api.locations.listProvinces, {}, { token })
  const preloadedCities = await preloadQuery(api.locations.listCities, {}, { token })
  const preloadedBarangays = await preloadQuery(api.locations.listBarangays, {}, { token })

  return (
    <LocationsClient
      preloadedProvinces={preloadedProvinces}
      preloadedCities={preloadedCities}
      preloadedBarangays={preloadedBarangays}
    />
  )
}
