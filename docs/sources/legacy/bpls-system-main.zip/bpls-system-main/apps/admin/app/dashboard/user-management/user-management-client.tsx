"use client"

import { useState } from "react"
import { usePreloadedQuery, useMutation, useAction } from "convex/react"
import { Users, Search, Plus, MoreHorizontal, Edit, Trash2, Mail, Calendar, Loader2, UserX, UserCheck, Clock, RefreshCw, Copy, Check, AlertTriangle, KeyRound } from "lucide-react"

import { api } from "@repo/backend/convex/_generated/api"
import type { Preloaded } from "convex/react"
import type { Id, Doc } from "@repo/backend/convex/_generated/dataModel"
import { Button } from "@repo/ui/components/button"
import { Input } from "@repo/ui/components/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@repo/ui/components/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Checkbox } from "@repo/ui/components/checkbox"
import { Avatar, AvatarFallback, AvatarImage } from "@repo/ui/components/avatar"
import { AddUserDialog } from "@/components/add-user-dialog"
import { EditUserDialog } from "@/components/edit-user-dialog"
import { PermissionGuard } from "@/components/permission-guard"
import { useToast } from "@/hooks/use-toast"
import { getInitials } from "@/lib/utils/formatting"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import { formatDate } from "@/lib/utils"

interface UserManagementClientProps {
  preloadedUsers: Preloaded<typeof api.users.list>
}

export function UserManagementClient({ preloadedUsers }: UserManagementClientProps) {
  const { toast } = useToast()
  const users = usePreloadedQuery(preloadedUsers)
  const createUserWithAuth = useAction(api.users.createUserWithAuth)
  const updateUser = useMutation(api.users.update)
  const deleteUserMutation = useMutation(api.users.deleteUser)
  const setUserStatus = useMutation(api.users.setStatus)
  const regeneratePasswordAction = useAction(api.users.regeneratePassword)

  const [searchTerm, setSearchTerm] = useState("")
  const [selectedUsers, setSelectedUsers] = useState<string[]>([])
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const [editingUser, setEditingUser] = useState<Doc<"users"> | null>(null)
  const [deletingUserId, setDeletingUserId] = useState<Id<"users"> | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [regeneratingUser, setRegeneratingUser] = useState<Doc<"users"> | null>(null)
  const [regeneratedPassword, setRegeneratedPassword] = useState<string | null>(null)
  const [passwordCopied, setPasswordCopied] = useState(false)

  // Handle undefined users (should not happen with preloaded query, but type safety)
  if (users === undefined) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  const filteredUsers = users.filter(
    (user: (typeof users)[number]) =>
      user.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.department.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedUsers(filteredUsers.map((user: (typeof users)[number]) => user._id))
    } else {
      setSelectedUsers([])
    }
  }

  const handleSelectUser = (userId: string, checked: boolean) => {
    if (checked) {
      setSelectedUsers([...selectedUsers, userId])
    } else {
      setSelectedUsers(selectedUsers.filter((id) => id !== userId))
    }
  }

  const handleAddUser = async (userData: {
    firstName: string
    lastName: string
    email: string
    phone?: string
    role: string
    department: string
    password: string
  }) => {
    setIsSubmitting(true)
    try {
      await createUserWithAuth({
        email: userData.email,
        firstName: userData.firstName,
        lastName: userData.lastName,
        phone: userData.phone,
        role: userData.role,
        department: userData.department,
        password: userData.password,
      })
      toast({
        title: "User created",
        description: `${userData.firstName} ${userData.lastName} has been added to the system.`,
      })
      // Don't close dialog - let it show the password success state
    } catch (error) {
      // Extract clean error message from Convex error format
      let errorMessage = "Failed to create user. Please try again."
      if (error instanceof Error) {
        // Remove "Uncaught Error:" prefix if present
        errorMessage = error.message
          .replace(/^Uncaught Error:\s*/i, "")
          .replace(/^Error:\s*/i, "")
          .trim()
      }

      // Determine appropriate title based on error type
      let errorTitle = "User Creation Failed"
      if (errorMessage.toLowerCase().includes("email")) {
        errorTitle = "Email Already In Use"
      } else if (errorMessage.toLowerCase().includes("password")) {
        errorTitle = "Invalid Password"
      } else if (errorMessage.toLowerCase().includes("credentials")) {
        errorTitle = "Authentication Error"
      }

      toast({
        title: errorTitle,
        description: errorMessage,
        variant: "destructive",
      })
      throw error // Re-throw to prevent success state in dialog
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleEditUser = async (userData: {
    firstName?: string
    lastName?: string
    phone?: string
    role?: string
    department?: string
    profilePhoto?: string
  }) => {
    if (!editingUser) return
    setIsSubmitting(true)
    try {
      await updateUser({
        id: editingUser._id,
        ...userData,
      })
      toast({
        title: "User updated",
        description: "User information has been updated successfully.",
      })
      setEditingUser(null)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update user",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleSetStatus = async (userId: Id<"users">, status: "Active" | "Inactive") => {
    try {
      await setUserStatus({ id: userId, status })
      toast({
        title: status === "Active" ? "User activated" : "User deactivated",
        description: status === "Inactive"
          ? "User can no longer log in until reactivated."
          : "User can now log in.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update user status",
        variant: "destructive",
      })
    }
  }

  const handleDeleteUser = async () => {
    if (!deletingUserId) return
    setIsSubmitting(true)
    try {
      await deleteUserMutation({ id: deletingUserId })
      toast({
        title: "User deleted",
        description: "The user has been removed from the system.",
      })
      setDeletingUserId(null)
      setSelectedUsers(selectedUsers.filter((id) => id !== deletingUserId))
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete user",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Generate a secure random password
  function generatePassword(): string {
    const uppercase = "ABCDEFGHJKLMNPQRSTUVWXYZ"
    const lowercase = "abcdefghijkmnpqrstuvwxyz"
    const numbers = "23456789"
    const special = "!@#$%^&*"
    const allChars = uppercase + lowercase + numbers + special
    let password = ""
    password += uppercase[Math.floor(Math.random() * uppercase.length)]
    password += lowercase[Math.floor(Math.random() * lowercase.length)]
    password += numbers[Math.floor(Math.random() * numbers.length)]
    password += special[Math.floor(Math.random() * special.length)]
    for (let i = 0; i < 8; i++) {
      password += allChars[Math.floor(Math.random() * allChars.length)]
    }
    return password.split("").sort(() => Math.random() - 0.5).join("")
  }

  const handleRegeneratePassword = async () => {
    if (!regeneratingUser) return
    setIsSubmitting(true)
    try {
      const newPassword = generatePassword()
      await regeneratePasswordAction({
        userId: regeneratingUser._id,
        newPassword,
      })
      setRegeneratedPassword(newPassword)
      toast({
        title: "Password regenerated",
        description: `New password generated for ${regeneratingUser.firstName} ${regeneratingUser.lastName}.`,
      })
    } catch (error) {
      let errorMessage = "Failed to regenerate password."
      if (error instanceof Error) {
        errorMessage = error.message.replace(/^Uncaught Error:\s*/i, "").replace(/^Error:\s*/i, "").trim()
      }
      toast({
        title: "Password Regeneration Failed",
        description: errorMessage,
        variant: "destructive",
      })
      setRegeneratingUser(null)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <PermissionGuard resource="users" action="read" showLoading>
      <div className="flex-1 space-y-4 p-4 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">User Management</h1>
            <p className="text-muted-foreground">Manage system users, their roles, and account settings</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search users..."
                className="w-[300px] pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                System Users
              </CardTitle>
              <CardDescription>Manage user accounts and permissions for the BPLS system</CardDescription>
            </div>
            <PermissionGuard resource="users" action="create" fallback={null}>
              <Button onClick={() => setIsAddUserOpen(true)}>
                <Plus className="h-4 w-4" />
                Add User
              </Button>
            </PermissionGuard>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">
                      <Checkbox
                        checked={selectedUsers.length === filteredUsers.length && filteredUsers.length > 0}
                        onCheckedChange={handleSelectAll}
                      />
                    </TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Login</TableHead>
                    <TableHead className="w-12">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user: (typeof users)[number]) => (
                    <TableRow key={user._id}>
                      <TableCell>
                        <Checkbox
                          checked={selectedUsers.includes(user._id)}
                          onCheckedChange={(checked) => handleSelectUser(user._id, checked as boolean)}
                        />
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={user.profilePhoto || undefined} alt={`${user.firstName} ${user.lastName}`} />
                            <AvatarFallback className="text-sm">
                              {getInitials(user.firstName, user.lastName)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">
                              {user.firstName} {user.lastName}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4 text-muted-foreground" />
                          {user.email}
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="inline-flex items-center rounded-full bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 dark:bg-blue-950 dark:text-blue-300">
                          {user.role}
                        </span>
                      </TableCell>
                      <TableCell>
                        {user.department || (
                          <span className="text-muted-foreground italic">No department</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <span
                          className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ${
                            user.status === "Active"
                              ? "bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300"
                              : "bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300"
                          }`}
                        >
                          {user.status}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          {formatDate(user.lastLogin)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <PermissionGuard resource="users" action="update" fallback={null}>
                              <DropdownMenuItem onClick={() => setEditingUser(user)}>
                                <Edit className="h-4 w-4" />
                                Edit User
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => setRegeneratingUser(user)}>
                                <KeyRound className="h-4 w-4" />
                                Regenerate Password
                              </DropdownMenuItem>
                            </PermissionGuard>

                            <PermissionGuard resource="users" action="update" fallback={null}>
                              <DropdownMenuSeparator />
                              {user.status === "Active" ? (
                                <DropdownMenuItem
                                  onClick={() => handleSetStatus(user._id, "Inactive")}
                                  className="text-amber-600 focus:text-amber-600"
                                >
                                  <UserX className="h-4 w-4" />
                                  Deactivate User
                                </DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem
                                  onClick={() => handleSetStatus(user._id, "Active")}
                                  className="text-green-600 focus:text-green-600"
                                >
                                  <UserCheck className="h-4 w-4" />
                                  Activate User
                                </DropdownMenuItem>
                              )}
                            </PermissionGuard>

                            <PermissionGuard resource="users" action="delete" fallback={null}>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                variant="destructive"
                                onClick={() => setDeletingUserId(user._id)}
                              >
                                <Trash2 className="h-4 w-4" />
                                Delete User
                              </DropdownMenuItem>
                            </PermissionGuard>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            {filteredUsers.length === 0 && (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Users className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium">No users found</h3>
                <p className="text-muted-foreground">
                  {searchTerm ? "Try adjusting your search terms." : "Get started by adding your first user."}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <AddUserDialog
          open={isAddUserOpen}
          onOpenChange={setIsAddUserOpen}
          onAddUser={handleAddUser}
          isSubmitting={isSubmitting}
        />

        {editingUser && (
          <EditUserDialog
            open={!!editingUser}
            onOpenChange={(open) => !open && setEditingUser(null)}
            user={editingUser}
            onEditUser={handleEditUser}
            isSubmitting={isSubmitting}
          />
        )}

        <AlertDialog open={!!deletingUserId} onOpenChange={(open) => !open && setDeletingUserId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete User</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete this user? This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={isSubmitting}>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDeleteUser}
                disabled={isSubmitting}
                className="bg-destructive text-white hover:bg-destructive/90"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Deleting...
                  </>
                ) : (
                  "Delete"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        <AlertDialog
          open={!!regeneratingUser || !!regeneratedPassword}
          onOpenChange={(open) => {
            if (!open) {
              setRegeneratingUser(null)
              setRegeneratedPassword(null)
              setPasswordCopied(false)
            }
          }}
        >
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>
                {regeneratedPassword ? "Password Regenerated" : "Regenerate Password"}
              </AlertDialogTitle>
              <AlertDialogDescription asChild>
                {regeneratedPassword ? (
                  <div className="space-y-4">
                    <p>New password for {regeneratingUser?.firstName} {regeneratingUser?.lastName}:</p>
                    <div className="flex items-center gap-2 p-3 bg-muted rounded-md font-mono">
                      <span className="flex-1 select-all">{regeneratedPassword}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          navigator.clipboard.writeText(regeneratedPassword)
                          setPasswordCopied(true)
                          setTimeout(() => setPasswordCopied(false), 2000)
                        }}
                      >
                        {passwordCopied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                    <p className="text-amber-600 text-sm flex items-center gap-1">
                      <AlertTriangle className="h-4 w-4" />
                      Make sure to copy this password. It won&apos;t be shown again.
                    </p>
                  </div>
                ) : (
                  <span>
                    Generate a new password for {regeneratingUser?.firstName} {regeneratingUser?.lastName}? They will need to use this new password to log in.
                  </span>
                )}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              {regeneratedPassword ? (
                <AlertDialogAction onClick={() => {
                  setRegeneratingUser(null)
                  setRegeneratedPassword(null)
                  setPasswordCopied(false)
                }}>
                  Done
                </AlertDialogAction>
              ) : (
                <>
                  <AlertDialogCancel disabled={isSubmitting}>Cancel</AlertDialogCancel>
                  <Button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault()
                      e.stopPropagation()
                      handleRegeneratePassword()
                    }}
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      "Regenerate"
                    )}
                  </Button>
                </>
              )}
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </PermissionGuard>
  )
}
