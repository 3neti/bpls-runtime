import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { ConvexError } from "convex/values"
import { api } from "@repo/backend/convex/_generated/api"
import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"
import BusinessesClient from "./businesses-client"

// Page size constant - should match the client component
const PAGE_SIZE = 20

export default async function BusinessesPage() {
  const token = await convexAuthNextjsToken()

  try {
    // Preload paginated businesses
    const preloadedBusinesses = await preloadQuery(
      api.businesses.listPaginated,
      {
        includeBlacklisted: true,
        paginationOpts: { numItems: PAGE_SIZE, cursor: null },
      },
      { token }
    )

    // Preload count for pagination UI
    const preloadedCount = await preloadQuery(
      api.businesses.getBusinessCount,
      { includeBlacklisted: true },
      { token }
    )

    return (
      <BusinessesClient
        preloadedBusinesses={preloadedBusinesses}
        preloadedCount={preloadedCount}
      />
    )
  } catch (error) {
    // Handle permission denied errors gracefully
    if (error instanceof ConvexError) {
      const errorData = error.data as {
        code?: string
        message?: string
        details?: {
          resource?: string
          action?: string
          userRole?: string
          requiredPermission?: string
        }
      }

      if (errorData.code === "PERMISSION_DENIED") {
        return (
          <PermissionDenied
            title="Businesses"
            description="Manage business registrations"
            message={errorData.message}
            details={errorData.details}
            resourceName="business"
          />
        )
      }

      if (errorData.code === "UNAUTHENTICATED") {
        return <AuthenticationRequired />
      }
    }

    // Re-throw other errors
    throw error
  }
}
