"use client"

import { useState, useCallback, useMemo, useRef, useEffect } from "react"
import { usePreloadedQuery, useQuery } from "convex/react"
import type { Preloaded } from "convex/react"
import {
  Search,
  Download,
  ExternalLink,
  CreditCard,
  TrendingUp,
  TrendingDown,
  DollarSign,
  AlertCircle,
  Layers,
  FileText,
  Plus,
  Pencil,
  HandCoins,
  Loader2,
} from "lucide-react"
import Link from "next/link"

import { Button } from "@repo/ui/components/button"
import { Input } from "@repo/ui/components/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@repo/ui/components/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select"
import { Skeleton } from "@repo/ui/components/skeleton"
import { Progress } from "@repo/ui/components/progress"

import { api } from "@repo/backend/convex/_generated/api"
import { formatCurrency } from "@/lib/utils"
import { formatDate } from "@/lib/utils/formatting"
import { useDebouncedValue } from "@/hooks/use-debounced-value"
import { NewTransactionModal } from "@/components/payments/new-transaction-modal"
import { EditDescriptionModal } from "@/components/payments/edit-description-modal"
import {
  convertToCSV,
  downloadCSV,
  generateExportFilename,
  formatDateForCSV,
  formatCurrencyForCSV,
  type CSVColumn,
} from "@/lib/utils/csv-export"
import {
  TableFilterPopover,
  createDefaultFilterState,
  type FilterConfig,
  type FilterState,
} from "@/components/permits/table-filter-popover"
import { PermissionGuard } from "@/components/permission-guard"

// Filter config for payments table
const FILTER_CONFIG: FilterConfig = {
  statusOptions: [],
  showDateRange: true,
  showTypeFilter: false,
}

type PaymentStatus = "all" | "pending" | "completed" | "failed" | "cancelled"
type SourceFilter = "all" | "permitPayment" | "billingGroup" | "manual"

type Transaction = {
  _id: string
  _creationTime?: number
  transactionNumber: string
  amount: number
  status: string
  date: string
  paymentMethod?: string
  referenceNumber?: string
  receiptNumber?: string
  applicationNumber?: string
  applicationId?: string
  billingGroupId?: string
  billingGroupName?: string
  description?: string
  transactionType?: "debit" | "credit"
  source: "permitPayment" | "billingGroup" | "manual"
}

interface PaymentsBillingClientProps {
  preloadedSummary: Preloaded<typeof api.payments.getSummary>;
  preloadedTransactions: Preloaded<typeof api.payments.listUnifiedPaginated>;
}

export default function PaymentsBillingClient({
  preloadedSummary,
  preloadedTransactions,
}: PaymentsBillingClientProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<PaymentStatus>("all")
  const [sourceFilter, setSourceFilter] = useState<SourceFilter>("all")
  const [filters, setFilters] = useState<FilterState>(createDefaultFilterState())
  const [isNewTransactionModalOpen, setIsNewTransactionModalOpen] = useState(false)
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null)

  // Cursor state for pagination
  const [cursor, setCursor] = useState<number | undefined>(undefined)
  const [accumulatedPages, setAccumulatedPages] = useState<Transaction[]>([])
  const [isLoadingMore, setIsLoadingMore] = useState(false)

  // Debounce search query
  const debouncedSearch = useDebouncedValue(searchQuery, 300)

  // Use preloaded data for SSR
  const preloadedSummaryData = usePreloadedQuery(preloadedSummary)
  const preloadedTransactionsData = usePreloadedQuery(preloadedTransactions)

  // Track filter changes to reset pagination
  const filterSignature = useMemo(
    () => JSON.stringify({ status: statusFilter, source: sourceFilter }),
    [statusFilter, sourceFilter]
  )

  // Reset accumulated pages when filters change
  useEffect(() => {
    setAccumulatedPages([])
    setCursor(undefined)
    setIsLoadingMore(false)
  }, [filterSignature])

  // Query for additional pages (after initial preloaded data)
  const additionalPages = useQuery(
    api.payments.listUnifiedPaginated,
    cursor !== undefined
      ? {
          status: statusFilter !== "all" ? statusFilter : undefined,
          source: sourceFilter !== "all" ? sourceFilter : undefined,
          cursor,
          pageSize: 50,
        }
      : "skip"
  )

  // Initialize with preloaded data
  useEffect(() => {
    if (preloadedTransactionsData && accumulatedPages.length === 0) {
      setAccumulatedPages(preloadedTransactionsData.page)
    }
  }, [preloadedTransactionsData, accumulatedPages.length])

  // Accumulate additional pages
  useEffect(() => {
    if (additionalPages && cursor !== undefined) {
      setAccumulatedPages((prev) => {
        const existingIds = new Set(prev.map((t) => t._id))
        const newItems = additionalPages.page.filter((t: Transaction) => !existingIds.has(t._id))
        return [...prev, ...newItems]
      })
      setIsLoadingMore(false)
    }
  }, [additionalPages, cursor])

  // Determine hasMore from the latest query result
  const hasMore = cursor === undefined
    ? preloadedTransactionsData?.hasMore ?? false
    : additionalPages?.hasMore ?? false

  // Get the next cursor
  const nextCursor = cursor === undefined
    ? preloadedTransactionsData?.nextCursor
    : additionalPages?.nextCursor

  // Load more function
  const loadMore = useCallback(() => {
    if (hasMore && nextCursor && !isLoadingMore) {
      setIsLoadingMore(true)
      setCursor(nextCursor)
    }
  }, [hasMore, nextCursor, isLoadingMore])

  // Server-side search query
  const searchResults = useQuery(
    api.search.searchUnifiedPayments,
    debouncedSearch.length >= 2
      ? { query: debouncedSearch, limit: 50 }
      : "skip"
  )

  // Infinite scroll observer
  const loadMoreRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!loadMoreRef.current || !hasMore || isLoadingMore) return

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !isLoadingMore) {
          loadMore()
        }
      },
      { threshold: 0.1 }
    )

    observer.observe(loadMoreRef.current)
    return () => observer.disconnect()
  }, [hasMore, isLoadingMore, loadMore])

  // Export state
  const [isExporting, setIsExporting] = useState(false)
  const [exportProgress, setExportProgress] = useState(0)
  const [exportCursor, setExportCursor] = useState<number | undefined>(undefined)
  const [exportTransactions, setExportTransactions] = useState<Transaction[]>([])

  // Query for export
  const exportResult = useQuery(
    api.payments.listUnifiedPaginated,
    isExporting
      ? {
          status: statusFilter !== "all" ? statusFilter : undefined,
          source: sourceFilter !== "all" ? sourceFilter : undefined,
          cursor: exportCursor,
          pageSize: 100,
        }
      : "skip"
  )

  // Process export results
  useEffect(() => {
    if (!isExporting || !exportResult) return

    setExportTransactions((prev) => {
      const existingIds = new Set(prev.map((t) => t._id))
      const newItems = exportResult.page.filter((t: Transaction) => !existingIds.has(t._id))
      return [...prev, ...newItems]
    })

    setExportProgress((prev) => prev + exportResult.page.length)

    if (exportResult.hasMore && exportResult.nextCursor) {
      setExportCursor(exportResult.nextCursor)
    } else {
      // Export complete - download CSV
      const allData = [...exportTransactions, ...exportResult.page]
      const uniqueData = Array.from(new Map(allData.map(t => [t._id, t])).values())

      const exportColumns: CSVColumn<Transaction>[] = [
        { header: "Transaction ID", accessor: (row) => row.transactionNumber },
        { header: "Source", accessor: (row) => row.source === "permitPayment" ? "Permit" : row.source === "billingGroup" ? "Billing Group" : row.transactionType === "credit" ? "Manual Credit" : "Manual Debit" },
        { header: "Amount", accessor: (row) => formatCurrencyForCSV(row.amount) },
        { header: "Date", accessor: (row) => formatDateForCSV(row.date) },
        { header: "Application Number", accessor: (row) => row.applicationNumber || "" },
        { header: "Billing Group", accessor: (row) => row.billingGroupName || "" },
        { header: "Reference Number", accessor: (row) => row.referenceNumber || "" },
        { header: "Receipt Number", accessor: (row) => row.receiptNumber || "" },
        { header: "Description", accessor: (row) => row.description || "" },
        { header: "Status", accessor: (row) => row.status },
      ]

      const csv = convertToCSV(uniqueData, exportColumns)
      const filename = generateExportFilename("payments-billing")
      downloadCSV(csv, filename)

      // Reset export state
      setIsExporting(false)
      setExportProgress(0)
      setExportCursor(undefined)
      setExportTransactions([])
    }
  }, [exportResult, isExporting, exportTransactions])

  // Start export
  const handleExport = useCallback(() => {
    setExportTransactions([])
    setExportProgress(0)
    setExportCursor(undefined)
    setIsExporting(true)
  }, [])

  // Cancel export
  const cancelExport = useCallback(() => {
    setIsExporting(false)
    setExportTransactions([])
    setExportProgress(0)
    setExportCursor(undefined)
  }, [])

  // Determine which data to use: search results or paginated data
  const filteredTransactions = useMemo((): Transaction[] => {
    if (debouncedSearch.length >= 2 && searchResults !== undefined) {
      // Normalize search results
      const normalizedPermitPayments = (searchResults.permitPayments || []).map((p: any): Transaction => ({
        _id: p._id,
        _creationTime: p._creationTime,
        transactionNumber: p.transactionNumber,
        amount: p.amount,
        status: p.status,
        date: p.paidAt,
        paymentMethod: p.paymentMethod,
        referenceNumber: p.referenceNumber,
        receiptNumber: p.receiptNumber,
        applicationNumber: p.applicationNumber,
        applicationId: p.applicationId,
        description: p.remarks || "",
        source: "permitPayment",
      }))

      const normalizedBillingRecords = (searchResults.billingRecords || []).map((r: any): Transaction => ({
        _id: r._id,
        _creationTime: r._creationTime,
        transactionNumber: r.transactionNumber,
        amount: r.amount,
        status: r.status,
        date: r.date || r.createdAt,
        paymentMethod: r.paymentMethod || "Cash",
        referenceNumber: r.referenceNumber,
        billingGroupId: r.billingGroupId,
        billingGroupName: r.billingGroupName,
        description: r.description || "",
        source: "billingGroup",
      }))

      const combined = [...normalizedPermitPayments, ...normalizedBillingRecords]

      // Apply date range filter
      if (filters.dateRange.from || filters.dateRange.to) {
        return combined.filter((transaction) => {
          if (!transaction.date) return true
          const itemDate = new Date(transaction.date)
          if (filters.dateRange.from && itemDate < filters.dateRange.from) return false
          if (filters.dateRange.to && itemDate > filters.dateRange.to) return false
          return true
        })
      }

      return combined
    }

    // Use paginated data
    let result = accumulatedPages || []

    // Apply date range filter
    if (filters.dateRange.from || filters.dateRange.to) {
      result = result.filter((transaction) => {
        if (!transaction.date) return true
        const itemDate = new Date(transaction.date)
        if (filters.dateRange.from && itemDate < filters.dateRange.from) return false
        if (filters.dateRange.to && itemDate > filters.dateRange.to) return false
        return true
      })
    }

    return result
  }, [accumulatedPages, debouncedSearch, searchResults, filters])

  const isLoading = preloadedSummaryData === undefined

  const getStatusBadge = (status: string, source: string) => {
    const normalizedStatus = source === "billingGroup" && status === "cancelled" ? "cancelled" : status

    switch (normalizedStatus) {
      case "completed":
        return (
          <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-100">
            Completed
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
            Pending
          </Badge>
        )
      case "failed":
        return <Badge variant="destructive">Failed</Badge>
      case "cancelled":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800">
            Cancelled
          </Badge>
        )
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <TrendingUp className="h-4 w-4 text-green-600" />
      case "pending":
        return <CreditCard className="h-4 w-4 text-yellow-600" />
      case "failed":
      case "cancelled":
        return <AlertCircle className="h-4 w-4 text-red-600" />
      default:
        return <CreditCard className="h-4 w-4 text-gray-600" />
    }
  }

  const getSourceBadge = (source: "permitPayment" | "billingGroup" | "manual", transactionType?: "debit" | "credit") => {
    if (source === "permitPayment") {
      return (
        <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
          <FileText className="h-3 w-3 mr-1" />
          Permit
        </Badge>
      )
    }
    if (source === "billingGroup") {
      return (
        <Badge variant="outline" className="text-xs bg-purple-50 text-purple-700 border-purple-200">
          <Layers className="h-3 w-3 mr-1" />
          Billing Group
        </Badge>
      )
    }
    return (
      <Badge variant="outline" className={`text-xs ${transactionType === "credit" ? "bg-orange-50 text-orange-700 border-orange-200" : "bg-emerald-50 text-emerald-700 border-emerald-200"}`}>
        <HandCoins className="h-3 w-3 mr-1" />
        {transactionType === "credit" ? "Credit" : "Debit"}
      </Badge>
    )
  }

  const getAmountDisplay = (amount: number, status: string, transactionType?: "debit" | "credit") => {
    const isNegative = status === "cancelled" || transactionType === "credit"
    return (
      <div className={`flex items-center gap-1 ${isNegative ? 'text-red-600' : 'text-green-600'}`}>
        {isNegative ? <TrendingDown className="h-4 w-4" /> : <TrendingUp className="h-4 w-4" />}
        <span className="font-medium">
          {isNegative ? '-' : '+'}{formatCurrency(amount)}
        </span>
      </div>
    )
  }

  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Payments & Billing</h2>
          <p className="text-muted-foreground">Track and manage all payment transactions</p>
        </div>
        <PermissionGuard resource="payments_billing" action="create" fallback={null}>
          <Button onClick={() => setIsNewTransactionModalOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            New Transaction
          </Button>
        </PermissionGuard>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(preloadedSummaryData?.totalRevenue || 0)}</div>
            <p className="text-xs text-muted-foreground">
              {preloadedSummaryData?.completedCount || 0} completed payments
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Recent Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(preloadedSummaryData?.recentRevenue || 0)}</div>
            <p className="text-xs text-muted-foreground">Last 30 days</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Payments</CardTitle>
            <CreditCard className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(preloadedSummaryData?.pendingAmount || 0)}</div>
            <p className="text-xs text-muted-foreground">
              {preloadedSummaryData?.pendingCount || 0} awaiting completion
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Cancelled/Failed</CardTitle>
            <AlertCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency((preloadedSummaryData?.cancelledAmount || 0) + (preloadedSummaryData?.failedAmount || 0))}</div>
            <p className="text-xs text-muted-foreground">
              {(preloadedSummaryData?.cancelledCount || 0) + (preloadedSummaryData?.failedCount || 0)} transactions
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Payment Transactions</CardTitle>
          <CardDescription>Complete history of all payment transactions including permits and billing groups</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by transaction ID, application, billing group, or reference..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8"
              />
            </div>
            <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as PaymentStatus)}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sourceFilter} onValueChange={(v) => setSourceFilter(v as SourceFilter)}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Source" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sources</SelectItem>
                <SelectItem value="permitPayment">Permit Payments</SelectItem>
                <SelectItem value="billingGroup">Billing Groups</SelectItem>
                <SelectItem value="manual">Manual</SelectItem>
              </SelectContent>
            </Select>
            <TableFilterPopover
              config={FILTER_CONFIG}
              filters={filters}
              onFiltersChange={setFilters}
            />
            <PermissionGuard resource="reports" action="read" fallback={null}>
              <Button
                variant="outline"
                onClick={handleExport}
                disabled={isExporting}
              >
                {isExporting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Exporting...
                  </>
                ) : (
                  <>
                    <Download className="mr-2 h-4 w-4" />
                    Export
                  </>
                )}
              </Button>
            </PermissionGuard>
          </div>

          {/* Export Progress */}
          {isExporting && (
            <div className="mb-4 p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-blue-700">
                  Exporting transactions... {exportProgress} loaded
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={cancelExport}
                  className="text-blue-700 hover:text-blue-900"
                >
                  Cancel
                </Button>
              </div>
              <Progress value={undefined} className="h-2" />
            </div>
          )}

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Transaction ID</TableHead>
                  <TableHead>Source</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Reference</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTransactions.length > 0 ? (
                  filteredTransactions.map((transaction) => (
                    <TableRow key={transaction._id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          {getStatusIcon(transaction.status)}
                          <span className="font-mono text-sm">{transaction.transactionNumber}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {getSourceBadge(transaction.source, transaction.transactionType)}
                      </TableCell>
                      <TableCell>
                        {getAmountDisplay(transaction.amount, transaction.status, transaction.transactionType)}
                      </TableCell>
                      <TableCell>{formatDate(transaction.date, "short")}</TableCell>
                      <TableCell>
                        {transaction.source === "permitPayment" ? (
                          <div className="flex items-center gap-2">
                            <div className="flex flex-col">
                              <span className="font-medium">{transaction.applicationNumber}</span>
                              {(transaction.referenceNumber || transaction.receiptNumber) && (
                                <span className="text-xs text-muted-foreground">
                                  {transaction.referenceNumber && `Ref: ${transaction.referenceNumber}`}
                                  {transaction.referenceNumber && transaction.receiptNumber && " • "}
                                  {transaction.receiptNumber && `OR: ${transaction.receiptNumber}`}
                                </span>
                              )}
                            </div>
                            {transaction.applicationId && (
                              <Link href={`/dashboard/permit-applications/assessment/${transaction.applicationId}`}>
                                <Button variant="ghost" size="sm" className="p-1 h-6 w-6">
                                  <ExternalLink className="h-3 w-3" />
                                </Button>
                              </Link>
                            )}
                          </div>
                        ) : transaction.source === "billingGroup" ? (
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-sm">{transaction.transactionNumber}</span>
                            {transaction.billingGroupId && (
                              <Link href={`/dashboard/billing-groups/${transaction.billingGroupId}`}>
                                <Button variant="ghost" size="sm" className="p-1 h-6 w-6">
                                  <ExternalLink className="h-3 w-3" />
                                </Button>
                              </Link>
                            )}
                          </div>
                        ) : (
                          <div className="flex flex-col">
                            <span className="font-mono text-sm">{transaction.transactionNumber}</span>
                            {transaction.referenceNumber && (
                              <span className="text-xs text-muted-foreground">
                                Ref: {transaction.referenceNumber}
                              </span>
                            )}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <span className="text-sm text-muted-foreground truncate max-w-[200px] block">
                          {transaction.description || "—"}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-1">
                          {getStatusBadge(transaction.status, transaction.source)}
                          {transaction.status === "cancelled" && transaction.description && (
                            <span className="text-xs text-muted-foreground max-w-[150px] truncate" title={transaction.description}>
                              {transaction.description}
                            </span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <PermissionGuard resource="payments_billing" action="update" fallback={null}>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="p-1 h-6 w-6"
                            onClick={() => setEditingTransaction(transaction)}
                            title="Edit description"
                          >
                            <Pencil className="h-3 w-3" />
                          </Button>
                        </PermissionGuard>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-6">
                      <p className="text-muted-foreground">
                        {searchQuery || statusFilter !== "all" || sourceFilter !== "all"
                          ? "No transactions found matching your search."
                          : "No payment transactions yet."}
                      </p>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>

          {/* Infinite scroll trigger */}
          {debouncedSearch.length < 2 && (
            <>
              <div ref={loadMoreRef} className="h-4" />
              {isLoadingMore && (
                <div className="flex justify-center py-4">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              )}
              {hasMore && !isLoadingMore && (
                <div className="flex justify-center py-4">
                  <Button variant="outline" onClick={loadMore}>
                    Load More
                  </Button>
                </div>
              )}
            </>
          )}

          {filteredTransactions.length > 0 && (
            <div className="text-sm text-muted-foreground mt-4 text-center">
              Showing {filteredTransactions.length}
              {debouncedSearch.length >= 2
                ? " search results"
                : hasMore
                  ? ` of ${preloadedSummaryData?.totalCount || "many"} transactions`
                  : " transactions"
              }
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modals */}
      <NewTransactionModal
        open={isNewTransactionModalOpen}
        onClose={() => setIsNewTransactionModalOpen(false)}
      />
      <EditDescriptionModal
        open={editingTransaction !== null}
        onClose={() => setEditingTransaction(null)}
        transaction={editingTransaction}
      />
    </div>
  )
}
