import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import { PlatformConfigurationClient } from "./platform-configuration-client"

/**
 * Platform Configuration Settings Page (Server Component)
 *
 * Admin interface for configuring platform-wide settings including
 * application number format, permit expiry rules, and other system configs.
 *
 * Architecture:
 * - Server-side rendering with preloaded Convex query
 * - Loading state handled by parent settings/loading.tsx skeleton
 * - Client interactions delegated to PlatformConfigurationClient component
 */
export default async function PlatformConfigurationPage() {
  const token = await convexAuthNextjsToken()

  const preloadedSettings = await preloadQuery(
    api.platformSettings.get,
    {},
    { token }
  )

  return <PlatformConfigurationClient preloadedSettings={preloadedSettings} />
}
