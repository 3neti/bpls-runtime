"use client"

import { usePreloadedQuery } from "convex/react"
import { api } from "@repo/backend/convex/_generated/api"
import { useToast } from "@/hooks/use-toast"
import { BrandingSection } from "@/components/settings/branding-section"
import { PermissionGuard } from "@/components/permission-guard"
import type { Preloaded } from "convex/react"

interface BrandingClientProps {
  preloadedSettings: Preloaded<typeof api.platformSettings.get>
  preloadedLogoUrl: Preloaded<typeof api.platformSettings.getLogoUrl>
  preloadedLandingImageUrl: Preloaded<typeof api.platformSettings.getLandingImageUrl>
  preloadedMunicipalSealUrl: Preloaded<typeof api.platformSettings.getMunicipalSealUrl>
}

export function BrandingClient({
  preloadedSettings,
  preloadedLogoUrl,
  preloadedLandingImageUrl,
  preloadedMunicipalSealUrl,
}: BrandingClientProps) {
  const { toast } = useToast()
  const settings = usePreloadedQuery(preloadedSettings)
  const logoUrl = usePreloadedQuery(preloadedLogoUrl)
  const landingImageUrl = usePreloadedQuery(preloadedLandingImageUrl)
  const municipalSealUrl = usePreloadedQuery(preloadedMunicipalSealUrl)

  return (
    <PermissionGuard resource="settings:branding" action="read" showLoading>
      <BrandingSection
        settings={settings}
        logoUrl={logoUrl}
        landingImageUrl={landingImageUrl}
        municipalSealUrl={municipalSealUrl}
        toast={toast}
      />
    </PermissionGuard>
  )
}
