"use client";

import { useState, useCallback } from "react";
import { useMutation } from "convex/react";
import { Shield, ImageIcon, Upload, Trash2, Loader2 } from "lucide-react";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import { Button } from "@repo/ui/components/button";
import { Card, CardContent } from "@repo/ui/components/card";
import { useToast } from "@/hooks/use-toast";

interface UploadedImages {
  municipalSeal?: { storageId: Id<"_storage">; url: string };
  logo?: { storageId: Id<"_storage">; url: string };
  landingImage?: { storageId: Id<"_storage">; url: string };
}

interface BrandingStepProps {
  uploadedImages: UploadedImages;
  setUploadedImages: React.Dispatch<React.SetStateAction<UploadedImages>>;
}

interface ImageUploadProps {
  title: string;
  description: string;
  imageType: keyof UploadedImages;
  currentImage?: { storageId: Id<"_storage">; url: string };
  onUpload: (storageId: Id<"_storage">, url: string) => void;
  onRemove: () => void;
  previewSize?: "small" | "large";
}

function ImageUpload({
  title,
  description,
  imageType,
  currentImage,
  onUpload,
  onRemove,
  previewSize = "small",
}: ImageUploadProps) {
  const { toast } = useToast();
  const [isUploading, setIsUploading] = useState(false);
  const generateUploadUrl = useMutation(api.platformSettings.generateUploadUrl);

  const handleFileChange = useCallback(
    async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      // Validate file type
      if (!file.type.startsWith("image/")) {
        toast({
          title: "Invalid file type",
          description: "Please upload an image file (PNG, JPG, etc.)",
          variant: "destructive",
        });
        return;
      }

      // Validate file size (5MB max)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please upload an image smaller than 5MB",
          variant: "destructive",
        });
        return;
      }

      setIsUploading(true);

      try {
        // Get upload URL from Convex
        const uploadUrl = await generateUploadUrl();

        // Upload file to Convex storage
        const response = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": file.type },
          body: file,
        });

        if (!response.ok) {
          throw new Error("Upload failed");
        }

        const { storageId } = await response.json();

        // Create a local URL for preview
        const localUrl = URL.createObjectURL(file);

        onUpload(storageId as Id<"_storage">, localUrl);

        toast({
          title: "Image uploaded",
          description: `${title} has been uploaded successfully.`,
        });
      } catch (error) {
        console.error("Upload error:", error);
        toast({
          title: "Upload failed",
          description: "There was an error uploading the image. Please try again.",
          variant: "destructive",
        });
      } finally {
        setIsUploading(false);
      }
    },
    [generateUploadUrl, onUpload, title, toast]
  );

  const getPlaceholderIcon = () => {
    switch (imageType) {
      case "municipalSeal":
        return <Shield className="h-8 w-8 text-muted-foreground" />;
      case "logo":
        return <ImageIcon className="h-8 w-8 text-muted-foreground" />;
      default:
        return <ImageIcon className="h-8 w-8 text-muted-foreground" />;
    }
  };

  return (
    <div className="flex flex-col sm:flex-row gap-4 p-4 border rounded-lg">
      {/* Preview */}
      <div className="shrink-0">
        <div
          className={`
            relative overflow-hidden rounded-lg border-2 bg-muted/50 flex items-center justify-center
            ${previewSize === "small" ? "h-24 w-24" : "h-32 w-48"}
          `}
        >
          {currentImage?.url ? (
            <img
              src={currentImage.url}
              alt={title}
              className={`
                h-full w-full
                ${previewSize === "small" ? "object-contain p-2" : "object-cover"}
              `}
            />
          ) : (
            <div className="flex flex-col items-center justify-center">
              {getPlaceholderIcon()}
              <span className="text-xs text-muted-foreground mt-1">No image</span>
            </div>
          )}
        </div>
      </div>

      {/* Info & Actions */}
      <div className="flex-1 min-w-0 space-y-3">
        <div>
          <h4 className="font-medium text-sm">{title}</h4>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>

        <div className="flex gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            disabled={isUploading}
            onClick={() => document.getElementById(`file-${imageType}`)?.click()}
          >
            {isUploading ? (
              <>
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="h-4 w-4 mr-1" />
                {currentImage ? "Replace" : "Upload"}
              </>
            )}
          </Button>

          {currentImage && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={onRemove}
              disabled={isUploading}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>

        <input
          id={`file-${imageType}`}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileChange}
        />
      </div>
    </div>
  );
}

export function BrandingStep({ uploadedImages, setUploadedImages }: BrandingStepProps) {
  const handleUpload = (
    type: keyof UploadedImages,
    storageId: Id<"_storage">,
    url: string
  ) => {
    setUploadedImages((prev) => ({
      ...prev,
      [type]: { storageId, url },
    }));
  };

  const handleRemove = (type: keyof UploadedImages) => {
    setUploadedImages((prev) => {
      const updated = { ...prev };
      delete updated[type];
      return updated;
    });
  };

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <ImageUpload
          title="Municipal Seal"
          description="Official seal displayed on permits and documents. Recommended: Square image, 200x200px minimum."
          imageType="municipalSeal"
          currentImage={uploadedImages.municipalSeal}
          onUpload={(storageId, url) => handleUpload("municipalSeal", storageId, url)}
          onRemove={() => handleRemove("municipalSeal")}
          previewSize="small"
        />

        <ImageUpload
          title="Platform Logo"
          description="Logo displayed in the sidebar and header. Recommended: Square or horizontal, transparent background."
          imageType="logo"
          currentImage={uploadedImages.logo}
          onUpload={(storageId, url) => handleUpload("logo", storageId, url)}
          onRemove={() => handleRemove("logo")}
          previewSize="small"
        />

        <ImageUpload
          title="Landing Page Image"
          description="Hero image on the login page. Recommended: 1920x1080px or larger landscape image."
          imageType="landingImage"
          currentImage={uploadedImages.landingImage}
          onUpload={(storageId, url) => handleUpload("landingImage", storageId, url)}
          onRemove={() => handleRemove("landingImage")}
          previewSize="large"
        />
      </div>

      {/* Preview */}
      <Card className="bg-muted/30">
        <CardContent className="pt-6">
          <p className="text-xs text-muted-foreground mb-3">Sidebar Preview:</p>
          <div className="w-48 bg-background rounded-lg border p-3">
            <div className="flex items-center gap-2">
              {uploadedImages.logo?.url ? (
                <img
                  src={uploadedImages.logo.url}
                  alt="Logo"
                  className="h-8 w-8 object-contain"
                />
              ) : (
                <div className="h-8 w-8 rounded bg-muted flex items-center justify-center">
                  <ImageIcon className="h-4 w-4 text-muted-foreground" />
                </div>
              )}
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold truncate">BPLS Portal</p>
                <p className="text-xs text-muted-foreground truncate">
                  Business Permit System
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground text-center">
        All images are optional. You can add or change them later in Settings.
      </p>
    </div>
  );
}
