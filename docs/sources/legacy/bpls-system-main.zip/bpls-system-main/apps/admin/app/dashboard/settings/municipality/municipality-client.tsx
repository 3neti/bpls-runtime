"use client"

import { usePreloadedQuery } from "convex/react"
import { api } from "@repo/backend/convex/_generated/api"
import { useToast } from "@/hooks/use-toast"
import { MunicipalitySection } from "@/components/settings/municipality-section"
import { PermissionGuard } from "@/components/permission-guard"
import type { Preloaded } from "convex/react"

interface MunicipalityClientProps {
  preloadedSettings: Preloaded<typeof api.platformSettings.get>
}

export function MunicipalityClient({
  preloadedSettings,
}: MunicipalityClientProps) {
  const { toast } = useToast()
  const settings = usePreloadedQuery(preloadedSettings)

  return (
    <PermissionGuard resource="settings:municipality" action="read" showLoading>
      <MunicipalitySection settings={settings} toast={toast} />
    </PermissionGuard>
  )
}
