import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Skeleton } from "@repo/ui/components/skeleton"

export default function Loading() {
  return (
    <div className="flex-1 space-y-6 p-4 pt-6">
      {/* Header Skeleton */}
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <Skeleton className="h-9 w-80" /> {/* Title */}
          <Skeleton className="h-5 w-96" /> {/* Description */}
        </div>
        <Skeleton className="h-10 w-40" /> {/* Save to Drafts button */}
      </div>

      {/* Stepper Skeleton - matches actual Stepper component structure */}
      <nav className="mb-8 flex items-center justify-center">
        <ol className="flex items-center space-x-2 md:space-x-4">
          {/* Step 1 */}
          <li className="flex items-center">
            <div className="flex flex-col items-center">
              <Skeleton className="h-8 w-8 rounded-full" />
              <div className="mt-2 text-center">
                <Skeleton className="h-4 w-28" />
                <Skeleton className="mt-1 h-3 w-32" />
              </div>
            </div>
            <Skeleton className="mx-2 h-0.5 w-8 md:w-16" />
          </li>

          {/* Step 2 */}
          <li className="flex items-center">
            <div className="flex flex-col items-center">
              <Skeleton className="h-8 w-8 rounded-full" />
              <div className="mt-2 text-center">
                <Skeleton className="h-4 w-28" />
                <Skeleton className="mt-1 h-3 w-32" />
              </div>
            </div>
            <Skeleton className="mx-2 h-0.5 w-8 md:w-16" />
          </li>

          {/* Step 3 */}
          <li className="flex items-center">
            <div className="flex flex-col items-center">
              <Skeleton className="h-8 w-8 rounded-full" />
              <div className="mt-2 text-center">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="mt-1 h-3 w-32" />
              </div>
            </div>
          </li>
        </ol>
      </nav>

      {/* Main Card Skeleton - Step 1: Business Owner Selection */}
      <Card>
        <CardHeader>
          <CardTitle>Business Owner Information</CardTitle>
          <CardDescription>Select an existing business owner or create a new one</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Selection Cards Skeleton */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Select Existing Owner Card */}
            <Card className="cursor-pointer transition-all hover:shadow-md hover:border-primary/50">
              <CardContent className="p-6 text-center">
                <div className="flex flex-col items-center space-y-4">
                  <Skeleton className="h-16 w-16 rounded-full" />
                  <div className="w-full space-y-2">
                    <Skeleton className="h-5 w-56 mx-auto" />
                    <Skeleton className="h-4 w-64 mx-auto" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Create New Owner Card */}
            <Card className="cursor-pointer transition-all hover:shadow-md hover:border-primary/50">
              <CardContent className="p-6 text-center">
                <div className="flex flex-col items-center space-y-4">
                  <Skeleton className="h-16 w-16 rounded-full" />
                  <div className="w-full space-y-2">
                    <Skeleton className="h-5 w-40 mx-auto" />
                    <Skeleton className="h-4 w-72 mx-auto" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
