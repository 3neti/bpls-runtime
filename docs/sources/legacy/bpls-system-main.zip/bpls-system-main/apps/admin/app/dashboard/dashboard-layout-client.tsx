"use client"

import type React from "react"
import { useState, useEffect } from "react"
import Link from "next/link"

import {
  Activity,
  BarChart3,
  Bell,
  User,
  Shield,
  FileText,
  Users,
  HelpCircle,
  ClipboardList,
  Settings,
  Plus,
  List,
  Search,
  Building2,
  DollarSign,
  BadgeCheck,
  MapPin,
  Layers,
  CreditCard,
  Award,
  LogOut,
  Tags,
} from "lucide-react"
import { Suspense } from "react"
import { ConvexErrorBoundary } from "@/components/convex-error-boundary"
import { usePreloadedQuery } from "convex/react"
import type { Preloaded } from "convex/react"
import { useAuthActions } from "@convex-dev/auth/react"
import { useRouter } from "next/navigation"
import { api } from "@repo/backend/convex/_generated/api"

import { Button } from "@repo/ui/components/button"
import {
  DEFAULT_LOGO_URL,
  DEFAULT_PLATFORM_SETTINGS,
} from "@/hooks/use-platform-settings"
import { ThemeToggle } from "@/components/theme-toggle"
import { NavMain } from "@/components/nav-main"
import { NavSecondary } from "@/components/nav-secondary"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@repo/ui/components/sidebar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@repo/ui/components/avatar"
import { BreadcrumbNav } from "@/components/breadcrumb-nav"
import { getInitials } from "@/lib/utils/formatting"
import { GlobalSearchPalette } from "@/components/global-search-palette"

// User type from server
interface AppUser {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  department: string;
  status: "Active" | "Inactive";
  lastLogin: string;
  profilePhoto?: string;
  tokenIdentifier?: string;
}

const navData = {
  navMain: [
    {
      title: "Dashboard",
      url: "/dashboard",
      icon: ClipboardList,
    },
    {
      title: "Permit Applications",
      url: "/dashboard/permit-applications",
      icon: FileText,
      items: [
        {
          title: "Application",
          url: "/dashboard/permit-applications/new",
          icon: Plus,
        },
        {
          title: "All Applications",
          url: "/dashboard/permit-applications",
          icon: List,
        },
        {
          title: "Assessment",
          url: "/dashboard/permit-applications/assessment",
          icon: ClipboardList,
        },
        {
          title: "Approval",
          url: "/dashboard/permit-applications/approval",
          icon: BadgeCheck,
        },
        {
          title: "Payment",
          url: "/dashboard/permit-applications/payment",
          icon: CreditCard,
        },
        {
          title: "Releasing",
          url: "/dashboard/permit-applications/released",
          icon: Search,
        },
      ],
    },
    {
      title: "Permits",
      url: "/dashboard/permits",
      icon: Award,
    },
    {
      title: "Business Owners",
      url: "/dashboard/business-owners",
      icon: Users,
    },
    {
      title: "Business Information",
      url: "/dashboard/businesses",
      icon: Building2,
    },
  ],
  navBilling: [
    {
      title: "Payments & Billing",
      url: "/dashboard/payments-billing",
      icon: DollarSign,
    },
    {
      title: "Billing Groups",
      url: "/dashboard/billing-groups",
      icon: Layers,
    },
  ],
  navReferences: [],
  navAdmin: [
    {
      title: "Reports",
      url: "/dashboard/reports",
      icon: BarChart3,
    },
    {
      title: "Clearances",
      url: "/dashboard/clearances",
      icon: BadgeCheck,
    },
    {
      title: "Activity",
      url: "/dashboard/activity",
      icon: Activity,
    },
    {
      title: "User Management",
      url: "/dashboard/user-management",
      icon: Users,
      items: [
        {
          title: "Users",
          url: "/dashboard/user-management",
          icon: User,
        },
        {
          title: "Roles",
          url: "/dashboard/user-management/roles",
          icon: Shield,
        },
      ],
    },
    {
      title: "Taxes & Fees",
      url: "/dashboard/taxes-and-fees",
      icon: Building2,
      items: [
        {
          title: "Major",
          url: "/dashboard/taxes-and-fees/major",
        },
        {
          title: "Division",
          url: "/dashboard/taxes-and-fees/division",
        },
        {
          title: "Line of Business",
          url: "/dashboard/taxes-and-fees/line-of-business",
        },
        {
          title: "Fees",
          url: "/dashboard/taxes-and-fees/fees",
        },
        {
          title: "Surcharge & Penalty",
          url: "/dashboard/taxes-and-fees/surcharge-penalty",
        },
      ],
    },
    {
      title: "Locations",
      url: "/dashboard/locations",
      icon: MapPin,
    },
    {
      title: "Business Categories",
      url: "/dashboard/business-categories",
      icon: Tags,
    },
  ],
  navSecondary: [
    {
      title: "Help & Support",
      url: "/dashboard/help",
      icon: HelpCircle,
    },
    {
      title: "Settings",
      url: "/dashboard/settings",
      icon: Settings,
    },
  ],
}

interface DashboardLayoutClientProps {
  preloadedSettings: Preloaded<typeof api.platformSettings.get>;
  preloadedLogoUrl: Preloaded<typeof api.platformSettings.getLogoUrl>;
  currentUser: AppUser;
  children: React.ReactNode;
}

export default function DashboardLayoutClient({
  preloadedSettings,
  preloadedLogoUrl,
  currentUser,
  children,
}: DashboardLayoutClientProps) {
  const settings = usePreloadedQuery(preloadedSettings);
  const logoUrl = usePreloadedQuery(preloadedLogoUrl);
  const { signOut } = useAuthActions();
  const router = useRouter();
  const [searchOpen, setSearchOpen] = useState(false);

  // Keyboard shortcut for Command Palette (Cmd+K / Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Logout handler
  const handleLogout = async () => {
    await signOut();
    router.push("/login");
  };

  // User display values
  const userName = `${currentUser.firstName} ${currentUser.lastName}`;
  const userInitials = getInitials(currentUser.firstName, currentUser.lastName);

  // Compute effective values with fallbacks
  const effectiveLogoUrl = logoUrl ?? DEFAULT_LOGO_URL;
  const platformName = settings?.platformName ?? DEFAULT_PLATFORM_SETTINGS.platformName;
  const platformTitle = settings?.platformTitle ?? DEFAULT_PLATFORM_SETTINGS.platformTitle;

  // Truncate platform title to fit in sidebar
  const truncatedTitle = platformTitle.length > 30 ? platformTitle.slice(0, 27) + "..." : platformTitle;

  return (
    <SidebarProvider>
      <Suspense fallback={null}>
        <Sidebar variant="inset">
          <SidebarHeader>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton size="lg" asChild>
                  <a href="/dashboard">
                    {effectiveLogoUrl ? (
                      <img
                        src={effectiveLogoUrl}
                        alt="Platform Logo"
                        className="size-8 object-contain"
                      />
                    ) : (
                      <div className="size-8 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Building2 className="size-5 text-primary" />
                      </div>
                    )}
                    <div className="grid flex-1 text-left text-sm leading-tight">
                      <span className="truncate font-semibold">{platformName}</span>
                      <span className="truncate text-xs">{truncatedTitle}</span>
                    </div>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarHeader>
          <SidebarContent>
            <NavMain title="Platform" items={navData.navMain} />
            <NavMain title="Billing" items={navData.navBilling} />
            <NavMain title="Admin" items={navData.navAdmin} />
          </SidebarContent>
          <SidebarFooter>
            <NavSecondary title="Support" items={navData.navSecondary} />
          </SidebarFooter>
        </Sidebar>
        <SidebarInset>
          <header className="flex h-16 shrink-0 items-center gap-2 transition-[width,height] ease-linear group-has-data-[collapsible=icon]/sidebar-wrapper:h-12">
            <div className="flex items-center gap-2 px-4">
              <SidebarTrigger className="-ml-1" />
              <div className="h-4 w-px bg-sidebar-border" />
              <BreadcrumbNav />
            </div>
            <div className="flex-1 flex justify-center px-4">
              <button
                onClick={() => setSearchOpen(true)}
                className="relative max-w-md w-full flex items-center gap-2 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 whitespace-nowrap overflow-hidden"
              >
                <Search className="h-4 w-4 text-muted-foreground shrink-0" />
                <span className="flex-1 text-left text-muted-foreground truncate">
                  Search permits, users, or documents...
                </span>
                <kbd className="pointer-events-none hidden h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground sm:flex shrink-0">
                  <span className="text-xs">⌘</span>K
                </kbd>
              </button>
              <GlobalSearchPalette open={searchOpen} onOpenChange={setSearchOpen} />
            </div>
            <div className="ml-auto flex items-center gap-2 px-4">
              <ThemeToggle />
              <Button variant="outline" size="icon">
                <Bell className="h-4 w-4" />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-auto px-2">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={currentUser.profilePhoto || "/placeholder.svg"} alt={userName} />
                        <AvatarFallback>{userInitials}</AvatarFallback>
                      </Avatar>
                      <div className="hidden md:grid text-left text-sm leading-tight">
                        <span className="truncate font-semibold">{userName}</span>
                        <span className="truncate text-xs text-muted-foreground">{currentUser.email}</span>
                      </div>
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{userName}</p>
                      <p className="text-xs leading-none text-muted-foreground">{currentUser.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard/account">
                      <User className="mr-2 h-4 w-4" />
                      Account Settings
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Bell className="mr-2 h-4 w-4" />
                    Notifications
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Log out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </header>
          <div className="flex flex-1 flex-col gap-4 p-4 pt-0">
            <ConvexErrorBoundary>
              {children}
            </ConvexErrorBoundary>
          </div>
        </SidebarInset>
      </Suspense>
    </SidebarProvider>
  )
}
