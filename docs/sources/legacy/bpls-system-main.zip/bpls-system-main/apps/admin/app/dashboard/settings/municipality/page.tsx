import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import { MunicipalityClient } from "./municipality-client"

/**
 * Municipality Settings Page (Server Component)
 *
 * Admin interface for configuring municipality information including
 * name, address, contact details, and other local government info.
 *
 * Architecture:
 * - Server-side rendering with preloaded Convex query
 * - Loading state handled by parent settings/loading.tsx skeleton
 * - Client interactions delegated to MunicipalityClient component
 */
export default async function MunicipalityPage() {
  const token = await convexAuthNextjsToken()

  const preloadedSettings = await preloadQuery(
    api.platformSettings.get,
    {},
    { token }
  )

  return <MunicipalityClient preloadedSettings={preloadedSettings} />
}
