"use client"

import { useQuery } from "convex/react"
import {
  CheckCircle2,
  XCircle,
  Building2,
  User,
  MapPin,
  Calendar,
  Hash,
  Loader2,
  ShieldCheck,
  ShieldX,
  Shield,
} from "lucide-react"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"
import { Separator } from "@repo/ui/components/separator"
import { usePlatformSettings } from "@/hooks/use-platform-settings"
import { formatDate } from "@/lib/utils/formatting"

interface VerifyClientProps {
  permitId: string
}

export function VerifyClient({ permitId }: VerifyClientProps) {
  // Get platform settings for municipality branding
  const { effectiveMunicipalSealUrl, municipalityName, municipalityShortName } = usePlatformSettings()

  // Query permit data - this returns public-safe fields
  const permit = useQuery(api.permits.getById, {
    permitId: permitId as Id<"permits">,
  })

  // Loading state
  if (permit === undefined) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="text-muted-foreground">Verifying permit...</p>
        </div>
      </div>
    )
  }

  // Not found state
  if (permit === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 h-16 w-16 rounded-full bg-red-500/10 flex items-center justify-center">
              <ShieldX className="h-8 w-8 text-red-500" />
            </div>
            <CardTitle className="text-xl">Permit Not Found</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-sm text-muted-foreground">
              The permit you are trying to verify does not exist or has been removed.
            </p>
            <p className="text-sm text-muted-foreground mt-4">
              If you believe this is an error, please contact the Municipal Business Licensing Office.
            </p>
          </CardContent>
        </Card>
      </div>
    )
  }

  const isValid = permit.isValid

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-lg mx-auto space-y-6">
        {/* Header */}
        <div className="text-center">
          {effectiveMunicipalSealUrl ? (
            <img
              src={effectiveMunicipalSealUrl}
              alt={`${municipalityShortName} Municipal Seal`}
              width={80}
              height={80}
              className="mx-auto mb-3"
            />
          ) : (
            <div className="mx-auto mb-3 h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center">
              <Shield className="h-10 w-10 text-primary" />
            </div>
          )}
          <h1 className="text-2xl font-bold">Permit Verification</h1>
          <p className="text-muted-foreground mt-1">{municipalityName ? municipalityName.replace("MUNICIPALITY OF ", "Municipality of ") : "Business Licensing"} - Business Licensing</p>
        </div>

        {/* Verification Status Card */}
        <Card className={isValid ? "border-green-500/50" : "border-red-500/50"}>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <div className={`h-20 w-20 rounded-full flex items-center justify-center ${
                isValid ? "bg-green-500/10" : "bg-red-500/10"
              }`}>
                {isValid ? (
                  <ShieldCheck className="h-10 w-10 text-green-500" />
                ) : (
                  <ShieldX className="h-10 w-10 text-red-500" />
                )}
              </div>
              <h2 className={`mt-4 text-xl font-semibold ${isValid ? "text-green-500" : "text-red-500"}`}>
                {isValid ? "Valid Permit" : permit.isExpired ? "Expired Permit" : "Invalid Permit"}
              </h2>
              <p className={`text-sm ${isValid ? "text-green-500/80" : "text-red-500/80"}`}>
                {isValid
                  ? "This Business Permit is authentic and currently valid."
                  : permit.isExpired
                    ? "This permit has expired and is no longer valid."
                    : "This permit is not in active status."}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Permit Details Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Permit Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Permit Number */}
            <div className="flex items-start gap-3">
              <Hash className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-xs text-muted-foreground">Permit Number</p>
                <p className="font-mono font-semibold">{permit.permitNumber || "—"}</p>
              </div>
            </div>

            {/* Status */}
            <div className="flex items-start gap-3">
              {isValid ? (
                <CheckCircle2 className="h-5 w-5 text-green-500 mt-0.5" />
              ) : (
                <XCircle className="h-5 w-5 text-red-500 mt-0.5" />
              )}
              <div>
                <p className="text-xs text-muted-foreground">Status</p>
                <Badge
                  variant="outline"
                  className={isValid ? "text-green-500 border-green-500/50" : "text-red-500 border-red-500/50"}
                >
                  {permit.isExpired ? "Expired" : permit.status}
                </Badge>
              </div>
            </div>

            <Separator />

            {/* Business Name */}
            <div className="flex items-start gap-3">
              <Building2 className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-xs text-muted-foreground">Business Name</p>
                <p className="font-medium">{permit.businessName}</p>
              </div>
            </div>

            {/* Owner */}
            <div className="flex items-start gap-3">
              <User className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-xs text-muted-foreground">Owner/Operator</p>
                <p className="font-medium">{permit.ownerName}</p>
              </div>
            </div>

            {/* Address */}
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-xs text-muted-foreground">Business Address</p>
                <p className="font-medium">{permit.businessAddress}</p>
              </div>
            </div>

            <Separator />

            {/* Dates */}
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-start gap-3">
                <Calendar className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-xs text-muted-foreground">Date Issued</p>
                  <p className="font-medium text-sm">
                    {permit.issuedAt ? formatDate(permit.issuedAt) : formatDate(permit.dateReleased)}
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Calendar className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-xs text-muted-foreground">Valid Until</p>
                  <p className={`font-medium text-sm ${permit.isExpired ? "text-red-500" : ""}`}>
                    {formatDate(permit.expiryDate)}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center text-xs text-muted-foreground space-y-2">
          <p>
            This verification was performed on {new Date().toLocaleDateString("en-PH", {
              year: "numeric",
              month: "long",
              day: "numeric",
              hour: "2-digit",
              minute: "2-digit",
            })}
          </p>
          <p>
            For inquiries, contact the Municipal Business Licensing Office
          </p>
        </div>
      </div>
    </div>
  )
}
