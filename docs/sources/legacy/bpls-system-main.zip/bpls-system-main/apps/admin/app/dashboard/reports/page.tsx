import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import { ReportsClient } from "./reports-client"

/**
 * Reports Management Page (Server Component)
 *
 * Interface for managing dynamic reports with configurable dimensions,
 * metrics, and filters across all BPLS resources.
 *
 * Features:
 * - View all saved reports (personal and public)
 * - Create new custom reports with the report builder
 * - Edit, duplicate, and delete saved reports
 * - Permission-based access control
 *
 * Architecture:
 * - Server-side rendering with preloaded Convex queries
 * - Loading state handled by loading.tsx skeleton
 * - Client interactions delegated to ReportsClient component
 */
export default async function ReportsPage() {
  const token = await convexAuthNextjsToken()

  // Preload saved reports on the server
  const preloadedReports = await preloadQuery(
    api.savedReports.list,
    {},
    { token }
  )

  return <ReportsClient preloadedReports={preloadedReports} />
}
