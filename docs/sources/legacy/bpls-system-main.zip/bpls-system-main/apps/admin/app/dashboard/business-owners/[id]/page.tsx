import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { ConvexError } from "convex/values"
import { api } from "@repo/backend/convex/_generated/api"
import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"
import { BusinessOwnerDetailClient } from "./business-owner-detail-client"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

interface BusinessOwnerDetailPageProps {
  params: Promise<{ id: string }>
}

export default async function BusinessOwnerDetailPage({ params }: BusinessOwnerDetailPageProps) {
  const { id } = await params
  const token = await convexAuthNextjsToken()

  try {
    // Preload business owner data server-side
    const [preloadedOwner, preloadedActivityLogs] = await Promise.all([
      preloadQuery(
        api.businessOwners.get,
        { id: id as Id<"business_owners"> },
        { token }
      ),
      preloadQuery(
        api.activityLogs.getResourceHistory,
        { resourceType: "business_owner", resourceId: id, limit: 20 },
        { token }
      ),
    ])

    return (
      <BusinessOwnerDetailClient
        preloadedOwner={preloadedOwner}
        preloadedActivityLogs={preloadedActivityLogs}
        ownerId={id as Id<"business_owners">}
      />
    )
  } catch (error) {
    // Handle permission denied errors gracefully
    if (error instanceof ConvexError) {
      const errorData = error.data as {
        code?: string
        message?: string
        details?: {
          resource?: string
          action?: string
          userRole?: string
          requiredPermission?: string
        }
      }

      if (errorData.code === "PERMISSION_DENIED") {
        return (
          <PermissionDenied
            title="Business Owner Information"
            description="View business owner details"
            message={errorData.message}
            details={errorData.details}
            resourceName="business owner"
            backLink="/dashboard/business-owners"
            backLinkText="Back to Business Owners"
          />
        )
      }

      if (errorData.code === "UNAUTHENTICATED") {
        return <AuthenticationRequired />
      }
    }

    // Re-throw other errors
    throw error
  }
}
