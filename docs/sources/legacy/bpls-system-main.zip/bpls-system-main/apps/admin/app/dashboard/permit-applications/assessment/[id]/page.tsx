import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { ConvexError } from "convex/values"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"
import { AssessmentDetailClient } from "./assessment-detail-client"

export default async function AssessmentDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const applicationId = id as Id<"business_permit_applications">
  const token = await convexAuthNextjsToken()

  try {
    const [preloadedApplication, preloadedGroups, preloadedActivityLogs] = await Promise.all([
      preloadQuery(
        api.businessPermitApplications.getById,
        { id: applicationId },
        { token }
      ),
      preloadQuery(
        api.groups.list,
        {},
        { token }
      ),
      preloadQuery(
        api.activityLogs.getResourceHistory,
        { resourceType: "permit_application", resourceId: applicationId, limit: 20 },
        { token }
      ),
    ])

    return (
      <AssessmentDetailClient
        preloadedApplication={preloadedApplication}
        preloadedGroups={preloadedGroups}
        preloadedActivityLogs={preloadedActivityLogs}
        applicationId={applicationId}
      />
    )
  } catch (error) {
    if (error instanceof ConvexError) {
      const errorData = error.data as {
        code?: string
        message?: string
        details?: {
          resource?: string
          action?: string
          userRole?: string
          requiredPermission?: string
        }
      }

      if (errorData.code === "PERMISSION_DENIED") {
        return (
          <PermissionDenied
            title="Assessment Application Details"
            description="View and assess permit application"
            message={errorData.message}
            details={errorData.details}
            resourceName="permit application"
            backLink="/dashboard/permit-applications"
            backLinkText="Back to Permit Applications"
          />
        )
      }

      if (errorData.code === "UNAUTHENTICATED") {
        return <AuthenticationRequired />
      }
    }

    throw error
  }
}
