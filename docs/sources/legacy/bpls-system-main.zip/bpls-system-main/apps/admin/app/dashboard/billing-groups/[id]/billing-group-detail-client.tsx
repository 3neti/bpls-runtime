"use client"

import { useState } from "react"
import { usePreloadedQuery, useQuery } from "convex/react"
import {
  Plus,
  Settings,
  ArrowLeft,
  FileText,
  CheckCircle,
  Clock,
  XCircle,
  Library,
  Printer,
  Check,
} from "lucide-react"
import Link from "next/link"

import { usePermissions } from "@/hooks/use-permissions"
import { PermissionGuard } from "@/components/permission-guard"
import { PermissionDenied } from "@/components/permission-error-states"
import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@repo/ui/components/tabs"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import type { Preloaded } from "convex/react"
import { formatCurrency } from "@/lib/utils"
import { FieldManager } from "@/components/billing-groups/field-manager"
import { RecordsTable } from "@/components/billing-groups/records-table"
import { createDefaultFilterState, type FilterState } from "@/components/permits/table-filter-popover"
import { RecordModal } from "@/components/billing-groups/record-modal"
import { FeeLibrary } from "@/components/billing-groups/fee-library"
import { TransactionModal } from "@/components/billing-groups/transaction-modal"
import { ReceiptTemplateEditor } from "@/components/billing-groups/receipt-template-editor"

interface BillingGroupDetailClientProps {
  billingGroupId: Id<"billing_groups">
  preloadedBillingGroup: Preloaded<typeof api.billingGroups.getById>
  preloadedSummary: Preloaded<typeof api.billingGroupRecords.getSummary>
  preloadedFees: Preloaded<typeof api.billingGroupFees.listByGroup>
}

export function BillingGroupDetailClient({
  billingGroupId,
  preloadedBillingGroup,
  preloadedSummary,
  preloadedFees,
}: BillingGroupDetailClientProps) {
  const { canCreate, canUpdate, canDelete, canRead, isLoading: permissionsLoading } = usePermissions()

  // Per-tab permission checks
  const canCreateRecords = canCreate("billing_groups:records")
  const canUpdateRecords = canUpdate("billing_groups:records")
  const canDeleteRecords = canDelete("billing_groups:records")
  const canUpdateRecordsAfterPayment = canUpdate("billing_groups:records_update_after_payment")
  const canReadLineItems = canRead("billing_groups:line_items")
  const canCreateLineItems = canCreate("billing_groups:line_items")
  const canUpdateLineItems = canUpdate("billing_groups:line_items")
  const canDeleteLineItems = canDelete("billing_groups:line_items")
  const canReadCustomFields = canRead("billing_groups:custom_fields")
  const canCreateCustomFields = canCreate("billing_groups:custom_fields")
  const canUpdateCustomFields = canUpdate("billing_groups:custom_fields")
  const canDeleteCustomFields = canDelete("billing_groups:custom_fields")
  const canReadReceipt = canRead("billing_groups:receipt")
  const canCreateReceipt = canCreate("billing_groups:receipt")
  const canUpdateReceipt = canUpdate("billing_groups:receipt")

  const [isRecordModalOpen, setIsRecordModalOpen] = useState(false)
  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false)
  const [editingRecordId, setEditingRecordId] = useState<Id<"billing_group_records"> | null>(null)
  const [activeTab, setActiveTab] = useState("records")
  const [filters, setFilters] = useState<FilterState>(createDefaultFilterState())

  // Use preloaded query data
  const billingGroup = usePreloadedQuery(preloadedBillingGroup)
  const preloadedSummaryData = usePreloadedQuery(preloadedSummary)
  const fees = usePreloadedQuery(preloadedFees)

  // Derive filter values for summary query
  const hasActiveTextFilters = filters.textFilters ? Object.values(filters.textFilters).some(v => v.trim() !== "") : false
  const hasActiveNumericFilters = filters.numericFilters ? Object.values(filters.numericFilters).some(v => v.value !== null) : false
  const hasActiveFilters = filters.statuses.length > 0 || !!filters.dateRange.from || !!filters.dateRange.to || hasActiveTextFilters || hasActiveNumericFilters
  const statusFilter = filters.statuses.length === 1
    ? filters.statuses[0] as "pending" | "completed" | "cancelled"
    : undefined
  const dateFrom = filters.dateRange.from?.toISOString().split('T')[0]
  const dateTo = filters.dateRange.to?.toISOString().split('T')[0]

  // Filtered summary query (only when filters are active)
  const filteredSummary = useQuery(
    api.billingGroupRecords.getSummary,
    hasActiveFilters ? { billingGroupId, status: statusFilter, dateFrom, dateTo } : "skip"
  )

  // Use filtered when available, otherwise preloaded
  const summary = hasActiveFilters ? (filteredSummary ?? preloadedSummaryData) : preloadedSummaryData

  const hasFees = !!(fees && fees.length > 0)
  const hasRecords = (summary?.totalCount ?? 0) > 0

  if (!billingGroup) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Billing Group Not Found</h2>
          <p className="text-muted-foreground mb-4">
            The billing group you're looking for doesn't exist or has been deleted.
          </p>
          <Link href="/dashboard/billing-groups">
            <Button>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Billing Groups
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <PermissionGuard
      resource="billing_groups:records"
      action="read"
      showLoading
      fallback={
        <PermissionDenied
          title="Billing Group Details"
          description="View and manage billing group records and settings"
          resourceName="billing group"
          backLink="/dashboard/billing-groups"
          backLinkText="Back to Billing Groups"
        />
      }
    >
    <div className="flex-1 space-y-4 p-4 pt-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/dashboard/billing-groups">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-3xl font-bold tracking-tight">{billingGroup.name}</h2>
              {!billingGroup.isActive && (
                <Badge variant="secondary">Inactive</Badge>
              )}
            </div>
            {billingGroup.description && (
              <p className="text-muted-foreground">{billingGroup.description}</p>
            )}
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Records</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summary?.totalCount || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {formatCurrency(summary?.totalRevenue || 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              {summary?.completedCount || 0} records
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {formatCurrency(summary?.pendingAmount || 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              {summary?.pendingCount || 0} records
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Cancelled</CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summary?.cancelledCount || 0}</div>
            <p className="text-xs text-muted-foreground">
              {summary?.cancelledCount || 0} records
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Onboarding Walkthrough for New Billing Groups */}
      {!hasFees && !hasRecords && (
        <Card className="overflow-hidden border-0 shadow-lg bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
          <CardHeader className="pb-2">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                <CheckCircle className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-xl">Welcome! Let&apos;s get you started</CardTitle>
                <CardDescription className="text-sm">
                  Complete these steps to set up your billing group
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              {/* Step 1 */}
              <div className="group relative">
                <div className="relative rounded-xl border bg-card p-5 transition-all hover:shadow-md hover:border-primary/30">
                  <div className="mb-4 flex items-center justify-between">
                    <div className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-semibold ${
                      billingGroup.fields.length > 0
                        ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                        : "bg-primary/10 text-primary"
                    }`}>
                      {billingGroup.fields.length > 0 ? <Check className="h-4 w-4" /> : "1"}
                    </div>
                    <Badge variant="outline" className="text-xs font-normal">Optional</Badge>
                  </div>
                  <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100 dark:bg-blue-900/30">
                    <Settings className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                  </div>
                  <h4 className="mb-1 font-semibold">Custom Fields</h4>
                  <p className="mb-4 text-sm text-muted-foreground leading-relaxed">
                    Add extra fields to capture additional transaction data
                  </p>
                  {billingGroup.fields.length === 0 ? (
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={() => setActiveTab("fields")}
                    >
                      Configure
                    </Button>
                  ) : (
                    <div className="flex items-center gap-1.5 text-sm text-green-600 dark:text-green-400">
                      <Check className="h-4 w-4" />
                      <span>{billingGroup.fields.length} field{billingGroup.fields.length !== 1 ? "s" : ""} configured</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Step 2 */}
              <div className="group relative">
                <div className="relative rounded-xl border bg-card p-5 transition-all hover:shadow-md hover:border-primary/30">
                  <div className="mb-4 flex items-center justify-between">
                    <div className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-semibold ${
                      hasFees
                        ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                        : "bg-primary/10 text-primary"
                    }`}>
                      {hasFees ? <Check className="h-4 w-4" /> : "2"}
                    </div>
                    <Badge variant="outline" className="text-xs font-normal">Recommended</Badge>
                  </div>
                  <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-purple-100 dark:bg-purple-900/30">
                    <Library className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                  </div>
                  <h4 className="mb-1 font-semibold">Line Items</h4>
                  <p className="mb-4 text-sm text-muted-foreground leading-relaxed">
                    Create fee entries with codes and default amounts
                  </p>
                  {!hasFees ? (
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={() => setActiveTab("library")}
                    >
                      Add Items
                    </Button>
                  ) : (
                    <div className="flex items-center gap-1.5 text-sm text-green-600 dark:text-green-400">
                      <Check className="h-4 w-4" />
                      <span>{fees?.length} item{fees?.length !== 1 ? "s" : ""} added</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Step 3 */}
              <div className="group relative">
                <div className="relative rounded-xl border bg-card p-5 transition-all hover:shadow-md hover:border-primary/30">
                  <div className="mb-4 flex items-center justify-between">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary text-sm font-semibold">
                      3
                    </div>
                    <Badge className="bg-primary/10 text-primary border-0 text-xs font-normal">Ready</Badge>
                  </div>
                  <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-green-100 dark:bg-green-900/30">
                    <FileText className="h-5 w-5 text-green-600 dark:text-green-400" />
                  </div>
                  <h4 className="mb-1 font-semibold">Create Transactions</h4>
                  <p className="mb-4 text-sm text-muted-foreground leading-relaxed">
                    Start creating transactions with built-in system columns
                  </p>
                  <Button
                    size="sm"
                    className="w-full"
                    onClick={() => setIsTransactionModalOpen(true)}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    New Transaction
                  </Button>
                </div>
              </div>

              {/* Step 4 */}
              <div className="group relative">
                <div className="relative rounded-xl border bg-card p-5 transition-all hover:shadow-md hover:border-primary/30">
                  <div className="mb-4 flex items-center justify-between">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted text-muted-foreground text-sm font-semibold">
                      4
                    </div>
                    <Badge variant="outline" className="text-xs font-normal">Optional</Badge>
                  </div>
                  <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-orange-100 dark:bg-orange-900/30">
                    <Printer className="h-5 w-5 text-orange-600 dark:text-orange-400" />
                  </div>
                  <h4 className="mb-1 font-semibold">Receipt Layout</h4>
                  <p className="mb-4 text-sm text-muted-foreground leading-relaxed">
                    Customize print templates for your receipts
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full"
                    onClick={() => setActiveTab("print")}
                  >
                    Customize
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tabs for Records, Library, and Field Configuration */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="records">
            <FileText className="mr-2 h-4 w-4" />
            Records ({billingGroup.recordCount})
          </TabsTrigger>
          {canReadLineItems && (
            <TabsTrigger value="library">
              <Library className="mr-2 h-4 w-4" />
              Line Items
            </TabsTrigger>
          )}
          {canReadCustomFields && (
            <TabsTrigger value="fields">
              <Settings className="mr-2 h-4 w-4" />
              Custom Fields ({billingGroup.fields.length})
            </TabsTrigger>
          )}
          {canReadReceipt && (
            <TabsTrigger value="print">
              <Printer className="mr-2 h-4 w-4" />
              Receipt
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="records">
          <RecordsTable
            fields={billingGroup.fields}
            descriptionFieldId={billingGroup.descriptionFieldId}
            billingGroupId={billingGroupId}
            billingGroupName={billingGroup.name}
            onEdit={(recordId) => setEditingRecordId(recordId)}
            onAddTransaction={() => setIsTransactionModalOpen(true)}
            canAddTransaction={canCreateRecords && !permissionsLoading}
            canEdit={canUpdateRecords && !permissionsLoading}
            canUpdateAfterPayment={canUpdateRecordsAfterPayment && !permissionsLoading}
            canDelete={canDeleteRecords && !permissionsLoading}
            filters={filters}
            onFiltersChange={setFilters}
          />
        </TabsContent>

        {canReadLineItems && (
          <TabsContent value="library">
            <FeeLibrary
              billingGroupId={billingGroupId}
              canCreate={canCreateLineItems && !permissionsLoading}
              canUpdate={canUpdateLineItems && !permissionsLoading}
              canDelete={canDeleteLineItems && !permissionsLoading}
            />
          </TabsContent>
        )}

        {canReadCustomFields && (
          <TabsContent value="fields">
            <FieldManager
              billingGroupId={billingGroupId}
              fields={billingGroup.fields}
              amountFieldId={billingGroup.amountFieldId}
              descriptionFieldId={billingGroup.descriptionFieldId}
              canCreate={canCreateCustomFields && !permissionsLoading}
              canUpdate={canUpdateCustomFields && !permissionsLoading}
              canDelete={canDeleteCustomFields && !permissionsLoading}
            />
          </TabsContent>
        )}

        {canReadReceipt && (
          <TabsContent value="print">
            <ReceiptTemplateEditor
              billingGroupId={billingGroupId}
              canCreate={canCreateReceipt && !permissionsLoading}
              canUpdate={canUpdateReceipt && !permissionsLoading}
            />
          </TabsContent>
        )}
      </Tabs>

      {/* Record Modal - for field-based records (legacy mode) */}
      <RecordModal
        open={isRecordModalOpen || (!hasFees && editingRecordId !== null)}
        onClose={() => {
          setIsRecordModalOpen(false)
          setEditingRecordId(null)
        }}
        billingGroupId={billingGroupId}
        fields={billingGroup.fields}
        editingRecordId={editingRecordId}
      />

      {/* Transaction Modal - for fee library-based transactions */}
      <TransactionModal
        open={isTransactionModalOpen || (hasFees && editingRecordId !== null)}
        onClose={() => {
          setIsTransactionModalOpen(false)
          setEditingRecordId(null)
        }}
        billingGroupId={billingGroupId}
        maxLineItems={billingGroup.maxLineItems || 11}
        editingRecordId={editingRecordId}
      />
    </div>
    </PermissionGuard>
  )
}
