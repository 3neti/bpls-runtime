import { redirect } from "next/navigation";
import { fetchQuery, preloadQuery } from "convex/nextjs";
import { api } from "@repo/backend/convex/_generated/api";
import LoginClient from "./login-client";

export default async function LoginPage() {
  // Check if platform has completed onboarding and has users
  const [isOnboarded, hasUsers] = await Promise.all([
    fetchQuery(api.platformSettings.isOnboarded, {}),
    fetchQuery(api.users.hasUsers, {}),
  ]);

  // Redirect to onboarding if not set up or no users exist
  if (!isOnboarded || !hasUsers) {
    redirect("/admin/onboarding");
  }

  // Preload all platform settings for SSR
  const [preloadedSettings, preloadedLogoUrl, preloadedLandingImageUrl] =
    await Promise.all([
      preloadQuery(api.platformSettings.get, {}),
      preloadQuery(api.platformSettings.getLogoUrl, {}),
      preloadQuery(api.platformSettings.getLandingImageUrl, {}),
    ]);

  return (
    <LoginClient
      preloadedSettings={preloadedSettings}
      preloadedLogoUrl={preloadedLogoUrl}
      preloadedLandingImageUrl={preloadedLandingImageUrl}
    />
  );
}
