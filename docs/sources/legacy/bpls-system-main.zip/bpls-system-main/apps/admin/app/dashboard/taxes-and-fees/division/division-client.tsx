"use client"

import { useState, useMemo } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { usePreloadedQuery, useMutation } from "convex/react"
import type { Preloaded } from "convex/react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { Plus, Search, Eye, Pencil, Trash2 } from "lucide-react"
import { usePermissions } from "@/hooks/use-permissions"
import { PermissionGuard } from "@/components/permission-guard"
import { PermissionDenied } from "@/components/permission-error-states"
import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Input } from "@repo/ui/components/input"
import { Checkbox } from "@repo/ui/components/checkbox"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@repo/ui/components/dialog"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"
import { Textarea } from "@repo/ui/components/textarea"
import { Label } from "@repo/ui/components/label"
import { useToast } from "@/hooks/use-toast"
import { divisionFormSchema, type DivisionFormSchema, divisionFormDefaultValues } from "@/lib/schemas/division-form"
import type { Division } from "@/lib/types/division"
import { applyToGroup } from "@repo/backend/convex/divisions"

interface DivisionClientProps {
  preloadedDivisions: Preloaded<typeof api.divisions.list>
  preloadedMajors: Preloaded<typeof api.majors.list>
  preloadedGroups: Preloaded<typeof api.groups.list>
}

export function DivisionClient({ preloadedDivisions, preloadedMajors, preloadedGroups }: DivisionClientProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const { canCreate, canUpdate, canDelete, isLoading: permissionsLoading } = usePermissions()

  // Permission checks
  const hasCreatePermission = canCreate("taxes_and_fees:division")
  const hasUpdatePermission = canUpdate("taxes_and_fees:division")
  const hasDeletePermission = canDelete("taxes_and_fees:division")

  const divisionsResult = usePreloadedQuery(preloadedDivisions)
  const divisions = divisionsResult.success ? divisionsResult.data : []

  const majorsResult = usePreloadedQuery(preloadedMajors)
  const majors = majorsResult.success ? majorsResult.data : []

  const groupsResult = usePreloadedQuery(preloadedGroups)
  const groups = groupsResult.success ? groupsResult.data : []

  const createDivision = useMutation(api.divisions.create)
  const updateDivision = useMutation(api.divisions.update)
  const deleteDivision = useMutation(api.divisions.remove)
  const applyToGroup = useMutation(api.divisions.applyToGroup)

  const [searchTerm, setSearchTerm] = useState("")
  const [filterMajor, setFilterMajor] = useState<string>("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingDivision, setEditingDivision] = useState<Division | null>(null)
  const [deletingDivisionId, setDeletingDivisionId] = useState<Id<"divisions"> | null>(null)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isApplyDialogOpen, setIsApplyDialogOpen] = useState(false)
  const [applyingDivisionId, setApplyingDivisionId] = useState<Id<"divisions"> | null>(null)
  const [selectedLineOfBusinessIds, setSelectedGroupIds] = useState<Id<"groups">[]>([])

  // Pre-select major if passed in URL params
  const preSelectedMajorId = searchParams.get("majorId")

  const form = useForm<DivisionFormSchema>({
    resolver: zodResolver(divisionFormSchema),
    defaultValues: {
      ...divisionFormDefaultValues,
      majorId: preSelectedMajorId || "",
    },
  })

  // Filter divisions by search term and major
  const filteredDivisions = useMemo(() => {
    return (divisions ?? []).filter((division: (typeof divisions)[number]) => {
      const search = searchTerm.toLowerCase()
      const matchesSearch =
        division.name.toLowerCase().includes(search) ||
        division.description?.toLowerCase().includes(search)

      const matchesMajor = filterMajor === "all" || division.majorId === filterMajor

      return matchesSearch && matchesMajor
    })
  }, [divisions, searchTerm, filterMajor])

  // Get major name for a division
  const getMajorName = (majorId: Id<"majors">) => {
    const major = (majors ?? []).find((m: (typeof majors)[number]) => m._id === majorId)
    return major?.name || "Unknown"
  }

  const handleAddDivision = async (values: DivisionFormSchema) => {
    try {
      const result = await createDivision({
        name: values.name,
        description: values.description,
        majorId: values.majorId as Id<"majors">,
      })

      if (result.success) {
        toast({
          title: "Success",
          description: `Division "${values.name}" has been created successfully.`,
        })
        setIsAddDialogOpen(false)
        form.reset(divisionFormDefaultValues)
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to create division",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to create division:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create division. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleEditDivision = async (values: DivisionFormSchema) => {
    if (!editingDivision) return

    try {
      const result = await updateDivision({
        divisionId: editingDivision._id,
        name: values.name,
        description: values.description,
        majorId: values.majorId as Id<"majors">,
      })

      if (result.success) {
        toast({
          title: "Success",
          description: `Division "${values.name}" has been updated successfully.`,
        })
        setIsAddDialogOpen(false)
        setEditingDivision(null)
        form.reset(divisionFormDefaultValues)
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to update division",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to update division:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update division. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteDivision = async () => {
    if (!deletingDivisionId) return

    try {
      const result = await deleteDivision({ divisionId: deletingDivisionId })

      if (result.success) {
        toast({
          title: "Success",
          description: "Division has been deleted successfully.",
        })
        setIsDeleteDialogOpen(false)
        setDeletingDivisionId(null)
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to delete division",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to delete division:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete division. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleApplyToLinesOfBusiness = async () => {
    if (!applyingDivisionId || selectedLineOfBusinessIds.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one line of business",
        variant: "destructive",
      })
      return
    }

    try {
      let successCount = 0
      let failureCount = 0

      for (const groupId of selectedLineOfBusinessIds) {
        const result = await applyToGroup({
          divisionId: applyingDivisionId,
          groupId: groupId,
        })

        if (result.success) {
          successCount++
        } else {
          failureCount++
        }
      }

      toast({
        title: "Division Applied",
        description: `Successfully applied to ${successCount} group(s)${failureCount > 0 ? `. ${failureCount} failed (may already be applied).` : ""}`,
      })

      setIsApplyDialogOpen(false)
      setApplyingDivisionId(null)
      setSelectedGroupIds([])
    } catch (error) {
      console.error("Failed to apply division to groups:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to apply division. Please try again.",
        variant: "destructive",
      })
    }
  }

  const openEditDialog = (division: Division) => {
    setEditingDivision(division)
    form.reset({
      name: division.name,
      description: division.description,
      majorId: division.majorId,
    })
    setIsAddDialogOpen(true)
  }

  const openDeleteDialog = (divisionId: Id<"divisions">) => {
    setDeletingDivisionId(divisionId)
    setIsDeleteDialogOpen(true)
  }

  const openApplyDialog = (divisionId: Id<"divisions">) => {
    setApplyingDivisionId(divisionId)
    setSelectedGroupIds([])
    setIsApplyDialogOpen(true)
  }

  const closeDialog = () => {
    setIsAddDialogOpen(false)
    setEditingDivision(null)
    form.reset(divisionFormDefaultValues)
  }

  const toggleGroupSelection = (lineOfBusinessId: Id<"groups">) => {
    setSelectedGroupIds((prev) =>
      prev.includes(lineOfBusinessId) ? prev.filter((id) => id !== lineOfBusinessId) : [...prev, lineOfBusinessId]
    )
  }

  return (
    <PermissionGuard
      resource="taxes_and_fees:division"
      action="read"
      showLoading
      fallback={
        <PermissionDenied
          title="Divisions"
          description="Manage divisions and their fee configurations"
          resourceName="division"
          backLink="/dashboard"
          backLinkText="Back to Dashboard"
        />
      }
    >
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Divisions</h1>
          <p className="text-muted-foreground">
            Manage divisions and their fee configurations
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={hasCreatePermission ? -1 : 0}>
                  <DialogTrigger asChild>
                    <Button onClick={closeDialog} disabled={!hasCreatePermission || permissionsLoading}>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Division
                    </Button>
                  </DialogTrigger>
                </span>
              </TooltipTrigger>
              {!hasCreatePermission && !permissionsLoading && (
                <TooltipContent>
                  <p>You don't have permission to create divisions</p>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingDivision ? "Edit Division" : "Add New Division"}</DialogTitle>
              <DialogDescription>
                {editingDivision
                  ? "Update the division details"
                  : "Create a new division under a major category"}
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form
                onSubmit={form.handleSubmit(editingDivision ? handleEditDivision : handleAddDivision)}
                className="space-y-4"
              >
                <FormField
                  control={form.control}
                  name="majorId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Major</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a major category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {(majors ?? []).map((major: (typeof majors)[number]) => (
                            <SelectItem key={major._id} value={major._id}>
                              {major.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., DNEC, ETC" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe this division..."
                          className="resize-none"
                          rows={4}
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={closeDialog}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={form.formState.isSubmitting}>
                    {form.formState.isSubmitting
                      ? editingDivision
                        ? "Updating..."
                        : "Creating..."
                      : editingDivision
                        ? "Update Division"
                        : "Create Division"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Divisions</CardTitle>
          <CardDescription>A list of all divisions in the system</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex items-center space-x-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search divisions by name or description..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterMajor} onValueChange={setFilterMajor}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filter by major" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Majors</SelectItem>
                {(majors ?? []).map((major: (typeof majors)[number]) => (
                  <SelectItem key={major._id} value={major._id}>
                    {major.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Major</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDivisions.length > 0 ? (
                  filteredDivisions.map((division: (typeof divisions)[number]) => (
                    <TableRow
                      key={division._id}
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => router.push(`/dashboard/taxes-and-fees/division/${division._id}`)}
                    >
                      <TableCell className="font-medium">{division.name}</TableCell>
                      <TableCell>{getMajorName(division.majorId)}</TableCell>
                      <TableCell className="max-w-md truncate">{division.description}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    router.push(`/dashboard/taxes-and-fees/division/${division._id}`)
                                  }}
                                >
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>View Division</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>

                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span tabIndex={hasUpdatePermission ? -1 : 0}>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    disabled={!hasUpdatePermission || permissionsLoading}
                                    onClick={(e) => {
                                      e.stopPropagation()
                                      openEditDialog(division)
                                    }}
                                  >
                                    <Pencil className="h-4 w-4" />
                                  </Button>
                                </span>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{hasUpdatePermission ? "Edit Division" : "You don't have permission to edit divisions"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>

                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span tabIndex={hasDeletePermission ? -1 : 0}>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    disabled={!hasDeletePermission || permissionsLoading}
                                    onClick={(e) => {
                                      e.stopPropagation()
                                      openDeleteDialog(division._id)
                                    }}
                                    className="text-destructive hover:text-destructive"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </span>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{hasDeletePermission ? "Delete Division" : "You don't have permission to delete divisions"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={4} className="h-24 text-center">
                      {searchTerm || filterMajor !== "all"
                        ? "No divisions found matching your filters."
                        : "No divisions yet. Click 'Add Division' to get started."}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Apply to Lines of Business Dialog */}
      <Dialog open={isApplyDialogOpen} onOpenChange={setIsApplyDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Apply Division to Groups</DialogTitle>
            <DialogDescription>
              Select groups to inherit fees from this division
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 max-h-[400px] overflow-y-auto">
            <Label>Select Groups</Label>
            {(groups ?? []).length > 0 ? (
              <div className="space-y-2">
                {(groups ?? []).map((group: (typeof groups)[number]) => (
                  <div key={group._id} className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted/50">
                    <Checkbox
                      id={group._id}
                      checked={selectedLineOfBusinessIds.includes(group._id)}
                      onCheckedChange={() => toggleGroupSelection(group._id)}
                    />
                    <label
                      htmlFor={group._id}
                      className="flex-1 cursor-pointer text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      <div>{group.name}</div>
                      <div className="text-xs text-muted-foreground">{group.description}</div>
                    </label>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No groups available. Create groups first.</p>
            )}
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsApplyDialogOpen(false)
                setApplyingDivisionId(null)
                setSelectedGroupIds([])
              }}
            >
              Cancel
            </Button>
            <Button onClick={handleApplyToLinesOfBusiness} disabled={selectedLineOfBusinessIds.length === 0}>
              Apply to {selectedLineOfBusinessIds.length} Group(s)
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Division</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this division? This action cannot be undone. All associated fees and group applications will also be removed.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsDeleteDialogOpen(false)
                setDeletingDivisionId(null)
              }}
            >
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteDivision}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
    </PermissionGuard>
  )
}
