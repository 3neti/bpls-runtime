import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import { BrandingClient } from "./branding-client"

/**
 * Branding Settings Page (Server Component)
 *
 * Admin interface for configuring platform branding including
 * logo, landing page image, municipal seal, and color schemes.
 *
 * Architecture:
 * - Server-side rendering with preloaded Convex queries
 * - Loading state handled by parent settings/loading.tsx skeleton
 * - Client interactions delegated to BrandingClient component
 */
export default async function BrandingPage() {
  const token = await convexAuthNextjsToken()

  // Preload settings and all image URLs on the server
  const [
    preloadedSettings,
    preloadedLogoUrl,
    preloadedLandingImageUrl,
    preloadedMunicipalSealUrl,
  ] = await Promise.all([
    preloadQuery(api.platformSettings.get, {}, { token }),
    preloadQuery(api.platformSettings.getLogoUrl, {}, { token }),
    preloadQuery(api.platformSettings.getLandingImageUrl, {}, { token }),
    preloadQuery(api.platformSettings.getMunicipalSealUrl, {}, { token }),
  ])

  return (
    <BrandingClient
      preloadedSettings={preloadedSettings}
      preloadedLogoUrl={preloadedLogoUrl}
      preloadedLandingImageUrl={preloadedLandingImageUrl}
      preloadedMunicipalSealUrl={preloadedMunicipalSealUrl}
    />
  )
}
