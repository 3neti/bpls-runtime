"use client"

import { useState, useEffect, useMemo } from "react"
import Link from "next/link"
import { usePreloadedQuery, useQuery, useMutation } from "convex/react"
import { PDFDownloadLink, PDFViewer } from "@react-pdf/renderer"
import QRCode from "qrcode"

import { Button } from "@repo/ui/components/button"
import { Input } from "@repo/ui/components/input"
import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"
import { Separator } from "@repo/ui/components/separator"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import {
  ArrowLeft,
  Loader2,
  Award,
  Calendar,
  FileText,
  CheckCircle2,
  XCircle,
  Download,
  Eye,
  ExternalLink,
  Pencil,
  Check,
  X,
  AlertCircle,
} from "lucide-react"

import { useToast } from "@/hooks/use-toast"
import { usePermissions } from "@/hooks/use-permissions"

import { BusinessOwnerCard } from "@/components/permit/business-owner-card"
import { BusinessInfoCard } from "@/components/permit/business-info-card"
import { MayorsPermitDocument, type MayorsPermitData, type PermitLayoutConfig } from "@/components/permit/mayors-permit-document"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import type { Preloaded } from "convex/react"
import { formatDate } from "@/lib/utils/formatting"

interface PermitDetailClientProps {
  preloadedPermit: Preloaded<typeof api.permits.getPermitWithFullDetails>
  permitId: Id<"permits">
}

export function PermitDetailClient({
  preloadedPermit,
  permitId,
}: PermitDetailClientProps) {
  const permitData = usePreloadedQuery(preloadedPermit)
  const { toast } = useToast()
  const { canUpdate, isLoading: permissionsLoading } = usePermissions()
  const canEditPermit = canUpdate("permits")

  const [isClient, setIsClient] = useState(false)
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>("")
  const [showPdfPreview, setShowPdfPreview] = useState(false)

  // Edit permit number state
  const [isEditingPermitNumber, setIsEditingPermitNumber] = useState(false)
  const [editPermitNumber, setEditPermitNumber] = useState("")
  const [editPermitError, setEditPermitError] = useState("")
  const [isSavingPermitNumber, setIsSavingPermitNumber] = useState(false)

  // Mutations
  const updatePermitNumber = useMutation(api.permits.updatePermitNumber)

  // Check permit number availability for editing
  const permitNumberCheck = useQuery(
    api.permits.checkPermitNumberAvailability,
    isEditingPermitNumber && editPermitNumber.trim()
      ? { permitNumber: editPermitNumber.trim(), excludePermitId: permitId }
      : "skip"
  )

  // Update error based on availability check
  useEffect(() => {
    if (isEditingPermitNumber && permitNumberCheck) {
      if (!permitNumberCheck.available) {
        setEditPermitError("This permit number is already in use")
      } else {
        setEditPermitError("")
      }
    }
  }, [permitNumberCheck, isEditingPermitNumber])

  const handleStartEditPermitNumber = () => {
    setEditPermitNumber(permitData?.permitNumber || "")
    setEditPermitError("")
    setIsEditingPermitNumber(true)
  }

  const handleCancelEditPermitNumber = () => {
    setIsEditingPermitNumber(false)
    setEditPermitNumber("")
    setEditPermitError("")
  }

  const handleSavePermitNumber = async () => {
    if (!editPermitNumber.trim()) {
      setEditPermitError("Permit number is required")
      return
    }
    if (editPermitError) return

    setIsSavingPermitNumber(true)
    try {
      await updatePermitNumber({
        permitId,
        permitNumber: editPermitNumber.trim(),
      })
      toast({
        title: "Permit Number Updated",
        description: `Permit number changed to ${editPermitNumber.trim()}`,
      })
      setIsEditingPermitNumber(false)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update permit number",
        variant: "destructive",
      })
    } finally {
      setIsSavingPermitNumber(false)
    }
  }

  // Client-side detection
  useEffect(() => {
    setIsClient(true)
  }, [])

  // Query location names for business
  const businessLocationData = useQuery(
    api.locations.getLocationHierarchy,
    permitData?.business?.provinceId
      ? {
          provinceId: permitData.business.provinceId,
          cityId: permitData.business.cityId,
          barangayId: permitData.business.barangayId,
        }
      : "skip"
  )

  // Query location names for business owner
  const ownerLocationData = useQuery(
    api.locations.getLocationHierarchy,
    permitData?.owner?.provinceId
      ? {
          provinceId: permitData.owner.provinceId,
          cityId: permitData.owner.cityId,
          barangayId: permitData.owner.barangayId,
        }
      : "skip"
  )

  // Fetch permit layout configuration for PDF generation
  const permitLayout = useQuery(api.permitLayouts.get)
  const backgroundImageUrl = useQuery(api.permitLayouts.getBackgroundImageUrl)

  // Fetch platform settings for municipality info
  const platformSettings = useQuery(api.platformSettings.get)

  // Build location strings
  const buildLocationString = (locationData: typeof businessLocationData) => {
    if (!locationData) return undefined
    const parts = [
      locationData.barangay?.name,
      locationData.city?.name,
      locationData.province?.name,
    ].filter(Boolean)
    return parts.length > 0 ? parts.join(", ") : undefined
  }

  // Generate verification URL
  const verificationUrl = useMemo(() => {
    let baseUrl = ""
    if (typeof window !== "undefined") {
      baseUrl = window.location.origin
    } else if (process.env.NEXT_PUBLIC_APP_URL) {
      baseUrl = process.env.NEXT_PUBLIC_APP_URL
    }
    return `${baseUrl}/permits/verify/${permitId}`
  }, [permitId])

  // Generate permit data for PDF with extended fields for dynamic layout
  const pdfPermitData: MayorsPermitData | null = useMemo(() => {
    if (!permitData || !permitData.business || !permitData.owner) return null

    const ownerName = `${permitData.owner.firstName} ${
      permitData.owner.middleName ? permitData.owner.middleName + " " : ""
    }${permitData.owner.lastName}`

    const businessAddress = permitData.business.address || buildLocationString(businessLocationData) || ""
    const ownerAddress = permitData.owner.address || buildLocationString(ownerLocationData) || ""

    // Extract lines of business names
    const linesOfBusiness = permitData.application?.linesOfBusiness?.map(
      (lob: { businessCategory: string }) => lob.businessCategory
        .split("-")
        .map((word: string) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ")
    ) || []

    return {
      businessName: permitData.business.name,
      ownerName,
      businessAddress,
      businessProvince: businessLocationData?.province?.name || "",
      businessCityMunicipality: businessLocationData?.city?.name || "",
      businessBarangay: businessLocationData?.barangay?.name || "",
      permitNumber: permitData.permitNumber || "",
      dateIssued: permitData.issuedAt || "",
      expirationDate: permitData.expiryDate || "",
      qrCodeDataUrl,
      applicationNumber: permitData.application?.applicationNumber || "",
      orNumber: permitData.firstOrNumber || "",
      // Extended fields for dynamic layout
      businessTIN: permitData.business.tin || "",
      businessEmail: permitData.business.email || "",
      businessContactNumber: permitData.business.contactNumber || "",
      ownershipType: permitData.business.ownershipType || "",
      dateStarted: permitData.business.dateStarted || "",
      registrationNumber: permitData.business.registrationNumber || "",
      ownerAddress,
      ownerContactNumber: permitData.owner.mobile || "",
      ownerEmail: permitData.owner.email || "",
      linesOfBusiness,
      // Platform settings
      municipalityName: platformSettings?.municipalityName || "",
      mayorName: platformSettings?.mayorName || "",
      mayorTitle: platformSettings?.mayorTitle || "Municipal Mayor",
      provinceName: platformSettings?.provinceName || "",
      fullAddress: platformSettings?.fullAddress || "",
      treasurerName: platformSettings?.treasurerName || "",
    }
  }, [permitData, qrCodeDataUrl, businessLocationData, ownerLocationData, platformSettings])

  // Build layout config from permit layout
  const layoutConfig: PermitLayoutConfig | null = useMemo(() => {
    if (!permitLayout) return null

    return {
      paperSize: permitLayout.paperSize,
      orientation: permitLayout.orientation,
      marginTop: permitLayout.marginTop,
      marginRight: permitLayout.marginRight,
      marginBottom: permitLayout.marginBottom,
      marginLeft: permitLayout.marginLeft,
      headerTemplate: permitLayout.headerTemplate,
      bodyTemplate: permitLayout.bodyTemplate,
      footerTemplate: permitLayout.footerTemplate,
      qrCodeSize: permitLayout.qrCodeSize,
      logoUrl: undefined,
      sealUrl: undefined,
      backgroundImageUrl: backgroundImageUrl ?? undefined,
      backgroundImageOpacity: permitLayout.backgroundImageOpacity,
      backgroundImageWidth: permitLayout.backgroundImageWidth,
      backgroundImageHeight: permitLayout.backgroundImageHeight,
    }
  }, [permitLayout, backgroundImageUrl])

  // Generate QR code
  useEffect(() => {
    if (isClient && verificationUrl) {
      QRCode.toDataURL(verificationUrl, {
        width: 200,
        margin: 1,
        color: { dark: "#000000", light: "#ffffff" },
      })
        .then((url) => setQrCodeDataUrl(url))
        .catch((err) => console.error("QR Code generation failed:", err))
    }
  }, [isClient, verificationUrl])

  const handleViewVerificationUrl = () => {
    window.open(verificationUrl, "_blank")
  }

  // Loading state
  if (permitData === undefined) {
    return (
      <div className="flex-1 flex items-center justify-center p-4 pt-6">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading permit details...</p>
        </div>
      </div>
    )
  }

  // Not found state
  if (!permitData) {
    return (
      <div className="flex-1 space-y-4 p-4 pt-6">
        <div className="flex items-center gap-4">
          <Link href="/dashboard/permits">
            <Button variant="outline" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Permits
            </Button>
          </Link>
        </div>
        <Card>
          <CardContent className="flex items-center justify-center py-8">
            <div className="text-center">
              <h3 className="text-lg font-semibold">Permit Not Found</h3>
              <p className="text-muted-foreground">
                The permit with ID &quot;{permitId}&quot; could not be found.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Transform permit data to match component expectations
  const owner = permitData.owner
    ? {
        profilePhoto: permitData.owner.avatar || "/government-official-male.jpg",
        firstName: permitData.owner.firstName,
        middleName: permitData.owner.middleName || "",
        lastName: permitData.owner.lastName,
        fullName: `${permitData.owner.firstName} ${
          permitData.owner.middleName ? permitData.owner.middleName + " " : ""
        }${permitData.owner.lastName}`,
        birthDate: permitData.owner.birthDate,
        civilStatus: permitData.owner.civilStatus,
        gender: permitData.owner.gender,
        citizenship: permitData.owner.citizenship,
        tin: permitData.owner.tin,
        mobile: permitData.owner.mobile,
        email: permitData.owner.email,
        address:
          permitData.owner.address ||
          buildLocationString(ownerLocationData) ||
          "",
        provinceId: permitData.owner.provinceId,
        cityId: permitData.owner.cityId,
        barangayId: permitData.owner.barangayId,
        // New fields for link and owner details
        ownerId: permitData.owner._id,
        ownerType: permitData.owner.ownerType,
        groupName: permitData.owner.groupName,
      }
    : null

  const business = permitData.business
    ? {
        name: permitData.business.name,
        dateEstablished: permitData.business.establishedDate,
        ownershipType: permitData.business.ownershipType,
        occupancy: permitData.business.occupancy,
        permitPaymentCadence: permitData.business.permitPaymentCadence,
        maleEmployeeCount: permitData.business.maleEmployeeCount,
        femaleEmployeeCount: permitData.business.femaleEmployeeCount,
        contactNumber: permitData.business.contactNumber,
        email: permitData.business.email,
        address:
          permitData.business.address ||
          buildLocationString(businessLocationData) ||
          "",
        provinceId: permitData.business.provinceId,
        cityId: permitData.business.cityId,
        barangayId: permitData.business.barangayId,
        linesOfBusiness: permitData.application?.linesOfBusiness?.map(
          (lob: any, index: number) => ({
            id: String(index + 1),
            businessCategory: lob.businessCategory,
            categoryName: lob.businessCategory
              .split("-")
              .map(
                (word: string) =>
                  word.charAt(0).toUpperCase() + word.slice(1)
              )
              .join(" "),
            capitalInvestment: lob.capitalInvestment,
            grossSales: lob.grossSales || "",
            businessAnnualRevenue: lob.businessAnnualRevenue,
            permitApplicationType: lob.permitApplicationType,
          })
        ) || [],
        // New fields for link and business details
        businessId: permitData.business._id,
        registrationNumber: permitData.business.registrationNumber,
        registrationDate: permitData.business.registrationDate,
        propertyIndexNumber: permitData.business.propertyIndexNumber,
        businessScale: permitData.business.businessScale,
        annualRevenue: permitData.business.annualRevenue ? Number(permitData.business.annualRevenue) : undefined,
        dateStarted: permitData.business.dateStarted,
        businessArea: permitData.business.businessArea,
      }
    : null

  // Get status badge styling
  const getStatusBadge = () => {
    if (permitData.isExpired) {
      return (
        <Badge variant="destructive" className="text-sm">
          <XCircle className="mr-1 h-3 w-3" />
          Expired
        </Badge>
      )
    }

    if (permitData.isValid) {
      return (
        <Badge className="bg-green-100 text-green-800 text-sm">
          <CheckCircle2 className="mr-1 h-3 w-3" />
          Active
        </Badge>
      )
    }

    return (
      <Badge variant="secondary" className="text-sm">
        {permitData.status}
      </Badge>
    )
  }

  // PDF Preview view
  if (showPdfPreview && pdfPermitData) {
    return (
      <div className="flex-1 flex flex-col p-4 pt-6 h-[calc(100vh-4rem)]">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm" onClick={() => setShowPdfPreview(false)}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Details
            </Button>
            <h2 className="text-lg font-semibold">Business Permit - PDF Preview</h2>
          </div>
          <div className="flex items-center gap-2">
            {isClient && qrCodeDataUrl && (
              <PDFDownloadLink
                document={<MayorsPermitDocument data={pdfPermitData} layout={layoutConfig} />}
                fileName={`business-permit-${pdfPermitData.permitNumber}.pdf`}
              >
                {({ loading }) => (
                  <Button variant="outline" size="sm" disabled={loading}>
                    {loading ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Download className="mr-2 h-4 w-4" />
                    )}
                    {loading ? "Preparing..." : "Download PDF"}
                  </Button>
                )}
              </PDFDownloadLink>
            )}
          </div>
        </div>

        {/* PDF Viewer */}
        <div className="flex-1 border rounded-lg overflow-hidden">
          {isClient && qrCodeDataUrl ? (
            <PDFViewer width="100%" height="100%" showToolbar={true}>
              <MayorsPermitDocument data={pdfPermitData} layout={layoutConfig} />
            </PDFViewer>
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="flex-1 space-y-6 p-4 pt-6">
      {/* Header with Back Button */}
      <div className="flex items-center gap-4">
        <Link href="/dashboard/permits">
          <Button variant="outline" size="sm">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Permits
          </Button>
        </Link>
      </div>

      {/* Permit Title */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-3">
          <Award className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-2xl font-bold tracking-tight">
              {permitData.permitNumber || "Business Permit"}
            </h1>
            <p className="text-muted-foreground">
              Business Permit • Issued {formatDate(permitData.issuedAt)} •
              Expires {formatDate(permitData.expiryDate)}
            </p>
          </div>
          <div className="ml-auto">{getStatusBadge()}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content - 2 columns */}
        <div className="lg:col-span-2 space-y-6">
          {/* Business Owner Card */}
          {owner && <BusinessOwnerCard owner={owner} />}

          {/* Business Info Card */}
          {business && (
            <BusinessInfoCard business={business} hideFeesSection={true} />
          )}
        </div>

        {/* Sidebar - 1 column */}
        <div className="space-y-6">
          {/* Permit Info Card */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Permit Information
                </CardTitle>
                <TooltipProvider>
                  <div className="flex items-center gap-1">
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => setShowPdfPreview(true)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>View PDF</p>
                      </TooltipContent>
                    </Tooltip>
                    {isClient && qrCodeDataUrl && pdfPermitData && (
                      <PDFDownloadLink
                        document={<MayorsPermitDocument data={pdfPermitData} layout={layoutConfig} />}
                        fileName={`business-permit-${pdfPermitData.permitNumber}.pdf`}
                      >
                        {({ loading }) => (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                disabled={loading}
                              >
                                {loading ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  <Download className="h-4 w-4" />
                                )}
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{loading ? "Preparing..." : "Download PDF"}</p>
                            </TooltipContent>
                          </Tooltip>
                        )}
                      </PDFDownloadLink>
                    )}
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={handleViewVerificationUrl}
                        >
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>View Verification URL</p>
                      </TooltipContent>
                    </Tooltip>
                  </div>
                </TooltipProvider>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between items-start">
                  <span className="text-sm text-muted-foreground">
                    Permit Number
                  </span>
                  {isEditingPermitNumber ? (
                    <div className="flex flex-col items-end gap-1 max-w-[200px]">
                      <div className="flex items-center gap-1">
                        <Input
                          value={editPermitNumber}
                          onChange={(e) => {
                            setEditPermitNumber(e.target.value)
                            if (!e.target.value.trim()) {
                              setEditPermitError("Permit number is required")
                            }
                          }}
                          className={`h-7 text-sm font-mono w-[160px] ${editPermitError ? "border-destructive" : ""}`}
                          autoFocus
                          onKeyDown={(e) => {
                            if (e.key === "Enter") handleSavePermitNumber()
                            if (e.key === "Escape") handleCancelEditPermitNumber()
                          }}
                        />
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={handleSavePermitNumber}
                          disabled={isSavingPermitNumber || !!editPermitError || !editPermitNumber.trim()}
                        >
                          {isSavingPermitNumber ? (
                            <Loader2 className="h-3 w-3 animate-spin" />
                          ) : (
                            <Check className="h-3 w-3 text-green-600" />
                          )}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={handleCancelEditPermitNumber}
                          disabled={isSavingPermitNumber}
                        >
                          <X className="h-3 w-3 text-muted-foreground" />
                        </Button>
                      </div>
                      {editPermitError && (
                        <p className="text-xs text-destructive flex items-center gap-1">
                          <AlertCircle className="h-3 w-3" />
                          {editPermitError}
                        </p>
                      )}
                      {editPermitNumber.trim() && !editPermitError && permitNumberCheck?.available && (
                        <p className="text-xs text-green-600 flex items-center gap-1">
                          <CheckCircle2 className="h-3 w-3" />
                          Available
                        </p>
                      )}
                    </div>
                  ) : (
                    <div className="flex items-center gap-1">
                      <span className="text-sm font-medium font-mono">
                        {permitData.permitNumber || "—"}
                      </span>
                      {canEditPermit && !permissionsLoading && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={handleStartEditPermitNumber}
                        >
                          <Pencil className="h-3 w-3 text-muted-foreground" />
                        </Button>
                      )}
                    </div>
                  )}
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Status</span>
                  {getStatusBadge()}
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">
                    Issued Date
                  </span>
                  <span className="text-sm font-medium flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {formatDate(permitData.issuedAt)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">
                    Expiry Date
                  </span>
                  <span className="text-sm font-medium flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {formatDate(permitData.expiryDate)}
                  </span>
                </div>
                {permitData.issuedBy && (
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">
                      Issued By
                    </span>
                    <span className="text-sm font-medium">
                      {permitData.issuedBy}
                    </span>
                  </div>
                )}
              </div>

              {/* QR Code */}
              {qrCodeDataUrl && (
                <>
                  <Separator />
                  <div className="flex justify-center">
                    <div className="text-center">
                      <img
                        src={qrCodeDataUrl}
                        alt="Verification QR Code"
                        className="w-24 h-24 mx-auto"
                      />
                      <p className="text-xs text-muted-foreground mt-2">
                        Scan to verify permit
                      </p>
                    </div>
                  </div>
                </>
              )}

              <Separator />

              {/* Validity indicator */}
              <div
                className={`p-3 rounded-lg ${
                  permitData.isValid
                    ? "bg-green-50 text-green-700"
                    : "bg-red-50 text-red-700"
                }`}
              >
                <div className="flex items-center gap-2 text-sm font-medium">
                  {permitData.isValid ? (
                    <>
                      <CheckCircle2 className="h-4 w-4" />
                      This permit is currently valid
                    </>
                  ) : (
                    <>
                      <XCircle className="h-4 w-4" />
                      This permit has expired
                    </>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Application Reference Card */}
          {permitData.application && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Source Application
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">
                      Application Number
                    </span>
                    <span className="text-sm font-medium font-mono">
                      {permitData.application.applicationNumber}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">
                      Status
                    </span>
                    <Badge variant="default" className="bg-green-100 text-green-800">
                      {permitData.application.status}
                    </Badge>
                  </div>
                </div>

                <Link
                  href={`/dashboard/permit-applications/released/${permitData.application._id}`}
                >
                  <Button variant="outline" className="w-full">
                    <FileText className="mr-2 h-4 w-4" />
                    View Application
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
