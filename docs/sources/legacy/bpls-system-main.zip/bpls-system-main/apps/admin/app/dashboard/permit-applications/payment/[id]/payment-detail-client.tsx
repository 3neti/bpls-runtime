"use client";

import type { Preloaded } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import { PermitDetailView } from "@/components/permit/permit-detail-view";

interface PaymentDetailClientProps {
  preloadedApplication: Preloaded<typeof api.businessPermitApplications.getById>;
  preloadedGroups: Preloaded<typeof api.groups.list>;
  preloadedActivityLogs: Preloaded<typeof api.activityLogs.getResourceHistory>;
  applicationId: Id<"business_permit_applications">;
}

export function PaymentDetailClient({
  preloadedApplication,
  preloadedGroups,
  preloadedActivityLogs,
  applicationId,
}: PaymentDetailClientProps) {
  return (
    <PermitDetailView
      preloadedApplication={preloadedApplication}
      preloadedGroups={preloadedGroups}
      preloadedActivityLogs={preloadedActivityLogs}
      applicationId={applicationId}
      mode="payment"
    />
  );
}
