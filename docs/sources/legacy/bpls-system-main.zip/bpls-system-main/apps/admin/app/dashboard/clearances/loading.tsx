import { Skeleton } from "@repo/ui/components/skeleton"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"

/**
 * Loading Skeleton for Clearances Management Page
 *
 * Matches the layout of the clearances page with:
 * - Header skeleton (title, description, button)
 * - Table skeleton with columns: Icon, Name, Description, Status, Created, Actions
 */
export default function ClearancesLoading() {
  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      {/* Header Skeleton */}
      <div className="flex items-center justify-between space-y-2">
        <div className="space-y-2">
          <Skeleton className="h-9 w-[200px]" /> {/* Title */}
          <Skeleton className="h-4 w-[380px]" /> {/* Description */}
        </div>
        <Skeleton className="h-10 w-[140px]" /> {/* Add Clearance button */}
      </div>

      {/* Table Toolbar Skeleton */}
      <div className="flex items-center justify-between py-4">
        <Skeleton className="h-10 w-[250px]" /> {/* Search input */}
        <Skeleton className="h-10 w-[100px]" /> {/* View options */}
      </div>

      {/* Table Skeleton */}
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[60px]"></TableHead> {/* Icon */}
              <TableHead>
                <Skeleton className="h-4 w-[120px]" />
              </TableHead> {/* Clearance Name */}
              <TableHead>
                <Skeleton className="h-4 w-[90px]" />
              </TableHead> {/* Description */}
              <TableHead>
                <Skeleton className="h-4 w-[50px]" />
              </TableHead> {/* Status */}
              <TableHead>
                <Skeleton className="h-4 w-[60px]" />
              </TableHead> {/* Created */}
              <TableHead>
                <Skeleton className="h-4 w-[60px]" />
              </TableHead> {/* Actions */}
            </TableRow>
          </TableHeader>
          <TableBody>
            {Array.from({ length: 8 }).map((_, i) => (
              <TableRow key={i}>
                {/* Icon */}
                <TableCell>
                  <Skeleton className="h-9 w-9 rounded-lg" />
                </TableCell>
                {/* Clearance Name */}
                <TableCell>
                  <Skeleton className="h-5 w-[180px]" />
                </TableCell>
                {/* Description */}
                <TableCell>
                  <Skeleton className="h-4 w-[250px]" />
                </TableCell>
                {/* Status */}
                <TableCell>
                  <Skeleton className="h-6 w-[60px] rounded-full" />
                </TableCell>
                {/* Created */}
                <TableCell>
                  <Skeleton className="h-4 w-[90px]" />
                </TableCell>
                {/* Actions */}
                <TableCell>
                  <div className="flex items-center gap-1">
                    <Skeleton className="h-8 w-8 rounded-md" />
                    <Skeleton className="h-8 w-8 rounded-md" />
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Pagination Skeleton */}
      <div className="flex items-center justify-between">
        <Skeleton className="h-4 w-[180px]" /> {/* Row count text */}
        <div className="flex items-center gap-2">
          <Skeleton className="h-8 w-8 rounded-md" />
          <Skeleton className="h-8 w-8 rounded-md" />
          <Skeleton className="h-8 w-8 rounded-md" />
          <Skeleton className="h-8 w-8 rounded-md" />
        </div>
      </div>
    </div>
  )
}
