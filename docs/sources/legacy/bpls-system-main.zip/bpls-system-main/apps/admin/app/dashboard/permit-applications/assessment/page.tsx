import { preloadQuery, fetchQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { ConvexError } from "convex/values"
import { api } from "@repo/backend/convex/_generated/api"
import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"
import { AssessmentClient } from "./assessment-client"

export default async function AssessmentPage() {
  const token = await convexAuthNextjsToken()

  try {
    // Check if user has permission to view assessment page
    const hasAssessmentPermission = await fetchQuery(
      api.permissions.hasPermission,
      { resource: "permit_applications:assessment", action: "read" },
      { token }
    )

    // If user doesn't have permission, show permission denied
    if (!hasAssessmentPermission) {
      return (
        <PermissionDenied
          title="Assessment"
          description="View permit applications for assessment"
          message="You don't have permission to view the assessment page"
          details={{
            resource: "permit_applications:assessment",
            action: "read",
            requiredPermission: "permit_applications:assessment:read",
          }}
          resourceName="assessment page"
          backLink="/dashboard/permit-applications"
          backLinkText="Back to Permit Applications"
        />
      )
    }

    // Preload only Assessment status applications (Pending Payment now has its own page)
    const preloadedApplications = await preloadQuery(
      api.businessPermitApplications.listByStatuses,
      { statuses: ["Assessment"] },
      { token }
    )

    return <AssessmentClient preloadedApplications={preloadedApplications} />
  } catch (error) {
    if (error instanceof ConvexError) {
      const errorData = error.data as {
        code?: string
        message?: string
        details?: {
          resource?: string
          action?: string
          userRole?: string
          requiredPermission?: string
        }
      }

      if (errorData.code === "PERMISSION_DENIED") {
        return (
          <PermissionDenied
            title="Assessment"
            description="View permit applications for assessment"
            message={errorData.message}
            details={errorData.details}
            resourceName="assessment page"
            backLink="/dashboard/permit-applications"
            backLinkText="Back to Permit Applications"
          />
        )
      }

      if (errorData.code === "UNAUTHENTICATED") {
        return <AuthenticationRequired />
      }
    }

    throw error
  }
}
