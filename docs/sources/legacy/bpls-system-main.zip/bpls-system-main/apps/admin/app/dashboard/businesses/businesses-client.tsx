"use client"

import { useState, useMemo, useCallback } from "react"
import { useRouter } from "next/navigation"
import { usePreloadedQuery, useMutation, useQuery } from "convex/react"
import type { Preloaded } from "convex/react"
import { Plus, Building2, Lock, ChevronLeft, ChevronRight, Loader2 } from "lucide-react"

import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@repo/ui/components/tooltip"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import { createBusinessColumns } from "@/components/businesses/columns"
import { DataTable } from "@/components/businesses/data-table"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { usePermissions } from "@/hooks/use-permissions"
import { useToast } from "@/hooks/use-toast"

// Page size constant - should match server component
const PAGE_SIZE = 20

interface BusinessesClientProps {
  preloadedBusinesses: Preloaded<typeof api.businesses.listPaginated>
  preloadedCount: Preloaded<typeof api.businesses.getBusinessCount>
}

export default function BusinessesClient({
  preloadedBusinesses,
  preloadedCount,
}: BusinessesClientProps) {
  const router = useRouter()
  const { toast } = useToast()

  // Get preloaded data
  const initialData = usePreloadedQuery(preloadedBusinesses)
  const totalCount = usePreloadedQuery(preloadedCount) || 0

  // Calculate total pages
  const totalPages = Math.ceil(totalCount / PAGE_SIZE)

  // Pagination state - track current page and cursors for each page
  const [currentPage, setCurrentPage] = useState(0)
  const [pageCursors, setPageCursors] = useState<(string | null)[]>([null]) // First page has null cursor

  // Fetch subsequent pages when needed (skip for page 0 which uses preloaded data)
  const paginatedResult = useQuery(
    api.businesses.listPaginated,
    currentPage === 0
      ? "skip"
      : {
          includeBlacklisted: true,
          paginationOpts: { numItems: PAGE_SIZE, cursor: pageCursors[currentPage] ?? null },
        }
  )

  // Get current page data
  const currentData = currentPage === 0 ? initialData : paginatedResult
  const businesses = currentData?.page || []
  const continueCursor = currentData?.continueCursor
  const isDone = currentData?.isDone ?? true

  // Pagination handlers
  const handleNextPage = useCallback(() => {
    if (continueCursor && currentPage < totalPages - 1) {
      // Store the cursor for the next page
      setPageCursors((prev) => {
        const newCursors = [...prev]
        if (newCursors.length <= currentPage + 1) {
          newCursors.push(continueCursor)
        }
        return newCursors
      })
      setCurrentPage((prev) => prev + 1)
    }
  }, [continueCursor, currentPage, totalPages])

  const handlePrevPage = useCallback(() => {
    if (currentPage > 0) {
      setCurrentPage((prev) => prev - 1)
    }
  }, [currentPage])

  // Check if we can go next (has cursor for next page or we haven't stored it yet)
  const canGoNext = !isDone && currentPage < totalPages - 1
  const canGoPrev = currentPage > 0

  // Loading state for non-preloaded pages
  const isLoading = currentPage > 0 && !paginatedResult
  const { canCreate, canDelete, isLoading: permissionsLoading } = usePermissions()
  const canCreateBusiness = canCreate("businesses")
  const canDeleteBusiness = canDelete("businesses")

  // Delete state
  const [deleteBusinessId, setDeleteBusinessId] = useState<Id<"businesses"> | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)
  const deleteBusiness = useMutation(api.businesses.remove)

  // Handle delete
  const handleDeleteClick = useCallback((businessId: string) => {
    setDeleteBusinessId(businessId as Id<"businesses">)
  }, [])

  const handleDelete = async () => {
    if (!deleteBusinessId) return

    setIsDeleting(true)
    try {
      await deleteBusiness({ id: deleteBusinessId })
      toast({
        title: "Success",
        description: "Business deleted successfully",
      })
      setDeleteBusinessId(null)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete business",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  // Create columns with delete handler
  const columns = useMemo(
    () => createBusinessColumns({
      onDelete: canDeleteBusiness ? handleDeleteClick : undefined
    }),
    [canDeleteBusiness, handleDeleteClick]
  )

  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Businesses</h1>
          <p className="text-muted-foreground">Manage business registrations</p>
        </div>
        <div className="flex items-center gap-2">
          <TooltipProvider delayDuration={300}>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="inline-block">
                  <Button
                    onClick={() => router.push("/dashboard/businesses/new")}
                    disabled={!canCreateBusiness || permissionsLoading}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Create Business
                  </Button>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                {!canCreateBusiness && !permissionsLoading ? (
                  <div className="flex items-center gap-2">
                    <Lock className="h-4 w-4" />
                    <p>You don't have permission to create businesses</p>
                  </div>
                ) : permissionsLoading ? (
                  <p>Loading permissions...</p>
                ) : (
                  <p>Create a new business</p>
                )}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Registered Businesses
            </CardTitle>
            <CardDescription>View and manage all registered businesses in the system</CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <DataTable
            columns={columns}
            data={businesses}
            isLoading={isLoading}
            onRowClick={(business: { _id: string }) => {
              router.push(`/dashboard/businesses/${business._id}`)
            }}
          />

          {/* Server-Side Pagination */}
          <div className="flex items-center justify-between px-2 pt-4">
            <div className="flex-1 text-sm text-muted-foreground">
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Loading...
                </span>
              ) : (
                <>
                  Page {currentPage + 1} of {totalPages} ({totalCount} total business{totalCount !== 1 ? "es" : ""})
                </>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handlePrevPage}
                disabled={!canGoPrev || isLoading}
              >
                <ChevronLeft className="h-4 w-4 mr-1" />
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleNextPage}
                disabled={!canGoNext || isLoading}
              >
                Next
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteBusinessId} onOpenChange={() => setDeleteBusinessId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Business?</AlertDialogTitle>
            <AlertDialogDescription>
              This will soft-delete the business. The record can be restored later if needed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
