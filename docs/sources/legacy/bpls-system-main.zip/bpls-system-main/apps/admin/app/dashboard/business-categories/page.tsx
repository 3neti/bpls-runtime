import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import BusinessCategoriesClient from "./business-categories-client"

export default async function BusinessCategoriesPage() {
  const token = await convexAuthNextjsToken()

  const preloadedCategories = await preloadQuery(api.businessCategories.listCategories, {}, { token })
  const preloadedSubCategories = await preloadQuery(api.businessCategories.listSubCategories, {}, { token })

  return (
    <BusinessCategoriesClient
      preloadedCategories={preloadedCategories}
      preloadedSubCategories={preloadedSubCategories}
    />
  )
}
