"use client";

import { usePreloadedQuery } from "convex/react";
import type { Preloaded } from "convex/react";
import { Building2, ImageIcon } from "lucide-react";
import { api } from "@repo/backend/convex/_generated/api";
import { LoginForm } from "@/components/login-form";
import { DEFAULT_PLATFORM_SETTINGS } from "@/hooks/use-platform-settings";

interface LoginClientProps {
  preloadedSettings: Preloaded<typeof api.platformSettings.get>;
  preloadedLogoUrl: Preloaded<typeof api.platformSettings.getLogoUrl>;
  preloadedLandingImageUrl: Preloaded<
    typeof api.platformSettings.getLandingImageUrl
  >;
}

export default function LoginClient({
  preloadedSettings,
  preloadedLogoUrl,
  preloadedLandingImageUrl,
}: LoginClientProps) {
  const settings = usePreloadedQuery(preloadedSettings);
  const logoUrl = usePreloadedQuery(preloadedLogoUrl);
  const landingImageUrl = usePreloadedQuery(preloadedLandingImageUrl);

  // Compute effective values with fallbacks
  const platformName =
    settings?.platformName ?? DEFAULT_PLATFORM_SETTINGS.platformName;
  const platformTitle =
    settings?.platformTitle ?? DEFAULT_PLATFORM_SETTINGS.platformTitle;
  const tagline = settings?.tagline ?? DEFAULT_PLATFORM_SETTINGS.tagline;

  return (
    <div className="grid min-h-svh lg:grid-cols-2">
      <div className="flex flex-col gap-4 p-6 md:p-10">
        <div className="flex justify-center gap-2 md:justify-start">
          <a href="/" className="flex items-center gap-2 font-medium">
            <div className="flex size-8 items-center justify-center">
              {logoUrl ? (
                <img
                  src={logoUrl}
                  alt="Platform Logo"
                  className="size-8 object-contain"
                />
              ) : (
                <div className="size-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Building2 className="size-5 text-primary" />
                </div>
              )}
            </div>
            {platformName}
          </a>
        </div>
        <div className="flex flex-1 items-center justify-center">
          <div className="w-full max-w-xs">
            <LoginForm
              platformName={platformName}
              platformTitle={platformTitle}
              tagline={tagline}
            />
          </div>
        </div>
      </div>
      <div className="bg-muted relative hidden lg:block">
        {landingImageUrl ? (
          <img
            src={landingImageUrl}
            alt="Landing Background"
            className="absolute inset-0 h-full w-full object-cover dark:brightness-[0.2] dark:grayscale"
          />
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-primary/5 to-primary/20">
            <ImageIcon className="size-24 text-muted-foreground/30" />
            <p className="mt-4 text-sm text-muted-foreground/50">
              Landing Image
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
