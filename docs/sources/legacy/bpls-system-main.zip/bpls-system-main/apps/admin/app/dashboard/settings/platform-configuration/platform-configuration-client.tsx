"use client"

import { usePreloadedQuery } from "convex/react"
import { api } from "@repo/backend/convex/_generated/api"
import { useToast } from "@/hooks/use-toast"
import { PlatformConfigSection } from "@/components/settings/platform-config-section"
import { PermissionGuard } from "@/components/permission-guard"
import type { Preloaded } from "convex/react"

interface PlatformConfigurationClientProps {
  preloadedSettings: Preloaded<typeof api.platformSettings.get>
}

export function PlatformConfigurationClient({
  preloadedSettings,
}: PlatformConfigurationClientProps) {
  const { toast } = useToast()
  const settings = usePreloadedQuery(preloadedSettings)

  return (
    <PermissionGuard resource="settings:platform_configuration" action="read" showLoading>
      <PlatformConfigSection settings={settings} toast={toast} />
    </PermissionGuard>
  )
}
