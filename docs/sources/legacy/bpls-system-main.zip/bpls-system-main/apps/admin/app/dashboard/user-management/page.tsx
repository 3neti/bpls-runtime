import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import { UserManagementClient } from "./user-management-client"

/**
 * User Management Page (Server Component)
 *
 * Admin interface for managing system users, their roles, and account settings.
 *
 * Features:
 * - View all system users with search and filtering
 * - Create, edit, and delete user accounts
 * - Activate/deactivate user status
 * - Manage user roles and departments
 *
 * Architecture:
 * - Server-side rendering with preloaded Convex query
 * - Loading state handled by loading.tsx skeleton
 * - Client interactions delegated to UserManagementClient component
 */
export default async function UserManagementPage() {
  const token = await convexAuthNextjsToken()

  // Preload users data on the server
  const preloadedUsers = await preloadQuery(api.users.list, {}, { token })

  return (
    <UserManagementClient
      preloadedUsers={preloadedUsers}
    />
  )
}
