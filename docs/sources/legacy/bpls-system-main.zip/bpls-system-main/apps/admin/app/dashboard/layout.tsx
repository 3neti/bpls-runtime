import { redirect } from "next/navigation";
import { fetchQuery, preloadQuery } from "convex/nextjs";
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server";
import { api } from "@repo/backend/convex/_generated/api";
import DashboardLayoutClient from "./dashboard-layout-client";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Check authentication status
  const token = await convexAuthNextjsToken();
  if (!token) {
    redirect("/login");
  }

  // Check if platform has been onboarded
  const isOnboarded = await fetchQuery(api.platformSettings.isOnboarded, {});

  // Redirect to onboarding if not set up
  if (!isOnboarded) {
    redirect("/admin/onboarding");
  }

  // Get current user for the layout
  const currentUser = await fetchQuery(
    api.users.getCurrentUser,
    {},
    { token }
  );

  if (!currentUser) {
    // User authenticated but not in app users table - redirect to login
    redirect("/login");
  }

  // Preload platform settings for SSR (logo and branding in sidebar)
  const [preloadedSettings, preloadedLogoUrl] = await Promise.all([
    preloadQuery(api.platformSettings.get, {}),
    preloadQuery(api.platformSettings.getLogoUrl, {}),
  ]);

  return (
    <DashboardLayoutClient
      preloadedSettings={preloadedSettings}
      preloadedLogoUrl={preloadedLogoUrl}
      currentUser={currentUser}
    >
      {children}
    </DashboardLayoutClient>
  );
}
