"use client";

import { Building2, User, Briefcase, ImageIcon, Shield, CheckCircle2, Eye } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card";
import { Badge } from "@repo/ui/components/badge";
import { Separator } from "@repo/ui/components/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@repo/ui/components/tabs";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Button } from "@repo/ui/components/button";
import type { OnboardingData } from "@/lib/schemas/onboarding";
import type { Id } from "@repo/backend/convex/_generated/dataModel";

interface UploadedImages {
  municipalSeal?: { storageId: Id<"_storage">; url: string };
  logo?: { storageId: Id<"_storage">; url: string };
  landingImage?: { storageId: Id<"_storage">; url: string };
}

interface ReviewStepProps {
  formData: OnboardingData;
  uploadedImages: UploadedImages;
}

function SummaryItem({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
}) {
  return (
    <div className="flex items-start gap-3 py-2">
      {Icon && <Icon className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />}
      <div className="min-w-0 flex-1">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-medium truncate">{value || "—"}</p>
      </div>
    </div>
  );
}

export function ReviewStep({ formData, uploadedImages }: ReviewStepProps) {
  const imagesConfigured = Object.keys(uploadedImages).length;

  return (
    <div className="space-y-6">
      {/* Summary Banner */}
      <div className="flex items-center gap-3 p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
        <CheckCircle2 className="h-5 w-5 text-green-600 shrink-0" />
        <div>
          <p className="text-sm font-medium text-green-800 dark:text-green-200">
            Ready to complete setup
          </p>
          <p className="text-xs text-green-700 dark:text-green-300">
            Review your configuration below and click "Complete Setup" when ready.
          </p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid md:grid-cols-3 gap-4">
        {/* Municipality */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Building2 className="h-4 w-4" />
              Municipality
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            <SummaryItem label="Name" value={formData.municipalityName} />
            <SummaryItem label="Short Name" value={formData.municipalityShortName} />
            <SummaryItem label="Province" value={formData.provinceName} />
            <SummaryItem label="Address" value={formData.fullAddress} />
          </CardContent>
        </Card>

        {/* Officials */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <User className="h-4 w-4" />
              Officials
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1">
            <SummaryItem label="Mayor" value={formData.mayorName} icon={User} />
            <SummaryItem label="Title" value={formData.mayorTitle} />
            <Separator className="my-2" />
            <SummaryItem label="Treasurer" value={formData.treasurerName} icon={Briefcase} />
            <SummaryItem label="Title" value={formData.treasurerTitle} />
          </CardContent>
        </Card>

        {/* Branding */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <ImageIcon className="h-4 w-4" />
              Branding
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Municipal Seal</span>
                <Badge variant={uploadedImages.municipalSeal ? "default" : "secondary"}>
                  {uploadedImages.municipalSeal ? "Uploaded" : "Not set"}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Platform Logo</span>
                <Badge variant={uploadedImages.logo ? "default" : "secondary"}>
                  {uploadedImages.logo ? "Uploaded" : "Not set"}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Landing Image</span>
                <Badge variant={uploadedImages.landingImage ? "default" : "secondary"}>
                  {uploadedImages.landingImage ? "Uploaded" : "Not set"}
                </Badge>
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-3">
              {imagesConfigured}/3 images configured
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Live Previews */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Live Previews</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="permit" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="permit">Permit</TabsTrigger>
              <TabsTrigger value="receipt">Receipt</TabsTrigger>
              <TabsTrigger value="login">Login Page</TabsTrigger>
            </TabsList>

            <TabsContent value="permit" className="mt-4">
              <div className="border rounded-lg p-6 bg-card text-card-foreground max-w-md mx-auto">
                <div className="text-center border-b-2 border-primary/30 pb-4">
                  {uploadedImages.municipalSeal?.url ? (
                    <img
                      src={uploadedImages.municipalSeal.url}
                      alt="Seal"
                      className="h-16 w-16 object-contain mx-auto mb-2"
                    />
                  ) : (
                    <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-2">
                      <Shield className="h-8 w-8 text-muted-foreground" />
                    </div>
                  )}
                  <p className="text-sm font-bold text-primary">
                    {formData.municipalityName || "MUNICIPALITY NAME"}
                  </p>
                  <p className="text-xs text-muted-foreground">Office of the Mayor</p>
                  <p className="text-lg font-bold text-primary mt-2 tracking-wider">
                    MAYOR'S PERMIT
                  </p>
                </div>
                <div className="mt-6 text-center">
                  <div className="border-t border-border w-40 mx-auto mb-2" />
                  <p className="text-sm font-bold">{formData.mayorName || "MAYOR NAME"}</p>
                  <p className="text-xs text-muted-foreground">{formData.mayorTitle}</p>
                  <p className="text-xs text-muted-foreground/70 mt-1">Authorizing Official</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="receipt" className="mt-4">
              <div className="border rounded-lg p-4 bg-card text-card-foreground font-mono text-sm max-w-sm mx-auto">
                <p className="text-xs text-muted-foreground">Date: {new Date().toLocaleDateString()}</p>
                <p className="font-bold mt-2">{formData.fullAddress || "MUNICIPALITY ADDRESS"}</p>
                <p className="text-xs text-muted-foreground">Official Receipt</p>
                <div className="mt-4 space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Business Tax</span>
                    <span>1,500.00</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Mayor's Permit Fee</span>
                    <span>500.00</span>
                  </div>
                  <div className="border-t border-border mt-2 pt-2 flex justify-between font-bold text-xs">
                    <span>TOTAL</span>
                    <span>PHP 2,000.00</span>
                  </div>
                </div>
                <div className="mt-4 text-center text-xs text-muted-foreground">
                  <p>Approved by:</p>
                  <p className="font-bold text-foreground">{formData.treasurerName || "TREASURER"}</p>
                  <p>{formData.treasurerTitle}</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="login" className="mt-4">
              <div className="border rounded-lg overflow-hidden max-w-2xl mx-auto">
                <div className="grid lg:grid-cols-2 min-h-[280px]">
                  {/* Login Form Side */}
                  <div className="flex flex-col gap-4 p-6 bg-background">
                    {/* Header with Logo */}
                    <div className="flex items-center gap-2">
                      <div className="flex size-6 items-center justify-center">
                        {uploadedImages.logo?.url ? (
                          <img
                            src={uploadedImages.logo.url}
                            alt="Logo"
                            className="size-6 object-contain"
                          />
                        ) : (
                          <div className="size-6 rounded-lg bg-primary/10 flex items-center justify-center">
                            <Building2 className="size-4 text-primary" />
                          </div>
                        )}
                      </div>
                      <span className="text-sm font-medium">
                        {formData.municipalityShortName || "BPLS"}
                      </span>
                    </div>

                    {/* Login Form */}
                    <div className="flex flex-1 items-center justify-center">
                      <div className="w-full max-w-[200px] space-y-4">
                        <div className="text-center space-y-1">
                          <h2 className="text-base font-bold">
                            Login to {formData.municipalityShortName || "BPLS"}
                          </h2>
                          <p className="text-muted-foreground text-[10px]">
                            Enter your credentials to access the system
                          </p>
                        </div>

                        <div className="space-y-3">
                          <div className="space-y-1">
                            <Label className="text-[10px]">Email</Label>
                            <Input
                              placeholder="user@example.gov.ph"
                              className="h-7 text-[10px]"
                              disabled
                            />
                          </div>
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <Label className="text-[10px]">Password</Label>
                              <span className="text-[8px] text-muted-foreground">Forgot password?</span>
                            </div>
                            <div className="relative">
                              <Input
                                type="password"
                                placeholder="••••••••"
                                className="h-7 text-[10px] pr-8"
                                disabled
                              />
                              <Eye className="absolute right-2 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
                            </div>
                          </div>
                          <Button className="w-full h-7 text-[10px]" disabled>
                            Login
                          </Button>
                          <p className="text-center text-[8px] text-muted-foreground">
                            Need help? Contact IT Support
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Landing Image Side */}
                  <div className="bg-muted relative hidden lg:block">
                    {uploadedImages.landingImage?.url ? (
                      <img
                        src={uploadedImages.landingImage.url}
                        alt="Login Background"
                        className="absolute inset-0 w-full h-full object-cover"
                      />
                    ) : (
                      <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-primary/5 to-primary/20">
                        <ImageIcon className="size-12 text-muted-foreground/30" />
                        <p className="mt-2 text-[10px] text-muted-foreground/50">
                          Landing Image
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
