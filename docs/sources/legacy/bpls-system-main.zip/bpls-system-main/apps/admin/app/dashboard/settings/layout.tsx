"use client";

import type React from "react";
import { usePathname } from "next/navigation";
import Link from "next/link";
import { Building2, MapPin, Users, Palette, Receipt, FileText, Loader2, ShieldX } from "lucide-react";
import { cn } from "@/lib/utils";
import { usePermissions, type Resource } from "@/hooks/use-permissions";
import { Card, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";

const settingsNavItems = [
  {
    id: "platform-configuration",
    title: "Platform Configuration",
    icon: Building2,
    description: "Platform name, title, and regional settings",
    resource: "settings:platform_configuration" as Resource,
  },
  {
    id: "municipality",
    title: "Municipality",
    icon: MapPin,
    description: "Municipality name, province, and address",
    resource: "settings:municipality" as Resource,
  },
  {
    id: "officials",
    title: "Government Officials",
    icon: Users,
    description: "Mayor, treasurer, and other officials",
    resource: "settings:officials" as Resource,
  },
  {
    id: "branding",
    title: "Branding",
    icon: Palette,
    description: "Logo, seal, and visual identity",
    resource: "settings:branding" as Resource,
  },
  {
    id: "receipting",
    title: "Receipting",
    icon: Receipt,
    description: "Configure receipt layouts and templates",
    resource: "settings:receipting" as Resource,
  },
  {
    id: "permit-layout",
    title: "Permit Layout",
    icon: FileText,
    description: "Customize business permit document design",
    resource: "settings:permit_layout" as Resource,
  },
];

export default function SettingsLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { canRead, isLoading } = usePermissions();

  // Filter nav items based on permissions
  const visibleNavItems = settingsNavItems.filter((item) => canRead(item.resource));

  // Show loading state
  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  // Show access denied if user has no settings permissions
  if (visibleNavItems.length === 0) {
    return (
      <div className="flex-1 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Settings</h2>
            <p className="text-muted-foreground">Configure your platform settings and branding</p>
          </div>
        </div>
        <Card className="border-destructive/20 bg-destructive/5">
          <CardHeader>
            <div className="flex items-center gap-2">
              <ShieldX className="h-6 w-6 text-destructive" />
              <CardTitle className="text-destructive">Access Denied</CardTitle>
            </div>
            <CardDescription>
              You don&apos;t have permission to access any settings. Please contact your administrator.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex-1 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Settings</h2>
          <p className="text-muted-foreground">Configure your platform settings and branding</p>
        </div>
      </div>

      <div className="flex flex-col gap-6 lg:flex-row">
        {/* Sidebar Navigation */}
        <aside className="lg:w-64 shrink-0">
          <nav className="space-y-1">
            {visibleNavItems.map((item) => {
              const isActive = pathname?.includes(`/settings/${item.id}`);
              return (
                <Link
                  key={item.id}
                  href={`/dashboard/settings/${item.id}`}
                  className={cn(
                    "w-full flex items-start gap-3 rounded-lg px-3 py-3 text-left transition-colors",
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-muted"
                  )}
                >
                  <item.icon className="h-5 w-5 mt-0.5 shrink-0" />
                  <div className="min-w-0">
                    <div className="font-medium truncate">{item.title}</div>
                    <div
                      className={cn(
                        "text-xs truncate",
                        isActive ? "text-primary-foreground/80" : "text-muted-foreground"
                      )}
                    >
                      {item.description}
                    </div>
                  </div>
                </Link>
              );
            })}
          </nav>
        </aside>

        {/* Content Area */}
        <main className="flex-1 min-w-0">
          {children}
        </main>
      </div>
    </div>
  );
}
