"use client"

import { useState } from "react"
import { usePreloadedQuery, useMutation } from "convex/react"
import type { Preloaded } from "convex/react"
import { Plus, DollarSign } from "lucide-react"

import { usePermissions } from "@/hooks/use-permissions"
import { PermissionGuard } from "@/components/permission-guard"
import { PermissionDenied } from "@/components/permission-error-states"
import { Button } from "@repo/ui/components/button"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { columns } from "@/components/fees/data-table/columns"
import { DataTable } from "@/components/fees/data-table/data-table"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { useToast } from "@/hooks/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { Input } from "@repo/ui/components/input"
import { Label } from "@repo/ui/components/label"
import { Textarea } from "@repo/ui/components/textarea"

interface FeesClientProps {
  preloadedFeeNames: Preloaded<typeof api.feeNames.list>
}

interface EditingFee {
  _id: Id<"fee_names">
  name: string
  description?: string
  isActive: boolean
}

export default function FeesClient({ preloadedFeeNames }: FeesClientProps) {
  const feeNames = usePreloadedQuery(preloadedFeeNames)
  const { toast } = useToast()
  const { canCreate, canUpdate, canDelete, isLoading: permissionsLoading } = usePermissions()

  // Permission checks
  const hasCreatePermission = canCreate("taxes_and_fees:fees")
  const hasUpdatePermission = canUpdate("taxes_and_fees:fees")
  const hasDeletePermission = canDelete("taxes_and_fees:fees")

  // Dialog states
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editingFee, setEditingFee] = useState<EditingFee | null>(null)

  // Form states
  const [newFeeName, setNewFeeName] = useState("")
  const [newFeeDescription, setNewFeeDescription] = useState("")
  const [editFeeName, setEditFeeName] = useState("")
  const [editFeeDescription, setEditFeeDescription] = useState("")

  // Mutations
  const createFeeName = useMutation(api.feeNames.create)
  const updateFeeName = useMutation(api.feeNames.update)
  const toggleActive = useMutation(api.feeNames.toggleActive)

  // Handle add new fee name
  const handleAddFeeName = async () => {
    if (!newFeeName.trim()) {
      toast({
        title: "Error",
        description: "Fee name is required",
        variant: "destructive",
      })
      return
    }

    try {
      await createFeeName({
        name: newFeeName.trim(),
        description: newFeeDescription.trim() || undefined,
        isActive: true,
      })

      toast({
        title: "Success",
        description: "Fee name created successfully",
      })

      setNewFeeName("")
      setNewFeeDescription("")
      setIsAddDialogOpen(false)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create fee name",
        variant: "destructive",
      })
    }
  }

  // Handle edit fee name
  const handleEditFeeName = async () => {
    if (!editingFee) return

    if (!editFeeName.trim()) {
      toast({
        title: "Error",
        description: "Fee name is required",
        variant: "destructive",
      })
      return
    }

    try {
      await updateFeeName({
        id: editingFee._id,
        name: editFeeName.trim(),
        description: editFeeDescription.trim() || undefined,
      })

      toast({
        title: "Success",
        description: "Fee name updated successfully",
      })

      setEditingFee(null)
      setEditFeeName("")
      setEditFeeDescription("")
      setIsEditDialogOpen(false)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update fee name",
        variant: "destructive",
      })
    }
  }

  // Handle archive (toggle active status)
  const handleToggleActive = async (id: Id<"fee_names">, currentStatus: boolean) => {
    try {
      await toggleActive({ id })

      toast({
        title: "Success",
        description: currentStatus
          ? "Fee name archived successfully"
          : "Fee name restored successfully",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update fee status",
        variant: "destructive",
      })
    }
  }

  // Open edit dialog
  const openEditDialog = (fee: EditingFee) => {
    setEditingFee(fee)
    setEditFeeName(fee.name)
    setEditFeeDescription(fee.description || "")
    setIsEditDialogOpen(true)
  }

  return (
    <PermissionGuard
      resource="taxes_and_fees:fees"
      action="read"
      showLoading
      fallback={
        <PermissionDenied
          title="Fee Names"
          description="Manage available fee name options"
          resourceName="fee names"
          backLink="/dashboard"
          backLinkText="Back to Dashboard"
        />
      }
    >
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Fee Names</h1>
          <p className="text-muted-foreground">Manage available fee name options</p>
        </div>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <span tabIndex={hasCreatePermission ? -1 : 0}>
                <Button
                  onClick={() => setIsAddDialogOpen(true)}
                  disabled={!hasCreatePermission || permissionsLoading}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Fee Name
                </Button>
              </span>
            </TooltipTrigger>
            {!hasCreatePermission && !permissionsLoading && (
              <TooltipContent>
                <p>You don't have permission to create fee names</p>
              </TooltipContent>
            )}
          </Tooltip>
        </TooltipProvider>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <div>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Fee Names
            </CardTitle>
            <CardDescription>
              View and manage all available fee names in the system
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <DataTable
            columns={columns}
            data={feeNames}
            onEdit={openEditDialog}
            onToggleActive={handleToggleActive}
            hasUpdatePermission={hasUpdatePermission && !permissionsLoading}
            hasDeletePermission={hasDeletePermission && !permissionsLoading}
          />
        </CardContent>
      </Card>

      {/* Add Fee Name Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Fee Name</DialogTitle>
            <DialogDescription>
              Create a new fee name that can be used when configuring fees.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={newFeeName}
                onChange={(e) => setNewFeeName(e.target.value)}
                placeholder="Enter fee name..."
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description (optional)</Label>
              <Textarea
                id="description"
                value={newFeeDescription}
                onChange={(e) => setNewFeeDescription(e.target.value)}
                placeholder="Enter description..."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddFeeName}>Add Fee Name</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Fee Name Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Fee Name</DialogTitle>
            <DialogDescription>Update the fee name details.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Name</Label>
              <Input
                id="edit-name"
                value={editFeeName}
                onChange={(e) => setEditFeeName(e.target.value)}
                placeholder="Enter fee name..."
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-description">Description (optional)</Label>
              <Textarea
                id="edit-description"
                value={editFeeDescription}
                onChange={(e) => setEditFeeDescription(e.target.value)}
                placeholder="Enter description..."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleEditFeeName}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
    </PermissionGuard>
  )
}
