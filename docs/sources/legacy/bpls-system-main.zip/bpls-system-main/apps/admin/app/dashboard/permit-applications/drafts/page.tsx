"use client"

import * as React from "react"
import { useState, useMemo, useCallback } from "react"
import { Search, Plus, FileText, ChevronDown, Download } from "lucide-react"
import Link from "next/link"
import {
  ColumnFiltersState,
  SortingState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table"

import { Button } from "@repo/ui/components/button"
import { Input } from "@repo/ui/components/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@repo/ui/components/table"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@repo/ui/components/dialog"
import { useColumnVisibilityStore } from "@/lib/stores/column-visibility-store"
import {
  TableFilterPopover,
  createDefaultFilterState,
  applyFilters,
  type FilterConfig,
  type FilterState,
} from "@/components/permits/table-filter-popover"
import { createDraftsColumns, type DraftRow } from "@/components/permits/drafts-columns"
import {
  convertToCSV,
  downloadCSV,
  generateExportFilename,
  formatDateForCSV,
  type CSVColumn,
} from "@/lib/utils/csv-export"
import { PermissionGuard } from "@/components/permission-guard"

// Sample draft data
const initialDrafts: DraftRow[] = [
  {
    id: "draft-001",
    name: "Juan's Restaurant Application",
    comments: "Need to gather additional documents for health permit requirements",
    createdAt: "2024-01-15T10:30:00Z",
    updatedAt: "2024-01-16T14:20:00Z",
    currentStep: 2,
    totalSteps: 4,
    stepName: "Business Details",
    formData: {
      ownerName: "Juan Dela Cruz",
      businessName: "Juan's Restaurant",
      businessType: "new",
    },
  },
  {
    id: "draft-002",
    name: "Maria's Salon Renewal",
    comments: "",
    createdAt: "2024-01-10T09:15:00Z",
    updatedAt: "2024-01-10T09:15:00Z",
    currentStep: 1,
    totalSteps: 4,
    stepName: "Business Owner",
    formData: {
      ownerName: "Maria Santos",
      businessName: "Maria's Beauty Salon",
      businessType: "renew",
    },
  },
  {
    id: "draft-003",
    name: "Auto Repair Shop Permit",
    comments: "Waiting for zoning clearance from city planning office",
    createdAt: "2024-01-08T16:45:00Z",
    updatedAt: "2024-01-12T11:30:00Z",
    currentStep: 3,
    totalSteps: 4,
    stepName: "Requirements",
    formData: {
      ownerName: "Pedro Garcia",
      businessName: "Pedro's Auto Repair",
      businessType: "new",
    },
  },
]

// Column name formatting helper
function formatColumnName(id: string): string {
  return id
    .replace(/([A-Z])/g, " $1")
    .replace(/^./, (str) => str.toUpperCase())
    .trim()
}

// Filter config for Drafts table
const FILTER_CONFIG: FilterConfig = {
  showDateRange: true,
  showTypeFilter: true,
  showProgressRange: true,
}

export default function DraftsPage() {
  // Data state
  const [draftsList, setDraftsList] = useState<DraftRow[]>(initialDrafts)

  // Modal states
  const [selectedComments, setSelectedComments] = useState("")
  const [isCommentsModalOpen, setIsCommentsModalOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [draftToDelete, setDraftToDelete] = useState<string | null>(null)

  // Table state
  const [sorting, setSorting] = React.useState<SortingState>([])
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
  const [filters, setFilters] = React.useState<FilterState>(createDefaultFilterState())

  // Get column visibility from Zustand store
  const { draftsColumns, setDraftsColumns } = useColumnVisibilityStore()

  // Handlers
  const handleDeleteDraft = useCallback((draftId: string) => {
    setDraftToDelete(draftId)
    setDeleteDialogOpen(true)
  }, [])

  const confirmDelete = useCallback(() => {
    if (draftToDelete) {
      setDraftsList(prev => prev.filter((draft) => draft.id !== draftToDelete))
      setDraftToDelete(null)
      setDeleteDialogOpen(false)
    }
  }, [draftToDelete])

  const handleContinueDraft = useCallback((draftId: string) => {
    console.log("Continuing draft:", draftId)
    // In a real app, you would navigate to /dashboard/permit-applications/new?draft=draftId
  }, [])

  const handleViewComments = useCallback((comments: string) => {
    setSelectedComments(comments || "N/A")
    setIsCommentsModalOpen(true)
  }, [])

  // Create columns with handlers
  const columns = useMemo(
    () => createDraftsColumns({
      onContinue: handleContinueDraft,
      onDelete: handleDeleteDraft,
      onViewComments: handleViewComments,
    }),
    [handleContinueDraft, handleDeleteDraft, handleViewComments]
  )

  // Apply custom filters to data
  const filteredData = useMemo(() => {
    return applyFilters<DraftRow>(draftsList, filters, {
      dateKey: "updatedAt",
      getProgress: (item: DraftRow) => (item.currentStep / item.totalSteps) * 100,
    })
  }, [draftsList, filters])

  const table = useReactTable({
    data: filteredData,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onColumnVisibilityChange: setDraftsColumns,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    initialState: {
      pagination: {
        pageSize: 10,
      },
    },
    state: {
      sorting,
      columnFilters,
      columnVisibility: draftsColumns,
    },
  })

  // Export handler
  const handleExport = useCallback(() => {
    const exportColumns: CSVColumn<DraftRow>[] = [
      { header: "Draft Name", accessor: (row) => row.name },
      { header: "Owner Name", accessor: (row) => row.formData.ownerName },
      { header: "Business Name", accessor: (row) => row.formData.businessName },
      { header: "Type", accessor: (row) => row.formData.businessType === "new" ? "New Application" : "Renewal" },
      { header: "Progress", accessor: (row) => `${Math.round((row.currentStep / row.totalSteps) * 100)}%` },
      { header: "Current Step", accessor: (row) => row.stepName },
      { header: "Updated", accessor: (row) => formatDateForCSV(row.updatedAt) },
      { header: "Created", accessor: (row) => formatDateForCSV(row.createdAt) },
      { header: "Comments", accessor: (row) => row.comments || "N/A" },
    ]

    const csv = convertToCSV(filteredData, exportColumns)
    const filename = generateExportFilename("draft-applications")
    downloadCSV(csv, filename)
  }, [filteredData])

  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Draft Permits</h2>
          <p className="text-muted-foreground">Manage your saved permit application drafts</p>
        </div>
        <Link href="/dashboard/permit-applications/new">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New Application
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Saved Drafts</CardTitle>
          <CardDescription>Continue working on your permit applications</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="w-full space-y-4">
            <div className="flex items-center space-x-2">
              <div className="relative flex-1">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search drafts..."
                  value={(table.getColumn("name")?.getFilterValue() as string) ?? ""}
                  onChange={(event) =>
                    table.getColumn("name")?.setFilterValue(event.target.value)
                  }
                  className="pl-8"
                />
              </div>

              {/* Columns Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline">
                    Columns <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-[200px]">
                  {table
                    .getAllColumns()
                    .filter((column) => column.getCanHide())
                    .map((column) => {
                      const displayName = formatColumnName(column.id)
                      return (
                        <DropdownMenuCheckboxItem
                          key={column.id}
                          className="capitalize"
                          checked={column.getIsVisible()}
                          onCheckedChange={(value) =>
                            column.toggleVisibility(!!value)
                          }
                        >
                          {displayName}
                        </DropdownMenuCheckboxItem>
                      )
                    })}
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Filter Popover */}
              <TableFilterPopover
                config={FILTER_CONFIG}
                filters={filters}
                onFiltersChange={setFilters}
              />

              {/* Export Button */}
              <PermissionGuard resource="reports" action="read" fallback={null}>
                <Button variant="outline" onClick={handleExport}>
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </PermissionGuard>
            </div>

            {filteredData.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No drafts found</h3>
                <p className="text-muted-foreground mb-4">
                  You haven&apos;t saved any drafts yet or no drafts match your filters.
                </p>
                <Link href="/dashboard/permit-applications/new">
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Start New Application
                  </Button>
                </Link>
              </div>
            ) : (
              <>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      {table.getHeaderGroups().map((headerGroup) => (
                        <TableRow key={headerGroup.id}>
                          {headerGroup.headers.map((header) => {
                            return (
                              <TableHead key={header.id}>
                                {header.isPlaceholder
                                  ? null
                                  : flexRender(
                                      header.column.columnDef.header,
                                      header.getContext()
                                    )}
                              </TableHead>
                            )
                          })}
                        </TableRow>
                      ))}
                    </TableHeader>
                    <TableBody>
                      {table.getRowModel().rows?.length ? (
                        table.getRowModel().rows.map((row) => (
                          <TableRow
                            key={row.id}
                            className="hover:bg-muted/50"
                          >
                            {row.getVisibleCells().map((cell) => (
                              <TableCell key={cell.id}>
                                {flexRender(
                                  cell.column.columnDef.cell,
                                  cell.getContext()
                                )}
                              </TableCell>
                            ))}
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell
                            colSpan={columns.length}
                            className="h-24 text-center"
                          >
                            No drafts found.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>

                <div className="flex items-center justify-end space-x-2">
                  <div className="text-muted-foreground flex-1 text-sm">
                    {table.getFilteredRowModel().rows.length} draft(s) total.
                  </div>
                  <div className="flex items-center space-x-2">
                    <p className="text-sm text-muted-foreground">
                      Page {table.getState().pagination.pageIndex + 1} of{" "}
                      {table.getPageCount() || 1}
                    </p>
                    <div className="space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => table.previousPage()}
                        disabled={!table.getCanPreviousPage()}
                      >
                        Previous
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => table.nextPage()}
                        disabled={!table.getCanNextPage()}
                      >
                        Next
                      </Button>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Comments Dialog */}
      <Dialog open={isCommentsModalOpen} onOpenChange={setIsCommentsModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Draft Comments</DialogTitle>
            <DialogDescription>View the full comments for this draft application.</DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            <div className="bg-muted/50 p-4 rounded-md">
              <p className="text-sm text-muted-foreground whitespace-pre-wrap">{selectedComments}</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Draft</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this draft? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setDraftToDelete(null)}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
