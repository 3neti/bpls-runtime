"use client"

import { useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import { usePreloadedQuery, useMutation, useQuery } from "convex/react"
import type { Preloaded } from "convex/react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import { createAssessmentColumns } from "@/components/permits/assessment-columns"
import { AssessmentDataTable } from "@/components/permits/assessment-data-table"
import { useToast } from "@/hooks/use-toast"
import { useDebouncedValue } from "@/hooks/use-debounced-value"
import { usePermissions } from "@/hooks/use-permissions"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { formatDateForCSV, type CSVColumn } from "@/lib/utils/csv-export"
import type { FilterConfig } from "@/components/permits/table-filter-popover"

// Filter config for Approval table - no status filter since all are "Approval"
const APPROVAL_FILTER_CONFIG: FilterConfig = {
  statusOptions: [], // No status filter - all applications are in Approval
  showDateRange: true,
  showTypeFilter: true,
}

// Type for the enriched application data
type EnrichedApplication = {
  _id: Id<"business_permit_applications">
  applicationNumber: string
  ownerName: string
  businessName: string
  submittedAt: string
  status: string
}

// CSV export column definitions for approval applications
const exportColumns: CSVColumn<EnrichedApplication>[] = [
  { header: "Application Number", accessor: (row) => row.applicationNumber },
  { header: "Owner Name", accessor: (row) => row.ownerName },
  { header: "Business Name", accessor: (row) => row.businessName },
  { header: "Submitted Date", accessor: (row) => formatDateForCSV(row.submittedAt) },
  { header: "Status", accessor: (row) => row.status },
]

interface ApprovalClientProps {
  preloadedApplications: Preloaded<typeof api.businessPermitApplications.listByStatuses>
}

export function ApprovalClient({ preloadedApplications }: ApprovalClientProps) {
  const router = useRouter()
  const { toast } = useToast()
  const { canDelete } = usePermissions()
  const [deleteApplicationId, setDeleteApplicationId] = useState<Id<"business_permit_applications"> | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const debouncedSearch = useDebouncedValue(searchQuery, 300)

  const rawApplications = usePreloadedQuery(preloadedApplications)
  const deleteApplication = useMutation(api.businessPermitApplications.remove)

  // Server-side search query (conditionally skip when search is too short)
  const searchResults = useQuery(
    api.search.searchApplications,
    debouncedSearch.length >= 2
      ? { query: debouncedSearch, status: "Approval", limit: 50 }
      : "skip"
  )

  // Transform data to match the table columns type
  // Use search results when available, otherwise use preloaded data
  const applications = useMemo(() => {
    // If search is active and we have results, use search results (already enriched)
    if (debouncedSearch.length >= 2 && searchResults) {
      return searchResults.map((app) => ({
        ...app,
        ownerName: app.ownerName ?? "Unknown Owner",
        businessName: app.businessName ?? "Unknown Business"
      }))
    }

    // Otherwise, use preloaded data
    if (!rawApplications) return []

    return rawApplications.map((app: typeof rawApplications[number]) => ({
      ...app,
      ownerName: app.businessOwner
        ? `${app.businessOwner.firstName} ${app.businessOwner.lastName}`
        : "Unknown Owner",
      businessName: app.business?.name ?? "Unknown Business"
    }))
  }, [rawApplications, searchResults, debouncedSearch])

  // Create columns with delete handler (guarded by permission)
  const columns = useMemo(
    () =>
      createAssessmentColumns({
        onView: (applicationId) => router.push(`/dashboard/permit-applications/approval/${applicationId}`),
        onDelete: canDelete("permit_applications:approval")
          ? (applicationId) => setDeleteApplicationId(applicationId as Id<"business_permit_applications">)
          : undefined,
      }),
    [canDelete, router]
  )

  const handleRowClick = (application: typeof applications[0]) => {
    router.push(`/dashboard/permit-applications/approval/${application._id}`)
  }

  const handleDelete = async () => {
    if (!deleteApplicationId) return

    setIsDeleting(true)

    try {
      await deleteApplication({ id: deleteApplicationId })
      toast({
        title: "Success",
        description: "Application deleted successfully",
      })
      setDeleteApplicationId(null)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete application",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Permit Approval</h2>
          <p className="text-muted-foreground">
            Review and approve assessed business permit applications
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Applications for Approval</CardTitle>
          <CardDescription>
            Assessed applications awaiting review and approval before payment
          </CardDescription>
        </CardHeader>
        <CardContent>
          <AssessmentDataTable
            columns={columns}
            data={applications || []}
            tableType="assessment"
            searchKey="applicationNumber"
            searchPlaceholder="Search by application number, business name, or owner name..."
            searchValue={searchQuery}
            onSearchChange={setSearchQuery}
            onRowClick={handleRowClick}
            exportEnabled={true}
            exportFilename="approval-applications"
            exportColumns={exportColumns as CSVColumn<unknown>[]}
            filterConfig={APPROVAL_FILTER_CONFIG}
          />
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteApplicationId} onOpenChange={() => setDeleteApplicationId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Application?</AlertDialogTitle>
            <AlertDialogDescription>
              This will soft-delete the permit application. The record can be restored later if needed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
