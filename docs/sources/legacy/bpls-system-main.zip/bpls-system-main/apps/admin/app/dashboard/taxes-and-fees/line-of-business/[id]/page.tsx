import { Suspense } from "react"
import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { LineOfBusinessDetailClient } from "./line-of-business-detail-client"
import { Skeleton } from "@repo/ui/components/skeleton"

interface LineOfBusinessDetailPageProps {
  params: Promise<{ id: Id<"groups"> }>
}

export default async function LineOfBusinessDetailPage({ params }: LineOfBusinessDetailPageProps) {
  const token = await convexAuthNextjsToken()

  const { id } = await params
  const preloadedLineOfBusiness = await preloadQuery(api.groups.getById, { groupId: id }, { token })
  const preloadedAllLineOfBusinessFees = await preloadQuery(api.groups.getAllGroupFees, { groupId: id }, { token })
  const preloadedAppliedDivisions = await preloadQuery(api.groups.getAppliedDivisions, { groupId: id }, { token })

  return (
    <Suspense fallback={<LineOfBusinessDetailSkeleton />}>
      <LineOfBusinessDetailClient
        preloadedLineOfBusiness={preloadedLineOfBusiness}
        preloadedAllLineOfBusinessFees={preloadedAllLineOfBusinessFees}
        preloadedAppliedDivisions={preloadedAppliedDivisions}
        lineOfBusinessId={id}
      />
    </Suspense>
  )
}

function LineOfBusinessDetailSkeleton() {
  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center space-x-4">
        <Skeleton className="h-8 w-8" />
        <Skeleton className="h-9 w-[300px]" />
      </div>
      <Skeleton className="h-[200px] w-full" />
      <Skeleton className="h-[300px] w-full" />
      <Skeleton className="h-[500px] w-full" />
    </div>
  )
}
