"use client";

import { useState, useCallback, useMemo, useRef, useEffect } from "react";
import { usePreloadedQuery, useQuery } from "convex/react";
import type { Preloaded } from "convex/react";
import { Search, Download, Loader2, Activity } from "lucide-react";

import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";

import { api } from "@repo/backend/convex/_generated/api";
import { useDebouncedValue } from "@/hooks/use-debounced-value";
import {
  convertToCSV,
  downloadCSV,
  generateExportFilename,
  formatDateForCSV,
  type CSVColumn,
} from "@/lib/utils/csv-export";
import { PermissionGuard } from "@/components/permission-guard";
import { ActivityTable } from "@/components/activity/activity-table";
import { ActivityFiltersSidebar } from "@/components/activity/activity-filters-sidebar";
import { ActivityHistogram } from "@/components/activity/activity-histogram";

import type { Id, Doc } from "@repo/backend/convex/_generated/dataModel";

// Type for activity log
type ActivityLog = Doc<"activity_logs">;

// Filter state
export interface ActivityFilters {
  actions: string[];
  resourceTypes: string[];
  performerIds: string[];
  dateFrom: Date | undefined;
  dateTo: Date | undefined;
  timelinePreset: "all" | "hour" | "today" | "week" | "month";
}

const defaultFilters: ActivityFilters = {
  actions: [],
  resourceTypes: [],
  performerIds: [],
  dateFrom: undefined,
  dateTo: undefined,
  timelinePreset: "all",
};

interface ActivityClientProps {
  preloadedLogs: Preloaded<typeof api.activityLogs.listPaginated>;
  preloadedFacets: Preloaded<typeof api.activityLogs.getFilterFacets>;
  preloadedHistogram: Preloaded<typeof api.activityLogs.getHistogramData>;
}

export default function ActivityClient({
  preloadedLogs,
  preloadedFacets,
  preloadedHistogram,
}: ActivityClientProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState<ActivityFilters>(defaultFilters);
  const [cursor, setCursor] = useState<number | undefined>(undefined);
  const [accumulatedLogs, setAccumulatedLogs] = useState<ActivityLog[]>([]);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  // Observer ref for infinite scroll
  const observerRef = useRef<IntersectionObserver | null>(null);
  const loadMoreRef = useRef<HTMLDivElement>(null);

  // Debounce search query
  const debouncedSearch = useDebouncedValue(searchQuery, 300);

  // Use preloaded data for SSR
  const preloadedLogsData = usePreloadedQuery(preloadedLogs);
  const preloadedFacetsData = usePreloadedQuery(preloadedFacets);
  const preloadedHistogramData = usePreloadedQuery(preloadedHistogram);

  // Build filter arguments
  const filterArgs = useMemo(() => {
    const args: {
      cursor?: number;
      pageSize: number;
      actions?: string[];
      resourceTypes?: string[];
      performerIds?: Id<"users">[];
      dateFrom?: number;
      dateTo?: number;
    } = { pageSize: 50 };

    if (filters.actions.length > 0) args.actions = filters.actions;
    if (filters.resourceTypes.length > 0)
      args.resourceTypes = filters.resourceTypes;
    if (filters.performerIds.length > 0)
      args.performerIds = filters.performerIds as Id<"users">[];
    if (filters.dateFrom) args.dateFrom = filters.dateFrom.getTime();
    if (filters.dateTo) args.dateTo = filters.dateTo.getTime();

    return args;
  }, [filters]);

  // Whether any filter beyond default pageSize is active
  const hasActiveFilters = Object.keys(filterArgs).length > 1;

  // Track filter changes to reset pagination
  const filterSignature = useMemo(
    () => JSON.stringify(filterArgs),
    [filterArgs]
  );

  // Reset accumulated logs when filters change
  useEffect(() => {
    setAccumulatedLogs([]);
    setCursor(undefined);
    setIsLoadingMore(false);
  }, [filterSignature]);

  // Query for paginated results (filtered first page OR additional pages)
  const paginatedResults = useQuery(
    api.activityLogs.listPaginated,
    hasActiveFilters || cursor !== undefined
      ? { ...filterArgs, ...(cursor !== undefined ? { cursor } : {}) }
      : "skip"
  );

  // Search query
  const searchResults = useQuery(
    api.activityLogs.search,
    debouncedSearch.length >= 2
      ? {
          query: debouncedSearch,
          actions: filters.actions.length > 0 ? filters.actions : undefined,
          resourceTypes:
            filters.resourceTypes.length > 0
              ? filters.resourceTypes
              : undefined,
          performerIds:
            filters.performerIds.length > 0
              ? (filters.performerIds as Id<"users">[])
              : undefined,
          dateFrom: filters.dateFrom
            ? filters.dateFrom.getTime()
            : undefined,
          dateTo: filters.dateTo
            ? filters.dateTo.getTime()
            : undefined,
        }
      : "skip"
  );

  // Query for histogram with filters
  const filteredHistogram = useQuery(
    api.activityLogs.getHistogramData,
    Object.keys(filterArgs).length > 1
      ? {
          dateFrom: filterArgs.dateFrom,
          dateTo: filterArgs.dateTo,
          actions: filterArgs.actions,
          resourceTypes: filterArgs.resourceTypes,
          performerIds: filterArgs.performerIds,
        }
      : "skip"
  );

  // Initialize with preloaded data (only when no filters active)
  useEffect(() => {
    if (preloadedLogsData && accumulatedLogs.length === 0 && !hasActiveFilters) {
      setAccumulatedLogs(preloadedLogsData.page);
    }
  }, [preloadedLogsData, accumulatedLogs.length, hasActiveFilters]);

  // Process paginated results (first page or additional pages)
  useEffect(() => {
    if (paginatedResults) {
      if (cursor === undefined) {
        // First page of filtered results — replace accumulated logs
        setAccumulatedLogs(paginatedResults.page);
      } else {
        // Additional pages — append new items
        setAccumulatedLogs((prev) => {
          const existingIds = new Set(prev.map((l) => l._id));
          const newItems = paginatedResults.page.filter(
            (l: ActivityLog) => !existingIds.has(l._id)
          );
          return [...prev, ...newItems];
        });
      }
      setIsLoadingMore(false);
    }
  }, [paginatedResults, cursor]);

  // Determine which data to display
  const displayLogs = useMemo(() => {
    // If searching, use search results
    if (debouncedSearch.length >= 2 && searchResults) {
      return searchResults;
    }

    // When filters are active, only show filtered results (never fall back to unfiltered preloaded data)
    if (hasActiveFilters) {
      return accumulatedLogs;
    }

    // Otherwise use paginated data
    if (accumulatedLogs.length > 0) {
      return accumulatedLogs;
    }

    // Fall back to preloaded data (no filters active)
    return preloadedLogsData?.page ?? [];
  }, [debouncedSearch, searchResults, accumulatedLogs, preloadedLogsData, hasActiveFilters]);

  // Loading state for filter/search transitions
  const isFilterLoading =
    (hasActiveFilters && paginatedResults === undefined && cursor === undefined) ||
    (debouncedSearch.length >= 2 && searchResults === undefined);

  // Determine if there are more pages
  const hasMore = useMemo(() => {
    if (debouncedSearch.length >= 2) return false;
    if (paginatedResults) return paginatedResults.hasMore;
    return preloadedLogsData?.hasMore ?? false;
  }, [debouncedSearch, paginatedResults, preloadedLogsData]);

  // Histogram data
  const histogramData = useMemo(() => {
    if (Object.keys(filterArgs).length > 1 && filteredHistogram) {
      return filteredHistogram;
    }
    return preloadedHistogramData;
  }, [filterArgs, filteredHistogram, preloadedHistogramData]);

  // Load more handler
  const loadMore = useCallback(() => {
    if (isLoadingMore || !hasMore || debouncedSearch.length >= 2) return;

    const lastLog = displayLogs[displayLogs.length - 1];
    if (lastLog) {
      setIsLoadingMore(true);
      setCursor(lastLog.timestamp);
    }
  }, [isLoadingMore, hasMore, debouncedSearch, displayLogs]);

  // Setup intersection observer for infinite scroll
  useEffect(() => {
    if (observerRef.current) observerRef.current.disconnect();

    observerRef.current = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !isLoadingMore) {
          loadMore();
        }
      },
      { threshold: 0.1 }
    );

    if (loadMoreRef.current) {
      observerRef.current.observe(loadMoreRef.current);
    }

    return () => observerRef.current?.disconnect();
  }, [hasMore, isLoadingMore, loadMore]);

  // Export handler
  const handleExport = useCallback(async () => {
    setIsExporting(true);

    try {
      const columns: CSVColumn<ActivityLog>[] = [
        {
          header: "Timestamp",
          accessor: (log) => formatDateForCSV(new Date(log.timestamp)),
        },
        { header: "Action", accessor: (log) => log.action },
        { header: "Performer", accessor: (log) => log.performerName },
        { header: "Description", accessor: (log) => log.description },
        { header: "Resource Type", accessor: (log) => log.resourceType },
        { header: "Resource ID", accessor: (log) => log.resourceId },
        { header: "Resource Label", accessor: (log) => log.resourceLabel },
        {
          header: "Changes",
          accessor: (log) => {
            if (!log.changes) return "";
            try {
              const parsed = JSON.parse(log.changes) as Record<string, { before?: unknown; after: unknown }>;
              return Object.entries(parsed)
                .map(([field, { before, after }]) => `${field}: ${before ?? "—"} → ${after}`)
                .join("; ");
            } catch {
              return "";
            }
          },
        },
      ];

      const csv = convertToCSV(displayLogs, columns);
      const filename = generateExportFilename("activity-logs");
      downloadCSV(csv, filename);
    } finally {
      setIsExporting(false);
    }
  }, [displayLogs]);

  // Filter change handler
  const handleFiltersChange = useCallback((newFilters: ActivityFilters) => {
    setFilters(newFilters);
  }, []);

  // Clear filters handler
  const handleClearFilters = useCallback(() => {
    setFilters(defaultFilters);
    setSearchQuery("");
  }, []);

  // Calculate active filter count
  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (filters.actions.length > 0) count++;
    if (filters.resourceTypes.length > 0) count++;
    if (filters.performerIds.length > 0) count++;
    if (filters.dateFrom || filters.dateTo) count++;
    return count;
  }, [filters]);

  return (
    <PermissionGuard resource="activity_logs" action="read">
      <div className="flex h-full">
        {/* Filters Sidebar */}
        <ActivityFiltersSidebar
          filters={filters}
          onFiltersChange={handleFiltersChange}
          onClearFilters={handleClearFilters}
          facets={preloadedFacetsData}
          activeFilterCount={activeFilterCount}
        />

        {/* Main Content */}
        <div className="flex-1 p-6 space-y-4 overflow-auto">
          {/* Header - Compact layout */}
          <div className="flex items-center justify-between">
            <div className="relative w-72">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search logs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                size="sm"
                onClick={handleExport}
                disabled={isExporting || displayLogs.length === 0}
              >
                {isExporting ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <Download className="h-4 w-4 mr-2" />
                )}
                Export
              </Button>
              <span className="text-sm text-muted-foreground">
                {debouncedSearch.length >= 2
                  ? `Results: ${displayLogs.length}`
                  : `Showing ${displayLogs.length} logs`}
                {activeFilterCount > 0 && ` (${activeFilterCount} filters)`}
              </span>
            </div>
          </div>

          {/* Histogram - No card wrapper */}
          <div className="border rounded-lg p-4">
            <ActivityHistogram data={histogramData} isLoading={isFilterLoading} />
          </div>

          {/* Table - Minimal wrapper */}
          <div className="border rounded-lg">
            {isFilterLoading ? (
              <div className="flex flex-col items-center justify-center py-16">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                <p className="mt-3 text-sm text-muted-foreground">
                  Loading filtered results...
                </p>
              </div>
            ) : (
              <>
                <ActivityTable logs={displayLogs} />

                {/* Load more trigger */}
                <div ref={loadMoreRef} className="h-4" />

                {/* Loading indicator */}
                {isLoadingMore && (
                  <div className="flex justify-center py-4">
                    <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                  </div>
                )}

                {/* End of list */}
                {!hasMore && displayLogs.length > 0 && !debouncedSearch && (
                  <p className="text-center text-sm text-muted-foreground py-4">
                    No more activities to load
                  </p>
                )}

                {/* Empty state */}
                {displayLogs.length === 0 && (
                  <div className="text-center py-12">
                    <Activity className="h-12 w-12 mx-auto text-muted-foreground/50" />
                    <h3 className="mt-4 text-lg font-medium">No activities found</h3>
                    <p className="text-muted-foreground mt-1">
                      {debouncedSearch
                        ? "Try a different search term"
                        : activeFilterCount > 0
                          ? "Try adjusting your filters"
                          : "Activities will appear here as users make changes"}
                    </p>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </PermissionGuard>
  );
}
