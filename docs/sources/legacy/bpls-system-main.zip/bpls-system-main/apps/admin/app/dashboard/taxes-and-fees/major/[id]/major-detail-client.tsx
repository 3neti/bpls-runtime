"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { usePreloadedQuery, useMutation } from "convex/react"
import type { Preloaded } from "convex/react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { ArrowLeft, Eye, Pencil, Trash2, Plus } from "lucide-react"
import { usePermissions } from "@/hooks/use-permissions"
import { PermissionGuard } from "@/components/permission-guard"
import { PermissionDenied } from "@/components/permission-error-states"
import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"
import { Input } from "@repo/ui/components/input"
import { Textarea } from "@repo/ui/components/textarea"
import { useToast } from "@/hooks/use-toast"
import { majorFormSchema, type MajorFormSchema } from "@/lib/schemas/major-form"

interface MajorDetailClientProps {
  preloadedMajor: Preloaded<typeof api.majors.getWithDivisions>
  majorId: Id<"majors">
}

export function MajorDetailClient({ preloadedMajor, majorId }: MajorDetailClientProps) {
  const router = useRouter()
  const { toast } = useToast()
  const { canCreate, canUpdate, canDelete, isLoading: permissionsLoading } = usePermissions()

  // Permission checks for major
  const hasUpdatePermission = canUpdate("taxes_and_fees:major")
  const hasDeletePermission = canDelete("taxes_and_fees:major")
  // Permission check for division (for Add Division button)
  const hasCreateDivisionPermission = canCreate("taxes_and_fees:division")

  const majorResult = usePreloadedQuery(preloadedMajor)
  const majorData = majorResult.success ? majorResult.data : null

  const updateMajor = useMutation(api.majors.update)
  const deleteMajor = useMutation(api.majors.remove)

  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)

  const form = useForm<MajorFormSchema>({
    resolver: zodResolver(majorFormSchema),
    defaultValues: {
      name: majorData?.name || "",
      description: majorData?.description || "",
    },
  })

  if (!majorData) {
    return (
      <div className="flex-1 space-y-4 p-4 pt-6">
        <div className="text-center py-8">
          <h2 className="text-2xl font-bold">Major not found</h2>
          <p className="text-muted-foreground mt-2">The major you are looking for does not exist.</p>
          <Button onClick={() => router.back()} className="mt-4">
            Go Back
          </Button>
        </div>
      </div>
    )
  }

  const handleUpdateMajor = async (values: MajorFormSchema) => {
    try {
      const result = await updateMajor({
        majorId,
        ...values,
      })

      if (result.success) {
        toast({
          title: "Success",
          description: `Major "${values.name}" has been updated successfully.`,
        })
        setIsEditDialogOpen(false)
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to update major",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to update major:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update major. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteMajor = async () => {
    try {
      const result = await deleteMajor({ majorId })

      if (result.success) {
        toast({
          title: "Success",
          description: "Major has been deleted successfully.",
        })
        router.push("/dashboard/taxes-and-fees/major")
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to delete major",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to delete major:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete major. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <PermissionGuard
      resource="taxes_and_fees:major"
      action="read"
      showLoading
      fallback={
        <PermissionDenied
          title="Major Details"
          description="View major category details"
          resourceName="major"
          backLink="/dashboard/taxes-and-fees/major"
          backLinkText="Back to Majors"
        />
      }
    >
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center space-x-4">
        <Button variant="ghost" size="sm" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold tracking-tight">{majorData.name}</h1>
          <p className="text-muted-foreground">Major category details and divisions</p>
        </div>
        <div className="flex items-center space-x-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={hasUpdatePermission ? -1 : 0}>
                  <Button
                    variant="outline"
                    disabled={!hasUpdatePermission || permissionsLoading}
                    onClick={() => setIsEditDialogOpen(true)}
                  >
                    <Pencil className="mr-2 h-4 w-4" />
                    Edit
                  </Button>
                </span>
              </TooltipTrigger>
              {!hasUpdatePermission && !permissionsLoading && (
                <TooltipContent>
                  <p>You don't have permission to edit majors</p>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={hasDeletePermission ? -1 : 0}>
                  <Button
                    variant="destructive"
                    disabled={!hasDeletePermission || permissionsLoading}
                    onClick={() => setIsDeleteDialogOpen(true)}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete
                  </Button>
                </span>
              </TooltipTrigger>
              {!hasDeletePermission && !permissionsLoading && (
                <TooltipContent>
                  <p>You don't have permission to delete majors</p>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      {/* Major Details Card */}
      <Card>
        <CardHeader>
          <CardTitle>Major Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Name</p>
              <p className="text-lg font-semibold">{majorData.name}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Description</p>
              <p className="text-sm">{majorData.description}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Divisions Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Divisions</CardTitle>
            <CardDescription>
              Divisions belonging to this major ({majorData.divisions?.length || 0})
            </CardDescription>
          </div>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={hasCreateDivisionPermission ? -1 : 0}>
                  <Button
                    disabled={!hasCreateDivisionPermission || permissionsLoading}
                    onClick={() => router.push(`/dashboard/taxes-and-fees/division?majorId=${majorId}`)}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add Division
                  </Button>
                </span>
              </TooltipTrigger>
              {!hasCreateDivisionPermission && !permissionsLoading && (
                <TooltipContent>
                  <p>You don't have permission to create divisions</p>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
        </CardHeader>
        <CardContent>
          {majorData.divisions && majorData.divisions.length > 0 ? (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {majorData.divisions.map((division: (typeof majorData.divisions)[number]) => (
                    <TableRow
                      key={division._id}
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => router.push(`/dashboard/taxes-and-fees/division/${division._id}`)}
                    >
                      <TableCell className="font-medium">{division.name}</TableCell>
                      <TableCell className="max-w-md truncate">{division.description}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    router.push(`/dashboard/taxes-and-fees/division/${division._id}`)
                                  }}
                                >
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>View Division</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              No divisions yet. Click "Add Division" to get started.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Major</DialogTitle>
            <DialogDescription>Update the major category details</DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleUpdateMajor)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Dealer, Retailer, Manufacturer" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Describe this major category..."
                        className="resize-none"
                        rows={4}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={form.formState.isSubmitting}>
                  {form.formState.isSubmitting ? "Updating..." : "Update Major"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Major</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this major? This action cannot be undone. All associated divisions will also be affected.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteMajor}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
    </PermissionGuard>
  )
}
