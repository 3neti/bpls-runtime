import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import FeesClient from "./fees-client"

export default async function FeesPage() {
  const token = await convexAuthNextjsToken()

  const preloadedFeeNames = await preloadQuery(api.feeNames.list, {}, { token })

  return <FeesClient preloadedFeeNames={preloadedFeeNames} />
}
