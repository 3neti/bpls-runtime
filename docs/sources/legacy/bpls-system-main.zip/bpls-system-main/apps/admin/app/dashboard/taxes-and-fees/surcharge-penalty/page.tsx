import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import SurchargePenaltyClient from "./surcharge-penalty-client"

export default async function SurchargePenaltyPage() {
  const token = await convexAuthNextjsToken()

  const preloadedConfig = await preloadQuery(api.surchargeConfig.getWithDefaults, {}, { token })

  return <SurchargePenaltyClient preloadedConfig={preloadedConfig} />
}
