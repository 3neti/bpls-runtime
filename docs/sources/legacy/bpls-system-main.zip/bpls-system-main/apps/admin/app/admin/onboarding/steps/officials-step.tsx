"use client";

import { useFormContext } from "react-hook-form";
import { User, Briefcase } from "lucide-react";
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
  FormDescription,
} from "@repo/ui/components/form";
import { Input } from "@repo/ui/components/input";
import { Card, CardContent } from "@repo/ui/components/card";
import type { OnboardingData } from "@/lib/schemas/onboarding";

export function OfficialsStep() {
  const form = useFormContext<OnboardingData>();
  const mayorName = form.watch("mayorName");
  const mayorTitle = form.watch("mayorTitle");
  const treasurerName = form.watch("treasurerName");
  const treasurerTitle = form.watch("treasurerTitle");

  return (
    <div className="grid md:grid-cols-2 gap-6">
      {/* Form Fields */}
      <div className="space-y-6">
        {/* Mayor Section */}
        <div className="space-y-4">
          <h4 className="text-sm font-medium flex items-center gap-2">
            <User className="h-4 w-4" />
            Mayor Information
          </h4>

          <FormField
            control={form.control}
            name="mayorName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Mayor's Full Name</FormLabel>
                <FormControl>
                  <Input
                    placeholder="e.g., JUAN DELA CRUZ"
                    {...field}
                  />
                </FormControl>
                <FormDescription>
                  Name as it appears on official documents
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="mayorTitle"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Mayor's Title</FormLabel>
                <FormControl>
                  <Input placeholder="e.g., Municipal Mayor" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        {/* Treasurer Section */}
        <div className="space-y-4">
          <h4 className="text-sm font-medium flex items-center gap-2">
            <Briefcase className="h-4 w-4" />
            Treasurer Information
          </h4>

          <FormField
            control={form.control}
            name="treasurerName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Treasurer's Full Name</FormLabel>
                <FormControl>
                  <Input
                    placeholder="e.g., MARIA SANTOS"
                    {...field}
                  />
                </FormControl>
                <FormDescription>
                  Name as it appears on assessment sheets
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="treasurerTitle"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Treasurer's Title</FormLabel>
                <FormControl>
                  <Input placeholder="e.g., Municipal Treasurer" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
      </div>

      {/* Preview */}
      <div className="space-y-4">
        <h4 className="text-sm font-medium text-muted-foreground">Preview</h4>

        {/* Mayor Signature Block */}
        <Card className="bg-muted/30">
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground mb-3">Permit Signature Block:</p>
            <div className="text-center">
              <div className="border-t border-foreground w-48 mx-auto mb-2" />
              <p className="text-sm font-bold">
                {mayorName || "MAYOR NAME"}
              </p>
              <p className="text-xs text-muted-foreground">
                {mayorTitle || "Municipal Mayor"}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Authorizing Official
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Treasurer Signature Block */}
        <Card className="bg-muted/30">
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground mb-3">Assessment Sheet Approver:</p>
            <div className="text-center">
              <div className="border-t border-foreground w-48 mx-auto mb-2" />
              <p className="text-sm font-bold">
                {treasurerName || "TREASURER NAME"}
              </p>
              <p className="text-xs text-muted-foreground">
                {treasurerTitle || "Municipal Treasurer"}
              </p>
            </div>
          </CardContent>
        </Card>

        <p className="text-xs text-muted-foreground text-center">
          These names will appear on official permits, receipts, and assessment documents.
        </p>
      </div>
    </div>
  );
}
