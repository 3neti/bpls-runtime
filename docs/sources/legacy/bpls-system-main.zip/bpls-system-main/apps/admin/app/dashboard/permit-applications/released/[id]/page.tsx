import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { ConvexError } from "convex/values"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"

import { ReleasedDetailClient } from "./released-detail-client"

interface PageProps {
  params: Promise<{
    id: string
  }>
}

export default async function ApplicationDetailsPage({ params }: PageProps) {
  const { id } = await params
  const applicationId = id as Id<"business_permit_applications">
  const token = await convexAuthNextjsToken()

  try {
    // Preload application, groups, and activity logs data from Convex with authentication
    const [preloadedApplication, preloadedGroups, preloadedActivityLogs] = await Promise.all([
      preloadQuery(
        api.businessPermitApplications.getById,
        { id: applicationId },
        { token }
      ),
      preloadQuery(
        api.groups.list,
        {},
        { token }
      ),
      preloadQuery(
        api.activityLogs.getResourceHistory,
        { resourceType: "permit_application", resourceId: applicationId, limit: 20 },
        { token }
      ),
    ])

    return (
      <ReleasedDetailClient
        preloadedApplication={preloadedApplication}
        preloadedGroups={preloadedGroups}
        preloadedActivityLogs={preloadedActivityLogs}
        applicationId={applicationId}
      />
    )
  } catch (error) {
    if (error instanceof ConvexError) {
      const errorData = error.data as {
        code?: string
        message?: string
        details?: {
          resource?: string
          action?: string
          userRole?: string
          requiredPermission?: string
        }
      }

      if (errorData.code === "PERMISSION_DENIED") {
        return (
          <PermissionDenied
            title="Released Application Details"
            description="View released permit application information"
            message={errorData.message}
            details={errorData.details}
            resourceName="permit application"
            backLink="/dashboard/permit-applications"
            backLinkText="Back to Permit Applications"
          />
        )
      }

      if (errorData.code === "UNAUTHENTICATED") {
        return <AuthenticationRequired />
      }
    }

    throw error
  }
}
