import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { BillingGroupDetailClient } from "./billing-group-detail-client"

interface BillingGroupDetailPageProps {
  params: Promise<{ id: string }>
}

/**
 * Billing Group Detail Page (Server Component)
 *
 * Admin interface for managing a specific billing group's records,
 * line items, custom fields, and receipt templates.
 *
 * Features:
 * - View billing group summary statistics
 * - Manage records and transactions
 * - Configure line items in the fee library
 * - Set up custom fields for additional data capture
 * - Customize receipt print templates
 *
 * Architecture:
 * - Server-side rendering with preloaded Convex queries
 * - Loading state handled by loading.tsx skeleton
 * - Client interactions delegated to BillingGroupDetailClient component
 */
export default async function BillingGroupDetailPage({ params }: BillingGroupDetailPageProps) {
  const { id } = await params
  const billingGroupId = id as Id<"billing_groups">
  const token = await convexAuthNextjsToken()

  // Preload billing group data, summary, and fees on the server
  const [preloadedBillingGroup, preloadedSummary, preloadedFees] = await Promise.all([
    preloadQuery(
      api.billingGroups.getById,
      { id: billingGroupId },
      { token }
    ),
    preloadQuery(
      api.billingGroupRecords.getSummary,
      { billingGroupId },
      { token }
    ),
    preloadQuery(
      api.billingGroupFees.listByGroup,
      { billingGroupId, includeInactive: false },
      { token }
    ),
  ])

  return (
    <BillingGroupDetailClient
      billingGroupId={billingGroupId}
      preloadedBillingGroup={preloadedBillingGroup}
      preloadedSummary={preloadedSummary}
      preloadedFees={preloadedFees}
    />
  )
}
