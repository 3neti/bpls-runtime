"use client"

import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import Link from "next/link"
import { usePreloadedQuery, useQuery, useMutation } from "convex/react"
import { useForm, useFieldArray } from "react-hook-form"

import { Button } from "@repo/ui/components/button"
import { Card, CardContent } from "@repo/ui/components/card"
import { Alert, AlertDescription, AlertTitle } from "@repo/ui/components/alert"
import { ArrowLeft, Loader2, Lock, CheckCircle, AlertCircle } from "lucide-react"
import { usePermissions } from "@/hooks/use-permissions"
import { useToast } from "@/hooks/use-toast"

import { PermitApplicationHeader } from "@/components/permit/permit-application-header"
import { BusinessOwnerCard } from "@/components/permit/business-owner-card"
import { BusinessInfoCard } from "@/components/permit/business-info-card"
import { DocumentsCard } from "@/components/permit/documents-card"
import { ModeOfPaymentCard } from "@/components/permit/mode-of-payment-card"
import { PermitTransactionTypeCard } from "@/components/permit/permit-transaction-type-card"
import { UnitsOfMeasurementReadonlyCard } from "@/components/permit/units-of-measurement-readonly-card"
import {
  LOBConfigurationCard,
  type FeeOverride,
  type FeeExclusion,
  type AggregatedFeeSummary,
} from "@/components/permit/lob-configuration-card"
import { ScheduleOfPaymentsCard } from "@/components/permit/schedule-of-payments-card"
import { ApplicationTimelineCard } from "@/components/permit/application-timeline-card"
import { BplsFormsCard } from "@/components/permit/bpls-forms-card"
import { ClearancesChecklistCard } from "@/components/permit/clearances-checklist-card"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import type { Preloaded } from "convex/react"

interface LineOfBusiness {
  id: string
  businessCategory: string
  groupId: any
  capitalInvestment: string
  grossSales: string
  permitApplicationType: "New" | "Renewal"
  numberOfEmployees?: number
  excludedFees?: any[]
  feeVariableMappings?: any[]
}

interface AssessmentFormValues {
  linesOfBusiness: LineOfBusiness[]
}

interface ReleasedDetailClientProps {
  preloadedApplication: Preloaded<typeof api.businessPermitApplications.getById>
  preloadedGroups: Preloaded<typeof api.groups.list>
  preloadedActivityLogs: Preloaded<typeof api.activityLogs.getResourceHistory>
  applicationId: Id<"business_permit_applications">
}

export function ReleasedDetailClient({
  preloadedApplication,
  preloadedGroups,
  preloadedActivityLogs,
  applicationId,
}: ReleasedDetailClientProps) {
  const applicationData = usePreloadedQuery(preloadedApplication)

  // Query location names for business
  const businessLocationData = useQuery(
    api.locations.getLocationHierarchy,
    applicationData?.business?.provinceId
      ? {
          provinceId: applicationData.business.provinceId,
          cityId: applicationData.business.cityId,
          barangayId: applicationData.business.barangayId,
        }
      : "skip"
  )

  // Query location names for business owner
  const ownerLocationData = useQuery(
    api.locations.getLocationHierarchy,
    applicationData?.businessOwner?.provinceId
      ? {
          provinceId: applicationData.businessOwner.provinceId,
          cityId: applicationData.businessOwner.cityId,
          barangayId: applicationData.businessOwner.barangayId,
        }
      : "skip"
  )

  // Query clearance progress for timeline
  const progressSummary = useQuery(api.permitClearances.getProgressSummary, {
    applicationId,
  })

  // Calculate clearance completion status for timeline
  const allClearancesCompleted = progressSummary
    ? progressSummary.completed === progressSummary.total && progressSummary.total > 0
    : false

  // Use preloaded groups list to resolve businessCategory names to group IDs
  const groupsResult = usePreloadedQuery(preloadedGroups)
  const groups = groupsResult?.success ? groupsResult.data : []

  // Form setup for LOBConfigurationCard (read-only mode)
  const form = useForm<AssessmentFormValues>({
    defaultValues: { linesOfBusiness: [] },
  })
  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "linesOfBusiness",
  })

  // Fee state management
  const [feeOverrides, setFeeOverrides] = useState<FeeOverride[]>([])
  const [feeExclusions, setFeeExclusions] = useState<FeeExclusion[]>([])
  const [aggregatedFees, setAggregatedFees] = useState<AggregatedFeeSummary[]>([])

  // Auto-save state
  const [autoSaveStatus, setAutoSaveStatus] = useState<"idle" | "saving" | "saved" | "error">("idle")
  const [autoSaveError, setAutoSaveError] = useState<string | null>(null)
  const autoSaveTimerRef = useRef<NodeJS.Timeout | null>(null)
  const debouncedAutoSaveRef = useRef<NodeJS.Timeout | null>(null)

  const { toast } = useToast()

  // Mutation for saving LOB configuration (only used with override permission)
  const updateLOBConfiguration = useMutation(api.businessPermitApplications.updateLOBConfiguration)

  // Initialize LOB form data from application (wait for groups to resolve IDs)
  const hasInitializedLOBs = useRef<string | null>(null)
  useEffect(() => {
    if (applicationData?.linesOfBusiness && applicationId && groups && groups.length > 0) {
      if (hasInitializedLOBs.current !== applicationId) {
        const initialLOBs = applicationData.linesOfBusiness.map((lob: any, idx: number) => {
          const group = groups.find((g: any) => g.name === lob.businessCategory)

          const excludedFeeIds = (lob.excludedFees || [])
            .map((ef: any) => (typeof ef === "object" && ef.feeId ? ef.feeId : ef))
            .filter((id: any): id is Id<"fees"> => id !== undefined && id !== null)

          return {
            id: `released-${applicationId}-${idx}`,
            businessCategory: lob.businessCategory || "",
            groupId: group?._id || null,
            capitalInvestment: lob.capitalInvestment || "",
            grossSales: lob.grossSales || lob.businessAnnualRevenue || "",
            permitApplicationType: (lob.permitApplicationType || "New") as "New" | "Renewal",
            numberOfEmployees: lob.numberOfEmployees,
            excludedFees: excludedFeeIds,
            feeVariableMappings: lob.feeVariableMappings || [],
          }
        })
        form.reset({ linesOfBusiness: initialLOBs })

        // Initialize fee overrides from application data
        if (applicationData.feeOverrides && applicationData.feeOverrides.length > 0) {
          setFeeOverrides(applicationData.feeOverrides as FeeOverride[])
        } else {
          setFeeOverrides([])
        }

        // Initialize fee exclusions from application data
        const allExclusions: FeeExclusion[] = []
        applicationData.linesOfBusiness.forEach((lob: any, idx: number) => {
          const lobId = `released-${applicationId}-${idx}`
          if (lob.excludedFees && lob.excludedFees.length > 0) {
            lob.excludedFees.forEach((exclusion: any) => {
              const feeId = typeof exclusion === "string" ? exclusion : exclusion?.feeId
              const feeName = typeof exclusion === "string" ? "Disabled Fee" : (exclusion?.feeName || "Disabled Fee")
              const excludedAmount = typeof exclusion === "string" ? 0 : (exclusion?.excludedAmount || 0)
              if (feeId) {
                allExclusions.push({ lobId, feeId, feeName, excludedAmount })
              }
            })
          }
        })
        setFeeExclusions(allExclusions)

        hasInitializedLOBs.current = applicationId
      }
    }
  }, [applicationData, applicationId, form, groups])

  // Calculate total employees from business data (not from LOBs)
  const totalEmployees = useMemo(() => {
    if (!applicationData?.business) return 0
    return applicationData.business.maleEmployeeCount + applicationData.business.femaleEmployeeCount
  }, [applicationData])

  // Permission checks
  const { canUpdate, isLoading: permissionsLoading } = usePermissions()
  const canUpdateApplication = canUpdate("permit_applications")
  const canOverrideFees = canUpdate("permit_applications:fees_override" as any)
  const canUpdateStatus = canUpdate("permit_applications:status_update" as any)

  // Sequential save queue: prevents race conditions when saves overlap
  const isSavingRef = useRef(false)
  const pendingSaveRef = useRef(false)

  // Auto-save: builds payload and calls mutation
  const triggerAutoSave = useCallback(async () => {
    const formValues = form.getValues()
    if (formValues.linesOfBusiness.length === 0 || !canOverrideFees) return

    // If a save is already in-flight, mark as pending and return
    if (isSavingRef.current) {
      pendingSaveRef.current = true
      return
    }

    isSavingRef.current = true
    if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current)
    setAutoSaveStatus("saving")
    setAutoSaveError(null)

    try {
      const currentLOBs = formValues.linesOfBusiness
      const lobsForSave = currentLOBs.map((lob) => {
        const lobExclusions = feeExclusions.filter((e) => e.lobId === lob.id)

        const lobData: {
          businessCategory: string
          capitalInvestment: string
          grossSales: string
          permitApplicationType: string
          numberOfEmployees?: number
          excludedFees?: Id<"fees">[]
          feeVariableMappings?: any[]
        } = {
          businessCategory: lob.businessCategory,
          capitalInvestment: lob.capitalInvestment,
          grossSales: lob.grossSales,
          permitApplicationType: lob.permitApplicationType,
        }

        if (lob.numberOfEmployees !== undefined && lob.numberOfEmployees !== null) {
          lobData.numberOfEmployees = lob.numberOfEmployees
        }

        if (lobExclusions.length > 0) {
          const validFeeIds = lobExclusions
            .map((e) => e.feeId)
            .filter((feeId): feeId is Id<"fees"> => feeId !== undefined && feeId !== null)
          if (validFeeIds.length > 0) {
            lobData.excludedFees = validFeeIds
          }
        }

        if (lob.feeVariableMappings && lob.feeVariableMappings.length > 0) {
          const validMappings = lob.feeVariableMappings.filter(
            (m: any) => m.feeId !== undefined && m.variableName !== undefined
          )
          if (validMappings.length > 0) {
            lobData.feeVariableMappings = validMappings
          }
        }

        return lobData
      })

      const feeOverridesForSave =
        feeOverrides.length > 0
          ? feeOverrides.map((override) => ({
              feeId: override.feeId,
              feeName: override.feeName,
              originalAmount: override.originalAmount,
              overriddenAmount: override.overriddenAmount,
              overriddenAt: new Date().toISOString(),
              overriddenBy: "Current User",
            }))
          : undefined

      await updateLOBConfiguration({
        id: applicationId,
        linesOfBusiness: lobsForSave,
        feeOverrides: feeOverridesForSave,
      })

      setAutoSaveStatus("saved")
      toast({ title: "Changes saved", description: "LOB configuration updated successfully." })
      autoSaveTimerRef.current = setTimeout(() => setAutoSaveStatus("idle"), 2000)
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to save. Please try again."
      setAutoSaveError(message)
      setAutoSaveStatus("error")
      toast({ title: "Save failed", description: message, variant: "destructive" })
    } finally {
      isSavingRef.current = false
      // If another save was requested while we were saving, re-trigger with latest state
      if (pendingSaveRef.current) {
        pendingSaveRef.current = false
        triggerAutoSaveRef.current()
      }
    }
  }, [form, feeOverrides, feeExclusions, applicationId, canOverrideFees, updateLOBConfiguration, toast])

  // Keep a ref to the latest triggerAutoSave to avoid stale closures in debounced calls
  const triggerAutoSaveRef = useRef(triggerAutoSave)
  useEffect(() => {
    triggerAutoSaveRef.current = triggerAutoSave
  }, [triggerAutoSave])

  // Debounced wrapper so rapid changes batch into a single save
  const handleAutoSaveRequest = useCallback(() => {
    if (debouncedAutoSaveRef.current) clearTimeout(debouncedAutoSaveRef.current)
    debouncedAutoSaveRef.current = setTimeout(() => {
      triggerAutoSaveRef.current()
    }, 300)
  }, [])

  // Cleanup timers on unmount
  useEffect(() => {
    return () => {
      if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current)
      if (debouncedAutoSaveRef.current) clearTimeout(debouncedAutoSaveRef.current)
    }
  }, [])

  // Loading state
  if (applicationData === undefined) {
    return (
      <div className="flex-1 flex items-center justify-center p-4 pt-6">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading application details...</p>
        </div>
      </div>
    )
  }

  // Not found state
  if (!applicationData) {
    return (
      <div className="flex-1 space-y-4 p-4 pt-6">
        <div className="flex items-center gap-4">
          <Link href="/dashboard/permit-applications/released">
            <Button variant="outline" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Releasing
            </Button>
          </Link>
        </div>
        <Card>
          <CardContent className="flex items-center justify-center py-8">
            <div className="text-center">
              <h3 className="text-lg font-semibold">Application Not Found</h3>
              <p className="text-muted-foreground">
                The application with ID "{applicationId}" could not be found.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Transform Convex data to match component expectations
  const application = {
    applicationNumber: applicationData.applicationNumber,
    status: applicationData.status.toLowerCase().replace(" ", "_"), // "Released" → "released"
    submittedOn: applicationData.submittedAt.split("T")[0], // Extract date from ISO string

    // Business Owner Information
    owner: applicationData.businessOwner ? {
      profilePhoto: applicationData.businessOwner.avatar || "/government-official-male.jpg",
      firstName: applicationData.businessOwner.firstName,
      middleName: applicationData.businessOwner.middleName || "",
      lastName: applicationData.businessOwner.lastName,
      fullName: `${applicationData.businessOwner.firstName} ${applicationData.businessOwner.middleName ? applicationData.businessOwner.middleName + " " : ""}${applicationData.businessOwner.lastName}`,
      birthDate: applicationData.businessOwner.birthDate,
      civilStatus: applicationData.businessOwner.civilStatus,
      gender: applicationData.businessOwner.gender,
      citizenship: applicationData.businessOwner.citizenship,
      tin: applicationData.businessOwner.tin,
      mobile: applicationData.businessOwner.mobile,
      email: applicationData.businessOwner.email,
      address: applicationData.businessOwner.address,
      provinceId: applicationData.businessOwner.provinceId,
      cityId: applicationData.businessOwner.cityId,
      barangayId: applicationData.businessOwner.barangayId,
      // New fields for link and owner details
      ownerId: applicationData.businessOwner._id,
      ownerType: applicationData.businessOwner.ownerType,
      groupName: applicationData.businessOwner.groupName,
    } : null,

    // Business Information
    business: applicationData.business ? {
      name: applicationData.business.name,
      dateEstablished: applicationData.business.establishedDate,
      ownershipType: applicationData.business.ownershipType,
      occupancy: applicationData.business.occupancy,
      permitPaymentCadence: applicationData.business.permitPaymentCadence,
      maleEmployeeCount: applicationData.business.maleEmployeeCount,
      femaleEmployeeCount: applicationData.business.femaleEmployeeCount,
      contactNumber: applicationData.business.contactNumber,
      email: applicationData.business.email,
      address: applicationData.business.address,
      provinceId: applicationData.business.provinceId,
      cityId: applicationData.business.cityId,
      barangayId: applicationData.business.barangayId,
      linesOfBusiness: [],
      // New fields for link and business details
      businessId: applicationData.business._id,
      registrationNumber: applicationData.business.registrationNumber,
      registrationDate: applicationData.business.registrationDate,
      propertyIndexNumber: applicationData.business.propertyIndexNumber,
      businessScale: applicationData.business.businessScale,
      annualRevenue: applicationData.business.annualRevenue ? Number(applicationData.business.annualRevenue) : undefined,
      dateStarted: applicationData.business.dateStarted,
      businessArea: applicationData.business.businessArea,
    } : null,

    // Prerequisites/Documents (mock data for now - to be implemented)
    prerequisites: {
      ownershipType: applicationData.business?.ownershipType.toLowerCase().replace(" ", "-") || "sole-proprietorship",
      documents: {
        applicationForm: { uploaded: true, fileName: "application-form.pdf" },
        barangayClearance: { uploaded: true, fileName: "barangay-clearance.pdf" },
        sanitaryPermit: { uploaded: true, fileName: "sanitary-permit.pdf" },
        fireSafetyInspection: { uploaded: true, fileName: "fire-safety.pdf" },
      },
    },
  }

  const handleApprove = () => {
    console.log("Approving application:", applicationId)
    // TODO: Implement approval logic
  }

  const handleReject = () => {
    console.log("Rejecting application:", applicationId)
    // TODO: Implement rejection logic
  }

  return (
    <div className="flex-1 space-y-6 p-4 pt-6">
      {/* Header */}
      <PermitApplicationHeader
        applicationNumber={application.applicationNumber}
        submittedOn={application.submittedOn}
        status={applicationData.status}
        backUrl="/dashboard/permit-applications/released"
        onApprove={canUpdateApplication && !permissionsLoading ? handleApprove : undefined}
        onReject={canUpdateApplication && !permissionsLoading ? handleReject : undefined}
        showActions={canUpdateApplication && !permissionsLoading}
        enableStatusEdit={canUpdateStatus && !permissionsLoading}
        applicationId={applicationId}
      />

      {/* Read-Only Alert */}
      {!canUpdateApplication && !permissionsLoading && (
        <Alert className="border-amber-500 bg-amber-50">
          <Lock className="h-4 w-4 text-amber-600" />
          <AlertTitle className="text-amber-900">Read-Only Access</AlertTitle>
          <AlertDescription className="text-amber-700">
            You don't have permission to update permit applications. You can view this application but cannot make changes.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Business Owner Information */}
          {application.owner && <BusinessOwnerCard owner={application.owner} />}

          {/* Business Information */}
          {application.business && (
            <BusinessInfoCard
              business={application.business}
              applicationId={applicationData._id}
            />
          )}

          {/* Permit Transaction Type (Read-only) */}
          <PermitTransactionTypeCard
            value={applicationData.permitApplicationType as "New" | "Renewal" | "Additional" | undefined}
            readonly={true}
          />

          {/* Mode of Payment (Read-only) */}
          <ModeOfPaymentCard
            value={applicationData.modeOfPayment || undefined}
            onChange={() => {}}
            readonly={true}
          />

          {/* Units of Measurement (Read-only) */}
          <UnitsOfMeasurementReadonlyCard applicationId={applicationId} />

          {/* Auto-save status */}
          {canOverrideFees && autoSaveStatus !== "idle" && (
            <div className="w-full">
              {autoSaveStatus === "saving" && (
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <Loader2 className="h-3 w-3 animate-spin" />
                  <span>Saving changes...</span>
                </div>
              )}
              {autoSaveStatus === "saved" && (
                <div className="flex items-center gap-1.5 text-sm text-green-600">
                  <CheckCircle className="h-3 w-3" />
                  <span>All changes saved</span>
                </div>
              )}
              {autoSaveStatus === "error" && (
                <div className="bg-destructive/10 border border-destructive/20 text-destructive rounded-md p-2.5 text-sm w-full">
                  <p className="font-semibold flex items-center gap-1.5">
                    <AlertCircle className="h-3.5 w-3.5" />
                    Failed to save
                  </p>
                  {autoSaveError && <p className="text-xs mt-1">{autoSaveError}</p>}
                </div>
              )}
            </div>
          )}

          {/* Lines of Business Configuration (Read-only unless user has fees override permission) */}
          <LOBConfigurationCard
            form={form}
            fields={fields}
            append={append}
            remove={remove}
            totalEmployees={totalEmployees}
            applicationId={applicationId}
            businessArea={applicationData?.business?.businessArea}
            maleEmployeeCount={applicationData?.business?.maleEmployeeCount}
            femaleEmployeeCount={applicationData?.business?.femaleEmployeeCount}
            onFeeOverridesChange={canOverrideFees ? setFeeOverrides : undefined}
            initialFeeOverrides={feeOverrides}
            onFeeExclusionsChange={canOverrideFees ? setFeeExclusions : undefined}
            initialFeeExclusions={feeExclusions}
            onAggregatedFeesChange={setAggregatedFees}
            disabled={!canOverrideFees}
            disabledReason={!canOverrideFees ? "Released permit - read only" : undefined}
            permitApplicationType={applicationData.permitApplicationType as "New" | "Renewal" | "Additional" | undefined}
            onAutoSave={canOverrideFees ? handleAutoSaveRequest : undefined}
          />

          {/* Schedule of Payments (Functional - NOT read-only) */}
          <ScheduleOfPaymentsCard
            applicationId={applicationId}
            modeOfPayment={applicationData.modeOfPayment || undefined}
            aggregatedFees={aggregatedFees}
            readOnly={false}
            applicationNumber={applicationData.applicationNumber}
            businessName={applicationData.business?.name}
            businessOwnerName={applicationData.businessOwner ? `${applicationData.businessOwner.firstName} ${applicationData.businessOwner.lastName}` : undefined}
            applicationStatus={applicationData.status}
          />

          {/* Documents */}
          <DocumentsCard documents={application.prerequisites.documents} />
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Clearances Checklist */}
          <ClearancesChecklistCard
            applicationId={applicationId}
            applicationNumber={applicationData.applicationNumber}
            businessName={applicationData.business?.name}
          />

          {/* Application Timeline */}
          <ApplicationTimelineCard
            resourceId={applicationId}
            resourceType="permit_application"
            preloadedActivityLogs={preloadedActivityLogs}
          />

          {/* BPLS Forms */}
          <BplsFormsCard
            applicationNumber={applicationData.applicationNumber}
            permitApplicationType={applicationData.permitApplicationType as "New" | "Renewal" | "Additional" | undefined}
            modeOfPayment={applicationData.modeOfPayment as "Annually" | "Semi-Annually" | "Quarterly" | undefined}
            submittedAt={applicationData.submittedAt}
            businessOwner={applicationData.businessOwner ? {
              firstName: applicationData.businessOwner.firstName,
              middleName: applicationData.businessOwner.middleName,
              lastName: applicationData.businessOwner.lastName,
              birthDate: applicationData.businessOwner.birthDate,
              civilStatus: applicationData.businessOwner.civilStatus,
              gender: applicationData.businessOwner.gender,
              citizenship: applicationData.businessOwner.citizenship,
              tin: applicationData.businessOwner.tin,
              mobile: applicationData.businessOwner.mobile,
              email: applicationData.businessOwner.email,
              address: applicationData.businessOwner.address,
            } : null}
            business={applicationData.business ? {
              name: applicationData.business.name,
              establishedDate: applicationData.business.establishedDate,
              ownershipType: applicationData.business.ownershipType,
              occupancy: applicationData.business.occupancy,
              permitPaymentCadence: applicationData.business.permitPaymentCadence,
              maleEmployeeCount: applicationData.business.maleEmployeeCount,
              femaleEmployeeCount: applicationData.business.femaleEmployeeCount,
              contactNumber: applicationData.business.contactNumber,
              email: applicationData.business.email,
              address: applicationData.business.address,
              buildingName: applicationData.business.buildingName,
              businessArea: applicationData.business.businessArea,
              registrationNumber: applicationData.business.registrationNumber,
              registrationDate: applicationData.business.registrationDate,
              propertyIndexNumber: applicationData.business.propertyIndexNumber,
            } : null}
            linesOfBusiness={applicationData.linesOfBusiness?.map((lob: any) => ({
              businessCategory: lob.businessCategory,
              capitalInvestment: lob.capitalInvestment,
              grossSales: lob.grossSales,
              permitApplicationType: lob.permitApplicationType,
              numberOfEmployees: lob.numberOfEmployees,
            }))}
            provinceName={businessLocationData?.province?.name}
            cityName={businessLocationData?.city?.name}
            barangayName={businessLocationData?.barangay?.name}
            ownerProvinceName={ownerLocationData?.province?.name}
            ownerCityName={ownerLocationData?.city?.name}
            ownerBarangayName={ownerLocationData?.barangay?.name}
          />
        </div>
      </div>
    </div>
  )
}
