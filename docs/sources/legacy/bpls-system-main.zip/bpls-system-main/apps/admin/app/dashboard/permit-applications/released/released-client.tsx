"use client"

import * as React from "react"
import { useMemo, useCallback, useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { usePreloadedQuery, useQuery, useMutation } from "convex/react"
import type { Preloaded } from "convex/react"
import { useDebouncedValue } from "@/hooks/use-debounced-value"
import {
  ColumnFiltersState,
  SortingState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table"
import { Search, Download, ChevronDown, Loader2 } from "lucide-react"

import { Button } from "@repo/ui/components/button"
import { Input } from "@repo/ui/components/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import { api } from "@repo/backend/convex/_generated/api"
import {
  convertToCSV,
  downloadCSV,
  generateExportFilename,
  formatDateForCSV,
  formatCurrencyForCSV,
  type CSVColumn,
} from "@/lib/utils/csv-export"
import { PermissionGuard } from "@/components/permission-guard"
import { usePermissions } from "@/hooks/use-permissions"
import { useToast } from "@/hooks/use-toast"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { useColumnVisibilityStore } from "@/lib/stores/column-visibility-store"
import {
  TableFilterPopover,
  createDefaultFilterState,
  applyFilters,
  type FilterConfig,
  type FilterState,
} from "@/components/permits/table-filter-popover"
import { createReleasedColumns, type ReleasedApplicationRow } from "@/components/permits/released-columns"

// Page size constant
const PAGE_SIZE = 20

interface ReleasedClientProps {
  preloadedApplications: Preloaded<typeof api.businessPermitApplications.listReleasedWithPaymentSummaryPaginated>
  preloadedCount: Preloaded<typeof api.businessPermitApplications.getReleasedCount>
}

// Column name formatting helper
function formatColumnName(id: string): string {
  return id
    .replace(/([A-Z])/g, " $1")
    .replace(/^./, (str) => str.toUpperCase())
    .trim()
}

// Filter config for Released table
const FILTER_CONFIG: FilterConfig = {
  showDateRange: true,
  showPaymentStatus: true,
  showClearanceProgress: true,
}

export default function ReleasedClient({ preloadedApplications, preloadedCount }: ReleasedClientProps) {
  const router = useRouter()
  const { toast } = useToast()
  const { canDelete } = usePermissions()

  // Search state
  const [searchQuery, setSearchQuery] = useState("")
  const debouncedSearch = useDebouncedValue(searchQuery, 300)

  // Delete state
  const [deleteApplicationId, setDeleteApplicationId] = useState<Id<"business_permit_applications"> | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)
  const deleteApplication = useMutation(api.businessPermitApplications.remove)

  // Pagination state - track current page and cursors for each page
  const [currentPage, setCurrentPage] = useState(0)
  const [pageCursors, setPageCursors] = useState<(string | null)[]>([null]) // null for first page

  // Determine if we're in search mode
  const isSearchMode = debouncedSearch.length >= 2

  // Use preloaded query for initial page (page 0 with no cursor)
  const preloadedData = usePreloadedQuery(preloadedApplications)
  const preloadedTotalCount = usePreloadedQuery(preloadedCount)

  // Server-side paginated list query for subsequent pages
  const paginatedList = useQuery(
    api.businessPermitApplications.listReleasedWithPaymentSummaryPaginated,
    !isSearchMode && currentPage > 0
      ? {
          paginationOpts: {
            numItems: PAGE_SIZE,
            cursor: pageCursors[currentPage],
          },
        }
      : "skip"
  )

  // Server-side search query with pagination
  const searchResults = useQuery(
    api.businessPermitApplications.searchReleasedPaginated,
    isSearchMode
      ? {
          query: debouncedSearch,
          cursor: pageCursors[currentPage] ? Number(pageCursors[currentPage]) : undefined,
          pageSize: PAGE_SIZE,
        }
      : "skip"
  )

  // Get total count for pagination UI (updates when searching)
  const searchCount = useQuery(
    api.businessPermitApplications.getReleasedCount,
    isSearchMode
      ? { searchQuery: debouncedSearch }
      : "skip"
  )

  // Reset pagination when search term changes
  useEffect(() => {
    setCurrentPage(0)
    setPageCursors([null])
  }, [debouncedSearch])

  // Determine loading states
  const isLoading = isSearchMode
    ? searchResults === undefined
    : currentPage === 0
      ? preloadedData === undefined
      : paginatedList === undefined

  // Get current page data based on mode
  const currentPageData = useMemo(() => {
    if (isSearchMode) {
      return searchResults?.page || []
    }
    if (currentPage === 0) {
      return preloadedData?.page || []
    }
    return paginatedList?.page || []
  }, [isSearchMode, currentPage, preloadedData, paginatedList, searchResults])

  // Transform data for display - the type parameter ensures proper typing for the map callback
  const applications = useMemo((): ReleasedApplicationRow[] => {
    if (!currentPageData || currentPageData.length === 0) return []

    return currentPageData.map((app: typeof currentPageData[0]): ReleasedApplicationRow => ({
      ...app,
      ownerName: app.businessOwner
        ? `${app.businessOwner.firstName} ${app.businessOwner.lastName}`
        : "Unknown Owner",
      businessName: app.business?.name ?? "Unknown Business",
      ownerAvatar: app.businessOwner?.avatar,
    })) as ReleasedApplicationRow[]
  }, [currentPageData])

  // Pagination controls
  const totalCount = isSearchMode ? (searchCount ?? 0) : preloadedTotalCount
  const totalPages = totalCount !== undefined ? Math.ceil(totalCount / PAGE_SIZE) : undefined

  const canGoNext = isSearchMode
    ? searchResults?.hasMore ?? false
    : currentPage === 0
      ? !preloadedData?.isDone
      : paginatedList ? !paginatedList.isDone : false

  const canGoPrev = currentPage > 0

  const handleNextPage = () => {
    if (!canGoNext) return

    // Get the cursor for the next page
    const nextCursor = isSearchMode
      ? searchResults?.nextCursor?.toString()
      : currentPage === 0
        ? preloadedData?.continueCursor
        : paginatedList?.continueCursor

    if (nextCursor) {
      setPageCursors((prev) => {
        const newCursors = [...prev]
        newCursors[currentPage + 1] = nextCursor
        return newCursors
      })
      setCurrentPage((prev) => prev + 1)
    }
  }

  const handlePrevPage = () => {
    if (!canGoPrev) return
    setCurrentPage((prev) => prev - 1)
  }

  // Table state
  const [sorting, setSorting] = React.useState<SortingState>([])
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
  const [filters, setFilters] = React.useState<FilterState>(createDefaultFilterState())

  // Get column visibility from Zustand store
  const { releasedColumns, setReleasedColumns } = useColumnVisibilityStore()

  // Handle row click
  const handleRowClick = useCallback((applicationId: string) => {
    router.push(`/dashboard/permit-applications/released/${applicationId}`)
  }, [router])

  // Handle delete action
  const handleDeleteClick = useCallback((applicationId: string) => {
    setDeleteApplicationId(applicationId as Id<"business_permit_applications">)
  }, [])

  const handleDelete = async () => {
    if (!deleteApplicationId) return

    setIsDeleting(true)
    try {
      await deleteApplication({ id: deleteApplicationId })
      toast({
        title: "Success",
        description: "Application deleted successfully",
      })
      setDeleteApplicationId(null)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete application",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  // Create columns with row click and delete handlers
  const columns = useMemo(
    () => createReleasedColumns({
      onRowClick: handleRowClick,
      onDelete: canDelete("permit_applications:releasing") ? handleDeleteClick : undefined
    }),
    [handleRowClick, handleDeleteClick, canDelete]
  )

  // Apply custom filters to data
  const filteredData = useMemo(() => {
    return applyFilters(applications, filters, {
      dateKey: "submittedAt" as keyof ReleasedApplicationRow,
      getPaymentRemaining: (item) => item.paymentSummary?.totalRemaining ?? 0,
      getClearancePercentage: (item) => item.clearanceProgress?.percentage || 0,
    })
  }, [applications, filters])

  // Note: Server-side pagination is used, so we don't need getPaginationRowModel
  const table = useReactTable({
    data: filteredData,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onColumnVisibilityChange: setReleasedColumns,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    state: {
      sorting,
      columnFilters,
      columnVisibility: releasedColumns,
    },
  })

  // Export handler
  const handleExport = useCallback(() => {
    type ExportRow = typeof filteredData[0]

    const exportColumns: CSVColumn<ExportRow>[] = [
      { header: "Application Number", accessor: (row) => row.applicationNumber },
      { header: "Business Name", accessor: (row) => row.businessName },
      { header: "Owner Name", accessor: (row) => row.ownerName },
      { header: "Total Paid", accessor: (row) => formatCurrencyForCSV(row.paymentSummary?.totalPaid ?? 0) },
      { header: "Total Remaining", accessor: (row) => formatCurrencyForCSV(row.paymentSummary?.totalRemaining ?? 0) },
      { header: "Periods Paid", accessor: (row) => `${row.paymentSummary?.periodsPaid ?? 0}/${row.paymentSummary?.totalPeriods ?? 0}` },
      { header: "Next Payment Date", accessor: (row) => row.paymentSummary?.nextPaymentDate ? formatDateForCSV(row.paymentSummary.nextPaymentDate) : "Fully Paid" },
      { header: "Clearance Progress", accessor: (row) => `${row.clearanceProgress?.completed || 0}/${row.clearanceProgress?.total || 0}` },
    ]

    const csv = convertToCSV(filteredData, exportColumns)
    const filename = generateExportFilename("released-applications")
    downloadCSV(csv, filename)
  }, [filteredData])

  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Releasing</h2>
          <p className="text-muted-foreground">Permit applications ready for release (first payment completed)</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Released Applications</CardTitle>
          <CardDescription>Applications with first payment period completed and ready for permit release</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="w-full space-y-4">
            <div className="flex items-center space-x-2">
              <div className="relative flex-1">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search applications..."
                  value={searchQuery}
                  onChange={(event) => setSearchQuery(event.target.value)}
                  className="pl-8 pr-8"
                />
                {isSearchMode && searchResults === undefined && (
                  <Loader2 className="absolute right-2 top-2.5 h-4 w-4 animate-spin text-muted-foreground" />
                )}
              </div>

              {/* Columns Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline">
                    Columns <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-[200px]">
                  {table
                    .getAllColumns()
                    .filter((column) => column.getCanHide())
                    .map((column) => {
                      const displayName = formatColumnName(column.id)
                      return (
                        <DropdownMenuCheckboxItem
                          key={column.id}
                          className="capitalize"
                          checked={column.getIsVisible()}
                          onCheckedChange={(value) =>
                            column.toggleVisibility(!!value)
                          }
                        >
                          {displayName}
                        </DropdownMenuCheckboxItem>
                      )
                    })}
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Filter Popover */}
              <TableFilterPopover
                config={FILTER_CONFIG}
                filters={filters}
                onFiltersChange={setFilters}
              />

              {/* Export Button */}
              <PermissionGuard resource="reports" action="read" fallback={null}>
                <Button variant="outline" onClick={handleExport}>
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </PermissionGuard>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  {table.getHeaderGroups().map((headerGroup) => (
                    <TableRow key={headerGroup.id}>
                      {headerGroup.headers.map((header) => {
                        return (
                          <TableHead key={header.id}>
                            {header.isPlaceholder
                              ? null
                              : flexRender(
                                  header.column.columnDef.header,
                                  header.getContext()
                                )}
                          </TableHead>
                        )
                      })}
                    </TableRow>
                  ))}
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={columns.length} className="h-24 text-center">
                        <div className="flex items-center justify-center">
                          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground mr-2" />
                          <span className="text-muted-foreground">Loading applications...</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : table.getRowModel().rows?.length ? (
                    table.getRowModel().rows.map((row) => (
                      <TableRow
                        key={row.id}
                        className="cursor-pointer hover:bg-muted/50"
                        onClick={() => handleRowClick(row.original._id)}
                      >
                        {row.getVisibleCells().map((cell) => (
                          <TableCell key={cell.id}>
                            {flexRender(
                              cell.column.columnDef.cell,
                              cell.getContext()
                            )}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell
                        colSpan={columns.length}
                        className="h-24 text-center"
                      >
                        No released applications found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>

            {/* Server-side Pagination Controls */}
            <div className="flex items-center justify-between px-2 pt-4">
              <div className="flex-1 text-sm text-muted-foreground">
                {isLoading ? (
                  "Loading..."
                ) : (
                  `Showing ${filteredData.length} of ${totalCount ?? "..."} ${isSearchMode ? "results" : "applications"}`
                )}
              </div>
              <div className="flex items-center space-x-6 lg:space-x-8">
                <div className="flex items-center space-x-2">
                  <p className="text-sm font-medium">
                    Page {currentPage + 1} of {totalPages ?? "..."}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handlePrevPage}
                    disabled={!canGoPrev || isLoading}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleNextPage}
                    disabled={!canGoNext || isLoading}
                  >
                    Next
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteApplicationId} onOpenChange={() => setDeleteApplicationId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Application?</AlertDialogTitle>
            <AlertDialogDescription>
              This will soft-delete the permit application. The record can be restored later if needed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
