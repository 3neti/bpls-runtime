import { Skeleton } from "@repo/ui/components/skeleton";
import { Card, CardContent, CardHeader } from "@repo/ui/components/card";

export default function ActivityLoading() {
  return (
    <div className="flex h-full">
      {/* Filters Sidebar Skeleton */}
      <div className="w-64 border-r p-4 space-y-6">
        <Skeleton className="h-6 w-32" />

        {/* Timeline Section */}
        <div className="space-y-2">
          <Skeleton className="h-4 w-20" />
          <div className="space-y-1">
            <Skeleton className="h-8 w-full" />
            <Skeleton className="h-8 w-full" />
            <Skeleton className="h-8 w-full" />
          </div>
        </div>

        {/* Date Range */}
        <div className="space-y-2">
          <Skeleton className="h-4 w-16" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>

        {/* Action Filter */}
        <div className="space-y-2">
          <Skeleton className="h-4 w-16" />
          <div className="space-y-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-6 w-full" />
            ))}
          </div>
        </div>

        {/* Type Filter */}
        <div className="space-y-2">
          <Skeleton className="h-4 w-12" />
          <div className="space-y-1">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-6 w-full" />
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-6 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <Skeleton className="h-8 w-40" />
            <Skeleton className="h-4 w-64 mt-1" />
          </div>
          <div className="flex gap-2">
            <Skeleton className="h-10 w-64" />
            <Skeleton className="h-10 w-24" />
          </div>
        </div>

        {/* Histogram */}
        <Card>
          <CardContent className="pt-4">
            <Skeleton className="h-16 w-full" />
          </CardContent>
        </Card>

        {/* Table */}
        <Card>
          <CardHeader className="pb-0">
            <Skeleton className="h-4 w-32" />
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {/* Table Header */}
              <div className="grid grid-cols-6 gap-4 py-2">
                <Skeleton className="h-4 w-20" />
                <Skeleton className="h-4 w-16" />
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-4 w-16" />
                <Skeleton className="h-4 w-8" />
              </div>
              {/* Table Rows */}
              {Array.from({ length: 10 }).map((_, i) => (
                <div key={i} className="grid grid-cols-6 gap-4 py-3 border-t">
                  <Skeleton className="h-4 w-28" />
                  <Skeleton className="h-6 w-24" />
                  <Skeleton className="h-4 w-28" />
                  <Skeleton className="h-4 w-48" />
                  <Skeleton className="h-6 w-20" />
                  <Skeleton className="h-8 w-8" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
