import { redirect } from "next/navigation";
import { fetchQuery, preloadQuery } from "convex/nextjs";
import { api } from "@repo/backend/convex/_generated/api";
import { OnboardingClient } from "./onboarding-client";

export default async function OnboardingPage() {
  // Check if already onboarded AND has users - redirect to login if so
  const [isOnboarded, hasUsers] = await Promise.all([
    fetchQuery(api.platformSettings.isOnboarded, {}),
    fetchQuery(api.users.hasUsers, {}),
  ]);

  // Only redirect away if BOTH conditions are met (fully set up)
  if (isOnboarded && hasUsers) {
    redirect("/login");
  }

  // Preload settings and image URLs for SSR
  const [preloadedSettings, preloadedLogoUrl, preloadedLandingImageUrl, preloadedMunicipalSealUrl] =
    await Promise.all([
      preloadQuery(api.platformSettings.get, {}),
      preloadQuery(api.platformSettings.getLogoUrl, {}),
      preloadQuery(api.platformSettings.getLandingImageUrl, {}),
      preloadQuery(api.platformSettings.getMunicipalSealUrl, {}),
    ]);

  return (
    <OnboardingClient
      preloadedSettings={preloadedSettings}
      preloadedLogoUrl={preloadedLogoUrl}
      preloadedLandingImageUrl={preloadedLandingImageUrl}
      preloadedMunicipalSealUrl={preloadedMunicipalSealUrl}
      isReturningUser={isOnboarded && !hasUsers}
    />
  );
}
