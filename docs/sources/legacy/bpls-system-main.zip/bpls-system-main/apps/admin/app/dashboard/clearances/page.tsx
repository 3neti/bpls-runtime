import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import { ClearancesClient } from "./clearances-client"

/**
 * Clearance Types Management Page (Server Component)
 *
 * Admin interface for managing clearance types for business permit workflow.
 * Clearance types are separate from user departments - they represent the
 * government offices that must approve a permit (e.g., Sanitary, Fire, MPDC).
 *
 * Features:
 * - View all clearance types and their certificate information
 * - Access clearance review portals via slug-based routing
 * - Manage clearance configurations (certificates, officers, descriptions)
 * - Toggle active/inactive status for clearance types
 *
 * Architecture:
 * - Server-side rendering with preloaded Convex query
 * - Loading state handled by loading.tsx skeleton
 * - Client interactions delegated to ClearancesClient component
 */
export default async function ClearancesPage() {
  const token = await convexAuthNextjsToken()

  // Preload clearance types data on the server
  const preloadedClearanceTypes = await preloadQuery(
    api.clearanceTypes.listClearanceTypes,
    { activeOnly: false },
    { token }
  )

  return <ClearancesClient preloadedClearanceTypes={preloadedClearanceTypes} />
}
