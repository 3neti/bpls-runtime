import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import { BillingGroupsClient } from "./billing-groups-client"

// Page size constant - should match the client component
const PAGE_SIZE = 20

/**
 * Billing Groups Management Page (Server Component)
 *
 * Admin interface for managing billing groups with customizable fields.
 * Billing groups are dynamic fee libraries that allow creating custom
 * transaction types with configurable fields and line items.
 *
 * Features:
 * - View all billing groups with revenue statistics
 * - Create, edit, and delete billing groups
 * - Restore deleted billing groups
 * - Permission-based access control
 *
 * Architecture:
 * - Server-side rendering with preloaded Convex queries
 * - Loading state handled by loading.tsx skeleton
 * - Client interactions delegated to BillingGroupsClient component
 */
export default async function BillingGroupsPage() {
  const token = await convexAuthNextjsToken()

  // Preload paginated billing groups and deleted groups on the server
  const [preloadedBillingGroups, preloadedDeletedGroups, preloadedCount] = await Promise.all([
    preloadQuery(
      api.billingGroups.listPaginated,
      { includeInactive: true, paginationOpts: { numItems: PAGE_SIZE, cursor: null } },
      { token }
    ),
    preloadQuery(
      api.billingGroups.listDeleted,
      {},
      { token }
    ),
    preloadQuery(
      api.billingGroups.getBillingGroupCount,
      { includeInactive: true },
      { token }
    ),
  ])

  return (
    <BillingGroupsClient
      preloadedBillingGroups={preloadedBillingGroups}
      preloadedDeletedGroups={preloadedDeletedGroups}
      preloadedCount={preloadedCount}
    />
  )
}
