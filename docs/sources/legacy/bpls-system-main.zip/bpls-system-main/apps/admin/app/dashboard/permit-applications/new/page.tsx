import { fetchQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { ConvexError } from "convex/values"
import { api } from "@repo/backend/convex/_generated/api"
import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"
import { NewPermitClient } from "./new-permit-client"

export default async function NewPermitPage() {
  const token = await convexAuthNextjsToken()

  try {
    // Check if user has permission to access the new application page
    const hasNewPagePermission = await fetchQuery(
      api.permissions.hasPermission,
      { resource: "permit_applications:new", action: "read" },
      { token }
    )

    // No heavy SSR preloads: the owner selector paginates + searches server-side on the
    // client (api.businessOwners.listPaginated), and the business selector is owner-scoped
    // (api.businesses.getByOwner). Both load only what's needed, on demand.

    // If user doesn't have permission to access new application page, show permission denied
    if (!hasNewPagePermission) {
      return (
        <PermissionDenied
          title="New Permit Application"
          description="Create a new business permit application"
          message="You don't have permission to access the new permit application page"
          details={{
            resource: "permit_applications:new",
            action: "read",
            requiredPermission: "permit_applications:new:read",
          }}
          resourceName="new application page"
          backLink="/dashboard/permit-applications"
          backLinkText="Back to Permit Applications"
        />
      )
    }

    return <NewPermitClient />
  } catch (error) {
    if (error instanceof ConvexError) {
      const errorData = error.data as {
        code?: string
        message?: string
        details?: {
          resource?: string
          action?: string
          userRole?: string
          requiredPermission?: string
        }
      }

      if (errorData.code === "PERMISSION_DENIED") {
        return (
          <PermissionDenied
            title="New Permit Application"
            description="Create a new business permit application"
            message={errorData.message}
            details={errorData.details}
            resourceName="permit application"
            backLink="/dashboard/permit-applications"
            backLinkText="Back to Permit Applications"
          />
        )
      }

      if (errorData.code === "UNAUTHENTICATED") {
        return <AuthenticationRequired />
      }
    }

    throw error
  }
}
