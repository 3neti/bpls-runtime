import { preloadQuery, fetchQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { ConvexError } from "convex/values"
import { api } from "@repo/backend/convex/_generated/api"
import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"
import { PaymentClient } from "./payment-client"

export default async function PaymentPage() {
  const token = await convexAuthNextjsToken()

  try {
    // Check if user has permission to view payment page
    const hasPaymentPermission = await fetchQuery(
      api.permissions.hasPermission,
      { resource: "permit_applications:payment", action: "read" },
      { token }
    )

    // If user doesn't have permission, show permission denied
    if (!hasPaymentPermission) {
      return (
        <PermissionDenied
          title="Payment"
          description="View permit applications pending payment"
          message="You don't have permission to view the payment page"
          details={{
            resource: "permit_applications:payment",
            action: "read",
            requiredPermission: "permit_applications:payment:read",
          }}
          resourceName="payment page"
          backLink="/dashboard/permit-applications"
          backLinkText="Back to Permit Applications"
        />
      )
    }

    // Preload only "Pending Payment" status applications
    const preloadedApplications = await preloadQuery(
      api.businessPermitApplications.listByStatuses,
      { statuses: ["Pending Payment"] },
      { token }
    )

    return <PaymentClient preloadedApplications={preloadedApplications} />
  } catch (error) {
    if (error instanceof ConvexError) {
      const errorData = error.data as {
        code?: string
        message?: string
        details?: {
          resource?: string
          action?: string
          userRole?: string
          requiredPermission?: string
        }
      }

      if (errorData.code === "PERMISSION_DENIED") {
        return (
          <PermissionDenied
            title="Payment"
            description="View permit applications pending payment"
            message={errorData.message}
            details={errorData.details}
            resourceName="payment page"
            backLink="/dashboard/permit-applications"
            backLinkText="Back to Permit Applications"
          />
        )
      }

      if (errorData.code === "UNAUTHENTICATED") {
        return <AuthenticationRequired />
      }
    }

    throw error
  }
}
