import { preloadQuery, fetchQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { ConvexError } from "convex/values"
import { api } from "@repo/backend/convex/_generated/api"
import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"
import { ApprovalClient } from "./approval-client"

export default async function ApprovalPage() {
  const token = await convexAuthNextjsToken()

  try {
    // Check if user has permission to view the approval page
    const hasApprovalPermission = await fetchQuery(
      api.permissions.hasPermission,
      { resource: "permit_applications:approval", action: "read" },
      { token }
    )

    // If user doesn't have permission, show permission denied
    if (!hasApprovalPermission) {
      return (
        <PermissionDenied
          title="Approval"
          description="Review and approve permit applications"
          message="You don't have permission to view the approval page"
          details={{
            resource: "permit_applications:approval",
            action: "read",
            requiredPermission: "permit_applications:approval:read",
          }}
          resourceName="approval page"
          backLink="/dashboard/permit-applications"
          backLinkText="Back to Permit Applications"
        />
      )
    }

    // Preload only Approval status applications
    const preloadedApplications = await preloadQuery(
      api.businessPermitApplications.listByStatuses,
      { statuses: ["Approval"] },
      { token }
    )

    return <ApprovalClient preloadedApplications={preloadedApplications} />
  } catch (error) {
    if (error instanceof ConvexError) {
      const errorData = error.data as {
        code?: string
        message?: string
        details?: {
          resource?: string
          action?: string
          userRole?: string
          requiredPermission?: string
        }
      }

      if (errorData.code === "PERMISSION_DENIED") {
        return (
          <PermissionDenied
            title="Approval"
            description="Review and approve permit applications"
            message={errorData.message}
            details={errorData.details}
            resourceName="approval page"
            backLink="/dashboard/permit-applications"
            backLinkText="Back to Permit Applications"
          />
        )
      }

      if (errorData.code === "UNAUTHENTICATED") {
        return <AuthenticationRequired />
      }
    }

    throw error
  }
}
