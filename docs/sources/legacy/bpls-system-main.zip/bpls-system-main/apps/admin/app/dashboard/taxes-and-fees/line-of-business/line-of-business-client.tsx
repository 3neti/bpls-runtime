"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { usePreloadedQuery, useMutation, useQuery } from "convex/react";
import type { Preloaded } from "convex/react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import { Plus, Search, Eye, Pencil, Trash2 } from "lucide-react";
import { usePermissions } from "@/hooks/use-permissions";
import { PermissionGuard } from "@/components/permission-guard";
import { PermissionDenied } from "@/components/permission-error-states";
import { Button } from "@repo/ui/components/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import { Input } from "@repo/ui/components/input";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@repo/ui/components/tooltip";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@repo/ui/components/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@repo/ui/components/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@repo/ui/components/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@repo/ui/components/table";
import { Textarea } from "@repo/ui/components/textarea";
import { useToast } from "@/hooks/use-toast";
import {
  lineOfBusinessFormSchema,
  type LineOfBusinessFormSchema,
  lineOfBusinessFormDefaultValues,
} from "@/lib/schemas/line-of-business-form";
import type { LineOfBusiness } from "@/lib/types/line-of-business";

interface LineOfBusinessClientProps {
  preloadedGroups: Preloaded<typeof api.groups.list>;
}

export function LineOfBusinessClient({ preloadedGroups }: LineOfBusinessClientProps) {
  const router = useRouter();
  const { toast } = useToast();
  const { canCreate, canUpdate, canDelete, isLoading: permissionsLoading } = usePermissions();

  // Permission checks
  const hasCreatePermission = canCreate("taxes_and_fees:line_of_business");
  const hasUpdatePermission = canUpdate("taxes_and_fees:line_of_business");
  const hasDeletePermission = canDelete("taxes_and_fees:line_of_business");

  const groupsResult = usePreloadedQuery(preloadedGroups);
  const groups = groupsResult.success ? groupsResult.data : [];

  // Fetch all divisions for the division select dropdown
  const divisionsResult = useQuery(api.divisions.list);
  const divisions = divisionsResult?.success ? divisionsResult.data : [];

  const createLineOfBusiness = useMutation(api.groups.create);
  const applyDivisionToGroup = useMutation(api.groups.applyDivision);
  const updateLineOfBusiness = useMutation(api.groups.update);
  const deleteLineOfBusiness = useMutation(api.groups.remove);

  const [searchTerm, setSearchTerm] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingLineOfBusiness, setEditingGroup] = useState<LineOfBusiness | null>(null);
  const [deletingLineOfBusinessId, setDeletingGroupId] = useState<Id<"groups"> | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  const form = useForm<LineOfBusinessFormSchema>({
    resolver: zodResolver(lineOfBusinessFormSchema),
    defaultValues: lineOfBusinessFormDefaultValues,
  });

  // Filter groups by search term
  const filteredGroups = (groups ?? []).filter((group: (typeof groups)[number]) => {
    const search = searchTerm.toLowerCase();
    return group.name.toLowerCase().includes(search) || group.description?.toLowerCase().includes(search);
  });

  const handleAddLineOfBusiness = async (values: LineOfBusinessFormSchema) => {
    try {
      // Create the line of business first
      const result = await createLineOfBusiness({
        name: values.name,
        description: values.description,
      });

      if (result.success && result.data) {
        // If a division was selected, apply it to the newly created group
        if (values.divisionId) {
          const applyResult = await applyDivisionToGroup({
            groupId: result.data._id,
            divisionId: values.divisionId as Id<"divisions">,
          });

          if (!applyResult.success) {
            // Line of business was created but division application failed
            toast({
              title: "Partial Success",
              description: `Line of business "${values.name}" was created, but failed to apply division: ${applyResult.error}`,
              variant: "destructive",
            });
            setIsAddDialogOpen(false);
            form.reset(lineOfBusinessFormDefaultValues);
            return;
          }
        }

        // Success - both line of business created and division applied (if selected)
        const successMessage = values.divisionId
          ? `Line of business "${values.name}" has been created and division applied successfully.`
          : `Line of business "${values.name}" has been created successfully.`;

        toast({
          title: "Success",
          description: successMessage,
        });
        setIsAddDialogOpen(false);
        form.reset(lineOfBusinessFormDefaultValues);
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to create line of business",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Failed to create line of business:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create line of business. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleEditLineOfBusiness = async (values: LineOfBusinessFormSchema) => {
    if (!editingLineOfBusiness) return;

    try {
      const result = await updateLineOfBusiness({
        groupId: editingLineOfBusiness._id,
        ...values,
      });

      if (result.success) {
        toast({
          title: "Success",
          description: `Line of business "${values.name}" has been updated successfully.`,
        });
        setIsAddDialogOpen(false);
        setEditingGroup(null);
        form.reset(lineOfBusinessFormDefaultValues);
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to update group",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Failed to update group:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update group. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleDeleteLineOfBusiness = async () => {
    if (!deletingLineOfBusinessId) return;

    try {
      const result = await deleteLineOfBusiness({ groupId: deletingLineOfBusinessId });

      if (result.success) {
        toast({
          title: "Success",
          description: "LineOfBusiness has been deleted successfully.",
        });
        setIsDeleteDialogOpen(false);
        setDeletingGroupId(null);
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to delete group",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Failed to delete group:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete group. Please try again.",
        variant: "destructive",
      });
    }
  };

  const openEditDialog = (group: LineOfBusiness) => {
    setEditingGroup(group);
    form.reset({
      name: group.name,
      description: group.description,
      divisionId: undefined, // Don't carry over division when editing
    });
    setIsAddDialogOpen(true);
  };

  const openDeleteDialog = (groupId: Id<"groups">) => {
    setDeletingGroupId(groupId);
    setIsDeleteDialogOpen(true);
  };

  const closeDialog = () => {
    setIsAddDialogOpen(false);
    setEditingGroup(null);
    form.reset(lineOfBusinessFormDefaultValues);
  };

  return (
    <PermissionGuard
      resource="taxes_and_fees:line_of_business"
      action="read"
      showLoading
      fallback={
        <PermissionDenied
          title="Lines of Business"
          description="Manage lines of business and their inherited fees"
          resourceName="line of business"
          backLink="/dashboard"
          backLinkText="Back to Dashboard"
        />
      }
    >
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Lines of Business</h1>
          <p className="text-muted-foreground">Manage lines of business and their inherited fees</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={hasCreatePermission ? -1 : 0}>
                  <DialogTrigger asChild>
                    <Button onClick={closeDialog} disabled={!hasCreatePermission || permissionsLoading}>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Line of Business
                    </Button>
                  </DialogTrigger>
                </span>
              </TooltipTrigger>
              {!hasCreatePermission && !permissionsLoading && (
                <TooltipContent>
                  <p>You don't have permission to create lines of business</p>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingLineOfBusiness ? "Edit Line of Business" : "Add New Line of Business"}</DialogTitle>
              <DialogDescription>
                {editingLineOfBusiness
                  ? "Update the line of business details"
                  : "Create a new line of business that can inherit fees from divisions"}
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form
                onSubmit={form.handleSubmit(editingLineOfBusiness ? handleEditLineOfBusiness : handleAddLineOfBusiness)}
                className="space-y-4"
              >
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Retail Trade, Food & Beverage" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe this line of business..."
                          className="resize-none"
                          rows={4}
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="divisionId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Division </FormLabel>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a division" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {divisions?.map((division: (typeof divisions)[number]) => (
                            <SelectItem key={division._id} value={division._id}>
                              {division.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription>Optionally attach this line of business to an existing division</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={closeDialog}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={form.formState.isSubmitting}>
                    {form.formState.isSubmitting
                      ? editingLineOfBusiness
                        ? "Updating..."
                        : "Creating..."
                      : editingLineOfBusiness
                        ? "Update Line of Business"
                        : "Create Line of Business"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Lines of Business</CardTitle>
          <CardDescription>A list of all lines of business in the system</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search lines of business by name or description..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredGroups.length > 0 ? (
                  filteredGroups.map((group: (typeof groups)[number]) => (
                    <TableRow
                      key={group._id}
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => router.push(`/dashboard/taxes-and-fees/line-of-business/${group._id}`)}
                    >
                      <TableCell className="font-medium">{group.name}</TableCell>
                      <TableCell className="max-w-md truncate">{group.description}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    router.push(`/dashboard/taxes-and-fees/line-of-business/${group._id}`);
                                  }}
                                >
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>View Line of Business</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>

                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span tabIndex={hasUpdatePermission ? -1 : 0}>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    disabled={!hasUpdatePermission || permissionsLoading}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      openEditDialog(group);
                                    }}
                                  >
                                    <Pencil className="h-4 w-4" />
                                  </Button>
                                </span>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{hasUpdatePermission ? "Edit Line of Business" : "You don't have permission to edit"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>

                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span tabIndex={hasDeletePermission ? -1 : 0}>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    disabled={!hasDeletePermission || permissionsLoading}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      openDeleteDialog(group._id);
                                    }}
                                    className="text-destructive hover:text-destructive"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </span>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{hasDeletePermission ? "Delete Line of Business" : "You don't have permission to delete"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={3} className="h-24 text-center">
                      {searchTerm
                        ? "No lines of business found matching your search."
                        : "No lines of business yet. Click 'Add Line of Business' to get started."}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Line of Business</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this line of business? This action cannot be undone. All fee overrides for
              this line of business will also be removed.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsDeleteDialogOpen(false);
                setDeletingGroupId(null);
              }}
            >
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteLineOfBusiness}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
    </PermissionGuard>
  );
}
