import { Skeleton } from "@repo/ui/components/skeleton"
import { Card, CardContent, CardHeader } from "@repo/ui/components/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"

/**
 * Loading Skeleton for Business Owners Page
 *
 * Matches the layout with:
 * - Header: Title, subtitle, Create button
 * - Card with icon title and DataTable
 */
export default function BusinessOwnersLoading() {
  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      {/* Header Skeleton */}
      <div className="flex items-center justify-between space-y-2">
        <div>
          <Skeleton className="h-9 w-[200px]" /> {/* Title */}
          <Skeleton className="h-4 w-[260px] mt-2" /> {/* Subtitle */}
        </div>
        <Skeleton className="h-10 w-[130px]" /> {/* Create Owner button */}
      </div>

      {/* Card with Table */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Skeleton className="h-5 w-5" /> {/* Icon */}
              <Skeleton className="h-5 w-[200px]" /> {/* Title */}
            </div>
            <Skeleton className="h-4 w-[360px]" /> {/* Description */}
          </div>
        </CardHeader>
        <CardContent>
          {/* Search/Filter Bar */}
          <div className="flex items-center py-4">
            <Skeleton className="h-10 w-[250px]" /> {/* Search input */}
          </div>

          {/* Table Skeleton */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]"></TableHead>
                  <TableHead><Skeleton className="h-4 w-[80px]" /></TableHead>
                  <TableHead><Skeleton className="h-4 w-[60px]" /></TableHead>
                  <TableHead><Skeleton className="h-4 w-[100px]" /></TableHead>
                  <TableHead><Skeleton className="h-4 w-[60px]" /></TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {Array.from({ length: 8 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell>
                      <Skeleton className="h-10 w-10 rounded-full" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-[150px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-[120px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-4 w-[180px]" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-6 w-[70px] rounded-full" />
                    </TableCell>
                    <TableCell>
                      <Skeleton className="h-8 w-8 rounded-md" />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between py-4">
            <Skeleton className="h-4 w-[150px]" />
            <div className="flex items-center gap-2">
              <Skeleton className="h-8 w-8 rounded-md" />
              <Skeleton className="h-8 w-8 rounded-md" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
