import { Suspense } from "react"
import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import { MajorClient } from "./major-client"
import { Skeleton } from "@repo/ui/components/skeleton"

export default async function MajorPage() {
  const token = await convexAuthNextjsToken()

  const preloadedMajors = await preloadQuery(api.majors.list, {}, { token })

  return (
    <Suspense fallback={<MajorPageSkeleton />}>
      <MajorClient preloadedMajors={preloadedMajors} />
    </Suspense>
  )
}

function MajorPageSkeleton() {
  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center justify-between">
        <Skeleton className="h-9 w-[200px]" />
        <Skeleton className="h-10 w-[120px]" />
      </div>
      <Skeleton className="h-[500px] w-full" />
    </div>
  )
}
