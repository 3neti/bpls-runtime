import Link from "next/link"
import { FileQuestion } from "lucide-react"
import { Button } from "@repo/ui/components/button"
import { Card, CardContent } from "@repo/ui/components/card"

export default function ReportNotFound() {
  return (
    <div className="container mx-auto py-6">
      <Card className="border-dashed">
        <CardContent className="flex flex-col items-center justify-center py-12">
          <FileQuestion className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium">Report not found</h3>
          <p className="text-muted-foreground text-center max-w-sm mt-1">
            The report you're looking for doesn't exist or has been deleted.
          </p>
          <Button asChild className="mt-4">
            <Link href="/dashboard/reports">Back to Reports</Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
