"use client";

import { useRouter } from "next/navigation";
import { ArrowLeft, AlertTriangle, Award, Loader2, Eye, Lock } from "lucide-react";
import { usePreloadedQuery, useQuery } from "convex/react";

import { Button } from "@repo/ui/components/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@repo/ui/components/table";
import { Alert, AlertDescription, AlertTitle } from "@repo/ui/components/alert";
import { Badge } from "@repo/ui/components/badge";
import { BusinessUpdateForm } from "@/components/business/business-update-form";
import { ApplicationTimelineCard } from "@/components/permit/application-timeline-card";
import { usePermissions } from "@/hooks/use-permissions";
import { api } from "@repo/backend/convex/_generated/api";

import type { Preloaded } from "convex/react";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import type { Business } from "@/lib/types/business";

interface BusinessDetailClientProps {
  preloadedBusiness: Preloaded<typeof api.businesses.getWithLOBDetails>;
  preloadedActivityLogs: Preloaded<typeof api.activityLogs.getResourceHistory>;
  businessId: Id<"businesses">;
}

export function BusinessDetailClient({ preloadedBusiness, preloadedActivityLogs, businessId }: BusinessDetailClientProps) {
  const router = useRouter();
  const businessData = usePreloadedQuery(preloadedBusiness);
  const { canUpdate, canRead, isLoading: permissionsLoading } = usePermissions();
  const canModifyBusiness = canUpdate("businesses");
  const canReadPermits = canRead("permits");

  // Query permits for this business - only if user has permission
  const permits = useQuery(
    api.permits.getByBusiness,
    canReadPermits ? { businessId } : "skip"
  );

  // Not found state
  if (businessData === null) {
    return (
      <div className="flex-1 space-y-4 p-4 pt-6">
        <div className="text-center py-10">
          <h1 className="text-2xl font-bold mb-4">Business Not Found</h1>
          <Button onClick={() => router.push("/dashboard/businesses")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Businesses
          </Button>
        </div>
      </div>
    );
  }

  const { owner, ...businessDoc } = businessData;

  // Convert Convex Doc to Business type
  // Note: ownerName and avatar don't exist in schema, so we derive/default them
  const business: Business = {
    id: businessDoc._id,
    name: businessDoc.name,
    ownerName: owner ? `${owner.firstName} ${owner.lastName}` : "Unknown",
    ownerId: businessDoc.ownerId,
    businessScale: businessDoc.businessScale,
    annualRevenue: businessDoc.annualRevenue,
    establishedDate: businessDoc.establishedDate,
    registrationDate: businessDoc.registrationDate, // DTI/SEC/CDA registration date
    registrationNumber: businessDoc.registrationNumber, // DTI/SEC/CDA registration number
    dateStarted: businessDoc.dateStarted,
    avatar: undefined, // avatar doesn't exist in businesses schema
    lineOfBusiness: "", // Line of business is now managed at permit application level
    ownershipType: businessDoc.ownershipType,
    groupName: businessDoc.groupName,
    occupancy: businessDoc.occupancy,
    permitPaymentCadence: businessDoc.permitPaymentCadence,
    numberOfEmployees: businessDoc.numberOfEmployees?.toString() ?? "0",
    maleEmployeeCount: businessDoc.maleEmployeeCount,
    femaleEmployeeCount: businessDoc.femaleEmployeeCount,
    businessArea: businessDoc.businessArea,
    propertyIndexNumber: businessDoc.propertyIndexNumber,
    contactNumber: businessDoc.contactNumber,
    email: businessDoc.email,
    address: businessDoc.address || "",
    buildingName: businessDoc.buildingName,
    provinceId: businessDoc.provinceId || "",
    cityId: businessDoc.cityId || "",
    barangayId: businessDoc.barangayId || "",
    categoryId: businessDoc.categoryId,
    subCategoryId: businessDoc.subCategoryId,
    documents: businessDoc.documents || [],
    isBlacklisted: businessDoc.isBlacklisted ?? false,
    blacklistReason: businessDoc.blacklistReason,
    blacklistedAt: businessDoc.blacklistedAt,
    blacklistedBy: businessDoc.blacklistedBy,
  };

  const handleSuccess = () => {
    router.refresh();
  };

  return (
    <div className="flex-1 space-y-6 p-4 pt-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.push("/dashboard/businesses")}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Business Details</h2>
          <p className="text-muted-foreground">
            {canModifyBusiness ? "Update" : "View"} information for {businessDoc.name}
            {owner && ` • Owned by ${owner.firstName} ${owner.lastName}`}
          </p>
        </div>
      </div>

      {/* Permission Warning */}
      {!canModifyBusiness && !permissionsLoading && (
        <Alert>
          <Lock className="h-4 w-4" />
          <AlertTitle>View-Only Mode</AlertTitle>
          <AlertDescription>
            You don't have permission to modify business information.
            All form fields are disabled.
          </AlertDescription>
        </Alert>
      )}

      {/* Blacklist Alert */}
      {businessData.isBlacklisted && (
        <Alert variant="destructive" className="border-2">
          <AlertTriangle className="h-5 w-5" />
          <AlertTitle className="text-lg font-semibold">This business has been blacklisted</AlertTitle>
          <AlertDescription className="mt-2 space-y-2">
            <div className="space-y-1">
              <p className="font-medium">Reason:</p>
              <p className="text-sm">{businessData.blacklistReason}</p>
            </div>
            <div className="flex gap-4 text-sm pt-2">
              <div>
                <span className="font-medium">Blacklisted on:</span>{" "}
                {businessData.blacklistedAt
                  ? new Date(businessData.blacklistedAt).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })
                  : "N/A"}
              </div>
              <div>
                <span className="font-medium">By:</span> {businessData.blacklistedBy || "N/A"}
              </div>
            </div>
            <p className="text-sm pt-2 border-t border-destructive/20 mt-3 pt-3">
              This business cannot be selected for new permit applications.
            </p>
          </AlertDescription>
        </Alert>
      )}
      {/* Update Form */}
      <BusinessUpdateForm
        business={business}
        onSuccess={handleSuccess}
        disabled={!canModifyBusiness}
      />


      {/* Business Owners Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Business Owners</CardTitle>
          <CardDescription>Owners associated with this business</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Owner ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Mobile</TableHead>
                  <TableHead>TIN</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {owner ? (
                  <TableRow
                    className="cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => router.push(`/dashboard/business-owners/${owner._id}`)}
                  >
                    <TableCell className="font-medium font-mono text-xs">{owner._id}</TableCell>
                    <TableCell>{`${owner.firstName} ${owner.lastName}`}</TableCell>
                    <TableCell>{owner.email}</TableCell>
                    <TableCell>{owner.mobile}</TableCell>
                    <TableCell className="font-mono text-sm">{owner.tin}</TableCell>
                  </TableRow>
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground">
                      No owner information available
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Mayor's Permits Card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Award className="h-5 w-5" />
            Mayor's Permits
          </CardTitle>
          <CardDescription>Permits issued for this business</CardDescription>
        </CardHeader>
        <CardContent>
          {!canReadPermits && !permissionsLoading ? (
            <div className="text-center py-8 text-muted-foreground">
              <Lock className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>You don't have permission to view permits</p>
            </div>
          ) : permits === undefined ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : permits.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Award className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No permits issued yet</p>
            </div>
          ) : (
            <div className="border rounded-lg">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Permit Number</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Issue Date</TableHead>
                    <TableHead>Expiry Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {permits.map((permit: NonNullable<typeof permits>[number]) => {
                    const isExpired = new Date(permit.expiryDate) < new Date();
                    const displayStatus = isExpired ? "Expired" : permit.status;

                    return (
                      <TableRow key={permit._id}>
                        <TableCell className="font-mono font-medium">
                          {permit.permitNumber || "—"}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={
                              displayStatus === "Active"
                                ? "text-green-600 border-green-300 bg-green-50"
                                : displayStatus === "Expired"
                                  ? "text-red-600 border-red-300 bg-red-50"
                                  : "text-yellow-600 border-yellow-300 bg-yellow-50"
                            }
                          >
                            {displayStatus}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {permit.issuedAt
                            ? new Date(permit.issuedAt).toLocaleDateString("en-PH", {
                                year: "numeric",
                                month: "short",
                                day: "numeric",
                              })
                            : new Date(permit.dateReleased).toLocaleDateString("en-PH", {
                                year: "numeric",
                                month: "short",
                                day: "numeric",
                              })}
                        </TableCell>
                        <TableCell>
                          {new Date(permit.expiryDate).toLocaleDateString("en-PH", {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                          })}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              window.open(`/permits/verify/${permit._id}`, "_blank")
                            }}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Request History */}
      <ApplicationTimelineCard
        resourceId={businessId}
        resourceType="business"
        preloadedActivityLogs={preloadedActivityLogs}
      />

      {/* Navigation Button */}
      <div className="flex justify-start">
        <Button variant="outline" onClick={() => router.push("/dashboard/businesses")}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to List
        </Button>
      </div>
    </div>
  );
}
