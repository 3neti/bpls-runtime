"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Plus, AlertCircle } from "lucide-react"
import { usePreloadedQuery } from "convex/react"

import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { CreateBusinessForm } from "@/components/businesses/create-business-form"
import { BusinessOwnerSelector } from "@/components/businesses/business-owner-selector"
import { Alert, AlertDescription } from "@repo/ui/components/alert"

import type { Preloaded } from "convex/react"
import type { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

interface NewBusinessClientProps {
  preloadedOwners: Preloaded<typeof api.businessOwners.list>
}

export function NewBusinessClient({ preloadedOwners }: NewBusinessClientProps) {
  const router = useRouter()
  const [selectedOwnerId, setSelectedOwnerId] = useState<Id<"business_owners"> | null>(null)

  // Use preloaded query data
  const owners = usePreloadedQuery(preloadedOwners)

  // Get selected owner's ownerType for filtering
  const selectedOwner = owners?.find((owner: NonNullable<typeof owners>[number]) => owner._id === selectedOwnerId)
  const ownerType = selectedOwner?.ownerType

  // Check for loading state (shouldn't happen with preloaded data, but good for safety)
  if (owners === undefined) {
    return (
      <div className="flex-1 space-y-6 p-4 pt-6">
        <div className="text-center py-8 text-muted-foreground">Loading business owners...</div>
      </div>
    )
  }

  return (
    <div className="flex-1 space-y-6 p-4 pt-6">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => router.push("/dashboard/businesses")}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Create Business</h2>
          <p className="text-muted-foreground">
            Register a new business in the system
          </p>
        </div>
      </div>

      {/* Step 1: Business Owner Selection */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Step 1: Select Business Owner</CardTitle>
              <CardDescription>
                Choose the business owner for this business registration
              </CardDescription>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => router.push("/dashboard/business-owners/new?returnTo=/dashboard/businesses/new")}
            >
              <Plus className="mr-2 h-4 w-4" />
              Create New Owner
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {owners.length === 0 ? (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                No business owners available. Please{" "}
                <Button
                  variant="link"
                  className="p-0 h-auto font-semibold"
                  onClick={() => router.push("/dashboard/business-owners/new?returnTo=/dashboard/businesses/new")}
                >
                  create a business owner
                </Button>{" "}
                first before creating a business.
              </AlertDescription>
            </Alert>
          ) : (
            <BusinessOwnerSelector
              owners={owners}
              selectedOwnerId={selectedOwnerId}
              onOwnerSelect={setSelectedOwnerId}
            />
          )}
        </CardContent>
      </Card>

      {/* Step 2: Business Information */}
      <Card>
        <CardHeader>
          <CardTitle>Step 2: Business Information</CardTitle>
          <CardDescription>
            {selectedOwnerId
              ? "Enter the business details and operations information"
              : "Please select a business owner first"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {!selectedOwnerId ? (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Please select a business owner from the section above to continue.
              </AlertDescription>
            </Alert>
          ) : (
            <CreateBusinessForm
              ownerId={selectedOwnerId}
              ownerType={ownerType}
              onSuccess={() => {
                router.push("/dashboard/businesses")
              }}
              onCancel={() => {
                router.push("/dashboard/businesses")
              }}
            />
          )}
        </CardContent>
      </Card>
    </div>
  )
}
