"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { usePreloadedQuery, useMutation } from "convex/react"
import type { Preloaded } from "convex/react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { Plus, Search, Eye, Pencil, Trash2, Lock } from "lucide-react"
import { usePermissions } from "@/hooks/use-permissions"
import { PermissionGuard } from "@/components/permission-guard"
import { PermissionDenied } from "@/components/permission-error-states"
import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Input } from "@repo/ui/components/input"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@repo/ui/components/dialog"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"
import { Textarea } from "@repo/ui/components/textarea"
import { useToast } from "@/hooks/use-toast"
import { majorFormSchema, type MajorFormSchema, majorFormDefaultValues } from "@/lib/schemas/major-form"
import type { Major } from "@/lib/types/major"

interface MajorClientProps {
  preloadedMajors: Preloaded<typeof api.majors.list>
}

export function MajorClient({ preloadedMajors }: MajorClientProps) {
  const router = useRouter()
  const { toast } = useToast()
  const { canCreate, canUpdate, canDelete, isLoading: permissionsLoading } = usePermissions()

  // Permission checks
  const hasCreatePermission = canCreate("taxes_and_fees:major")
  const hasUpdatePermission = canUpdate("taxes_and_fees:major")
  const hasDeletePermission = canDelete("taxes_and_fees:major")

  const majorsResult = usePreloadedQuery(preloadedMajors)
  const majors = majorsResult.success ? majorsResult.data : []

  const createMajor = useMutation(api.majors.create)
  const updateMajor = useMutation(api.majors.update)
  const deleteMajor = useMutation(api.majors.remove)

  const [searchTerm, setSearchTerm] = useState("")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingMajor, setEditingMajor] = useState<Major | null>(null)
  const [deletingMajorId, setDeletingMajorId] = useState<Id<"majors"> | null>(null)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)

  const form = useForm<MajorFormSchema>({
    resolver: zodResolver(majorFormSchema),
    defaultValues: majorFormDefaultValues,
  })

  // Filter majors by search term
  const filteredMajors = (majors ?? []).filter((major: (typeof majors)[number]) => {
    const search = searchTerm.toLowerCase()
    return (
      major.name.toLowerCase().includes(search) ||
      major.description?.toLowerCase().includes(search)
    )
  })

  const handleAddMajor = async (values: MajorFormSchema) => {
    try {
      const result = await createMajor(values)

      if (result.success) {
        toast({
          title: "Success",
          description: `Major "${values.name}" has been created successfully.`,
        })
        setIsAddDialogOpen(false)
        form.reset(majorFormDefaultValues)
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to create major",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to create major:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create major. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleEditMajor = async (values: MajorFormSchema) => {
    if (!editingMajor) return

    try {
      const result = await updateMajor({
        majorId: editingMajor._id,
        ...values,
      })

      if (result.success) {
        toast({
          title: "Success",
          description: `Major "${values.name}" has been updated successfully.`,
        })
        setIsAddDialogOpen(false)
        setEditingMajor(null)
        form.reset(majorFormDefaultValues)
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to update major",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to update major:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update major. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteMajor = async () => {
    if (!deletingMajorId) return

    try {
      const result = await deleteMajor({ majorId: deletingMajorId })

      if (result.success) {
        toast({
          title: "Success",
          description: "Major has been deleted successfully.",
        })
        setIsDeleteDialogOpen(false)
        setDeletingMajorId(null)
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to delete major",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to delete major:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete major. Please try again.",
        variant: "destructive",
      })
    }
  }

  const openEditDialog = (major: Major) => {
    setEditingMajor(major)
    form.reset({
      name: major.name,
      description: major.description,
    })
    setIsAddDialogOpen(true)
  }

  const openDeleteDialog = (majorId: Id<"majors">) => {
    setDeletingMajorId(majorId)
    setIsDeleteDialogOpen(true)
  }

  const closeDialog = () => {
    setIsAddDialogOpen(false)
    setEditingMajor(null)
    form.reset(majorFormDefaultValues)
  }

  return (
    <PermissionGuard
      resource="taxes_and_fees:major"
      action="read"
      showLoading
      fallback={
        <PermissionDenied
          title="Majors"
          description="Manage major categories in the taxes & fees hierarchy"
          resourceName="major"
          backLink="/dashboard"
          backLinkText="Back to Dashboard"
        />
      }
    >
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Majors</h1>
          <p className="text-muted-foreground">
            Manage major categories in the taxes & fees hierarchy
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={hasCreatePermission ? -1 : 0}>
                  <DialogTrigger asChild>
                    <Button onClick={closeDialog} disabled={!hasCreatePermission || permissionsLoading}>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Major
                    </Button>
                  </DialogTrigger>
                </span>
              </TooltipTrigger>
              {!hasCreatePermission && !permissionsLoading && (
                <TooltipContent>
                  <p>You don't have permission to create majors</p>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingMajor ? "Edit Major" : "Add New Major"}</DialogTitle>
              <DialogDescription>
                {editingMajor
                  ? "Update the major category details"
                  : "Create a new major category for business classification"}
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form
                onSubmit={form.handleSubmit(editingMajor ? handleEditMajor : handleAddMajor)}
                className="space-y-4"
              >
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Dealer, Retailer, Manufacturer" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe this major category..."
                          className="resize-none"
                          rows={4}
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={closeDialog}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={form.formState.isSubmitting}>
                    {form.formState.isSubmitting
                      ? editingMajor
                        ? "Updating..."
                        : "Creating..."
                      : editingMajor
                        ? "Update Major"
                        : "Create Major"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Majors</CardTitle>
          <CardDescription>A list of all major categories in the system</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search majors by name or description..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMajors.length > 0 ? (
                  filteredMajors.map((major: (typeof majors)[number]) => (
                    <TableRow
                      key={major._id}
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => router.push(`/dashboard/taxes-and-fees/major/${major._id}`)}
                    >
                      <TableCell className="font-medium">{major.name}</TableCell>
                      <TableCell className="max-w-md truncate">{major.description}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    router.push(`/dashboard/taxes-and-fees/major/${major._id}`)
                                  }}
                                >
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>View Major</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>

                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span tabIndex={hasUpdatePermission ? -1 : 0}>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    disabled={!hasUpdatePermission || permissionsLoading}
                                    onClick={(e) => {
                                      e.stopPropagation()
                                      openEditDialog(major)
                                    }}
                                  >
                                    <Pencil className="h-4 w-4" />
                                  </Button>
                                </span>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{hasUpdatePermission ? "Edit Major" : "You don't have permission to edit majors"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>

                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span tabIndex={hasDeletePermission ? -1 : 0}>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    disabled={!hasDeletePermission || permissionsLoading}
                                    onClick={(e) => {
                                      e.stopPropagation()
                                      openDeleteDialog(major._id)
                                    }}
                                    className="text-destructive hover:text-destructive"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </span>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{hasDeletePermission ? "Delete Major" : "You don't have permission to delete majors"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={3} className="h-24 text-center">
                      {searchTerm ? "No majors found matching your search." : "No majors yet. Click 'Add Major' to get started."}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Major</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this major? This action cannot be undone. All associated divisions will also be affected.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsDeleteDialogOpen(false)
                setDeletingMajorId(null)
              }}
            >
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteMajor}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
    </PermissionGuard>
  )
}
