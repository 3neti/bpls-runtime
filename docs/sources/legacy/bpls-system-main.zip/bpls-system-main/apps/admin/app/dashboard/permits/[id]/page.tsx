import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { ConvexError } from "convex/values"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"
import { PermitDetailClient } from "./permit-detail-client"

interface PermitDetailPageProps {
  params: Promise<{ id: string }>
}

export default async function PermitDetailPage({ params }: PermitDetailPageProps) {
  const { id } = await params
  const permitId = id as Id<"permits">
  const token = await convexAuthNextjsToken()

  try {
    const preloadedPermit = await preloadQuery(
      api.permits.getPermitWithFullDetails,
      { permitId },
      { token }
    )

    return <PermitDetailClient preloadedPermit={preloadedPermit} permitId={permitId} />
  } catch (error) {
    if (error instanceof ConvexError) {
      const errorData = error.data as {
        code?: string
        message?: string
        details?: {
          resource?: string
          action?: string
          userRole?: string
          requiredPermission?: string
        }
      }

      if (errorData.code === "PERMISSION_DENIED") {
        return (
          <PermissionDenied
            title="Permit Details"
            description="View permit information"
            message={errorData.message}
            details={errorData.details}
            resourceName="permit"
            backLink="/dashboard/permits"
            backLinkText="Back to Permits"
          />
        )
      }

      if (errorData.code === "UNAUTHENTICATED") {
        return <AuthenticationRequired />
      }
    }

    throw error
  }
}
