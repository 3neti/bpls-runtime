"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { usePreloadedQuery, useMutation, useQuery } from "convex/react"
import type { Preloaded } from "convex/react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id, Doc } from "@repo/backend/convex/_generated/dataModel"
import { ArrowLeft, Pencil, Trash2, Edit, X, AlertCircle, Calculator, DollarSign, TrendingUp, Plus, Eye } from "lucide-react"
import { usePermissions } from "@/hooks/use-permissions"
import { PermissionGuard } from "@/components/permission-guard"
import { PermissionDenied } from "@/components/permission-error-states"
import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Badge } from "@repo/ui/components/badge"
import { Alert, AlertDescription } from "@repo/ui/components/alert"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import { Input } from "@repo/ui/components/input"
import { Textarea } from "@repo/ui/components/textarea"
import { Label } from "@repo/ui/components/label"
import { useToast } from "@/hooks/use-toast"
import { cn } from "@/lib/utils"
import { formatCurrency } from "@/lib/utils/formatting"
import { lineOfBusinessFormSchema, type LineOfBusinessFormSchema, feeOverrideSchema, type FeeOverrideSchema } from "@/lib/schemas/line-of-business-form"
import type { InheritedFee } from "@/lib/types/line-of-business"
import type { FeeRange } from "@/lib/types/fees"
import { FeeManagementModal } from "@/components/fees/fee-management-modal"
import { AvailableVariablesCard } from "@/components/fees/available-variables-card"
import { FormulaInput, type FormulaValidationResult } from "@/components/fees/formula-input"

interface LineOfBusinessDetailClientProps {
  preloadedLineOfBusiness: Preloaded<typeof api.groups.getById>
  preloadedAllLineOfBusinessFees: Preloaded<typeof api.groups.getAllGroupFees>
  preloadedAppliedDivisions: Preloaded<typeof api.groups.getAppliedDivisions>
  lineOfBusinessId: Id<"groups">
}

export function LineOfBusinessDetailClient({
  preloadedLineOfBusiness,
  preloadedAllLineOfBusinessFees,
  preloadedAppliedDivisions,
  lineOfBusinessId,
}: LineOfBusinessDetailClientProps) {
  const router = useRouter()
  const { toast } = useToast()
  const { canCreate, canUpdate, canDelete, isLoading: permissionsLoading } = usePermissions()

  // Permission checks for line of business
  const hasUpdatePermission = canUpdate("taxes_and_fees:line_of_business")
  const hasDeletePermission = canDelete("taxes_and_fees:line_of_business")
  // Permission checks for fees (for Add Fee button)
  const hasCreateFeePermission = canCreate("taxes_and_fees:fees")

  const groupResult = usePreloadedQuery(preloadedLineOfBusiness)
  const groupData = groupResult.success ? groupResult.data : null

  const allGroupFeesResult = usePreloadedQuery(preloadedAllLineOfBusinessFees)
  // Transform backend data to match InheritedFee type
  const rawAllFees = allGroupFeesResult.success ? allGroupFeesResult.data : []
  const allFees: InheritedFee[] = (rawAllFees ?? []).map((fee: (typeof rawAllFees)[number]) => ({
    ...fee,
    majorName: (fee as any).majorName || "Custom Fee",
    isOverridden: (fee as any).isOverridden || false, // Will be updated based on overrides
  })) as InheritedFee[]

  const appliedDivisionsResult = usePreloadedQuery(preloadedAppliedDivisions)
  const appliedDivisions = appliedDivisionsResult.success ? appliedDivisionsResult.data : []

  const updateGroup = useMutation(api.groups.update)
  const deleteGroup = useMutation(api.groups.remove)
  const setFeeOverride = useMutation(api.groups.setFeeOverride)
  const removeFeeOverride = useMutation(api.groups.removeFeeOverride)
  const deleteCustomFee = useMutation(api.groups.deleteCustomFee)
  const applyDivision = useMutation(api.groups.applyDivision)
  const removeDivision = useMutation(api.groups.removeDivision)

  // Query available divisions for the group
  const availableDivisionsResult = useQuery(
    api.groups.getAvailableDivisions,
    lineOfBusinessId ? { groupId: lineOfBusinessId as Id<"groups"> } : "skip"
  )
  const availableDivisions = availableDivisionsResult?.success
    ? availableDivisionsResult.data
    : []

  // Query fee names for custom fee creation
  const feeNamesData = useQuery(api.feeNames.list, {})
  // Map to FeeNameOption format (with _id for unique keys, including isActive for filtering)
  const feeNames = (feeNamesData ?? []).map((fn: NonNullable<typeof feeNamesData>[number]) => ({
    _id: fn._id,
    name: fn.name,
    isActive: fn.isActive,
  }))

  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isOverrideDialogOpen, setIsOverrideDialogOpen] = useState(false)
  const [isAddCustomFeeOpen, setIsAddCustomFeeOpen] = useState(false)
  const [isEditCustomFeeOpen, setIsEditCustomFeeOpen] = useState(false)
  const [editingFee, setEditingFee] = useState<InheritedFee | null>(null)
  const [editingCustomFee, setEditingCustomFee] = useState<any>(null)
  const [deleteConfirmFee, setDeleteConfirmFee] = useState<any>(null)
  const [overrideRanges, setOverrideRanges] = useState<FeeRange[]>([])
  const [overrideFormula, setOverrideFormula] = useState("")
  const [overrideRangeField, setOverrideRangeField] = useState<string>("")
  const [isAddDivisionOpen, setIsAddDivisionOpen] = useState(false)
  const [selectedDivisionId, setSelectedDivisionId] = useState<string>("")
  const [removingDivisionId, setRemovingDivisionId] = useState<string | null>(null)
  const [overrideFormulaValidation, setOverrideFormulaValidation] = useState<FormulaValidationResult>({ valid: false })
  const [overrideRangeFormulaValidations, setOverrideRangeFormulaValidations] = useState<Record<number, FormulaValidationResult>>({})

  const form = useForm<LineOfBusinessFormSchema>({
    resolver: zodResolver(lineOfBusinessFormSchema),
    defaultValues: {
      name: groupData?.name || "",
      description: groupData?.description || "",
    },
  })

  const overrideForm = useForm<FeeOverrideSchema>({
    resolver: zodResolver(feeOverrideSchema),
    defaultValues: {
      feeId: "",
      feeName: "",
      feeType: "Constant",
      originalAmount: undefined,
      originalRanges: undefined,
      originalFormula: undefined,
      overrideAmount: undefined,
      overrideRanges: undefined,
      overrideFormula: undefined,
      reason: "",
    },
  })

  if (!groupData) {
    return (
      <div className="flex-1 space-y-4 p-4 pt-6">
        <div className="text-center py-8">
          <h2 className="text-2xl font-bold">Line of business not found</h2>
          <p className="text-muted-foreground mt-2">The line of business you are looking for does not exist.</p>
          <Button onClick={() => router.back()} className="mt-4">
            Go Back
          </Button>
        </div>
      </div>
    )
  }

  const handleUpdateGroup = async (values: LineOfBusinessFormSchema) => {
    try {
      const result = await updateGroup({
        groupId: lineOfBusinessId,
        ...values,
      })

      if (result.success) {
        toast({
          title: "Success",
          description: `Group "${values.name}" has been updated successfully.`,
        })
        setIsEditDialogOpen(false)
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to update group",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to update group:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update group. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteGroup = async () => {
    try {
      const result = await deleteGroup({ groupId: lineOfBusinessId })

      if (result.success) {
        toast({
          title: "Success",
          description: "Group has been deleted successfully.",
        })
        router.push("/dashboard/taxes-and-fees/line-of-business")
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to delete group",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to delete group:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete group. Please try again.",
        variant: "destructive",
      })
    }
  }

  const updateOverrideRangeFormulaValidation = (index: number, validation: FormulaValidationResult) => {
    setOverrideRangeFormulaValidations((prev) => ({
      ...prev,
      [index]: validation,
    }))
  }

  const openOverrideDialog = (fee: InheritedFee) => {
    setEditingFee(fee)

    // Reset validation states
    setOverrideFormulaValidation({ valid: false })
    setOverrideRangeFormulaValidations({})

    // Initialize override form with fee data
    const feeType = fee.feeType as "Constant" | "Range" | "Formula"

    overrideForm.reset({
      feeId: fee._id,
      feeName: fee.name,
      feeType,
      originalAmount: fee.feeType === "Constant" ? fee.amount : undefined,
      originalRanges: fee.feeType === "Range" ? fee.ranges : undefined,
      originalFormula: fee.feeType === "Formula" ? fee.formula : undefined,
      overrideAmount: fee.isOverridden && fee.override?.overrideAmount !== undefined ? fee.override.overrideAmount : undefined,
      overrideRanges: fee.isOverridden && fee.override?.overrideRanges ? fee.override.overrideRanges : undefined,
      overrideFormula: fee.isOverridden && fee.override?.overrideFormula ? fee.override.overrideFormula : undefined,
      overrideRangeField: fee.isOverridden && fee.override?.overrideRangeField ? fee.override.overrideRangeField : (fee.rangeField || ""),
      reason: fee.isOverridden && fee.override?.reason ? fee.override.reason : "",
    })

    // Initialize ranges, rangeField, and formula state
    if (fee.feeType === "Range") {
      if (fee.isOverridden && fee.override?.overrideRanges) {
        setOverrideRanges(fee.override.overrideRanges)
      } else if (fee.ranges) {
        setOverrideRanges(fee.ranges)
      } else {
        setOverrideRanges([{ min: 0, max: 0, fee: 0 }])
      }
      // Initialize rangeField state
      if (fee.isOverridden && fee.override?.overrideRangeField) {
        setOverrideRangeField(fee.override.overrideRangeField)
      } else if (fee.rangeField) {
        setOverrideRangeField(fee.rangeField)
      } else {
        setOverrideRangeField("capitalInvestment")
      }
    }

    if (fee.feeType === "Formula") {
      if (fee.isOverridden && fee.override?.overrideFormula) {
        setOverrideFormula(fee.override.overrideFormula)
      } else if (fee.formula) {
        setOverrideFormula(fee.formula)
      } else {
        setOverrideFormula("")
      }
    }

    setIsOverrideDialogOpen(true)
  }

  const handleSetOverride = async (values: FeeOverrideSchema) => {
    if (!editingFee) return

    try {
      const overrideData: {
        feeId: Id<"fees">
        groupId: Id<"groups">
        overrideAmount?: number
        overrideRanges?: FeeRange[]
        overrideFormula?: string
        overrideRangeField?: string
        reason: string
      } = {
        feeId: values.feeId as Id<"fees">,
        groupId: lineOfBusinessId,
        reason: values.reason,
      }

      if (values.feeType === "Constant" && values.overrideAmount !== undefined) {
        overrideData.overrideAmount = values.overrideAmount
      } else if (values.feeType === "Range" && values.overrideRanges) {
        overrideData.overrideRanges = values.overrideRanges
        if (overrideRangeField) {
          overrideData.overrideRangeField = overrideRangeField
        }
      } else if (values.feeType === "Formula" && values.overrideFormula) {
        overrideData.overrideFormula = values.overrideFormula
      }

      const result = await setFeeOverride(overrideData)

      if (result.success) {
        toast({
          title: "Success",
          description: "Fee override has been set successfully.",
        })
        setIsOverrideDialogOpen(false)
        setEditingFee(null)
        overrideForm.reset()
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to set fee override",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to set override:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to set override. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleRemoveOverride = async (feeId: Id<"fees">) => {
    try {
      const result = await removeFeeOverride({ feeId, groupId: lineOfBusinessId })

      if (result.success) {
        toast({
          title: "Success",
          description: "Fee override has been removed successfully.",
        })
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to remove fee override",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to remove override:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to remove override. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleEditCustomFee = (fee: any) => {
    setEditingCustomFee(fee)
    setIsEditCustomFeeOpen(true)
  }

  const handleDeleteCustomFee = (fee: any) => {
    setDeleteConfirmFee(fee)
  }

  const confirmDeleteCustomFee = async () => {
    if (!deleteConfirmFee) return

    try {
      const result = await deleteCustomFee({
        feeId: deleteConfirmFee._id as Id<"fees">,
      })

      if (result.success) {
        toast({
          title: "Success",
          description: "Custom fee deleted successfully",
        })
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to delete custom fee",
          variant: "destructive",
        })
      }

      setDeleteConfirmFee(null)
    } catch (error) {
      console.error("Failed to delete custom fee:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete custom fee. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleApplyDivision = async () => {
    if (!lineOfBusinessId || !selectedDivisionId) return

    try {
      const result = await applyDivision({
        groupId: lineOfBusinessId as Id<"groups">,
        divisionId: selectedDivisionId as Id<"divisions">,
      })

      if (result.success) {
        toast({
          title: "Success",
          description: result.message || "Division applied successfully",
        })
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to apply division",
          variant: "destructive",
        })
      }

      setIsAddDivisionOpen(false)
      setSelectedDivisionId("")
    } catch (error) {
      console.error("Failed to apply division:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to apply division. Please try again.",
        variant: "destructive",
      })
    }
  }

  const confirmRemoveDivision = async () => {
    if (!lineOfBusinessId || !removingDivisionId) return

    try {
      const result = await removeDivision({
        groupId: lineOfBusinessId as Id<"groups">,
        divisionId: removingDivisionId as Id<"divisions">,
      })

      if (result.success) {
        toast({
          title: "Success",
          description: result.message || "Division removed successfully",
        })
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to remove division",
          variant: "destructive",
        })
      }

      setRemovingDivisionId(null)
    } catch (error) {
      console.error("Failed to remove division:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to remove division. Please try again.",
        variant: "destructive",
      })
    }
  }

  const addOverrideRange = () => {
    setOverrideRanges([...overrideRanges, { min: 0, max: 0, fee: 0 }])
  }

  const updateOverrideRange = (index: number, field: keyof FeeRange, value: number | string) => {
    const updatedRanges = overrideRanges.map((range, i) => (i === index ? { ...range, [field]: value } : range))
    setOverrideRanges(updatedRanges)
    overrideForm.setValue("overrideRanges", updatedRanges)
  }

  const removeOverrideRange = (index: number) => {
    const filtered = overrideRanges.filter((_, i) => i !== index)
    setOverrideRanges(filtered)
    overrideForm.setValue("overrideRanges", filtered)
  }

  const getFeeTypeIcon = (feeType: string) => {
    switch (feeType) {
      case "Constant":
        return <DollarSign className="h-4 w-4" />
      case "Range":
        return <TrendingUp className="h-4 w-4" />
      case "Formula":
        return <Calculator className="h-4 w-4" />
    }
  }

  const formatFeeValue = (fee: InheritedFee) => {
    if (fee.feeType === "Constant") {
      return formatCurrency(fee.finalAmount ?? fee.amount, { withSymbol: true })
    } else if (fee.feeType === "Range") {
      return "Variable (Range-based)"
    } else {
      return "Calculated (Formula)"
    }
  }

  return (
    <PermissionGuard
      resource="taxes_and_fees:line_of_business"
      action="read"
      showLoading
      fallback={
        <PermissionDenied
          title="Line of Business Details"
          description="View line of business details and fee configuration"
          resourceName="line of business"
          backLink="/dashboard/taxes-and-fees/line-of-business"
          backLinkText="Back to Lines of Business"
        />
      }
    >
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center space-x-4">
        <Button variant="ghost" size="sm" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold tracking-tight">{groupData.name}</h1>
          <p className="text-muted-foreground">Group details and inherited fee configuration</p>
        </div>
        <div className="flex items-center space-x-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={hasUpdatePermission ? -1 : 0}>
                  <Button
                    variant="outline"
                    disabled={!hasUpdatePermission || permissionsLoading}
                    onClick={() => setIsEditDialogOpen(true)}
                  >
                    <Pencil className="mr-2 h-4 w-4" />
                    Edit
                  </Button>
                </span>
              </TooltipTrigger>
              {!hasUpdatePermission && !permissionsLoading && (
                <TooltipContent>
                  <p>You don't have permission to edit lines of business</p>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={hasDeletePermission ? -1 : 0}>
                  <Button
                    variant="destructive"
                    disabled={!hasDeletePermission || permissionsLoading}
                    onClick={() => setIsDeleteDialogOpen(true)}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete
                  </Button>
                </span>
              </TooltipTrigger>
              {!hasDeletePermission && !permissionsLoading && (
                <TooltipContent>
                  <p>You don't have permission to delete lines of business</p>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      {/* Line of Business Details Card */}
      <Card>
        <CardHeader>
          <CardTitle>Line of Business Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Name</p>
              <p className="text-lg font-semibold">{groupData.name}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Description</p>
              <p className="text-sm">{groupData.description}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Applied Divisions Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Applied Divisions</CardTitle>
            <CardDescription>
              Divisions that this line of business inherits fees from ({(appliedDivisions ?? []).length})
            </CardDescription>
          </div>
          <Button
            onClick={() => setIsAddDivisionOpen(true)}
            disabled={!availableDivisions || availableDivisions.length === 0}
          >
            <Plus className="mr-2 h-4 w-4" />
            Add to Division
          </Button>
        </CardHeader>
        <CardContent>
          {(appliedDivisions ?? []).length > 0 ? (
            <>
              {/* Desktop Table View */}
              <div className="hidden lg:block rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Division Name</TableHead>
                      <TableHead>Major</TableHead>
                      <TableHead>Fee Count</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(appliedDivisions ?? []).map((division: (typeof appliedDivisions)[number]) => {
                      // Safe property access with fallbacks
                      const divisionName = division?.name ?? "Unknown"
                      const majorName = (division as any)?.majorName ?? "Unknown"
                      const feeCount = (division as any)?.feeCount ?? 0

                      return (
                        <TableRow key={division._id}>
                          <TableCell className="font-medium">{divisionName}</TableCell>
                          <TableCell>{majorName}</TableCell>
                          <TableCell>{feeCount}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => router.push(`/dashboard/taxes-and-fees/division/${division._id}`)}
                                    >
                                      <Eye className="h-4 w-4" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p>View Division</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>

                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => setRemovingDivisionId(division._id)}
                                      className="text-destructive hover:text-destructive"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p>Remove from Group</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card View */}
              <div className="block lg:hidden space-y-4">
                {(appliedDivisions ?? []).map((division: (typeof appliedDivisions)[number]) => {
                  const divisionName = division?.name ?? "Unknown"
                  const majorName = (division as any)?.majorName ?? "Unknown"
                  const feeCount = (division as any)?.feeCount ?? 0

                  return (
                    <Card key={division._id} className="border-2">
                      <CardHeader>
                        <CardTitle className="text-base">{divisionName}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Major:</span>
                          <span className="font-medium">{majorName}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Fee Count:</span>
                          <span className="font-medium">{feeCount}</span>
                        </div>
                        <div className="flex gap-2 pt-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex-1"
                            onClick={() => router.push(`/dashboard/taxes-and-fees/division/${division._id}`)}
                          >
                            <Eye className="mr-2 h-4 w-4" />
                            View
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => setRemovingDivisionId(division._id)}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Remove
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </>
          ) : (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                This group has no divisions applied yet. Go to the Division page to apply divisions to this line of business.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Fees Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Fees</CardTitle>
            <CardDescription>
              Fees inherited from applied divisions with optional overrides, plus custom fees ({allFees.length} fees)
            </CardDescription>
          </div>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={hasCreateFeePermission ? -1 : 0}>
                  <Button
                    disabled={!hasCreateFeePermission || permissionsLoading}
                    onClick={() => {
                      setEditingCustomFee(null)
                      setIsAddCustomFeeOpen(true)
                    }}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add Fee
                  </Button>
                </span>
              </TooltipTrigger>
              {!hasCreateFeePermission && !permissionsLoading && (
                <TooltipContent>
                  <p>You don't have permission to create fees</p>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
        </CardHeader>
        <CardContent>
          {allFees.length > 0 ? (
            <>
              {/* Desktop Table View */}
              <div className="hidden lg:block rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Fee Name</TableHead>
                      <TableHead>Division</TableHead>
                      <TableHead>Major</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Fee Category</TableHead>
                      <TableHead>Original Value</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Final Value</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {allFees.map((fee) => (
                      <TableRow key={fee._id} className={cn(fee.isOverridden && "bg-orange-50 dark:bg-orange-950/20")}>
                        <TableCell className="font-medium">{fee.name}</TableCell>
                        <TableCell>{fee.divisionName || "—"}</TableCell>
                        <TableCell>{fee.majorName}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {getFeeTypeIcon(fee.feeType)}
                            <span>{fee.feeType}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="text-muted-foreground">{fee.feeCategory || "-"}</span>
                        </TableCell>
                        <TableCell>
                          {fee.feeType === "Constant" ? formatCurrency(fee.amount, { withSymbol: true }) : fee.feeType}
                        </TableCell>
                        <TableCell>
                          {fee.isOverridden ? (
                            <Badge variant="default" className="bg-orange-500">
                              Overridden
                            </Badge>
                          ) : (fee as any).status === "Custom" ? (
                            <Badge variant="default" className="bg-blue-500">
                              Custom
                            </Badge>
                          ) : (
                            <Badge variant="secondary">Inherited</Badge>
                          )}
                        </TableCell>
                        <TableCell className="font-medium">{formatFeeValue(fee)}</TableCell>
                        <TableCell className="text-right">
                          {(fee as any).status === "Custom" ? (
                            <div className="flex justify-end gap-2">
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => handleEditCustomFee(fee)}
                                    >
                                      <Edit className="h-4 w-4" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p>Edit Custom Fee</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>

                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => handleDeleteCustomFee(fee)}
                                      className="text-destructive hover:text-destructive"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p>Delete Custom Fee</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            </div>
                          ) : (
                            <div className="flex items-center justify-end gap-2">
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => openOverrideDialog(fee)}
                                    >
                                      <Edit className="h-4 w-4" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p>Override Fee</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>

                              {fee.isOverridden && (
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="text-destructive hover:text-destructive"
                                        onClick={() => handleRemoveOverride(fee._id)}
                                      >
                                        <X className="h-4 w-4" />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p>Remove Override</p>
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              )}
                            </div>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card View */}
              <div className="block lg:hidden space-y-4">
                {allFees.map((fee) => (
                  <Card key={fee._id} className={cn("border-2", fee.isOverridden && "bg-orange-50 dark:bg-orange-950/20")}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <CardTitle className="text-base">{fee.name}</CardTitle>
                        {fee.isOverridden ? (
                          <Badge variant="default" className="bg-orange-500">
                            Overridden
                          </Badge>
                        ) : (fee as any).status === "Custom" ? (
                          <Badge variant="default" className="bg-blue-500">
                            Custom
                          </Badge>
                        ) : (
                          <Badge variant="secondary">Inherited</Badge>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Division:</span>
                        <span className="font-medium">{fee.divisionName || "—"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Major:</span>
                        <span className="font-medium">{fee.majorName}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Type:</span>
                        <div className="flex items-center space-x-2">
                          {getFeeTypeIcon(fee.feeType)}
                          <span className="font-medium">{fee.feeType}</span>
                        </div>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Fee Category:</span>
                        <span className="font-medium">{fee.feeCategory || "-"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Original Value:</span>
                        <span className="font-medium">
                          {fee.feeType === "Constant" ? formatCurrency(fee.amount, { withSymbol: true }) : fee.feeType}
                        </span>
                      </div>
                      <div className="flex justify-between items-center pt-2 border-t">
                        <span className="text-sm font-semibold">Final Value:</span>
                        <span className="font-bold text-lg">{formatFeeValue(fee)}</span>
                      </div>
                      <div className="flex gap-2 pt-2">
                        {(fee as any).status === "Custom" ? (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              className="flex-1"
                              onClick={() => handleEditCustomFee(fee)}
                            >
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => handleDeleteCustomFee(fee)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </Button>
                          </>
                        ) : (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              className="flex-1"
                              onClick={() => openOverrideDialog(fee)}
                            >
                              <Edit className="mr-2 h-4 w-4" />
                              Override
                            </Button>
                            {fee.isOverridden && (
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => handleRemoveOverride(fee._id)}
                              >
                                <X className="mr-2 h-4 w-4" />
                                Remove
                              </Button>
                            )}
                          </>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          ) : (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                No fees yet. Apply divisions to inherit fees, or click "Add Fee" to create a custom fee for this line of business.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Fee Management Modal for Custom Fees */}
      <FeeManagementModal
        isOpen={isAddCustomFeeOpen || isEditCustomFeeOpen}
        onOpenChange={(open) => {
          setIsAddCustomFeeOpen(open)
          setIsEditCustomFeeOpen(open)
          if (!open) setEditingCustomFee(null)
        }}
        entityId={lineOfBusinessId}
        entityType="group"
        editingFee={editingCustomFee}
        feeNames={feeNames}
      />

      {/* Override Dialog */}
      <Dialog open={isOverrideDialogOpen} onOpenChange={setIsOverrideDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle>
              {editingFee?.isOverridden ? "Edit Fee Override" : "Set Fee Override"}
            </DialogTitle>
            <DialogDescription>
              Override the inherited fee values for this specific line of business
            </DialogDescription>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto pr-2 space-y-4">
            {editingFee && (
              <>
                {/* Fee Info */}
                <div className="bg-muted/50 p-4 rounded-lg space-y-2">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-xs text-muted-foreground">Fee Name</Label>
                      <p className="font-medium">{editingFee.name}</p>
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Fee Type</Label>
                      <div className="flex items-center space-x-2">
                        {getFeeTypeIcon(editingFee.feeType)}
                        <p className="font-medium">{editingFee.feeType}</p>
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Division</Label>
                      <p className="font-medium">{editingFee.divisionName}</p>
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Major</Label>
                      <p className="font-medium">{editingFee.majorName}</p>
                    </div>
                  </div>
                </div>

                <Form {...overrideForm}>
                  <form onSubmit={overrideForm.handleSubmit(handleSetOverride)} className="space-y-4">
                    {/* Constant Override */}
                    {editingFee.feeType === "Constant" && (
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm">Original Amount</Label>
                          <p className="text-lg font-semibold text-muted-foreground">
                            {formatCurrency(editingFee.amount, { withSymbol: true })}
                          </p>
                        </div>
                        <FormField
                          control={overrideForm.control}
                          name="overrideAmount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Override Amount (₱)</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  step="0.01"
                                  placeholder="Enter new amount"
                                  {...field}
                                  onChange={(e) => field.onChange(Number.parseFloat(e.target.value) || 0)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    )}

                    {/* Range Override */}
                    {editingFee.feeType === "Range" && (
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm">Original Ranges</Label>
                          <div className="text-sm text-muted-foreground">
                            {editingFee.ranges?.length || 0} range(s) configured
                            {editingFee.rangeField && ` (based on ${editingFee.rangeField})`}
                          </div>
                        </div>

                        {/* Range Field Selection */}
                        <div>
                          <Label className="text-sm">Range Field</Label>
                          <Select
                            value={overrideRangeField}
                            onValueChange={(value) => {
                              setOverrideRangeField(value)
                              overrideForm.setValue("overrideRangeField", value)
                            }}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue placeholder="Select range field" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="capitalInvestment">Capital Investment (₱)</SelectItem>
                              <SelectItem value="grossSales">Gross Sales (₱)</SelectItem>
                              <SelectItem value="numberOfEmployees">Number of Employees</SelectItem>
                              <SelectItem value="businessArea">Business Area (sqm)</SelectItem>
                              <SelectItem value="assetSize">Asset Size</SelectItem>
                            </SelectContent>
                          </Select>
                          <p className="text-xs text-muted-foreground mt-1">
                            The field used to determine which range applies
                          </p>
                        </div>

                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <Label>Override Ranges</Label>
                            <Button type="button" variant="outline" size="sm" onClick={addOverrideRange}>
                              Add Range
                            </Button>
                          </div>
                          <div className="space-y-2 max-h-60 overflow-y-auto">
                            {overrideRanges.map((range, index) => (
                              <div key={index} className="p-3 border rounded-lg space-y-3">
                                <div className="grid grid-cols-2 gap-3">
                                  <div>
                                    <Label className="text-xs">Min Value</Label>
                                    <Input
                                      type="number"
                                      value={range.min}
                                      onChange={(e) => updateOverrideRange(index, "min", Number.parseFloat(e.target.value) || 0)}
                                    />
                                  </div>
                                  <div>
                                    <Label className="text-xs">Max Value</Label>
                                    <Input
                                      type="number"
                                      value={range.max}
                                      onChange={(e) => updateOverrideRange(index, "max", Number.parseFloat(e.target.value) || 0)}
                                    />
                                  </div>
                                </div>

                                {/* Fee Type Toggle */}
                                <div>
                                  <Label className="text-xs mb-2 block">Fee Calculation</Label>
                                  <div className="flex space-x-2">
                                    <Button
                                      type="button"
                                      variant={range.formula === undefined ? "default" : "outline"}
                                      size="sm"
                                      onClick={() => {
                                        const updated = overrideRanges.map((r, i) =>
                                          i === index ? { ...r, formula: undefined, fee: r.fee || 0 } : r
                                        )
                                        setOverrideRanges(updated)
                                        overrideForm.setValue("overrideRanges", updated)
                                        // Clear validation for this range
                                        setOverrideRangeFormulaValidations((prev) => {
                                          const newState = { ...prev }
                                          delete newState[index]
                                          return newState
                                        })
                                      }}
                                      className="flex-1"
                                    >
                                      <DollarSign className="h-3 w-3 mr-1" />
                                      Fixed
                                    </Button>
                                    <Button
                                      type="button"
                                      variant={range.formula !== undefined ? "default" : "outline"}
                                      size="sm"
                                      onClick={() => {
                                        const updated = overrideRanges.map((r, i) =>
                                          i === index ? { ...r, fee: undefined, formula: r.formula || "" } : r
                                        )
                                        setOverrideRanges(updated)
                                        overrideForm.setValue("overrideRanges", updated)
                                      }}
                                      className="flex-1"
                                    >
                                      <Calculator className="h-3 w-3 mr-1" />
                                      Formula
                                    </Button>
                                  </div>
                                </div>

                                {/* Fee Amount or Formula Input */}
                                {range.formula !== undefined ? (
                                  <FormulaInput
                                    value={range.formula || ""}
                                    onChange={(value) => {
                                      const updated = overrideRanges.map((r, i) =>
                                        i === index ? { ...r, formula: value } : r
                                      )
                                      setOverrideRanges(updated)
                                      overrideForm.setValue("overrideRanges", updated)
                                    }}
                                    placeholder="e.g., numberOfEmployees * 100"
                                    rangeField={overrideRangeField}
                                    onValidationChange={(result) => updateOverrideRangeFormulaValidation(index, result)}
                                    showValidation={true}
                                    rows={2}
                                  />
                                ) : (
                                  <div>
                                    <Label className="text-xs">Fee Amount (₱)</Label>
                                    <Input
                                      type="number"
                                      step="0.01"
                                      value={range.fee || 0}
                                      onChange={(e) => updateOverrideRange(index, "fee", Number.parseFloat(e.target.value) || 0)}
                                    />
                                  </div>
                                )}

                                {overrideRanges.length > 1 && (
                                  <div className="flex justify-end">
                                    <Button type="button" variant="outline" size="sm" onClick={() => removeOverrideRange(index)}>
                                      Remove
                                    </Button>
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Available Variables for Range */}
                        <AvailableVariablesCard rangeField={overrideRangeField} compact />
                      </div>
                    )}

                    {/* Formula Override */}
                    {editingFee.feeType === "Formula" && (
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm">Original Formula</Label>
                          <p className="text-sm font-mono text-muted-foreground bg-muted/50 p-2 rounded">
                            {editingFee.formula || "No formula"}
                          </p>
                        </div>
                        <FormField
                          control={overrideForm.control}
                          name="overrideFormula"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Override Formula</FormLabel>
                              <FormControl>
                                <FormulaInput
                                  value={overrideFormula}
                                  onChange={(value) => {
                                    setOverrideFormula(value)
                                    field.onChange(value)
                                  }}
                                  placeholder="e.g., numberOfEmployees * 100 + grossSales * 0.02"
                                  onValidationChange={setOverrideFormulaValidation}
                                  showValidation={true}
                                  rows={3}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* Available Variables for Formula */}
                        <AvailableVariablesCard compact />
                      </div>
                    )}

                    {/* Reason */}
                    <FormField
                      control={overrideForm.control}
                      name="reason"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Reason for Override</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Explain why this override is necessary..."
                              className="resize-none"
                              rows={3}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <DialogFooter className="flex-shrink-0 mt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          setIsOverrideDialogOpen(false)
                          setEditingFee(null)
                          overrideForm.reset()
                        }}
                      >
                        Cancel
                      </Button>
                      <Button type="submit" disabled={overrideForm.formState.isSubmitting}>
                        {overrideForm.formState.isSubmitting ? "Saving..." : "Save Override"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Line of Business</DialogTitle>
            <DialogDescription>Update the line of business details</DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleUpdateGroup)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Retail Trade, Food & Beverage" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Describe this group..." className="resize-none" rows={4} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={form.formState.isSubmitting}>
                  {form.formState.isSubmitting ? "Updating..." : "Update Group"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Line of Business</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this line of business? This action cannot be undone. All fee overrides for this
              group will also be removed.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteGroup}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Custom Fee Confirmation Dialog */}
      <AlertDialog open={!!deleteConfirmFee} onOpenChange={(open) => !open && setDeleteConfirmFee(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Custom Fee</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deleteConfirmFee?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteCustomFee} className="bg-destructive text-destructive-foreground">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Add Division Dialog */}
      <Dialog open={isAddDivisionOpen} onOpenChange={setIsAddDivisionOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Division to Group</DialogTitle>
            <DialogDescription>
              Select a division to apply to this line of business. The group will inherit all fees from the selected division.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="division-select">Division</Label>
              <Select value={selectedDivisionId} onValueChange={setSelectedDivisionId}>
                <SelectTrigger id="division-select">
                  <SelectValue placeholder="Select a division" />
                </SelectTrigger>
                <SelectContent>
                  {(availableDivisions ?? []).map((division: (typeof availableDivisions)[number]) => (
                    <SelectItem key={division._id} value={division._id}>
                      {division.name} ({(division as any).majorName})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {availableDivisions?.length === 0 && (
                <p className="text-sm text-muted-foreground">
                  All divisions have been applied to this line of business.
                </p>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsAddDivisionOpen(false)
                setSelectedDivisionId("")
              }}
            >
              Cancel
            </Button>
            <Button onClick={handleApplyDivision} disabled={!selectedDivisionId}>
              Apply Division
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Remove Division Confirmation Dialog */}
      <AlertDialog open={!!removingDivisionId} onOpenChange={(open) => !open && setRemovingDivisionId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Division</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove this division from the line of business? The group will no longer inherit fees
              from this division.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmRemoveDivision} className="bg-destructive text-destructive-foreground">
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
    </PermissionGuard>
  )
}
