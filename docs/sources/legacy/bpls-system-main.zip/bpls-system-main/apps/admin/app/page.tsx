import { redirect } from "next/navigation";
import { fetchQuery } from "convex/nextjs";
import { api } from "@repo/backend/convex/_generated/api";

export default async function HomePage() {
  // Check if platform has completed onboarding and has users
  const [isOnboarded, hasUsers] = await Promise.all([
    fetchQuery(api.platformSettings.isOnboarded, {}),
    fetchQuery(api.users.hasUsers, {}),
  ]);

  // Redirect to onboarding if not set up or no users exist
  if (!isOnboarded || !hasUsers) {
    redirect("/admin/onboarding");
  }

  // If onboarded but not authenticated, middleware will let this through
  // so redirect to login (middleware handles authenticated users → dashboard)
  redirect("/login");
}
