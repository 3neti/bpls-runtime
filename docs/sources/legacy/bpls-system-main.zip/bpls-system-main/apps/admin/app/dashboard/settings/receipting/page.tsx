"use client";

import { useToast } from "@/hooks/use-toast";
import { ReceiptingSection } from "@/components/settings/receipting-section";
import { PermissionGuard } from "@/components/permission-guard";

export default function ReceiptingPage() {
  const { toast } = useToast();

  return (
    <PermissionGuard resource="settings:receipting" action="read" showLoading>
      <ReceiptingSection toast={toast} />
    </PermissionGuard>
  );
}
