import { Skeleton } from "@repo/ui/components/skeleton"
import { Card, CardContent, CardHeader } from "@repo/ui/components/card"

/**
 * Loading Skeleton for Line of Business Detail Page
 *
 * Matches the layout with:
 * - Back button + Header
 * - Form fields for editing LOB
 */
export default function LineOfBusinessDetailLoading() {
  return (
    <div className="flex-1 space-y-6 p-4 pt-6">
      {/* Header with Back Button */}
      <div className="flex items-center gap-4">
        <Skeleton className="h-10 w-10 rounded-md" />
        <div className="space-y-2">
          <Skeleton className="h-9 w-[220px]" />
          <Skeleton className="h-4 w-[300px]" />
        </div>
      </div>

      {/* Form Card */}
      <Card>
        <CardHeader className="space-y-2">
          <Skeleton className="h-6 w-[200px]" />
          <Skeleton className="h-4 w-[320px]" />
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Form Fields */}
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-2">
              <Skeleton className="h-4 w-[100px]" />
              <Skeleton className="h-10 w-full" />
            </div>
            <div className="space-y-2">
              <Skeleton className="h-4 w-[80px]" />
              <Skeleton className="h-10 w-full" />
            </div>
          </div>

          <div className="space-y-2">
            <Skeleton className="h-4 w-[100px]" />
            <Skeleton className="h-10 w-full" />
          </div>

          {/* Fees Section */}
          <div className="space-y-4">
            <Skeleton className="h-5 w-[100px]" />
            <div className="space-y-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="flex items-center gap-4">
                  <Skeleton className="h-4 w-[150px]" />
                  <Skeleton className="h-4 w-[80px]" />
                </div>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-4 pt-4">
            <Skeleton className="h-10 w-[100px]" />
            <Skeleton className="h-10 w-[120px]" />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
