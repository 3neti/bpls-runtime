import { Skeleton } from "@repo/ui/components/skeleton"
import { Card, CardContent, CardHeader } from "@repo/ui/components/card"

/**
 * Loading Skeleton for Billing Group Detail Page
 *
 * Matches the layout with:
 * - Back button + Header with title
 * - Summary stats cards
 * - Tabs with table content
 */
export default function BillingGroupDetailLoading() {
  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      {/* Header with Back Button */}
      <div className="flex items-center gap-4">
        <Skeleton className="h-10 w-10 rounded-md" /> {/* Back button */}
        <div className="flex-1 space-y-2">
          <Skeleton className="h-9 w-[250px]" /> {/* Title */}
          <Skeleton className="h-4 w-[350px]" /> {/* Description */}
        </div>
        <div className="flex gap-2">
          <Skeleton className="h-10 w-[120px]" /> {/* Action button */}
          <Skeleton className="h-10 w-[100px]" /> {/* Action button */}
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <Skeleton className="h-4 w-[100px]" />
              <Skeleton className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-7 w-[80px]" />
              <Skeleton className="h-3 w-[120px] mt-1" />
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tabs */}
      <div className="space-y-4">
        <div className="flex gap-2 border-b">
          <Skeleton className="h-10 w-[100px]" />
          <Skeleton className="h-10 w-[100px]" />
          <Skeleton className="h-10 w-[100px]" />
          <Skeleton className="h-10 w-[100px]" />
        </div>

        {/* Table Content */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-4">
              <Skeleton className="h-10 w-[250px]" /> {/* Search */}
              <Skeleton className="h-10 w-[120px]" /> {/* Add button */}
            </div>
            <div className="space-y-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="flex items-center gap-4 py-2">
                  <Skeleton className="h-4 w-[150px]" />
                  <Skeleton className="h-4 w-[100px]" />
                  <Skeleton className="h-4 w-[80px]" />
                  <Skeleton className="h-4 flex-1" />
                  <Skeleton className="h-8 w-8 rounded-md" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
