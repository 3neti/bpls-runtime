import { Skeleton } from "@repo/ui/components/skeleton"
import { Card, CardContent, CardHeader } from "@repo/ui/components/card"

/**
 * Loading Skeleton for Create Business Owner Page
 *
 * Matches the layout with:
 * - Back button + Header
 * - Card with form fields
 */
export default function NewBusinessOwnerLoading() {
  return (
    <div className="flex-1 space-y-6 p-4 pt-6">
      {/* Header with Back Button */}
      <div className="flex items-center gap-4">
        <Skeleton className="h-10 w-10 rounded-md" /> {/* Back button */}
        <div className="space-y-2">
          <Skeleton className="h-9 w-[250px]" /> {/* Title */}
          <Skeleton className="h-4 w-[300px]" /> {/* Subtitle */}
        </div>
      </div>

      {/* Form Card */}
      <Card>
        <CardHeader className="space-y-2">
          <Skeleton className="h-6 w-[220px]" /> {/* Card Title */}
          <Skeleton className="h-4 w-[400px]" /> {/* Card Description */}
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Form Fields Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* First Name */}
            <div className="space-y-2">
              <Skeleton className="h-4 w-[80px]" />
              <Skeleton className="h-10 w-full" />
            </div>
            {/* Last Name */}
            <div className="space-y-2">
              <Skeleton className="h-4 w-[80px]" />
              <Skeleton className="h-10 w-full" />
            </div>
            {/* Email */}
            <div className="space-y-2">
              <Skeleton className="h-4 w-[60px]" />
              <Skeleton className="h-10 w-full" />
            </div>
            {/* Phone */}
            <div className="space-y-2">
              <Skeleton className="h-4 w-[100px]" />
              <Skeleton className="h-10 w-full" />
            </div>
          </div>

          {/* Address Field */}
          <div className="space-y-2">
            <Skeleton className="h-4 w-[70px]" />
            <Skeleton className="h-10 w-full" />
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-4 pt-4">
            <Skeleton className="h-10 w-[100px]" /> {/* Cancel */}
            <Skeleton className="h-10 w-[120px]" /> {/* Submit */}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
