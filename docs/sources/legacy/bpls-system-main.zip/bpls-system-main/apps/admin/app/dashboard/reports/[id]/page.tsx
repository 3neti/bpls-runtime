import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import { notFound } from "next/navigation"
import { ReportDetailClient } from "./report-detail-client"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

interface ReportDetailPageProps {
  params: Promise<{ id: string }>
}

/**
 * Report Detail Page (Server Component)
 *
 * View and edit a saved report configuration.
 *
 * Features:
 * - View saved report configuration
 * - Re-run report with current data
 * - Edit configuration (if user has permission)
 * - Export report data
 *
 * Architecture:
 * - Server-side rendering with preloaded Convex query
 * - Client interactions delegated to ReportDetailClient component
 */
export default async function ReportDetailPage({ params }: ReportDetailPageProps) {
  const resolvedParams = await params
  const token = await convexAuthNextjsToken()

  try {
    const preloadedReport = await preloadQuery(
      api.savedReports.get,
      { id: resolvedParams.id as Id<"saved_reports"> },
      { token }
    )

    return <ReportDetailClient preloadedReport={preloadedReport} />
  } catch {
    notFound()
  }
}
