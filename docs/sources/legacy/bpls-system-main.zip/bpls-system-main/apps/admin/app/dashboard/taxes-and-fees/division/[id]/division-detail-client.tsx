"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { usePreloadedQuery, useMutation, useQuery } from "convex/react"
import type { Preloaded } from "convex/react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { api } from "@repo/backend/convex/_generated/api"
import type { Doc, Id } from "@repo/backend/convex/_generated/dataModel"
import { ArrowLeft, Eye, Pencil, Trash2, Plus, Calculator, DollarSign, TrendingUp } from "lucide-react"
import { usePermissions } from "@/hooks/use-permissions"
import { PermissionGuard } from "@/components/permission-guard"
import { PermissionDenied } from "@/components/permission-error-states"
import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@repo/ui/components/form"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"
import { Input } from "@repo/ui/components/input"
import { Textarea } from "@repo/ui/components/textarea"
import { Label } from "@repo/ui/components/label"
import { useToast } from "@/hooks/use-toast"
import { cn } from "@/lib/utils"
import { formatCurrency } from "@/lib/utils/formatting"
import { divisionFormSchema, type DivisionFormSchema } from "@/lib/schemas/division-form"
import type { FeeType } from "@/lib/types/fees"
import { FeeManagementModal } from "@/components/fees/fee-management-modal"

type Fee = Doc<"fees">

interface DivisionDetailClientProps {
  preloadedDivision: Preloaded<typeof api.divisions.getWithFees>
  preloadedAppliedGroups: Preloaded<typeof api.divisions.getAppliedGroups>
  preloadedFeeNames: Preloaded<typeof api.feeNames.list>
  divisionId: Id<"divisions">
}

export function DivisionDetailClient({
  preloadedDivision,
  preloadedAppliedGroups,
  preloadedFeeNames,
  divisionId,
}: DivisionDetailClientProps) {
  const router = useRouter()
  const { toast } = useToast()
  const { canUpdate, canDelete, canCreate, isLoading: permissionsLoading } = usePermissions()

  // Permission checks
  const hasUpdatePermission = canUpdate("taxes_and_fees:division")
  const hasDeletePermission = canDelete("taxes_and_fees:division")
  // Fee permissions (using taxes_and_fees:fees resource)
  const hasCreateFeePermission = canCreate("taxes_and_fees:fees")
  const hasUpdateFeePermission = canUpdate("taxes_and_fees:fees")
  const hasDeleteFeePermission = canDelete("taxes_and_fees:fees")

  const divisionResult = usePreloadedQuery(preloadedDivision)
  const divisionData = divisionResult.success ? divisionResult.data : null

  const appliedGroupsResult = usePreloadedQuery(preloadedAppliedGroups)
  const appliedGroups = appliedGroupsResult.success ? appliedGroupsResult.data : []

  const feeNamesData = usePreloadedQuery(preloadedFeeNames)
  // Map to FeeNameOption format (with _id for unique keys, including isActive for filtering)
  const feeNames = (feeNamesData ?? []).map((fn: NonNullable<typeof feeNamesData>[number]) => ({
    _id: fn._id,
    name: fn.name,
    isActive: fn.isActive,
  }))

  const updateDivision = useMutation(api.divisions.update)
  const deleteDivision = useMutation(api.divisions.remove)
  const removeFromGroup = useMutation(api.divisions.removeFromGroup)
  const applyToGroup = useMutation(api.divisions.applyToGroup)
  const deleteFee = useMutation(api.fees.remove)

  // Query available groups for "Apply to new Group" feature
  const availableGroupsResult = useQuery(api.divisions.getAvailableGroupsForDivision, { divisionId })
  const availableGroups = availableGroupsResult?.success ? availableGroupsResult.data : []

  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isAddFeeOpen, setIsAddFeeOpen] = useState(false)
  const [isApplyGroupDialogOpen, setIsApplyGroupDialogOpen] = useState(false)
  const [selectedGroupForApplication, setSelectedGroupForApplication] = useState<string>("")
  const [editingFee, setEditingFee] = useState<Fee | null>(null)

  const form = useForm<DivisionFormSchema>({
    resolver: zodResolver(divisionFormSchema),
    defaultValues: {
      name: divisionData?.name || "",
      description: divisionData?.description || "",
      majorId: divisionData?.majorId || "",
    },
  })

  if (!divisionData) {
    return (
      <div className="flex-1 space-y-4 p-4 pt-6">
        <div className="text-center py-8">
          <h2 className="text-2xl font-bold">Division not found</h2>
          <p className="text-muted-foreground mt-2">The division you are looking for does not exist.</p>
          <Button onClick={() => router.back()} className="mt-4">
            Go Back
          </Button>
        </div>
      </div>
    )
  }

  const fees = divisionData.fees || []

  const handleUpdateDivision = async (values: DivisionFormSchema) => {
    try {
      const result = await updateDivision({
        divisionId,
        name: values.name,
        description: values.description,
        majorId: values.majorId as Id<"majors">,
      })

      if (result.success) {
        toast({
          title: "Success",
          description: `Division "${values.name}" has been updated successfully.`,
        })
        setIsEditDialogOpen(false)
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to update division",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to update division:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update division. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteDivision = async () => {
    try {
      const result = await deleteDivision({ divisionId })

      if (result.success) {
        toast({
          title: "Success",
          description: "Division has been deleted successfully.",
        })
        router.push("/dashboard/taxes-and-fees/division")
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to delete division",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to delete division:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete division. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleRemoveFromGroup = async (groupId: Id<"groups">) => {
    try {
      const result = await removeFromGroup({ divisionId, groupId })

      if (result.success) {
        toast({
          title: "Success",
          description: "Division removed from group successfully.",
        })
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to remove division from group",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to remove from group:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to remove from group. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleApplyToGroup = async () => {
    if (!selectedGroupForApplication) {
      toast({
        title: "Error",
        description: "Please select a group to apply the division to.",
        variant: "destructive",
      })
      return
    }

    try {
      const result = await applyToGroup({
        divisionId,
        groupId: selectedGroupForApplication as Id<"groups">,
      })

      if (result.success) {
        toast({
          title: "Success",
          description: result.message || "Division applied to group successfully.",
        })
        setIsApplyGroupDialogOpen(false)
        setSelectedGroupForApplication("")
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to apply division to group",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Failed to apply to group:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to apply to group. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleEditFee = (fee: Fee) => {
    setEditingFee(fee)
    setIsAddFeeOpen(true)
  }

  const handleDeleteFee = async (feeId: string) => {
    try {
      await deleteFee({ id: feeId as Id<"fees"> })
      toast({
        title: "Success",
        description: "Fee has been deleted successfully.",
      })
    } catch (error) {
      console.error("Failed to delete fee:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete fee. Please try again.",
        variant: "destructive",
      })
    }
  }

  const getFeeTypeIcon = (feeType: FeeType) => {
    switch (feeType) {
      case "Constant":
        return <DollarSign className="h-4 w-4" />
      case "Range":
        return <TrendingUp className="h-4 w-4" />
      case "Formula":
        return <Calculator className="h-4 w-4" />
    }
  }

  const formatAmount = (fee: Fee) => {
    if (fee.feeType === "Constant") {
      return formatCurrency(fee.amount, { withSymbol: true })
    } else if (fee.feeType === "Range") {
      return "Variable"
    } else {
      return "Calculated"
    }
  }

  const formatApplicationTypes = (applicationTypes: string[]) => {
    return applicationTypes.map((type) => (
      <span
        key={type}
        className={cn(
          "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium mr-1",
          type === "New" ? "bg-blue-100 text-blue-800" : "bg-green-100 text-green-800"
        )}
      >
        {type}
      </span>
    ))
  }

  return (
    <PermissionGuard
      resource="taxes_and_fees:division"
      action="read"
      showLoading
      fallback={
        <PermissionDenied
          title="Division Details"
          description="View division details and fee configuration"
          resourceName="division"
          backLink="/dashboard/taxes-and-fees/division"
          backLinkText="Back to Divisions"
        />
      }
    >
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center space-x-4">
        <Button variant="ghost" size="sm" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold tracking-tight">{divisionData.name}</h1>
          <p className="text-muted-foreground">Division details and fee configuration</p>
        </div>
        <div className="flex items-center space-x-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={hasUpdatePermission ? -1 : 0}>
                  <Button
                    variant="outline"
                    disabled={!hasUpdatePermission || permissionsLoading}
                    onClick={() => setIsEditDialogOpen(true)}
                  >
                    <Pencil className="mr-2 h-4 w-4" />
                    Edit
                  </Button>
                </span>
              </TooltipTrigger>
              {!hasUpdatePermission && !permissionsLoading && (
                <TooltipContent>
                  <p>You don't have permission to edit divisions</p>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={hasDeletePermission ? -1 : 0}>
                  <Button
                    variant="destructive"
                    disabled={!hasDeletePermission || permissionsLoading}
                    onClick={() => setIsDeleteDialogOpen(true)}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete
                  </Button>
                </span>
              </TooltipTrigger>
              {!hasDeletePermission && !permissionsLoading && (
                <TooltipContent>
                  <p>You don't have permission to delete divisions</p>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      {/* Division Details Card */}
      <Card>
        <CardHeader>
          <CardTitle>Division Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Name</p>
              <p className="text-lg font-semibold">{divisionData.name}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Description</p>
              <p className="text-sm">{divisionData.description}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Fees Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Fees</CardTitle>
            <CardDescription>All fees configured for this division</CardDescription>
          </div>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={hasCreateFeePermission ? -1 : 0}>
                  <Button
                    disabled={!hasCreateFeePermission || permissionsLoading}
                    onClick={() => {
                      setEditingFee(null)
                      setIsAddFeeOpen(true)
                    }}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Add Fee
                  </Button>
                </span>
              </TooltipTrigger>
              {!hasCreateFeePermission && !permissionsLoading && (
                <TooltipContent>
                  <p>You don't have permission to create fees</p>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Application Type</TableHead>
                  <TableHead>Fee Type</TableHead>
                  <TableHead>Fee Category</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {fees.map((fee: Fee) => (
                  <TableRow
                    key={fee._id}
                    className="cursor-pointer hover:bg-muted/50"
                    onClick={() => handleEditFee(fee)}
                  >
                    <TableCell className="font-medium">{fee.name}</TableCell>
                    <TableCell>{formatAmount(fee)}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">{formatApplicationTypes(fee.applicationType)}</div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        {getFeeTypeIcon(fee.feeType as FeeType)}
                        <span>{fee.feeType}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-muted-foreground">{fee.feeCategory || "-"}</span>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span tabIndex={hasUpdateFeePermission ? -1 : 0}>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  disabled={!hasUpdateFeePermission || permissionsLoading}
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    handleEditFee(fee)
                                  }}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{hasUpdateFeePermission ? "Edit Fee" : "You don't have permission to edit fees"}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>

                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span tabIndex={hasDeleteFeePermission ? -1 : 0}>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  disabled={!hasDeleteFeePermission || permissionsLoading}
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    handleDeleteFee(fee._id)
                                  }}
                                  className="text-destructive hover:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{hasDeleteFeePermission ? "Delete Fee" : "You don't have permission to delete fees"}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          {fees.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No fees configured for this division. Click "Add Fee" to get started.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Applied Lines of Business Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Applied Lines of Business</CardTitle>
            <CardDescription>Groups that inherit fees from this division ({(appliedGroups ?? []).length})</CardDescription>
          </div>
          <Button
            onClick={() => setIsApplyGroupDialogOpen(true)}
            disabled={!availableGroups || availableGroups.length === 0}
          >
            <Plus className="mr-2 h-4 w-4" />
            Apply to new Group
          </Button>
        </CardHeader>
        <CardContent>
          {(appliedGroups ?? []).length > 0 ? (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Group Name</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(appliedGroups ?? []).map((group: (typeof appliedGroups)[number]) => (
                    <TableRow key={group._id}>
                      <TableCell className="font-medium">{group.name}</TableCell>
                      <TableCell className="max-w-md truncate">{group.description}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => router.push(`/dashboard/taxes-and-fees/line-of-business/${group._id}`)}
                                >
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>View Group</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>

                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => group._id && handleRemoveFromGroup(group._id)}
                                  className="text-destructive hover:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>Remove from Division</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              This division is not applied to any groups yet.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Fee Management Modal */}
      <FeeManagementModal
        isOpen={isAddFeeOpen}
        onOpenChange={(open) => {
          setIsAddFeeOpen(open)
          if (!open) setEditingFee(null)
        }}
        entityId={divisionId}
        entityType="division"
        editingFee={editingFee}
        feeNames={feeNames}
      />

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Division</DialogTitle>
            <DialogDescription>Update the division details</DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleUpdateDivision)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., DNEC, ETC" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Describe this division..." className="resize-none" rows={4} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={form.formState.isSubmitting}>
                  {form.formState.isSubmitting ? "Updating..." : "Update Division"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Division</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this division? This action cannot be undone. All associated fees and
              group applications will also be removed.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteDivision}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Apply to Group Dialog */}
      <Dialog open={isApplyGroupDialogOpen} onOpenChange={setIsApplyGroupDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Apply Division to Group</DialogTitle>
            <DialogDescription>
              Select a group to apply the &quot;{divisionData.name}&quot; division and its fees.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="group-select">Group</Label>
              <Select value={selectedGroupForApplication} onValueChange={setSelectedGroupForApplication}>
                <SelectTrigger id="group-select">
                  <SelectValue placeholder="Select a group" />
                </SelectTrigger>
                <SelectContent>
                  {(availableGroups ?? []).map((group: (typeof availableGroups)[number]) => (
                    <SelectItem key={group._id} value={group._id}>
                      {group.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {availableGroups && availableGroups.length === 0 && (
                <p className="text-sm text-muted-foreground mt-2">
                  All groups already have this division applied. Create a new group to apply this division.
                </p>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsApplyGroupDialogOpen(false)
                setSelectedGroupForApplication("")
              }}
            >
              Cancel
            </Button>
            <Button onClick={handleApplyToGroup} disabled={!selectedGroupForApplication}>
              Apply Division
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
    </PermissionGuard>
  )
}
