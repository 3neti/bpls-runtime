import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"

import { api } from "@repo/backend/convex/_generated/api"
import { NewBusinessClient } from "./new-business-client"

export default async function NewBusinessPage() {
  const token = await convexAuthNextjsToken()

  // Preload business owners data on the server
  const preloadedOwners = await preloadQuery(api.businessOwners.list, {
    includeBlacklisted: false,
  }, { token })

  return <NewBusinessClient preloadedOwners={preloadedOwners} />
}
