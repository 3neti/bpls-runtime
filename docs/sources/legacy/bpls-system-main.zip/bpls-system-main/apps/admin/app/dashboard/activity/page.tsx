import { preloadQuery } from "convex/nextjs";
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server";
import { api } from "@repo/backend/convex/_generated/api";
import ActivityClient from "./activity-client";

export default async function ActivityPage() {
  const token = await convexAuthNextjsToken();

  // Preload initial activity data for SSR
  const [preloadedLogs, preloadedFacets, preloadedHistogram] = await Promise.all([
    preloadQuery(api.activityLogs.listPaginated, { pageSize: 50 }, { token }),
    preloadQuery(api.activityLogs.getFilterFacets, {}, { token }),
    preloadQuery(api.activityLogs.getHistogramData, {}, { token }),
  ]);

  return (
    <ActivityClient
      preloadedLogs={preloadedLogs}
      preloadedFacets={preloadedFacets}
      preloadedHistogram={preloadedHistogram}
    />
  );
}
