"use client";

import { useFormContext } from "react-hook-form";
import { Building2, MapPin, Map, FileText, Calendar, CalendarClock } from "lucide-react";
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
  FormDescription,
} from "@repo/ui/components/form";
import { Input } from "@repo/ui/components/input";
import { Card, CardContent } from "@repo/ui/components/card";
import { RadioGroup, RadioGroupItem } from "@repo/ui/components/radio-group";
import { Label } from "@repo/ui/components/label";
import type { OnboardingData } from "@/lib/schemas/onboarding";

export function MunicipalityStep() {
  const form = useFormContext<OnboardingData>();
  const municipalityName = form.watch("municipalityName");
  const municipalityShortName = form.watch("municipalityShortName");
  const provinceName = form.watch("provinceName");

  return (
    <div className="grid md:grid-cols-2 gap-6">
      {/* Form Fields */}
      <div className="space-y-4">
        <FormField
          control={form.control}
          name="municipalityName"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2">
                <Building2 className="h-4 w-4" />
                Municipality Name
              </FormLabel>
              <FormControl>
                <Input
                  placeholder="e.g., MUNICIPALITY OF SAN JOSE"
                  {...field}
                />
              </FormControl>
              <FormDescription>
                Full official name of your municipality
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="municipalityShortName"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Short Name
              </FormLabel>
              <FormControl>
                <Input placeholder="e.g., San Jose" {...field} />
              </FormControl>
              <FormDescription>
                Short name used in headers and labels
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="provinceName"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2">
                <Map className="h-4 w-4" />
                Province Name
              </FormLabel>
              <FormControl>
                <Input placeholder="e.g., Nueva Ecija" {...field} />
              </FormControl>
              <FormDescription>
                Province where your municipality is located
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="fullAddress"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                Full Address
              </FormLabel>
              <FormControl>
                <Input
                  placeholder="e.g., SAN JOSE, NUEVA ECIJA"
                  {...field}
                />
              </FormControl>
              <FormDescription>
                Address as it appears on official documents
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Permit Expiration Setting */}
        <FormField
          control={form.control}
          name="permitExpiryMode"
          render={({ field }) => (
            <FormItem className="space-y-3">
              <FormLabel>Permit Expiration</FormLabel>
              <FormDescription>
                How should permit expiration dates be calculated?
              </FormDescription>
              <FormControl>
                <RadioGroup
                  onValueChange={field.onChange}
                  value={field.value}
                  className="space-y-2"
                >
                  <div className={`flex items-start space-x-3 p-3 border rounded-lg transition-colors ${field.value === "end_of_year" ? "border-primary bg-primary/5" : "border-border"}`}>
                    <RadioGroupItem value="end_of_year" id="onboard_end_of_year" className="mt-0.5" />
                    <div className="flex-1">
                      <Label htmlFor="onboard_end_of_year" className="font-medium flex items-center gap-2 cursor-pointer text-sm">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        End of Calendar Year (Dec 31)
                      </Label>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        Permit expires on December 31st of the year issued
                      </p>
                    </div>
                  </div>
                  <div className={`flex items-start space-x-3 p-3 border rounded-lg transition-colors ${field.value === "one_year" ? "border-primary bg-primary/5" : "border-border"}`}>
                    <RadioGroupItem value="one_year" id="onboard_one_year" className="mt-0.5" />
                    <div className="flex-1">
                      <Label htmlFor="onboard_one_year" className="font-medium flex items-center gap-2 cursor-pointer text-sm">
                        <CalendarClock className="h-4 w-4 text-muted-foreground" />
                        1 Year from Release Date
                      </Label>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        Permit expires exactly 1 year after issue
                      </p>
                    </div>
                  </div>
                </RadioGroup>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      {/* Preview */}
      <div className="space-y-4">
        <h4 className="text-sm font-medium text-muted-foreground">Preview</h4>
        <Card className="bg-muted/30">
          <CardContent className="pt-6">
            <div className="text-center border-b-2 border-primary/20 pb-4">
              <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mx-auto mb-2">
                <Building2 className="h-6 w-6 text-muted-foreground" />
              </div>
              <p className="text-sm font-bold text-primary">
                {municipalityName || "MUNICIPALITY NAME"}
              </p>
              <p className="text-xs text-muted-foreground">
                {provinceName || "Province Name"}
              </p>
              <p className="text-lg font-bold text-primary mt-2 tracking-wider">
                MAYOR'S PERMIT
              </p>
            </div>
            <div className="mt-4 text-center text-sm text-muted-foreground">
              <p>This is how your municipality info will appear on permits and official documents.</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-muted/30">
          <CardContent className="pt-4">
            <p className="text-xs text-muted-foreground mb-2">Receipt Header Preview:</p>
            <div className="font-mono text-sm border rounded p-2 bg-background">
              <p className="font-bold">{municipalityShortName || "Municipality"}</p>
              <p className="text-xs text-muted-foreground">Business Permit & Licensing</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
