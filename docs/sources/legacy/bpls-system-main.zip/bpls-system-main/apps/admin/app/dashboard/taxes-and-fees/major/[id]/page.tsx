import { Suspense } from "react"
import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { MajorDetailClient } from "./major-detail-client"
import { Skeleton } from "@repo/ui/components/skeleton"

interface MajorDetailPageProps {
  params: Promise<{ id: Id<"majors"> }>
}

export default async function MajorDetailPage({ params }: MajorDetailPageProps) {
  const token = await convexAuthNextjsToken()

  const { id } = await params
  const preloadedMajor = await preloadQuery(api.majors.getWithDivisions, { majorId: id }, { token })

  return (
    <Suspense fallback={<MajorDetailSkeleton />}>
      <MajorDetailClient preloadedMajor={preloadedMajor} majorId={id} />
    </Suspense>
  )
}

function MajorDetailSkeleton() {
  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center space-x-4">
        <Skeleton className="h-8 w-8" />
        <Skeleton className="h-9 w-[300px]" />
      </div>
      <Skeleton className="h-[200px] w-full" />
      <Skeleton className="h-[400px] w-full" />
    </div>
  )
}
