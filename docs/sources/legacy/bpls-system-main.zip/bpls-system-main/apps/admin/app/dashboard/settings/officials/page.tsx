import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import { OfficialsClient } from "./officials-client"

/**
 * Officials Settings Page (Server Component)
 *
 * Admin interface for configuring municipal officials information
 * including mayor, treasurer, and other signatories for permits.
 *
 * Architecture:
 * - Server-side rendering with preloaded Convex query
 * - Loading state handled by parent settings/loading.tsx skeleton
 * - Client interactions delegated to OfficialsClient component
 */
export default async function OfficialsPage() {
  const token = await convexAuthNextjsToken()

  const preloadedSettings = await preloadQuery(
    api.platformSettings.get,
    {},
    { token }
  )

  return <OfficialsClient preloadedSettings={preloadedSettings} />
}
