"use client";

import { FileText, RefreshCw, DollarSign, TrendingUp, Download, CalendarIcon, Search } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import { Badge } from "@repo/ui/components/badge";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@repo/ui/components/table";
import { Popover, PopoverContent, PopoverTrigger } from "@repo/ui/components/popover";
import { Calendar } from "@repo/ui/components/calendar";
import { Skeleton } from "@repo/ui/components/skeleton";
import { cn } from "@/lib/utils";
import { formatCurrency } from "@/lib/utils/formatting";
import { format, startOfMonth, endOfMonth, subMonths, subDays } from "date-fns";
import * as React from "react";
import { usePreloadedQuery, useQuery } from "convex/react";
import type { Preloaded } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import { PermitsActivityChart } from "@/components/charts/permits-activity-chart";
import { DailyApplicationsChart } from "@/components/charts/daily-applications-chart";
import { PermitApplicationsRadialChart } from "@/components/charts/permit-applications-radial-chart";

interface DashboardClientProps {
  preloadedStats: Preloaded<typeof api.dashboard.getDashboardStats>;
  preloadedActivity: Preloaded<typeof api.dashboard.getPermitsActivityTimeSeries>;
  preloadedWeekly: Preloaded<typeof api.dashboard.getDailyApplicationsBreakdown>;
  preloadedDistribution: Preloaded<typeof api.dashboard.getPermitApplicationsDistribution>;
  preloadedTransactions: Preloaded<typeof api.dashboard.getRecentTransactions>;
}

// Date preset options
type DatePreset = "last7days" | "last30days" | "thisMonth" | "lastMonth" | "custom";

// Calculate default date range (last 7 days) - must match server-side calculation
function getDefaultDateRange() {
  const now = new Date();
  const end = new Date(now);
  end.setHours(23, 59, 59, 999);

  const start = new Date(now);
  start.setDate(start.getDate() - 6); // 7 days including today
  start.setHours(0, 0, 0, 0);

  return { start, end };
}

// Get date range for a preset
function getPresetDateRange(preset: DatePreset): { start: Date; end: Date } {
  const now = new Date();
  const today = new Date(now);
  today.setHours(23, 59, 59, 999);

  switch (preset) {
    case "last7days": {
      const start = subDays(now, 6);
      start.setHours(0, 0, 0, 0);
      return { start, end: today };
    }
    case "last30days": {
      const start = subDays(now, 29);
      start.setHours(0, 0, 0, 0);
      return { start, end: today };
    }
    case "thisMonth": {
      const start = startOfMonth(now);
      start.setHours(0, 0, 0, 0);
      const end = endOfMonth(now);
      end.setHours(23, 59, 59, 999);
      return { start, end };
    }
    case "lastMonth": {
      const lastMonth = subMonths(now, 1);
      const start = startOfMonth(lastMonth);
      start.setHours(0, 0, 0, 0);
      const end = endOfMonth(lastMonth);
      end.setHours(23, 59, 59, 999);
      return { start, end };
    }
    default:
      return getDefaultDateRange();
  }
}

export default function DashboardClient({
  preloadedStats,
  preloadedActivity,
  preloadedWeekly,
  preloadedDistribution,
  preloadedTransactions,
}: DashboardClientProps) {
  // Initialize with default date range (last 7 days)
  const defaultRange = getDefaultDateRange();
  const [startDate, setStartDate] = React.useState<Date>(defaultRange.start);
  const [endDate, setEndDate] = React.useState<Date>(defaultRange.end);
  const [searchQuery, setSearchQuery] = React.useState("");
  const [activePreset, setActivePreset] = React.useState<DatePreset>("last7days");

  // Use preloaded data for initial SSR render
  const preloadedStatsData = usePreloadedQuery(preloadedStats);
  const preloadedActivityData = usePreloadedQuery(preloadedActivity);
  const preloadedWeeklyData = usePreloadedQuery(preloadedWeekly);
  const preloadedDistributionData = usePreloadedQuery(preloadedDistribution);
  const preloadedTransactionsData = usePreloadedQuery(preloadedTransactions);

  // Check if dates have changed from preloaded defaults
  const isDefaultRange =
    activePreset === "last7days" &&
    Math.abs(startDate.getTime() - defaultRange.start.getTime()) < 1000 &&
    Math.abs(endDate.getTime() - defaultRange.end.getTime()) < 1000;

  // Convert dates to ISO strings for Convex queries
  const startDateStr = startDate.toISOString();
  const endDateStr = endDate.toISOString();

  // Conditional queries - only run when dates differ from preloaded
  const filteredStats = useQuery(
    api.dashboard.getDashboardStats,
    isDefaultRange ? "skip" : { startDate: startDateStr, endDate: endDateStr }
  );
  const filteredActivity = useQuery(
    api.dashboard.getPermitsActivityTimeSeries,
    isDefaultRange ? "skip" : { startDate: startDateStr, endDate: endDateStr }
  );
  const filteredWeekly = useQuery(
    api.dashboard.getDailyApplicationsBreakdown,
    isDefaultRange ? "skip" : { startDate: startDateStr, endDate: endDateStr }
  );
  const filteredDistribution = useQuery(
    api.dashboard.getPermitApplicationsDistribution,
    isDefaultRange ? "skip" : { startDate: startDateStr, endDate: endDateStr }
  );
  const filteredTransactions = useQuery(
    api.dashboard.getRecentTransactions,
    isDefaultRange ? "skip" : { limit: 10, startDate: startDateStr, endDate: endDateStr }
  );

  // Use filtered data when available, otherwise use preloaded data
  const stats = isDefaultRange ? preloadedStatsData : (filteredStats ?? preloadedStatsData);
  const activityData = isDefaultRange ? preloadedActivityData : (filteredActivity ?? preloadedActivityData);
  const weeklyData = isDefaultRange ? preloadedWeeklyData : (filteredWeekly ?? preloadedWeeklyData);
  const distribution = isDefaultRange ? preloadedDistributionData : (filteredDistribution ?? preloadedDistributionData);
  const transactions = isDefaultRange ? preloadedTransactionsData : (filteredTransactions ?? preloadedTransactionsData);

  // Loading states (only when filtering and data is loading)
  const isStatsLoading = !isDefaultRange && filteredStats === undefined;
  const isActivityLoading = !isDefaultRange && filteredActivity === undefined;
  const isWeeklyLoading = !isDefaultRange && filteredWeekly === undefined;
  const isDistributionLoading = !isDefaultRange && filteredDistribution === undefined;
  const isTransactionsLoading = !isDefaultRange && filteredTransactions === undefined;

  // Filter transactions by search query
  const searchFilteredTransactions = React.useMemo(() => {
    if (!transactions) return [];
    return transactions.filter(
      (transaction: (typeof transactions)[number]) =>
        transaction.business.toLowerCase().includes(searchQuery.toLowerCase()) ||
        transaction.businessOwner.toLowerCase().includes(searchQuery.toLowerCase()) ||
        transaction.type.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [transactions, searchQuery]);

  // Apply date preset
  const applyPreset = (preset: DatePreset) => {
    const range = getPresetDateRange(preset);
    setStartDate(range.start);
    setEndDate(range.end);
    setActivePreset(preset);
  };

  // Handle custom date selection
  const handleStartDateChange = (date: Date | undefined) => {
    if (date) {
      date.setHours(0, 0, 0, 0);
      setStartDate(date);
      setActivePreset("custom");
    }
  };

  const handleEndDateChange = (date: Date | undefined) => {
    if (date) {
      date.setHours(23, 59, 59, 999);
      setEndDate(date);
      setActivePreset("custom");
    }
  };

  return (
    <>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">Overview of business permit applications and system activity</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Download
          </Button>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn("w-[280px] justify-start text-left font-normal")}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {format(startDate, "LLL dd, y")} - {format(endDate, "LLL dd, y")}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              {/* Date presets */}
              <div className="flex flex-wrap gap-2 p-3 border-b">
                <Button
                  variant={activePreset === "last7days" ? "default" : "outline"}
                  size="sm"
                  onClick={() => applyPreset("last7days")}
                >
                  Last 7 days
                </Button>
                <Button
                  variant={activePreset === "last30days" ? "default" : "outline"}
                  size="sm"
                  onClick={() => applyPreset("last30days")}
                >
                  Last 30 days
                </Button>
                <Button
                  variant={activePreset === "thisMonth" ? "default" : "outline"}
                  size="sm"
                  onClick={() => applyPreset("thisMonth")}
                >
                  This month
                </Button>
                <Button
                  variant={activePreset === "lastMonth" ? "default" : "outline"}
                  size="sm"
                  onClick={() => applyPreset("lastMonth")}
                >
                  Last month
                </Button>
              </div>
              {/* Custom date picker */}
              <div className="flex">
                <div className="p-3">
                  <div className="text-sm font-medium mb-2">Start Date</div>
                  <Calendar mode="single" selected={startDate} onSelect={handleStartDateChange} />
                </div>
                <div className="p-3 border-l">
                  <div className="text-sm font-medium mb-2">End Date</div>
                  <Calendar
                    mode="single"
                    selected={endDate}
                    onSelect={handleEndDateChange}
                    disabled={(date) => date < startDate}
                  />
                </div>
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-medium">New Permits</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              {isStatsLoading ? (
                <Skeleton className="h-10 w-24" />
              ) : (
                <div className="text-2xl sm:text-3xl lg:text-4xl font-bold">{stats?.newPermits ?? 0}</div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-medium">Renewed Permits</CardTitle>
            <RefreshCw className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              {isStatsLoading ? (
                <Skeleton className="h-10 w-24" />
              ) : (
                <div className="text-2xl sm:text-3xl lg:text-4xl font-bold">{stats?.renewedPermits ?? 0}</div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-medium">Avg Amount Paid</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              {isStatsLoading ? (
                <Skeleton className="h-10 w-32" />
              ) : (
                <div className="text-2xl sm:text-3xl lg:text-4xl font-bold truncate">{formatCurrency(stats?.avgAmountPaid ?? 0, { withSymbol: true })}</div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-medium">Total Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              {isStatsLoading ? (
                <Skeleton className="h-10 w-36" />
              ) : (
                <div className="text-2xl sm:text-3xl lg:text-4xl font-bold truncate">{formatCurrency(stats?.totalRevenue ?? 0, { withSymbol: true })}</div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div className="md:col-span-1 lg:col-span-3">
          <PermitsActivityChart data={activityData ?? undefined} isLoading={isActivityLoading} />
        </div>
        <div className="md:col-span-1 lg:col-span-1">
          <DailyApplicationsChart data={weeklyData ?? undefined} isLoading={isWeeklyLoading} />
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div className="md:col-span-1 lg:col-span-3">
          <Card>
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
              <CardDescription>Manage your business permit payments</CardDescription>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search transactions..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8"
                />
              </div>
            </CardHeader>
            <CardContent>
              {isTransactionsLoading ? (
                <div className="space-y-3">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : searchFilteredTransactions.length === 0 ? (
                <div className="py-8 text-center text-muted-foreground">
                  {searchQuery ? "No transactions match your search" : "No transactions in this period"}
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Transaction ID</TableHead>
                      <TableHead>Business</TableHead>
                      <TableHead>Business Owner</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Date & Time</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {searchFilteredTransactions.map((transaction: (typeof transactions)[number]) => (
                      <TableRow key={transaction.id}>
                        <TableCell>
                          <div className="font-mono text-sm">{transaction.transactionNumber}</div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{transaction.business}</div>
                            <div className="text-sm text-muted-foreground">{transaction.email}</div>
                          </div>
                        </TableCell>
                        <TableCell>{transaction.businessOwner}</TableCell>
                        <TableCell>
                          <Badge variant={transaction.type === "New Application" ? "default" : "secondary"}>
                            {transaction.type}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <div>{new Date(transaction.dateTime).toLocaleDateString()}</div>
                            <div className="text-muted-foreground">
                              {new Date(transaction.dateTime).toLocaleTimeString()}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">{formatCurrency(transaction.amount, { withSymbol: true })}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
        <div className="md:col-span-1 lg:col-span-1">
          <PermitApplicationsRadialChart
            newCount={distribution?.new}
            renewalCount={distribution?.renewal}
            isLoading={isDistributionLoading}
          />
        </div>
      </div>
    </>
  );
}
