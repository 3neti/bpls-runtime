import { preloadQuery } from "convex/nextjs";
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server";
import { api } from "@repo/backend/convex/_generated/api";
import PaymentsBillingClient from "./payments-billing-client";

export default async function PaymentsBillingPage() {
  const token = await convexAuthNextjsToken();

  // Preload payment data for SSR
  const [preloadedSummary, preloadedTransactions] = await Promise.all([
    preloadQuery(api.payments.getSummary, {}, { token }),
    preloadQuery(
      api.payments.listUnifiedPaginated,
      { pageSize: 50 },
      { token }
    ),
  ]);

  return (
    <PaymentsBillingClient
      preloadedSummary={preloadedSummary}
      preloadedTransactions={preloadedTransactions}
    />
  );
}
