"use client"

import * as React from "react"
import { useMemo, useCallback, useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { usePreloadedQuery, useQuery, useMutation } from "convex/react"
import type { Preloaded } from "convex/react"
import {
  ColumnFiltersState,
  SortingState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table"
import { Search, Download, ChevronDown, Plus, FileText, Loader2 } from "lucide-react"

import { useDebouncedValue } from "@/hooks/use-debounced-value"

import { Button } from "@repo/ui/components/button"
import { Input } from "@repo/ui/components/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@repo/ui/components/table"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import { api } from "@repo/backend/convex/_generated/api"
import {
  convertToCSV,
  downloadCSV,
  generateExportFilename,
  formatDateForCSV,
  type CSVColumn,
} from "@/lib/utils/csv-export"
import { useColumnVisibilityStore } from "@/lib/stores/column-visibility-store"
import {
  TableFilterPopover,
  createDefaultFilterState,
  applyFilters,
  type FilterConfig,
  type FilterState,
} from "@/components/permits/table-filter-popover"
import { createPermitApplicationsColumns, type PermitApplicationRow } from "@/components/permits/permit-applications-columns"
import { STATUS_OPTIONS } from "@/lib/types/permit-application"
import { PermissionGuard } from "@/components/permission-guard"
import { usePermissions } from "@/hooks/use-permissions"
import { useToast } from "@/hooks/use-toast"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

// Page size constant - should match the server page
const PAGE_SIZE = 20

// Default statuses to filter by
const DEFAULT_STATUSES = ["Assessment", "Approval", "Pending Payment", "Released"] as const

interface PermitApplicationsClientProps {
  preloadedApplications: Preloaded<typeof api.businessPermitApplications.listByStatusesPaginated>
  preloadedCount: Preloaded<typeof api.businessPermitApplications.getApplicationsCountByStatuses>
}

// Column name formatting helper
function formatColumnName(id: string): string {
  return id
    .replace(/([A-Z])/g, " $1")
    .replace(/^./, (str) => str.toUpperCase())
    .trim()
}

// Filter config for main Permit Applications table
const FILTER_CONFIG: FilterConfig = {
  statusOptions: STATUS_OPTIONS,
  showDateRange: true,
  showTypeFilter: true,
}

export function PermitApplicationsClient({ preloadedApplications, preloadedCount }: PermitApplicationsClientProps) {
  const router = useRouter()
  const { toast } = useToast()
  const { canDelete } = usePermissions()

  // Search state
  const [searchQuery, setSearchQuery] = useState("")
  const debouncedSearch = useDebouncedValue(searchQuery, 300)

  // Delete state
  const [deleteApplicationId, setDeleteApplicationId] = useState<Id<"business_permit_applications"> | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)
  const deleteApplication = useMutation(api.businessPermitApplications.remove)

  // Pagination state - track current page and cursors for each page
  const [currentPage, setCurrentPage] = useState(0)
  const [pageCursors, setPageCursors] = useState<(number | null)[]>([null]) // null for first page

  // Determine if we're in search mode
  const isSearchMode = debouncedSearch.length >= 2

  // Use preloaded query for initial page (page 0 with no cursor)
  const preloadedData = usePreloadedQuery(preloadedApplications)
  const preloadedTotalCount = usePreloadedQuery(preloadedCount)

  // Server-side paginated list query for subsequent pages
  const paginatedList = useQuery(
    api.businessPermitApplications.listByStatusesPaginated,
    !isSearchMode && currentPage > 0
      ? {
          statuses: [...DEFAULT_STATUSES],
          pageSize: PAGE_SIZE,
          cursor: pageCursors[currentPage] ?? undefined,
        }
      : "skip"
  )

  // Server-side search query with pagination
  const searchResults = useQuery(
    api.search.searchApplications,
    isSearchMode
      ? { query: debouncedSearch, limit: 50 }
      : "skip"
  )

  // Reset pagination when search term changes
  useEffect(() => {
    setCurrentPage(0)
    setPageCursors([null])
  }, [debouncedSearch])

  // Determine loading states
  const isLoading = isSearchMode
    ? searchResults === undefined
    : currentPage === 0
      ? preloadedData === undefined
      : paginatedList === undefined

  // Get current page data based on mode
  const currentPageData = useMemo(() => {
    if (isSearchMode) {
      return searchResults || []
    }
    if (currentPage === 0) {
      return preloadedData?.page || []
    }
    return paginatedList?.page || []
  }, [isSearchMode, currentPage, preloadedData, paginatedList, searchResults])

  // Transform data for display
  const applications = useMemo(() => {
    if (!currentPageData) return []

    return currentPageData.map((app: (typeof currentPageData)[number]) => ({
      ...app,
      ownerName: app.businessOwner
        ? `${app.businessOwner.firstName} ${app.businessOwner.lastName}`
        : "Unknown Owner",
      businessName: app.business?.name ?? "Unknown Business",
      ownerAvatar: app.businessOwner?.avatar,
      permitNumber: (app as Record<string, unknown>).permitNumber as string | null ?? null,
    }))
  }, [currentPageData]) as PermitApplicationRow[]

  // Pagination controls
  const totalCount = preloadedTotalCount
  const totalPages = totalCount !== undefined ? Math.ceil(totalCount / PAGE_SIZE) : undefined

  const canGoNext = isSearchMode
    ? false // Search mode uses client-side pagination for now
    : currentPage === 0
      ? preloadedData?.hasMore ?? false
      : paginatedList?.hasMore ?? false

  const canGoPrev = currentPage > 0

  const handleNextPage = () => {
    if (!canGoNext) return

    // Get the cursor for the next page
    const nextCursor = currentPage === 0
      ? preloadedData?.nextCursor
      : paginatedList?.nextCursor

    if (nextCursor !== undefined && nextCursor !== null) {
      setPageCursors((prev) => {
        const newCursors = [...prev]
        newCursors[currentPage + 1] = nextCursor
        return newCursors
      })
      setCurrentPage((prev) => prev + 1)
    }
  }

  const handlePrevPage = () => {
    if (!canGoPrev) return
    setCurrentPage((prev) => prev - 1)
  }

  // Table state
  const [sorting, setSorting] = React.useState<SortingState>([])
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
  const [filters, setFilters] = React.useState<FilterState>(createDefaultFilterState())

  // Get column visibility from Zustand store
  const { permitApplicationsColumns, setPermitApplicationsColumns } = useColumnVisibilityStore()

  // Navigate to application based on status
  const navigateToApplication = useCallback((applicationId: string, status: string) => {
    switch (status) {
      case "Assessment":
        router.push(`/dashboard/permit-applications/assessment/${applicationId}`)
        break
      case "Approval":
        router.push(`/dashboard/permit-applications/approval/${applicationId}`)
        break
      case "Pending Payment":
        router.push(`/dashboard/permit-applications/payment/${applicationId}`)
        break
      case "Released":
        router.push(`/dashboard/permit-applications/released/${applicationId}`)
        break
      default:
        router.push(`/dashboard/permit-applications/assessment/${applicationId}`)
    }
  }, [router])

  // Handle view action - find the application and navigate based on its status
  const handleView = useCallback((applicationId: string) => {
    const app = applications.find(a => a._id === applicationId)
    if (app) {
      navigateToApplication(applicationId, app.status)
    }
  }, [applications, navigateToApplication])

  // Handle delete action
  const handleDeleteClick = useCallback((applicationId: string) => {
    setDeleteApplicationId(applicationId as Id<"business_permit_applications">)
  }, [])

  const handleDelete = async () => {
    if (!deleteApplicationId) return

    setIsDeleting(true)
    try {
      await deleteApplication({ id: deleteApplicationId })
      toast({
        title: "Success",
        description: "Application deleted successfully",
      })
      setDeleteApplicationId(null)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete application",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  // Create columns with view and delete handlers
  const columns = useMemo(
    () => createPermitApplicationsColumns({
      onView: handleView,
      onDelete: canDelete("permit_applications:all_applications") ? handleDeleteClick : undefined
    }),
    [handleView, handleDeleteClick, canDelete]
  )

  // Apply custom filters to data
  const filteredData = useMemo(() => {
    return applyFilters(applications, filters, {
      dateKey: "submittedAt" as keyof PermitApplicationRow,
    })
  }, [applications, filters])

  const table = useReactTable({
    data: filteredData,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onColumnVisibilityChange: setPermitApplicationsColumns,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    initialState: {
      pagination: {
        pageSize: PAGE_SIZE,
      },
    },
    state: {
      sorting,
      columnFilters,
      columnVisibility: permitApplicationsColumns,
    },
  })

  // Export handler
  const handleExport = useCallback(() => {
    type ExportRow = typeof filteredData[0]

    const exportColumns: CSVColumn<ExportRow>[] = [
      { header: "Application Number", accessor: (row) => row.applicationNumber },
      { header: "Business Name", accessor: (row) => row.businessName },
      { header: "Owner Name", accessor: (row) => row.ownerName },
      { header: "Application Type", accessor: (row) => row.permitApplicationType || "N/A" },
      { header: "Status", accessor: (row) => row.status },
      { header: "Submitted Date", accessor: (row) => formatDateForCSV(row.submittedAt) },
    ]

    const csv = convertToCSV(filteredData, exportColumns)
    const filename = generateExportFilename("permit-applications")
    downloadCSV(csv, filename)
  }, [filteredData])

  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Permit Applications</h2>
          <p className="text-muted-foreground">
            View and manage all business permit applications
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Link href="/dashboard/permit-applications/new">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Application
            </Button>
          </Link>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            All Applications
          </CardTitle>
          <CardDescription>
            Applications in Assessment, Payment, and Releasing stages
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="w-full space-y-4">
            <div className="flex items-center space-x-2">
              <div className="relative flex-1">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search applications (business name, owner, application number)..."
                  value={searchQuery}
                  onChange={(event) => setSearchQuery(event.target.value)}
                  className="pl-8"
                />
              </div>

              {/* Columns Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline">
                    Columns <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-[200px]">
                  {table
                    .getAllColumns()
                    .filter((column) => column.getCanHide())
                    .map((column) => {
                      const displayName = formatColumnName(column.id)
                      return (
                        <DropdownMenuCheckboxItem
                          key={column.id}
                          className="capitalize"
                          checked={column.getIsVisible()}
                          onCheckedChange={(value) =>
                            column.toggleVisibility(!!value)
                          }
                        >
                          {displayName}
                        </DropdownMenuCheckboxItem>
                      )
                    })}
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Filter Popover */}
              <TableFilterPopover
                config={FILTER_CONFIG}
                filters={filters}
                onFiltersChange={setFilters}
              />

              {/* Export Button */}
              <PermissionGuard resource="reports" action="read" fallback={null}>
                <Button variant="outline" onClick={handleExport}>
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </PermissionGuard>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  {table.getHeaderGroups().map((headerGroup) => (
                    <TableRow key={headerGroup.id}>
                      {headerGroup.headers.map((header) => {
                        return (
                          <TableHead key={header.id}>
                            {header.isPlaceholder
                              ? null
                              : flexRender(
                                  header.column.columnDef.header,
                                  header.getContext()
                                )}
                          </TableHead>
                        )
                      })}
                    </TableRow>
                  ))}
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={columns.length} className="h-24 text-center">
                        <div className="flex items-center justify-center">
                          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                          <span className="ml-2 text-muted-foreground">Loading applications...</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : table.getRowModel().rows?.length ? (
                    table.getRowModel().rows.map((row) => (
                      <TableRow
                        key={row.id}
                        className="cursor-pointer hover:bg-muted/50"
                        onClick={() => navigateToApplication(row.original._id, row.original.status)}
                      >
                        {row.getVisibleCells().map((cell) => (
                          <TableCell key={cell.id}>
                            {flexRender(
                              cell.column.columnDef.cell,
                              cell.getContext()
                            )}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell
                        colSpan={columns.length}
                        className="h-24 text-center"
                      >
                        No permit applications found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>

            {/* Server-side pagination controls */}
            <div className="flex items-center justify-end space-x-2">
              <div className="text-muted-foreground flex-1 text-sm">
                {isSearchMode ? (
                  `${applications.length} search result(s)`
                ) : (
                  `Page ${currentPage + 1}${totalPages ? ` of ${totalPages}` : ""} (${totalCount ?? 0} total)`
                )}
              </div>
              <div className="flex items-center space-x-2">
                {!isSearchMode && (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handlePrevPage}
                      disabled={!canGoPrev || isLoading}
                    >
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleNextPage}
                      disabled={!canGoNext || isLoading}
                    >
                      Next
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteApplicationId} onOpenChange={() => setDeleteApplicationId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Application?</AlertDialogTitle>
            <AlertDialogDescription>
              This will soft-delete the permit application. The record can be restored later if needed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
