"use client"

import { useState } from "react"
import { usePreloadedQuery, useMutation } from "convex/react"
import type { Preloaded } from "convex/react"
import { Plus, Edit, Trash2, Tags } from "lucide-react"
import { usePermissions } from "@/hooks/use-permissions"
import { PermissionGuard } from "@/components/permission-guard"
import { PermissionDenied } from "@/components/permission-error-states"
import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@repo/ui/components/card"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@repo/ui/components/accordion"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import { CategoryDialog } from "@/components/business-categories/category-dialog"
import { SubCategoryDialog } from "@/components/business-categories/subcategory-dialog"
import { toast } from "sonner"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

interface Category {
  _id: string;
  name: string;
  description?: string;
  code?: string;
}

interface SubCategory {
  _id: string;
  name: string;
  categoryId: string;
  description?: string;
  code?: string;
}

interface BusinessCategoriesClientProps {
  preloadedCategories: Preloaded<typeof api.businessCategories.listCategories>
  preloadedSubCategories: Preloaded<typeof api.businessCategories.listSubCategories>
}

export default function BusinessCategoriesClient({
  preloadedCategories,
  preloadedSubCategories,
}: BusinessCategoriesClientProps) {
  const categories = usePreloadedQuery(preloadedCategories)
  const subCategories = usePreloadedQuery(preloadedSubCategories)
  const { canCreate, canUpdate, canDelete, isLoading: permissionsLoading } = usePermissions()

  // Permission checks
  const hasCreatePermission = canCreate("business_categories")
  const hasUpdatePermission = canUpdate("business_categories")
  const hasDeletePermission = canDelete("business_categories")

  const deleteCategory = useMutation(api.businessCategories.deleteCategory)
  const deleteSubCategory = useMutation(api.businessCategories.deleteSubCategory)

  // Dialog states
  const [categoryDialog, setCategoryDialog] = useState<{
    open: boolean
    mode: "create" | "edit"
    category?: Category
  }>({ open: false, mode: "create" })

  const [subCategoryDialog, setSubCategoryDialog] = useState<{
    open: boolean
    mode: "create" | "edit"
    subCategory?: SubCategory
    categoryId?: string
    categoryName?: string
  }>({ open: false, mode: "create" })

  // Delete confirmation states
  const [deleteDialog, setDeleteDialog] = useState<{
    open: boolean
    type: "category" | "subcategory"
    id?: string
    name?: string
  }>({ open: false, type: "category" })

  const handleDelete = async () => {
    try {
      if (!deleteDialog.id) return

      switch (deleteDialog.type) {
        case "category":
          await deleteCategory({ id: deleteDialog.id as Id<"business_categories"> })
          toast.success("Category deleted successfully")
          break
        case "subcategory":
          await deleteSubCategory({ id: deleteDialog.id as Id<"business_subcategories"> })
          toast.success("Sub-category deleted successfully")
          break
      }
      setDeleteDialog({ open: false, type: "category" })
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : "An error occurred"
      toast.error(`Failed to delete: ${errorMessage}`)
    }
  }

  const getSubCategoriesByCategory = (categoryId: string) => {
    return subCategories?.filter((sub: SubCategory) => sub.categoryId === categoryId) || []
  }

  return (
    <PermissionGuard
      resource="business_categories"
      action="read"
      showLoading
      fallback={
        <PermissionDenied
          title="Business Category Management"
          description="Manage business categories and sub-categories"
          resourceName="business_categories"
          backLink="/dashboard"
          backLinkText="Back to Dashboard"
        />
      }
    >
    <div className="flex-1 space-y-4 p-4 pt-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Business Category Management</h1>
          <p className="text-muted-foreground mt-2">
            Manage business categories and sub-categories for classification
          </p>
        </div>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <span tabIndex={hasCreatePermission ? -1 : 0}>
                <Button
                  onClick={() => setCategoryDialog({ open: true, mode: "create" })}
                  size="sm"
                  className="gap-2"
                  disabled={!hasCreatePermission || permissionsLoading}
                >
                  <Plus className="h-4 w-4" />
                  Add Category
                </Button>
              </span>
            </TooltipTrigger>
            {!hasCreatePermission && !permissionsLoading && (
              <TooltipContent>
                <p>You don't have permission to create business categories</p>
              </TooltipContent>
            )}
          </Tooltip>
        </TooltipProvider>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Tags className="h-5 w-5" />
              Categories
            </CardTitle>
            <CardDescription>Total: {categories.length}</CardDescription>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Tags className="h-5 w-5" />
              Sub-Categories
            </CardTitle>
            <CardDescription>Total: {subCategories.length}</CardDescription>
          </CardHeader>
        </Card>
      </div>

      {/* Category Hierarchy */}
      <Card>
        <CardHeader>
          <CardTitle>Category Hierarchy</CardTitle>
          <CardDescription>
            Expand categories to view sub-categories. Click icons to edit or delete.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {categories.map((category: Category) => {
              const categorySubCategories = getSubCategoriesByCategory(category._id)
              return (
                <AccordionItem key={category._id} value={category._id}>
                  <div className="flex items-center justify-between gap-4">
                    <AccordionTrigger className="hover:no-underline flex-1">
                      <div className="flex w-full items-center gap-2 pr-4">
                        <span className="font-medium">{category.name}</span>
                        <span className="text-muted-foreground text-sm">
                          - {categorySubCategories.length}{" "}
                          {categorySubCategories.length === 1 ? "sub-category" : "sub-categories"}
                        </span>
                      </div>
                    </AccordionTrigger>
                    <div className="flex items-center gap-1">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span tabIndex={hasUpdatePermission ? -1 : 0}>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  setCategoryDialog({ open: true, mode: "edit", category })
                                }}
                                disabled={!hasUpdatePermission || permissionsLoading}
                                className="inline-flex h-8 w-8 items-center justify-center rounded-md hover:bg-accent hover:text-accent-foreground disabled:opacity-50 disabled:pointer-events-none"
                                aria-label="Edit category"
                              >
                                <Edit className="h-4 w-4" />
                              </button>
                            </span>
                          </TooltipTrigger>
                          <TooltipContent>
                            {hasUpdatePermission ? "Edit category" : "You don't have permission to edit"}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span tabIndex={hasDeletePermission ? -1 : 0}>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  setDeleteDialog({
                                    open: true,
                                    type: "category",
                                    id: category._id,
                                    name: category.name,
                                  })
                                }}
                                disabled={!hasDeletePermission || permissionsLoading}
                                className="inline-flex h-8 w-8 items-center justify-center rounded-md hover:bg-accent hover:text-destructive disabled:opacity-50 disabled:pointer-events-none"
                                aria-label="Delete category"
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </button>
                            </span>
                          </TooltipTrigger>
                          <TooltipContent>
                            {hasDeletePermission ? "Delete category" : "You don't have permission to delete"}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </div>
                  <AccordionContent>
                    <div className="ml-6 space-y-2">
                      <div className="flex items-center justify-between mb-2">
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span tabIndex={hasCreatePermission ? -1 : 0}>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() =>
                                    setSubCategoryDialog({
                                      open: true,
                                      mode: "create",
                                      categoryId: category._id,
                                      categoryName: category.name,
                                    })
                                  }
                                  disabled={!hasCreatePermission || permissionsLoading}
                                  className="gap-2 h-8 text-muted-foreground hover:text-foreground"
                                >
                                  <Plus className="h-3.5 w-3.5" />
                                  Add Sub-Category
                                </Button>
                              </span>
                            </TooltipTrigger>
                            {!hasCreatePermission && !permissionsLoading && (
                              <TooltipContent>
                                <p>You don't have permission to create business categories</p>
                              </TooltipContent>
                            )}
                          </Tooltip>
                        </TooltipProvider>
                      </div>

                      {categorySubCategories.length > 0 ? (
                        <ul className="space-y-1">
                          {categorySubCategories.map((sub: SubCategory) => (
                            <li
                              key={sub._id}
                              className="flex items-center justify-between rounded-md py-2 px-3 hover:bg-muted"
                            >
                              <span>{sub.name}</span>
                              <div className="flex items-center gap-1">
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <span tabIndex={hasUpdatePermission ? -1 : 0}>
                                        <Button
                                          size="icon"
                                          variant="ghost"
                                          className="h-8 w-8"
                                          disabled={!hasUpdatePermission || permissionsLoading}
                                          onClick={() =>
                                            setSubCategoryDialog({
                                              open: true,
                                              mode: "edit",
                                              subCategory: sub,
                                            })
                                          }
                                        >
                                          <Edit className="h-4 w-4" />
                                        </Button>
                                      </span>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      {hasUpdatePermission ? "Edit sub-category" : "You don't have permission to edit"}
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <span tabIndex={hasDeletePermission ? -1 : 0}>
                                        <Button
                                          size="icon"
                                          variant="ghost"
                                          className="h-8 w-8"
                                          disabled={!hasDeletePermission || permissionsLoading}
                                          onClick={() =>
                                            setDeleteDialog({
                                              open: true,
                                              type: "subcategory",
                                              id: sub._id,
                                              name: sub.name,
                                            })
                                          }
                                        >
                                          <Trash2 className="h-4 w-4 text-destructive" />
                                        </Button>
                                      </span>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      {hasDeletePermission ? "Delete sub-category" : "You don't have permission to delete"}
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              </div>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-muted-foreground text-sm">
                          No sub-categories yet. Click "Add Sub-Category" to create one.
                        </p>
                      )}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              )
            })}
          </Accordion>

          {categories.length === 0 && (
            <p className="text-muted-foreground text-center py-8">
              No categories yet. Click "Add Category" to create one.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Dialogs */}
      <CategoryDialog
        mode={categoryDialog.mode}
        category={categoryDialog.category}
        open={categoryDialog.open}
        onOpenChange={(open) => setCategoryDialog({ ...categoryDialog, open })}
        onSuccess={() => setCategoryDialog({ open: false, mode: "create" })}
      />

      <SubCategoryDialog
        mode={subCategoryDialog.mode}
        subCategory={subCategoryDialog.subCategory}
        categoryId={subCategoryDialog.categoryId}
        categoryName={subCategoryDialog.categoryName}
        open={subCategoryDialog.open}
        onOpenChange={(open) => setSubCategoryDialog({ ...subCategoryDialog, open })}
        onSuccess={() => setSubCategoryDialog({ open: false, mode: "create" })}
      />

      <AlertDialog open={deleteDialog.open} onOpenChange={(open) => setDeleteDialog({ ...deleteDialog, open })}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete <strong>{deleteDialog.name}</strong>.
              {deleteDialog.type === "category" && (
                <span className="block mt-2 text-destructive font-semibold">
                  Warning: This action will fail if there are related sub-categories or businesses using this category.
                </span>
              )}
              {deleteDialog.type === "subcategory" && (
                <span className="block mt-2 text-destructive font-semibold">
                  Warning: This action will fail if there are businesses using this sub-category.
                </span>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
    </PermissionGuard>
  )
}
