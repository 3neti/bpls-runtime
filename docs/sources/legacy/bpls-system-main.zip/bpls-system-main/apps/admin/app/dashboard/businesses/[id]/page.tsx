import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { ConvexError } from "convex/values"
import { api } from "@repo/backend/convex/_generated/api"
import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"
import { BusinessDetailClient } from "./business-detail-client"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

export default async function BusinessDetailPage(props: { params: Promise<{ id: string }> }) {
  const params = await props.params
  const { id } = params
  const businessId = id as Id<"businesses">
  const token = await convexAuthNextjsToken()

  try {
    // Preload business data on the server with LOB details
    const [preloadedBusiness, preloadedActivityLogs] = await Promise.all([
      preloadQuery(
        api.businesses.getWithLOBDetails,
        { id: businessId },
        { token }
      ),
      preloadQuery(
        api.activityLogs.getResourceHistory,
        { resourceType: "business", resourceId: id, limit: 20 },
        { token }
      ),
    ])

    return (
      <BusinessDetailClient
        preloadedBusiness={preloadedBusiness}
        preloadedActivityLogs={preloadedActivityLogs}
        businessId={businessId}
      />
    )
  } catch (error) {
    if (error instanceof ConvexError) {
      const errorData = error.data as {
        code?: string
        message?: string
        details?: {
          resource?: string
          action?: string
          userRole?: string
          requiredPermission?: string
        }
      }

      if (errorData.code === "PERMISSION_DENIED") {
        return (
          <PermissionDenied
            title="Business Details"
            description="View business information"
            message={errorData.message}
            details={errorData.details}
            resourceName="business"
            backLink="/dashboard/businesses"
            backLinkText="Back to Businesses"
          />
        )
      }

      if (errorData.code === "UNAUTHENTICATED") {
        return <AuthenticationRequired />
      }
    }

    throw error
  }
}
