import { Suspense } from "react"
import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import { DivisionDetailClient } from "./division-detail-client"
import { Skeleton } from "@repo/ui/components/skeleton"

interface DivisionDetailPageProps {
  params: Promise<{ id: Id<"divisions"> }>
}

export default async function DivisionDetailPage({ params }: DivisionDetailPageProps) {
  const token = await convexAuthNextjsToken()

  const { id } = await params
  const preloadedDivision = await preloadQuery(api.divisions.getWithFees, { divisionId: id }, { token })
  const preloadedAppliedGroups = await preloadQuery(api.divisions.getAppliedGroups, { divisionId: id }, { token })
  const preloadedFeeNames = await preloadQuery(api.feeNames.list, {}, { token })

  return (
    <Suspense fallback={<DivisionDetailSkeleton />}>
      <DivisionDetailClient
        preloadedDivision={preloadedDivision}
        preloadedAppliedGroups={preloadedAppliedGroups}
        preloadedFeeNames={preloadedFeeNames}
        divisionId={id}
      />
    </Suspense>
  )
}

function DivisionDetailSkeleton() {
  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center space-x-4">
        <Skeleton className="h-8 w-8" />
        <Skeleton className="h-9 w-[300px]" />
      </div>
      <Skeleton className="h-[200px] w-full" />
      <Skeleton className="h-[400px] w-full" />
      <Skeleton className="h-[300px] w-full" />
    </div>
  )
}
