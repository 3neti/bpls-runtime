"use client"

import { useState, useMemo, useCallback, useEffect } from "react"
import { Search, Download, Award, Eye, ExternalLink, Loader2, ChevronDown, Trash2, ChevronLeft, ChevronRight } from "lucide-react"
import { useRouter } from "next/navigation"
import { usePreloadedQuery, useMutation, useQuery, usePaginatedQuery } from "convex/react"
import type { Preloaded } from "convex/react"
import { PDFDownloadLink, PDFViewer } from "@react-pdf/renderer"
import QRCode from "qrcode"
import {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table"

import { Button } from "@repo/ui/components/button"
import { Input } from "@repo/ui/components/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@repo/ui/components/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import { Badge } from "@repo/ui/components/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@repo/ui/components/avatar"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog"
import { api } from "@repo/backend/convex/_generated/api"
import { MayorsPermitDocument, type MayorsPermitData, type PermitLayoutConfig } from "@/components/permit/mayors-permit-document"
import {
  convertToCSV,
  downloadCSV,
  generateExportFilename,
  formatDateForCSV,
  type CSVColumn,
} from "@/lib/utils/csv-export"
import {
  TableFilterPopover,
  createDefaultFilterState,
  type FilterConfig,
  type FilterState,
} from "@/components/permits/table-filter-popover"
import { useColumnVisibilityStore } from "@/lib/stores/column-visibility-store"
import { cn } from "@/lib/utils"
import { formatDate, getInitials } from "@/lib/utils/formatting"
import { PermissionGuard } from "@/components/permission-guard"
import { usePermissions } from "@/hooks/use-permissions"
import { useToast } from "@/hooks/use-toast"
import type { Id } from "@repo/backend/convex/_generated/dataModel"

// Status options for permits table
const STATUS_OPTIONS = [
  { value: "Active", label: "Active" },
  { value: "Expired", label: "Expired" },
  { value: "Pending", label: "Pending" },
]

// Filter config for permits table
const FILTER_CONFIG: FilterConfig = {
  statusOptions: STATUS_OPTIONS,
  showDateRange: true,
  showTypeFilter: false,
}

// Type for transformed permit data
type TransformedPermit = {
  _id: string
  permitNumber?: string
  issuedAt?: string
  expiryDate: string
  dateReleased?: string
  status: string
  businessName: string
  ownerName: string
  businessAddress?: string
  ownerAvatar?: string
}

// Platform settings type for PDF generation
interface PlatformSettingsForPdf {
  municipalityName?: string
  mayorName?: string
  mayorTitle?: string
  provinceName?: string
  fullAddress?: string
  treasurerName?: string
}

// Actions cell component that handles QR code generation for each row
function PermitActionsCell({
  permit,
  onViewPermit,
  onDelete,
  layoutConfig,
  platformSettings,
}: {
  permit: {
    _id: string
    permitNumber?: string
    issuedAt?: string
    expiryDate: string
    businessName: string
    ownerName: string
    businessAddress?: string
  }
  onViewPermit: (permit: TransformedPermit) => void
  onDelete?: (permitId: string) => void
  layoutConfig: PermitLayoutConfig | null
  platformSettings: PlatformSettingsForPdf | null
}) {
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>("")
  const [isClient, setIsClient] = useState(false)

  // Generate verification URL
  const verificationUrl = useMemo(() => {
    if (typeof window !== "undefined") {
      return `${window.location.origin}/permits/verify/${permit._id}`
    }
    return ""
  }, [permit._id])

  // Client-side detection and QR code generation
  useEffect(() => {
    setIsClient(true)
    if (verificationUrl) {
      QRCode.toDataURL(verificationUrl, {
        width: 200,
        margin: 1,
        color: { dark: "#000000", light: "#ffffff" },
      })
        .then((url) => setQrCodeDataUrl(url))
        .catch((err) => console.error("QR Code generation failed:", err))
    }
  }, [verificationUrl])

  // Prepare PDF data with layout and platform settings
  const pdfPermitData: MayorsPermitData | null = useMemo(() => {
    if (!qrCodeDataUrl) return null
    return {
      businessName: permit.businessName,
      ownerName: permit.ownerName,
      businessAddress: permit.businessAddress || "",
      permitNumber: permit.permitNumber || "",
      dateIssued: permit.issuedAt || "",
      expirationDate: permit.expiryDate || "",
      qrCodeDataUrl,
      applicationNumber: permit.permitNumber?.replace("BP-", "BPA-") || "",
      // Platform settings
      municipalityName: platformSettings?.municipalityName || "",
      mayorName: platformSettings?.mayorName || "",
      mayorTitle: platformSettings?.mayorTitle || "Municipal Mayor",
      provinceName: platformSettings?.provinceName || "",
      fullAddress: platformSettings?.fullAddress || "",
      treasurerName: platformSettings?.treasurerName || "",
    }
  }, [permit, qrCodeDataUrl, platformSettings])

  const handleViewVerificationUrl = (e: React.MouseEvent) => {
    e.stopPropagation()
    window.open(verificationUrl, "_blank")
  }

  const handleViewPermit = (e: React.MouseEvent) => {
    e.stopPropagation()
    onViewPermit({
      _id: permit._id,
      permitNumber: permit.permitNumber,
      issuedAt: permit.issuedAt,
      expiryDate: permit.expiryDate,
      businessName: permit.businessName,
      ownerName: permit.ownerName,
      businessAddress: permit.businessAddress,
      status: "Active",
    })
  }

  return (
    <TooltipProvider>
      <div className="flex items-center justify-end gap-1" onClick={(e) => e.stopPropagation()}>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={handleViewPermit}
            >
              <Eye className="h-4 w-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>View Permit</p>
          </TooltipContent>
        </Tooltip>

        {isClient && qrCodeDataUrl && pdfPermitData ? (
          <PDFDownloadLink
            document={<MayorsPermitDocument data={pdfPermitData} layout={layoutConfig} />}
            fileName={`business-permit-${pdfPermitData.permitNumber}.pdf`}
            onClick={(e) => e.stopPropagation()}
          >
            {({ loading }) => (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    disabled={loading}
                  >
                    {loading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Download className="h-4 w-4" />
                    )}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{loading ? "Preparing..." : "Download PDF"}</p>
                </TooltipContent>
              </Tooltip>
            )}
          </PDFDownloadLink>
        ) : (
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8" disabled>
                <Loader2 className="h-4 w-4 animate-spin" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Loading...</p>
            </TooltipContent>
          </Tooltip>
        )}

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={handleViewVerificationUrl}
            >
              <ExternalLink className="h-4 w-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Verification URL</p>
          </TooltipContent>
        </Tooltip>

        {onDelete && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                onClick={(e) => {
                  e.stopPropagation()
                  onDelete(permit._id)
                }}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Delete permit</p>
            </TooltipContent>
          </Tooltip>
        )}
      </div>
    </TooltipProvider>
  )
}

const getStatusBadge = (status: string, expiryDate: string) => {
  const isExpired = new Date(expiryDate) < new Date()

  if (isExpired && status === "Active") {
    return (
      <Badge variant="destructive">
        Expired
      </Badge>
    )
  }

  switch (status) {
    case "Active":
      return (
        <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-100">
          Active
        </Badge>
      )
    case "Expired":
      return <Badge variant="destructive">Expired</Badge>
    case "Pending":
      return (
        <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
          Pending
        </Badge>
      )
    case "Rejected":
      return <Badge variant="outline">Rejected</Badge>
    default:
      return <Badge variant="outline">{status}</Badge>
  }
}

// Column definitions factory
function createColumns(
  handleViewPermit: (permit: TransformedPermit) => void,
  handleDelete: ((permitId: string) => void) | undefined,
  layoutConfig: PermitLayoutConfig | null,
  platformSettings: PlatformSettingsForPdf | null
): ColumnDef<TransformedPermit>[] {
  return [
    {
      id: "permitNumber",
      accessorKey: "permitNumber",
      header: "Permit Number",
      cell: ({ row }) => (
        <span className="font-medium font-mono">
          {row.original.permitNumber || row.original._id}
        </span>
      ),
    },
    {
      id: "businessName",
      accessorKey: "businessName",
      header: "Business Name",
      cell: ({ row }) => row.original.businessName,
    },
    {
      id: "ownerName",
      accessorKey: "ownerName",
      header: "Business Owner",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8">
            <AvatarImage src={row.original.ownerAvatar} alt={row.original.ownerName} />
            <AvatarFallback className="text-xs">
              {getInitials(row.original.ownerName)}
            </AvatarFallback>
          </Avatar>
          <span className="font-medium text-sm">{row.original.ownerName}</span>
        </div>
      ),
    },
    {
      id: "issuedAt",
      accessorKey: "issuedAt",
      header: "Issued Date",
      cell: ({ row }) => formatDate(row.original.issuedAt, "short") || "N/A",
    },
    {
      id: "expiryDate",
      accessorKey: "expiryDate",
      header: "Expiry Date",
      cell: ({ row }) => formatDate(row.original.expiryDate, "short") || "N/A",
    },
    {
      id: "status",
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => getStatusBadge(row.original.status, row.original.expiryDate),
    },
    {
      id: "actions",
      header: () => <span className="text-right block">Actions</span>,
      cell: ({ row }) => (
        <PermitActionsCell
          permit={{
            _id: row.original._id,
            permitNumber: row.original.permitNumber,
            issuedAt: row.original.issuedAt,
            expiryDate: row.original.expiryDate,
            businessName: row.original.businessName,
            ownerName: row.original.ownerName,
            businessAddress: row.original.businessAddress,
          }}
          onViewPermit={handleViewPermit}
          onDelete={handleDelete}
          layoutConfig={layoutConfig}
          platformSettings={platformSettings}
        />
      ),
      enableHiding: false,
    },
  ]
}

// Page size constant - should match server component
const PAGE_SIZE = 20

interface PermitsListClientProps {
  preloadedPermits: Preloaded<typeof api.permits.getPermitsWithOwnersPaginated>
  preloadedCount: Preloaded<typeof api.permits.getPermitsCount>
}

export function PermitsListClient({ preloadedPermits, preloadedCount }: PermitsListClientProps) {
  const router = useRouter()
  const { toast } = useToast()
  const { canDelete } = usePermissions()
  const canDeletePermit = canDelete("permits")

  // Get preloaded data
  const initialData = usePreloadedQuery(preloadedPermits)
  const totalCount = usePreloadedQuery(preloadedCount) || 0

  // Calculate total pages
  const totalPages = Math.ceil(totalCount / PAGE_SIZE)

  // Pagination state - track current page and cursors for each page
  const [currentPage, setCurrentPage] = useState(0)
  const [pageCursors, setPageCursors] = useState<(string | null)[]>([null]) // First page has null cursor

  // Fetch subsequent pages when needed (skip for page 0 which uses preloaded data)
  const paginatedResult = useQuery(
    api.permits.getPermitsWithOwnersPaginated,
    currentPage === 0
      ? "skip"
      : { paginationOpts: { numItems: PAGE_SIZE, cursor: pageCursors[currentPage] ?? null } }
  )

  // Get current page data
  const currentData = currentPage === 0 ? initialData : paginatedResult
  const permits = currentData?.page || []
  const continueCursor = currentData?.continueCursor
  const isDone = currentData?.isDone ?? true

  // Pagination handlers
  const handleNextPage = useCallback(() => {
    if (continueCursor && currentPage < totalPages - 1) {
      // Store the cursor for the next page
      setPageCursors((prev) => {
        const newCursors = [...prev]
        if (newCursors.length <= currentPage + 1) {
          newCursors.push(continueCursor)
        }
        return newCursors
      })
      setCurrentPage((prev) => prev + 1)
    }
  }, [continueCursor, currentPage, totalPages])

  const handlePrevPage = useCallback(() => {
    if (currentPage > 0) {
      setCurrentPage((prev) => prev - 1)
    }
  }, [currentPage])

  // Check if we can go next (has cursor for next page or we haven't stored it yet)
  const canGoNext = !isDone && currentPage < totalPages - 1
  const canGoPrev = currentPage > 0

  // Loading state for non-preloaded pages
  const isLoading = currentPage > 0 && !paginatedResult

  // Table state
  const [sorting, setSorting] = useState<SortingState>([])
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([])
  const [filters, setFilters] = useState<FilterState>(createDefaultFilterState())

  // Delete state
  const [deletePermitId, setDeletePermitId] = useState<Id<"permits"> | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)
  const deletePermit = useMutation(api.permits.softDelete)

  // View permit modal state
  const [viewPermit, setViewPermit] = useState<TransformedPermit | null>(null)
  const [viewQrCodeDataUrl, setViewQrCodeDataUrl] = useState<string>("")
  const [isClient, setIsClient] = useState(false)

  // Fetch permit layout configuration for PDF generation
  const permitLayout = useQuery(api.permitLayouts.get)
  const backgroundImageUrl = useQuery(api.permitLayouts.getBackgroundImageUrl)

  // Fetch platform settings for municipality info
  const platformSettings = useQuery(api.platformSettings.get)

  // Client-side detection
  useEffect(() => {
    setIsClient(true)
  }, [])

  // Generate QR code when viewing a permit
  useEffect(() => {
    if (viewPermit && isClient) {
      const verificationUrl = `${window.location.origin}/permits/verify/${viewPermit._id}`
      QRCode.toDataURL(verificationUrl, {
        width: 200,
        margin: 1,
        color: { dark: "#000000", light: "#ffffff" },
      })
        .then((url) => setViewQrCodeDataUrl(url))
        .catch((err) => console.error("QR Code generation failed:", err))
    } else {
      setViewQrCodeDataUrl("")
    }
  }, [viewPermit, isClient])

  // Build layout config from permit layout
  const layoutConfig: PermitLayoutConfig | null = useMemo(() => {
    if (!permitLayout) return null

    return {
      paperSize: permitLayout.paperSize,
      orientation: permitLayout.orientation,
      marginTop: permitLayout.marginTop,
      marginRight: permitLayout.marginRight,
      marginBottom: permitLayout.marginBottom,
      marginLeft: permitLayout.marginLeft,
      headerTemplate: permitLayout.headerTemplate,
      bodyTemplate: permitLayout.bodyTemplate,
      footerTemplate: permitLayout.footerTemplate,
      qrCodeSize: permitLayout.qrCodeSize,
      logoUrl: undefined,
      sealUrl: undefined,
      backgroundImageUrl: backgroundImageUrl ?? undefined,
      backgroundImageOpacity: permitLayout.backgroundImageOpacity,
      backgroundImageWidth: permitLayout.backgroundImageWidth,
      backgroundImageHeight: permitLayout.backgroundImageHeight,
    }
  }, [permitLayout, backgroundImageUrl])

  // Build platform settings for PDF
  const platformSettingsForPdf: PlatformSettingsForPdf | null = useMemo(() => {
    if (!platformSettings) return null

    return {
      municipalityName: platformSettings.municipalityName,
      mayorName: platformSettings.mayorName,
      mayorTitle: platformSettings.mayorTitle,
      provinceName: platformSettings.provinceName,
      fullAddress: platformSettings.fullAddress,
      treasurerName: platformSettings.treasurerName,
    }
  }, [platformSettings])

  // Build PDF data for the viewed permit
  const viewPdfPermitData: MayorsPermitData | null = useMemo(() => {
    if (!viewPermit || !viewQrCodeDataUrl) return null
    return {
      businessName: viewPermit.businessName,
      ownerName: viewPermit.ownerName,
      businessAddress: viewPermit.businessAddress || "",
      permitNumber: viewPermit.permitNumber || "",
      dateIssued: viewPermit.issuedAt || "",
      expirationDate: viewPermit.expiryDate || "",
      qrCodeDataUrl: viewQrCodeDataUrl,
      applicationNumber: viewPermit.permitNumber?.replace("BP-", "BPA-") || "",
      // Platform settings
      municipalityName: platformSettings?.municipalityName || "",
      mayorName: platformSettings?.mayorName || "",
      mayorTitle: platformSettings?.mayorTitle || "Municipal Mayor",
      provinceName: platformSettings?.provinceName || "",
      fullAddress: platformSettings?.fullAddress || "",
      treasurerName: platformSettings?.treasurerName || "",
    }
  }, [viewPermit, viewQrCodeDataUrl, platformSettings])

  // Use Zustand store for column visibility
  const { permitsColumns, setPermitsColumns } = useColumnVisibilityStore()

  // Transform data for display
  const transformedPermits = useMemo((): TransformedPermit[] => {
    return permits.map((permit: typeof permits[number]) => ({
      _id: permit._id,
      permitNumber: permit.permitNumber,
      issuedAt: permit.issuedAt,
      expiryDate: permit.expiryDate,
      dateReleased: permit.dateReleased,
      status: permit.status,
      businessName: permit.business?.name ?? "Unknown Business",
      ownerName: permit.owner
        ? `${permit.owner.firstName} ${permit.owner.lastName}`
        : "Unknown Owner",
      businessAddress: permit.business?.address ?? "",
      ownerAvatar: permit.owner?.avatar,
    }))
  }, [permits])

  // Apply custom filters to data
  const filteredData = useMemo(() => {
    let result = [...transformedPermits]

    // Status filter
    if (filters.statuses.length > 0) {
      result = result.filter((permit) => {
        // Check for expired status override
        const isExpired = new Date(permit.expiryDate) < new Date()
        const displayStatus = isExpired && permit.status === "Active" ? "Expired" : permit.status
        return filters.statuses.includes(displayStatus)
      })
    }

    // Date range filter (using issuedAt)
    if (filters.dateRange.from || filters.dateRange.to) {
      result = result.filter((permit) => {
        if (!permit.issuedAt) return true
        const itemDate = new Date(permit.issuedAt)
        if (filters.dateRange.from && itemDate < filters.dateRange.from) return false
        if (filters.dateRange.to && itemDate > filters.dateRange.to) return false
        return true
      })
    }

    return result
  }, [transformedPermits, filters])

  // View permit handler - opens modal with PDF
  const handleViewPermit = useCallback((permit: TransformedPermit) => {
    setViewPermit(permit)
  }, [])

  // Handle delete action
  const handleDeleteClick = useCallback((permitId: string) => {
    setDeletePermitId(permitId as Id<"permits">)
  }, [])

  const handleDelete = async () => {
    if (!deletePermitId) return

    setIsDeleting(true)
    try {
      await deletePermit({ id: deletePermitId })
      toast({
        title: "Success",
        description: "Permit deleted successfully",
      })
      setDeletePermitId(null)
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete permit",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  // Create columns with handlers
  const columns = useMemo(
    () => createColumns(
      handleViewPermit,
      canDeletePermit ? handleDeleteClick : undefined,
      layoutConfig,
      platformSettingsForPdf
    ),
    [handleViewPermit, handleDeleteClick, canDeletePermit, layoutConfig, platformSettingsForPdf]
  )

  // Export handler
  const handleExport = useCallback(() => {
    const exportColumns: CSVColumn<TransformedPermit>[] = [
      { header: "Permit Number", accessor: (row) => row.permitNumber || row._id },
      { header: "Business Name", accessor: (row) => row.businessName },
      { header: "Owner Name", accessor: (row) => row.ownerName },
      { header: "Status", accessor: (row) => row.status },
      { header: "Issued Date", accessor: (row) => formatDateForCSV(row.issuedAt) },
      { header: "Date Released", accessor: (row) => formatDateForCSV(row.dateReleased) },
      { header: "Expiry Date", accessor: (row) => formatDateForCSV(row.expiryDate) },
    ]

    const csv = convertToCSV(filteredData, exportColumns)
    downloadCSV(csv, generateExportFilename("permits"))
  }, [filteredData])

  // Table instance - server-side pagination, no client-side pagination
  const table = useReactTable({
    data: filteredData,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onColumnVisibilityChange: setPermitsColumns,
    state: {
      sorting,
      columnFilters,
      columnVisibility: permitsColumns,
    },
  })

  // Row click handler
  const handleRowClick = (permitId: string) => {
    router.push(`/dashboard/permits/${permitId}`)
  }

  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Permits</h2>
          <p className="text-muted-foreground">
            View all issued Business Permits
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5" />
            Issued Permits
          </CardTitle>
          <CardDescription>
            A list of all Business Permits issued by the municipality
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Toolbar */}
          <div className="flex items-center space-x-2 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by permit number, business name, or owner..."
                value={(table.getColumn("permitNumber")?.getFilterValue() as string) ?? ""}
                onChange={(event) =>
                  table.getColumn("permitNumber")?.setFilterValue(event.target.value)
                }
                className="pl-8"
              />
            </div>

            {/* Columns Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  Columns <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[200px]">
                {table
                  .getAllColumns()
                  .filter((column) => column.getCanHide())
                  .map((column) => {
                    // Format column display name
                    const displayName = column.id
                      .replace(/([A-Z])/g, ' $1')
                      .replace(/^./, str => str.toUpperCase())
                      .trim()

                    return (
                      <DropdownMenuCheckboxItem
                        key={column.id}
                        className="capitalize"
                        checked={column.getIsVisible()}
                        onCheckedChange={(value) =>
                          column.toggleVisibility(!!value)
                        }
                      >
                        {displayName}
                      </DropdownMenuCheckboxItem>
                    )
                  })}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Filter Popover */}
            <TableFilterPopover
              config={FILTER_CONFIG}
              filters={filters}
              onFiltersChange={setFilters}
            />

            {/* Export Button */}
            <PermissionGuard resource="reports" action="read" fallback={null}>
              <Button variant="outline" onClick={handleExport}>
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </PermissionGuard>
          </div>

          {/* Table */}
          <div className="rounded-lg border bg-card">
            <Table>
              <TableHeader>
                {table.getHeaderGroups().map((headerGroup) => (
                  <TableRow key={headerGroup.id}>
                    {headerGroup.headers.map((header) => (
                      <TableHead key={header.id}>
                        {header.isPlaceholder
                          ? null
                          : flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                      </TableHead>
                    ))}
                  </TableRow>
                ))}
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell
                      colSpan={columns.length}
                      className="h-24 text-center"
                    >
                      <div className="flex items-center justify-center gap-2">
                        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                        <span className="text-muted-foreground">Loading...</span>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : table.getRowModel().rows?.length ? (
                  table.getRowModel().rows.map((row) => (
                    <TableRow
                      key={row.id}
                      className={cn(
                        "hover:bg-muted/50 transition-colors cursor-pointer"
                      )}
                      onClick={() => handleRowClick(row.original._id)}
                    >
                      {row.getVisibleCells().map((cell) => (
                        <TableCell key={cell.id}>
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell
                      colSpan={columns.length}
                      className="h-24 text-center"
                    >
                      No permits found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>

          {/* Server-Side Pagination */}
          <div className="flex items-center justify-between px-2 pt-4">
            <div className="flex-1 text-sm text-muted-foreground">
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Loading...
                </span>
              ) : (
                <>
                  Page {currentPage + 1} of {totalPages} ({totalCount} total permit{totalCount !== 1 ? "s" : ""})
                </>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handlePrevPage}
                disabled={!canGoPrev || isLoading}
              >
                <ChevronLeft className="h-4 w-4 mr-1" />
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleNextPage}
                disabled={!canGoNext || isLoading}
              >
                Next
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* View Permit PDF Modal */}
      <Dialog open={!!viewPermit} onOpenChange={(open) => !open && setViewPermit(null)}>
        <DialogContent className="sm:max-w-[95vw] w-full h-[90vh] flex flex-col p-0">
          <DialogHeader className="flex-shrink-0 px-6 py-4 border-b">
            <div className="flex items-center justify-between">
              <DialogTitle className="flex items-center gap-2">
                <Award className="h-5 w-5" />
                Business Permit - {viewPermit?.permitNumber || viewPermit?._id}
              </DialogTitle>
              <div className="flex items-center gap-2">
                {isClient && viewQrCodeDataUrl && viewPdfPermitData && (
                  <PDFDownloadLink
                    document={<MayorsPermitDocument data={viewPdfPermitData} layout={layoutConfig} />}
                    fileName={`business-permit-${viewPdfPermitData.permitNumber}.pdf`}
                  >
                    {({ loading }) => (
                      <Button variant="outline" size="sm" disabled={loading}>
                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
                        {loading ? "Preparing..." : "Download PDF"}
                      </Button>
                    )}
                  </PDFDownloadLink>
                )}
              </div>
            </div>
          </DialogHeader>
          <div className="flex-1 overflow-hidden p-6">
            {isClient && viewQrCodeDataUrl && viewPdfPermitData ? (
              <div className="w-full h-full border rounded-lg overflow-hidden">
                <PDFViewer width="100%" height="100%" showToolbar={true}>
                  <MayorsPermitDocument data={viewPdfPermitData} layout={layoutConfig} />
                </PDFViewer>
              </div>
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deletePermitId} onOpenChange={() => setDeletePermitId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Permit?</AlertDialogTitle>
            <AlertDialogDescription>
              This will soft-delete the permit. The record can be restored later if needed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
