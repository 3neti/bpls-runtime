import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { ConvexError } from "convex/values"
import { api } from "@repo/backend/convex/_generated/api"
import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"
import BusinessOwnersClient from "./business-owners-client"

// Page size constant - should match the client component
const PAGE_SIZE = 20

export default async function BusinessOwnersPage() {
  const token = await convexAuthNextjsToken()

  try {
    // Preload paginated business owners
    const preloadedOwners = await preloadQuery(
      api.businessOwners.listPaginated,
      {
        includeBlacklisted: true,
        paginationOpts: { numItems: PAGE_SIZE, cursor: null },
      },
      { token }
    )

    // Preload count for pagination UI
    const preloadedCount = await preloadQuery(
      api.businessOwners.getBusinessOwnerCount,
      { includeBlacklisted: true },
      { token }
    )

    return (
      <BusinessOwnersClient
        preloadedOwners={preloadedOwners}
        preloadedCount={preloadedCount}
      />
    )
  } catch (error) {
    // Handle permission denied errors gracefully
    if (error instanceof ConvexError) {
      const errorData = error.data as {
        code?: string
        message?: string
        details?: {
          resource?: string
          action?: string
          userRole?: string
          requiredPermission?: string
        }
      }

      if (errorData.code === "PERMISSION_DENIED") {
        return (
          <PermissionDenied
            title="Business Owners"
            description="Manage business owner profiles"
            message={errorData.message}
            details={errorData.details}
            resourceName="business owner"
          />
        )
      }

      if (errorData.code === "UNAUTHENTICATED") {
        return <AuthenticationRequired />
      }
    }

    // Re-throw other errors
    throw error
  }
}
