import { Suspense } from "react"
import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { api } from "@repo/backend/convex/_generated/api"
import { DivisionClient } from "./division-client"
import { Skeleton } from "@repo/ui/components/skeleton"

export default async function DivisionPage() {
  const token = await convexAuthNextjsToken()

  const preloadedDivisions = await preloadQuery(api.divisions.list, {}, { token })
  const preloadedMajors = await preloadQuery(api.majors.list, {}, { token })
  const preloadedGroups = await preloadQuery(api.groups.list, {}, { token })

  return (
    <Suspense fallback={<DivisionPageSkeleton />}>
      <DivisionClient
        preloadedDivisions={preloadedDivisions}
        preloadedMajors={preloadedMajors}
        preloadedGroups={preloadedGroups}
      />
    </Suspense>
  )
}

function DivisionPageSkeleton() {
  return (
    <div className="flex-1 space-y-4 p-4 pt-6">
      <div className="flex items-center justify-between">
        <Skeleton className="h-9 w-[200px]" />
        <Skeleton className="h-10 w-[140px]" />
      </div>
      <Skeleton className="h-[500px] w-full" />
    </div>
  )
}
