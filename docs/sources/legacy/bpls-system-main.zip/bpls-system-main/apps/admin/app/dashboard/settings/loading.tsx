import { Skeleton } from "@repo/ui/components/skeleton"
import { Card, CardContent, CardHeader } from "@repo/ui/components/card"

/**
 * Loading Skeleton for Settings Page
 *
 * Matches the layout with:
 * - Header with title
 * - Navigation tabs
 * - Form sections with fields
 */
export default function SettingsLoading() {
  return (
    <div className="flex-1 space-y-6 p-4 pt-6">
      {/* Header */}
      <div className="space-y-2">
        <Skeleton className="h-9 w-[150px]" /> {/* Title */}
        <Skeleton className="h-4 w-[350px]" /> {/* Description */}
      </div>

      {/* Navigation Tabs */}
      <div className="flex gap-2 flex-wrap">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-10 w-[160px] rounded-md" />
        ))}
      </div>

      {/* Form Content */}
      <Card>
        <CardHeader className="space-y-2">
          <Skeleton className="h-6 w-[200px]" /> {/* Section Title */}
          <Skeleton className="h-4 w-[300px]" /> {/* Section Description */}
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Form Fields */}
          <div className="grid gap-6 md:grid-cols-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-4 w-[100px]" /> {/* Label */}
                <Skeleton className="h-10 w-full" /> {/* Input */}
                <Skeleton className="h-3 w-[200px]" /> {/* Description */}
              </div>
            ))}
          </div>

          {/* Textarea Field */}
          <div className="space-y-2">
            <Skeleton className="h-4 w-[80px]" />
            <Skeleton className="h-20 w-full" />
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-4 pt-4">
            <Skeleton className="h-10 w-[100px]" />
            <Skeleton className="h-10 w-[120px]" />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
