"use client"

import { useRouter } from "next/navigation"
import { ArrowLeft, AlertTriangle, Lock } from "lucide-react"
import { usePreloadedQuery } from "convex/react"

import { Button } from "@repo/ui/components/button"
import { Badge } from "@repo/ui/components/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card"
import { Alert, AlertDescription, AlertTitle } from "@repo/ui/components/alert"
import { BusinessOwnerUpdateForm } from "@/components/business-owner/business-owner-update-form"
import { ApplicationTimelineCard } from "@/components/permit/application-timeline-card"
import { usePermissions } from "@/hooks/use-permissions"
import { api } from "@repo/backend/convex/_generated/api"

import type { Preloaded } from "convex/react"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import type { BusinessOwner } from "@/lib/types/business-owners"

interface BusinessOwnerDetailClientProps {
  preloadedOwner: Preloaded<typeof api.businessOwners.get>
  preloadedActivityLogs: Preloaded<typeof api.activityLogs.getResourceHistory>
  ownerId: Id<"business_owners">
}

export function BusinessOwnerDetailClient({ preloadedOwner, preloadedActivityLogs, ownerId }: BusinessOwnerDetailClientProps) {
  const router = useRouter()
  const owner = usePreloadedQuery(preloadedOwner)
  const { canUpdate, isLoading: permissionsLoading } = usePermissions()
  const canModifyOwner = canUpdate("business_owners")

  // Not found state
  if (owner === null) {
    return (
      <div className="flex-1 space-y-4 p-4 pt-6">
        <div className="text-center py-10">
          <h1 className="text-2xl font-bold mb-4">Business Owner Not Found</h1>
          <Button onClick={() => router.push("/dashboard/business-owners")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Business Owners
          </Button>
        </div>
      </div>
    )
  }

  // Convert Convex Doc to BusinessOwner type
  const businessOwner: BusinessOwner = {
    id: owner._id,
    firstName: owner.firstName,
    middleName: owner.middleName,
    lastName: owner.lastName,
    birthDate: owner.birthDate,
    civilStatus: owner.civilStatus,
    gender: owner.gender,
    citizenship: owner.citizenship,
    tin: owner.tin,
    mobile: owner.mobile,
    email: owner.email,
    address: owner.address,
    provinceId: owner.provinceId ?? "",
    cityId: owner.cityId ?? "",
    barangayId: owner.barangayId ?? "",
    avatar: owner.avatar,
    ownerType: owner.ownerType ?? "Single",
    groupName: owner.groupName,
    isBlacklisted: owner.isBlacklisted ?? false,
    blacklistReason: owner.blacklistReason,
    blacklistedAt: owner.blacklistedAt,
    blacklistedBy: owner.blacklistedBy,
  }

  const handleSuccess = () => {
    router.refresh()
  }

  return (
    <div className="flex-1 space-y-6 p-4 pt-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.push("/dashboard/business-owners")}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Business Owner Information</h2>
          <p className="text-muted-foreground">
            {canModifyOwner ? "Update" : "View"} information for {owner.firstName} {owner.lastName}
          </p>
        </div>
      </div>

      {/* Permission Warning */}
      {!canModifyOwner && !permissionsLoading && (
        <Alert>
          <Lock className="h-4 w-4" />
          <AlertTitle>View-Only Mode</AlertTitle>
          <AlertDescription>
            You don't have permission to modify business owner information.
            All form fields are disabled.
          </AlertDescription>
        </Alert>
      )}

      {/* Blacklist Alert */}
      {owner.isBlacklisted && (
        <Alert variant="destructive" className="border-2">
          <AlertTriangle className="h-5 w-5" />
          <AlertTitle className="text-lg font-semibold">This business owner has been blacklisted</AlertTitle>
          <AlertDescription className="mt-2 space-y-2">
            <div className="space-y-1">
              <p className="font-medium">Reason:</p>
              <p className="text-sm">{owner.blacklistReason}</p>
            </div>
            <div className="flex gap-4 text-sm pt-2">
              <div>
                <span className="font-medium">Blacklisted on:</span>{" "}
                {owner.blacklistedAt
                  ? new Date(owner.blacklistedAt).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })
                  : "N/A"}
              </div>
              <div>
                <span className="font-medium">By:</span> {owner.blacklistedBy || "N/A"}
              </div>
            </div>
            <p className="text-sm pt-2 border-t border-destructive/20 mt-3 pt-3">
              This business owner cannot be selected for new permit applications.
            </p>
          </AlertDescription>
        </Alert>
      )}

      {/* Owner Classification (Read-Only) */}
      <Card>
        <CardHeader>
          <CardTitle>Owner Classification</CardTitle>
          <CardDescription>Type of business owner registration</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <p className="text-sm font-medium text-muted-foreground">Owner Type</p>
              <div>
                <Badge variant={owner.ownerType === "Single" ? "default" : "secondary"} className="text-sm">
                  {owner.ownerType === "Single" ? "Single (Individual)" : "Group (Partnership/Corporation)"}
                </Badge>
              </div>
            </div>

            {owner.ownerType === "Group" && owner.groupName && (
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Group/Organization Name</p>
                <p className="text-base font-medium">{owner.groupName}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Update Form */}
      <Card>
        <CardHeader>
          <CardTitle>Business Owner Information</CardTitle>
          <CardDescription>
            {canModifyOwner
              ? "Update personal and contact information"
              : "View personal and contact information (read-only)"
            }
          </CardDescription>
        </CardHeader>
        <CardContent>
          <BusinessOwnerUpdateForm
            businessOwner={businessOwner}
            onSuccess={handleSuccess}
            disabled={!canModifyOwner}
          />
        </CardContent>
      </Card>

      {/* Request History */}
      <ApplicationTimelineCard
        resourceId={ownerId}
        resourceType="business_owner"
        preloadedActivityLogs={preloadedActivityLogs}
      />

      {/* Navigation Button */}
      <div className="flex justify-start">
        <Button variant="outline" onClick={() => router.push("/dashboard/business-owners")}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to List
        </Button>
      </div>
    </div>
  )
}
