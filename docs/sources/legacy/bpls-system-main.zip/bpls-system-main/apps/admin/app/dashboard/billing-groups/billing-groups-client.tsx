"use client"

import { useState, useCallback } from "react"
import { usePreloadedQuery, useMutation, useQuery } from "convex/react"
import {
  Plus,
  Settings,
  Trash2,
  RotateCcw,
  ChevronRight,
  ChevronLeft,
  Layers,
  MoreHorizontal,
  Loader2,
} from "lucide-react"
import Link from "next/link"

import { usePermissions } from "@/hooks/use-permissions"
import { PermissionGuard } from "@/components/permission-guard"
import { PermissionDenied } from "@/components/permission-error-states"
import { Button } from "@repo/ui/components/button"
import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@repo/ui/components/tooltip"
import { Badge } from "@repo/ui/components/badge"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@repo/ui/components/alert-dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu"
import { useToast } from "@/hooks/use-toast"

import { api } from "@repo/backend/convex/_generated/api"
import type { Id } from "@repo/backend/convex/_generated/dataModel"
import type { Preloaded } from "convex/react"
import { formatCurrency } from "@/lib/utils"
import { BillingGroupModal } from "@/components/billing-groups/billing-group-modal"

// Page size constant - should match server component
const PAGE_SIZE = 20

interface BillingGroupsClientProps {
  preloadedBillingGroups: Preloaded<typeof api.billingGroups.listPaginated>
  preloadedDeletedGroups: Preloaded<typeof api.billingGroups.listDeleted>
  preloadedCount: Preloaded<typeof api.billingGroups.getBillingGroupCount>
}

export function BillingGroupsClient({
  preloadedBillingGroups,
  preloadedDeletedGroups,
  preloadedCount,
}: BillingGroupsClientProps) {
  const { toast } = useToast()
  const { canCreate, canUpdate, canDelete, isLoading: permissionsLoading } = usePermissions()

  // Permission checks
  const hasCreatePermission = canCreate("billing_groups:records")
  const hasUpdatePermission = canUpdate("billing_groups:records")
  const hasDeletePermission = canDelete("billing_groups:records")

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [editingGroup, setEditingGroup] = useState<{
    id: Id<"billing_groups">
    name: string
    description?: string
  } | null>(null)
  const [deletingGroupId, setDeletingGroupId] = useState<Id<"billing_groups"> | null>(null)

  // Get preloaded data
  const initialData = usePreloadedQuery(preloadedBillingGroups)
  const deletedGroups = usePreloadedQuery(preloadedDeletedGroups)
  const totalCount = usePreloadedQuery(preloadedCount) || 0

  // Calculate total pages
  const totalPages = Math.max(1, Math.ceil(totalCount / PAGE_SIZE))

  // Pagination state - track current page and cursors for each page
  const [currentPage, setCurrentPage] = useState(0)
  const [pageCursors, setPageCursors] = useState<(string | null)[]>([null]) // First page has null cursor

  // Fetch subsequent pages when needed (skip for page 0 which uses preloaded data)
  const paginatedResult = useQuery(
    api.billingGroups.listPaginated,
    currentPage === 0
      ? "skip"
      : {
          includeInactive: true,
          paginationOpts: { numItems: PAGE_SIZE, cursor: pageCursors[currentPage] ?? null },
        }
  )

  // Get current page data
  const currentData = currentPage === 0 ? initialData : paginatedResult
  const billingGroups = currentData?.page || []
  const continueCursor = currentData?.continueCursor
  const isDone = currentData?.isDone ?? true

  // Pagination handlers
  const handleNextPage = useCallback(() => {
    if (continueCursor && currentPage < totalPages - 1) {
      // Store the cursor for the next page
      setPageCursors((prev) => {
        const newCursors = [...prev]
        if (newCursors.length <= currentPage + 1) {
          newCursors.push(continueCursor)
        }
        return newCursors
      })
      setCurrentPage((prev) => prev + 1)
    }
  }, [continueCursor, currentPage, totalPages])

  const handlePrevPage = useCallback(() => {
    if (currentPage > 0) {
      setCurrentPage((prev) => prev - 1)
    }
  }, [currentPage])

  // Check if we can go next (has cursor for next page or we haven't stored it yet)
  const canGoNext = !isDone && currentPage < totalPages - 1
  const canGoPrev = currentPage > 0

  // Loading state for non-preloaded pages
  const isLoading = currentPage > 0 && !paginatedResult

  // Mutations
  const softDeleteGroup = useMutation(api.billingGroups.softDelete)
  const restoreGroup = useMutation(api.billingGroups.restore)

  const handleDelete = async () => {
    if (!deletingGroupId) return

    try {
      await softDeleteGroup({ id: deletingGroupId })
      toast({
        title: "Billing group deleted",
        description: "The billing group has been moved to trash.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete billing group",
        variant: "destructive",
      })
    } finally {
      setDeletingGroupId(null)
    }
  }

  const handleRestore = async (id: Id<"billing_groups">) => {
    try {
      await restoreGroup({ id })
      toast({
        title: "Billing group restored",
        description: "The billing group has been restored successfully.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to restore billing group",
        variant: "destructive",
      })
    }
  }

  return (
    <PermissionGuard
      resource="billing_groups:records"
      action="read"
      showLoading
      fallback={
        <PermissionDenied
          title="Billing Groups"
          description="Create and manage dynamic fee libraries with customizable fields"
          resourceName="billing groups"
          backLink="/dashboard"
          backLinkText="Back to Dashboard"
        />
      }
    >
    <div className="flex-1 space-y-6 p-4 pt-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Billing Groups</h2>
          <p className="text-muted-foreground">
            Create and manage dynamic fee libraries with customizable fields
          </p>
        </div>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <span tabIndex={hasCreatePermission ? -1 : 0}>
                <Button
                  onClick={() => setIsCreateModalOpen(true)}
                  disabled={!hasCreatePermission || permissionsLoading}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Create Billing Group
                </Button>
              </span>
            </TooltipTrigger>
            {!hasCreatePermission && !permissionsLoading && (
              <TooltipContent>
                <p>You don't have permission to create billing groups</p>
              </TooltipContent>
            )}
          </Tooltip>
        </TooltipProvider>
      </div>

      {/* Billing Groups List */}
      {isLoading ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground mb-4" />
            <p className="text-muted-foreground">Loading billing groups...</p>
          </CardContent>
        </Card>
      ) : billingGroups.length > 0 ? (
        <div className="space-y-3">
          {billingGroups.map((group) => (
            <Link
              key={group._id}
              href={`/dashboard/billing-groups/${group._id}`}
              className="block"
            >
              <Card className="group hover:bg-muted/50 transition-colors cursor-pointer">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    {/* Icon */}
                    <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Layers className="h-6 w-6 text-primary" />
                    </div>

                    {/* Main Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-base truncate">{group.name}</h3>
                        {!group.isActive && (
                          <Badge variant="secondary" className="text-xs">
                            Inactive
                          </Badge>
                        )}
                      </div>
                      {group.description ? (
                        <p className="text-sm text-muted-foreground line-clamp-1 mt-0.5">
                          {group.description}
                        </p>
                      ) : (
                        <p className="text-sm text-muted-foreground/60 mt-0.5">
                          No description
                        </p>
                      )}
                    </div>

                    {/* Stats */}
                    <div className="hidden sm:flex items-center gap-6 text-sm">
                      <div className="text-center min-w-[60px]">
                        <div className="font-semibold text-foreground">{group.fieldCount}</div>
                        <div className="text-xs text-muted-foreground">Fields</div>
                      </div>
                      <div className="text-center min-w-[60px]">
                        <div className="font-semibold text-foreground">{group.recordCount}</div>
                        <div className="text-xs text-muted-foreground">Records</div>
                      </div>
                      <div className="text-center min-w-[80px]">
                        <div className="font-semibold text-green-600">{formatCurrency(group.totalAmount || 0)}</div>
                        <div className="text-xs text-muted-foreground">Revenue</div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild onClick={(e) => e.preventDefault()}>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={(e) => {
                              e.preventDefault()
                              setEditingGroup({
                                id: group._id,
                                name: group.name,
                                description: group.description,
                              })
                            }}
                            disabled={!hasUpdatePermission || permissionsLoading}
                          >
                            <Settings className="h-4 w-4 mr-2" />
                            Edit Settings
                            {!hasUpdatePermission && !permissionsLoading && (
                              <span className="ml-auto text-xs text-muted-foreground">(No permission)</span>
                            )}
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            onClick={(e) => {
                              e.preventDefault()
                              setDeletingGroupId(group._id)
                            }}
                            className="text-destructive focus:text-destructive"
                            disabled={!hasDeletePermission || permissionsLoading}
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                            {!hasDeletePermission && !permissionsLoading && (
                              <span className="ml-auto text-xs text-muted-foreground">(No permission)</span>
                            )}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                      <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-foreground transition-colors" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}

          {/* Server-Side Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-2 pt-4">
              <div className="flex-1 text-sm text-muted-foreground">
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Loading...
                  </span>
                ) : (
                  <>
                    Page {currentPage + 1} of {totalPages} ({totalCount} total group{totalCount !== 1 ? "s" : ""})
                  </>
                )}
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handlePrevPage}
                  disabled={!canGoPrev || isLoading}
                >
                  <ChevronLeft className="h-4 w-4 mr-1" />
                  Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleNextPage}
                  disabled={!canGoNext || isLoading}
                >
                  Next
                  <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </div>
          )}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <Layers className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No billing groups yet</h3>
            <p className="text-muted-foreground mb-6 max-w-sm">
              Create your first billing group to start managing custom fee collections with dynamic fields
            </p>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <span tabIndex={hasCreatePermission ? -1 : 0}>
                    <Button
                      onClick={() => setIsCreateModalOpen(true)}
                      disabled={!hasCreatePermission || permissionsLoading}
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Create Billing Group
                    </Button>
                  </span>
                </TooltipTrigger>
                {!hasCreatePermission && !permissionsLoading && (
                  <TooltipContent>
                    <p>You don't have permission to create billing groups</p>
                  </TooltipContent>
                )}
              </Tooltip>
            </TooltipProvider>
          </CardContent>
        </Card>
      )}

      {/* Deleted Groups Section */}
      {deletedGroups && deletedGroups.length > 0 && (
        <Card className="border-dashed">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Deleted Billing Groups
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-2">
              {deletedGroups.map((group) => (
                <div
                  key={group._id}
                  className="flex items-center justify-between py-2 px-3 rounded-md bg-muted/30"
                >
                  <div className="flex items-center gap-3">
                    <Layers className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium text-sm">{group.name}</span>
                    {group.deletedAt && (
                      <span className="text-xs text-muted-foreground">
                        Deleted {new Date(group.deletedAt).toLocaleDateString()}
                      </span>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleRestore(group._id)}
                  >
                    <RotateCcw className="mr-1 h-3 w-3" />
                    Restore
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Create/Edit Modal */}
      <BillingGroupModal
        open={isCreateModalOpen || editingGroup !== null}
        onClose={() => {
          setIsCreateModalOpen(false)
          setEditingGroup(null)
        }}
        editingGroup={editingGroup}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deletingGroupId !== null} onOpenChange={() => setDeletingGroupId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Billing Group?</AlertDialogTitle>
            <AlertDialogDescription>
              This will move the billing group and all its records to trash. You can restore it
              later if needed. This action does not permanently delete the data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
    </PermissionGuard>
  )
}
