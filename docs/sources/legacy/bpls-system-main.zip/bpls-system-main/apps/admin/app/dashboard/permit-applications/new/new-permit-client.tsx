"use client";

import type React from "react";
import { useState, useRef, useEffect, useMemo } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import Webcam from "react-webcam";
import { ArrowRight, Save, Plus, Check, CheckCircle, Download, FileText, AlertCircle } from "lucide-react";
import Link from "next/link";
import { useMutation, useQuery } from "convex/react";

import { Button } from "@repo/ui/components/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog";
import { TooltipProvider } from "@repo/ui/components/tooltip";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Alert, AlertDescription } from "@repo/ui/components/alert";
import { Stepper } from "@repo/ui/components/stepper";
import { Dropzone } from "@repo/ui/components/dropzone";
import { useToast } from "@/hooks/use-toast";
import { usePlatformSettings } from "@/hooks/use-platform-settings";
import { Form } from "@repo/ui/components/form";
import { BusinessOwnerSelection } from "@/components/permit/business-owner-selection";
import { BusinessOwnerSearch } from "@/components/permit/business-owner-search";
import { BusinessOwnerForm } from "@/components/permit/business-owner-form";
import { BusinessSelection } from "@/components/permit/business-selection";
import { BusinessSearch } from "@/components/permit/business-search";
import { BusinessForm } from "@/components/permit/business-form";
import { ModeOfPaymentCard } from "@/components/permit/mode-of-payment-card";
import { PermitTransactionTypeCard } from "@/components/permit/permit-transaction-type-card";
import { ApplicationFormModal } from "@/components/permit/application-form-modal";
import { mapToFormData } from "@/components/permit/application-form-pdf";
import { BusinessPermitFormDocument } from "@/components/permit/business-permit-form-document";
import { pdf } from "@react-pdf/renderer";
import { permitFormSchema, permitFormDefaultValues, type PermitFormSchema } from "@/lib/schemas/permit-form";
import { api } from "@repo/backend/convex/_generated/api";
import type { Business } from "@/lib/types/business";
import type { BusinessOwner } from "@/lib/types/business-owners";
import type { Doc, Id } from "@repo/backend/convex/_generated/dataModel";

const steps = [
  { id: "owner", title: "Business Owner", description: "Owner information" },
  { id: "business", title: "Business Details", description: "Business information" },
  { id: "success", title: "Complete", description: "Application submitted" },
];

/**
 * Type for enriched business from Convex API with partial owner info
 */
type EnrichedBusiness = Doc<"businesses"> & {
  owner: {
    _id: string;
    firstName: string;
    middleName?: string;
    lastName: string;
    email: string;
    mobile: string;
    isBlacklisted?: boolean;
  } | null;
};

/**
 * Transform Convex business data to match UI interface
 */
function transformBusiness(convexBusiness: EnrichedBusiness): Business {
  const ownerName = convexBusiness.owner
    ? `${convexBusiness.owner.firstName} ${convexBusiness.owner.lastName}`
    : "Unknown Owner";

  // Handle ownerId conversion (can be Convex ID or legacy string ID)
  const ownerId = typeof convexBusiness.ownerId === "string" ? convexBusiness.ownerId : convexBusiness.ownerId;

  // Line of business is now managed at the permit application level, not business level
  const lineOfBusiness = "";

  return {
    id: convexBusiness._id,
    name: convexBusiness.name,
    ownerName,
    ownerId: ownerId as string,
    businessScale: convexBusiness.businessScale,
    annualRevenue: convexBusiness.annualRevenue,
    establishedDate: convexBusiness.establishedDate,
    dateStarted: convexBusiness.dateStarted,
    registrationDate: convexBusiness.registrationDate,
    registrationNumber: convexBusiness.registrationNumber,
    address: convexBusiness.address ?? "",
    buildingName: convexBusiness.buildingName,
    provinceId: convexBusiness.provinceId ?? "",
    cityId: convexBusiness.cityId ?? "",
    barangayId: convexBusiness.barangayId ?? "",
    lineOfBusiness,
    ownershipType: convexBusiness.ownershipType,
    groupName: convexBusiness.groupName,
    occupancy: convexBusiness.occupancy,
    permitPaymentCadence: convexBusiness.permitPaymentCadence,
    numberOfEmployees: convexBusiness.numberOfEmployees.toString(),
    maleEmployeeCount: convexBusiness.maleEmployeeCount,
    femaleEmployeeCount: convexBusiness.femaleEmployeeCount,
    businessArea: convexBusiness.businessArea,
    propertyIndexNumber: convexBusiness.propertyIndexNumber,
    contactNumber: convexBusiness.contactNumber,
    email: convexBusiness.email,
    documents: convexBusiness.documents?.map((doc) => ({
      storageId: doc.storageId,
      documentType: doc.documentType,
      fileName: doc.fileName,
      uploadedAt: doc.uploadedAt,
      uploadedBy: doc.uploadedBy,
      status: doc.status,
      rejectionReason: doc.rejectionReason,
    })),
    isBlacklisted: convexBusiness.isBlacklisted ?? false,
    blacklistReason: convexBusiness.blacklistReason,
    blacklistedAt: convexBusiness.blacklistedAt,
    blacklistedBy: convexBusiness.blacklistedBy,
  };
}

export function NewPermitClient() {
  const [currentStep, setCurrentStep] = useState(1);
  const [ownerSelectionMode, setOwnerSelectionMode] = useState<"none" | "existing" | "new">("none");
  const [businessSelectionMode, setBusinessSelectionMode] = useState<"none" | "new" | "existing">("none");
  const [profilePhotoPreview, setProfilePhotoPreview] = useState<string | null>(null);
  const [cameraMode, setCameraMode] = useState<"upload" | "camera">("upload");
  const [hasFormChanges, setHasFormChanges] = useState(false);
  const [showDraftModal, setShowDraftModal] = useState(false);
  const [showApplicationFormModal, setShowApplicationFormModal] = useState(false);
  const [draftName, setDraftName] = useState("");
  const [draftComments, setDraftComments] = useState("");
  const [initialFormValues, setInitialFormValues] = useState<any>(null);
  const [hasPdfDownloaded, setHasPdfDownloaded] = useState(false);
  const [submittedApplication, setSubmittedApplication] = useState<{ id: string; applicationNumber: string } | null>(
    null
  );
  const camera = useRef<Webcam>(null);
  const { toast } = useToast();
  const { mayorName } = usePlatformSettings();

  const form = useForm<PermitFormSchema>({
    resolver: zodResolver(permitFormSchema),
    defaultValues: permitFormDefaultValues,
    mode: "onChange",
  });

  const formValues = form.watch();

  // Query outstanding payment balances scoped to selected owner (fires only when owner is selected)
  const selectedOwnerId = formValues.selectedOwnerId;

  // Fetch ONLY the selected owner's businesses via the by_owner index, instead of
  // preloading the entire businesses table. Skips until an owner is selected.
  // (Previously this page preloaded api.businesses.list, which loaded all ~3,000+
  // businesses with per-row owner lookups and 500'd in production.)
  const ownerBusinessesData = useQuery(
    api.businesses.getByOwner,
    selectedOwnerId ? { ownerId: selectedOwnerId as Id<"business_owners"> } : "skip"
  );

  const businesses = useMemo(() => {
    if (!ownerBusinessesData) return [];
    return ownerBusinessesData.map(transformBusiness);
  }, [ownerBusinessesData]);

  // Only show the businesses loader once an owner is selected and the query is in flight.
  const isLoadingBusinesses = !!selectedOwnerId && ownerBusinessesData === undefined;
  const outstandingBalances = useQuery(
    api.businessPermitApplications.getBusinessesWithOutstandingBalances,
    selectedOwnerId ? { ownerId: selectedOwnerId as Id<"business_owners"> } : "skip"
  );

  // Queries for location names (used in Application Form PDF modal)
  // Note: Empty strings must be converted to undefined since Convex validators
  // accept undefined for optional ID fields, but not empty strings
  const ownerLocationData = useQuery(
    api.locations.getLocationHierarchy,
    formValues.provinceId
      ? {
          provinceId: formValues.provinceId as Id<"provinces">,
          cityId: formValues.cityId ? (formValues.cityId as Id<"cities">) : undefined,
          barangayId: formValues.barangayId ? (formValues.barangayId as Id<"barangays">) : undefined,
        }
      : "skip"
  );

  const businessLocationData = useQuery(
    api.locations.getLocationHierarchy,
    formValues.businessProvinceId
      ? {
          provinceId: formValues.businessProvinceId as Id<"provinces">,
          cityId: formValues.businessCityId ? (formValues.businessCityId as Id<"cities">) : undefined,
          barangayId: formValues.businessBarangayId ? (formValues.businessBarangayId as Id<"barangays">) : undefined,
        }
      : "skip"
  );

  useEffect(() => {
    if (!initialFormValues) {
      setInitialFormValues(formValues);
    } else {
      const hasChanges = JSON.stringify(formValues) !== JSON.stringify(initialFormValues);
      setHasFormChanges(hasChanges);
    }
  }, [formValues, initialFormValues]);

  // Auto-download PDF when reaching Step 3 (success page)
  useEffect(() => {
    const downloadPdf = async () => {
      if (currentStep === 3 && submittedApplication && !hasPdfDownloaded) {
        try {
          // Build application data for PDF
          const applicationData = {
            applicationNumber: submittedApplication.applicationNumber,
            permitApplicationType: formValues.permitApplicationType as "New" | "Renewal" | "Additional" | undefined,
            modeOfPayment: formValues.modeOfPayment as "Annually" | "Semi-Annually" | "Quarterly" | undefined,
            submittedAt: new Date().toISOString(),
            businessOwner: formValues.firstName
              ? {
                  firstName: formValues.firstName,
                  middleName: formValues.middleName,
                  lastName: formValues.lastName || "",
                  birthDate: formValues.birthDate || "",
                  civilStatus: formValues.civilStatus || "",
                  gender: formValues.gender || "",
                  citizenship: formValues.citizenship || "",
                  tin: formValues.tin,
                  mobile: formValues.mobile || "",
                  email: formValues.email || "",
                  address: formValues.address,
                }
              : null,
            business: formValues.businessName
              ? {
                  name: formValues.businessName,
                  establishedDate: formValues.dateEstablished || "",
                  ownershipType: formValues.ownershipType || "",
                  occupancy: formValues.occupancy || "",
                  permitPaymentCadence: formValues.permitPaymentCadence || "",
                  maleEmployeeCount: formValues.maleEmployeeCount || 0,
                  femaleEmployeeCount: formValues.femaleEmployeeCount || 0,
                  contactNumber: formValues.businessContactNumber || "",
                  email: formValues.businessEmail || "",
                  address: formValues.businessAddress,
                  buildingName: formValues.businessBuildingName,
                  businessArea: formValues.businessArea,
                  propertyIndexNumber: formValues.propertyIndexNumber,
                }
              : null,
            linesOfBusiness: [],
            provinceName: businessLocationData?.province?.name,
            cityName: businessLocationData?.city?.name,
            barangayName: businessLocationData?.barangay?.name,
            ownerProvinceName: ownerLocationData?.province?.name,
            ownerCityName: ownerLocationData?.city?.name,
            ownerBarangayName: ownerLocationData?.barangay?.name,
            mayorName,
          };

          const formData = mapToFormData(applicationData);

          // Generate PDF blob
          const blob = await pdf(<BusinessPermitFormDocument data={formData} />).toBlob();

          // Create download link and trigger download
          const url = URL.createObjectURL(blob);
          const link = document.createElement("a");
          link.href = url;
          link.download = `application-form-${submittedApplication.applicationNumber}.pdf`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(url);

          setHasPdfDownloaded(true);

          toast({
            title: "PDF Downloaded",
            description: "Your application form has been downloaded automatically.",
          });
        } catch (error) {
          console.error("Error generating PDF:", error);
          toast({
            title: "PDF Download Failed",
            description: "Failed to download the application form. You can download it manually using the 'View Application Form' button.",
            variant: "destructive",
          });
        }
      }
    };

    downloadPdf();
  }, [currentStep, submittedApplication, hasPdfDownloaded, formValues, businessLocationData, ownerLocationData, mayorName, toast]);

  const handleOwnerSelect = (owner: BusinessOwner) => {
    form.setValue("selectedOwnerId", owner.id);
    form.setValue("firstName", owner.firstName);
    form.setValue("middleName", owner.middleName || "");
    form.setValue("lastName", owner.lastName);
    form.setValue("birthDate", owner.birthDate);
    form.setValue("civilStatus", owner.civilStatus);
    form.setValue("gender", owner.gender);
    form.setValue("citizenship", owner.citizenship);
    form.setValue("tin", owner.tin);
    form.setValue("mobile", owner.mobile);
    form.setValue("address", owner.address);
    form.setValue("provinceId", owner.provinceId);
    form.setValue("cityId", owner.cityId);
    form.setValue("barangayId", owner.barangayId);
    form.setValue("email", owner.email);
    setProfilePhotoPreview(owner.avatar || null);
    setOwnerSelectionMode("new");
  };

  const handleProfilePhotoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      form.setValue("profilePhoto", file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfilePhotoPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTakePhoto = () => {
    if (camera.current) {
      try {
        const photo = camera.current.getScreenshot();
        if (photo) {
          setProfilePhotoPreview(photo);
          fetch(photo)
            .then((res) => res.blob())
            .then((blob) => {
              const file = new File([blob], "camera-photo.jpg", { type: "image/jpeg" });
              form.setValue("profilePhoto", file);
            });
          setCameraMode("upload");
        }
      } catch (error) {
        console.error("Error taking photo:", error);
        toast({
          title: "Camera Error",
          description: "Failed to capture photo. Please try again or use file upload.",
          variant: "destructive",
        });
      }
    }
  };

  const handleBackToOptions = () => {
    setOwnerSelectionMode("none");
    form.reset();
    setProfilePhotoPreview(null);
    setCameraMode("upload");
  };

  const handleBusinessSelect = (business: Business) => {
    form.setValue("selectedBusinessId", business.id);
    form.setValue("businessName", business.name);
    form.setValue("businessArea", business.businessArea || 1);
    form.setValue("propertyIndexNumber", business.propertyIndexNumber || "");
    form.setValue("dateEstablished", business.establishedDate);
    form.setValue("dateStarted", business.dateStarted);
    form.setValue("registrationDate", business.registrationDate || "");
    form.setValue("registrationNumber", business.registrationNumber || "");
    form.setValue("ownershipType", business.ownershipType.toLowerCase().replace(/\s+/g, "-"));
    form.setValue("groupName", business.groupName || "");
    form.setValue("occupancy", business.occupancy.toLowerCase());
    form.setValue("permitPaymentCadence", business.permitPaymentCadence);
    form.setValue("maleEmployeeCount", business.maleEmployeeCount);
    form.setValue("femaleEmployeeCount", business.femaleEmployeeCount);
    form.setValue("businessContactNumber", business.contactNumber);
    form.setValue("businessEmail", business.email);
    form.setValue("businessAddress", business.address);
    form.setValue("businessBuildingName", business.buildingName || "");
    form.setValue("businessProvinceId", business.provinceId);
    form.setValue("businessCityId", business.cityId);
    form.setValue("businessBarangayId", business.barangayId);

    // Carry over documents from the business (ownership-specific documents like DTI, SEC, etc.)
    if (business.documents && business.documents.length > 0) {
      const documentsMap: Record<string, { file: null; uploaded: boolean; storageId?: string; fileName?: string }> = {};

      for (const doc of business.documents) {
        // Map document types to form field keys
        const docTypeKey = doc.documentType
          .toLowerCase()
          .replace(/\s+/g, "")
          .replace(/certificate/i, "Certificate")
          .replace(/articles/i, "Articles");

        // Create mapping based on document type
        let formKey = "";
        if (doc.documentType.toLowerCase().includes("dti")) {
          formKey = "dtiCertificate";
        } else if (doc.documentType.toLowerCase().includes("sec")) {
          formKey = "secCertificate";
        } else if (doc.documentType.toLowerCase().includes("cda")) {
          formKey = "cdaCertificate";
        } else if (doc.documentType.toLowerCase().includes("articles of partnership")) {
          formKey = "articlesOfPartnership";
        } else if (doc.documentType.toLowerCase().includes("articles of incorporation")) {
          formKey = "articlesOfIncorporation";
        } else if (doc.documentType.toLowerCase().includes("articles of cooperation")) {
          formKey = "articlesOfCooperation";
        } else if (doc.documentType.toLowerCase().includes("by-laws") || doc.documentType.toLowerCase().includes("bylaws")) {
          formKey = "byLaws";
        } else if (doc.documentType.toLowerCase().includes("general information sheet") || doc.documentType.toLowerCase().includes("gis")) {
          formKey = "generalInformationSheet";
        }

        if (formKey) {
          documentsMap[formKey] = {
            file: null, // File object not available, but we have the storageId
            uploaded: true,
            storageId: doc.storageId,
            fileName: doc.fileName,
          };
        }
      }

      // Get current documents and merge with business documents
      const currentDocs = form.getValues("documents") || {};
      form.setValue("documents", { ...currentDocs, ...documentsMap });
    }

    setBusinessSelectionMode("new");
  };

  const handleBackToBusinessOptions = () => {
    setBusinessSelectionMode("none");
    form.setValue("selectedBusinessId", "");
    form.setValue("businessName", "");
    form.setValue("businessArea", 1);
    form.setValue("propertyIndexNumber", "");
    form.setValue("permitPaymentCadence", "");
    form.setValue("maleEmployeeCount", 0);
    form.setValue("femaleEmployeeCount", 0);
    form.setValue("businessContactNumber", "");
    form.setValue("dateEstablished", "");
    form.setValue("dateStarted", "");
    form.setValue("registrationDate", "");
    form.setValue("registrationNumber", "");
    form.setValue("occupancy", "");
    form.setValue("ownershipType", "");
    form.setValue("groupName", "");
    form.setValue("businessEmail", "");
    form.setValue("businessAddress", "");
    form.setValue("businessBuildingName", "");
    form.setValue("businessProvinceId", "");
    form.setValue("businessCityId", "");
    form.setValue("businessBarangayId", "");
    // Reset documents that were carried over from business
    form.setValue("documents", {});
  };

  const handleStepClick = (stepNumber: number) => {
    if (stepNumber <= currentStep) {
      setCurrentStep(stepNumber);
    }
  };

  const createApplication = useMutation(api.businessPermitApplications.create);
  const createBusinessOwner = useMutation(api.businessOwners.create);
  const createBusiness = useMutation(api.businesses.create);

  const handleSubmitApplication = form.handleSubmit(async (data) => {
    try {
      let businessOwnerId = data.selectedOwnerId;
      let businessId = data.selectedBusinessId;

      // Step 1: Create new business owner if needed
      if (data.ownerType === "new" && !businessOwnerId) {
        const newOwnerId = await createBusinessOwner({
          firstName: data.firstName!,
          middleName: data.middleName || undefined,
          lastName: data.lastName!,
          birthDate: data.birthDate!,
          civilStatus: data.civilStatus!,
          gender: data.gender!,
          citizenship: data.citizenship!,
          tin: data.tin || undefined,
          mobile: data.mobile!,
          email: data.email!,
          address: data.address || undefined,
          provinceId: data.provinceId! as Id<"provinces">,
          cityId: data.cityId! as Id<"cities">,
          barangayId: data.barangayId! as Id<"barangays">,
          ownerType: data.businessOwnerType,
          groupName: data.businessOwnerGroupName || undefined,
        });
        businessOwnerId = newOwnerId;
      }

      // Step 2: Create new business if needed
      if (!businessId && businessOwnerId) {
        const newBusinessId = await createBusiness({
          name: data.businessName!,
          ownerId: businessOwnerId as Id<"business_owners">,
          businessScale: "Micro",
          annualRevenue: "0",
          establishedDate: data.dateEstablished || new Date().toISOString().split("T")[0],
          dateStarted: data.dateStarted!,
          registrationDate: data.registrationDate || undefined,
          registrationNumber: data.registrationNumber || undefined,
          address: data.businessAddress!,
          buildingName: data.businessBuildingName || undefined,
          provinceId: data.businessProvinceId! as Id<"provinces">,
          cityId: data.businessCityId! as Id<"cities">,
          barangayId: data.businessBarangayId! as Id<"barangays">,
          ownershipType: data.ownershipType!,
          groupName: data.groupName || undefined,
          occupancy: data.occupancy || "Owned",
          permitPaymentCadence: data.permitPaymentCadence || "Annually",
          maleEmployeeCount: data.maleEmployeeCount || 1,
          femaleEmployeeCount: data.femaleEmployeeCount || 0,
          businessArea: data.businessArea || 1,
          propertyIndexNumber: data.propertyIndexNumber || undefined,
          contactNumber: data.businessContactNumber || data.mobile!,
          email: data.businessEmail || data.email!,
        });
        businessId = newBusinessId;
      }

      // Final validation
      if (!businessOwnerId || !businessId) {
        toast({
          title: "Error",
          description: "Failed to create business owner or business. Please check your inputs.",
          variant: "destructive",
        });
        return;
      }

      // Step 3: Create permit application with status "Assessment"
      // Note: Lines of Business (LOB) data is configured later during the Assessment phase
      // Empty array is intentional - LOB will be populated when application moves to "Pending Payment"
      const result = await createApplication({
        businessOwnerId: businessOwnerId as Id<"business_owners">,
        businessId: businessId as Id<"businesses">,
        permitApplicationType: data.permitApplicationType,
        linesOfBusiness: [], // Will be configured during Assessment workflow
        modeOfPayment: data.modeOfPayment,
      });

      setSubmittedApplication(result);
      setCurrentStep(3); // Move to success screen

      toast({
        title: "Success",
        description: "Application submitted successfully!",
      });
    } catch (error) {
      console.error("Error submitting application:", error);

      // Extract error message from Convex error
      const errorMessage = error instanceof Error ? error.message : "Failed to submit application. Please try again.";

      toast({
        title: "Submission Error",
        description: errorMessage,
        variant: "destructive",
      });
    }
  });

  const handleSaveToDrafts = () => {
    setShowDraftModal(true);
  };

  const handleConfirmSaveDraft = () => {
    if (draftName.trim()) {
      console.log("Saving draft:", {
        name: draftName,
        comments: draftComments,
        formData: form.getValues(),
      });
      alert(`Draft "${draftName}" saved successfully!`);
      setShowDraftModal(false);
      setDraftName("");
      setDraftComments("");
    }
  };

  return (
    <TooltipProvider>
      <div className="flex-1 space-y-6 p-4 pt-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">New Permit Application</h2>
            <p className="text-muted-foreground">Create a new business permit application</p>
          </div>
          <Button
            variant="outline"
            onClick={handleSaveToDrafts}
            disabled={!hasFormChanges}
            className="flex items-center gap-2 bg-transparent"
          >
            <Save className="h-4 w-4" />
            Save to Drafts
          </Button>
        </div>

        <Stepper steps={steps} currentStep={currentStep} className="mb-8" onStepClick={handleStepClick} />

        {currentStep === 1 && (
          <>
            {/* Permit Application Type Selection */}
            <PermitTransactionTypeCard
              value={formValues.permitApplicationType}
              onChange={(value) => form.setValue("permitApplicationType", value)}
              description="Select the type of permit application you are submitting"
            />

            {/* Business Owner Information */}
            <Card>
              <CardHeader>
                <CardTitle>Business Owner Information</CardTitle>
                <CardDescription>Select an existing business owner or create a new one</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {ownerSelectionMode === "none" && (
                  <BusinessOwnerSelection
                    onSelectExisting={() => {
                      setOwnerSelectionMode("existing");
                      form.setValue("ownerType", "existing");
                    }}
                    onSelectNew={() => {
                      setOwnerSelectionMode("new");
                      form.setValue("ownerType", "new");
                    }}
                  />
                )}

                {ownerSelectionMode === "existing" && (
                  <BusinessOwnerSearch
                    selectedOwnerId={formValues.selectedOwnerId}
                    onOwnerSelect={handleOwnerSelect}
                    onBack={() => setOwnerSelectionMode("none")}
                  />
                )}

                {ownerSelectionMode === "new" && (
                  <BusinessOwnerForm
                    form={form as any}
                    profilePhotoPreview={profilePhotoPreview}
                    cameraMode={cameraMode}
                    cameraRef={camera}
                    selectedOwnerId={formValues.selectedOwnerId}
                    onBack={handleBackToOptions}
                    onPhotoChange={handleProfilePhotoChange}
                    onCameraModeChange={setCameraMode}
                    onTakePhoto={handleTakePhoto}
                  />
                )}

                {ownerSelectionMode === "new" && (
                  <div className="flex justify-between pt-6 border-t">
                    <Link href="/dashboard/permit-applications">
                      <Button variant="outline">Cancel</Button>
                    </Link>
                    <Button
                      onClick={async () => {
                        // Validate Step 1 fields before proceeding
                        const ownerType = formValues.ownerType;

                        // Fields to validate based on owner type
                        let fieldsToValidate: (keyof PermitFormSchema)[] = ["ownerType"];

                        if (ownerType === "existing") {
                          // For existing owner, only validate that an owner is selected
                          fieldsToValidate.push("selectedOwnerId");
                        } else if (ownerType === "new") {
                          // For new owner, validate all required fields
                          // Note: TIN and address are now optional fields
                          fieldsToValidate = [
                            "ownerType",
                            "firstName",
                            "lastName",
                            "birthDate",
                            "civilStatus",
                            "gender",
                            "citizenship",
                            "mobile",
                            "email",
                            "provinceId",
                            "cityId",
                            "barangayId",
                          ];
                        }

                        const isValid = await form.trigger(fieldsToValidate);

                        if (!isValid) {
                          // Collect specific field errors
                          const errors = form.formState.errors;
                          const errorFields: string[] = [];

                          // Map error paths to readable field names
                          const fieldNameMap: Record<string, string> = {
                            selectedOwnerId: "Business Owner",
                            firstName: "First Name",
                            lastName: "Last Name",
                            birthDate: "Birth Date",
                            civilStatus: "Civil Status",
                            gender: "Gender",
                            citizenship: "Citizenship",
                            mobile: "Mobile Number",
                            email: "Email Address",
                            provinceId: "Province",
                            cityId: "City/Municipality",
                            barangayId: "Barangay",
                          };

                          // Build list of missing fields
                          fieldsToValidate.forEach((field) => {
                            if (errors[field]) {
                              const readableName = fieldNameMap[field] || field;
                              errorFields.push(readableName);
                            }
                          });

                          // Generate error message
                          let errorMessage = "";
                          if (errorFields.length === 0) {
                            errorMessage = "Please fill in all required fields before proceeding.";
                          } else if (errorFields.length <= 5) {
                            errorMessage = `Please fill in required fields: ${errorFields.join(", ")}`;
                          } else {
                            errorMessage = `Please complete all required fields. ${errorFields.length} fields are missing.`;
                          }

                          toast({
                            title: "Validation Error",
                            description: errorMessage,
                            variant: "destructive",
                          });
                        } else {
                          setCurrentStep(2);
                        }
                      }}
                    >
                      Next Step
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        )}

        {currentStep === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>Business Details</CardTitle>
              <CardDescription>Provide information about your business</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {isLoadingBusinesses ? (
                <div className="flex items-center justify-center py-12">
                  <div className="flex flex-col items-center gap-4">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                    <p className="text-sm text-muted-foreground">Loading businesses...</p>
                  </div>
                </div>
              ) : (
                <>
                  {businessSelectionMode === "none" && (
                    <BusinessSelection
                      onSelectNew={() => {
                        setBusinessSelectionMode("new");
                      }}
                      onSelectRenew={() => {
                        setBusinessSelectionMode("existing");
                      }}
                      selectedOwnerId={formValues.selectedOwnerId}
                      businesses={businesses}
                    />
                  )}

                  {businessSelectionMode === "existing" && (
                    <BusinessSearch
                      businesses={businesses}
                      selectedBusinessId={formValues.selectedBusinessId}
                      onBusinessSelect={handleBusinessSelect}
                      onBack={() => setBusinessSelectionMode("none")}
                      selectedOwnerId={formValues.selectedOwnerId}
                      outstandingBalances={outstandingBalances ?? null}
                    />
                  )}
                </>
              )}

              {businessSelectionMode === "new" && (
                <Form {...form}>
                  <BusinessForm
                    form={form}
                    selectedBusinessId={formValues.selectedBusinessId}
                    onBack={handleBackToBusinessOptions}
                    ownerType={formValues.businessOwnerType}
                  />
                </Form>
              )}

              {businessSelectionMode === "new" && (
                <div className="space-y-6 pt-6 border-t">
                  {/* Mode of Payment Section */}
                  <ModeOfPaymentCard
                    value={formValues.modeOfPayment as "Annually" | "Semi-Annually" | "Quarterly" | undefined}
                    onChange={(value) => form.setValue("modeOfPayment", value)}
                  />
                  {form.formState.errors.modeOfPayment && (
                    <p className="text-sm text-red-600 mt-1">{form.formState.errors.modeOfPayment.message}</p>
                  )}

                  <div>
                    <h3 className="text-lg font-semibold mb-2">
                      Document Attachments <span className="text-sm font-normal text-muted-foreground">(Optional)</span>
                    </h3>
                    <p className="text-muted-foreground mb-6">
                      Upload documents for your permit application. Documents can also be submitted later during the
                      assessment phase.
                    </p>
                  </div>

                  {/* Document 1: Permit Application Form */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <FileText className="h-5 w-5" />
                        Document 1: Permit Application Form
                      </CardTitle>
                      <CardDescription>Download, fill out, and upload the completed application form</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <Alert>
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>
                          Please download the official application form first, fill it out completely, then upload the
                          completed form below.
                        </AlertDescription>
                      </Alert>

                      <div className="flex items-center gap-4">
                        <Button
                          onClick={() => {
                            const link = document.createElement("a");
                            link.href = "/placeholder.pdf";
                            link.download = "Business-Permit-Application-Form.pdf";
                            link.click();
                          }}
                          variant="outline"
                          className="flex items-center gap-2 bg-transparent"
                        >
                          <Download className="h-4 w-4" />
                          Download Application Form
                        </Button>
                      </div>

                      <div className="space-y-2">
                        <Label>Upload Completed Application Form</Label>
                        <Dropzone
                          onFileSelect={(file) => {
                            const currentDocuments = formValues.documents || {};
                            form.setValue("documents", {
                              ...currentDocuments,
                              applicationForm: { file, uploaded: true },
                            });
                          }}
                          onFileRemove={() => {
                            const currentDocuments = formValues.documents || {};
                            form.setValue("documents", {
                              ...currentDocuments,
                              applicationForm: { file: null, uploaded: false },
                            });
                          }}
                          selectedFile={formValues.documents?.applicationForm?.file ?? null}
                        />
                      </div>
                    </CardContent>
                  </Card>

                  {/* Document 2: Barangay Clearance */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <FileText className="h-5 w-5" />
                        Document 2: Barangay Clearance
                      </CardTitle>
                      <CardDescription>Upload your valid Barangay Clearance certificate</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label>Upload Barangay Clearance</Label>
                        <Dropzone
                          onFileSelect={(file) => {
                            const currentDocuments = formValues.documents || {};
                            form.setValue("documents", {
                              ...currentDocuments,
                              barangayClearance: { file, uploaded: true },
                            });
                          }}
                          onFileRemove={() => {
                            const currentDocuments = formValues.documents || {};
                            form.setValue("documents", {
                              ...currentDocuments,
                              barangayClearance: { file: null, uploaded: false },
                            });
                          }}
                          selectedFile={formValues.documents?.barangayClearance?.file ?? null}
                        />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {businessSelectionMode === "new" && (
                <div className="flex justify-between pt-6 border-t">
                  <Button variant="outline" onClick={() => setCurrentStep(1)}>
                    Previous Step
                  </Button>
                  <Button
                    onClick={async () => {
                      // Trigger validation on all fields
                      const isValid = await form.trigger();

                      console.log("Values: ", form.getValues());

                      if (!isValid) {
                        // Collect all validation errors
                        const errors = form.formState.errors;
                        const errorMessages: string[] = [];

                        // Business owner errors
                        if (errors.firstName) errorMessages.push("First name is required");
                        if (errors.lastName) errorMessages.push("Last name is required");
                        if (errors.email) errorMessages.push("Valid email is required");

                        // Business errors
                        if (errors.businessName) errorMessages.push("Business name is required");
                        if (errors.ownershipType) errorMessages.push("Ownership type is required");
                        if (errors.businessAddress) errorMessages.push("Business address is required");
                        if (errors.businessProvinceId) errorMessages.push("Business province is required");
                        if (errors.businessCityId) errorMessages.push("Business city is required");
                        if (errors.businessBarangayId) errorMessages.push("Business barangay is required");

                        // Documents are now optional - no validation required

                        toast({
                          title: "Validation Error",
                          description:
                            errorMessages.length > 0
                              ? errorMessages.slice(0, 3).join(", ") + (errorMessages.length > 3 ? "..." : "")
                              : "Please fill in all required fields.",
                          variant: "destructive",
                        });

                        return;
                      }

                      // If valid, proceed with submission
                      handleSubmitApplication();
                    }}
                    disabled={form.formState.isSubmitting}
                    className="bg-green-600 hover:bg-green-700 disabled:opacity-50"
                  >
                    {form.formState.isSubmitting ? (
                      <>
                        <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                        Submitting...
                      </>
                    ) : (
                      <>
                        Submit Application
                        <Check className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {currentStep === 3 && (
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center justify-center text-center space-y-6 py-8">
                <div className="rounded-full bg-green-100 p-6">
                  <CheckCircle className="h-16 w-16 text-green-600" />
                </div>

                <div className="space-y-2">
                  <h2 className="text-2xl font-bold">Application Submitted Successfully!</h2>
                  <p className="text-muted-foreground">Your application has been submitted for assessment.</p>
                </div>

                {submittedApplication && (
                  <div className="bg-muted p-6 rounded-lg w-full max-w-md">
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">Application Number</p>
                      <p className="text-3xl font-mono font-bold text-primary">
                        {submittedApplication.applicationNumber}
                      </p>
                      <p className="text-xs text-muted-foreground">Please save this number for future reference</p>
                    </div>
                  </div>
                )}

                <div className="flex gap-4">
                  <Link href="/dashboard/permit-applications/assessment">
                    <Button variant="outline">
                      <FileText className="mr-2 h-4 w-4" />
                      View Assessment Queue
                    </Button>
                  </Link>
                  <Button variant="outline" onClick={() => setShowApplicationFormModal(true)}>
                    <FileText className="mr-2 h-4 w-4" />
                    View Application Form
                  </Button>
                  <Link href="/dashboard/permit-applications/new">
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Submit Another Application
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Dialog open={showDraftModal} onOpenChange={setShowDraftModal}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Save to Drafts</DialogTitle>
              <DialogDescription>
                Enter a name for this draft to save your progress and continue later.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="draftName">Draft Name</Label>
                <Input
                  id="draftName"
                  placeholder="e.g., Juan's Restaurant Application"
                  value={draftName}
                  onChange={(e) => setDraftName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="draftComments">Comments </Label>
                <Input
                  id="draftComments"
                  placeholder="e.g., Need to gather additional documents..."
                  value={draftComments}
                  onChange={(e) => setDraftComments(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowDraftModal(false)}>
                Cancel
              </Button>
              <Button onClick={handleConfirmSaveDraft} disabled={!draftName.trim()}>
                Save Draft
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Application Form PDF Modal */}
        {submittedApplication && (
          <ApplicationFormModal
            open={showApplicationFormModal}
            onOpenChange={setShowApplicationFormModal}
            applicationData={{
              applicationNumber: submittedApplication.applicationNumber,
              permitApplicationType: formValues.permitApplicationType as "New" | "Renewal" | "Additional" | undefined,
              modeOfPayment: formValues.modeOfPayment as "Annually" | "Semi-Annually" | "Quarterly" | undefined,
              submittedAt: new Date().toISOString(),
              businessOwner: formValues.firstName
                ? {
                    firstName: formValues.firstName,
                    middleName: formValues.middleName,
                    lastName: formValues.lastName || "",
                    birthDate: formValues.birthDate || "",
                    civilStatus: formValues.civilStatus || "",
                    gender: formValues.gender || "",
                    citizenship: formValues.citizenship || "",
                    tin: formValues.tin,
                    mobile: formValues.mobile || "",
                    email: formValues.email || "",
                    address: formValues.address,
                  }
                : null,
              business: formValues.businessName
                ? {
                    name: formValues.businessName,
                    establishedDate: formValues.dateEstablished || "",
                    ownershipType: formValues.ownershipType || "",
                    occupancy: formValues.occupancy || "",
                    permitPaymentCadence: formValues.permitPaymentCadence || "",
                    maleEmployeeCount: formValues.maleEmployeeCount || 0,
                    femaleEmployeeCount: formValues.femaleEmployeeCount || 0,
                    contactNumber: formValues.businessContactNumber || "",
                    email: formValues.businessEmail || "",
                    address: formValues.businessAddress,
                    buildingName: formValues.businessBuildingName,
                    businessArea: formValues.businessArea,
                    propertyIndexNumber: formValues.propertyIndexNumber,
                  }
                : null,
              linesOfBusiness: [], // LOB configured during Assessment
              provinceName: businessLocationData?.province?.name,
              cityName: businessLocationData?.city?.name,
              barangayName: businessLocationData?.barangay?.name,
              ownerProvinceName: ownerLocationData?.province?.name,
              ownerCityName: ownerLocationData?.city?.name,
              ownerBarangayName: ownerLocationData?.barangay?.name,
            }}
          />
        )}
      </div>
    </TooltipProvider>
  );
}
