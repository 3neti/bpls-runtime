import { preloadQuery } from "convex/nextjs"
import { convexAuthNextjsToken } from "@convex-dev/auth/nextjs/server"
import { ConvexError } from "convex/values"
import { api } from "@repo/backend/convex/_generated/api"
import { PermissionDenied, AuthenticationRequired } from "@/components/permission-error-states"
import { PermitsListClient } from "./permits-list-client"

// Page size constant - should match the client component
const PAGE_SIZE = 20

export default async function PermitsPage() {
  const token = await convexAuthNextjsToken()

  try {
    // Preload paginated permits with initial page
    const preloadedPermits = await preloadQuery(
      api.permits.getPermitsWithOwnersPaginated,
      { paginationOpts: { numItems: PAGE_SIZE, cursor: null } },
      { token }
    )

    // Preload count for pagination UI
    const preloadedCount = await preloadQuery(
      api.permits.getPermitsCount,
      {},
      { token }
    )

    return (
      <PermitsListClient
        preloadedPermits={preloadedPermits}
        preloadedCount={preloadedCount}
      />
    )
  } catch (error) {
    if (error instanceof ConvexError) {
      const errorData = error.data as {
        code?: string
        message?: string
        details?: {
          resource?: string
          action?: string
          userRole?: string
          requiredPermission?: string
        }
      }

      if (errorData.code === "PERMISSION_DENIED") {
        return (
          <PermissionDenied
            title="Permits"
            description="Manage business permits"
            message={errorData.message}
            details={errorData.details}
            resourceName="permit"
          />
        )
      }

      if (errorData.code === "UNAUTHENTICATED") {
        return <AuthenticationRequired />
      }
    }

    throw error
  }
}
