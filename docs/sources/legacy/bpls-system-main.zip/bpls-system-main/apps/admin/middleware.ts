import {
  convexAuthNextjsMiddleware,
  createRouteMatcher,
  nextjsMiddlewareRedirect,
} from "@convex-dev/auth/nextjs/server";

// Public routes that don't require authentication
const isPublicRoute = createRouteMatcher([
  "/",
  "/login",
  "/admin/onboarding",
  "/admin/onboarding/(.*)",
  "/permits/verify/(.*)",
]);

// Protected routes that require authentication
const isProtectedRoute = createRouteMatcher(["/dashboard", "/dashboard/(.*)"]);

export default convexAuthNextjsMiddleware(async (request, { convexAuth }) => {
  const isAuthenticated = await convexAuth.isAuthenticated();

  // Redirect unauthenticated users from protected routes to login
  if (isProtectedRoute(request) && !isAuthenticated) {
    return nextjsMiddlewareRedirect(request, "/login");
  }

  // Redirect authenticated users from login or home to dashboard
  if (
    (request.nextUrl.pathname === "/login" ||
      request.nextUrl.pathname === "/") &&
    isAuthenticated
  ) {
    return nextjsMiddlewareRedirect(request, "/dashboard");
  }
});

export const config = {
  // Match all routes except static files and Next.js internals
  matcher: ["/((?!.*\\..*|_next).*)", "/", "/(api|trpc)(.*)"],
};
