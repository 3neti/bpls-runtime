/**
 * Hook to get default location values for new resources
 *
 * Fetches default Province, City, and Barangay from platform settings.
 * Falls back to the first available province if no defaults are set.
 *
 * Usage:
 * ```tsx
 * const { defaultProvinceId, defaultCityId, defaultBarangayId, isLoading } = useDefaultLocations();
 *
 * // In form initialization:
 * const form = useForm({
 *   defaultValues: {
 *     provinceId: defaultProvinceId ?? "",
 *     cityId: defaultCityId ?? "",
 *     barangayId: defaultBarangayId ?? "",
 *   },
 * });
 * ```
 */

import { useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";

export interface DefaultLocationsResult {
  /** Default province ID from settings, or first available province */
  defaultProvinceId: string | null;
  /** Default city ID from settings (only if province is also set) */
  defaultCityId: string | null;
  /** Default barangay ID from settings (only if city is also set) */
  defaultBarangayId: string | null;
  /** Whether the queries are still loading */
  isLoading: boolean;
  /** Whether defaults came from settings (true) or fallback (false) */
  isFromSettings: boolean;
}

export function useDefaultLocations(): DefaultLocationsResult {
  // Query validated default locations from platform settings
  const defaultLocations = useQuery(api.platformSettings.getDefaultLocations);

  // Query first province as fallback
  const firstProvince = useQuery(api.locations.getFirstProvince);

  // Still loading
  if (defaultLocations === undefined || firstProvince === undefined) {
    return {
      defaultProvinceId: null,
      defaultCityId: null,
      defaultBarangayId: null,
      isLoading: true,
      isFromSettings: false,
    };
  }

  // Use settings if province is set, otherwise fallback to first province
  const hasSettingsProvince = defaultLocations.defaultProvinceId !== null;

  return {
    defaultProvinceId: hasSettingsProvince
      ? defaultLocations.defaultProvinceId
      : (firstProvince?._id ?? null),
    defaultCityId: hasSettingsProvince ? defaultLocations.defaultCityId : null,
    defaultBarangayId: hasSettingsProvince ? defaultLocations.defaultBarangayId : null,
    isLoading: false,
    isFromSettings: hasSettingsProvince,
  };
}
