"use client";

import { useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";

// Resources in the system (ordered to match sidebar navigation)
export const RESOURCES = [
  // 1. Permit Applications (with sub-resources)
  "permit_applications",
  "permit_applications:new",
  "permit_applications:all_applications",
  "permit_applications:assessment",
  "permit_applications:approval",
  "permit_applications:payment",
  "permit_applications:releasing",
  "permit_applications:schedule_of_payments",
  "permit_applications:fees_override",
  "permit_applications:status_update",

  // 2. Permits
  "permits",

  // 3. Business Owners
  "business_owners",

  // 4. Businesses
  "businesses",

  // 5. Billing Groups (with sub-resources)
  "billing_groups",
  "billing_groups:records",
  "billing_groups:records_update_after_payment",
  "billing_groups:line_items",
  "billing_groups:custom_fields",
  "billing_groups:receipt",

  // 6. Payments & Billing
  "payments_billing",

  // 7. Clearances
  "clearances",

  // 7. User Management
  "users",
  "roles",

  // 8. Taxes & Fees (with sub-resources)
  "taxes_and_fees",
  "taxes_and_fees:major",
  "taxes_and_fees:division",
  "taxes_and_fees:line_of_business",
  "taxes_and_fees:fees",
  "taxes_and_fees:surcharge_penalty",

  // 9. Locations
  "locations",

  // 10. Business Categories
  "business_categories",

  // 11. Settings (with sub-resources)
  "settings",
  "settings:platform_configuration",
  "settings:municipality",
  "settings:officials",
  "settings:branding",
  "settings:receipting",
  "settings:permit_layout",

  // 12. Reports
  "reports",

  // 13. Activity Logs (read-only)
  "activity_logs",
] as const;

// Actions that can be performed
export const ACTIONS = ["create", "read", "update", "delete"] as const;

export type Resource = (typeof RESOURCES)[number];
export type Action = (typeof ACTIONS)[number];

/**
 * Hook for checking user permissions in the UI
 */
export function usePermissions() {
  const permissions = useQuery(api.permissions.getUserPermissions);

  const isLoading = permissions === undefined;
  const permissionSet = new Set(permissions ?? []);

  /**
   * Check if user has a specific permission
   */
  const hasPermission = (resource: Resource, action: Action): boolean => {
    if (isLoading) return false;
    return permissionSet.has(`${resource}:${action}`);
  };

  /**
   * Check if user can create a resource
   */
  const canCreate = (resource: Resource): boolean => {
    return hasPermission(resource, "create");
  };

  /**
   * Check if user can read a resource
   */
  const canRead = (resource: Resource): boolean => {
    return hasPermission(resource, "read");
  };

  /**
   * Check if user can update a resource
   */
  const canUpdate = (resource: Resource): boolean => {
    return hasPermission(resource, "update");
  };

  /**
   * Check if user can delete a resource
   */
  const canDelete = (resource: Resource): boolean => {
    return hasPermission(resource, "delete");
  };

  /**
   * Check if user has any permission for a resource
   */
  const hasAnyPermission = (resource: Resource): boolean => {
    return ACTIONS.some((action) => hasPermission(resource, action));
  };

  /**
   * Check if user has all permissions for a resource (full CRUD)
   */
  const hasFullAccess = (resource: Resource): boolean => {
    return ACTIONS.every((action) => hasPermission(resource, action));
  };

  /**
   * Get all permissions as a formatted list
   */
  const getAllPermissions = (): string[] => {
    return Array.from(permissionSet);
  };

  return {
    isLoading,
    permissions: permissionSet,
    hasPermission,
    canCreate,
    canRead,
    canUpdate,
    canDelete,
    hasAnyPermission,
    hasFullAccess,
    getAllPermissions,
  };
}

/**
 * Hook for checking a single permission (optimized for single checks)
 */
export function useHasPermission(resource: Resource, action: Action) {
  const result = useQuery(api.permissions.hasPermission, { resource, action });
  return {
    hasPermission: result ?? false,
    isLoading: result === undefined,
  };
}
