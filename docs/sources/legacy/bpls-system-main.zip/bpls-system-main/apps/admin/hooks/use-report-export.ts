"use client"

import { useState, useCallback } from "react"
import { useQuery, useConvex } from "convex/react"
import { api } from "@repo/backend/convex/_generated/api"
import { Id } from "@repo/backend/convex/_generated/dataModel"

export interface ExportProgress {
  status: "pending" | "processing" | "generating_csv" | "completed" | "failed" | "cancelled"
  totalRecords?: number
  processedRecords?: number
  currentBatch?: number
  totalBatches?: number
  totalRows?: number
  errorMessage?: string
  downloadUrl?: string | null
}

export function useReportExport() {
  const convex = useConvex()
  const [exportId, setExportId] = useState<Id<"report_exports"> | null>(null)
  const [isStarting, setIsStarting] = useState(false)

  // Reactive progress tracking
  const exportStatus = useQuery(
    api.reportExports.getExportStatus,
    exportId ? { exportId } : "skip"
  )

  const downloadInfo = useQuery(
    api.reportExports.getExportDownloadUrl,
    exportId && exportStatus?.status === "completed" ? { exportId } : "skip"
  )

  const startExport = useCallback(async (resourceType: string, configuration: object) => {
    setIsStarting(true)
    try {
      const result = await convex.action(api.reportExportWorkflow.startExport, {
        resourceType,
        configuration: JSON.stringify(configuration),
      })
      setExportId(result.exportId as Id<"report_exports">)
      return result.exportId
    } finally {
      setIsStarting(false)
    }
  }, [convex])

  const cancelExport = useCallback(async () => {
    if (!exportId) return
    await convex.mutation(api.reportExports.cancelExport, { exportId })
  }, [convex, exportId])

  const reset = useCallback(() => {
    setExportId(null)
  }, [])

  const progress: ExportProgress = exportStatus
    ? {
        status: exportStatus.status,
        totalRecords: exportStatus.totalRecords ?? undefined,
        processedRecords: exportStatus.processedRecords ?? undefined,
        currentBatch: exportStatus.currentBatch ?? undefined,
        totalBatches: exportStatus.totalBatches ?? undefined,
        totalRows: exportStatus.totalRows ?? undefined,
        errorMessage: exportStatus.errorMessage ?? undefined,
        downloadUrl: downloadInfo?.url ?? undefined,
      }
    : { status: "pending" as const }

  return {
    exportId,
    isStarting,
    progress,
    startExport,
    cancelExport,
    reset,
    isExporting: !!exportId && !["completed", "failed", "cancelled"].includes(progress.status),
    isCompleted: progress.status === "completed",
    isFailed: progress.status === "failed",
  }
}
