"use client";

import { useState, useEffect, useCallback } from "react";
import { useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";

interface UseLocationSelectsOptions {
  /** Initial province ID (e.g., from existing data) */
  initialProvinceId?: string;
  /** Initial city ID (e.g., from existing data) */
  initialCityId?: string;
  /** Initial barangay ID (e.g., from existing data) */
  initialBarangayId?: string;
  /** Callback when province changes - useful for form setValue */
  onProvinceChange?: (provinceId: string) => void;
  /** Callback when city changes - useful for form setValue */
  onCityChange?: (cityId: string) => void;
  /** Callback when barangay changes - useful for form setValue */
  onBarangayChange?: (barangayId: string) => void;
}

/**
 * Reusable hook for cascading Province → City → Barangay location selects.
 * Handles loading states, dependent field clearing, and query management.
 *
 * @example
 * ```tsx
 * const {
 *   provinces,
 *   cities,
 *   barangays,
 *   selectedProvinceId,
 *   selectedCityId,
 *   handleProvinceChange,
 *   handleCityChange,
 *   handleBarangayChange,
 *   isCityDisabled,
 *   isBarangayDisabled,
 * } = useLocationSelects({
 *   initialProvinceId: business.provinceId,
 *   initialCityId: business.cityId,
 *   onProvinceChange: (id) => form.setValue("provinceId", id),
 *   onCityChange: (id) => form.setValue("cityId", id),
 *   onBarangayChange: (id) => form.setValue("barangayId", id),
 * });
 * ```
 */
export function useLocationSelects(options: UseLocationSelectsOptions = {}) {
  const {
    initialProvinceId = "",
    initialCityId = "",
    onProvinceChange,
    onCityChange,
    onBarangayChange,
  } = options;

  // Local state for selected IDs (drives dependent queries)
  const [selectedProvinceId, setSelectedProvinceId] = useState<string>(initialProvinceId);
  const [selectedCityId, setSelectedCityId] = useState<string>(initialCityId);

  // Convex queries with conditional fetching
  const provinces = useQuery(api.locations.listProvinces);

  const cities = useQuery(
    api.locations.listCitiesByProvince,
    selectedProvinceId ? { provinceId: selectedProvinceId as Id<"provinces"> } : "skip"
  );

  const barangays = useQuery(
    api.locations.listBarangaysByCity,
    selectedCityId ? { cityId: selectedCityId as Id<"cities"> } : "skip"
  );

  // Sync initial values when they change (e.g., when form data loads)
  useEffect(() => {
    if (initialProvinceId && initialProvinceId !== selectedProvinceId) {
      setSelectedProvinceId(initialProvinceId);
    }
  }, [initialProvinceId]);

  useEffect(() => {
    if (initialCityId && initialCityId !== selectedCityId) {
      setSelectedCityId(initialCityId);
    }
  }, [initialCityId]);

  /**
   * Handle province selection change.
   * Clears city and barangay selections when province changes.
   */
  const handleProvinceChange = useCallback(
    (provinceId: string) => {
      setSelectedProvinceId(provinceId);
      setSelectedCityId("");

      // Call external callbacks
      onProvinceChange?.(provinceId);
      onCityChange?.("");
      onBarangayChange?.("");
    },
    [onProvinceChange, onCityChange, onBarangayChange]
  );

  /**
   * Handle city selection change.
   * Clears barangay selection when city changes.
   */
  const handleCityChange = useCallback(
    (cityId: string) => {
      setSelectedCityId(cityId);

      // Call external callbacks
      onCityChange?.(cityId);
      onBarangayChange?.("");
    },
    [onCityChange, onBarangayChange]
  );

  /**
   * Handle barangay selection change.
   * Simply calls the external callback.
   */
  const handleBarangayChange = useCallback(
    (barangayId: string) => {
      onBarangayChange?.(barangayId);
    },
    [onBarangayChange]
  );

  /**
   * Reset all selections to empty.
   * Useful when clearing a form or resetting state.
   */
  const resetSelections = useCallback(() => {
    setSelectedProvinceId("");
    setSelectedCityId("");
    onProvinceChange?.("");
    onCityChange?.("");
    onBarangayChange?.("");
  }, [onProvinceChange, onCityChange, onBarangayChange]);

  /**
   * Set all selections at once.
   * Useful when populating form with existing data.
   */
  const setSelections = useCallback(
    (provinceId: string, cityId: string, barangayId?: string) => {
      setSelectedProvinceId(provinceId);
      setSelectedCityId(cityId);
      onProvinceChange?.(provinceId);
      onCityChange?.(cityId);
      if (barangayId) {
        onBarangayChange?.(barangayId);
      }
    },
    [onProvinceChange, onCityChange, onBarangayChange]
  );

  return {
    // Query data
    provinces,
    cities,
    barangays,

    // Current selections (for controlled selects)
    selectedProvinceId,
    selectedCityId,

    // State setters (for direct updates if needed)
    setSelectedProvinceId,
    setSelectedCityId,

    // Change handlers (call these in onValueChange)
    handleProvinceChange,
    handleCityChange,
    handleBarangayChange,

    // Utility functions
    resetSelections,
    setSelections,

    // Disabled states for selects
    isCityDisabled: !selectedProvinceId,
    isBarangayDisabled: !selectedCityId,

    // Loading states
    isProvincesLoading: provinces === undefined,
    isCitiesLoading: selectedProvinceId ? cities === undefined : false,
    isBarangaysLoading: selectedCityId ? barangays === undefined : false,
  };
}
