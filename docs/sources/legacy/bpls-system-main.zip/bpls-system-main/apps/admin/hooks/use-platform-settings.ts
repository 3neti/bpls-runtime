"use client";

import { useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";

// Default fallback values for when settings are loading or not found
export const DEFAULT_PLATFORM_SETTINGS = {
  platformName: "BPLS Portal",
  platformTitle: "Business Permit & Licensing System",
  tagline: "Streamlining business permit applications for local government",
  currencyFormat: "PHP",
  fiscalYearStart: "january",
};

// Default municipality settings - empty by default (configured during onboarding)
export const DEFAULT_MUNICIPALITY_SETTINGS = {
  municipalityName: "",
  municipalityShortName: "",
  provinceName: "",
  fullAddress: "",
};

// Default officials settings - names empty, titles have generic defaults
export const DEFAULT_OFFICIALS_SETTINGS = {
  mayorName: "",
  mayorTitle: "Municipal Mayor",
  treasurerName: "",
  treasurerTitle: "Municipal Treasurer",
};

// Default fallback images - null by default (components show placeholders)
export const DEFAULT_LOGO_URL: string | null = null;
export const DEFAULT_LANDING_IMAGE_URL: string | null = null;
export const DEFAULT_MUNICIPAL_SEAL_URL: string | null = null;

/**
 * Hook to access platform settings throughout the application
 * Provides settings data with loading states and fallback values
 */
export function usePlatformSettings() {
  const settings = useQuery(api.platformSettings.get);
  const logoUrl = useQuery(api.platformSettings.getLogoUrl);
  const landingImageUrl = useQuery(api.platformSettings.getLandingImageUrl);
  const municipalSealUrl = useQuery(api.platformSettings.getMunicipalSealUrl);

  // Determine loading state
  const isLoading = settings === undefined;

  // Provide effective values with fallbacks
  const effectiveLogoUrl = logoUrl ?? DEFAULT_LOGO_URL;
  const effectiveLandingImageUrl = landingImageUrl ?? DEFAULT_LANDING_IMAGE_URL;
  const effectiveMunicipalSealUrl = municipalSealUrl ?? DEFAULT_MUNICIPAL_SEAL_URL;

  return {
    // Raw data (may be undefined while loading)
    settings,
    logoUrl,
    landingImageUrl,
    municipalSealUrl,

    // Loading state
    isLoading,

    // Effective values with fallbacks (always defined)
    effectiveLogoUrl,
    effectiveLandingImageUrl,
    effectiveMunicipalSealUrl,

    // Platform settings
    platformName: settings?.platformName ?? DEFAULT_PLATFORM_SETTINGS.platformName,
    platformTitle: settings?.platformTitle ?? DEFAULT_PLATFORM_SETTINGS.platformTitle,
    tagline: settings?.tagline ?? DEFAULT_PLATFORM_SETTINGS.tagline,
    currencyFormat: settings?.currencyFormat ?? DEFAULT_PLATFORM_SETTINGS.currencyFormat,
    fiscalYearStart: settings?.fiscalYearStart ?? DEFAULT_PLATFORM_SETTINGS.fiscalYearStart,

    // Municipality settings
    municipalityName: settings?.municipalityName ?? DEFAULT_MUNICIPALITY_SETTINGS.municipalityName,
    municipalityShortName: settings?.municipalityShortName ?? DEFAULT_MUNICIPALITY_SETTINGS.municipalityShortName,
    provinceName: settings?.provinceName ?? DEFAULT_MUNICIPALITY_SETTINGS.provinceName,
    fullAddress: settings?.fullAddress ?? DEFAULT_MUNICIPALITY_SETTINGS.fullAddress,

    // Officials settings
    mayorName: settings?.mayorName ?? DEFAULT_OFFICIALS_SETTINGS.mayorName,
    mayorTitle: settings?.mayorTitle ?? DEFAULT_OFFICIALS_SETTINGS.mayorTitle,
    treasurerName: settings?.treasurerName ?? DEFAULT_OFFICIALS_SETTINGS.treasurerName,
    treasurerTitle: settings?.treasurerTitle ?? DEFAULT_OFFICIALS_SETTINGS.treasurerTitle,
  };
}

/**
 * Type for the return value of usePlatformSettings
 */
export type PlatformSettings = ReturnType<typeof usePlatformSettings>;
