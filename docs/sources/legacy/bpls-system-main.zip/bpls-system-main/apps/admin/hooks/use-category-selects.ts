"use client";

import { useState, useEffect, useCallback } from "react";
import { useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";

interface UseCategorySelectsOptions {
  /** Initial category ID (e.g., from existing data) */
  initialCategoryId?: string;
  /** Initial subcategory ID (e.g., from existing data) */
  initialSubCategoryId?: string;
  /** Callback when category changes - useful for form setValue */
  onCategoryChange?: (categoryId: string) => void;
  /** Callback when subcategory changes - useful for form setValue */
  onSubCategoryChange?: (subCategoryId: string) => void;
}

/**
 * Reusable hook for cascading Category → Sub-Category selects.
 * Handles loading states, dependent field clearing, and query management.
 *
 * @example
 * ```tsx
 * const {
 *   categories,
 *   subCategories,
 *   selectedCategoryId,
 *   handleCategoryChange,
 *   handleSubCategoryChange,
 *   isSubCategoryDisabled,
 * } = useCategorySelects({
 *   initialCategoryId: business.categoryId,
 *   initialSubCategoryId: business.subCategoryId,
 *   onCategoryChange: (id) => form.setValue("categoryId", id),
 *   onSubCategoryChange: (id) => form.setValue("subCategoryId", id),
 * });
 * ```
 */
export function useCategorySelects(options: UseCategorySelectsOptions = {}) {
  const {
    initialCategoryId = "",
    initialSubCategoryId = "",
    onCategoryChange,
    onSubCategoryChange,
  } = options;

  // Local state for selected IDs (drives dependent queries)
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>(initialCategoryId);

  // Convex queries with conditional fetching
  const categories = useQuery(api.businessCategories.listCategories);

  const subCategories = useQuery(
    api.businessCategories.listSubCategoriesByCategory,
    selectedCategoryId ? { categoryId: selectedCategoryId as Id<"business_categories"> } : "skip"
  );

  // Sync initial values when they change (e.g., when form data loads)
  useEffect(() => {
    if (initialCategoryId && initialCategoryId !== selectedCategoryId) {
      setSelectedCategoryId(initialCategoryId);
    }
  }, [initialCategoryId]);

  /**
   * Handle category selection change.
   * Clears subcategory selection when category changes.
   */
  const handleCategoryChange = useCallback(
    (categoryId: string) => {
      setSelectedCategoryId(categoryId);

      // Call external callbacks
      onCategoryChange?.(categoryId);
      onSubCategoryChange?.("");
    },
    [onCategoryChange, onSubCategoryChange]
  );

  /**
   * Handle subcategory selection change.
   * Simply calls the external callback.
   */
  const handleSubCategoryChange = useCallback(
    (subCategoryId: string) => {
      onSubCategoryChange?.(subCategoryId);
    },
    [onSubCategoryChange]
  );

  /**
   * Reset all selections to empty.
   * Useful when clearing a form or resetting state.
   */
  const resetSelections = useCallback(() => {
    setSelectedCategoryId("");
    onCategoryChange?.("");
    onSubCategoryChange?.("");
  }, [onCategoryChange, onSubCategoryChange]);

  return {
    // Query data
    categories,
    subCategories,

    // Current selection (for controlled selects)
    selectedCategoryId,

    // State setter (for direct updates if needed)
    setSelectedCategoryId,

    // Change handlers (call these in onValueChange)
    handleCategoryChange,
    handleSubCategoryChange,

    // Utility function
    resetSelections,

    // Disabled state for subcategory select
    isSubCategoryDisabled: !selectedCategoryId,

    // Loading states
    isCategoriesLoading: categories === undefined,
    isSubCategoriesLoading: selectedCategoryId ? subCategories === undefined : false,
  };
}
