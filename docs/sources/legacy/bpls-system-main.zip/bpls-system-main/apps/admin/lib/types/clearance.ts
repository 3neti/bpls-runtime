/**
 * Clearance Type Definitions (LEGACY COMPATIBILITY)
 *
 * ⚠️ CONSOLIDATION NOTICE: The clearances table has been merged into departments.
 * These types are maintained for backward compatibility with existing UI components.
 *
 * **NEW CODE**: Use Department types from lib/types/department.ts
 * **SOURCE OF TRUTH**: convex/schema.ts - departments table (consolidation: 2025-01-20)
 *
 * Migration Timeline:
 * - 2025-01-20: Clearances consolidated into departments (1:1 relationship)
 * - 2025-Q2: Planned removal of legacy compatibility layer
 * - New features: Use department-based types only
 *
 * Architecture (LEGACY):
 * - Clearances were separate entities linked to departments via departmentId
 * - NOW: Department IS the clearance (certificateName, description, isActive in departments)
 * - Legacy queries in convex/clearances.ts map departments → clearance format
 *
 * Architecture (NEW):
 * - Use Department type from lib/types/department.ts
 * - Access certificate data directly: department.certificateName, department.description
 * - Fees are managed separately via department-fees system
 *
 * Migration Path for Input Types:
 * ```typescript
 * // DEPRECATED: ClearanceFormInput, ClearanceWithDepartmentInput
 * // USE INSTEAD: DepartmentFormInput from lib/types/department.ts
 *
 * // Before (DEPRECATED):
 * const input: ClearanceWithDepartmentInput = {
 *   clearanceName: "...",
 *   certificateName: "...",
 *   departmentFullName: "...",
 *   // ...
 * }
 *
 * // After (RECOMMENDED):
 * import type { DepartmentFormInput } from '@/lib/types/department'
 * const input: DepartmentFormInput = {
 *   name: "...",
 *   certificateName: "...",
 *   shortName: "...",
 *   slug: "...",
 *   // ...
 * }
 * ```
 */

import type { Id } from "@repo/backend/convex/_generated/dataModel"
import type { LucideIcon } from "lucide-react"
import type { Department, DepartmentSummary } from "./department"

/**
 * @deprecated Clearances table no longer exists. Use Department type instead.
 * Legacy type maintained for backward compatibility during migration.
 *
 * A department IS a clearance. Use Department type from lib/types/department.ts.
 */
export type ConvexClearance = Department

/**
 * @deprecated Use Department type directly.
 * Clearance with full department details (for detail views).
 *
 * Since departments now contain all clearance information, this is just an alias.
 */
export interface ClearanceWithDepartment {
  department: Department | null
}

/**
 * @deprecated Use DepartmentSummary type directly.
 * Clearance with department summary (for listing views).
 *
 * Since departments now contain all clearance information, this is just an alias.
 */
export interface ClearanceWithDepartmentSummary {
  department: DepartmentSummary | null
}

/**
 * @deprecated Use DepartmentFormInput from lib/types/department.ts instead.
 * Clearance creation input (for creating clearances with existing department)
 *
 * Since clearances are now part of departments, use DepartmentFormInput.
 */
export interface ClearanceFormInput {
  name: string
  certificateName: string
  description: string
  departmentId: Id<"departments">
  isActive: boolean
}

/**
 * @deprecated Use DepartmentFormInput from lib/types/department.ts instead.
 * Combined clearance and department creation input.
 *
 * Since clearances are consolidated into departments, use DepartmentFormInput.
 * This type is maintained for backward compatibility with AddDepartmentDialog.
 */
export interface ClearanceWithDepartmentInput {
  // Clearance fields
  clearanceName: string
  certificateName: string
  description: string
  // Department fields
  departmentFullName: string
  departmentShortName: string
  departmentSlug: string
  icon: Department["icon"]
  officerName: string
  officerEmail: string
}

/**
 * @deprecated Use DepartmentUpdateInput from lib/types/department.ts instead.
 * Clearance update input.
 *
 * Since clearances are now part of departments, use DepartmentUpdateInput.
 */
export interface ClearanceUpdateInput {
  name?: string
  certificateName?: string
  description?: string
  isActive?: boolean
}

/**
 * @deprecated Use DepartmentUpdateInput from lib/types/department.ts instead.
 * Combined clearance and department update input.
 *
 * Since clearances are consolidated into departments, use DepartmentUpdateInput.
 */
export interface ClearanceWithDepartmentUpdateInput {
  // Clearance fields
  clearanceName?: string
  certificateName?: string
  description?: string
  isActive?: boolean
  // Department fields
  departmentFullName?: string
  departmentShortName?: string
  icon?: Department["icon"]
  officerName?: string
  officerEmail?: string
}

/**
 * @deprecated Use DepartmentUpdateResult from lib/types/department.ts instead.
 * Clearance creation result.
 *
 * Since clearances are now departments, this returns department IDs.
 */
export interface ClearanceCreationResult {
  departmentId: Id<"departments">
  /** @deprecated Same as departmentId (1:1 relationship) */
  clearanceId: Id<"departments">
  message: string
}

/**
 * @deprecated Use DepartmentUpdateResult from lib/types/department.ts instead.
 * Clearance update result.
 */
export interface ClearanceUpdateResult {
  id: Id<"departments">
  message: string
}

/**
 * @deprecated Use DepartmentUpdateResult from lib/types/department.ts instead.
 * Combined update result.
 */
export interface ClearanceWithDepartmentUpdateResult {
  success: boolean
  /** @deprecated Same as departmentId (1:1 relationship) */
  clearanceId: Id<"departments">
  departmentId: Id<"departments">
  message: string
}

/**
 * Clearance status values
 * - approved: Clearance has been reviewed and approved
 * - pending: Clearance is under review
 * - not_started: Clearance review hasn't begun yet
 */
export type ClearanceStatus = 'approved' | 'pending' | 'not_started'

/**
 * Clearance Type
 * Defines the type of clearance/certificate (e.g., "sanitary", "fire_safety")
 */
export type ClearanceType =
  | 'sanitary'
  | 'fire_safety'
  | 'mpdc'
  | 'environmental'
  | 'engineering'

/**
 * Department Information (Metadata)
 * Department details are properties of clearances, not primary entities
 */
export interface ClearanceDepartmentInfo {
  /** Department ID */
  id: string
  /** Full department name */
  name: string
  /** Abbreviated department name */
  shortName: string
  /** URL-safe slug for routing (e.g., "sanitary", "bfp") */
  slug: string
  /** Department icon for UI display */
  icon: LucideIcon
  /** Department user/officer information */
  officer: {
    name: string
    email: string
    avatar?: string
  }
}

/**
 * Clearance Configuration
 * Defines a clearance type with its department, requirements, and metadata
 */
export interface ClearanceConfig {
  /** Unique identifier for the clearance type */
  id: string
  /** Clearance type identifier */
  type: ClearanceType
  /** Display name of the clearance */
  name: string
  /** Full name including "Certificate" suffix */
  certificateName: string
  /** Description of what this clearance approves */
  description: string
  /** Department responsible for this clearance */
  department: ClearanceDepartmentInfo
  /** URL route for the clearance portal */
  route: string
  /** Whether this clearance requires a fee */
  requiresFee: boolean
  /** Default fee amount (if applicable) */
  defaultFee?: number
  /** Required documents or criteria */
  requirements?: string[]
}

/**
 * Clearance Instance
 * Represents a specific clearance for a permit application
 * This is the primary entity in the system
 */
export interface Clearance {
  /** Unique identifier for the clearance instance */
  id: string
  /** Permit ID this clearance belongs to */
  permitId: string
  /** Type of clearance */
  type: ClearanceType
  /** Reference to clearance configuration */
  clearanceId: string
  /** Display name of the clearance */
  name: string
  /** Full certificate name */
  certificateName: string
  /** Current status of the clearance */
  status: ClearanceStatus
  /** Department information (embedded for convenience) */
  department: {
    id: string
    name: string
    shortName: string
  }
  /** Fee amount charged for this clearance (in pesos) - DEPRECATED: use fees array */
  fee?: number
  /** Multiple fees applied to this clearance */
  fees?: Array<{
    feeId: string
    feeName: string
    defaultAmount: number
    appliedAmount: number
    overrideReason?: string
  }>
  /** Total amount from all fees */
  totalAmount?: number
  /** Remarks or notes about the clearance */
  remarks?: string
  /** Date the clearance was approved (ISO string) */
  approvedAt?: string
  /** ID of the user who approved the clearance */
  approvedBy?: string
  /** Name of the user who approved the clearance */
  approvedByName?: string
}

/**
 * @deprecated Use `Clearance` instead. This type is for backward compatibility only.
 */
export type DepartmentClearance = Clearance

/**
 * Clearance Approval Form Values (Single Fee - Legacy)
 * @deprecated Use ClearanceMultiFeeApprovalFormValues instead
 * Data structure for approving a clearance with single fee and remarks
 */
export interface ClearanceApprovalFormValues {
  /** Fee amount to charge for this clearance */
  fee: number
  /** Optional remarks about the approval */
  remarks: string
}

/**
 * Clearance Multi-Fee Approval Form Values
 * Data structure for approving a clearance with multiple fees and remarks
 */
export interface ClearanceMultiFeeApprovalFormValues {
  /** Multiple fees applied to this clearance */
  fees: Array<{
    feeId: string
    feeName: string
    defaultAmount: number
    appliedAmount: number
    overrideReason?: string
  }>
  /** Total amount from all fees */
  totalAmount: number
  /** Optional remarks about the approval */
  remarks: string
}

/**
 * Clearance Statistics
 * Summary counts of clearances by status
 */
export interface ClearanceStatistics {
  /** Total number of clearances */
  total: number
  /** Number of approved clearances */
  approved: number
  /** Number of pending clearances */
  pending: number
  /** Number of not started clearances */
  notStarted: number
  /** Percentage of completion (approved / total) */
  completionPercentage: number
}

/**
 * Clearance Review Data
 * Data structure for clearance review pages
 */
export interface ClearanceReviewData {
  /** Clearance configuration */
  config: ClearanceConfig
  /** List of permit applications requiring this clearance */
  permits: Array<{
    id: string
    ownerName: string
    businessName: string
    applicationDate: string
    status: "Applied" | "Approved" | "Rejected"
  }>
  /** Statistics for this clearance type */
  stats: {
    totalPending: number
    awaitingReview: number
    approvedToday: number
  }
}
