/**
 * Zod validation schema for Business Owner Update Form
 *
 * This schema validates the business owner update form with all required fields.
 */

import { z } from "zod";

/**
 * Business Owner Update Schema
 * All fields are editable except ID
 */
export const businessOwnerUpdateSchema = z.object({
  id: z.string().min(1, "ID is required"),
  firstName: z.string().min(1, "First name is required"),
  middleName: z.string().optional(),
  lastName: z.string().min(1, "Last name is required"),
  birthDate: z.string().min(1, "Birth date is required"),
  civilStatus: z.string().min(1, "Civil status is required"),
  gender: z.string().min(1, "Gender is required"),
  citizenship: z.string().min(1, "Citizenship is required"),
  tin: z.string().optional(), // Now optional
  mobile: z.string().min(1, "Mobile number is required"),
  email: z.string().email("Invalid email address").min(1, "Email is required"),
  // NEW: Hierarchical address fields
  address: z.string().optional(), // Now optional
  provinceId: z.string().min(1, "Province is required"),
  cityId: z.string().min(1, "City/Municipality is required"),
  barangayId: z.string().min(1, "Barangay is required"),
  avatar: z.string().optional(),
  profilePhoto: z.any().nullable().optional(),
});

/**
 * Type inference from schema
 */
export type BusinessOwnerUpdateSchema = z.infer<typeof businessOwnerUpdateSchema>;

/**
 * Default values factory function
 * Creates default values from BusinessOwner data
 */
export const createBusinessOwnerUpdateDefaultValues = (owner: {
  id: string;
  firstName: string;
  middleName?: string;
  lastName: string;
  birthDate: string;
  civilStatus: string;
  gender: string;
  citizenship: string;
  tin?: string; // Now optional
  mobile: string;
  email: string;
  address?: string; // Now optional
  provinceId: string;
  cityId: string;
  barangayId: string;
  avatar?: string;
}): BusinessOwnerUpdateSchema => ({
  id: owner.id,
  firstName: owner.firstName,
  middleName: owner.middleName || "",
  lastName: owner.lastName,
  birthDate: owner.birthDate,
  civilStatus: owner.civilStatus,
  gender: owner.gender,
  citizenship: owner.citizenship,
  tin: owner.tin || "",
  mobile: owner.mobile,
  email: owner.email,
  address: owner.address || "",
  provinceId: owner.provinceId,
  cityId: owner.cityId,
  barangayId: owner.barangayId,
  avatar: owner.avatar || "",
  profilePhoto: null,
});
