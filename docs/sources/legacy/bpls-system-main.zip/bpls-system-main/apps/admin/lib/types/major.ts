/**
 * Major types for the taxes & fees hierarchy system
 *
 * These types are derived from the Convex schema as the single source of truth.
 * The database schema is defined in convex/schema.ts
 *
 * Hierarchy: Major → Division → Fees → Groups (inherit fees)
 * Example majors: "Dealer", "Retailer", "Manufacturer"
 */

import type { Doc, Id } from "@repo/backend/convex/_generated/dataModel"

// Core major type derived from Convex schema
export type Major = Doc<"majors">

// Extract specific field types
export type MajorId = Id<"majors">

/**
 * Major form values for creation/editing
 */
export interface MajorFormValues {
  name: string
  description: string
}

/**
 * Major with statistics
 * Used for list/detail views with counts
 */
export interface MajorWithStats extends Major {
  divisionCount: number
  groupCount: number // Indirect count through divisions
}

/**
 * Major summary for dropdowns/selects
 */
export interface MajorSummary {
  _id: MajorId
  name: string
  description: string
}
