/**
 * Permit TipTap Converter
 *
 * Seamlessly detects whether a template string is TipTap JSON or plain text,
 * and always returns TipTap JSON. No schema-level discriminator needed.
 *
 * Plain text templates are auto-migrated to TipTap JSON on load:
 * - Each line becomes a paragraph node
 * - Macros {{macroName}} remain as plain text in text nodes
 * - Empty lines become empty paragraphs
 */

// TipTap JSON types
export interface TipTapMark {
  type: string;
  attrs?: Record<string, unknown>;
}

export interface TipTapNode {
  type: string;
  attrs?: Record<string, unknown>;
  marks?: TipTapMark[];
  text?: string;
  content?: TipTapNode[];
}

export interface TipTapDoc {
  type: "doc";
  content: TipTapNode[];
}

/**
 * Create an empty TipTap document
 */
export function emptyDoc(): TipTapDoc {
  return {
    type: "doc",
    content: [{ type: "paragraph" }],
  };
}

/**
 * Convert plain text to TipTap JSON document.
 * Each line becomes a paragraph node. Macros remain as plain text.
 */
export function plainTextToTipTapJSON(plainText: string): TipTapDoc {
  if (!plainText) return emptyDoc();

  const lines = plainText.split("\n");
  const content: TipTapNode[] = lines.map((line) => {
    if (!line) {
      // Empty line -> empty paragraph
      return { type: "paragraph" };
    }
    return {
      type: "paragraph",
      content: [{ type: "text", text: line }],
    };
  });

  return { type: "doc", content };
}

/**
 * Detect whether a template string is TipTap JSON or plain text,
 * and always return a TipTap JSON document.
 *
 * Detection logic:
 * 1. Try JSON.parse
 * 2. Check if parsed has type: "doc" and content array
 * 3. If not valid TipTap JSON, treat as plain text and convert
 */
export function parseTipTapContent(template: string): TipTapDoc {
  if (!template) return emptyDoc();

  try {
    const parsed = JSON.parse(template);
    if (
      parsed &&
      typeof parsed === "object" &&
      parsed.type === "doc" &&
      Array.isArray(parsed.content)
    ) {
      return parsed as TipTapDoc;
    }
  } catch {
    // Not JSON — fall through to plain text conversion
  }

  // Not valid TipTap JSON — treat as plain text and migrate
  return plainTextToTipTapJSON(template);
}

/**
 * Extract plain text from a TipTap JSON document.
 * Used for validation (macro checking) on the raw text content.
 */
export function tipTapToPlainText(doc: TipTapDoc): string {
  if (!doc || !doc.content) return "";

  return doc.content
    .map((node) => {
      if (node.type === "paragraph") {
        if (!node.content) return "";
        return node.content
          .map((child) => child.text || "")
          .join("");
      }
      return "";
    })
    .join("\n");
}
