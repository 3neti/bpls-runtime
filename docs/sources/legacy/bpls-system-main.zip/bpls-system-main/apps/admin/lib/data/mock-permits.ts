/**
 * Mock permit data shared across all department review pages
 * In production, this would be fetched from Convex queries
 */

import type { DepartmentPermit } from "@/lib/types/department"

export const MOCK_PERMITS: DepartmentPermit[] = [
  {
    id: "1",
    applicationNumber: "2025-001",
    ownerName: "Juan Dela Cruz",
    businessName: "Dela Cruz Sari-Sari Store",
    submittedAt: "2025-09-28",
    status: "Applied",
    certificateName: "Sanitary Permit",
  },
  {
    id: "2",
    applicationNumber: "2025-002",
    ownerName: "Maria Santos",
    businessName: "Santos Bakery & Cafe",
    submittedAt: "2025-09-29",
    status: "Applied",
    certificateName: "Sanitary Permit",
  },
  {
    id: "3",
    applicationNumber: "2025-003",
    ownerName: "Pedro Reyes",
    businessName: "Reyes Restaurant",
    submittedAt: "2025-09-30",
    status: "Applied",
    certificateName: "Sanitary Permit",
  },
  {
    id: "4",
    applicationNumber: "2025-004",
    ownerName: "Ana Garcia",
    businessName: "Garcia Food Cart",
    submittedAt: "2025-10-01",
    status: "Applied",
    certificateName: "Fire Safety Clearance",
  },
  {
    id: "5",
    applicationNumber: "2025-005",
    ownerName: "Roberto Mendoza",
    businessName: "Mendoza Meat Shop",
    submittedAt: "2025-10-02",
    status: "Applied",
    certificateName: "Sanitary Permit",
  },
  {
    id: "6",
    applicationNumber: "2025-006",
    ownerName: "Carmen Villanueva",
    businessName: "Villanueva Catering Services",
    submittedAt: "2025-10-03",
    status: "Approved",
    certificateName: "Sanitary Permit",
  },
  {
    id: "7",
    applicationNumber: "2025-007",
    ownerName: "Luis Torres",
    businessName: "Torres Grocery Store",
    submittedAt: "2025-10-04",
    status: "Approved",
    certificateName: "Fire Safety Clearance",
  },
  {
    id: "8",
    applicationNumber: "2025-008",
    ownerName: "Elena Ramos",
    businessName: "Ramos Seafood Market",
    submittedAt: "2025-10-05",
    status: "Approved",
    certificateName: "Sanitary Permit",
  },
  {
    id: "9",
    applicationNumber: "2025-009",
    ownerName: "Miguel Cruz",
    businessName: "Cruz Hardware Store",
    submittedAt: "2025-10-06",
    status: "Rejected",
    certificateName: "MPDC Clearance",
  },
  {
    id: "10",
    applicationNumber: "2025-010",
    ownerName: "Sofia Fernandez",
    businessName: "Fernandez Salon",
    submittedAt: "2025-10-07",
    status: "Rejected",
    certificateName: "Fire Safety Clearance",
  },
]
