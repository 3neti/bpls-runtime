/**
 * Permit-related type definitions
 *
 * SOURCE OF TRUTH: convex/schema.ts
 * This file derives types from the Convex database schema.
 * To modify permit types, update convex/schema.ts first.
 */

import type { Doc } from "@repo/backend/convex/_generated/dataModel"
import type { LineOfBusiness } from './business'
import type { OwnerType } from './business-owners'

/**
 * Permit type derived from Convex schema
 * This is the database representation of a permit
 */
export type Permit = Doc<"permits">

/**
 * Permit status type derived from Convex schema
 */
export type PermitStatus = Permit["status"]

/**
 * Form values for creating/editing a permit application
 * This is separate from the database model as it includes form-specific data
 */
export interface PermitFormValues {
  ownerType: OwnerType
  selectedOwnerId: string
  profilePhoto: File | null
  firstName: string
  middleName: string
  lastName: string
  birthDate: string
  civilStatus: string
  gender: string
  citizenship: string
  tin: string
  mobile: string
  houseNo: string
  street: string
  city: string
  district: string
  barangay: string
  zone: string
  email: string
  selectedBusinessId: string
  businessName: string
  linesOfBusiness: LineOfBusiness[]
  permitPaymentCadence: string
  numberOfEmployees: string
  businessContactNumber: string
  dateEstablished: string
  occupancy: string
  ownershipType: string
  businessEmail: string
  businessHouseNo: string
  businessStreet: string
  businessCity: string
  businessDistrict: string
  businessBarangay: string
  businessZone: string
  documents: Record<string, { file: File | null; uploaded: boolean }>
}

/**
 * Extended permit type with additional application metadata
 */
export interface PermitApplication extends Permit {
  reviewerNotes?: string
  reviewedBy?: string
  attachments?: string[]
}

/**
 * Legacy type - kept for backwards compatibility
 * Consider migrating to use PermitStatus directly
 */
export type PermitApplicationType = 'New' | 'Renewal'
