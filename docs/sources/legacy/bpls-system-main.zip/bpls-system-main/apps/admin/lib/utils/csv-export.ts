/**
 * CSV Export Utility Functions
 *
 * Provides utilities for converting data to CSV format and triggering downloads.
 * All currency values are exported as plain numbers for spreadsheet compatibility.
 * Dates are formatted as YYYY-MM-DD for consistent sorting.
 */

import { format as dateFnsFormat } from "date-fns"
import {
  formatDate as formatDateFromFormatting,
  formatCurrencyForCSV as formatCurrencyFromFormatting,
} from "@/lib/utils/formatting"

// Re-export for backward compatibility
export const formatDateForCSV = (
  value: string | Date | number | null | undefined
): string => formatDateFromFormatting(value, "csv")

export const formatCurrencyForCSV = formatCurrencyFromFormatting

/**
 * Column definition for CSV export
 */
export interface CSVColumn<T> {
  /** Header text displayed in CSV */
  header: string
  /** Function to extract value from data row */
  accessor: (row: T) => string | number | null | undefined
}

/**
 * Escapes a value for CSV format
 * - Wraps in quotes if contains comma, quote, or newline
 * - Escapes existing quotes by doubling them
 */
function escapeCSVValue(value: string | number | null | undefined): string {
  if (value === null || value === undefined) {
    return ""
  }

  const stringValue = String(value)

  // Check if value needs escaping
  if (
    stringValue.includes(",") ||
    stringValue.includes('"') ||
    stringValue.includes("\n") ||
    stringValue.includes("\r")
  ) {
    // Escape quotes by doubling them and wrap in quotes
    return `"${stringValue.replace(/"/g, '""')}"`
  }

  return stringValue
}

/**
 * Converts an array of data to CSV string format
 *
 * @param data - Array of data objects to convert
 * @param columns - Column definitions with headers and accessor functions
 * @returns CSV formatted string
 *
 * @example
 * ```ts
 * const csv = convertToCSV(users, [
 *   { header: "Name", accessor: (u) => u.name },
 *   { header: "Email", accessor: (u) => u.email },
 * ])
 * ```
 */
export function convertToCSV<T>(data: T[], columns: CSVColumn<T>[]): string {
  // Create header row
  const headerRow = columns.map((col) => escapeCSVValue(col.header)).join(",")

  // Create data rows
  const dataRows = data.map((row) =>
    columns.map((col) => escapeCSVValue(col.accessor(row))).join(",")
  )

  // Combine header and data rows
  return [headerRow, ...dataRows].join("\n")
}

/**
 * Triggers a CSV file download in the browser
 *
 * @param content - CSV string content
 * @param filename - Name of the file to download (without extension)
 *
 * @example
 * ```ts
 * downloadCSV(csvContent, "users-export-2025-01-15")
 * ```
 */
export function downloadCSV(content: string, filename: string): void {
  // Add BOM for Excel UTF-8 compatibility
  const BOM = "\uFEFF"
  const blob = new Blob([BOM + content], { type: "text/csv;charset=utf-8;" })

  // Create download link
  const link = document.createElement("a")
  const url = URL.createObjectURL(blob)

  link.setAttribute("href", url)
  link.setAttribute("download", `${filename}.csv`)
  link.style.visibility = "hidden"

  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)

  // Clean up object URL
  URL.revokeObjectURL(url)
}

// Note: formatDateForCSV and formatCurrencyForCSV are now exported from the top of this file
// They use the consolidated implementations from @/lib/utils/formatting

/**
 * Generates a filename for CSV export with current date
 *
 * @param prefix - Filename prefix (e.g., "assessment-export")
 * @returns Filename with date suffix (e.g., "assessment-export-2025-01-15")
 */
export function generateExportFilename(prefix: string): string {
  const today = dateFnsFormat(new Date(), "yyyy-MM-dd")
  return `${prefix}-${today}`
}
