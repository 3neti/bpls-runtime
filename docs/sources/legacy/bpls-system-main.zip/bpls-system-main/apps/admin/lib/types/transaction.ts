/**
 * Transaction and payment types
 */

export type PaymentStatus = 'pending' | 'completed' | 'failed' | 'cancelled'
export type PaymentMethod = 'cash' | 'card' | 'bank-transfer' | 'online'

export interface Payment {
  id: string
  transactionId: string
  amount: number
  method: PaymentMethod
  status: PaymentStatus
  paidAt?: string
  reference?: string
}

export interface Transaction {
  id: string
  permitId: string
  businessId: string
  totalAmount: number
  payments: Payment[]
  status: PaymentStatus
  createdAt: string
  completedAt?: string
  processedBy?: string
}

export interface TransactionSummary {
  id: string
  permitId: string
  businessName: string
  totalAmount: number
  status: PaymentStatus
  createdAt: string
}
