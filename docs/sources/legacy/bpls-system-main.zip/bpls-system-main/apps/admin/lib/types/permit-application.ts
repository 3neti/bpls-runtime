/**
 * Business Permit Application Types
 *
 * Type definitions for business permit applications derived from Convex schema.
 * This file serves as the single source of truth for permit application types in the frontend.
 *
 * SOURCE OF TRUTH: convex/schema.ts (business_permit_applications table)
 *
 * Import pattern:
 * ```typescript
 * import type { PermitApplication, PermitApplicationStatus } from '@/lib/types/permit-application'
 * ```
 */

import type { Doc } from "@repo/backend/convex/_generated/dataModel"

/**
 * Business Permit Application record
 * Derived directly from Convex schema - automatically stays in sync
 */
export type PermitApplication = Doc<"business_permit_applications">

/**
 * Application status enum
 * Extracted from the PermitApplication type
 */
export type PermitApplicationStatus = PermitApplication["status"]

/**
 * Line of Business object structure
 * Extracted from the PermitApplication linesOfBusiness array
 */
export type LineOfBusiness = PermitApplication["linesOfBusiness"][number]

/**
 * Permit Application with enriched related data
 * Used when fetching application details with business owner and business information
 */
export interface PermitApplicationWithDetails extends PermitApplication {
  businessOwner: Doc<"business_owners"> | null
  business: Doc<"businesses"> | null
}

/**
 * Permit Application summary view
 * Lightweight representation for list views
 */
export type PermitApplicationSummary = Pick<
  PermitApplication,
  "_id" | "applicationNumber" | "status" | "submittedAt" | "totalFees"
>

/**
 * Form values for creating a new permit application
 * Used in the permit application submission flow
 */
export interface CreatePermitApplicationInput {
  businessOwnerId: string
  businessId: string
  linesOfBusiness: LineOfBusiness[]
}

/**
 * Form values for submitting application for department clearances
 * Used when completing LOB configuration and fee calculation
 */
export interface SubmitForClearancesInput {
  id: string
  linesOfBusiness: LineOfBusiness[]
  totalFees: number
  assessedBy: string
  assessmentRemarks?: string
}

/**
 * Form values for updating application status
 * Used for workflow transitions
 */
export interface UpdatePermitApplicationStatusInput {
  id: string
  status: PermitApplicationStatus
  remarks?: string
}

/**
 * Form values for updating lines of business
 * Used during the assessment phase
 */
export interface UpdateLinesOfBusinessInput {
  id: string
  linesOfBusiness: LineOfBusiness[]
}

/**
 * Status transition validation map
 * Defines allowed status transitions in the workflow
 */
export const STATUS_TRANSITIONS: Record<PermitApplicationStatus, PermitApplicationStatus[]> = {
  Draft: ["Assessment"],
  Assessment: ["Approval", "Draft"],
  Approval: ["Pending Payment", "Assessment"],
  "Pending Payment": ["Released", "Assessment"],
  Released: ["Pending Payment"],
}

/**
 * Status display labels
 * User-friendly labels for each status
 */
export const STATUS_LABELS: Record<PermitApplicationStatus, string> = {
  Draft: "Draft",
  Assessment: "Pending Assessment",
  Approval: "Pending Approval",
  "Pending Payment": "Pending Payment",
  Released: "Released",
}

/**
 * Status colors for UI display
 * Tailwind-compatible color classes
 */
export const STATUS_COLORS: Record<PermitApplicationStatus, string> = {
  Draft: "bg-gray-100 text-gray-800 border-gray-200",
  Assessment: "bg-yellow-100 text-yellow-800 border-yellow-200",
  Approval: "bg-purple-100 text-purple-800 border-purple-200",
  "Pending Payment": "bg-orange-100 text-orange-800 border-orange-200",
  Released: "bg-blue-100 text-blue-800 border-blue-200",
}

/**
 * Status options for filter dropdowns
 * Array of { value, label } objects for use in filter components
 */
export const STATUS_OPTIONS: { value: string; label: string }[] = [
  { value: "Draft", label: "Draft" },
  { value: "Assessment", label: "Pending Assessment" },
  { value: "Approval", label: "Pending Approval" },
  { value: "Pending Payment", label: "Pending Payment" },
  { value: "Released", label: "Released" },
]

/**
 * Helper function to check if a status transition is valid
 */
export function isValidStatusTransition(
  currentStatus: PermitApplicationStatus,
  newStatus: PermitApplicationStatus
): boolean {
  return STATUS_TRANSITIONS[currentStatus]?.includes(newStatus) ?? false
}

/**
 * Helper function to get next allowed statuses
 */
export function getNextAllowedStatuses(
  currentStatus: PermitApplicationStatus
): PermitApplicationStatus[] {
  return STATUS_TRANSITIONS[currentStatus] || []
}
