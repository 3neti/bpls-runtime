/**
 * Line of Business types for the taxes & fees hierarchy system
 *
 * These types are derived from the Convex schema as the single source of truth.
 * The database schema is defined in convex/schema.ts (table name: "groups")
 *
 * Hierarchy: Major → Division (contains Fees) → Lines of Business (inherit & override fees)
 * Example lines of business: "Retail Trade", "Food & Beverage", "Manufacturing"
 * (Previously known as Business Nature Categories or Groups)
 */

import type { Doc, Id } from "@repo/backend/convex/_generated/dataModel"
import type { Fee } from "./fees"
import type { DivisionId } from "./division"

// Core line of business type derived from Convex schema (table name: "groups")
export type LineOfBusiness = Doc<"groups">

// Extract specific field types
export type LineOfBusinessId = Id<"groups">

/**
 * Line of Business form values for creation/editing
 */
export interface LineOfBusinessFormValues {
  name: string
  description: string
}

/**
 * Line of Business with applied divisions
 * Used for detail views showing which divisions are applied
 */
export interface LineOfBusinessWithDivisions extends LineOfBusiness {
  appliedDivisions: Array<{
    divisionId: DivisionId
    divisionName: string
    majorName: string
    feeCount: number
  }>
  totalInheritedFees: number
}

/**
 * Fee override configuration
 * Represents an override for a specific fee in a line of business
 */
export type FeeOverride = Doc<"fee_overrides">

/**
 * Inherited fee with override status
 * Represents a fee inherited from a division, with optional override
 */
export interface InheritedFee extends Fee {
  // Division information
  divisionId: DivisionId
  divisionName: string
  majorName: string

  // Override information
  isOverridden: boolean
  override?: FeeOverride

  // Final values (either original or overridden)
  finalAmount?: number
  finalRanges?: Fee["ranges"]
  finalFormula?: string
}

/**
 * Fee override form values
 * Used when creating/editing fee overrides
 */
export interface FeeOverrideFormValues {
  feeId: Id<"fees">
  feeName: string
  feeType: "Constant" | "Range" | "Formula"

  // Original values from inherited fee
  originalAmount?: number
  originalRanges?: Fee["ranges"]
  originalFormula?: string

  // Override values
  overrideAmount?: number
  overrideRanges?: Fee["ranges"]
  overrideFormula?: string
  reason: string
}

/**
 * Line of Business summary for dropdowns/selects
 */
export interface LineOfBusinessSummary {
  _id: LineOfBusinessId
  name: string
  description: string
}

/**
 * Line of Business with fee preview
 * Used for list views showing fee count preview
 */
export interface LineOfBusinessWithFeePreview extends LineOfBusiness {
  appliedDivisionCount: number
  inheritedFeeCount: number
  overriddenFeeCount: number
}

/**
 * Fee calculation result for a line of business
 * Used when calculating fees for permits
 */
export interface LineOfBusinessFeeCalculation {
  lineOfBusinessId: LineOfBusinessId
  lineOfBusinessName: string
  fees: InheritedFee[]
  totalFees: number
}
