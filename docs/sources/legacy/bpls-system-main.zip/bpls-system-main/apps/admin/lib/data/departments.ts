/**
 * Department Configurations
 *
 * @deprecated This file is deprecated. Use `lib/data/clearances.ts` instead.
 *
 * Departments are now properties of clearances, not primary entities.
 * This file is maintained for backward compatibility only.
 */

import type { DepartmentConfig } from "@/lib/types/department"
import { clearances, getClearanceByDepartmentSlug } from "./clearances"

/**
 * Convert clearance config to department config (for backward compatibility)
 */
function clearanceToDepartmentConfig(clearanceId: string): DepartmentConfig | undefined {
  const clearance = clearances.find((c) => c.id === clearanceId)
  if (!clearance) return undefined

  return {
    name: clearance.department.name,
    shortName: clearance.department.shortName,
    slug: clearance.department.slug,
    icon: clearance.department.icon,
    route: clearance.route,
    pageTitle: `${clearance.certificateName} Review`,
    description: clearance.description,
    user: clearance.department.officer,
  }
}

/**
 * @deprecated Use clearances from `lib/data/clearances.ts` instead
 */
export const sanitaryConfig = clearanceToDepartmentConfig("sanitary")!

/**
 * @deprecated Use clearances from `lib/data/clearances.ts` instead
 */
export const bfpConfig = clearanceToDepartmentConfig("fire-safety")!

/**
 * @deprecated Use clearances from `lib/data/clearances.ts` instead
 */
export const mpdcConfig = clearanceToDepartmentConfig("mpdc")!

/**
 * @deprecated Use clearances from `lib/data/clearances.ts` instead
 */
export const menroConfig = clearanceToDepartmentConfig("environmental")!

/**
 * @deprecated Use clearances from `lib/data/clearances.ts` instead
 */
export const engineeringConfig = clearanceToDepartmentConfig("engineering")!

/**
 * All Departments Registry (Backward Compatibility)
 * @deprecated Use `clearances` from `lib/data/clearances.ts` instead
 */
export const departments: DepartmentConfig[] = [
  sanitaryConfig,
  bfpConfig,
  mpdcConfig,
  menroConfig,
  engineeringConfig,
]

/**
 * Get Department by Slug (Backward Compatibility)
 * @deprecated Use `getClearanceByDepartmentSlug` from `lib/data/clearances.ts` instead
 *
 * @param slug - Department slug (e.g., "sanitary", "bfp")
 * @returns Department configuration or undefined if not found
 */
export function getDepartmentBySlug(slug: string): DepartmentConfig | undefined {
  const clearance = getClearanceByDepartmentSlug(slug)
  if (!clearance) return undefined

  return {
    name: clearance.department.name,
    shortName: clearance.department.shortName,
    slug: clearance.department.slug,
    icon: clearance.department.icon,
    route: clearance.route,
    pageTitle: `${clearance.certificateName} Review`,
    description: clearance.description,
    user: clearance.department.officer,
  }
}

/**
 * Get All Department Slugs (Backward Compatibility)
 * @deprecated Use `getDepartmentSlugs` from `lib/data/clearances.ts` instead
 *
 * @returns Array of department slugs
 */
export function getDepartmentSlugs(): string[] {
  return clearances.map((c) => c.department.slug)
}
