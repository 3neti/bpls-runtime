import { z } from "zod";

/**
 * Step 1: Municipality Information Schema
 */
export const municipalityStepSchema = z.object({
  municipalityName: z
    .string()
    .min(1, "Municipality name is required")
    .max(200, "Municipality name must be less than 200 characters"),
  municipalityShortName: z
    .string()
    .min(1, "Short name is required")
    .max(100, "Short name must be less than 100 characters"),
  provinceName: z
    .string()
    .min(1, "Province name is required")
    .max(200, "Province name must be less than 200 characters"),
  fullAddress: z
    .string()
    .min(1, "Full address is required")
    .max(500, "Full address must be less than 500 characters"),
  // Permit Configuration
  permitExpiryMode: z.enum(["one_year", "end_of_year"]),
});

/**
 * Step 2: Government Officials Schema
 */
export const officialsStepSchema = z.object({
  mayorName: z
    .string()
    .min(1, "Mayor name is required")
    .max(200, "Mayor name must be less than 200 characters"),
  mayorTitle: z
    .string()
    .min(1, "Mayor title is required")
    .max(100, "Mayor title must be less than 100 characters"),
  treasurerName: z
    .string()
    .min(1, "Treasurer name is required")
    .max(200, "Treasurer name must be less than 200 characters"),
  treasurerTitle: z
    .string()
    .min(1, "Treasurer title is required")
    .max(100, "Treasurer title must be less than 100 characters"),
});

/**
 * Step 3: Branding Schema (image storage IDs are optional)
 */
export const brandingStepSchema = z.object({
  municipalSealStorageId: z.string().optional(),
  logoStorageId: z.string().optional(),
  landingImageStorageId: z.string().optional(),
});

/**
 * Step 4: Admin User Schema
 */
export const adminUserStepSchema = z
  .object({
    adminEmail: z
      .string()
      .email("Please enter a valid email address")
      .min(1, "Email is required"),
    adminPassword: z
      .string()
      .min(8, "Password must be at least 8 characters")
      .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
      .regex(/[a-z]/, "Password must contain at least one lowercase letter")
      .regex(/\d/, "Password must contain at least one number"),
    adminConfirmPassword: z.string(),
    adminFirstName: z
      .string()
      .min(1, "First name is required")
      .max(100, "First name must be less than 100 characters"),
    adminLastName: z
      .string()
      .min(1, "Last name is required")
      .max(100, "Last name must be less than 100 characters"),
  })
  .refine((data) => data.adminPassword === data.adminConfirmPassword, {
    message: "Passwords do not match",
    path: ["adminConfirmPassword"],
  });

/**
 * Complete Onboarding Schema (all steps combined)
 */
export const onboardingSchema = municipalityStepSchema
  .merge(officialsStepSchema)
  .merge(brandingStepSchema)
  .merge(
    z.object({
      adminEmail: z.string().email().min(1),
      adminPassword: z.string().min(8),
      adminConfirmPassword: z.string(),
      adminFirstName: z.string().min(1).max(100),
      adminLastName: z.string().min(1).max(100),
    })
  );

/**
 * Types
 */
export type MunicipalityStepData = z.infer<typeof municipalityStepSchema>;
export type OfficialsStepData = z.infer<typeof officialsStepSchema>;
export type BrandingStepData = z.infer<typeof brandingStepSchema>;
export type AdminUserStepData = z.infer<typeof adminUserStepSchema>;
export type OnboardingData = z.infer<typeof onboardingSchema>;

/**
 * Default values for form initialization
 */
export const municipalityStepDefaults: MunicipalityStepData = {
  municipalityName: "",
  municipalityShortName: "",
  provinceName: "",
  fullAddress: "",
  permitExpiryMode: "end_of_year", // Default: end of calendar year
};

export const officialsStepDefaults: OfficialsStepData = {
  mayorName: "",
  mayorTitle: "Municipal Mayor",
  treasurerName: "",
  treasurerTitle: "Municipal Treasurer",
};

export const brandingStepDefaults: BrandingStepData = {
  municipalSealStorageId: undefined,
  logoStorageId: undefined,
  landingImageStorageId: undefined,
};

export const adminUserStepDefaults = {
  adminEmail: "",
  adminPassword: "",
  adminConfirmPassword: "",
  adminFirstName: "",
  adminLastName: "",
};

export const onboardingDefaults: OnboardingData = {
  ...municipalityStepDefaults,
  ...officialsStepDefaults,
  ...brandingStepDefaults,
  ...adminUserStepDefaults,
};

/**
 * Step configuration for the wizard
 */
export const ONBOARDING_STEPS = [
  {
    id: 1,
    title: "Municipality",
    description: "Set up your municipality information",
    schema: municipalityStepSchema,
  },
  {
    id: 2,
    title: "Officials",
    description: "Configure government officials",
    schema: officialsStepSchema,
  },
  {
    id: 3,
    title: "Branding",
    description: "Upload logos and images",
    schema: brandingStepSchema,
  },
  {
    id: 4,
    title: "Admin Account",
    description: "Create administrator account",
    schema: adminUserStepSchema,
  },
  {
    id: 5,
    title: "Review",
    description: "Review and complete setup",
    schema: null, // No validation needed for review step
  },
] as const;
