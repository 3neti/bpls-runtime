/**
 * Surcharge & Penalty Calculator Utility
 *
 * Client-side utility for calculating surcharge and penalty based on custom formulas.
 * Used for real-time preview in the sandbox and for quick calculations.
 *
 * Available Variables:
 * - periodFee: Tax / periodToPay (Tax amount divided by payment periods)
 * - Tax: Total of all fees with category "Tax" from Line of Business
 * - monthsMissed: Months between due date and payment date
 * - daysDiff: Days between due date and payment date
 * - periodToPay: Number of payment periods (1, 2, or 4)
 * - totalFees: Total fees from all schedules
 */

// Available variables for formula evaluation
export const SURCHARGE_PENALTY_VARIABLES = [
  "periodFee",
  "Tax",
  "monthsMissed",
  "monthsMissedInPeriod",
  "quartersMissed",
  "daysDiff",
  "periodToPay",
  "totalFees",
] as const;

// Allowed tokens in formulas (for validation)
const ALLOWED_TOKENS = [
  "+",
  "-",
  "*",
  "/",
  "(",
  ")",
  ".",
  " ",
  "Math",
  "min",
  "max",
  "floor",
  "ceil",
  "round",
  "abs",
  "pow",
  "sqrt",
] as const;

export interface SurchargeConfig {
  surchargeFormula: string | null | undefined;
  penaltyFormula: string | null | undefined;
  quarterlyDueDates?: { Q1: string; Q2: string; Q3: string; Q4: string };
  semiAnnualDueDates?: { S1: string; S2: string };
  annualDueDate?: { A1: string };
  fixedMonthlyDueDate?: number; // DEPRECATED - kept for backward compat
}

// Default due dates (MM-DD format)
export const DEFAULT_QUARTERLY_DUE_DATES = { Q1: "01-20", Q2: "04-20", Q3: "07-20", Q4: "10-20" };
export const DEFAULT_SEMI_ANNUAL_DUE_DATES = { S1: "01-20", S2: "07-20" };
export const DEFAULT_ANNUAL_DUE_DATE = { A1: "01-20" };

/**
 * Parse a MM-DD string into a Date for a given year.
 */
export function parseMMDDToDate(mmdd: string, year: number): Date {
  const [monthStr, dayStr] = mmdd.split("-");
  return new Date(year, parseInt(monthStr, 10) - 1, parseInt(dayStr, 10));
}

export interface CalculationInput {
  Tax: number; // Total of all fees with category "Tax"
  periodToPay: 1 | 2 | 4;
  dueDate: Date;
  paymentDate: Date;
  totalFees?: number;
}

export interface CalculationResult {
  periodFee: number;
  daysDiff: number;
  monthsMissed: number;
  monthsMissedInPeriod: number;
  quartersMissed: number;
  isPastDueDate: boolean;
  surcharge: number;
  penalty: number;
  total: number;
}

export interface FormulaValidationResult {
  valid: boolean;
  error?: string;
  evaluatedResult?: number;
}

/**
 * Calculate the number of days between two dates.
 * Returns positive if paymentDate is after dueDate.
 */
export function calculateDaysDiff(dueDate: Date, paymentDate: Date): number {
  const timeDiff = paymentDate.getTime() - dueDate.getTime();
  return Math.floor(timeDiff / (1000 * 60 * 60 * 24));
}

/**
 * Calculate months missed (rounded up to nearest month).
 * Minimum is 1 if payment is on or past due date.
 */
export function calculateMonthsMissed(daysDiff: number): number {
  if (daysDiff < 0) return 0;
  return Math.max(1, Math.ceil(Math.max(daysDiff, 1) / 30));
}

/**
 * Calculate quarters missed (rounded up to nearest quarter).
 * Minimum is 1 if payment is on or past due date.
 */
export function calculateQuartersMissed(daysDiff: number): number {
  if (daysDiff < 0) return 0;
  return Math.max(1, Math.ceil(Math.max(daysDiff, 1) / 90));
}

/**
 * Cap monthsMissed at the length of one payment period (12 / periodToPay).
 * Quarterly=3, Semi-Annually=6, Annually=12. This keeps the per-period
 * penalty constant once the next period begins.
 */
export function calculateMonthsMissedInPeriod(monthsMissed: number, periodToPay: number): number {
  if (monthsMissed <= 0 || periodToPay <= 0) return 0;
  const cap = Math.floor(12 / periodToPay);
  return Math.min(monthsMissed, cap);
}

/**
 * Validate a surcharge/penalty formula.
 * Checks for valid variables and syntax.
 */
export function validateSurchargeFormula(formula: string): FormulaValidationResult {
  // Empty formula is valid (results in 0)
  if (!formula || formula.trim() === "") {
    return { valid: true, evaluatedResult: 0 };
  }

  // Extract all word tokens from formula (potential variables)
  const variablePattern = /[a-zA-Z_][a-zA-Z0-9_]*/g;
  const tokens = formula.match(variablePattern) || [];

  // Check each token
  for (const token of tokens) {
    // Skip allowed tokens (Math functions, etc.)
    if (ALLOWED_TOKENS.includes(token as typeof ALLOWED_TOKENS[number])) {
      continue;
    }
    // Check if it's an allowed variable
    if (!SURCHARGE_PENALTY_VARIABLES.includes(token as typeof SURCHARGE_PENALTY_VARIABLES[number])) {
      return {
        valid: false,
        error: `Unknown variable: "${token}". Available: ${SURCHARGE_PENALTY_VARIABLES.join(", ")}`,
      };
    }
  }

  // Try to evaluate with sample data
  try {
    const sampleData = {
      periodFee: 12500,
      Tax: 50000,
      monthsMissed: 4,
      monthsMissedInPeriod: 3,
      quartersMissed: 2,
      daysDiff: 120,
      periodToPay: 4,
      totalFees: 75000,
    };

    let expression = formula;
    for (const [varName, value] of Object.entries(sampleData)) {
      const regex = new RegExp(`\\b${varName}\\b`, "g");
      expression = expression.replace(regex, value.toString());
    }

    // Check for invalid characters (security)
    const sanitized = expression.replace(/[0-9\s+\-*/().Math\w]/g, "");
    if (sanitized.length > 0) {
      return {
        valid: false,
        error: `Invalid characters in formula: "${sanitized}"`,
      };
    }

    // Evaluate the expression
    const result = Function(`"use strict"; return (${expression})`)();

    if (typeof result !== "number" || isNaN(result)) {
      return {
        valid: false,
        error: "Formula must evaluate to a valid number",
      };
    }

    if (!isFinite(result)) {
      return {
        valid: false,
        error: "Formula results in infinity (division by zero?)",
      };
    }

    return { valid: true, evaluatedResult: result };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    if (errorMessage.includes("Unexpected")) {
      return {
        valid: false,
        error: "Syntax error: Check for missing operators or parentheses",
      };
    }
    return {
      valid: false,
      error: `Syntax error: ${errorMessage}`,
    };
  }
}

/**
 * Evaluate a formula with given variables.
 * Returns 0 if formula is empty or invalid.
 */
export function evaluateFormula(
  formula: string | null | undefined,
  variables: {
    periodFee: number;
    Tax: number;
    monthsMissed: number;
    monthsMissedInPeriod: number;
    quartersMissed: number;
    daysDiff: number;
    periodToPay: number;
    totalFees: number;
  }
): number {
  if (!formula || formula.trim() === "") {
    return 0;
  }

  try {
    let expression = formula;
    for (const [varName, value] of Object.entries(variables)) {
      const regex = new RegExp(`\\b${varName}\\b`, "g");
      expression = expression.replace(regex, value.toString());
    }

    const result = Function(`"use strict"; return (${expression})`)();

    if (typeof result === "number" && !isNaN(result) && isFinite(result)) {
      return Math.max(0, result); // Ensure non-negative
    }
    return 0;
  } catch {
    return 0;
  }
}

/**
 * Calculate surcharge and penalty based on configuration formulas.
 *
 * @param config - The surcharge/penalty configuration with formulas
 * @param input - The calculation inputs (Tax amount, periods, dates)
 * @returns The calculated results with breakdown
 */
export function calculateSurchargeAndPenalty(
  config: SurchargeConfig,
  input: CalculationInput
): CalculationResult {
  // Calculate period fee (Tax amount divided by payment periods)
  const periodFee = input.Tax / input.periodToPay;

  // Calculate days difference
  const daysDiff = calculateDaysDiff(input.dueDate, input.paymentDate);

  // Due date applies ON the date (inclusive) - payment on the due date incurs surcharge
  const isPastDueDate = daysDiff >= 0;

  // If not past due date, no surcharge/penalty
  if (!isPastDueDate) {
    return {
      periodFee: roundTo2Decimals(periodFee),
      daysDiff,
      monthsMissed: 0,
      monthsMissedInPeriod: 0,
      quartersMissed: 0,
      isPastDueDate: false,
      surcharge: 0,
      penalty: 0,
      total: roundTo2Decimals(periodFee),
    };
  }

  // Calculate months and quarters missed
  const monthsMissed = calculateMonthsMissed(daysDiff);
  const monthsMissedInPeriod = calculateMonthsMissedInPeriod(monthsMissed, input.periodToPay);
  const quartersMissed = calculateQuartersMissed(daysDiff);

  // Prepare variables for formula evaluation
  const variables = {
    periodFee,
    Tax: input.Tax,
    monthsMissed,
    monthsMissedInPeriod,
    quartersMissed,
    daysDiff,
    periodToPay: input.periodToPay,
    totalFees: input.totalFees || 0,
  };

  // Evaluate formulas
  const surcharge = evaluateFormula(config.surchargeFormula, variables);
  const penalty = evaluateFormula(config.penaltyFormula, variables);

  // Calculate total
  const total = periodFee + surcharge + penalty;

  return {
    periodFee: roundTo2Decimals(periodFee),
    daysDiff,
    monthsMissed,
    monthsMissedInPeriod,
    quartersMissed,
    isPastDueDate: true,
    surcharge: roundTo2Decimals(surcharge),
    penalty: roundTo2Decimals(penalty),
    total: roundTo2Decimals(total),
  };
}

/**
 * Round a number to 2 decimal places (for currency).
 */
function roundTo2Decimals(value: number): number {
  return Math.round(value * 100) / 100;
}

/**
 * Get the due dates based on payment mode.
 * Uses per-mode due dates from config if provided, otherwise falls back to defaults.
 * @param mode - Payment mode
 * @param year - Year for the dates
 * @param dueDatesConfig - Optional per-mode due dates (MM-DD format)
 * @returns Array of due dates
 */
export function getDefaultDueDates(
  mode: "Annually" | "Semi-Annually" | "Quarterly",
  year: number = new Date().getFullYear(),
  dueDatesConfig?: {
    quarterlyDueDates?: { Q1: string; Q2: string; Q3: string; Q4: string };
    semiAnnualDueDates?: { S1: string; S2: string };
    annualDueDate?: { A1: string };
  }
): Date[] {
  switch (mode) {
    case "Annually": {
      const dates = dueDatesConfig?.annualDueDate || DEFAULT_ANNUAL_DUE_DATE;
      return [parseMMDDToDate(dates.A1, year)];
    }
    case "Semi-Annually": {
      const dates = dueDatesConfig?.semiAnnualDueDates || DEFAULT_SEMI_ANNUAL_DUE_DATES;
      return [
        parseMMDDToDate(dates.S1, year),
        parseMMDDToDate(dates.S2, year),
      ];
    }
    case "Quarterly": {
      const dates = dueDatesConfig?.quarterlyDueDates || DEFAULT_QUARTERLY_DUE_DATES;
      return [
        parseMMDDToDate(dates.Q1, year),
        parseMMDDToDate(dates.Q2, year),
        parseMMDDToDate(dates.Q3, year),
        parseMMDDToDate(dates.Q4, year),
      ];
    }
  }
}

/**
 * Get the number of periods for a payment mode.
 */
export function getPeriodsForMode(
  mode: "Annually" | "Semi-Annually" | "Quarterly"
): 1 | 2 | 4 {
  switch (mode) {
    case "Annually":
      return 1;
    case "Semi-Annually":
      return 2;
    case "Quarterly":
      return 4;
  }
}

/**
 * Resolve the due date (MM-DD) for a specific payment term from the surcharge config.
 * Maps (mode, sectionNumber) → MM-DD string.
 * Returns null if config doesn't have per-mode dates for this term.
 */
export function resolveTermDueDate(
  mode: "Annually" | "Semi-Annually" | "Quarterly",
  sectionNumber: number,
  config: {
    quarterlyDueDates?: { Q1: string; Q2: string; Q3: string; Q4: string };
    semiAnnualDueDates?: { S1: string; S2: string };
    annualDueDate?: { A1: string };
  }
): string | null {
  switch (mode) {
    case "Quarterly": {
      const keys = ["Q1", "Q2", "Q3", "Q4"] as const;
      const key = keys[sectionNumber - 1];
      return key ? (config.quarterlyDueDates?.[key] ?? null) : null;
    }
    case "Semi-Annually": {
      const keys = ["S1", "S2"] as const;
      const key = keys[sectionNumber - 1];
      return key ? (config.semiAnnualDueDates?.[key] ?? null) : null;
    }
    case "Annually":
      return config.annualDueDate?.A1 ?? null;
  }
}
