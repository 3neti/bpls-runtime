/**
 * Permit Helper Utilities
 *
 * Pure functions for permit-related calculations and formatting.
 * These utilities are used across permit review and approval components.
 */

import { businessNatureFees } from '@/lib/data/business-fees'
import type { FeeConfig, BusinessData, ApplicationType } from '@/lib/types/fees'
import type { LineOfBusiness } from '@/lib/types/business'
import { formatCurrency, getInitials, formatDate } from '@/lib/utils/formatting'

// Re-export formatting utilities for backward compatibility
export { formatCurrency, getInitials, formatDate }

/**
 * Calculate fee amount based on fee type and business data
 */
export const calculateFee = (fee: FeeConfig, businessData: BusinessData): number => {
  if (fee.feeType === "Constant") {
    return fee.amount
  }

  if (fee.feeType === "Range" && fee.ranges && fee.rangeField) {
    // Check if range field is an asset variable
    let fieldValue = 0;
    if (businessData.categoryVariables && fee.rangeField in businessData.categoryVariables) {
      // Asset variable (e.g., "horses", "numberOfTables")
      fieldValue = businessData.categoryVariables[fee.rangeField] || 0;
    } else {
      // Standard business field
      fieldValue = businessData[fee.rangeField as keyof BusinessData] as number || 0;
    }

    const matchingRange = fee.ranges.find(
      (range) => fieldValue >= range.min && fieldValue <= range.max
    )
    return matchingRange ? (matchingRange.fee || 0) : 0
  }

  if (fee.feeType === "Formula" && fee.formula) {
    try {
      const expression = fee.formula
        .replace(/numberOfEmployees/g, (businessData.numberOfEmployees || 0).toString())
        .replace(/grossSales/g, (businessData.grossSales || 0).toString())
        .replace(/floorArea/g, (businessData.floorArea || 0).toString())
        .replace(/capitalInvestment/g, (businessData.capitalInvestment || 0).toString())

      const result = Function(`"use strict"; return (${expression})`)()
      return typeof result === "number" && !isNaN(result) ? result : 0
    } catch (error) {
      console.error('Error calculating formula fee:', error)
      return 0
    }
  }

  return 0
}

/**
 * Generate fee calculation caption/description
 */
export const generateFeeCaption = (fee: FeeConfig, businessData: BusinessData): string | null => {
  if (fee.feeType === "Range" && fee.rangeField && fee.ranges) {
    // Check if range field is an asset variable
    let fieldValue = 0;
    if (businessData.categoryVariables && fee.rangeField in businessData.categoryVariables) {
      // Asset variable (e.g., "horses", "numberOfTables")
      fieldValue = businessData.categoryVariables[fee.rangeField] || 0;
    } else {
      // Standard business field
      fieldValue = businessData[fee.rangeField as keyof BusinessData] as number || 0;
    }

    const matchingRange = fee.ranges.find(
      (range) => fieldValue >= range.min && fieldValue <= range.max
    )

    const fieldLabel =
      fee.rangeField === "grossSales"
        ? "Gross Sales"
        : fee.rangeField === "floorArea"
          ? "Floor Area"
          : fee.rangeField === "numberOfEmployees"
            ? "Number of Employees"
            : "Capital Investment"

    const formatFieldValue = (field: string, value: number): string => {
      if (field === "grossSales" || field === "capitalInvestment") {
        return formatCurrency(value, { withSymbol: true })
      } else if (field === "businessArea") {
        return `${value.toLocaleString()} sq.m.`
      } else if (field === "numberOfEmployees") {
        return value.toString()
      }
      return value.toString()
    }

    if (matchingRange) {
      return `${fieldLabel} (${formatFieldValue(fee.rangeField, fieldValue)}) - Range: ${formatFieldValue(fee.rangeField, matchingRange.min)} to ${formatFieldValue(fee.rangeField, matchingRange.max)}`
    } else {
      return `${fieldLabel} (${formatFieldValue(fee.rangeField, fieldValue)}) - No matching range`
    }
  }

  if (fee.feeType === "Formula" && fee.formula) {
    let caption = fee.formula
    if (caption.includes("numberOfEmployees")) {
      caption = caption.replace(
        /numberOfEmployees/g,
        `numberOfEmployees (${businessData.numberOfEmployees})`
      )
    }
    if (caption.includes("grossSales")) {
      caption = caption.replace(
        /grossSales/g,
        `grossSales (${formatCurrency(businessData.grossSales, { withSymbol: true })})`
      )
    }
    if (caption.includes("floorArea")) {
      caption = caption.replace(
        /floorArea/g,
        `floorArea (${businessData.floorArea} sq.m.)`
      )
    }
    if (caption.includes("capitalInvestment")) {
      caption = caption.replace(
        /capitalInvestment/g,
        `capitalInvestment (${formatCurrency(businessData.capitalInvestment, { withSymbol: true })})`
      )
    }
    return caption
  }

  return null
}

/**
 * Calculate aggregated fees from all lines of business
 */
export interface AggregatedFeesResult {
  feesBreakdown: Array<{
    name: string
    amount: number
    type: string
    description: string
  }>
  feesTotal: number
}

export interface ApplicationForFees {
  business: {
    maleEmployeeCount: number
    femaleEmployeeCount: number
    linesOfBusiness: Array<LineOfBusiness & { permitApplicationType?: string }>
  }
}

export const calculateAggregatedFees = (application: ApplicationForFees): AggregatedFeesResult => {
  const feeMap = new Map<string, { amount: number; type: string; description: string }>()

  application.business.linesOfBusiness.forEach((line) => {
    const businessNature = businessNatureFees[line.businessCategory as keyof typeof businessNatureFees]
    if (!businessNature) return

    const totalEmployees = application.business.maleEmployeeCount + application.business.femaleEmployeeCount
    const businessData: BusinessData = {
      numberOfEmployees: totalEmployees,
      grossSales: parseFloat(line.businessAnnualRevenue ?? line.grossSales) || 0,
      floorArea: 200,
      capitalInvestment: parseFloat(line.capitalInvestment) || 0,
    }

    businessNature.fees
      .filter((fee) => fee.applicationType.includes((line.permitApplicationType as ApplicationType) || "New"))
      .forEach((fee) => {
        const calculatedAmount = calculateFee(fee, businessData)

        if (feeMap.has(fee.name)) {
          const existing = feeMap.get(fee.name)!
          existing.amount += calculatedAmount
        } else {
          let description = ""
          if (fee.feeType === "Formula") {
            description = `${totalEmployees} employees`
          } else if (fee.feeType === "Range") {
            description = `Based on ${fee.rangeField === "grossSales" ? "gross sales" : fee.rangeField === "capitalInvestment" ? "capital investment" : fee.rangeField}`
          } else {
            description = "Standard fee"
          }

          feeMap.set(fee.name, {
            amount: calculatedAmount,
            type: fee.feeType,
            description: description,
          })
        }
      })
  })

  const feesBreakdown = Array.from(feeMap.entries()).map(([name, data]) => ({
    name,
    amount: data.amount,
    type: data.type,
    description: data.description,
  }))

  const feesTotal = feesBreakdown.reduce((sum, fee) => sum + fee.amount, 0)

  return { feesBreakdown, feesTotal }
}

/**
 * Generate permit number from application number
 * Converts "BPA-2025-001" to "MP-2025-001"
 */
export const generatePermitNumber = (applicationNumber: string): string => {
  return applicationNumber.replace("BPA-", "MP-")
}

/**
 * Calculate expiration date (1 year from issue date)
 */
export const calculateExpirationDate = (issueDateStr: string): string => {
  const issueDate = new Date(issueDateStr)
  issueDate.setFullYear(issueDate.getFullYear() + 1)
  return issueDate.toISOString()
}
