/**
 * Zod validation schema for Business Owner Creation/Edit Form
 *
 * This schema validates the standalone business owner form used in:
 * - /dashboard/business-owners/new (create new owner)
 * - /dashboard/business-owners/[id]/edit (edit existing owner)
 *
 * This is separate from permitFormSchema which includes business and document fields.
 */

import { z } from "zod";

/**
 * Business Owner Form Schema
 * Validates all required fields for creating/editing a business owner
 */
export const businessOwnerFormSchema = z.object({
  // Personal Information
  firstName: z.string().min(1, "First name is required"),
  middleName: z.string().optional(),
  lastName: z.string().min(1, "Last name is required"),
  birthDate: z.string().min(1, "Birth date is required"),
  civilStatus: z.string().min(1, "Civil status is required"),
  gender: z.string().min(1, "Gender is required"),
  citizenship: z.string().min(1, "Citizenship is required"),
  tin: z.string().optional(), // Now optional

  // Contact Information
  mobile: z.string().min(1, "Mobile number is required"),
  email: z.string().min(1, "Email is required").email("Invalid email address"),

  // NEW: Hierarchical address fields
  address: z.string().optional(), // Now optional
  provinceId: z.string().min(1, "Province is required"),
  cityId: z.string().min(1, "City/Municipality is required"),
  barangayId: z.string().min(1, "Barangay is required"),

  // Optional fields
  avatar: z.string().optional(),

  // Owner Type Classification
  ownerType: z.enum(["Single", "Group"]),
  groupName: z.string().optional(),
}).superRefine((data, ctx) => {
  // Validate groupName is required for Group owners
  if (data.ownerType === "Group" && (!data.groupName || data.groupName.trim().length === 0)) {
    ctx.addIssue({
      code: "custom",
      message: "Group name is required for group owners",
      path: ["groupName"],
    })
  }
});

/**
 * Type inference from schema - use this instead of manually defining types
 */
export type BusinessOwnerFormSchema = z.infer<typeof businessOwnerFormSchema>;

/**
 * Default values for the business owner form
 */
export const businessOwnerFormDefaultValues: Partial<BusinessOwnerFormSchema> = {
  firstName: "",
  middleName: "",
  lastName: "",
  birthDate: "",
  civilStatus: "",
  gender: "",
  citizenship: "",
  tin: "", // Optional field
  mobile: "",
  email: "",
  address: "", // Optional field
  provinceId: "",
  cityId: "",
  barangayId: "",
  avatar: undefined,
  ownerType: "Single",
  groupName: "",
};
