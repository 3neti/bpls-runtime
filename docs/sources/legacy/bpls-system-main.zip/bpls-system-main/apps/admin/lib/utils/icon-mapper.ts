/**
 * Icon Mapper Utility
 *
 * Maps icon name strings (from Convex database) to Lucide icon components.
 * Used by department pages to convert Department.icon to LucideIcon components.
 *
 * Usage:
 * ```typescript
 * import { getIconComponent, iconOptions } from '@/lib/utils/icon-mapper'
 *
 * const department = useQuery(api.departments.getDepartmentBySlug, { slug: "sanitary" })
 * const Icon = getIconComponent(department.icon) // Returns Shield component
 *
 * // For Select components
 * <SelectContent>
 *   {iconOptions.map((option) => (
 *     <SelectItem key={option.value} value={option.value}>
 *       <option.icon /> {option.label}
 *     </SelectItem>
 *   ))}
 * </SelectContent>
 * ```
 */

import {
  Shield,
  Flame,
  Building2,
  TreePine,
  Wrench,
  Building,
  FileCheck,
  Briefcase,
} from "lucide-react"
import type { LucideIcon } from "lucide-react"
import type { DepartmentIcon } from "@/lib/types/department"

/**
 * Icon component registry
 * Maps icon name strings to Lucide React components
 */
const iconMap: Record<DepartmentIcon, LucideIcon> = {
  Shield,
  Flame,
  Building2,
  TreePine,
  Wrench,
  Building,
  FileCheck,
  Briefcase,
}

/**
 * Icon options for Select components
 * Provides label, value, and icon component for dropdowns
 */
export const iconOptions: Array<{
  value: DepartmentIcon
  label: string
  icon: LucideIcon
}> = [
  { value: "Shield", label: "Shield", icon: Shield },
  { value: "Flame", label: "Flame", icon: Flame },
  { value: "Building2", label: "Building", icon: Building2 },
  { value: "TreePine", label: "Tree/Pine", icon: TreePine },
  { value: "Wrench", label: "Wrench", icon: Wrench },
  { value: "Building", label: "Office Building", icon: Building },
  { value: "FileCheck", label: "File Check", icon: FileCheck },
  { value: "Briefcase", label: "Briefcase", icon: Briefcase },
]

/**
 * Get Lucide icon component from icon name string
 *
 * @param iconName - Icon name from department.icon (e.g., "Shield", "Flame")
 * @returns LucideIcon component (defaults to Shield if not found)
 *
 * @example
 * ```typescript
 * const Icon = getIconComponent("Flame") // Returns Flame component
 * <Icon className="h-6 w-6" /> // Render icon
 * ```
 */
export function getIconComponent(iconName: DepartmentIcon | string): LucideIcon {
  return iconMap[iconName as DepartmentIcon] || Shield
}
