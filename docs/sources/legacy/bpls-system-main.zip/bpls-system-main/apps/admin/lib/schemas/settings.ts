import { z } from "zod";

/**
 * Platform Settings Schema
 * Configuration for platform-wide settings (admin only)
 * These settings are stored in Convex and propagate across the platform
 */
export const platformSettingsSchema = z.object({
  platformName: z
    .string()
    .min(1, "Platform name is required")
    .max(100, "Platform name must be less than 100 characters"),
  platformTitle: z
    .string()
    .min(1, "Platform title is required")
    .max(200, "Platform title must be less than 200 characters"),
  tagline: z
    .string()
    .max(500, "Tagline must be less than 500 characters"),
  currencyFormat: z.enum(["PHP", "USD"]),
  fiscalYearStart: z.enum(["january", "april", "july", "october"]),
  // Permit Settings
  permitExpiryMode: z.enum(["one_year", "end_of_year"]).optional(),
  // Permit Number Format
  permitNumberFormat: z.string().max(100, "Format must be less than 100 characters").optional(),
});

/**
 * Municipality Settings Schema
 * Configuration for municipality-specific information
 */
export const municipalitySettingsSchema = z.object({
  municipalityName: z
    .string()
    .min(1, "Municipality name is required")
    .max(200, "Municipality name must be less than 200 characters"),
  municipalityShortName: z
    .string()
    .min(1, "Short name is required")
    .max(100, "Short name must be less than 100 characters"),
  provinceName: z
    .string()
    .min(1, "Province name is required")
    .max(200, "Province name must be less than 200 characters"),
  fullAddress: z
    .string()
    .min(1, "Full address is required")
    .max(500, "Full address must be less than 500 characters"),
});

/**
 * Government Officials Schema
 * Configuration for government official names and titles
 */
export const officialsSettingsSchema = z.object({
  mayorName: z
    .string()
    .min(1, "Mayor name is required")
    .max(200, "Mayor name must be less than 200 characters"),
  mayorTitle: z
    .string()
    .min(1, "Mayor title is required")
    .max(100, "Mayor title must be less than 100 characters"),
  treasurerName: z
    .string()
    .min(1, "Treasurer name is required")
    .max(200, "Treasurer name must be less than 200 characters"),
  treasurerTitle: z
    .string()
    .min(1, "Treasurer title is required")
    .max(100, "Treasurer title must be less than 100 characters"),
});

/**
 * Location Defaults Schema
 * Optional default location values for new resources
 * When set, forms will pre-populate with these location values
 */
export const locationDefaultsSchema = z.object({
  defaultProvinceId: z.string().optional(),
  defaultCityId: z.string().optional(),
  defaultBarangayId: z.string().optional(),
});

export type PlatformSettingsSchema = z.infer<typeof platformSettingsSchema>;
export type MunicipalitySettingsSchema = z.infer<typeof municipalitySettingsSchema>;
export type OfficialsSettingsSchema = z.infer<typeof officialsSettingsSchema>;
export type LocationDefaultsSchema = z.infer<typeof locationDefaultsSchema>;

/**
 * Default Values for Platform Settings
 */
export const platformSettingsDefaultValues: PlatformSettingsSchema = {
  platformName: "BPLS Portal",
  platformTitle: "Business Permit & Licensing System",
  tagline: "Streamlining business permit applications for local government",
  currencyFormat: "PHP",
  fiscalYearStart: "january",
  permitExpiryMode: "end_of_year",
  permitNumberFormat: "BP-{{YEAR}}-{{SEQUENCE}}",
};

/**
 * Default Values for Municipality Settings
 * Note: These are intentionally empty - must be configured during onboarding
 * The empty values are for form initialization only, not runtime defaults
 */
export const municipalitySettingsDefaultValues = {
  municipalityName: "",
  municipalityShortName: "",
  provinceName: "",
  fullAddress: "",
};

/**
 * Default Values for Officials Settings
 * Note: Names are empty - must be configured during onboarding
 * Titles have generic defaults
 */
export const officialsSettingsDefaultValues = {
  mayorName: "",
  mayorTitle: "Municipal Mayor",
  treasurerName: "",
  treasurerTitle: "Municipal Treasurer",
};
