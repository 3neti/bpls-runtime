/**
 * Consolidated Formatting Utilities
 *
 * This module contains all formatting utilities used across the application.
 * Previously scattered across multiple files, now consolidated for maintainability.
 */

import { format as dateFnsFormat } from "date-fns"

/**
 * Format options for currency formatting
 */
export interface FormatCurrencyOptions {
  /** Whether to include PHP currency symbol (default: false) */
  withSymbol?: boolean
  /** Whether to format for CSV export (plain number, no commas) */
  forCSV?: boolean
  /** Locale for formatting (default: "en-PH") */
  locale?: string
}

/**
 * Format a number or string as currency
 *
 * @param value - The value to format (string or number)
 * @param options - Formatting options
 * @returns Formatted currency string
 *
 * @example
 * ```ts
 * formatCurrency(1234.56) // "1,234.56"
 * formatCurrency(1234.56, { withSymbol: true }) // "₱1,234.56"
 * formatCurrency(1234.56, { forCSV: true }) // "1234.56"
 * ```
 */
export function formatCurrency(
  value: string | number | null | undefined,
  options: FormatCurrencyOptions = {}
): string {
  const { withSymbol = false, forCSV = false, locale = "en-PH" } = options

  // Handle empty/null/undefined
  if (value === "" || value === null || value === undefined) return ""

  // Convert to number and handle invalid inputs
  const numValue =
    typeof value === "string"
      ? Number.parseFloat(value.replace(/,/g, ""))
      : value

  if (isNaN(numValue)) return ""

  // CSV format: plain number with 2 decimal places
  if (forCSV) {
    return numValue.toFixed(2)
  }

  // With PHP currency symbol
  if (withSymbol) {
    return new Intl.NumberFormat(locale, {
      style: "currency",
      currency: "PHP",
    }).format(numValue)
  }

  // Default: formatted number with commas, 2 decimal places
  return new Intl.NumberFormat(locale, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(numValue)
}

/**
 * Alias for formatCurrency with currency symbol
 * @deprecated Use formatCurrency(value, { withSymbol: true }) instead
 */
export const formatCurrencyWithSymbol = (value: number): string =>
  formatCurrency(value, { withSymbol: true })

/**
 * Format currency for CSV export (plain number, 2 decimal places)
 */
export const formatCurrencyForCSV = (
  value: number | string | null | undefined
): string => formatCurrency(value, { forCSV: true })

/**
 * Parse a formatted currency string back to raw number string
 */
export function parseCurrency(formattedValue: string): string {
  if (!formattedValue) return ""
  // Remove commas, currency symbols, and whitespace
  return formattedValue.replace(/[₱,\s]/g, "")
}

/**
 * Format options for date formatting
 */
export type DateFormatType = "display" | "iso" | "csv" | "full" | "short"

/**
 * Format a date value
 *
 * @param value - Date string, Date object, or timestamp
 * @param format - Output format type
 * @returns Formatted date string
 *
 * @example
 * ```ts
 * formatDate("2025-01-15") // "January 15, 2025"
 * formatDate("2025-01-15", "csv") // "2025-01-15"
 * formatDate("2025-01-15", "short") // "Jan 15, 2025"
 * ```
 */
export function formatDate(
  value: string | Date | number | null | undefined,
  format: DateFormatType = "display"
): string {
  if (!value) return ""

  try {
    const date = value instanceof Date ? value : new Date(value)
    if (isNaN(date.getTime())) return ""

    switch (format) {
      case "iso":
        return date.toISOString()
      case "csv":
        return dateFnsFormat(date, "yyyy-MM-dd")
      case "full":
        return dateFnsFormat(date, "MMMM d, yyyy 'at' h:mm a")
      case "short":
        return dateFnsFormat(date, "MMM d, yyyy")
      case "display":
      default:
        return new Date(value).toLocaleDateString("en-US", {
          year: "numeric",
          month: "long",
          day: "numeric",
        })
    }
  } catch {
    return ""
  }
}

/**
 * Format date for CSV export (YYYY-MM-DD format)
 */
export const formatDateForCSV = (
  value: string | Date | number | null | undefined
): string => formatDate(value, "csv")

/**
 * Get initials from a full name or first/last name
 *
 * @param nameOrFirstName - Full name string, or first name if lastName is provided
 * @param lastName - Optional last name
 * @returns Uppercase initials
 *
 * @example
 * ```ts
 * getInitials("John Doe") // "JD"
 * getInitials("John", "Doe") // "JD"
 * getInitials("John Michael Doe") // "JMD"
 * ```
 */
export function getInitials(nameOrFirstName: string, lastName?: string): string {
  if (!nameOrFirstName) return ""

  // If lastName is provided, combine first and last name
  if (lastName) {
    const first = nameOrFirstName.trim()[0] || ""
    const last = lastName.trim()[0] || ""
    return (first + last).toUpperCase()
  }

  // Otherwise, split full name and get initials
  return nameOrFirstName
    .split(" ")
    .filter((part) => part.length > 0)
    .map((n) => n[0])
    .join("")
    .toUpperCase()
}
