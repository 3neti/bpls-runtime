/**
 * Report Resource Configurations
 *
 * Defines dimensions and metrics for each resource type in the report builder.
 * Each resource has dimension groups (for tree-view selection) and metric groups.
 */

import type {
  ResourceConfig,
  ResourceMeta,
  DimensionGroup,
  MetricGroup,
  ResourceType,
} from "@/lib/types/report-builder"

// ===========================================
// RESOURCE METADATA
// ===========================================

export const RESOURCE_META: Record<ResourceType, ResourceMeta> = {
  permit_applications: {
    type: "permit_applications",
    name: "Permit Applications",
    description: "Business permit applications with owner, business, payments, and clearance data",
    icon: "FileText",
  },
  billing_groups: {
    type: "billing_groups",
    name: "Billing Groups",
    description: "Custom billing group transactions with line items",
    icon: "Receipt",
  },
  payments: {
    type: "payments",
    name: "Payments",
    description: "Payment records for permit applications",
    icon: "CreditCard",
  },
  permits: {
    type: "permits",
    name: "Permits",
    description: "Issued Mayor's Permits",
    icon: "BadgeCheck",
  },
  businesses: {
    type: "businesses",
    name: "Businesses",
    description: "Registered businesses",
    icon: "Building2",
  },
  business_owners: {
    type: "business_owners",
    name: "Business Owners",
    description: "Business owner profiles",
    icon: "Users",
  },
  manual_transactions: {
    type: "manual_transactions",
    name: "Manual Transactions",
    description: "Manual debit/credit transactions",
    icon: "FileEdit",
  },
}

// ===========================================
// PERMIT APPLICATIONS CONFIGURATION
// ===========================================

const PERMIT_APPLICATION_DIMENSION_GROUPS: DimensionGroup[] = [
  {
    id: "application_details",
    name: "Application Details",
    defaultExpanded: true,
    dimensions: [
      { id: "applicationNumber", name: "Application Details - BPA #", type: "text", filterable: true, source: "business_permit_applications", autoSelect: true, sortOrder: 1 },
      { id: "status", name: "Application Details - Application Status", type: "categorical", filterable: true, source: "business_permit_applications", sortOrder: 2, options: ["Draft", "Assessment", "Approval", "Pending Payment", "Released"] },
      { id: "permitApplicationType", name: "Application Details - Application Type", type: "categorical", filterable: true, source: "business_permit_applications", sortOrder: 3, options: ["New", "Renewal", "Additional"] },
      { id: "modeOfPayment", name: "Application Details - Mode of Payment", type: "categorical", filterable: true, source: "business_permit_applications", sortOrder: 4, options: ["Annually", "Semi-Annually", "Quarterly"] },
      { id: "submittedAt", name: "Application Details - Date Submitted", type: "date", filterable: true, source: "business_permit_applications", sortOrder: 5 },
      { id: "assessedAt", name: "Application Details - Date Assessed", type: "date", filterable: true, source: "business_permit_applications", sortOrder: 6 },
      { id: "releasedAt", name: "Application Details - Date Released", type: "date", filterable: true, source: "business_permit_applications", sortOrder: 7 },
      { id: "rejectedAt", name: "Application Details - Date Rejected", type: "date", filterable: true, source: "business_permit_applications", sortOrder: 8 },
      { id: "assessmentRemarks", name: "Application Details - Assessment Remarks", type: "text", filterable: false, source: "business_permit_applications", sortOrder: 9 },
      { id: "rejectionReason", name: "Application Details - Rejection Reason", type: "text", filterable: false, source: "business_permit_applications", sortOrder: 10 },
      { id: "totalFees", name: "Application Details - Total Assessed Fees", type: "numeric", filterable: true, source: "business_permit_applications", sortOrder: 11 },
    ],
  },
  {
    id: "owner_info",
    name: "Business Owner Information",
    dimensions: [
      { id: "ownerFullName", name: "Business Owner Information - Owner Full Name", type: "text", filterable: true, source: "business_owners", path: "owner", autoSelect: true, sortOrder: 1 },
      { id: "ownerFirstName", name: "Business Owner Information - First Name", type: "text", filterable: true, source: "business_owners", path: "owner.firstName", sortOrder: 2 },
      { id: "ownerLastName", name: "Business Owner Information - Last Name", type: "text", filterable: true, source: "business_owners", path: "owner.lastName", sortOrder: 3 },
      { id: "ownerMiddleName", name: "Business Owner Information - Middle Name", type: "text", filterable: false, source: "business_owners", path: "owner.middleName", sortOrder: 4 },
      { id: "ownerEmail", name: "Business Owner Information - Email", type: "text", filterable: true, source: "business_owners", path: "owner.email", sortOrder: 5 },
      { id: "ownerMobile", name: "Business Owner Information - Mobile", type: "text", filterable: true, source: "business_owners", path: "owner.mobile", sortOrder: 6 },
      { id: "ownerTIN", name: "Business Owner Information - TIN", type: "text", filterable: true, source: "business_owners", path: "owner.tin", sortOrder: 7 },
      { id: "ownerCitizenship", name: "Business Owner Information - Citizenship", type: "categorical", filterable: true, source: "business_owners", path: "owner.citizenship", sortOrder: 8 },
      { id: "ownerCivilStatus", name: "Business Owner Information - Civil Status", type: "categorical", filterable: true, source: "business_owners", path: "owner.civilStatus", sortOrder: 9 },
      { id: "ownerGender", name: "Business Owner Information - Gender", type: "categorical", filterable: true, source: "business_owners", path: "owner.gender", sortOrder: 10, options: ["Male", "Female"] },
      { id: "ownerBirthDate", name: "Business Owner Information - Birth Date", type: "date", filterable: true, source: "business_owners", path: "owner.birthDate", sortOrder: 11 },
      { id: "ownerAddress", name: "Business Owner Information - Owner Address", type: "text", filterable: false, source: "business_owners", path: "owner.address", sortOrder: 12 },
      { id: "ownerProvince", name: "Business Owner Information - Owner Province", type: "text", filterable: true, source: "provinces", path: "owner.province", sortOrder: 13 },
      { id: "ownerCity", name: "Business Owner Information - Owner City", type: "text", filterable: true, source: "cities", path: "owner.city", sortOrder: 14 },
      { id: "ownerBarangay", name: "Business Owner Information - Owner Barangay", type: "text", filterable: true, source: "barangays", path: "owner.barangay", sortOrder: 15 },
      { id: "ownerType", name: "Business Owner Information - Owner Type", type: "categorical", filterable: true, source: "business_owners", path: "owner.ownerType", sortOrder: 16, options: ["Single", "Group"] },
      { id: "isBlacklisted", name: "Business Owner Information - Blacklist Status", type: "boolean", filterable: true, source: "business_owners", path: "owner.isBlacklisted", sortOrder: 17 },
      { id: "blacklistReason", name: "Business Owner Information - Blacklist Reason", type: "text", filterable: false, source: "business_owners", path: "owner.blacklistReason", sortOrder: 18 },
    ],
  },
  {
    id: "business_info",
    name: "Business Information",
    dimensions: [
      { id: "businessName", name: "Business Information - Business Name", type: "text", filterable: true, source: "businesses", path: "business", autoSelect: true, sortOrder: 1 },
      { id: "businessTradeName", name: "Business Information - Trade Name", type: "text", filterable: true, source: "businesses", path: "business.tradeName", sortOrder: 2 },
      { id: "businessScale", name: "Business Information - Business Scale", type: "categorical", filterable: true, source: "businesses", path: "business.businessScale", sortOrder: 3, options: ["Micro", "Small", "Medium", "Large"] },
      { id: "businessOwnershipType", name: "Business Information - Ownership Type", type: "categorical", filterable: true, source: "businesses", path: "business.ownershipType", sortOrder: 4, options: ["Sole Proprietorship", "Partnership", "Corporation", "Cooperative"] },
      { id: "annualRevenue", name: "Business Information - Annual Revenue", type: "numeric", filterable: true, source: "businesses", path: "business.annualRevenue", sortOrder: 5 },
      { id: "numberOfEmployees", name: "Business Information - Total Employees", type: "numeric", filterable: true, source: "businesses", path: "business.numberOfEmployees", sortOrder: 6 },
      { id: "maleEmployeeCount", name: "Business Information - Male Employees", type: "numeric", filterable: false, source: "businesses", path: "business.maleEmployeeCount", sortOrder: 7 },
      { id: "femaleEmployeeCount", name: "Business Information - Female Employees", type: "numeric", filterable: false, source: "businesses", path: "business.femaleEmployeeCount", sortOrder: 8 },
      { id: "businessArea", name: "Business Information - Business Area (sqm)", type: "numeric", filterable: true, source: "businesses", path: "business.businessArea", sortOrder: 9 },
      { id: "businessAddress", name: "Business Information - Business Address", type: "text", filterable: false, source: "businesses", path: "business.address", sortOrder: 10 },
      { id: "businessBuildingName", name: "Business Information - Building Name", type: "text", filterable: false, source: "businesses", path: "business.buildingName", sortOrder: 11 },
      { id: "businessProvince", name: "Business Information - Business Province", type: "text", filterable: true, source: "provinces", path: "business.province", sortOrder: 12 },
      { id: "businessCity", name: "Business Information - Business City", type: "text", filterable: true, source: "cities", path: "business.city", sortOrder: 13 },
      { id: "businessBarangay", name: "Business Information - Business Barangay", type: "text", filterable: true, source: "barangays", path: "business.barangay", sortOrder: 14 },
      { id: "registrationNumber", name: "Business Information - DTI/SEC/CDA #", type: "text", filterable: true, source: "businesses", path: "business.registrationNumber", sortOrder: 15 },
      { id: "propertyIndexNumber", name: "Business Information - Property Index #", type: "text", filterable: false, source: "businesses", path: "business.propertyIndexNumber", sortOrder: 16 },
      { id: "businessContactNumber", name: "Business Information - Contact Number", type: "text", filterable: false, source: "businesses", path: "business.contactNumber", sortOrder: 17 },
      { id: "businessEmail", name: "Business Information - Business Email", type: "text", filterable: true, source: "businesses", path: "business.email", sortOrder: 18 },
      { id: "dateStarted", name: "Business Information - Date Started", type: "date", filterable: true, source: "businesses", path: "business.dateStarted", sortOrder: 19 },
      { id: "establishedDate", name: "Business Information - Established Date", type: "date", filterable: true, source: "businesses", path: "business.establishedDate", sortOrder: 20 },
      { id: "occupancy", name: "Business Information - Occupancy Type", type: "categorical", filterable: true, source: "businesses", path: "business.occupancy", sortOrder: 21 },
      { id: "permitPaymentCadence", name: "Business Information - Payment Cadence", type: "categorical", filterable: true, source: "businesses", path: "business.permitPaymentCadence", sortOrder: 22 },
    ],
  },
  {
    id: "lob_info",
    name: "Lines of Business",
    dimensions: [
      { id: "lobMajor", name: "Lines of Business - Major Category", type: "text", filterable: true, source: "majors", path: "lob.major", sortOrder: 1 },
      { id: "lobDivision", name: "Lines of Business - Division", type: "text", filterable: true, source: "divisions", path: "lob.division", sortOrder: 2 },
      { id: "lobGroup", name: "Lines of Business - Line of Business", type: "text", filterable: true, source: "groups", path: "lob.group", sortOrder: 3 },
      { id: "lobPermitType", name: "Lines of Business - LOB Permit Type", type: "categorical", filterable: true, source: "business_permit_applications", path: "lob.permitApplicationType", sortOrder: 4, options: ["New", "Renewal"] },
      { id: "lobCapitalInvestment", name: "Lines of Business - Capital", type: "numeric", filterable: false, source: "business_permit_applications", path: "lob.capitalInvestment", sortOrder: 5 },
      { id: "lobGrossSales", name: "Lines of Business - Gross Sales", type: "numeric", filterable: false, source: "business_permit_applications", path: "lob.grossSales", sortOrder: 6 },
      { id: "lobEmployees", name: "Lines of Business - Employees", type: "numeric", filterable: false, source: "business_permit_applications", path: "lob.numberOfEmployees", sortOrder: 7 },
      { id: "lobFeeName", name: "Lines of Business - Fee Name", type: "text", filterable: true, source: "fees", path: "lobFee.name", sortOrder: 8 },
      { id: "lobFeeCategory", name: "Lines of Business - Fee Category", type: "categorical", filterable: true, source: "fees", path: "lobFee.feeCategory", sortOrder: 9, options: ["Tax", "Regulatory Fee", "Other Charges", "Special Fee"] },
      { id: "lobFeeAmount", name: "Lines of Business - Calculated Amount", type: "numeric", filterable: true, source: "computed", path: "lobFee.amount", sortOrder: 10 },
    ],
  },
  {
    id: "fee_details",
    name: "Schedule of Fees - Fee Details",
    dimensions: [
      { id: "feeName", name: "Schedule of Fees - Fee Name", type: "text", filterable: true, source: "payment_schedules", path: "fee.feeName", sortOrder: 1 },
      { id: "feeCategory", name: "Schedule of Fees - Fee Category", type: "categorical", filterable: true, source: "payment_schedules", path: "fee.feeCategory", sortOrder: 2, options: ["Tax", "Regulatory Fee", "Other Charges", "Special Fee"] },
      { id: "feeOriginalAmount", name: "Schedule of Fees - Fee Amount", type: "numeric", filterable: true, source: "payment_schedules", path: "fee.originalAmount", sortOrder: 3 },
      { id: "feeSectionAmount", name: "Schedule of Fees - Section Amount", type: "numeric", filterable: true, source: "payment_schedules", path: "fee.sectionAmount", sortOrder: 4 },
    ],
  },
  {
    id: "payment_info",
    name: "Payment Information",
    dimensions: [
      { id: "orNumber", name: "Payment Information - OR Number", type: "text", filterable: true, source: "payments", path: "payment.receiptNumber", sortOrder: 1 },
      { id: "transactionNumber", name: "Payment Information - Transaction #", type: "text", filterable: true, source: "payments", path: "payment.transactionNumber", sortOrder: 2 },
      { id: "paymentAmount", name: "Payment Information - Payment Amount", type: "numeric", filterable: true, source: "payments", path: "payment.amount", sortOrder: 3 },
      { id: "paymentMethod", name: "Payment Information - Payment Method", type: "categorical", filterable: true, source: "payments", path: "payment.paymentMethod", sortOrder: 4, options: ["Cash", "Credit Card", "Bank Transfer", "GCash", "PayMaya", "Check"] },
      { id: "paymentStatus", name: "Payment Information - Payment Status", type: "categorical", filterable: true, source: "payments", path: "payment.status", sortOrder: 5, options: ["pending", "completed", "failed", "cancelled"] },
      { id: "paymentReference", name: "Payment Information - Reference Number", type: "text", filterable: true, source: "payments", path: "payment.referenceNumber", sortOrder: 6 },
      { id: "datePaid", name: "Payment Information - Date Paid", type: "date", filterable: true, source: "payments", path: "payment.paidAt", sortOrder: 7 },
      { id: "processedBy", name: "Payment Information - Processed By", type: "text", filterable: true, source: "users", path: "payment.processedBy", sortOrder: 8 },
    ],
  },
  {
    id: "schedule_info",
    name: "Payment Schedules",
    dimensions: [
      { id: "scheduleSection", name: "Payment Schedules - Section #", type: "numeric", filterable: false, source: "payment_schedules", path: "schedule.sectionNumber", sortOrder: 1 },
      { id: "scheduleDueDate", name: "Payment Schedules - Due Date", type: "date", filterable: true, source: "payment_schedules", path: "schedule.dueDate", sortOrder: 2 },
      { id: "scheduleStatus", name: "Payment Schedules - Schedule Status", type: "categorical", filterable: true, source: "payment_schedules", path: "schedule.status", sortOrder: 3, options: ["pending", "partial", "paid"] },
      { id: "scheduleSurcharge", name: "Payment Schedules - Surcharge", type: "numeric", filterable: false, source: "payment_schedules", path: "schedule.surcharge", sortOrder: 4 },
      { id: "schedulePenalty", name: "Payment Schedules - Penalty", type: "numeric", filterable: false, source: "payment_schedules", path: "schedule.penalty", sortOrder: 5 },
      { id: "scheduleTotalAmount", name: "Payment Schedules - Section Total", type: "numeric", filterable: false, source: "payment_schedules", path: "schedule.totalAmount", sortOrder: 6 },
      { id: "schedulePaidAmount", name: "Payment Schedules - Section Paid", type: "numeric", filterable: false, source: "payment_schedules", path: "schedule.paidAmount", sortOrder: 7 },
    ],
  },
  {
    id: "clearance_info",
    name: "Clearances",
    dimensions: [
      { id: "clearanceName", name: "Clearances - Clearance Name", type: "text", filterable: true, source: "permit_clearances", path: "clearance.clearanceName", sortOrder: 1 },
      { id: "clearanceStatus", name: "Clearances - Clearance Status", type: "boolean", filterable: true, source: "permit_clearances", path: "clearance.isCompleted", sortOrder: 2 },
      { id: "clearanceCompletedAt", name: "Clearances - Completed Date", type: "date", filterable: true, source: "permit_clearances", path: "clearance.completedAt", sortOrder: 3 },
      { id: "clearanceCompletedBy", name: "Clearances - Completed By", type: "text", filterable: false, source: "users", path: "clearance.completedBy", sortOrder: 4 },
    ],
  },
]

const PERMIT_APPLICATION_METRIC_GROUPS: MetricGroup[] = [
  {
    id: "financial",
    name: "Financial",
    metrics: [
      { id: "totalFees", name: "Total Assessed Fees", aggregation: "sum", format: "currency", field: "totalFees", description: "Sum of all assessed fees" },
      { id: "totalPaidAmount", name: "Total Paid Amount", aggregation: "sum", format: "currency", field: "paidAmount", description: "Sum of all completed payments" },
      { id: "totalSurcharge", name: "Total Surcharge", aggregation: "sum", format: "currency", field: "surcharge", description: "Sum of all surcharges" },
      { id: "totalPenalty", name: "Total Penalty", aggregation: "sum", format: "currency", field: "penalty", description: "Sum of all penalties" },
      { id: "outstandingBalance", name: "Outstanding Balance", aggregation: "sum", format: "currency", field: "outstanding", description: "Total fees minus paid amount" },
    ],
  },
  {
    id: "counts",
    name: "Counts",
    metrics: [
      { id: "applicationCount", name: "Application Count", aggregation: "count", format: "number", description: "Total number of applications" },
      { id: "newApplicationCount", name: "New Applications", aggregation: "count", format: "number", filter: { dimensionId: "permitApplicationType", operator: "equals", value: "New" }, description: "Applications with type = New" },
      { id: "renewalCount", name: "Renewals", aggregation: "count", format: "number", filter: { dimensionId: "permitApplicationType", operator: "equals", value: "Renewal" }, description: "Applications with type = Renewal" },
      { id: "completedClearances", name: "Completed Clearances", aggregation: "count", format: "number", filter: { dimensionId: "clearanceStatus", operator: "equals", value: true }, description: "Clearances marked complete" },
      { id: "pendingClearances", name: "Pending Clearances", aggregation: "count", format: "number", filter: { dimensionId: "clearanceStatus", operator: "equals", value: false }, description: "Clearances not yet complete" },
    ],
  },
  {
    id: "averages",
    name: "Averages",
    metrics: [
      { id: "avgProcessingDays", name: "Avg Processing Time", aggregation: "average", format: "number", field: "processingDays", description: "Average days from submit to release" },
      { id: "avgCapitalInvestment", name: "Avg Capital Investment", aggregation: "average", format: "currency", field: "capitalInvestment", description: "Average capital investment" },
      { id: "avgGrossSales", name: "Avg Gross Sales", aggregation: "average", format: "currency", field: "grossSales", description: "Average gross sales" },
      { id: "clearanceProgress", name: "Clearance Progress %", aggregation: "average", format: "percentage", field: "clearanceProgress", description: "Percentage of clearances complete" },
    ],
  },
  {
    id: "employment",
    name: "Employment",
    metrics: [
      { id: "totalEmployees", name: "Total Employees", aggregation: "sum", format: "number", field: "numberOfEmployees", description: "Sum of all employees" },
    ],
  },
]

// ===========================================
// BILLING GROUPS CONFIGURATION
// ===========================================

const BILLING_GROUP_DIMENSION_GROUPS: DimensionGroup[] = [
  {
    id: "transaction_details",
    name: "Transaction Details",
    defaultExpanded: true,
    dimensions: [
      { id: "billingTransactionNumber", name: "Transaction #", type: "text", filterable: true, source: "billing_group_records", autoSelect: true, sortOrder: 1 },
      { id: "billingGroupName", name: "Billing Group", type: "categorical", filterable: true, source: "billing_groups", sortOrder: 2 },
      { id: "billingDescription", name: "Description", type: "text", filterable: true, source: "billing_group_records", sortOrder: 3 },
      { id: "billingDate", name: "Transaction Date", type: "date", filterable: true, source: "billing_group_records", sortOrder: 4 },
      { id: "payorName", name: "Payor Name", type: "text", filterable: true, source: "billing_group_records", sortOrder: 5 },
      { id: "billingPaymentMethod", name: "Payment Method", type: "categorical", filterable: true, source: "billing_group_records", sortOrder: 6, options: ["Cash", "Credit Card", "Bank Transfer", "GCash", "PayMaya", "Check"] },
      { id: "billingReferenceNumber", name: "Reference Number", type: "text", filterable: true, source: "billing_group_records", sortOrder: 7 },
      { id: "billingStatus", name: "Transaction Status", type: "categorical", filterable: true, source: "billing_group_records", sortOrder: 8, options: ["pending", "completed", "cancelled"] },
      { id: "billingAmount", name: "Amount", type: "numeric", filterable: true, source: "billing_group_records", sortOrder: 9 },
      { id: "billingCreatedAt", name: "Created Date", type: "date", filterable: true, source: "billing_group_records", sortOrder: 10 },
    ],
  },
  {
    id: "line_items",
    name: "Line Items",
    dimensions: [
      { id: "lineItemFeeName", name: "Fee Name", type: "text", filterable: true, source: "billing_group_fees", path: "lineItem.fee.name", sortOrder: 1 },
      { id: "lineItemFeeCode", name: "Fee Code", type: "text", filterable: true, source: "billing_group_fees", path: "lineItem.fee.code", sortOrder: 2 },
      { id: "lineItemAmount", name: "Amount", type: "numeric", filterable: false, source: "billing_group_line_items", path: "lineItem.amount", sortOrder: 3 },
      { id: "lineItemQuantity", name: "Quantity", type: "numeric", filterable: false, source: "billing_group_line_items", path: "lineItem.quantity", sortOrder: 4 },
      { id: "lineItemTotal", name: "Line Total", type: "numeric", filterable: false, source: "computed", path: "lineItem.total", sortOrder: 5 },
    ],
  },
  {
    id: "system_columns",
    name: "System Columns",
    dimensions: [
      { id: "billingCreatedBy", name: "Created By", type: "text", filterable: true, source: "users", path: "record.createdBy", sortOrder: 1 },
      { id: "billingUpdatedAt", name: "Last Updated", type: "date", filterable: false, source: "billing_group_records", path: "record.updatedAt", sortOrder: 2 },
    ],
  },
]

const BILLING_GROUP_METRIC_GROUPS: MetricGroup[] = [
  {
    id: "financial",
    name: "Financial",
    metrics: [
      { id: "billingTotalAmount", name: "Total Amount", aggregation: "sum", format: "currency", field: "amount", description: "Sum of all transaction amounts" },
      { id: "billingAverageAmount", name: "Average Amount", aggregation: "average", format: "currency", field: "amount", description: "Average transaction amount" },
      { id: "billingMinAmount", name: "Min Amount", aggregation: "min", format: "currency", field: "amount", description: "Smallest transaction" },
      { id: "billingMaxAmount", name: "Max Amount", aggregation: "max", format: "currency", field: "amount", description: "Largest transaction" },
    ],
  },
  {
    id: "by_method",
    name: "By Payment Method",
    metrics: [
      { id: "cashAmount", name: "Cash Amount", aggregation: "sum", format: "currency", field: "amount", filter: { dimensionId: "billingPaymentMethod", operator: "equals", value: "Cash" } },
      { id: "checkAmount", name: "Check Amount", aggregation: "sum", format: "currency", field: "amount", filter: { dimensionId: "billingPaymentMethod", operator: "equals", value: "Check" } },
      { id: "bankTransferAmount", name: "Bank Transfer Amount", aggregation: "sum", format: "currency", field: "amount", filter: { dimensionId: "billingPaymentMethod", operator: "equals", value: "Bank Transfer" } },
      { id: "gcashAmount", name: "GCash Amount", aggregation: "sum", format: "currency", field: "amount", filter: { dimensionId: "billingPaymentMethod", operator: "equals", value: "GCash" } },
    ],
  },
  {
    id: "counts",
    name: "Counts",
    metrics: [
      { id: "billingTransactionCount", name: "Transaction Count", aggregation: "count", format: "number", description: "Total transactions" },
      { id: "billingCompletedCount", name: "Completed Count", aggregation: "count", format: "number", filter: { dimensionId: "billingStatus", operator: "equals", value: "completed" } },
      { id: "billingPendingCount", name: "Pending Count", aggregation: "count", format: "number", filter: { dimensionId: "billingStatus", operator: "equals", value: "pending" } },
      { id: "billingCancelledCount", name: "Cancelled Count", aggregation: "count", format: "number", filter: { dimensionId: "billingStatus", operator: "equals", value: "cancelled" } },
      { id: "lineItemCount", name: "Total Line Items", aggregation: "sum", format: "number", field: "lineItemCount", description: "Sum of all line items" },
      { id: "distinctPayors", name: "Unique Payors", aggregation: "countDistinct", format: "number", field: "payorName", description: "Unique payor names" },
    ],
  },
]

// ===========================================
// PAYMENTS CONFIGURATION
// ===========================================

const PAYMENTS_DIMENSION_GROUPS: DimensionGroup[] = [
  {
    id: "payment_details",
    name: "Payment Details",
    defaultExpanded: true,
    dimensions: [
      { id: "paymentTransactionNumber", name: "Transaction #", type: "text", filterable: true, source: "payments", autoSelect: true, sortOrder: 1 },
      { id: "receiptNumber", name: "OR Number", type: "text", filterable: true, source: "payments", sortOrder: 2 },
      { id: "amount", name: "Amount", type: "numeric", filterable: true, source: "payments", sortOrder: 3 },
      { id: "method", name: "Payment Method", type: "categorical", filterable: true, source: "payments", sortOrder: 4, options: ["Cash", "Credit Card", "Bank Transfer", "GCash", "PayMaya", "Check"] },
      { id: "status", name: "Payment Status", type: "categorical", filterable: true, source: "payments", sortOrder: 5, options: ["pending", "completed", "failed", "cancelled"] },
      { id: "referenceNumber", name: "Reference Number", type: "text", filterable: true, source: "payments", sortOrder: 6 },
      { id: "paidAt", name: "Date Paid", type: "date", filterable: true, source: "payments", sortOrder: 7 },
      { id: "paymentProcessedBy", name: "Processed By", type: "text", filterable: true, source: "users", path: "payment.processedBy", sortOrder: 8 },
    ],
  },
  {
    id: "related_info",
    name: "Related Information",
    dimensions: [
      { id: "applicationNumber", name: "Application #", type: "text", filterable: true, source: "business_permit_applications", path: "application.applicationNumber", sortOrder: 1 },
      { id: "businessName", name: "Business Name", type: "text", filterable: true, source: "businesses", path: "business.name", sortOrder: 2 },
      { id: "ownerName", name: "Owner Name", type: "text", filterable: true, source: "business_owners", path: "owner.name", sortOrder: 3 },
      { id: "scheduleSection", name: "Schedule Section", type: "numeric", filterable: false, source: "payment_schedules", path: "schedule.sectionNumber", sortOrder: 4 },
    ],
  },
]

const PAYMENTS_METRIC_GROUPS: MetricGroup[] = [
  {
    id: "financial",
    name: "Financial",
    metrics: [
      { id: "paymentCount", name: "Payment Count", aggregation: "count", format: "number", description: "Total payments" },
      { id: "paymentTotalAmount", name: "Total Amount", aggregation: "sum", format: "currency", field: "amount", description: "Sum of all payments" },
      { id: "paymentAverageAmount", name: "Average Payment", aggregation: "average", format: "currency", field: "amount", description: "Average payment amount" },
    ],
  },
  {
    id: "by_method",
    name: "By Method",
    metrics: [
      { id: "cashPayments", name: "Cash Payments", aggregation: "sum", format: "currency", field: "amount", filter: { dimensionId: "method", operator: "equals", value: "Cash" } },
      { id: "cardPayments", name: "Card Payments", aggregation: "sum", format: "currency", field: "amount", filter: { dimensionId: "method", operator: "equals", value: "Credit Card" } },
      { id: "onlinePayments", name: "Online Payments", aggregation: "sum", format: "currency", field: "amount", filter: { dimensionId: "method", operator: "in", value: ["GCash", "PayMaya", "Bank Transfer"] } },
    ],
  },
  {
    id: "by_status",
    name: "By Status",
    metrics: [
      { id: "completedPayments", name: "Completed Count", aggregation: "count", format: "number", filter: { dimensionId: "status", operator: "equals", value: "completed" } },
      { id: "voidedPayments", name: "Voided Count", aggregation: "count", format: "number", filter: { dimensionId: "status", operator: "equals", value: "cancelled" } },
    ],
  },
]

// ===========================================
// PERMITS CONFIGURATION
// ===========================================

const PERMITS_DIMENSION_GROUPS: DimensionGroup[] = [
  {
    id: "permit_details",
    name: "Permit Details",
    defaultExpanded: true,
    dimensions: [
      { id: "permitNumber", name: "Permit #", type: "text", filterable: true, source: "permits", autoSelect: true, sortOrder: 1 },
      { id: "permitStatus", name: "Permit Status", type: "categorical", filterable: true, source: "permits", sortOrder: 2, options: ["Active", "Expired", "Pending", "Rejected"] },
      { id: "dateReleased", name: "Date Released", type: "date", filterable: true, source: "permits", sortOrder: 3 },
      { id: "expiryDate", name: "Expiry Date", type: "date", filterable: true, source: "permits", sortOrder: 4 },
      { id: "issuedBy", name: "Issued By", type: "text", filterable: true, source: "users", path: "permit.issuedBy", sortOrder: 5 },
      { id: "issuedAt", name: "Issued At", type: "date", filterable: true, source: "permits", sortOrder: 6 },
    ],
  },
  {
    id: "related_info",
    name: "Related Information",
    dimensions: [
      { id: "permitApplicationNumber", name: "Application #", type: "text", filterable: true, source: "business_permit_applications", path: "application.applicationNumber", sortOrder: 1 },
      { id: "permitBusinessName", name: "Business Name", type: "text", filterable: true, source: "businesses", path: "business.name", autoSelect: true, sortOrder: 2 },
      { id: "permitOwnerName", name: "Owner Name", type: "text", filterable: true, source: "business_owners", path: "owner.name", autoSelect: true, sortOrder: 3 },
      { id: "permitBusinessScale", name: "Business Scale", type: "categorical", filterable: true, source: "businesses", path: "business.businessScale", sortOrder: 4 },
      { id: "permitBusinessAddress", name: "Business Address", type: "text", filterable: false, source: "businesses", path: "business.address", sortOrder: 5 },
      { id: "linesOfBusiness", name: "Lines of Business", type: "text", filterable: false, source: "computed", sortOrder: 6 },
    ],
  },
]

const PERMITS_METRIC_GROUPS: MetricGroup[] = [
  {
    id: "counts",
    name: "Counts",
    metrics: [
      { id: "permitCount", name: "Permit Count", aggregation: "count", format: "number", description: "Total permits" },
      { id: "activePermits", name: "Active Permits", aggregation: "count", format: "number", filter: { dimensionId: "permitStatus", operator: "equals", value: "Active" } },
      { id: "expiredPermits", name: "Expired Permits", aggregation: "count", format: "number", filter: { dimensionId: "permitStatus", operator: "equals", value: "Expired" } },
    ],
  },
  {
    id: "expiring",
    name: "Expiring",
    metrics: [
      { id: "expiringThisMonth", name: "Expiring This Month", aggregation: "count", format: "number", description: "Permits expiring within current month" },
      { id: "expiringThisQuarter", name: "Expiring This Quarter", aggregation: "count", format: "number", description: "Permits expiring within current quarter" },
    ],
  },
  {
    id: "issued",
    name: "Issued",
    metrics: [
      { id: "newPermitsIssued", name: "New Permits (This Period)", aggregation: "count", format: "number", description: "New permits issued in selected period" },
      { id: "renewalPermitsIssued", name: "Renewals (This Period)", aggregation: "count", format: "number", description: "Renewal permits issued in selected period" },
    ],
  },
]

// ===========================================
// BUSINESSES CONFIGURATION
// ===========================================

const BUSINESSES_DIMENSION_GROUPS: DimensionGroup[] = [
  {
    id: "business_details",
    name: "Business Details",
    defaultExpanded: true,
    dimensions: [
      { id: "name", name: "Business Name", type: "text", filterable: true, source: "businesses", autoSelect: true, sortOrder: 1 },
      { id: "scale", name: "Business Scale", type: "categorical", filterable: true, source: "businesses", sortOrder: 2, options: ["Micro", "Small", "Medium", "Large"] },
      { id: "ownershipType", name: "Ownership Type", type: "categorical", filterable: true, source: "businesses", sortOrder: 3, options: ["Sole Proprietorship", "Partnership", "Corporation", "Cooperative"] },
      { id: "revenue", name: "Annual Revenue", type: "numeric", filterable: true, source: "businesses", sortOrder: 4 },
      { id: "employees", name: "Total Employees", type: "numeric", filterable: true, source: "businesses", sortOrder: 5 },
      { id: "area", name: "Business Area (sqm)", type: "numeric", filterable: true, source: "businesses", sortOrder: 6 },
      { id: "started", name: "Date Started", type: "date", filterable: true, source: "businesses", sortOrder: 7 },
      { id: "established", name: "Established Date", type: "date", filterable: true, source: "businesses", sortOrder: 8 },
    ],
  },
  {
    id: "location",
    name: "Location",
    dimensions: [
      { id: "province", name: "Province", type: "text", filterable: true, source: "provinces", sortOrder: 1 },
      { id: "city", name: "City", type: "text", filterable: true, source: "cities", sortOrder: 2 },
      { id: "barangay", name: "Barangay", type: "text", filterable: true, source: "barangays", sortOrder: 3 },
      { id: "address", name: "Full Address", type: "text", filterable: false, source: "businesses", sortOrder: 4 },
    ],
  },
  {
    id: "registration",
    name: "Registration",
    dimensions: [
      { id: "regNumber", name: "Registration #", type: "text", filterable: true, source: "businesses", sortOrder: 1 },
      { id: "businessOwnerName", name: "Owner Name", type: "text", filterable: true, source: "business_owners", path: "owner.name", autoSelect: true, sortOrder: 2 },
      { id: "businessBlacklisted", name: "Blacklist Status", type: "boolean", filterable: true, source: "businesses", sortOrder: 3 },
      { id: "occupancyType", name: "Occupancy Type", type: "categorical", filterable: true, source: "businesses", sortOrder: 4 },
      { id: "contactNumber", name: "Contact Number", type: "text", filterable: false, source: "businesses", sortOrder: 5 },
      { id: "email", name: "Email", type: "text", filterable: true, source: "businesses", sortOrder: 6 },
    ],
  },
]

const BUSINESSES_METRIC_GROUPS: MetricGroup[] = [
  {
    id: "counts",
    name: "Counts",
    metrics: [
      { id: "businessCount", name: "Business Count", aggregation: "count", format: "number", description: "Total businesses" },
      { id: "microBusinesses", name: "Micro Businesses", aggregation: "count", format: "number", filter: { dimensionId: "scale", operator: "equals", value: "Micro" } },
      { id: "smallBusinesses", name: "Small Businesses", aggregation: "count", format: "number", filter: { dimensionId: "scale", operator: "equals", value: "Small" } },
      { id: "mediumBusinesses", name: "Medium Businesses", aggregation: "count", format: "number", filter: { dimensionId: "scale", operator: "equals", value: "Medium" } },
      { id: "largeBusinesses", name: "Large Businesses", aggregation: "count", format: "number", filter: { dimensionId: "scale", operator: "equals", value: "Large" } },
      { id: "blacklistedBusinesses", name: "Blacklisted", aggregation: "count", format: "number", filter: { dimensionId: "businessBlacklisted", operator: "equals", value: true } },
      { id: "activeBusinesses", name: "Active", aggregation: "count", format: "number", filter: { dimensionId: "businessBlacklisted", operator: "equals", value: false } },
    ],
  },
  {
    id: "financial",
    name: "Financial",
    metrics: [
      { id: "totalAnnualRevenue", name: "Total Annual Revenue", aggregation: "sum", format: "currency", field: "annualRevenue", description: "Sum of annual revenues" },
      { id: "avgAnnualRevenue", name: "Avg Annual Revenue", aggregation: "average", format: "currency", field: "annualRevenue", description: "Average annual revenue" },
    ],
  },
  {
    id: "employment",
    name: "Employment",
    metrics: [
      { id: "businessTotalEmployees", name: "Total Employees", aggregation: "sum", format: "number", field: "numberOfEmployees", description: "Sum of all employees" },
      { id: "avgEmployees", name: "Avg Employees", aggregation: "average", format: "number", field: "numberOfEmployees", description: "Average employees per business" },
    ],
  },
  {
    id: "area",
    name: "Area",
    metrics: [
      { id: "totalBusinessArea", name: "Total Business Area", aggregation: "sum", format: "number", field: "businessArea", description: "Sum of business areas" },
      { id: "avgBusinessArea", name: "Avg Business Area", aggregation: "average", format: "number", field: "businessArea", description: "Average business area" },
    ],
  },
]

// ===========================================
// BUSINESS OWNERS CONFIGURATION
// ===========================================

const BUSINESS_OWNERS_DIMENSION_GROUPS: DimensionGroup[] = [
  {
    id: "owner_details",
    name: "Owner Details",
    defaultExpanded: true,
    dimensions: [
      { id: "fullName", name: "Full Name", type: "text", filterable: true, source: "business_owners", autoSelect: true, sortOrder: 1 },
      { id: "firstName", name: "First Name", type: "text", filterable: true, source: "business_owners", sortOrder: 2 },
      { id: "lastName", name: "Last Name", type: "text", filterable: true, source: "business_owners", sortOrder: 3 },
      { id: "ownerEmail", name: "Email", type: "text", filterable: true, source: "business_owners", sortOrder: 4 },
      { id: "mobile", name: "Mobile", type: "text", filterable: true, source: "business_owners", sortOrder: 5 },
      { id: "tin", name: "TIN", type: "text", filterable: true, source: "business_owners", sortOrder: 6 },
    ],
  },
  {
    id: "demographics",
    name: "Demographics",
    dimensions: [
      { id: "citizenship", name: "Citizenship", type: "categorical", filterable: true, source: "business_owners", sortOrder: 1 },
      { id: "civilStatus", name: "Civil Status", type: "categorical", filterable: true, source: "business_owners", sortOrder: 2 },
      { id: "gender", name: "Gender", type: "categorical", filterable: true, source: "business_owners", sortOrder: 3, options: ["Male", "Female"] },
      { id: "birthDate", name: "Birth Date", type: "date", filterable: true, source: "business_owners", sortOrder: 4 },
      { id: "type", name: "Owner Type", type: "categorical", filterable: true, source: "business_owners", sortOrder: 5, options: ["Single", "Group"] },
    ],
  },
  {
    id: "location",
    name: "Location",
    dimensions: [
      { id: "ownerProvince", name: "Province", type: "text", filterable: true, source: "provinces", sortOrder: 1 },
      { id: "ownerCity", name: "City", type: "text", filterable: true, source: "cities", sortOrder: 2 },
      { id: "ownerBarangay", name: "Barangay", type: "text", filterable: true, source: "barangays", sortOrder: 3 },
      { id: "ownerAddress", name: "Full Address", type: "text", filterable: false, source: "business_owners", sortOrder: 4 },
    ],
  },
  {
    id: "status",
    name: "Status",
    dimensions: [
      { id: "ownerBlacklisted", name: "Blacklist Status", type: "boolean", filterable: true, source: "business_owners", sortOrder: 1 },
      { id: "ownerBlacklistReason", name: "Blacklist Reason", type: "text", filterable: false, source: "business_owners", sortOrder: 2 },
      { id: "createdAt", name: "Created Date", type: "date", filterable: true, source: "business_owners", sortOrder: 3 },
    ],
  },
]

const BUSINESS_OWNERS_METRIC_GROUPS: MetricGroup[] = [
  {
    id: "counts",
    name: "Counts",
    metrics: [
      { id: "ownerCount", name: "Owner Count", aggregation: "count", format: "number", description: "Total owners" },
      { id: "singleOwners", name: "Single Owners", aggregation: "count", format: "number", filter: { dimensionId: "type", operator: "equals", value: "Single" } },
      { id: "groupOwners", name: "Group Owners", aggregation: "count", format: "number", filter: { dimensionId: "type", operator: "equals", value: "Group" } },
      { id: "blacklistedOwners", name: "Blacklisted", aggregation: "count", format: "number", filter: { dimensionId: "ownerBlacklisted", operator: "equals", value: true } },
      { id: "activeOwners", name: "Active Owners", aggregation: "count", format: "number", filter: { dimensionId: "ownerBlacklisted", operator: "equals", value: false } },
    ],
  },
  {
    id: "tin",
    name: "TIN Status",
    metrics: [
      { id: "ownersWithTIN", name: "With TIN", aggregation: "count", format: "number", filter: { dimensionId: "tin", operator: "isNotEmpty", value: "" } },
      { id: "ownersWithoutTIN", name: "Without TIN", aggregation: "count", format: "number", filter: { dimensionId: "tin", operator: "isEmpty", value: "" } },
    ],
  },
  {
    id: "demographics",
    name: "Demographics",
    metrics: [
      { id: "maleOwners", name: "Male Owners", aggregation: "count", format: "number", filter: { dimensionId: "gender", operator: "equals", value: "Male" } },
      { id: "femaleOwners", name: "Female Owners", aggregation: "count", format: "number", filter: { dimensionId: "gender", operator: "equals", value: "Female" } },
      { id: "filipinoOwners", name: "Filipino", aggregation: "count", format: "number", filter: { dimensionId: "citizenship", operator: "equals", value: "Filipino" } },
      { id: "foreignOwners", name: "Foreign", aggregation: "count", format: "number", filter: { dimensionId: "citizenship", operator: "notEquals", value: "Filipino" } },
    ],
  },
]

// ===========================================
// MANUAL TRANSACTIONS CONFIGURATION
// ===========================================

const MANUAL_TRANSACTIONS_DIMENSION_GROUPS: DimensionGroup[] = [
  {
    id: "transaction_details",
    name: "Transaction Details",
    defaultExpanded: true,
    dimensions: [
      { id: "manualTransactionNumber", name: "Transaction #", type: "text", filterable: true, source: "manual_transactions", autoSelect: true, sortOrder: 1 },
      { id: "transactionType", name: "Type", type: "categorical", filterable: true, source: "manual_transactions", sortOrder: 2, options: ["debit", "credit"] },
      { id: "manualAmount", name: "Amount", type: "numeric", filterable: true, source: "manual_transactions", sortOrder: 3 },
      { id: "description", name: "Description", type: "text", filterable: true, source: "manual_transactions", sortOrder: 4 },
      { id: "manualReferenceNumber", name: "Reference #", type: "text", filterable: true, source: "manual_transactions", sortOrder: 5 },
      { id: "manualStatus", name: "Status", type: "categorical", filterable: true, source: "manual_transactions", sortOrder: 6, options: ["pending", "completed", "cancelled"] },
      { id: "createdBy", name: "Created By", type: "text", filterable: true, source: "users", sortOrder: 7 },
      { id: "manualCreatedAt", name: "Created Date", type: "date", filterable: true, source: "manual_transactions", sortOrder: 8 },
    ],
  },
]

const MANUAL_TRANSACTIONS_METRIC_GROUPS: MetricGroup[] = [
  {
    id: "financial",
    name: "Financial",
    metrics: [
      { id: "manualTransactionCount", name: "Transaction Count", aggregation: "count", format: "number", description: "Total transactions" },
      { id: "totalDebits", name: "Total Debits", aggregation: "sum", format: "currency", field: "amount", filter: { dimensionId: "transactionType", operator: "equals", value: "debit" } },
      { id: "totalCredits", name: "Total Credits", aggregation: "sum", format: "currency", field: "amount", filter: { dimensionId: "transactionType", operator: "equals", value: "credit" } },
      { id: "netAmount", name: "Net Amount", aggregation: "sum", format: "currency", field: "netAmount", description: "Debits - Credits" },
    ],
  },
  {
    id: "by_status",
    name: "By Status",
    metrics: [
      { id: "manualCompletedCount", name: "Completed", aggregation: "count", format: "number", filter: { dimensionId: "manualStatus", operator: "equals", value: "completed" } },
      { id: "manualPendingCount", name: "Pending", aggregation: "count", format: "number", filter: { dimensionId: "manualStatus", operator: "equals", value: "pending" } },
      { id: "manualCancelledCount", name: "Cancelled", aggregation: "count", format: "number", filter: { dimensionId: "manualStatus", operator: "equals", value: "cancelled" } },
    ],
  },
]

// ===========================================
// FULL RESOURCE CONFIGURATIONS
// ===========================================

export const RESOURCE_CONFIGS: Record<ResourceType, ResourceConfig> = {
  permit_applications: {
    type: "permit_applications",
    meta: RESOURCE_META.permit_applications,
    dimensionGroups: PERMIT_APPLICATION_DIMENSION_GROUPS,
    metricGroups: PERMIT_APPLICATION_METRIC_GROUPS,
    defaultDimensions: ["applicationNumber", "ownerFullName", "businessName", "status"],
    defaultMetrics: ["applicationCount", "totalFees", "totalPaidAmount"],
    primaryDateDimension: "submittedAt",
  },
  billing_groups: {
    type: "billing_groups",
    meta: RESOURCE_META.billing_groups,
    dimensionGroups: BILLING_GROUP_DIMENSION_GROUPS,
    metricGroups: BILLING_GROUP_METRIC_GROUPS,
    defaultDimensions: ["billingTransactionNumber", "billingGroupName", "payorName", "billingAmount"],
    defaultMetrics: ["billingTransactionCount", "billingTotalAmount"],
    primaryDateDimension: "billingDate",
  },
  payments: {
    type: "payments",
    meta: RESOURCE_META.payments,
    dimensionGroups: PAYMENTS_DIMENSION_GROUPS,
    metricGroups: PAYMENTS_METRIC_GROUPS,
    defaultDimensions: ["paymentTransactionNumber", "receiptNumber", "amount", "method", "status"],
    defaultMetrics: ["paymentCount", "paymentTotalAmount"],
    primaryDateDimension: "paidAt",
  },
  permits: {
    type: "permits",
    meta: RESOURCE_META.permits,
    dimensionGroups: PERMITS_DIMENSION_GROUPS,
    metricGroups: PERMITS_METRIC_GROUPS,
    defaultDimensions: ["permitNumber", "permitBusinessName", "permitOwnerName", "permitStatus"],
    defaultMetrics: ["permitCount", "activePermits"],
    primaryDateDimension: "dateReleased",
  },
  businesses: {
    type: "businesses",
    meta: RESOURCE_META.businesses,
    dimensionGroups: BUSINESSES_DIMENSION_GROUPS,
    metricGroups: BUSINESSES_METRIC_GROUPS,
    defaultDimensions: ["name", "businessOwnerName", "scale", "ownershipType"],
    defaultMetrics: ["businessCount", "totalAnnualRevenue"],
    primaryDateDimension: "started",
  },
  business_owners: {
    type: "business_owners",
    meta: RESOURCE_META.business_owners,
    dimensionGroups: BUSINESS_OWNERS_DIMENSION_GROUPS,
    metricGroups: BUSINESS_OWNERS_METRIC_GROUPS,
    defaultDimensions: ["fullName", "ownerEmail", "mobile", "type"],
    defaultMetrics: ["ownerCount", "activeOwners"],
    primaryDateDimension: "createdAt",
  },
  manual_transactions: {
    type: "manual_transactions",
    meta: RESOURCE_META.manual_transactions,
    dimensionGroups: MANUAL_TRANSACTIONS_DIMENSION_GROUPS,
    metricGroups: MANUAL_TRANSACTIONS_METRIC_GROUPS,
    defaultDimensions: ["manualTransactionNumber", "transactionType", "manualAmount", "description"],
    defaultMetrics: ["manualTransactionCount", "totalDebits", "totalCredits"],
    primaryDateDimension: "manualCreatedAt",
  },
}

/**
 * Get all dimensions for a resource as a flat array
 */
export function getAllDimensions(resourceType: ResourceType) {
  const config = RESOURCE_CONFIGS[resourceType]
  return config.dimensionGroups.flatMap(group => group.dimensions)
}

/**
 * Get all metrics for a resource as a flat array
 */
export function getAllMetrics(resourceType: ResourceType) {
  const config = RESOURCE_CONFIGS[resourceType]
  return config.metricGroups.flatMap(group => group.metrics)
}

/**
 * Get a specific dimension by ID
 */
export function getDimension(resourceType: ResourceType, dimensionId: string) {
  return getAllDimensions(resourceType).find(d => d.id === dimensionId)
}

/**
 * Get a specific metric by ID
 */
export function getMetric(resourceType: ResourceType, metricId: string) {
  return getAllMetrics(resourceType).find(m => m.id === metricId)
}

/**
 * Get available resource types
 */
export function getResourceTypes(): ResourceType[] {
  return Object.keys(RESOURCE_CONFIGS) as ResourceType[]
}

/**
 * Get resource meta for all resources
 */
export function getAllResourceMeta(): ResourceMeta[] {
  return Object.values(RESOURCE_META)
}
