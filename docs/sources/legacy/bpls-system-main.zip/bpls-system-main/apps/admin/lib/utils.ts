// Compatibility shim - re-exports from shared packages
// This allows existing @/lib/utils imports to continue working
export { cn } from "@repo/ui/utils"

export {
  formatCurrency,
  parseCurrency,
  formatDate,
  formatDateForCSV,
  formatCurrencyForCSV,
  getInitials,
} from "@/lib/utils/formatting"
