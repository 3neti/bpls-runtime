/**
 * Major Form Schema
 *
 * Zod validation schema for adding/editing majors in the taxes & fees hierarchy
 * Hierarchy: Major → Division → Fees → Groups
 */

import { z } from "zod";

/**
 * Major Form Schema
 * Validates all fields when creating or editing a major
 */
export const majorFormSchema = z.object({
  name: z
    .string()
    .min(1, "Major name is required")
    .min(2, "Major name must be at least 2 characters")
    .max(100, "Major name cannot exceed 100 characters")
    .regex(/^[a-zA-Z0-9\s\-&]+$/, "Major name can only contain letters, numbers, spaces, hyphens, and ampersands"),

  description: z.string().optional().or(z.literal("")),
});

/**
 * Inferred TypeScript type from the schema
 */
export type MajorFormSchema = z.infer<typeof majorFormSchema>;

/**
 * Default values for the form
 */
export const majorFormDefaultValues: Partial<MajorFormSchema> = {
  name: "",
  description: "",
};
