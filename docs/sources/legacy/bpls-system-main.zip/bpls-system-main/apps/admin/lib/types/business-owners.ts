/**
 * Business Owner type definitions
 */

export interface BusinessOwner {
  id: string
  firstName: string
  middleName?: string
  lastName: string
  birthDate: string
  civilStatus: string
  gender: string
  citizenship: string
  tin?: string // Optional - not all business types require TIN
  mobile: string
  email: string
  // NEW: Hierarchical location fields
  address?: string // Optional free-form street address (House No., Street, Building)
  provinceId: string // REQUIRED - Foreign key to provinces table
  cityId: string // REQUIRED - Foreign key to cities table
  barangayId: string // REQUIRED - Foreign key to barangays table
  // DEPRECATED: Legacy address fields (kept for backward compatibility during migration)
  houseNo?: string
  street?: string
  city?: string
  district?: string
  barangay?: string
  zone?: string
  avatar?: string
  ownerType: "Single" | "Group"
  groupName?: string
  isBlacklisted: boolean
  blacklistReason?: string
  blacklistedAt?: string
  blacklistedBy?: string
}

export type OwnerType = "existing" | "new"

// Derived types
export type BusinessOwnerFormData = Omit<BusinessOwner, 'id' | 'avatar'>
export type BusinessOwnerSummary = Pick<BusinessOwner, 'id' | 'firstName' | 'lastName' | 'email'>
