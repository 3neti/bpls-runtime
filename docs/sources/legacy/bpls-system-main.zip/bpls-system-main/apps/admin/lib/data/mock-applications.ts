/**
 * Mock application data for clearance reviews
 * In production, this would come from Convex queries
 */

import type { Clearance } from "@/lib/types/clearance"
import { MOCK_BUSINESS_OWNERS } from "./mock-business-owners"
import { MOCK_BUSINESSES } from "./mock-businesses"

/**
 * Legacy Department Clearance structure for backward compatibility with mock data
 * @deprecated Will be migrated to new Clearance structure
 */
interface LegacyDepartmentClearance {
  id: string
  departmentId: string
  departmentName: string
  certificateName: string
  status: "approved" | "pending" | "not_started"
  fee?: number
  remarks?: string
  approvedAt?: string
  approvedBy?: string
  approvedByName?: string
}

interface MockApplicationData {
  applicationNumber: string
  status: string
  submittedOn: string
  remarks?: string
  owner: {
    profilePhoto?: string
    firstName: string
    middleName?: string
    lastName: string
    fullName: string
    birthDate: string
    civilStatus: string
    gender: string
    citizenship: string
    tin?: string // Optional - not all business types require TIN
    mobile: string
    email: string
    address: {
      houseNo?: string // Optional address field
      street?: string // Optional address field
      city?: string // Optional address field
      district?: string // Optional address field
      barangay?: string // Optional address field
      zone?: string // Optional address field
    }
  }
  business: {
    name: string
    dateEstablished: string
    ownershipType: string
    occupancy: string
    permitPaymentCadence: string
    numberOfEmployees: string
    contactNumber: string
    email: string
    address: {
      houseNo?: string // Optional address field
      street?: string // Optional address field
      city?: string // Optional address field
      district?: string // Optional address field
      barangay?: string // Optional address field
      zone?: string // Optional address field
    }
    linesOfBusiness: Array<{
      id: string
      businessCategory: string
      categoryName: string
      capitalInvestment: string
      businessAnnualRevenue: string
      permitApplicationType: string
    }>
  }
  prerequisites: {
    ownershipType: string
    documents: Record<string, { uploaded: boolean; fileName: string }>
  }
  departmentClearances: LegacyDepartmentClearance[]
}

/**
 * Helper to derive application owner data from centralized mock owner
 */
function deriveOwnerData(ownerId: string) {
  const owner = MOCK_BUSINESS_OWNERS.find(o => o.id === ownerId)
  if (!owner) throw new Error(`Owner with id ${ownerId} not found`)

  return {
    profilePhoto: owner.avatar,
    firstName: owner.firstName,
    middleName: owner.middleName || "",
    lastName: owner.lastName,
    fullName: `${owner.firstName} ${owner.lastName}`,
    birthDate: owner.birthDate,
    civilStatus: owner.civilStatus.charAt(0).toUpperCase() + owner.civilStatus.slice(1),
    gender: owner.gender.charAt(0).toUpperCase() + owner.gender.slice(1),
    citizenship: owner.citizenship.charAt(0).toUpperCase() + owner.citizenship.slice(1),
    tin: owner.tin,
    mobile: owner.mobile,
    email: owner.email,
    address: {
      houseNo: owner.houseNo,
      street: owner.street,
      city: owner.city,
      district: owner.district,
      barangay: owner.barangay,
      zone: owner.zone,
    },
  }
}

/**
 * Helper to derive application business data from centralized mock business
 */
function deriveBusinessData(businessId: string) {
  const business = MOCK_BUSINESSES.find(b => b.id === businessId)
  if (!business) throw new Error(`Business with id ${businessId} not found`)

  return {
    name: business.name,
    dateEstablished: business.establishedDate,
    ownershipType: business.ownershipType,
    occupancy: business.occupancy,
    permitPaymentCadence: business.permitPaymentCadence,
    numberOfEmployees: business.numberOfEmployees,
    contactNumber: business.contactNumber,
    email: business.email,
    address: {
      houseNo: business.houseNo,
      street: business.street,
      city: business.city,
      district: business.district,
      barangay: business.barangay,
      zone: business.zone,
    },
    linesOfBusiness: [
      {
        id: "1",
        businessCategory: business.lineOfBusiness,
        categoryName: business.lineOfBusiness.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
        capitalInvestment: "100000",
        businessAnnualRevenue: business.annualRevenue.replace(/[₱,]/g, ''),
        permitApplicationType: "New",
      },
    ],
  }
}

/**
 * Base mock applications database
 */
const baseApplications: Record<string, MockApplicationData> = {
  "1": {
    applicationNumber: "APP-2024-001",
    status: "pending",
    submittedOn: "2025-09-28",
    remarks: "This is our first business permit application. We plan to operate a small neighborhood store serving the local community with basic necessities.",
    owner: deriveOwnerData("1"),
    business: deriveBusinessData("1"),
    prerequisites: {
      ownershipType: "sole-proprietorship",
      documents: {
        applicationForm: { uploaded: true, fileName: "application-form.pdf" },
        barangayClearance: { uploaded: true, fileName: "barangay-clearance.pdf" },
        sanitaryPermit: { uploaded: true, fileName: "sanitary-permit.pdf" },
      },
    },
    departmentClearances: [
      {
        id: "clearance-1-sanitary",
        departmentId: "sanitary",
        departmentName: "Sanitary Department",
        certificateName: "Sanitary Certificate",
        status: "approved" as const,
        fee: 500,
        remarks: "Business premises meet all sanitary standards. Regular inspections required.",
        approvedAt: "2025-09-30T10:30:00Z",
        approvedBy: "sanitary-officer-1",
        approvedByName: "Dr. Maria Santos",
      },
      {
        id: "clearance-1-mpdc",
        departmentId: "mpdc",
        departmentName: "Municipal Planning & Development Coordinator",
        certificateName: "MPDC Certificate",
        status: "pending" as const,
      },
      {
        id: "clearance-1-menro",
        departmentId: "menro",
        departmentName: "Municipal Environment & Natural Resources Office",
        certificateName: "MENRO Certificate",
        status: "not_started" as const,
      },
      {
        id: "clearance-1-bfp",
        departmentId: "bfp",
        departmentName: "Bureau of Fire Protection",
        certificateName: "BFP Clearance Certificate",
        status: "approved" as const,
        fee: 750,
        remarks: "Fire safety equipment installed and compliant. Fire exits properly marked.",
        approvedAt: "2025-09-29T14:15:00Z",
        approvedBy: "bfp-officer-1",
        approvedByName: "FO Juan Cruz",
      },
      {
        id: "clearance-1-engineering",
        departmentId: "engineering",
        departmentName: "Engineering Department",
        certificateName: "Engineering Certificate",
        status: "not_started" as const,
      },
    ],
  },
  "2": {
    applicationNumber: "APP-2024-002",
    status: "pending",
    submittedOn: "2025-09-29",
    remarks: "Requesting permit for trading corporation. We have completed all regulatory requirements and obtained necessary certifications.",
    owner: deriveOwnerData("2"),
    business: deriveBusinessData("2"),
    prerequisites: {
      ownershipType: "sole-proprietorship",
      documents: {
        applicationForm: { uploaded: true, fileName: "application-form-santos.pdf" },
        barangayClearance: { uploaded: true, fileName: "barangay-clearance-santos.pdf" },
        sanitaryPermit: { uploaded: true, fileName: "sanitary-permit-santos.pdf" },
        fireSafetyInspection: { uploaded: true, fileName: "fire-safety-santos.pdf" },
      },
    },
    departmentClearances: [
      {
        id: "clearance-2-sanitary",
        departmentId: "sanitary",
        departmentName: "Sanitary Department",
        certificateName: "Sanitary Certificate",
        status: "approved" as const,
        fee: 1000,
        remarks: "Food handling area meets health standards. Staff health certificates verified.",
        approvedAt: "2025-09-30T09:00:00Z",
        approvedBy: "sanitary-officer-1",
        approvedByName: "Dr. Maria Santos",
      },
      {
        id: "clearance-2-mpdc",
        departmentId: "mpdc",
        departmentName: "Municipal Planning & Development Coordinator",
        certificateName: "MPDC Certificate",
        status: "approved" as const,
        fee: 800,
        remarks: "Business location complies with zoning regulations for commercial use.",
        approvedAt: "2025-09-30T11:45:00Z",
        approvedBy: "mpdc-officer-1",
        approvedByName: "Eng. Pedro Rodriguez",
      },
      {
        id: "clearance-2-menro",
        departmentId: "menro",
        departmentName: "Municipal Environment & Natural Resources Office",
        certificateName: "MENRO Certificate",
        status: "approved" as const,
        fee: 600,
        remarks: "Waste management plan approved. Environmental compliance certificate issued.",
        approvedAt: "2025-09-30T13:20:00Z",
        approvedBy: "menro-officer-1",
        approvedByName: "Mr. Roberto Garcia",
      },
      {
        id: "clearance-2-bfp",
        departmentId: "bfp",
        departmentName: "Bureau of Fire Protection",
        certificateName: "BFP Clearance Certificate",
        status: "approved" as const,
        fee: 1200,
        remarks: "Fire safety inspection passed. Kitchen fire suppression system installed.",
        approvedAt: "2025-09-30T15:00:00Z",
        approvedBy: "bfp-officer-2",
        approvedByName: "FO Luis Santos",
      },
      {
        id: "clearance-2-engineering",
        departmentId: "engineering",
        departmentName: "Engineering Department",
        certificateName: "Engineering Certificate",
        status: "approved" as const,
        fee: 900,
        remarks: "Structural integrity verified. Building permits and plans approved.",
        approvedAt: "2025-09-30T16:30:00Z",
        approvedBy: "engineering-officer-1",
        approvedByName: "Eng. Sofia Cruz",
      },
    ],
  },
}

/**
 * Get mock application details by ID
 * Returns null if application is not found
 */
export function getMockApplication(id: string): MockApplicationData | null {
  return baseApplications[id] || null
}

/**
 * Convert legacy department clearance to new clearance structure
 * This is a temporary conversion utility for backward compatibility
 *
 * @param legacyClearance - Legacy clearance with departmentId/departmentName fields
 * @param permitId - Permit ID for the clearance
 * @returns Clearance object with new structure
 */
export function convertLegacyClearance(
  legacyClearance: LegacyDepartmentClearance,
  permitId: string
): Clearance {
  // Map department IDs to clearance types
  const typeMap: Record<string, Clearance['type']> = {
    sanitary: 'sanitary',
    bfp: 'fire_safety',
    mpdc: 'mpdc',
    menro: 'environmental',
    engineering: 'engineering',
  }

  return {
    id: legacyClearance.id,
    permitId,
    type: typeMap[legacyClearance.departmentId] || 'sanitary',
    clearanceId: legacyClearance.departmentId,
    name: legacyClearance.certificateName,
    certificateName: legacyClearance.certificateName,
    status: legacyClearance.status,
    department: {
      id: legacyClearance.departmentId,
      name: legacyClearance.departmentName,
      shortName: legacyClearance.departmentName.split(' ')[0], // Extract first word
    },
    fee: legacyClearance.fee,
    remarks: legacyClearance.remarks,
    approvedAt: legacyClearance.approvedAt,
    approvedBy: legacyClearance.approvedBy,
    approvedByName: legacyClearance.approvedByName,
  }
}

/**
 * Get clearances for an application in the new format
 *
 * @param applicationId - Application ID
 * @returns Array of Clearance objects
 */
export function getApplicationClearances(applicationId: string): Clearance[] {
  const application = getMockApplication(applicationId)
  if (!application) return []

  return application.departmentClearances.map((legacy) =>
    convertLegacyClearance(legacy, applicationId)
  )
}
