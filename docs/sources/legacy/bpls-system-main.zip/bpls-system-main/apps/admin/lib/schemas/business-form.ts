/**
 * Zod validation schema for Business Create Form
 *
 * This schema is used for standalone business creation at /dashboard/businesses/new
 * It includes only the fields present in the CreateBusinessForm UI.
 */

import { z } from "zod"

/**
 * Document schema for ownership-specific documents
 */
const documentSchema = z.object({
  file: z.instanceof(File).nullable(),
  uploaded: z.boolean(),
})

/**
 * Business Create Schema
 * Used for creating new businesses in standalone context (not permit application)
 */
export const businessFormSchema = z
  .object({
    businessName: z.string().min(1, "Business name is required"),
    businessArea: z.number().positive("Must be a positive number").optional(),
    propertyIndexNumber: z.string().optional(),
    maleEmployeeCount: z.number().min(0, "Male employee count must be 0 or greater"),
    femaleEmployeeCount: z.number().min(0, "Female employee count must be 0 or greater"),
    contactNumber: z.string().optional(),
    email: z.union([z.string().email(), z.literal("")]).optional(),
    establishedDate: z.string().optional(),
    registrationDate: z.string().optional(), // DTI/SEC/CDA registration date based on ownership type
    registrationNumber: z.string().optional(), // DTI/SEC/CDA registration number based on ownership type
    dateStarted: z.string().min(1, "Date started is required"),
    occupancy: z.enum(["rented", "owned"]).optional(),
    ownershipType: z.enum([
      "sole-proprietorship",
      "partnership",
      "corporation",
      "cooperative",
      "religious",
      "non-profit",
    ]),
    // Conditional Group Name field (required for Partnership, Corporation, Cooperative)
    groupName: z.string().optional(),
    // NEW: Hierarchical address fields
    address: z.string().min(1, "Street address is required"),
    buildingName: z.string().min(1, "Building name is required"),
    provinceId: z.string().min(1, "Province is required"),
    cityId: z.string().min(1, "City/Municipality is required"),
    barangayId: z.string().min(1, "Barangay is required"),
    // Business classification (optional - existing businesses are unclassified)
    categoryId: z.string().optional(),
    subCategoryId: z.string().optional(),
    // Ownership-specific documents (optional but validated based on ownership type)
    documents: z
      .record(
        z.string(), // document type key (e.g., "dtiCertificate", "secCertificate")
        documentSchema
      )
      .optional(),
  })
  .refine((data) => data.maleEmployeeCount + data.femaleEmployeeCount > 0, {
    message: "At least one employee is required (male or female)",
    path: ["maleEmployeeCount"],
  })
  .superRefine((data, ctx) => {
    // Conditional validation for groupName based on ownership type
    const requiresGroupName = ["partnership", "corporation", "cooperative"].includes(data.ownershipType)
    if (requiresGroupName) {
      if (!data.groupName || data.groupName.trim().length === 0) {
        ctx.addIssue({
          code: "custom",
          message: `Company/Organization name is required for ${data.ownershipType}`,
          path: ["groupName"],
        })
      }
    }
  })

/**
 * Type inference from schema
 */
export type BusinessFormSchema = z.infer<typeof businessFormSchema>

/**
 * Default values for business creation form
 */
export const businessFormDefaultValues: BusinessFormSchema = {
  businessName: "",
  businessArea: undefined,
  propertyIndexNumber: "",
  maleEmployeeCount: 1,
  femaleEmployeeCount: 0,
  contactNumber: "",
  email: "",
  establishedDate: new Date().toISOString().split("T")[0],
  registrationDate: "",
  registrationNumber: "",
  dateStarted: new Date().toISOString().split("T")[0],
  occupancy: "rented",
  ownershipType: "sole-proprietorship",
  groupName: "",
  address: "",
  buildingName: "",
  provinceId: "",
  cityId: "",
  barangayId: "",
  categoryId: "",
  subCategoryId: "",
  documents: {},
}
