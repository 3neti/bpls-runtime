/**
 * Centralized type exports
 * Import domain types from this file for better maintainability
 */

// Business Owner types
export type { BusinessOwner, OwnerType, BusinessOwnerFormData, BusinessOwnerSummary } from './business-owners'

// Business types
export type { Business, LineOfBusiness, BusinessFormInput, BusinessSummary } from './business'

// Permit types
export type {
  PermitFormValues,
  PermitStatus,
  PermitApplicationType,
  Permit,
  PermitApplication,
} from './permit'

// Permit Application types (business_permit_applications table)
export type {
  PermitApplication as BusinessPermitApplication,
  PermitApplicationStatus,
  PermitApplicationWithDetails,
  LineOfBusiness as PermitLineOfBusiness,
} from './permit-application'

// Fee types
export type {
  FeeType,
  ApplicationType,
  BusinessField,
  FeeRange,
  FeeConfig,
  BusinessData,
  CalculatedFee,
  FeeAssessment,
} from './fees'

// User and Permission types
export type { Permission, Role, User, UserFormData, UserSummary } from './user'

// Transaction types
export type {
  PaymentStatus,
  PaymentMethod,
  Payment,
  Transaction,
  TransactionSummary,
} from './transaction'

// Common types
export type {
  SelectionMode,
  CameraMode,
  SelectOption,
  PaginationParams,
  PaginatedResponse,
  ApiError,
  ApiResponse,
} from './common'

// Department types (Convex-derived)
export type {
  Department,
  DepartmentIcon,
  DepartmentFormInput,
  DepartmentUpdateInput,
  DepartmentUpdateResult,
  DepartmentWithStats,
  DepartmentSummary,
  DepartmentConfig,
  DepartmentUser,
  DepartmentStats,
} from './department'

// Clearance types (Convex-derived)
export type {
  ConvexClearance,
  ClearanceWithDepartment,
  ClearanceWithDepartmentSummary,
  ClearanceFormInput,
  ClearanceWithDepartmentInput,
  ClearanceUpdateInput,
  ClearanceWithDepartmentUpdateInput,
  ClearanceCreationResult,
  ClearanceUpdateResult,
  ClearanceWithDepartmentUpdateResult,
  ClearanceStatus,
  ClearanceType,
  ClearanceDepartmentInfo,
  ClearanceConfig,
  Clearance,
  ClearanceApprovalFormValues,
  ClearanceMultiFeeApprovalFormValues,
  ClearanceStatistics,
  ClearanceReviewData,
} from './clearance'

// Report Builder types
export type {
  DimensionType,
  Dimension,
  DimensionGroup,
  AggregationType,
  MetricFormat,
  Metric,
  MetricGroup,
  FilterOperator,
  FilterCondition,
  LogicalOperator,
  FilterGroup,
  DateRangePreset,
  DateRange,
  SortConfig,
  PaginationConfig,
  ReportConfiguration,
  ResourceType,
  ResourceMeta,
  ResourceConfig,
  ReportGenerationInput,
  ReportRow,
  MetricResult,
  ReportResult,
  SavedReport,
  CreateSavedReportInput,
  UpdateSavedReportInput,
} from './report-builder'

export {
  getOperatorsForType,
  getOperatorLabel,
  formatMetricValue,
} from './report-builder'
