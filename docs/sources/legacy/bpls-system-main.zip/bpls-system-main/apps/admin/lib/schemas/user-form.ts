import { z } from "zod";

/**
 * Schema for creating a new user
 */
export const addUserSchema = z.object({
  firstName: z
    .string()
    .min(1, "First name is required")
    .max(100, "First name must be less than 100 characters"),
  lastName: z
    .string()
    .min(1, "Last name is required")
    .max(100, "Last name must be less than 100 characters"),
  email: z
    .string()
    .min(1, "Email is required")
    .email("Please enter a valid email address"),
  phone: z
    .string()
    .max(20, "Phone number must be less than 20 characters")
    .optional()
    .or(z.literal("")),
  role: z
    .string()
    .min(1, "Role is required"),
  department: z
    .string()
    .optional()
    .or(z.literal("")),
});

export type AddUserFormData = z.infer<typeof addUserSchema>;

export const addUserDefaults: AddUserFormData = {
  firstName: "",
  lastName: "",
  email: "",
  phone: "",
  role: "",
  department: "",
};
