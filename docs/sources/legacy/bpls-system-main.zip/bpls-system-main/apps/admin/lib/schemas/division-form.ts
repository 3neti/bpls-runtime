/**
 * Division Form Schema
 *
 * Zod validation schema for adding/editing divisions in the taxes & fees hierarchy
 * Hierarchy: Major → Division (contains Fees) → Groups
 */

import { z } from "zod";

/**
 * Division Form Schema
 * Validates all fields when creating or editing a division
 */
export const divisionFormSchema = z.object({
  name: z
    .string()
    .min(1, "Division name is required")
    .min(2, "Division name must be at least 2 characters")
    .max(100, "Division name cannot exceed 100 characters")
    .regex(/^[a-zA-Z0-9\s\-&]+$/, "Division name can only contain letters, numbers, spaces, hyphens, and ampersands"),

  description: z.string().optional().or(z.literal("")),

  majorId: z
    .string()
    .min(1, "Please select a major")
    .refine((val) => val !== "", { message: "Please select a major" }),
});

/**
 * Inferred TypeScript type from the schema
 */
export type DivisionFormSchema = z.infer<typeof divisionFormSchema>;

/**
 * Default values for the form
 */
export const divisionFormDefaultValues: Partial<DivisionFormSchema> = {
  name: "",
  description: "",
  majorId: "",
};

/**
 * Division application schema
 * For applying a division to multiple groups
 */
export const divisionApplicationSchema = z.object({
  divisionId: z.string().min(1, "Division ID is required"),

  groupIds: z
    .array(z.string())
    .min(1, "Please select at least one group")
    .max(50, "Cannot apply division to more than 50 groups at once"),
});

/**
 * Inferred TypeScript type for division application
 */
export type DivisionApplicationSchema = z.infer<typeof divisionApplicationSchema>;

/**
 * Default values for division application form
 */
export const divisionApplicationDefaultValues: Partial<DivisionApplicationSchema> = {
  divisionId: "",
  groupIds: [],
};
