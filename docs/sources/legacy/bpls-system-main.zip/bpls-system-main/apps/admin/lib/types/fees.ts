/**
 * Fee configuration and calculation types
 *
 * These types are derived from the Convex schema as the single source of truth.
 * The database schema is defined in convex/schema.ts
 */

import type { Doc, Id } from "@repo/backend/convex/_generated/dataModel"

// Core fee type derived from Convex schema
export type Fee = Doc<"fees">

// Business nature category type derived from Convex schema
export type BusinessNatureCategory = Doc<"business_nature_categories">

// Fee name type derived from Convex schema
export type FeeName = Doc<"fee_names">

// Extract specific field types from the schema
export type FeeType = Fee["feeType"]
export type FeeCategory = "Tax" | "Regulatory Fee" | "Other Charges" | "Special Fee"
export type ApplicationType = 'New' | 'Renewal'

// BusinessField represents the standard business data fields that can be used for range-based fee calculation
// Note: Category variables (from mayorsPermitCategories table) are also supported as range fields but are dynamic,
// so they cannot be statically typed here. They're stored as strings in the database (rangeField: v.optional(v.string()))
// and resolved at runtime from BusinessData.categoryVariables
export type BusinessField = 'numberOfEmployees' | 'maleEmployeeCount' | 'femaleEmployeeCount' | 'businessArea' | 'capitalInvestment' | 'grossSales' | 'businessAnnualRevenue' | 'floorArea'

// Fee range interface (matches Convex schema structure)
// Supports both fixed fee amounts and formula-based fees for the final range
export interface FeeRange {
  min: number
  max: number
  fee?: number       // Fixed fee amount (for standard ranges)
  formula?: string   // Formula expression (only for final range)
}

// Legacy alias for backward compatibility with existing UI code
export interface FeeConfig {
  id: string
  name: string
  amount: number
  applicationType: ApplicationType[]
  feeType: FeeType
  divisionId?: string // For inherited fees from divisions
  groupId?: string // For custom fees on groups
  businessNatureId?: string // For fees associated with business nature categories
  ranges?: FeeRange[]
  formula?: string
  rangeField?: BusinessField
}

export interface BusinessData {
  numberOfEmployees?: number
  maleEmployeeCount?: number
  femaleEmployeeCount?: number
  businessArea?: number
  capitalInvestment?: number // From Line of Business (LOB)
  grossSales?: number // From Line of Business (LOB)
  businessAnnualRevenue?: number // From Line of Business (LOB) - kept for backward compatibility
  floorArea?: number // Business floor area in square meters
  categoryVariables?: Record<string, number> // Dynamic variables from mayorsPermitCategories table (e.g., numberOfHorses, numberOfTables)
}

export interface CalculatedFee {
  feeId: string
  feeName: string
  amount: number
  calculationDetails?: string
}

export interface FeeAssessment {
  businessId: string
  totalFees: number
  breakdown: CalculatedFee[]
  assessedDate: string
  assessedBy: string
}

/**
 * Department Fee Configuration
 * Represents a fee that a department can apply to permit applications
 */
export interface DepartmentFee {
  /** Unique identifier for the fee */
  id: string
  /** Fee name/title */
  name: string
  /** Default amount in pesos */
  defaultAmount: number
  /** Optional description of the fee */
  description?: string
  /** Department ID this fee belongs to */
  departmentId: string
  /** Department name for display */
  departmentName?: string
  /** Whether this fee is active/available */
  isActive?: boolean
  /** Created timestamp */
  createdAt?: string
  /** Last updated timestamp */
  updatedAt?: string
}

/**
 * Applied Fee
 * Represents a fee that has been applied to a clearance with optional override
 */
export interface AppliedFee {
  /** Reference to the fee configuration ID */
  feeId: string
  /** Fee name for display */
  feeName: string
  /** Default amount from fee library */
  defaultAmount: number
  /** Applied amount (can be overridden from default) */
  appliedAmount: number
  /** Optional override reason */
  overrideReason?: string
}

/**
 * Fee Breakdown
 * Complete fee breakdown for a clearance approval
 */
export interface FeeBreakdown {
  /** List of applied fees */
  fees: AppliedFee[]
  /** Total calculated amount */
  totalAmount: number
  /** Number of fees applied */
  feeCount: number
}

/**
 * Fee Override Types (for Group fee inheritance system)
 */

// Fee override derived from Convex schema
export type FeeOverride = Doc<"fee_overrides">

/**
 * Override values for different fee types
 */
export interface FeeOverrideValues {
  // For Constant fees
  overrideAmount?: number

  // For Range fees
  overrideRanges?: FeeRange[]

  // For Formula fees
  overrideFormula?: string

  // Required reason for all overrides
  reason: string
}
