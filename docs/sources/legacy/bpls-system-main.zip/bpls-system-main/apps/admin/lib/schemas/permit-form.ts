/**
 * Zod validation schema for Permit Application Form
 *
 * This schema validates the multi-step permit application form including:
 * - Business Owner Information
 * - Business Details
 * - Lines of Business
 * - Document Uploads
 */

import { z } from "zod"

/**
 * Schema for document uploads
 */
export const documentSchema = z.object({
  file: z.any().nullable(),
  uploaded: z.boolean(),
})

/**
 * Main Permit Form Schema
 * Validates all fields across all steps of the permit application
 * Uses conditional validation - owner fields only required when ownerType is "new"
 */
export const permitFormSchema = z.object({
  // Permit Application Type - Top-level selection
  permitApplicationType: z.enum(["New", "Renewal", "Additional"]),

  // Business Owner Information
  ownerType: z.enum(["existing", "new"]),
  selectedOwnerId: z.string().optional(),
  profilePhoto: z.any().nullable().optional(),
  firstName: z.string().optional(),
  middleName: z.string().optional(),
  lastName: z.string().optional(),
  birthDate: z.string().optional(),
  civilStatus: z.string().optional(),
  gender: z.string().optional(),
  citizenship: z.string().optional(),
  tin: z.string().optional(), // Optional field
  mobile: z.string().optional(),
  email: z.string().optional(),

  // Business Owner Address (Hierarchical Location System)
  address: z.string().optional(), // Optional field
  provinceId: z.string().optional(),
  cityId: z.string().optional(),
  barangayId: z.string().optional(),

  // Business Owner Type Classification
  businessOwnerType: z.enum(["Single", "Group"]),
  businessOwnerGroupName: z.string().optional(),

  // Business Information
  selectedBusinessId: z.string().optional(),
  businessName: z.string().optional(),
  businessArea: z.number().min(1, "Business area is required").positive("Must be a positive number").optional(),
  propertyIndexNumber: z.string().optional(),
  permitPaymentCadence: z.string().optional(),
  maleEmployeeCount: z.number().min(0, "Male employee count must be 0 or greater").optional(),
  femaleEmployeeCount: z.number().min(0, "Female employee count must be 0 or greater").optional(),
  businessContactNumber: z.string().optional(),
  dateEstablished: z.string().optional(),
  dateStarted: z.string().optional(),
  registrationDate: z.string().optional(),
  registrationNumber: z.string().optional(),
  occupancy: z.string().optional(),
  ownershipType: z.string().optional(),
  groupName: z.string().optional(), // Optional - required for Partnership/Corporation/Cooperative
  businessEmail: z.string().optional(),

  // Business Address (Hierarchical Location System)
  businessAddress: z.string().optional(),
  businessBuildingName: z.string().optional(),
  businessProvinceId: z.string().optional(),
  businessCityId: z.string().optional(),
  businessBarangayId: z.string().optional(),

  // Documents
  documents: z.record(z.string(), documentSchema).optional(),

  // Mode of Payment (required field)
  modeOfPayment: z.enum(["Annually", "Semi-Annually", "Quarterly"], {
    message: "Mode of payment is required",
  }),
}).superRefine((data, ctx) => {
  // Only validate owner fields when creating a new owner
  if (data.ownerType === "new") {
    if (!data.firstName || data.firstName.length === 0) {
      ctx.addIssue({
        code: "custom",
        message: "First name is required",
        path: ["firstName"],
      })
    }
    if (!data.lastName || data.lastName.length === 0) {
      ctx.addIssue({
        code: "custom",
        message: "Last name is required",
        path: ["lastName"],
      })
    }
    if (!data.birthDate || data.birthDate.length === 0) {
      ctx.addIssue({
        code: "custom",
        message: "Birth date is required",
        path: ["birthDate"],
      })
    }
    if (!data.civilStatus || data.civilStatus.length === 0) {
      ctx.addIssue({
        code: "custom",
        message: "Civil status is required",
        path: ["civilStatus"],
      })
    }
    if (!data.gender || data.gender.length === 0) {
      ctx.addIssue({
        code: "custom",
        message: "Gender is required",
        path: ["gender"],
      })
    }
    if (!data.citizenship || data.citizenship.length === 0) {
      ctx.addIssue({
        code: "custom",
        message: "Citizenship is required",
        path: ["citizenship"],
      })
    }
    // TIN is now optional - no validation required
    if (!data.mobile || data.mobile.length === 0) {
      ctx.addIssue({
        code: "custom",
        message: "Mobile number is required",
        path: ["mobile"],
      })
    }
    if (!data.email || data.email.length === 0) {
      ctx.addIssue({
        code: "custom",
        message: "Email is required",
        path: ["email"],
      })
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      ctx.addIssue({
        code: "custom",
        message: "Invalid email address",
        path: ["email"],
      })
    }
    // Address is now optional - no validation required
    if (!data.provinceId || data.provinceId.length === 0) {
      ctx.addIssue({
        code: "custom",
        message: "Province is required",
        path: ["provinceId"],
      })
    }
    if (!data.cityId || data.cityId.length === 0) {
      ctx.addIssue({
        code: "custom",
        message: "City/Municipality is required",
        path: ["cityId"],
      })
    }
    if (!data.barangayId || data.barangayId.length === 0) {
      ctx.addIssue({
        code: "custom",
        message: "Barangay is required",
        path: ["barangayId"],
      })
    }
  }

  // Validate existing owner has selectedOwnerId
  if (data.ownerType === "existing" && (!data.selectedOwnerId || data.selectedOwnerId.length === 0)) {
    ctx.addIssue({
      code: "custom",
      message: "Please select a business owner",
      path: ["selectedOwnerId"],
    })
  }

  // Validate groupName based on ownership type (conditional requirement)
  // Partnership, Corporation, or Cooperative ownership types require a company/group name
  const normalizedOwnershipType = data.ownershipType?.toLowerCase().replace(/\s+/g, "-")
  const requiresGroupName = ["partnership", "corporation", "cooperative"].includes(normalizedOwnershipType || "")

  if (requiresGroupName) {
    if (!data.groupName || data.groupName.trim().length === 0) {
      const ownershipTypeDisplay = data.ownershipType || "this ownership type"
      ctx.addIssue({
        code: "custom",
        message: `Company/Organization name is required for ${ownershipTypeDisplay}`,
        path: ["groupName"],
      })
    }
  }

  // Validate businessOwnerGroupName is required for Group owner type
  if (data.businessOwnerType === "Group" && (!data.businessOwnerGroupName || data.businessOwnerGroupName.trim().length === 0)) {
    ctx.addIssue({
      code: "custom",
      message: "Group name is required for group owners",
      path: ["businessOwnerGroupName"],
    })
  }

  // Validate business fields (required for submission)
  if (!data.businessName || data.businessName.length === 0) {
    ctx.addIssue({
      code: "custom",
      message: "Business name is required",
      path: ["businessName"],
    })
  }

  if (!data.businessArea || data.businessArea <= 0) {
    ctx.addIssue({
      code: "custom",
      message: "Business area is required",
      path: ["businessArea"],
    })
  }

  if (!data.dateStarted || data.dateStarted.length === 0) {
    ctx.addIssue({
      code: "custom",
      message: "Date started is required",
      path: ["dateStarted"],
    })
  }

  if (!data.ownershipType || data.ownershipType.length === 0) {
    ctx.addIssue({
      code: "custom",
      message: "Ownership type is required",
      path: ["ownershipType"],
    })
  }

  // Validate business address fields
  if (!data.businessAddress || data.businessAddress.length === 0) {
    ctx.addIssue({
      code: "custom",
      message: "Business address is required",
      path: ["businessAddress"],
    })
  }

  if (!data.businessProvinceId || data.businessProvinceId.length === 0) {
    ctx.addIssue({
      code: "custom",
      message: "Business province is required",
      path: ["businessProvinceId"],
    })
  }

  if (!data.businessCityId || data.businessCityId.length === 0) {
    ctx.addIssue({
      code: "custom",
      message: "Business city/municipality is required",
      path: ["businessCityId"],
    })
  }

  if (!data.businessBarangayId || data.businessBarangayId.length === 0) {
    ctx.addIssue({
      code: "custom",
      message: "Business barangay is required",
      path: ["businessBarangayId"],
    })
  }

  // Validate business building name
  if (!data.businessBuildingName || data.businessBuildingName.length === 0) {
    ctx.addIssue({
      code: "custom",
      message: "Business building name is required",
      path: ["businessBuildingName"],
    })
  }

  // Documents are now optional - no validation required
  // Users can submit applications without uploading documents
  // Documents can be added later during the assessment phase
  // The following validation is removed to make documents optional:
  // - Application Form
  // - Barangay Clearance
  // - DTI Certificate (Sole Proprietorship)
  // - SEC Certificate (Partnership/Corporation)
  // - Articles of Partnership/Incorporation
  // - By-Laws (Corporation)
  // - GIS (Corporation)
  // - CDA Certificate (Cooperative)
  // - Certificate of Registration (Cooperative)

  // Legacy validation code removed - documents are optional
  // Uncomment below to re-enable document validation if needed
  /*
  if (!data.documents || Object.keys(data.documents).length === 0) {
    ctx.addIssue({
      code: "custom",
      message: "Required documents must be uploaded",
      path: ["documents"],
    })
  } else {
    // Check for application form and barangay clearance (always required)
    if (!data.documents.applicationForm || !data.documents.applicationForm.uploaded) {
      ctx.addIssue({
        code: "custom",
        message: "Permit Application Form is required",
        path: ["documents"],
      })
    }

    if (!data.documents.barangayClearance || !data.documents.barangayClearance.uploaded) {
      ctx.addIssue({
        code: "custom",
        message: "Barangay Clearance is required",
        path: ["documents"],
      })
    }

    // Validate ownership-specific documents
    const normalizedOwnershipType = data.ownershipType?.toLowerCase().replace(/\s+/g, "-")

    if (normalizedOwnershipType === "sole-proprietorship") {
      if (!data.documents.dtiCertificate || !data.documents.dtiCertificate.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "DTI Certificate is required for Sole Proprietorship",
          path: ["documents"],
        })
      }
    }

    if (normalizedOwnershipType === "partnership") {
      if (!data.documents.secCertificate || !data.documents.secCertificate.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "SEC Certificate is required for Partnership",
          path: ["documents"],
        })
      }
      if (!data.documents.articlesOfPartnership || !data.documents.articlesOfPartnership.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "Articles of Partnership is required",
          path: ["documents"],
        })
      }
    }

    if (normalizedOwnershipType === "corporation") {
      if (!data.documents.secCertificate || !data.documents.secCertificate.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "SEC Certificate is required for Corporation",
          path: ["documents"],
        })
      }
      if (!data.documents.articlesOfIncorporation || !data.documents.articlesOfIncorporation.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "Articles of Incorporation is required",
          path: ["documents"],
        })
      }
      if (!data.documents.bylaws || !data.documents.bylaws.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "By-Laws is required for Corporation",
          path: ["documents"],
        })
      }
      if (!data.documents.gis || !data.documents.gis.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "General Information Sheet (GIS) is required",
          path: ["documents"],
        })
      }
    }

    if (normalizedOwnershipType === "cooperative") {
      if (!data.documents.cdaCertificate || !data.documents.cdaCertificate.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "CDA Certificate is required for Cooperative",
          path: ["documents"],
        })
      }
      if (!data.documents.articlesOfCooperation || !data.documents.articlesOfCooperation.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "Articles of Cooperation is required",
          path: ["documents"],
        })
      }
      if (!data.documents.bylaws || !data.documents.bylaws.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "By-Laws is required for Cooperative",
          path: ["documents"],
        })
      }
    }

    if (normalizedOwnershipType === "religious") {
      if (!data.documents.secCertificate || !data.documents.secCertificate.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "SEC Certificate is required for Religious Organization",
          path: ["documents"],
        })
      }
      if (!data.documents.articlesOfIncorporation || !data.documents.articlesOfIncorporation.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "Articles of Incorporation is required",
          path: ["documents"],
        })
      }
      if (!data.documents.bylaws || !data.documents.bylaws.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "By-Laws is required for Religious Organization",
          path: ["documents"],
        })
      }
    }

    if (normalizedOwnershipType === "non-profit") {
      if (!data.documents.secCertificate || !data.documents.secCertificate.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "SEC Certificate is required for Non-Profit Organization",
          path: ["documents"],
        })
      }
      if (!data.documents.articlesOfIncorporation || !data.documents.articlesOfIncorporation.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "Articles of Incorporation is required",
          path: ["documents"],
        })
      }
      if (!data.documents.bylaws || !data.documents.bylaws.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "By-Laws is required for Non-Profit Organization",
          path: ["documents"],
        })
      }
      if (!data.documents.gis || !data.documents.gis.uploaded) {
        ctx.addIssue({
          code: "custom",
          message: "General Information Sheet (GIS) is required",
          path: ["documents"],
        })
      }
    }
  }
  */
})

/**
 * Type inference from schema - use this instead of manually defining types
 */
export type PermitFormSchema = z.infer<typeof permitFormSchema>

/**
 * Default values for the permit form
 */
export const permitFormDefaultValues: Partial<PermitFormSchema> = {
  permitApplicationType: "New",
  ownerType: "new",
  selectedOwnerId: "",
  profilePhoto: null,
  firstName: "",
  middleName: "",
  lastName: "",
  birthDate: "",
  civilStatus: "",
  gender: "",
  citizenship: "",
  tin: "", // Optional field
  mobile: "",
  address: "", // Optional field
  provinceId: "",
  cityId: "",
  barangayId: "",
  email: "",
  selectedBusinessId: "",
  businessName: "",
  businessArea: 1,
  propertyIndexNumber: "",
  permitPaymentCadence: "",
  maleEmployeeCount: 0,
  femaleEmployeeCount: 0,
  businessContactNumber: "",
  dateEstablished: "",
  dateStarted: "",
  registrationDate: "",
  registrationNumber: "",
  occupancy: "",
  ownershipType: "sole-proprietorship",
  groupName: "", // Business group name (Partnership/Corporation/Cooperative)
  businessEmail: "",
  businessAddress: "",
  businessBuildingName: "",
  businessProvinceId: "",
  businessCityId: "",
  businessBarangayId: "",
  documents: {},
  businessOwnerType: "Single",
  businessOwnerGroupName: "",
  modeOfPayment: undefined, // Mode of payment for permit fees
}
