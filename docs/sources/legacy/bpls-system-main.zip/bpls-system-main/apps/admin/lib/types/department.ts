/**
 * Department Type Definitions
 *
 * Type definitions for the departments table in Convex.
 * **SOURCE OF TRUTH**: convex/schema.ts - departments table
 *
 * Architecture:
 * - Departments are primary entities with certificate information embedded
 * - Each department has a dedicated review portal (accessed via slug)
 * - Certificate data (certificateName, description, isActive) is part of the department
 * - Fees are linked to departments via the department-fees system
 *
 * Migration Notes:
 * - Clearances table removed - all data consolidated into departments (2025-01-20)
 * - Department now includes: certificateName, description, isActive fields
 */

import type { Doc } from "@repo/backend/convex/_generated/dataModel"
import type { LucideIcon } from "lucide-react"

/**
 * Department record from Convex database
 * Derived from: Doc<"departments"> in convex/schema.ts
 *
 * Now includes certificate information:
 * - certificateName: string (e.g., "Sanitary Permit")
 * - description: string (department/certificate description)
 * - isActive: boolean (whether department is active)
 */
export type Department = Doc<"departments"> & {
  shortName?: string
  slug?: string
  icon?: DepartmentIcon
  officerName?: string
  officerEmail?: string
  certificateName?: string
}

/**
 * Department icon options (must match schema enum)
 */
export type DepartmentIcon =
  | "Shield"
  | "Flame"
  | "Building2"
  | "TreePine"
  | "Wrench"
  | "Building"
  | "FileCheck"
  | "Briefcase"

/**
 * Department form input (for creating/editing departments)
 * Used by AddDepartmentDialog and similar forms
 * UPDATED: Now includes certificate fields (certificateName, description, isActive)
 */
export interface DepartmentFormInput {
  name: string
  shortName: string
  slug: string
  icon: DepartmentIcon
  officerName: string
  officerEmail: string
  certificateName: string
  description: string
  isActive?: boolean
}

/**
 * Department update input
 * Used for updating existing department details (excludes slug - used for routing)
 * UPDATED: Now includes certificate fields
 */
export interface DepartmentUpdateInput {
  name?: string
  shortName?: string
  icon?: DepartmentIcon
  officerName?: string
  officerEmail?: string
  certificateName?: string
  description?: string
  isActive?: boolean
}

/**
 * Department update result
 * Returned by updateDepartment mutation
 */
export interface DepartmentUpdateResult {
  id: string
  message: string
}

/**
 * Department with statistics (for listing views)
 * @deprecated clearanceCount fields are no longer relevant (1:1 department:clearance)
 */
export interface DepartmentWithStats extends Department {
  clearanceCount: number
  activeClearanceCount: number
}

/**
 * Department summary (minimal info for dropdowns/cards)
 */
export type DepartmentSummary = Pick<Department, "_id" | "name" | "shortName" | "slug" | "icon">

/**
 * Department Configuration for UI (legacy compatibility)
 * Maps database department to UI configuration
 * @deprecated Use Department type directly and derive UI props as needed
 */
export interface DepartmentConfig {
  /** Full department name */
  name: string
  /** Abbreviated department name */
  shortName: string
  /** URL-safe slug for dynamic routing (e.g., "sanitary", "bfp") */
  slug: string
  /** Lucide icon component for department branding */
  icon: LucideIcon
  /** URL route prefix (e.g., "departments/sanitary") */
  route: string
  /** Page title displayed in the review interface */
  pageTitle: string
  /** Description text shown below page title */
  description: string
  /** Department user information */
  user: DepartmentUser
}

/**
 * Department User Information
 * Represents the logged-in user for a department
 */
export interface DepartmentUser {
  /** User's full name */
  name: string
  /** User's email address */
  email: string
  /** Optional avatar image path */
  avatar?: string
}

/**
 * Department Review Statistics
 */
export interface DepartmentStats {
  /** Total number of pending permits */
  totalPending: number
  /** Number of permits awaiting review */
  awaitingReview: number
  /** Number of permits approved today */
  approvedToday: number
}

/**
 * Department Permit
 * Represents a permit awaiting department clearance
 */
export interface DepartmentPermit {
  /** Permit application ID */
  id: string
  /** Permit application number */
  applicationNumber: string
  /** Business name */
  businessName: string
  /** Business owner name */
  ownerName: string
  /** Date submitted */
  submittedAt: string
  /** Application date */
  applicationDate?: string
  /** Current status */
  status: string
  /** Certificate name for this department */
  certificateName: string
}
