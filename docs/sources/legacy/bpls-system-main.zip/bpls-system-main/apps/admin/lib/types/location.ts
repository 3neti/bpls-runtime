/**
 * Location type definitions - derived from Convex schema
 * Source of truth: convex/schema.ts (provinces, cities, barangays tables)
 */

import type { Doc } from "@repo/backend/convex/_generated/dataModel"

/**
 * Province - Top-level administrative division
 * Example: "Zamboanga del Sur"
 */
export type Province = Doc<"provinces">

/**
 * City/Municipality - Second-level administrative division
 * Belongs to a province
 * Example: "Ipil"
 */
export type City = Doc<"cities">

/**
 * Barangay - Lowest-level administrative division
 * Belongs to a city/municipality
 * Example: "Poblacion"
 */
export type Barangay = Doc<"barangays">

/**
 * Complete location hierarchy
 * Used for displaying full addresses
 */
export interface LocationHierarchy {
  province: Province | null
  city: City | null
  barangay: Barangay | null
}

/**
 * Location form values (for create/edit dialogs)
 */
export interface ProvinceFormValues {
  name: string
  code?: string
}

export interface CityFormValues {
  name: string
  provinceId: string
  code?: string
}

export interface BarangayFormValues {
  name: string
  cityId: string
  code?: string
}

/**
 * Helper type for location IDs in forms
 * Used in business and business owner forms
 */
export interface AddressLocationIds {
  provinceId: string
  cityId: string
  barangayId: string
}
