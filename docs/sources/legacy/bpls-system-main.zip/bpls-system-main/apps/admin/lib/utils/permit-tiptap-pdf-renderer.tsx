/**
 * TipTap JSON -> react-pdf Renderer
 *
 * Walks a TipTap JSON document tree and produces react-pdf <Text> elements
 * with proper font variant mapping (react-pdf needs explicit font names like
 * "Helvetica-Bold", not CSS fontWeight).
 *
 * Integrates with the existing macro system: each text node's content goes
 * through parsePermitTemplate() for macro replacement. Special macros
 * become [[MARKER]] text which the parent renderer swaps with components.
 */

import React from "react";
import { Text, View, Font } from "@react-pdf/renderer";
import {
  parseTipTapContent,
  type TipTapDoc,
  type TipTapNode,
  type TipTapMark,
} from "./permit-tiptap-converter";
import {
  parsePermitTemplate,
  type PermitMacroData,
} from "./permit-template-renderer";

// Register Century Gothic custom font
Font.register({
  family: "Century Gothic",
  fonts: [
    { src: "/fonts/Century Gothic Font/centurygothic.ttf", fontWeight: "normal" },
    { src: "/fonts/Century Gothic Font/centurygothic_bold.ttf", fontWeight: "bold" },
  ],
});

// Font variant mapping - react-pdf needs explicit font family names
const FONT_MAP: Record<
  string,
  { normal: string; bold: string; italic: string; boldItalic: string }
> = {
  Helvetica: {
    normal: "Helvetica",
    bold: "Helvetica-Bold",
    italic: "Helvetica-Oblique",
    boldItalic: "Helvetica-BoldOblique",
  },
  "Times-Roman": {
    normal: "Times-Roman",
    bold: "Times-Bold",
    italic: "Times-Italic",
    boldItalic: "Times-BoldItalic",
  },
  Courier: {
    normal: "Courier",
    bold: "Courier-Bold",
    italic: "Courier-Oblique",
    boldItalic: "Courier-BoldOblique",
  },
  "Century Gothic": {
    normal: "Century Gothic",
    bold: "Century Gothic",
    italic: "Century Gothic",
    boldItalic: "Century Gothic",
  },
};

/**
 * Resolve font family from TipTap marks (bold/italic) into the correct
 * react-pdf font variant name.
 */
function resolveFontFamily(
  marks: TipTapMark[] | undefined,
  baseFontFamily: string
): string {
  const isBold = marks?.some((m) => m.type === "bold") ?? false;
  const isItalic = marks?.some((m) => m.type === "italic") ?? false;

  // Check if a fontFamily mark overrides the base
  const fontFamilyMark = marks?.find((m) => m.type === "textStyle");
  const fontFamily =
    (fontFamilyMark?.attrs?.fontFamily as string) || baseFontFamily;

  const map = FONT_MAP[fontFamily] || FONT_MAP["Helvetica"];

  if (isBold && isItalic) return map.boldItalic;
  if (isBold) return map.bold;
  if (isItalic) return map.italic;
  return map.normal;
}

/**
 * Get text decoration from marks (underline, strikethrough, or both)
 */
function getTextDecoration(
  marks: TipTapMark[] | undefined
): "underline" | "line-through" | "underline line-through" | undefined {
  const isUnderline = marks?.some((m) => m.type === "underline") ?? false;
  const isStrike = marks?.some((m) => m.type === "strike") ?? false;
  if (isUnderline && isStrike) return "underline line-through";
  if (isUnderline) return "underline";
  if (isStrike) return "line-through";
  return undefined;
}

/**
 * Get text color from textStyle marks
 */
function getTextColor(marks: TipTapMark[] | undefined): string | undefined {
  const textStyleMark = marks?.find((m) => m.type === "textStyle");
  return (textStyleMark?.attrs?.color as string) || undefined;
}

/**
 * Get text alignment from paragraph attrs
 */
function getTextAlign(
  attrs: Record<string, unknown> | undefined
): "left" | "center" | "right" | "justify" | undefined {
  if (!attrs?.textAlign) return undefined;
  return attrs.textAlign as "left" | "center" | "right" | "justify";
}

/**
 * Render a TipTap JSON document to react-pdf elements.
 * Returns an array of <Text> elements (one per paragraph).
 *
 * Each text node within a paragraph gets its own nested <Text> with
 * the correct font variant and text decoration.
 */
export function renderTipTapToPdf(
  doc: TipTapDoc,
  macroData: PermitMacroData,
  baseFontFamily: string,
  baseFontSize: number
): React.ReactNode[] {
  if (!doc || !doc.content) return [];

  return doc.content.map((node, paragraphIndex) => {
    if (node.type !== "paragraph") return null;

    const textAlign = getTextAlign(node.attrs);

    // Empty paragraph
    if (!node.content || node.content.length === 0) {
      return (
        <Text
          key={paragraphIndex}
          style={{
            marginBottom: 2,
            fontSize: baseFontSize,
            textAlign,
          }}
        >
          {"\u00A0"}
        </Text>
      );
    }

    // Paragraph with text nodes
    return (
      <Text
        key={paragraphIndex}
        style={{
          marginBottom: 2,
          fontSize: baseFontSize,
          textAlign,
        }}
      >
        {node.content.map((textNode, textIndex) =>
          renderTextNode(textNode, textIndex, macroData, baseFontFamily)
        )}
      </Text>
    );
  });
}

/**
 * Render a single text node with its marks applied as styles
 */
function renderTextNode(
  textNode: TipTapNode,
  index: number,
  macroData: PermitMacroData,
  baseFontFamily: string
): React.ReactNode {
  if (textNode.type !== "text" || !textNode.text) return null;

  // Run macro replacement on the text content
  const resolvedText = parsePermitTemplate(textNode.text, macroData);

  const fontFamily = resolveFontFamily(textNode.marks, baseFontFamily);
  const textDecoration = getTextDecoration(textNode.marks);
  const color = getTextColor(textNode.marks);

  // Extract per-text fontSize from textStyle marks
  const textStyleMark = textNode.marks?.find((m) => m.type === "textStyle");
  const fontSizeRaw = textStyleMark?.attrs?.fontSize;
  const fontSize = fontSizeRaw ? parseFloat(String(fontSizeRaw)) : undefined;

  // For registered fonts (e.g., Century Gothic), react-pdf needs fontWeight/fontStyle
  // in the style to select the correct variant
  const isBold = textNode.marks?.some((m) => m.type === "bold") ?? false;
  const isItalic = textNode.marks?.some((m) => m.type === "italic") ?? false;

  // Preserve whitespace: replace regular spaces with non-breaking spaces
  const displayText = resolvedText.replace(/ /g, "\u00A0");

  return (
    <Text
      key={index}
      style={{
        fontFamily,
        fontWeight: isBold ? "bold" : undefined,
        fontStyle: isItalic ? "italic" : undefined,
        textDecoration,
        fontSize,
        color,
      }}
    >
      {displayText}
    </Text>
  );
}

/**
 * Helpers interface for special macro rendering
 */
interface TemplateHelpers {
  renderLogo: () => React.ReactNode;
  renderSeal: () => React.ReactNode;
  renderQrCode: () => React.ReactNode;
  renderLinesOfBusiness: () => React.ReactNode;
}

/**
 * High-level function to render a template string (TipTap JSON or plain text)
 * into react-pdf elements, with special macro marker handling.
 *
 * This replaces the old renderTemplateContent() + renderLines() approach.
 *
 * Flow:
 * 1. Parse template via parseTipTapContent() (auto-detects format)
 * 2. Render to PDF elements via renderTipTapToPdf()
 * 3. Scan rendered output for [[MARKER]] text and split/insert special components
 */
export function renderTipTapTemplateContent(
  template: string,
  macroData: PermitMacroData,
  baseFontFamily: string,
  baseFontSize: number,
  helpers: TemplateHelpers
): React.ReactNode {
  if (!template) return null;

  const doc = parseTipTapContent(template);
  const pdfElements = renderTipTapToPdf(doc, macroData, baseFontFamily, baseFontSize);

  // Now scan for [[MARKER]] patterns in the rendered elements.
  // We need to check each paragraph's text for markers and split accordingly.
  const result: React.ReactNode[] = [];
  let key = 0;

  for (let i = 0; i < pdfElements.length; i++) {
    const element = pdfElements[i];
    if (!element) continue;

    // Check if this element (paragraph) contains a special marker.
    // Index-based lookup ensures correct correspondence with doc.content.
    const paragraphNode = doc.content[i];
    if (!paragraphNode) {
      result.push(React.cloneElement(element as React.ReactElement, { key: key++ }));
      continue;
    }

    const paragraphText = getParagraphText(paragraphNode, macroData);
    const markerMatch = paragraphText.match(
      /\[\[(LOGO|MUNICIPAL_SEAL|QR_CODE|LINES_OF_BUSINESS)\]\]/
    );

    if (markerMatch) {
      // This paragraph contains a special marker
      // Split around the marker and render everything in a single flex row
      // so spaces/characters before the macro appear inline (to the left),
      // and paragraph alignment controls horizontal positioning.
      const markerType = markerMatch[1];
      const markerFull = `[[${markerType}]]`;
      const beforeIdx = paragraphText.indexOf(markerFull);
      // Preserve spaces - don't trim, so typed spaces shift the component
      const beforeText = paragraphText.substring(0, beforeIdx);
      const afterText = paragraphText.substring(beforeIdx + markerFull.length);

      // Derive alignment from the TipTap paragraph's textAlign attribute
      const textAlign = getTextAlign(paragraphNode?.attrs);
      const justifyContent = textAlign === "right" ? "flex-end" as const
                           : textAlign === "center" ? "center" as const
                           : "flex-start" as const;

      // Build row children: [beforeText] [component] [afterText]
      const rowChildren: React.ReactNode[] = [];
      let childKey = 0;

      if (beforeText) {
        rowChildren.push(
          <Text key={childKey++} style={{ fontSize: baseFontSize }}>
            {beforeText.replace(/ /g, "\u00A0")}
          </Text>
        );
      }

      // Get the special component
      let specialComponent: React.ReactNode = null;
      switch (markerType) {
        case "LOGO":
          specialComponent = helpers.renderLogo();
          break;
        case "MUNICIPAL_SEAL":
          specialComponent = helpers.renderSeal();
          break;
        case "QR_CODE":
          specialComponent = helpers.renderQrCode();
          break;
        case "LINES_OF_BUSINESS":
          specialComponent = helpers.renderLinesOfBusiness();
          break;
      }

      if (specialComponent) {
        rowChildren.push(
          <View key={childKey++}>{specialComponent}</View>
        );
      }

      if (afterText) {
        rowChildren.push(
          <Text key={childKey++} style={{ fontSize: baseFontSize }}>
            {afterText.replace(/ /g, "\u00A0")}
          </Text>
        );
      }

      // Single flex row: spaces push inline, justifyContent handles alignment
      result.push(
        <View key={key++} style={{ flexDirection: "row", justifyContent, alignItems: "center", marginVertical: 4 }}>
          {rowChildren}
        </View>
      );
    } else {
      // No marker, render the styled paragraph as-is
      result.push(
        React.cloneElement(element as React.ReactElement, { key: key++ })
      );
    }
  }

  return <>{result}</>;
}

/**
 * Extract plain text from a paragraph node after macro replacement.
 * Used to detect [[MARKER]] patterns in rendered output.
 */
function getParagraphText(
  node: TipTapNode,
  macroData: PermitMacroData
): string {
  if (!node.content) return "";
  return node.content
    .map((child) => {
      if (child.type === "text" && child.text) {
        return parsePermitTemplate(child.text, macroData);
      }
      return "";
    })
    .join("");
}
