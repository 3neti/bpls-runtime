/**
 * Clearance Form Schema (Simplified)
 *
 * Zod validation schema for adding/editing clearances
 * Simplified to only require name and description
 */

import { z } from "zod"

/**
 * Clearance Form Schema (Simplified)
 * Requires name, icon, and optional description
 */
export const clearanceFormSchema = z.object({
  name: z
    .string()
    .min(1, "Clearance name is required")
    .min(2, "Clearance name must be at least 2 characters")
    .max(100, "Clearance name cannot exceed 100 characters"),

  icon: z.enum(
    ["Shield", "Flame", "Building2", "TreePine", "Wrench", "Building", "FileCheck", "Briefcase"],
    {
      message: "Please select an icon",
    }
  ),

  description: z
    .string()
    .max(500, "Description cannot exceed 500 characters"),
})

/**
 * Inferred TypeScript type from the schema
 */
export type ClearanceFormSchema = z.infer<typeof clearanceFormSchema>

/**
 * Default values for the form
 */
export const clearanceFormDefaultValues: ClearanceFormSchema = {
  name: "",
  icon: "FileCheck",
  description: "",
}

/**
 * @deprecated Use clearanceFormSchema instead
 * Legacy schema kept for backward compatibility
 */
export const departmentFormSchema = z.object({
  // Clearance Information
  clearanceName: z
    .string()
    .min(1, "Clearance name is required")
    .min(3, "Clearance name must be at least 3 characters")
    .max(100, "Clearance name cannot exceed 100 characters"),

  certificateName: z
    .string()
    .min(1, "Certificate name is required")
    .min(3, "Certificate name must be at least 3 characters")
    .max(100, "Certificate name cannot exceed 100 characters"),

  description: z
    .string()
    .min(1, "Description is required")
    .min(10, "Description must be at least 10 characters")
    .max(500, "Description cannot exceed 500 characters"),

  // Department Information
  departmentFullName: z
    .string()
    .min(1, "Department full name is required")
    .min(3, "Department name must be at least 3 characters")
    .max(100, "Department name cannot exceed 100 characters"),

  departmentShortName: z
    .string()
    .min(1, "Department short name is required")
    .min(2, "Short name must be at least 2 characters")
    .max(50, "Short name cannot exceed 50 characters"),

  departmentSlug: z
    .string()
    .min(1, "Department slug is required")
    .regex(/^[a-z0-9-]+$/, "Slug must be lowercase letters, numbers, and hyphens only")
    .min(2, "Slug must be at least 2 characters")
    .max(50, "Slug cannot exceed 50 characters"),

  // Icon Selection
  icon: z.enum(
    ["Shield", "Flame", "Building2", "TreePine", "Wrench", "Building", "FileCheck", "Briefcase"],
    {
      message: "Please select an icon",
    }
  ),

  // Officer Information
  officerName: z
    .string()
    .min(1, "Officer name is required")
    .min(3, "Officer name must be at least 3 characters")
    .max(100, "Officer name cannot exceed 100 characters"),

  officerEmail: z
    .string()
    .min(1, "Officer email is required")
    .email("Please enter a valid email address"),
})

/**
 * @deprecated Use ClearanceFormSchema instead
 */
export type DepartmentFormSchema = z.infer<typeof departmentFormSchema>

/**
 * @deprecated Use clearanceFormDefaultValues instead
 */
export const departmentFormDefaultValues: Partial<DepartmentFormSchema> = {
  clearanceName: "",
  certificateName: "",
  description: "",
  departmentFullName: "",
  departmentShortName: "",
  departmentSlug: "",
  icon: "Shield",
  officerName: "",
  officerEmail: "",
}
