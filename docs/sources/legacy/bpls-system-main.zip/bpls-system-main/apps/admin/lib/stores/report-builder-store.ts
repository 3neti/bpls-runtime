/**
 * Report Builder Zustand Store
 *
 * State management for the dynamic report builder with localStorage persistence.
 * Manages report configuration, selected dimensions/metrics, filters, and UI state.
 */

import { create } from "zustand"
import { persist, createJSONStorage } from "zustand/middleware"
import type {
  ResourceType,
  ReportConfiguration,
  FilterGroup,
  DateRange,
  SortConfig,
  PaginationConfig,
} from "@/lib/types/report-builder"
import { RESOURCE_CONFIGS } from "@/lib/config/report-resources"

// ===========================================
// STORE TYPES
// ===========================================

interface ReportBuilderState {
  // Core configuration
  resourceType: ResourceType | null
  selectedDimensions: string[]
  selectedMetrics: string[]
  filters: FilterGroup | null
  dateRange: DateRange | null
  sort: SortConfig | null
  pagination: PaginationConfig

  // UI state
  isPreviewOpen: boolean
  isDirty: boolean
  lastSavedAt: string | null
  draftName: string | null

  // Actions - Resource
  setResourceType: (type: ResourceType) => void
  clearResourceType: () => void

  // Actions - Dimensions
  setDimensions: (dimensions: string[]) => void
  addDimension: (dimensionId: string) => void
  removeDimension: (dimensionId: string) => void
  toggleDimension: (dimensionId: string) => void
  clearDimensions: () => void
  setDefaultDimensions: () => void

  // Actions - Metrics
  setMetrics: (metrics: string[]) => void
  addMetric: (metricId: string) => void
  removeMetric: (metricId: string) => void
  toggleMetric: (metricId: string) => void
  clearMetrics: () => void
  setDefaultMetrics: () => void

  // Actions - Filters
  setFilters: (filters: FilterGroup | null) => void
  clearFilters: () => void

  // Actions - Date Range
  setDateRange: (dateRange: DateRange | null) => void
  clearDateRange: () => void

  // Actions - Sorting
  setSort: (sort: SortConfig | null) => void
  clearSort: () => void

  // Actions - Pagination
  setPage: (page: number) => void
  setPageSize: (pageSize: number) => void
  resetPagination: () => void

  // Actions - UI
  setPreviewOpen: (open: boolean) => void
  setDraftName: (name: string | null) => void
  markAsSaved: () => void
  markAsDirty: () => void

  // Actions - Full Configuration
  getConfiguration: () => ReportConfiguration | null
  loadConfiguration: (config: ReportConfiguration) => void
  resetAll: () => void
}

// ===========================================
// INITIAL STATE
// ===========================================

const DEFAULT_PAGINATION: PaginationConfig = {
  page: 1,
  pageSize: 25,
}

const getInitialState = () => ({
  resourceType: null as ResourceType | null,
  selectedDimensions: [] as string[],
  selectedMetrics: [] as string[],
  filters: null as FilterGroup | null,
  dateRange: null as DateRange | null,
  sort: null as SortConfig | null,
  pagination: DEFAULT_PAGINATION,
  isPreviewOpen: false,
  isDirty: false,
  lastSavedAt: null as string | null,
  draftName: null as string | null,
})

// ===========================================
// STORE IMPLEMENTATION
// ===========================================

export const useReportBuilderStore = create<ReportBuilderState>()(
  persist(
    (set, get) => ({
      ...getInitialState(),

      // Resource Actions
      setResourceType: (type) => {
        const config = RESOURCE_CONFIGS[type]
        set({
          resourceType: type,
          selectedDimensions: config.defaultDimensions,
          selectedMetrics: config.defaultMetrics,
          filters: null,
          dateRange: null,
          sort: null,
          pagination: DEFAULT_PAGINATION,
          isDirty: true,
        })
      },

      clearResourceType: () => {
        set({
          resourceType: null,
          selectedDimensions: [],
          selectedMetrics: [],
          filters: null,
          dateRange: null,
          sort: null,
          pagination: DEFAULT_PAGINATION,
          isDirty: true,
        })
      },

      // Dimension Actions
      setDimensions: (dimensions) => {
        set({ selectedDimensions: dimensions, isDirty: true })
      },

      addDimension: (dimensionId) => {
        const { selectedDimensions } = get()
        if (!selectedDimensions.includes(dimensionId)) {
          set({
            selectedDimensions: [...selectedDimensions, dimensionId],
            isDirty: true,
          })
        }
      },

      removeDimension: (dimensionId) => {
        const { selectedDimensions } = get()
        set({
          selectedDimensions: selectedDimensions.filter((d) => d !== dimensionId),
          isDirty: true,
        })
      },

      toggleDimension: (dimensionId) => {
        const { selectedDimensions } = get()
        if (selectedDimensions.includes(dimensionId)) {
          set({
            selectedDimensions: selectedDimensions.filter((d) => d !== dimensionId),
            isDirty: true,
          })
        } else {
          set({
            selectedDimensions: [...selectedDimensions, dimensionId],
            isDirty: true,
          })
        }
      },

      clearDimensions: () => {
        set({ selectedDimensions: [], isDirty: true })
      },

      setDefaultDimensions: () => {
        const { resourceType } = get()
        if (resourceType) {
          const config = RESOURCE_CONFIGS[resourceType]
          set({ selectedDimensions: config.defaultDimensions, isDirty: true })
        }
      },

      // Metric Actions
      setMetrics: (metrics) => {
        set({ selectedMetrics: metrics, isDirty: true })
      },

      addMetric: (metricId) => {
        const { selectedMetrics } = get()
        if (!selectedMetrics.includes(metricId)) {
          set({
            selectedMetrics: [...selectedMetrics, metricId],
            isDirty: true,
          })
        }
      },

      removeMetric: (metricId) => {
        const { selectedMetrics } = get()
        set({
          selectedMetrics: selectedMetrics.filter((m) => m !== metricId),
          isDirty: true,
        })
      },

      toggleMetric: (metricId) => {
        const { selectedMetrics } = get()
        if (selectedMetrics.includes(metricId)) {
          set({
            selectedMetrics: selectedMetrics.filter((m) => m !== metricId),
            isDirty: true,
          })
        } else {
          set({
            selectedMetrics: [...selectedMetrics, metricId],
            isDirty: true,
          })
        }
      },

      clearMetrics: () => {
        set({ selectedMetrics: [], isDirty: true })
      },

      setDefaultMetrics: () => {
        const { resourceType } = get()
        if (resourceType) {
          const config = RESOURCE_CONFIGS[resourceType]
          set({ selectedMetrics: config.defaultMetrics, isDirty: true })
        }
      },

      // Filter Actions
      setFilters: (filters) => {
        set({ filters, isDirty: true })
      },

      clearFilters: () => {
        set({ filters: null, isDirty: true })
      },

      // Date Range Actions
      setDateRange: (dateRange) => {
        set({ dateRange, isDirty: true })
      },

      clearDateRange: () => {
        set({ dateRange: null, isDirty: true })
      },

      // Sort Actions
      setSort: (sort) => {
        set({ sort, isDirty: true })
      },

      clearSort: () => {
        set({ sort: null, isDirty: true })
      },

      // Pagination Actions
      setPage: (page) => {
        set((state) => ({
          pagination: { ...state.pagination, page },
        }))
      },

      setPageSize: (pageSize) => {
        set((state) => ({
          pagination: { ...state.pagination, pageSize, page: 1 },
        }))
      },

      resetPagination: () => {
        set({ pagination: DEFAULT_PAGINATION })
      },

      // UI Actions
      setPreviewOpen: (open) => {
        set({ isPreviewOpen: open })
      },

      setDraftName: (name) => {
        set({ draftName: name, isDirty: true })
      },

      markAsSaved: () => {
        set({
          isDirty: false,
          lastSavedAt: new Date().toISOString(),
        })
      },

      markAsDirty: () => {
        set({ isDirty: true })
      },

      // Configuration Actions
      getConfiguration: () => {
        const {
          resourceType,
          selectedDimensions,
          selectedMetrics,
          filters,
          dateRange,
          sort,
          pagination,
        } = get()

        if (!resourceType) return null

        return {
          resourceType,
          dimensions: selectedDimensions,
          metrics: selectedMetrics,
          filters: filters || undefined,
          dateRange: dateRange || undefined,
          sort: sort || undefined,
          pagination,
        }
      },

      loadConfiguration: (config) => {
        set({
          resourceType: config.resourceType,
          selectedDimensions: config.dimensions,
          selectedMetrics: config.metrics,
          filters: config.filters || null,
          dateRange: config.dateRange || null,
          sort: config.sort || null,
          pagination: config.pagination || DEFAULT_PAGINATION,
          isDirty: false,
        })
      },

      resetAll: () => {
        set(getInitialState())
      },
    }),
    {
      name: "report-builder-storage",
      storage: createJSONStorage(() => {
        // SSR-safe localStorage access
        if (typeof window !== "undefined") {
          return localStorage
        }
        // Fallback for SSR - no-op storage
        return {
          getItem: () => null,
          setItem: () => {},
          removeItem: () => {},
        }
      }),
      // Only persist the configuration state, not UI state
      partialize: (state) => ({
        resourceType: state.resourceType,
        selectedDimensions: state.selectedDimensions,
        selectedMetrics: state.selectedMetrics,
        filters: state.filters,
        dateRange: state.dateRange,
        sort: state.sort,
        draftName: state.draftName,
      }),
    }
  )
)

// ===========================================
// SELECTOR HOOKS
// ===========================================

/**
 * Check if a dimension is selected
 */
export const useIsDimensionSelected = (dimensionId: string) => {
  return useReportBuilderStore((state) =>
    state.selectedDimensions.includes(dimensionId)
  )
}

/**
 * Check if a metric is selected
 */
export const useIsMetricSelected = (metricId: string) => {
  return useReportBuilderStore((state) =>
    state.selectedMetrics.includes(metricId)
  )
}

/**
 * Get the current resource configuration
 */
export const useCurrentResourceConfig = () => {
  const resourceType = useReportBuilderStore((state) => state.resourceType)
  return resourceType ? RESOURCE_CONFIGS[resourceType] : null
}

/**
 * Get active filter count
 */
export const useActiveFilterCount = () => {
  return useReportBuilderStore((state) => {
    if (!state.filters) return 0
    return state.filters.conditions.length + (state.filters.groups?.length || 0)
  })
}

/**
 * Check if the builder has valid configuration to generate report
 */
export const useCanGenerateReport = () => {
  return useReportBuilderStore(
    (state) =>
      state.resourceType !== null &&
      state.selectedDimensions.length > 0
  )
}
