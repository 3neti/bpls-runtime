/**
 * Clearance Configurations
 *
 * Central registry of all clearance types in the BPLS system.
 * Clearances are the primary entity - departments are properties of clearances.
 */

import { Shield, Flame, Building2, TreePine, Wrench } from "lucide-react"
import type { ClearanceConfig, ClearanceType } from "@/lib/types/clearance"

/**
 * Sanitary Clearance Configuration
 */
export const sanitaryClearance: ClearanceConfig = {
  id: "sanitary",
  type: "sanitary",
  name: "Sanitary Clearance",
  certificateName: "Sanitary Certificate",
  description: "Health and sanitation compliance certificate for business premises",
  department: {
    id: "dept-sanitary",
    name: "Sanitary Department",
    shortName: "Sanitary",
    slug: "sanitary",
    icon: Shield,
    officer: {
      name: "Sanitary Inspector",
      email: "sanitary@bpls.gov.ph",
      avatar: "/government-official-avatar.png",
    },
  },
  route: "departments/sanitary",
  requiresFee: true,
  defaultFee: 500,
  requirements: [
    "Clean and sanitary premises",
    "Proper waste disposal system",
    "Clean water supply",
    "Food handler's health certificates (if applicable)",
  ],
}

/**
 * Fire Safety Clearance Configuration
 */
export const fireSafetyClearance: ClearanceConfig = {
  id: "fire-safety",
  type: "fire_safety",
  name: "Fire Safety Clearance",
  certificateName: "Fire Safety Certificate",
  description: "Fire protection and safety compliance certificate from Bureau of Fire Protection",
  department: {
    id: "dept-bfp",
    name: "Bureau of Fire Protection",
    shortName: "BFP",
    slug: "bfp",
    icon: Flame,
    officer: {
      name: "Fire Officer",
      email: "bfp@bpls.gov.ph",
      avatar: "/government-official-avatar.png",
    },
  },
  route: "departments/bfp",
  requiresFee: true,
  defaultFee: 750,
  requirements: [
    "Fire extinguishers installed",
    "Emergency exits clearly marked",
    "Fire alarm system functional",
    "Fire safety plan documented",
    "Regular fire drills conducted",
  ],
}

/**
 * MPDC Clearance Configuration
 */
export const mpdcClearance: ClearanceConfig = {
  id: "mpdc",
  type: "mpdc",
  name: "MPDC Clearance",
  certificateName: "MPDC Certificate",
  description: "Municipal planning and development compliance certificate",
  department: {
    id: "dept-mpdc",
    name: "Municipal Planning & Development Coordinator",
    shortName: "MPDC",
    slug: "mpdc",
    icon: Building2,
    officer: {
      name: "Planning Officer",
      email: "mpdc@bpls.gov.ph",
      avatar: "/government-official-avatar.png",
    },
  },
  route: "departments/mpdc",
  requiresFee: true,
  defaultFee: 600,
  requirements: [
    "Zoning compliance verification",
    "Land use compatibility",
    "Building permit (if required)",
    "Development plan approval",
  ],
}

/**
 * Environmental Clearance Configuration (MENRO)
 */
export const environmentalClearance: ClearanceConfig = {
  id: "environmental",
  type: "environmental",
  name: "Environmental Clearance",
  certificateName: "MENRO Certificate",
  description: "Environmental compliance certificate from Municipal Environment & Natural Resources Office",
  department: {
    id: "dept-menro",
    name: "Municipal Environment & Natural Resources Office",
    shortName: "MENRO",
    slug: "menro",
    icon: TreePine,
    officer: {
      name: "Environment Officer",
      email: "menro@bpls.gov.ph",
      avatar: "/government-official-avatar.png",
    },
  },
  route: "departments/menro",
  requiresFee: true,
  defaultFee: 550,
  requirements: [
    "Environmental compliance certificate",
    "Waste management plan",
    "Pollution control measures",
    "Tree-cutting permit (if applicable)",
  ],
}

/**
 * Engineering Clearance Configuration
 */
export const engineeringClearance: ClearanceConfig = {
  id: "engineering",
  type: "engineering",
  name: "Engineering Clearance",
  certificateName: "Engineering Certificate",
  description: "Structural and engineering compliance certificate",
  department: {
    id: "dept-engineering",
    name: "Engineering Department",
    shortName: "Engineering",
    slug: "engineering",
    icon: Wrench,
    officer: {
      name: "Chief Engineer",
      email: "engineering@bpls.gov.ph",
      avatar: "/government-official-avatar.png",
    },
  },
  route: "departments/engineering",
  requiresFee: true,
  defaultFee: 800,
  requirements: [
    "Structural integrity certification",
    "Building plans approved",
    "Electrical wiring compliance",
    "Plumbing system approval",
    "Occupancy load compliance",
  ],
}

/**
 * All Clearances Registry
 * Central array of all clearance configurations
 */
export const clearances: ClearanceConfig[] = [
  sanitaryClearance,
  fireSafetyClearance,
  mpdcClearance,
  environmentalClearance,
  engineeringClearance,
]

/**
 * Get Clearance by ID
 * Returns the clearance configuration matching the given ID
 *
 * @param id - Clearance ID (e.g., "sanitary", "fire-safety")
 * @returns Clearance configuration or undefined if not found
 */
export function getClearanceById(id: string): ClearanceConfig | undefined {
  return clearances.find((clearance) => clearance.id === id)
}

/**
 * Get Clearance by Type
 * Returns the clearance configuration matching the given type
 *
 * @param type - Clearance type (e.g., "sanitary", "fire_safety")
 * @returns Clearance configuration or undefined if not found
 */
export function getClearanceByType(type: ClearanceType): ClearanceConfig | undefined {
  return clearances.find((clearance) => clearance.type === type)
}

/**
 * Get Clearance by Department Slug
 * Returns the clearance configuration for a given department slug
 * Useful for backward compatibility with department-based routes
 *
 * @param slug - Department slug (e.g., "sanitary", "bfp")
 * @returns Clearance configuration or undefined if not found
 */
export function getClearanceByDepartmentSlug(slug: string): ClearanceConfig | undefined {
  return clearances.find((clearance) => clearance.department.slug === slug)
}

/**
 * Get All Clearance Types
 * Returns an array of all clearance types
 *
 * @returns Array of clearance types
 */
export function getClearanceTypes(): ClearanceType[] {
  return clearances.map((clearance) => clearance.type)
}

/**
 * Get All Department Slugs
 * Returns an array of all department slugs (for routing)
 *
 * @returns Array of department slugs
 */
export function getDepartmentSlugs(): string[] {
  return clearances.map((clearance) => clearance.department.slug)
}

/**
 * Calculate Total Default Fees
 * Returns the sum of all default clearance fees
 *
 * @returns Total default fees
 */
export function calculateTotalDefaultFees(): number {
  return clearances.reduce((total, clearance) => {
    return total + (clearance.defaultFee || 0)
  }, 0)
}
