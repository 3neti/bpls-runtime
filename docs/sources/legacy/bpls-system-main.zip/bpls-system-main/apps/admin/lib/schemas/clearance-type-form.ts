import { z } from "zod"

const iconValues = [
  "Shield",
  "Flame",
  "Building2",
  "TreePine",
  "Wrench",
  "Building",
  "FileCheck",
  "Briefcase",
] as const

/**
 * Schema for clearance type form validation
 * Used for creating and editing clearance types in the admin dashboard
 */
export const clearanceTypeFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  shortName: z.string().min(1, "Short name is required"),
  icon: z.enum(iconValues, { message: "Icon is required" }),
  certificateName: z.string().min(1, "Certificate name is required"),
  description: z.string().min(1, "Description is required"),
  isActive: z.boolean(),
})

export type ClearanceTypeFormValues = z.infer<typeof clearanceTypeFormSchema>

// Available icon options for the dropdown
export const CLEARANCE_TYPE_ICONS = [
  { value: "Shield", label: "Shield (Security/Safety)" },
  { value: "Flame", label: "Flame (Fire Protection)" },
  { value: "Building2", label: "Building (Zoning/Planning)" },
  { value: "TreePine", label: "Tree (Environment)" },
  { value: "Wrench", label: "Wrench (Engineering)" },
  { value: "Building", label: "Building (General)" },
  { value: "FileCheck", label: "File Check (Documentation)" },
  { value: "Briefcase", label: "Briefcase (Business)" },
] as const
