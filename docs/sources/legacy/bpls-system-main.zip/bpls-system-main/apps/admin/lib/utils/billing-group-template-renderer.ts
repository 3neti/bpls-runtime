/**
 * Billing Group Template Renderer
 *
 * Parses text-based receipt templates for billing groups and replaces
 * macro placeholders with actual values. Supports {{macroName}} syntax.
 *
 * This is a SEPARATE macro set from Settings > Receipting, specifically
 * designed for billing group receipts.
 */

// Types for fee custom field values in line items
export interface BillingGroupFeeFieldValue {
  fieldId: string
  value: string
}

// Types for fee fields to include in receipt
export interface BillingGroupFeeField {
  fieldId: string
  name: string
  fieldType: "text" | "number" | "currency" | "date" | "dropdown" | "checkbox"
}

// Types for billing group receipt data
export interface BillingGroupLineItem {
  feeCode: string
  feeName: string
  amount: number
  quantity: number
  subtotal: number
  customFieldValues?: BillingGroupFeeFieldValue[]
}

export interface BillingGroupHeaderField {
  fieldId?: string
  name: string
  value: string
}

export interface BillingGroupMacroData {
  // Transaction fields
  transactionNumber?: string
  date?: string
  status?: "pending" | "completed" | "cancelled"
  totalAmount?: number
  paymentMethod?: string
  referenceNumber?: string
  description?: string

  // Billing group fields
  billingGroupName?: string

  // Line items (for {{LINE_ITEMS_TABLE}})
  lineItems?: BillingGroupLineItem[]

  // Fee fields to include in receipt (where includeInReceipt: true)
  feeFields?: BillingGroupFeeField[]

  // Custom header fields (for {{field_FIELD_ID}})
  headerFields?: BillingGroupHeaderField[]

  // System fields
  currentDate?: string
}

export interface BillingGroupMacroDefinition {
  key: string
  category: "Transaction" | "Billing Group" | "Line Items" | "Custom Fields" | "System"
  description: string
}

export interface ValidationResult {
  isValid: boolean
  errors: string[]
  warnings: string[]
  unknownMacros: string[]
}

// List of valid static macros for billing groups
const VALID_STATIC_MACROS = new Set([
  // Transaction
  "transactionNumber",
  "date",
  "status",
  "totalAmount",
  "totalInWords",
  "paymentMethod",
  "referenceNumber",
  "description",
  // Billing Group
  "billingGroupName",
  // Line Items (special marker)
  "LINE_ITEMS_TABLE",
  // System
  "currentDate",
])

/**
 * Convert number to words (for amount in words)
 */
export function numberToWords(amount: number): string {
  const ones = [
    "",
    "One",
    "Two",
    "Three",
    "Four",
    "Five",
    "Six",
    "Seven",
    "Eight",
    "Nine",
    "Ten",
    "Eleven",
    "Twelve",
    "Thirteen",
    "Fourteen",
    "Fifteen",
    "Sixteen",
    "Seventeen",
    "Eighteen",
    "Nineteen",
  ]
  const tens = [
    "",
    "",
    "Twenty",
    "Thirty",
    "Forty",
    "Fifty",
    "Sixty",
    "Seventy",
    "Eighty",
    "Ninety",
  ]

  const convertHundreds = (num: number): string => {
    if (num === 0) return ""
    if (num < 20) return ones[num]
    if (num < 100) {
      return (
        tens[Math.floor(num / 10)] + (num % 10 !== 0 ? " " + ones[num % 10] : "")
      )
    }
    return (
      ones[Math.floor(num / 100)] +
      " Hundred" +
      (num % 100 !== 0 ? " " + convertHundreds(num % 100) : "")
    )
  }

  const convertThousands = (num: number): string => {
    if (num === 0) return "Zero"
    if (num < 1000) return convertHundreds(num)
    if (num < 1000000) {
      return (
        convertHundreds(Math.floor(num / 1000)) +
        " Thousand" +
        (num % 1000 !== 0 ? " " + convertHundreds(num % 1000) : "")
      )
    }
    if (num < 1000000000) {
      return (
        convertThousands(Math.floor(num / 1000000)) +
        " Million" +
        (num % 1000000 !== 0 ? " " + convertThousands(num % 1000000) : "")
      )
    }
    return (
      convertThousands(Math.floor(num / 1000000000)) +
      " Billion" +
      (num % 1000000000 !== 0 ? " " + convertThousands(num % 1000000000) : "")
    )
  }

  // Handle decimal part
  const wholePart = Math.floor(amount)
  const decimalPart = Math.round((amount - wholePart) * 100)

  let result = convertThousands(wholePart) + " Pesos"
  if (decimalPart > 0) {
    result += " And " + convertThousands(decimalPart) + " Cents"
  } else {
    result += " Only"
  }

  return result
}

/**
 * Format currency amount
 */
export function formatCurrency(amount: number | undefined): string {
  if (amount === undefined || amount === null) return "0.00"
  return new Intl.NumberFormat("en-PH", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount)
}

/**
 * Format date
 */
export function formatDate(dateString: string | undefined): string {
  if (!dateString) return ""
  try {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-PH", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  } catch {
    return dateString
  }
}

/**
 * Format status for display
 */
export function formatStatus(status: string | undefined): string {
  if (!status) return ""
  return status.charAt(0).toUpperCase() + status.slice(1)
}

/**
 * Get the value for a specific macro
 */
export function getBillingGroupMacroValue(
  macro: string,
  data: BillingGroupMacroData
): string {
  switch (macro) {
    // Transaction fields
    case "transactionNumber":
      return data.transactionNumber || ""
    case "date":
      return formatDate(data.date)
    case "status":
      return formatStatus(data.status)
    case "totalAmount":
      return formatCurrency(data.totalAmount)
    case "totalInWords":
      return data.totalAmount !== undefined ? numberToWords(data.totalAmount) : ""
    case "paymentMethod":
      return data.paymentMethod || ""
    case "referenceNumber":
      return data.referenceNumber || ""
    case "description":
      return data.description || ""

    // Billing Group fields
    case "billingGroupName":
      return data.billingGroupName || ""

    // Line Items Table (special marker - preserved for PDF renderer)
    case "LINE_ITEMS_TABLE":
      return "{{LINE_ITEMS_TABLE}}"

    // System fields
    case "currentDate":
      return formatDate(new Date().toISOString())

    default:
      // Check if it's a custom field (format: field_{fieldId})
      if (macro.startsWith("field_")) {
        const fieldId = macro.replace("field_", "")
        const headerField = data.headerFields?.find((f) => f.fieldId === fieldId)
        if (headerField) {
          return headerField.value
        }
        // Fallback: try to find by name matching
        const matchedField = data.headerFields?.find(
          (f) => f.name.toLowerCase().replace(/\s+/g, "_") === fieldId.toLowerCase()
        )
        return matchedField?.value || ""
      }
      return `{{${macro}}}` // Return original if unknown
  }
}

/**
 * Parse a template string and replace all macros with values
 * Note: {{LINE_ITEMS_TABLE}} is preserved for special handling by the PDF renderer
 */
export function parseBillingGroupTemplate(
  template: string,
  data: BillingGroupMacroData
): string {
  if (!template) return ""

  // Match all {{macroName}} patterns
  const macroPattern = /\{\{([^}]+)\}\}/g

  return template.replace(macroPattern, (match, macroName) => {
    const trimmedMacro = macroName.trim()

    // Preserve LINE_ITEMS_TABLE for special handling
    if (trimmedMacro === "LINE_ITEMS_TABLE") {
      return match
    }

    return getBillingGroupMacroValue(trimmedMacro, data)
  })
}

/**
 * Extract all macros from a template string
 */
export function extractMacros(template: string): string[] {
  if (!template) return []

  const macroPattern = /\{\{([^}]+)\}\}/g
  const macros: string[] = []
  let match

  while ((match = macroPattern.exec(template)) !== null) {
    const macroName = match[1].trim()
    if (!macros.includes(macroName)) {
      macros.push(macroName)
    }
  }

  return macros
}

/**
 * Validate a template string for unknown or malformed macros
 * @param template - The template string to validate
 * @param customFieldIds - Optional array of valid custom field IDs
 */
export function validateBillingGroupTemplate(
  template: string,
  customFieldIds?: string[]
): ValidationResult {
  const result: ValidationResult = {
    isValid: true,
    errors: [],
    warnings: [],
    unknownMacros: [],
  }

  if (!template) {
    return result
  }

  // Extract all macros
  const macros = extractMacros(template)

  // Check for unknown macros
  for (const macro of macros) {
    // Check if it's a static macro
    if (VALID_STATIC_MACROS.has(macro)) {
      continue
    }

    // Check if it's a custom field macro
    if (macro.startsWith("field_")) {
      const fieldId = macro.replace("field_", "")
      if (customFieldIds && !customFieldIds.includes(fieldId)) {
        result.unknownMacros.push(macro)
        result.warnings.push(`Unknown custom field: {{${macro}}}`)
      }
      continue
    }

    // Unknown macro
    result.unknownMacros.push(macro)
    result.warnings.push(`Unknown macro: {{${macro}}}`)
  }

  // Check for unclosed braces
  const openBraces = (template.match(/\{\{/g) || []).length
  const closeBraces = (template.match(/\}\}/g) || []).length

  if (openBraces !== closeBraces) {
    result.isValid = false
    result.errors.push("Mismatched braces: check for unclosed {{ or }}")
  }

  // Check for nested braces (invalid)
  if (/\{\{[^}]*\{\{/.test(template)) {
    result.isValid = false
    result.errors.push("Nested braces detected: {{...{{...}} is not allowed")
  }

  return result
}

/**
 * Get all available static macros with their descriptions
 */
export function getBillingGroupMacros(): BillingGroupMacroDefinition[] {
  return [
    // Transaction fields
    {
      key: "transactionNumber",
      category: "Transaction",
      description: "Transaction number (e.g., BGR-2025-000001)",
    },
    {
      key: "date",
      category: "Transaction",
      description: "Transaction date",
    },
    {
      key: "status",
      category: "Transaction",
      description: "Transaction status (Pending/Completed/Cancelled)",
    },
    {
      key: "totalAmount",
      category: "Transaction",
      description: "Formatted total amount",
    },
    {
      key: "totalInWords",
      category: "Transaction",
      description: "Total amount spelled out (e.g., 'Five Thousand Pesos Only')",
    },
    {
      key: "paymentMethod",
      category: "Transaction",
      description: "Payment method (Cash, Check, Credit Card, etc.)",
    },
    {
      key: "referenceNumber",
      category: "Transaction",
      description: "External reference number",
    },
    {
      key: "description",
      category: "Transaction",
      description: "Transaction description",
    },

    // Billing Group fields
    {
      key: "billingGroupName",
      category: "Billing Group",
      description: "Name of the billing group",
    },

    // Line Items
    {
      key: "LINE_ITEMS_TABLE",
      category: "Line Items",
      description: "Renders the line items table with all fees",
    },

    // System fields
    {
      key: "currentDate",
      category: "System",
      description: "Current date when printing",
    },
  ]
}

/**
 * Generate sample data for preview purposes
 */
export function getSampleBillingGroupData(
  billingGroupName: string = "Sample Billing Group"
): BillingGroupMacroData {
  return {
    // Transaction fields
    transactionNumber: "BGR-2025-000001",
    date: new Date().toISOString(),
    status: "completed",
    totalAmount: 2500.0,
    paymentMethod: "Cash",
    referenceNumber: "REF-2025-001234",
    description: "Sample transaction description",

    // Billing Group fields
    billingGroupName,

    // Line items
    lineItems: [
      { feeCode: "FEE-001", feeName: "Registration Fee", amount: 500.0, quantity: 1, subtotal: 500.0 },
      { feeCode: "FEE-002", feeName: "Processing Fee", amount: 750.0, quantity: 2, subtotal: 1500.0 },
      { feeCode: "FEE-003", feeName: "Documentary Stamp", amount: 500.0, quantity: 1, subtotal: 500.0 },
    ],

    // Sample header fields
    headerFields: [
      { fieldId: "sample_field_1", name: "Reference Number", value: "REF-2025-001" },
      { fieldId: "sample_field_2", name: "Applicant Name", value: "Juan Dela Cruz" },
    ],

    // System fields
    currentDate: new Date().toISOString(),
  }
}

/**
 * Default template values for new layouts
 */
export const DEFAULT_HEADER_TEMPLATE = `{{billingGroupName}}
Official Receipt

Transaction No: {{transactionNumber}}
Status: {{status}}`

export const DEFAULT_BODY_TEMPLATE = `Date: {{date}}

{{LINE_ITEMS_TABLE}}

TOTAL: {{totalAmount}}

AMOUNT IN WORDS:
{{totalInWords}}`

export const DEFAULT_FOOTER_TEMPLATE = `_________________________          _________________________
      Prepared By                        Received By

Printed: {{currentDate}}
This document is computer-generated`
