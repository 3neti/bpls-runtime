import { ConvexError } from "convex/values"

/**
 * Convex Error Handler Utility
 *
 * Centralized error handling for Convex errors, particularly for permission-related errors.
 * Provides consistent error handling across all dashboard components.
 */

// Error codes from convex/auth.ts
export const CONVEX_ERROR_CODES = {
  PERMISSION_DENIED: "PERMISSION_DENIED",
  UNAUTHENTICATED: "UNAUTHENTICATED",
  AUTH_USER_INVALID: "AUTH_USER_INVALID",
  USER_PROFILE_NOT_FOUND: "USER_PROFILE_NOT_FOUND",
  USER_NOT_FOUND: "USER_NOT_FOUND",
  ROLE_NOT_FOUND: "ROLE_NOT_FOUND",
  PERMISSION_NOT_DEFINED: "PERMISSION_NOT_DEFINED",
} as const

export type ConvexErrorCode = (typeof CONVEX_ERROR_CODES)[keyof typeof CONVEX_ERROR_CODES]

export interface ConvexErrorDetails {
  resource?: string
  action?: string
  userRole?: string
  requiredPermission?: string
}

export interface ConvexErrorData {
  code?: string
  message?: string
  details?: ConvexErrorDetails
}

interface ToastFunction {
  (props: { title: string; description: string; variant?: "default" | "destructive" }): void
}

interface HandleMutationErrorOptions {
  fallbackMessage?: string
  onPermissionDenied?: (details: ConvexErrorDetails | undefined) => void
  onAuthenticationError?: () => void
}

/**
 * Check if an error is a ConvexError
 */
export function isConvexError(error: unknown): error is ConvexError<any> {
  return error instanceof ConvexError
}

/**
 * Extract error data from a ConvexError
 */
export function getConvexErrorData(error: unknown): ConvexErrorData | null {
  if (!isConvexError(error)) return null
  return error.data as ConvexErrorData
}

/**
 * Check if an error is a permission denied error
 */
export function isPermissionDenied(error: unknown): boolean {
  const data = getConvexErrorData(error)
  return data?.code === CONVEX_ERROR_CODES.PERMISSION_DENIED
}

/**
 * Check if an error is an authentication-related error
 */
export function isAuthenticationError(error: unknown): boolean {
  const data = getConvexErrorData(error)
  if (!data?.code) return false

  const authErrorCodes: string[] = [
    CONVEX_ERROR_CODES.UNAUTHENTICATED,
    CONVEX_ERROR_CODES.AUTH_USER_INVALID,
    CONVEX_ERROR_CODES.USER_PROFILE_NOT_FOUND,
    CONVEX_ERROR_CODES.USER_NOT_FOUND,
  ]

  return authErrorCodes.includes(data.code)
}

/**
 * Check if an error is a role/permission configuration error
 */
export function isConfigurationError(error: unknown): boolean {
  const data = getConvexErrorData(error)
  if (!data?.code) return false

  const configErrorCodes: string[] = [
    CONVEX_ERROR_CODES.ROLE_NOT_FOUND,
    CONVEX_ERROR_CODES.PERMISSION_NOT_DEFINED,
  ]

  return configErrorCodes.includes(data.code)
}

/**
 * Extract a clean, user-friendly error message from any error
 */
export function getErrorMessage(error: unknown, fallback = "An unexpected error occurred"): string {
  if (isConvexError(error)) {
    const data = error.data as ConvexErrorData
    if (data?.message) {
      // Clean up common prefixes
      return data.message
        .replace(/^Uncaught Error:\s*/i, "")
        .replace(/^Error:\s*/i, "")
        .trim()
    }
  }

  if (error instanceof Error) {
    return error.message
      .replace(/^Uncaught Error:\s*/i, "")
      .replace(/^Error:\s*/i, "")
      .trim()
  }

  if (typeof error === "string") {
    return error
  }

  return fallback
}

/**
 * Get permission error details for displaying in PermissionDenied component
 */
export function getPermissionErrorDetails(error: unknown): ConvexErrorDetails | undefined {
  const data = getConvexErrorData(error)
  return data?.details
}

/**
 * Get the error code from a ConvexError
 */
export function getErrorCode(error: unknown): string | undefined {
  const data = getConvexErrorData(error)
  return data?.code
}

/**
 * Format permission details for display
 */
export function formatPermissionDetails(details: ConvexErrorDetails | undefined): string {
  if (!details) return ""

  const parts: string[] = []

  if (details.requiredPermission) {
    parts.push(`Required: ${details.requiredPermission}`)
  }

  if (details.userRole) {
    parts.push(`Your role: ${details.userRole}`)
  }

  return parts.join(" | ")
}

/**
 * Main error handler for mutation try-catch blocks
 *
 * Usage:
 * ```typescript
 * try {
 *   await mutation({ ... })
 * } catch (error) {
 *   handleMutationError(error, toast, {
 *     fallbackMessage: "Failed to save changes",
 *     onPermissionDenied: (details) => setShowPermissionDialog(true),
 *   })
 * }
 * ```
 */
export function handleMutationError(
  error: unknown,
  toast: ToastFunction,
  options: HandleMutationErrorOptions = {}
): void {
  const { fallbackMessage = "An unexpected error occurred", onPermissionDenied, onAuthenticationError } = options

  // Handle permission denied errors
  if (isPermissionDenied(error)) {
    const details = getPermissionErrorDetails(error)
    const message = getErrorMessage(error, "You don't have permission to perform this action")

    toast({
      title: "Access Denied",
      description: message,
      variant: "destructive",
    })

    // Call optional callback for custom handling
    if (onPermissionDenied) {
      onPermissionDenied(details)
    }

    return
  }

  // Handle authentication errors
  if (isAuthenticationError(error)) {
    const message = getErrorMessage(error, "Please log in to continue")

    toast({
      title: "Authentication Required",
      description: message,
      variant: "destructive",
    })

    // Call optional callback for custom handling (e.g., redirect to login)
    if (onAuthenticationError) {
      onAuthenticationError()
    }

    return
  }

  // Handle configuration errors (role/permission not found)
  if (isConfigurationError(error)) {
    const message = getErrorMessage(error, "There's a configuration issue. Please contact your administrator.")

    toast({
      title: "Configuration Error",
      description: message,
      variant: "destructive",
    })

    return
  }

  // Handle generic errors
  const message = getErrorMessage(error, fallbackMessage)

  toast({
    title: "Error",
    description: message,
    variant: "destructive",
  })
}

/**
 * Type guard to check if an error should be shown in the UI
 * (as opposed to being silently logged)
 */
export function isUserFacingError(error: unknown): boolean {
  // All ConvexErrors with known codes are user-facing
  const code = getErrorCode(error)
  if (code && Object.values(CONVEX_ERROR_CODES).includes(code as ConvexErrorCode)) {
    return true
  }

  // Other errors are also user-facing but may need different handling
  return error instanceof Error
}

/**
 * Create a wrapped mutation handler with automatic error handling
 *
 * Usage:
 * ```typescript
 * const handleSave = withErrorHandling(
 *   async () => await saveMutation({ ... }),
 *   toast,
 *   { fallbackMessage: "Failed to save" }
 * )
 * ```
 */
export function withErrorHandling<T>(
  fn: () => Promise<T>,
  toast: ToastFunction,
  options: HandleMutationErrorOptions = {}
): () => Promise<T | undefined> {
  return async () => {
    try {
      return await fn()
    } catch (error) {
      handleMutationError(error, toast, options)
      return undefined
    }
  }
}
