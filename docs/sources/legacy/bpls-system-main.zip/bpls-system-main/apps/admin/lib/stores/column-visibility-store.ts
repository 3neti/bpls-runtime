import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import type { VisibilityState, Updater } from '@tanstack/react-table'

// Helper function to check if a line items column is visible
// Returns true by default for columns not explicitly set (including dynamic fee fields)
export const isLineItemsColumnVisible = (
  lineItemsColumns: VisibilityState,
  columnId: string
): boolean => {
  return lineItemsColumns[columnId] !== false
}

// Default visible columns for Business Owners table
const DEFAULT_BUSINESS_OWNERS_COLUMNS: VisibilityState = {
  select: true,
  fullName: true,
  ownerType: true,
  email: true,
  mobile: true,
  location: true,
  status: true,
  // Hidden by default - can be toggled on
  groupName: false,
  tin: false,
  birthDate: false,
  civilStatus: false,
  gender: false,
  citizenship: false,
  address: false,
  blacklistReason: false,
  blacklistedAt: false,
  blacklistedBy: false,
}

// Default visible columns for Businesses table
const DEFAULT_BUSINESSES_COLUMNS: VisibilityState = {
  select: true,
  name: true,
  ownerName: true,
  lineOfBusiness: true,
  businessScale: true,
  ownershipType: true,
  location: true,
  status: true,
  // Hidden by default - can be toggled on
  groupName: false,
  annualRevenue: false,
  numberOfEmployees: false,
  contactNumber: false,
  address: false,
  occupancy: false,
  businessArea: false,
  permitPaymentCadence: false,
  establishedDate: false,
  dateStarted: false,
  registrationDate: false,
  registrationNumber: false,
  documents: false,
  blacklistReason: false,
  blacklistedAt: false,
  blacklistedBy: false,
}

// Default visible columns for Fee Names table
const DEFAULT_FEES_COLUMNS: VisibilityState = {
  select: true,
  name: true,
  description: true,
  isActive: true,
}

// Default visible columns for Clearances table
const DEFAULT_CLEARANCES_COLUMNS: VisibilityState = {
  icon: true,
  shortName: true,
  name: true,
  certificateName: true,
  isActive: true,
  _creationTime: true,
  actions: true,
}

// Default visible columns for Permit Applications (main table)
const DEFAULT_PERMIT_APPLICATIONS_COLUMNS: VisibilityState = {
  applicationNumber: true,
  businessName: true,
  ownerName: true,
  applicationType: true,
  submittedAt: true,
  status: true,
  // Hidden by default - can be toggled on
  lineOfBusiness: false,
  businessScale: false,
  ownershipType: false,
  businessAddress: false,
  ownerEmail: false,
  ownerContact: false,
  ownerTin: false,
  createdAt: false,
  updatedAt: false,
}

// Default visible columns for Assessment table
const DEFAULT_ASSESSMENT_COLUMNS: VisibilityState = {
  select: true,
  applicationNumber: true,
  ownerName: true,
  businessName: true,
  submittedAt: true,
  status: true,
  actions: true,
  // Hidden by default - can be toggled on
  lineOfBusiness: false,
  businessScale: false,
  ownershipType: false,
  businessAddress: false,
  ownerEmail: false,
  ownerContact: false,
  ownerTin: false,
  applicationType: false,
  createdAt: false,
  updatedAt: false,
}

// Default visible columns for Payment table
const DEFAULT_PAYMENT_COLUMNS: VisibilityState = {
  select: true,
  applicationNumber: true,
  ownerName: true,
  businessName: true,
  submittedAt: true,
  status: true,
  actions: true,
  // Hidden by default - can be toggled on
  lineOfBusiness: false,
  businessScale: false,
  ownershipType: false,
  businessAddress: false,
  ownerEmail: false,
  ownerContact: false,
  ownerTin: false,
  applicationType: false,
  createdAt: false,
  updatedAt: false,
}

// Default visible columns for Released table
const DEFAULT_RELEASED_COLUMNS: VisibilityState = {
  applicationNumber: true,
  businessName: true,
  ownerName: true,
  totalPaid: true,
  nextPayment: true,
  periodsPaid: true,
  clearances: true,
  totalRemaining: true,
  actions: true,
  // Hidden by default - can be toggled on
  lineOfBusiness: false,
  businessScale: false,
  ownershipType: false,
  businessAddress: false,
  ownerEmail: false,
  ownerContact: false,
  releasedAt: false,
  applicationType: false,
}

// Default visible columns for Drafts table
const DEFAULT_DRAFTS_COLUMNS: VisibilityState = {
  draftName: true,
  ownerName: true,
  businessName: true,
  applicationType: true,
  progress: true,
  comments: true,
  updatedAt: true,
  actions: true,
  // Hidden by default - can be toggled on
  lineOfBusiness: false,
  createdAt: false,
}

// Default visible columns for Permits table
const DEFAULT_PERMITS_COLUMNS: VisibilityState = {
  permitNumber: true,
  businessName: true,
  ownerName: true,
  issuedAt: true,
  expiryDate: true,
  status: true,
  actions: true,
  // Hidden by default - can be toggled on
  businessAddress: false,
  dateReleased: false,
}

// Default visible columns for Billing Group Records table
const DEFAULT_RECORDS_COLUMNS: VisibilityState = {
  transactionNumber: true,
  date: true,
  description: true,
  amount: true,
  paymentMethod: true,
  referenceNumber: true,
  status: true,
  actions: true,
}

// Default visible columns for Line Items table in Transaction modals
// Static columns: fee (always visible), amount, qty, subtotal
// Dynamic columns: prefixed with "feeField_" + fieldId
const DEFAULT_LINE_ITEMS_COLUMNS: VisibilityState = {
  fee: true,
  amount: true,
  qty: true,
  subtotal: true,
  // Dynamic fee field columns will be added at runtime with default true
}

interface ColumnVisibilityStore {
  // State
  businessOwnersColumns: VisibilityState
  businessesColumns: VisibilityState
  feesColumns: VisibilityState
  clearancesColumns: VisibilityState
  permitApplicationsColumns: VisibilityState
  assessmentColumns: VisibilityState
  paymentColumns: VisibilityState
  releasedColumns: VisibilityState
  draftsColumns: VisibilityState
  permitsColumns: VisibilityState
  recordsColumns: VisibilityState
  lineItemsColumns: VisibilityState

  // Actions
  setBusinessOwnersColumns: (updater: Updater<VisibilityState>) => void
  setBusinessesColumns: (updater: Updater<VisibilityState>) => void
  setFeesColumns: (updater: Updater<VisibilityState>) => void
  setClearancesColumns: (updater: Updater<VisibilityState>) => void
  setPermitApplicationsColumns: (updater: Updater<VisibilityState>) => void
  setAssessmentColumns: (updater: Updater<VisibilityState>) => void
  setPaymentColumns: (updater: Updater<VisibilityState>) => void
  setReleasedColumns: (updater: Updater<VisibilityState>) => void
  setDraftsColumns: (updater: Updater<VisibilityState>) => void
  setPermitsColumns: (updater: Updater<VisibilityState>) => void
  setRecordsColumns: (updater: Updater<VisibilityState>) => void
  setLineItemsColumns: (updater: Updater<VisibilityState>) => void
  resetBusinessOwnersColumns: () => void
  resetBusinessesColumns: () => void
  resetFeesColumns: () => void
  resetClearancesColumns: () => void
  resetPermitApplicationsColumns: () => void
  resetAssessmentColumns: () => void
  resetPaymentColumns: () => void
  resetReleasedColumns: () => void
  resetDraftsColumns: () => void
  resetPermitsColumns: () => void
  resetRecordsColumns: () => void
  resetLineItemsColumns: () => void
  toggleBusinessOwnersColumn: (columnId: string) => void
  toggleBusinessesColumn: (columnId: string) => void
  toggleFeesColumn: (columnId: string) => void
  toggleClearancesColumn: (columnId: string) => void
  togglePermitApplicationsColumn: (columnId: string) => void
  toggleAssessmentColumn: (columnId: string) => void
  togglePaymentColumn: (columnId: string) => void
  toggleReleasedColumn: (columnId: string) => void
  toggleDraftsColumn: (columnId: string) => void
  togglePermitsColumn: (columnId: string) => void
  toggleRecordsColumn: (columnId: string) => void
  toggleLineItemsColumn: (columnId: string) => void
}

export const useColumnVisibilityStore = create<ColumnVisibilityStore>()(
  persist(
    (set) => ({
      // Initial state
      businessOwnersColumns: DEFAULT_BUSINESS_OWNERS_COLUMNS,
      businessesColumns: DEFAULT_BUSINESSES_COLUMNS,
      feesColumns: DEFAULT_FEES_COLUMNS,
      clearancesColumns: DEFAULT_CLEARANCES_COLUMNS,
      permitApplicationsColumns: DEFAULT_PERMIT_APPLICATIONS_COLUMNS,
      assessmentColumns: DEFAULT_ASSESSMENT_COLUMNS,
      paymentColumns: DEFAULT_PAYMENT_COLUMNS,
      releasedColumns: DEFAULT_RELEASED_COLUMNS,
      draftsColumns: DEFAULT_DRAFTS_COLUMNS,
      permitsColumns: DEFAULT_PERMITS_COLUMNS,
      recordsColumns: DEFAULT_RECORDS_COLUMNS,
      lineItemsColumns: DEFAULT_LINE_ITEMS_COLUMNS,

      // Actions
      setBusinessOwnersColumns: (updater) =>
        set((state) => ({
          businessOwnersColumns:
            typeof updater === 'function'
              ? updater(state.businessOwnersColumns)
              : updater,
        })),

      setBusinessesColumns: (updater) =>
        set((state) => ({
          businessesColumns:
            typeof updater === 'function'
              ? updater(state.businessesColumns)
              : updater,
        })),

      setFeesColumns: (updater) =>
        set((state) => ({
          feesColumns:
            typeof updater === 'function'
              ? updater(state.feesColumns)
              : updater,
        })),

      setClearancesColumns: (updater) =>
        set((state) => ({
          clearancesColumns:
            typeof updater === 'function'
              ? updater(state.clearancesColumns)
              : updater,
        })),

      setPermitApplicationsColumns: (updater) =>
        set((state) => ({
          permitApplicationsColumns:
            typeof updater === 'function'
              ? updater(state.permitApplicationsColumns)
              : updater,
        })),

      setAssessmentColumns: (updater) =>
        set((state) => ({
          assessmentColumns:
            typeof updater === 'function'
              ? updater(state.assessmentColumns)
              : updater,
        })),

      setPaymentColumns: (updater) =>
        set((state) => ({
          paymentColumns:
            typeof updater === 'function'
              ? updater(state.paymentColumns)
              : updater,
        })),

      setReleasedColumns: (updater) =>
        set((state) => ({
          releasedColumns:
            typeof updater === 'function'
              ? updater(state.releasedColumns)
              : updater,
        })),

      setDraftsColumns: (updater) =>
        set((state) => ({
          draftsColumns:
            typeof updater === 'function'
              ? updater(state.draftsColumns)
              : updater,
        })),

      setPermitsColumns: (updater) =>
        set((state) => ({
          permitsColumns:
            typeof updater === 'function'
              ? updater(state.permitsColumns)
              : updater,
        })),

      setRecordsColumns: (updater) =>
        set((state) => ({
          recordsColumns:
            typeof updater === 'function'
              ? updater(state.recordsColumns)
              : updater,
        })),

      setLineItemsColumns: (updater) =>
        set((state) => ({
          lineItemsColumns:
            typeof updater === 'function'
              ? updater(state.lineItemsColumns)
              : updater,
        })),

      resetBusinessOwnersColumns: () =>
        set({ businessOwnersColumns: DEFAULT_BUSINESS_OWNERS_COLUMNS }),

      resetBusinessesColumns: () =>
        set({ businessesColumns: DEFAULT_BUSINESSES_COLUMNS }),

      resetFeesColumns: () =>
        set({ feesColumns: DEFAULT_FEES_COLUMNS }),

      resetClearancesColumns: () =>
        set({ clearancesColumns: DEFAULT_CLEARANCES_COLUMNS }),

      resetPermitApplicationsColumns: () =>
        set({ permitApplicationsColumns: DEFAULT_PERMIT_APPLICATIONS_COLUMNS }),

      resetAssessmentColumns: () =>
        set({ assessmentColumns: DEFAULT_ASSESSMENT_COLUMNS }),

      resetPaymentColumns: () =>
        set({ paymentColumns: DEFAULT_PAYMENT_COLUMNS }),

      resetReleasedColumns: () =>
        set({ releasedColumns: DEFAULT_RELEASED_COLUMNS }),

      resetDraftsColumns: () =>
        set({ draftsColumns: DEFAULT_DRAFTS_COLUMNS }),

      resetPermitsColumns: () =>
        set({ permitsColumns: DEFAULT_PERMITS_COLUMNS }),

      resetRecordsColumns: () =>
        set({ recordsColumns: DEFAULT_RECORDS_COLUMNS }),

      resetLineItemsColumns: () =>
        set({ lineItemsColumns: DEFAULT_LINE_ITEMS_COLUMNS }),

      toggleBusinessOwnersColumn: (columnId) =>
        set((state) => ({
          businessOwnersColumns: {
            ...state.businessOwnersColumns,
            [columnId]: !state.businessOwnersColumns[columnId],
          },
        })),

      toggleBusinessesColumn: (columnId) =>
        set((state) => ({
          businessesColumns: {
            ...state.businessesColumns,
            [columnId]: !state.businessesColumns[columnId],
          },
        })),

      toggleFeesColumn: (columnId) =>
        set((state) => ({
          feesColumns: {
            ...state.feesColumns,
            [columnId]: !state.feesColumns[columnId],
          },
        })),

      toggleClearancesColumn: (columnId) =>
        set((state) => ({
          clearancesColumns: {
            ...state.clearancesColumns,
            [columnId]: !state.clearancesColumns[columnId],
          },
        })),

      togglePermitApplicationsColumn: (columnId) =>
        set((state) => ({
          permitApplicationsColumns: {
            ...state.permitApplicationsColumns,
            [columnId]: !state.permitApplicationsColumns[columnId],
          },
        })),

      toggleAssessmentColumn: (columnId) =>
        set((state) => ({
          assessmentColumns: {
            ...state.assessmentColumns,
            [columnId]: !state.assessmentColumns[columnId],
          },
        })),

      togglePaymentColumn: (columnId) =>
        set((state) => ({
          paymentColumns: {
            ...state.paymentColumns,
            [columnId]: !state.paymentColumns[columnId],
          },
        })),

      toggleReleasedColumn: (columnId) =>
        set((state) => ({
          releasedColumns: {
            ...state.releasedColumns,
            [columnId]: !state.releasedColumns[columnId],
          },
        })),

      toggleDraftsColumn: (columnId) =>
        set((state) => ({
          draftsColumns: {
            ...state.draftsColumns,
            [columnId]: !state.draftsColumns[columnId],
          },
        })),

      togglePermitsColumn: (columnId) =>
        set((state) => ({
          permitsColumns: {
            ...state.permitsColumns,
            [columnId]: !state.permitsColumns[columnId],
          },
        })),

      toggleRecordsColumn: (columnId) =>
        set((state) => ({
          recordsColumns: {
            ...state.recordsColumns,
            [columnId]: !state.recordsColumns[columnId],
          },
        })),

      toggleLineItemsColumn: (columnId) =>
        set((state) => ({
          lineItemsColumns: {
            ...state.lineItemsColumns,
            [columnId]: state.lineItemsColumns[columnId] === undefined
              ? false  // If undefined (new column), set to false (hide)
              : !state.lineItemsColumns[columnId],
          },
        })),
    }),
    {
      name: 'column-visibility-storage',
      storage: createJSONStorage(() => {
        // SSR-safe localStorage access
        if (typeof window !== 'undefined') {
          return localStorage
        }
        // Fallback for SSR - no-op storage
        return {
          getItem: () => null,
          setItem: () => {},
          removeItem: () => {},
        }
      }),
    }
  )
)
