/**
 * Permit Template Renderer
 *
 * Parses text-based permit templates and replaces macro placeholders
 * with actual values. Supports {{macroName}} syntax.
 * Special macros (QR_CODE, MUNICIPAL_SEAL, LOGO, LINES_OF_BUSINESS) are
 * converted to [[MACRO_NAME]] markers for PDF renderer handling.
 */

// Types for macro data
export interface PermitMacroData {
  // Permit fields
  permitNumber?: string;
  dateIssued?: string;
  expirationDate?: string;
  applicationNumber?: string;
  applicationType?: string;

  // Business fields
  businessName?: string;
  businessAddress?: string;
  businessProvince?: string;
  businessCityMunicipality?: string;
  businessBarangay?: string;
  businessTIN?: string;
  businessEmail?: string;
  businessContactNumber?: string;
  ownershipType?: string;
  dateStarted?: string;
  registrationNumber?: string;

  // Owner fields
  ownerName?: string;
  ownerAddress?: string;
  ownerContactNumber?: string;
  ownerEmail?: string;

  // Municipality fields
  municipalityName?: string;
  provinceName?: string;
  fullAddress?: string;

  // Officials fields
  mayorName?: string;
  mayorTitle?: string;
  treasurerName?: string;

  // System fields
  currentDate?: string;
  currentYear?: string;

  // Payment fields
  orNumber?: string;

  // Lines of business (for LINES_OF_BUSINESS macro)
  linesOfBusiness?: string[];
}

export interface PermitMacroDefinition {
  key: string;
  category: "Permit" | "Business" | "Owner" | "Municipality" | "Officials" | "System" | "Special";
  description: string;
}

export interface PermitValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  unknownMacros: string[];
}

// List of all valid macros
const VALID_MACROS = new Set([
  // Permit
  "permitNumber",
  "dateIssued",
  "expirationDate",
  "applicationNumber",
  "applicationType",
  "orNumber",
  // Business
  "businessName",
  "businessAddress",
  "businessProvince",
  "businessCityMunicipality",
  "businessBarangay",
  "businessTIN",
  "businessEmail",
  "businessContactNumber",
  "ownershipType",
  "dateStarted",
  "registrationNumber",
  // Owner
  "ownerName",
  "ownerAddress",
  "ownerContactNumber",
  "ownerEmail",
  // Municipality
  "municipalityName",
  "provinceName",
  "fullAddress",
  // Officials
  "mayorName",
  "mayorTitle",
  "treasurerName",
  // System
  "currentDate",
  "currentYear",
  // Special (rendered as components)
  "QR_CODE",
  "MUNICIPAL_SEAL",
  "LOGO",
  "LINES_OF_BUSINESS",
]);

// Special macros that are preserved for PDF renderer handling
const SPECIAL_MACROS = new Set([
  "QR_CODE",
  "MUNICIPAL_SEAL",
  "LOGO",
  "LINES_OF_BUSINESS",
]);

/**
 * Format date only (no time)
 */
export function formatPermitDate(dateString: string | undefined): string {
  if (!dateString) return "";
  try {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-PH", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  } catch {
    return dateString;
  }
}

/**
 * Get the value for a specific macro
 */
export function getPermitMacroValue(
  macro: string,
  data: PermitMacroData
): string {
  // Special macros - preserve for PDF renderer
  if (SPECIAL_MACROS.has(macro)) {
    return `[[${macro}]]`;
  }

  switch (macro) {
    // Permit fields
    case "permitNumber":
      return data.permitNumber || "";
    case "dateIssued":
      return formatPermitDate(data.dateIssued);
    case "expirationDate":
      return formatPermitDate(data.expirationDate);
    case "applicationNumber":
      return data.applicationNumber || "";
    case "applicationType":
      return data.applicationType || "";
    case "orNumber":
      return data.orNumber || "";

    // Business fields
    case "businessName":
      return data.businessName || "";
    case "businessAddress":
      return data.businessAddress || "";
    case "businessProvince":
      return data.businessProvince || "";
    case "businessCityMunicipality":
      return data.businessCityMunicipality || "";
    case "businessBarangay":
      return data.businessBarangay || "";
    case "businessTIN":
      return data.businessTIN || "";
    case "businessEmail":
      return data.businessEmail || "";
    case "businessContactNumber":
      return data.businessContactNumber || "";
    case "ownershipType":
      return data.ownershipType || "";
    case "dateStarted":
      return formatPermitDate(data.dateStarted);
    case "registrationNumber":
      return data.registrationNumber || "";

    // Owner fields
    case "ownerName":
      return data.ownerName || "";
    case "ownerAddress":
      return data.ownerAddress || "";
    case "ownerContactNumber":
      return data.ownerContactNumber || "";
    case "ownerEmail":
      return data.ownerEmail || "";

    // Municipality fields
    case "municipalityName":
      return data.municipalityName || "";
    case "provinceName":
      return data.provinceName || "";
    case "fullAddress":
      return data.fullAddress || "";

    // Officials fields
    case "mayorName":
      return data.mayorName || "";
    case "mayorTitle":
      return data.mayorTitle || "";
    case "treasurerName":
      return data.treasurerName || "";

    // System fields
    case "currentDate":
      return formatPermitDate(new Date().toISOString());
    case "currentYear":
      return new Date().getFullYear().toString();

    default:
      return `{{${macro}}}`; // Return original if unknown
  }
}

/**
 * Parse a template string and replace all macros with values
 * Special macros (QR_CODE, MUNICIPAL_SEAL, LOGO, LINES_OF_BUSINESS) are
 * converted to [[MACRO_NAME]] markers for PDF renderer handling
 */
export function parsePermitTemplate(
  template: string,
  data: PermitMacroData
): string {
  if (!template) return "";

  // Match all {{macroName}} patterns
  const macroPattern = /\{\{([^}]+)\}\}/g;

  return template.replace(macroPattern, (_match, macroName) => {
    const trimmedMacro = macroName.trim();
    return getPermitMacroValue(trimmedMacro, data);
  });
}

/**
 * Extract all macros from a template string
 */
export function extractPermitMacros(template: string): string[] {
  if (!template) return [];

  const macroPattern = /\{\{([^}]+)\}\}/g;
  const macros: string[] = [];
  let match;

  while ((match = macroPattern.exec(template)) !== null) {
    const macroName = match[1].trim();
    if (!macros.includes(macroName)) {
      macros.push(macroName);
    }
  }

  return macros;
}

/**
 * Validate a template string for unknown or malformed macros
 */
export function validatePermitTemplate(template: string): PermitValidationResult {
  const result: PermitValidationResult = {
    isValid: true,
    errors: [],
    warnings: [],
    unknownMacros: [],
  };

  if (!template) {
    return result;
  }

  // Extract all macros
  const macros = extractPermitMacros(template);

  // Check for unknown macros
  for (const macro of macros) {
    if (!VALID_MACROS.has(macro)) {
      result.unknownMacros.push(macro);
      result.warnings.push(`Unknown macro: {{${macro}}}`);
    }
  }

  // Check for unclosed braces
  const openBraces = (template.match(/\{\{/g) || []).length;
  const closeBraces = (template.match(/\}\}/g) || []).length;

  if (openBraces !== closeBraces) {
    result.isValid = false;
    result.errors.push("Mismatched braces: check for unclosed {{ or }}");
  }

  // Check for nested braces (invalid)
  if (/\{\{[^}]*\{\{/.test(template)) {
    result.isValid = false;
    result.errors.push("Nested braces detected: {{...{{...}} is not allowed");
  }

  return result;
}

/**
 * Get all available macros with their descriptions
 */
export function getPermitAvailableMacros(): PermitMacroDefinition[] {
  return [
    // Permit fields
    { key: "permitNumber", category: "Permit", description: "Business permit number (e.g., BP-2025-001)" },
    { key: "dateIssued", category: "Permit", description: "Date permit was issued" },
    { key: "expirationDate", category: "Permit", description: "Permit expiration date" },
    { key: "applicationNumber", category: "Permit", description: "Application reference number" },
    { key: "applicationType", category: "Permit", description: "New / Renewal / Amendment" },
    { key: "orNumber", category: "Permit", description: "First Official Receipt (OR) number from Schedule of Payments" },

    // Business fields
    { key: "businessName", category: "Business", description: "Registered business name" },
    { key: "businessAddress", category: "Business", description: "Complete business address" },
    { key: "businessProvince", category: "Business", description: "Business province" },
    { key: "businessCityMunicipality", category: "Business", description: "Business city/municipality" },
    { key: "businessBarangay", category: "Business", description: "Business barangay" },
    { key: "businessTIN", category: "Business", description: "Business TIN" },
    { key: "businessEmail", category: "Business", description: "Business email" },
    { key: "businessContactNumber", category: "Business", description: "Business phone" },
    { key: "ownershipType", category: "Business", description: "Sole Proprietorship / Partnership / Corporation" },
    { key: "dateStarted", category: "Business", description: "Business start date" },
    { key: "registrationNumber", category: "Business", description: "DTI/SEC/CDA registration" },

    // Owner fields
    { key: "ownerName", category: "Owner", description: "Owner's full name" },
    { key: "ownerAddress", category: "Owner", description: "Owner's address" },
    { key: "ownerContactNumber", category: "Owner", description: "Owner's phone" },
    { key: "ownerEmail", category: "Owner", description: "Owner's email" },

    // Municipality fields
    { key: "municipalityName", category: "Municipality", description: "Full municipality name" },
    { key: "provinceName", category: "Municipality", description: "Province name" },
    { key: "fullAddress", category: "Municipality", description: "Municipal full address" },

    // Officials fields
    { key: "mayorName", category: "Officials", description: "Mayor's name" },
    { key: "mayorTitle", category: "Officials", description: "Mayor's title" },
    { key: "treasurerName", category: "Officials", description: "Treasurer's name" },

    // System fields
    { key: "currentDate", category: "System", description: "Current date when printing" },
    { key: "currentYear", category: "System", description: "Current year" },

    // Special fields
    { key: "QR_CODE", category: "Special", description: "Renders QR code for verification" },
    { key: "MUNICIPAL_SEAL", category: "Special", description: "Renders municipal seal image" },
    { key: "LOGO", category: "Special", description: "Renders platform logo" },
    { key: "LINES_OF_BUSINESS", category: "Special", description: "Renders simple bullet list of business activities" },
  ];
}

/**
 * Generate sample data for preview purposes
 */
export function getSamplePermitData(): PermitMacroData {
  return {
    // Permit fields
    permitNumber: "BP-2025-00001",
    dateIssued: new Date().toISOString(),
    expirationDate: new Date(new Date().getFullYear(), 11, 31).toISOString(), // End of year
    applicationNumber: "BPA-2025-00123",
    applicationType: "New",
    orNumber: "OR-2025-00001",

    // Business fields
    businessName: "Sample Business Enterprise",
    businessAddress: "123 Main St., Barangay Sample, Municipality",
    businessProvince: "Sample Province",
    businessCityMunicipality: "Municipality of Sample",
    businessBarangay: "Barangay Sample",
    businessTIN: "123-456-789-000",
    businessEmail: "business@example.com",
    businessContactNumber: "(049) 123-4567",
    ownershipType: "Sole Proprietorship",
    dateStarted: "2020-01-15",
    registrationNumber: "DTI-12345678",

    // Owner fields
    ownerName: "Juan Dela Cruz",
    ownerAddress: "456 Owner St., Barangay Owner, Municipality",
    ownerContactNumber: "(049) 987-6543",
    ownerEmail: "owner@example.com",

    // Municipality fields
    municipalityName: "MUNICIPALITY OF SAMPLE",
    provinceName: "SAMPLE PROVINCE",
    fullAddress: "SAMPLE, SAMPLE PROVINCE",

    // Officials fields
    mayorName: "HON. MAYOR SAMPLE",
    mayorTitle: "Municipal Mayor",
    treasurerName: "Municipal Treasurer Sample",

    // Lines of business
    linesOfBusiness: [
      "Retail Trade - General Merchandise",
      "Food and Beverage - Restaurant",
      "Services - Computer Shop",
    ],
  };
}
