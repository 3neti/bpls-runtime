/**
 * Business Nature Fees Configuration
 *
 * This file contains the fee structures for different business categories.
 * Each business nature has a unique set of fees that apply based on the application type.
 */

import type { FeeConfig } from '@/lib/types/fees'

export interface BusinessNature {
  id: string
  name: string
  fees: FeeConfig[]
}

export const businessNatureFees: Record<string, BusinessNature> = {
  "retail-trade": {
    id: "BN001",
    name: "Retail Trade",
    fees: [
      {
        id: "F001",
        name: "Business Tax",
        amount: 0,
        applicationType: ["New", "Renewal"],
        feeType: "Range",
        businessNatureId: "BN001",
        rangeField: "grossSales",
        ranges: [
          { min: 1, max: 50000, fee: 500 },
          { min: 50001, max: 100000, fee: 1000 },
          { min: 100001, max: 500000, fee: 2500 },
        ],
      },
      {
        id: "F002",
        name: "Sanitary Permit Fee",
        amount: 0,
        applicationType: ["New"],
        feeType: "Range",
        businessNatureId: "BN001",
        rangeField: "floorArea",
        ranges: [
          { min: 1, max: 100, fee: 200 },
          { min: 101, max: 500, fee: 400 },
          { min: 501, max: 1000, fee: 800 },
        ],
      },
      {
        id: "F003",
        name: "Health Certificate",
        amount: 0,
        applicationType: ["New", "Renewal"],
        feeType: "Formula",
        businessNatureId: "BN001",
        formula: "numberOfEmployees * 25",
      },
      {
        id: "F004",
        name: "Mayor's Permit Fee",
        amount: 0,
        applicationType: ["Renewal"],
        feeType: "Range",
        businessNatureId: "BN001",
        rangeField: "grossSales",
        ranges: [
          { min: 1, max: 25000, fee: 300 },
          { min: 25001, max: 75000, fee: 600 },
          { min: 75001, max: 200000, fee: 1200 },
        ],
      },
      {
        id: "F005",
        name: "Laminated ID",
        amount: 0,
        applicationType: ["New"],
        feeType: "Formula",
        businessNatureId: "BN001",
        formula: "numberOfEmployees * 15 + 50",
      },
      {
        id: "F006",
        name: "Occupation Fee",
        amount: 150.0,
        applicationType: ["New", "Renewal"],
        feeType: "Constant",
        businessNatureId: "BN001",
      },
    ],
  },
  "wholesale-trade": {
    id: "BN002",
    name: "Wholesale Trade",
    fees: [
      {
        id: "F007",
        name: "Business Tax",
        amount: 0,
        applicationType: ["New", "Renewal"],
        feeType: "Range",
        businessNatureId: "BN002",
        rangeField: "grossSales",
        ranges: [
          { min: 1, max: 100000, fee: 750 },
          { min: 100001, max: 500000, fee: 1500 },
          { min: 500001, max: 1000000, fee: 3000 },
        ],
      },
      {
        id: "F008",
        name: "Warehouse Permit",
        amount: 500.0,
        applicationType: ["New", "Renewal"],
        feeType: "Constant",
        businessNatureId: "BN002",
      },
    ],
  },
  "food-beverage": {
    id: "BN003",
    name: "Food & Beverage Services",
    fees: [
      {
        id: "F009",
        name: "Food Handler's Permit",
        amount: 0,
        applicationType: ["New", "Renewal"],
        feeType: "Formula",
        businessNatureId: "BN003",
        formula: "numberOfEmployees * 30",
      },
      {
        id: "F010",
        name: "Sanitary Permit",
        amount: 300.0,
        applicationType: ["New", "Renewal"],
        feeType: "Constant",
        businessNatureId: "BN003",
      },
    ],
  },
  "personal-services": {
    id: "BN004",
    name: "Other Personal Service Activities",
    fees: [
      {
        id: "F011",
        name: "Service Tax",
        amount: 0,
        applicationType: ["New", "Renewal"],
        feeType: "Range",
        businessNatureId: "BN004",
        rangeField: "grossSales",
        ranges: [
          { min: 1, max: 30000, fee: 400 },
          { min: 30001, max: 100000, fee: 800 },
          { min: 100001, max: 300000, fee: 1600 },
        ],
      },
      {
        id: "F012",
        name: "Professional License Fee",
        amount: 250.0,
        applicationType: ["New", "Renewal"],
        feeType: "Constant",
        businessNatureId: "BN004",
      },
    ],
  },
  "construction": {
    id: "BN005",
    name: "Construction",
    fees: [
      {
        id: "F013",
        name: "Construction Permit",
        amount: 0,
        applicationType: ["New", "Renewal"],
        feeType: "Range",
        businessNatureId: "BN005",
        rangeField: "capitalInvestment",
        ranges: [
          { min: 1, max: 500000, fee: 1000 },
          { min: 500001, max: 1000000, fee: 2000 },
          { min: 1000001, max: 5000000, fee: 5000 },
        ],
      },
      {
        id: "F014",
        name: "Safety Compliance Fee",
        amount: 750.0,
        applicationType: ["New", "Renewal"],
        feeType: "Constant",
        businessNatureId: "BN005",
      },
    ],
  },
}
