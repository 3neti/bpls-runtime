/**
 * User management and permission types
 */

export interface Permission {
  create: boolean
  read: boolean
  update: boolean
  delete: boolean
}

export interface Role {
  id: string
  name: string
  description: string
  permissions: {
    [resource: string]: Permission
  }
  userCount: number
}

export interface User {
  id: string
  firstName: string
  lastName: string
  email: string
  role: string
  department: string
  profilePhoto?: string
  isActive: boolean
  createdAt: string
  lastLogin?: string
}

// Derived types
export type UserFormData = Omit<User, 'id' | 'isActive' | 'createdAt' | 'lastLogin'>
export type UserSummary = Pick<User, 'id' | 'firstName' | 'lastName' | 'email' | 'role'>
