/**
 * Receipt Template Renderer
 *
 * Parses text-based receipt templates and replaces macro placeholders
 * with actual values. Supports {{macroName}} syntax.
 */

// Types for macro data
export interface PaymentReceiptFee {
  feeName: string;
  feeCategory: string;
  amount: number;
}

export interface ReceiptMacroData {
  // Payment fields
  receiptNumber?: string;
  transactionNumber?: string;
  amount?: number;
  paymentMethod?: string;
  referenceNumber?: string;
  paidAt?: string;

  // Business fields
  businessName?: string;
  businessOwnerName?: string;
  fullAddress?: string;
  applicationNumber?: string;

  // Schedule fields
  periodLabel?: string;
  dueDate?: string;
  sectionNumber?: number;
  surcharge?: number;
  penalty?: number;
  totalAmount?: number;
  fees?: PaymentReceiptFee[];

  // System fields
  municipalityName?: string;
  provinceName?: string;
  mayorName?: string;
  treasurerName?: string;
}

export interface MacroDefinition {
  key: string;
  category: "Payment" | "Business" | "Schedule" | "System";
  description: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  unknownMacros: string[];
}

// List of all valid macros
const VALID_MACROS = new Set([
  // Payment
  "receiptNumber",
  "transactionNumber",
  "amount",
  "amountInWords",
  "paymentMethod",
  "referenceNumber",
  "paidAt",
  // Business
  "businessName",
  "businessOwnerName",
  "fullAddress",
  "applicationNumber",
  // Schedule
  "periodLabel",
  "dueDate",
  "sectionNumber",
  "totalAmount",
  "FEES_TABLE",
  // System
  "currentDate",
  "municipalityName",
  "provinceName",
  "mayorName",
  "treasurerName",
]);

/**
 * Convert number to words (for amount in words)
 */
export function numberToWords(amount: number): string {
  const ones = [
    "",
    "One",
    "Two",
    "Three",
    "Four",
    "Five",
    "Six",
    "Seven",
    "Eight",
    "Nine",
    "Ten",
    "Eleven",
    "Twelve",
    "Thirteen",
    "Fourteen",
    "Fifteen",
    "Sixteen",
    "Seventeen",
    "Eighteen",
    "Nineteen",
  ];
  const tens = [
    "",
    "",
    "Twenty",
    "Thirty",
    "Forty",
    "Fifty",
    "Sixty",
    "Seventy",
    "Eighty",
    "Ninety",
  ];

  const convertHundreds = (num: number): string => {
    if (num === 0) return "";
    if (num < 20) return ones[num];
    if (num < 100) {
      return (
        tens[Math.floor(num / 10)] + (num % 10 !== 0 ? " " + ones[num % 10] : "")
      );
    }
    return (
      ones[Math.floor(num / 100)] +
      " Hundred" +
      (num % 100 !== 0 ? " " + convertHundreds(num % 100) : "")
    );
  };

  const convertThousands = (num: number): string => {
    if (num === 0) return "Zero";
    if (num < 1000) return convertHundreds(num);
    if (num < 1000000) {
      return (
        convertHundreds(Math.floor(num / 1000)) +
        " Thousand" +
        (num % 1000 !== 0 ? " " + convertHundreds(num % 1000) : "")
      );
    }
    if (num < 1000000000) {
      return (
        convertThousands(Math.floor(num / 1000000)) +
        " Million" +
        (num % 1000000 !== 0 ? " " + convertThousands(num % 1000000) : "")
      );
    }
    return (
      convertThousands(Math.floor(num / 1000000000)) +
      " Billion" +
      (num % 1000000000 !== 0 ? " " + convertThousands(num % 1000000000) : "")
    );
  };

  // Handle decimal part
  const wholePart = Math.floor(amount);
  const decimalPart = Math.round((amount - wholePart) * 100);

  let result = convertThousands(wholePart) + " Pesos";
  if (decimalPart > 0) {
    result += " And " + convertThousands(decimalPart) + " Cents";
  } else {
    result += " Only";
  }

  return result;
}

/**
 * Format currency amount
 */
export function formatCurrency(amount: number | undefined): string {
  if (amount === undefined || amount === null) return "0.00";
  return new Intl.NumberFormat("en-PH", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

/**
 * Format date/time
 */
export function formatDateTime(dateString: string | undefined): string {
  if (!dateString) return "";
  try {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  } catch {
    return dateString;
  }
}

/**
 * Format date only (no time)
 */
export function formatDate(dateString: string | undefined): string {
  if (!dateString) return "";
  try {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-PH", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  } catch {
    return dateString;
  }
}

/**
 * Get the value for a specific macro
 */
export function getMacroValue(
  macro: string,
  data: ReceiptMacroData
): string {
  switch (macro) {
    // Payment fields
    case "receiptNumber":
      return data.receiptNumber || "";
    case "transactionNumber":
      return data.transactionNumber || "";
    case "amount":
      return formatCurrency(data.amount);
    case "amountInWords":
      return data.amount !== undefined ? numberToWords(data.amount) : "";
    case "paymentMethod":
      return data.paymentMethod || "";
    case "referenceNumber":
      return data.referenceNumber || "";
    case "paidAt":
      return formatDateTime(data.paidAt);

    // Business fields
    case "businessName":
      return data.businessName || "";
    case "businessOwnerName":
      return data.businessOwnerName || "";
    case "fullAddress":
      return data.fullAddress || "";
    case "applicationNumber":
      return data.applicationNumber || "";

    // Schedule fields
    case "periodLabel":
      return data.periodLabel || "";
    case "dueDate":
      return formatDate(data.dueDate);
    case "sectionNumber":
      return data.sectionNumber !== undefined
        ? String(data.sectionNumber)
        : "";
    case "totalAmount":
      return formatCurrency(data.totalAmount);
    case "FEES_TABLE":
      // This is a special marker - actual rendering handled by the PDF component
      // Always return canonical form to ensure consistent detection
      return "{{FEES_TABLE}}";

    // System fields
    case "currentDate":
      return formatDate(new Date().toISOString());
    case "municipalityName":
      return data.municipalityName || "";
    case "provinceName":
      return data.provinceName || "";
    case "mayorName":
      return data.mayorName || "";
    case "treasurerName":
      return data.treasurerName || "";

    default:
      return `{{${macro}}}`; // Return original if unknown
  }
}

/**
 * Parse a template string and replace all macros with values
 * Note: {{FEES_TABLE}} is preserved for special handling by the PDF renderer
 */
export function parseTemplate(
  template: string,
  data: ReceiptMacroData
): string {
  if (!template) return "";

  // Match all {{macroName}} patterns
  const macroPattern = /\{\{([^}]+)\}\}/g;

  return template.replace(macroPattern, (match, macroName) => {
    const trimmedMacro = macroName.trim();

    // Preserve FEES_TABLE for special handling - always use canonical form
    // to ensure consistent detection by the PDF renderer
    if (trimmedMacro === "FEES_TABLE") {
      return "{{FEES_TABLE}}";
    }

    return getMacroValue(trimmedMacro, data);
  });
}

/**
 * Extract all macros from a template string
 */
export function extractMacros(template: string): string[] {
  if (!template) return [];

  const macroPattern = /\{\{([^}]+)\}\}/g;
  const macros: string[] = [];
  let match;

  while ((match = macroPattern.exec(template)) !== null) {
    const macroName = match[1].trim();
    if (!macros.includes(macroName)) {
      macros.push(macroName);
    }
  }

  return macros;
}

/**
 * Validate a template string for unknown or malformed macros
 */
export function validateTemplate(template: string): ValidationResult {
  const result: ValidationResult = {
    isValid: true,
    errors: [],
    warnings: [],
    unknownMacros: [],
  };

  if (!template) {
    return result;
  }

  // Extract all macros
  const macros = extractMacros(template);

  // Check for unknown macros
  for (const macro of macros) {
    if (!VALID_MACROS.has(macro)) {
      result.unknownMacros.push(macro);
      result.warnings.push(`Unknown macro: {{${macro}}}`);
    }
  }

  // Check for unclosed braces
  const openBraces = (template.match(/\{\{/g) || []).length;
  const closeBraces = (template.match(/\}\}/g) || []).length;

  if (openBraces !== closeBraces) {
    result.isValid = false;
    result.errors.push("Mismatched braces: check for unclosed {{ or }}");
  }

  // Check for nested braces (invalid)
  if (/\{\{[^}]*\{\{/.test(template)) {
    result.isValid = false;
    result.errors.push("Nested braces detected: {{...{{...}} is not allowed");
  }

  return result;
}

/**
 * Get all available macros with their descriptions
 */
export function getAvailableMacros(): MacroDefinition[] {
  return [
    // Payment fields
    {
      key: "receiptNumber",
      category: "Payment",
      description: "Official receipt number",
    },
    {
      key: "transactionNumber",
      category: "Payment",
      description: "System transaction ID",
    },
    {
      key: "amount",
      category: "Payment",
      description: "Formatted payment amount",
    },
    {
      key: "amountInWords",
      category: "Payment",
      description: "Amount spelled out (e.g., 'Five Thousand Pesos Only')",
    },
    {
      key: "paymentMethod",
      category: "Payment",
      description: "Payment method (Cash, Credit Card, etc.)",
    },
    {
      key: "referenceNumber",
      category: "Payment",
      description: "External reference number",
    },
    {
      key: "paidAt",
      category: "Payment",
      description: "Payment date and time",
    },

    // Business fields
    {
      key: "businessName",
      category: "Business",
      description: "Business name",
    },
    {
      key: "businessOwnerName",
      category: "Business",
      description: "Owner's full name",
    },
    {
      key: "fullAddress",
      category: "Business",
      description: "Complete business address",
    },
    {
      key: "applicationNumber",
      category: "Business",
      description: "Application reference number",
    },

    // Schedule fields
    {
      key: "periodLabel",
      category: "Schedule",
      description: "Payment period (Q1, 1st Semester, Full Payment)",
    },
    { key: "dueDate", category: "Schedule", description: "Payment due date" },
    {
      key: "sectionNumber",
      category: "Schedule",
      description: "Section number (1, 2, 3, 4)",
    },
    {
      key: "totalAmount",
      category: "Schedule",
      description: "Total section amount",
    },
    {
      key: "FEES_TABLE",
      category: "Schedule",
      description: "Renders the fees table with all line items, including surcharge and penalty rows",
    },

    // System fields
    {
      key: "currentDate",
      category: "System",
      description: "Current date when printing",
    },
    {
      key: "municipalityName",
      category: "System",
      description: "Municipality name from settings",
    },
    {
      key: "provinceName",
      category: "System",
      description: "Province name from settings",
    },
    {
      key: "mayorName",
      category: "System",
      description: "Mayor's name from settings",
    },
    {
      key: "treasurerName",
      category: "System",
      description: "Treasurer's name from settings",
    },
  ];
}

/**
 * Generate sample data for preview purposes
 */
export function getSampleReceiptData(): ReceiptMacroData {
  return {
    // Payment fields
    receiptNumber: "OR-2024-000123",
    transactionNumber: "TXN-2024-000456",
    amount: 5250.0,
    paymentMethod: "Cash",
    referenceNumber: "REF-123456",
    paidAt: new Date().toISOString(),

    // Business fields
    businessName: "Sample Business Inc.",
    businessOwnerName: "Juan Dela Cruz",
    fullAddress: "123 Main St., Barangay Sample, Municipality",
    applicationNumber: "BPA-2024-000789",

    // Schedule fields
    periodLabel: "Q1",
    dueDate: new Date().toISOString(),
    sectionNumber: 1,
    surcharge: 250.0,
    penalty: 125.0,
    totalAmount: 5250.0,
    fees: [
      { feeName: "Mayor's Permit", feeCategory: "Regulatory", amount: 2500.0 },
      { feeName: "Business Tax", feeCategory: "Tax", amount: 1500.0 },
      { feeName: "Sanitary Permit", feeCategory: "Regulatory", amount: 750.0 },
      { feeName: "Fire Safety Fee", feeCategory: "Safety", amount: 500.0 },
    ],

    // System fields
    municipalityName: "Municipality of Sample",
    provinceName: "Sample Province",
    mayorName: "Hon. Mayor Sample",
    treasurerName: "Municipal Treasurer Sample",
  };
}
