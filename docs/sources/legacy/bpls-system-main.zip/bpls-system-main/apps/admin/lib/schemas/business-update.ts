/**
 * Zod validation schema for Business Update Form
 *
 * This schema validates the business update form with all required fields.
 */

import { z } from "zod";

/**
 * Document schema for ownership-specific documents
 */
const documentSchema = z.object({
  file: z.instanceof(File).nullable(),
  uploaded: z.boolean(),
});

/**
 * Business Update Schema
 * All fields are editable except ID
 */
export const businessUpdateSchema = z
  .object({
    id: z.string().min(1, "ID is required"),
    name: z.string().min(1, "Business name is required"),
    businessArea: z.number().min(1, "Business area is required").positive("Must be a positive number"),
    propertyIndexNumber: z.string().optional(),
    dateEstablished: z.string().optional(),
    registrationDate: z.string().optional(), // DTI/SEC/CDA registration date based on ownership type
    registrationNumber: z.string().optional(), // DTI/SEC/CDA registration number based on ownership type
    dateStarted: z.string().min(1, "Date started is required"),
    occupancy: z.string().optional(),
    maleEmployeeCount: z.number().min(0, "Male employee count must be 0 or greater"),
    femaleEmployeeCount: z.number().min(0, "Female employee count must be 0 or greater"),
    ownershipType: z.string().min(1, "Ownership type is required"),
    // Conditional Group Name field (required for Partnership, Corporation, Cooperative)
    groupName: z.string().optional(),
    contactNumber: z.string().optional(),
    email: z.union([z.string().email(), z.literal("")]).optional(),
    // NEW: Hierarchical address fields
    address: z.string().min(1, "Street address is required"),
    buildingName: z.string().optional(),
    provinceId: z.string().min(1, "Province is required"),
    cityId: z.string().min(1, "City/Municipality is required"),
    barangayId: z.string().min(1, "Barangay is required"),
    // Business classification (optional - existing businesses are unclassified)
    categoryId: z.string().optional(),
    subCategoryId: z.string().optional(),
    // lineOfBusiness field removed - now using linesOfBusiness array in separate component
    // Ownership-specific documents (optional but validated based on ownership type)
    documents: z
      .record(
        z.string(), // document type key (e.g., "dtiCertificate", "secCertificate")
        documentSchema
      )
      .optional(),
  })
  .refine((data) => data.maleEmployeeCount + data.femaleEmployeeCount > 0, {
    message: "At least one employee is required (male or female)",
    path: ["maleEmployeeCount"],
  })
  .superRefine((data, ctx) => {
    // Conditional validation for groupName based on ownership type
    const normalizedOwnershipType = data.ownershipType.toLowerCase().replace(/\s+/g, "-");
    const requiresGroupName = ["partnership", "corporation", "cooperative"].includes(normalizedOwnershipType);
    if (requiresGroupName) {
      if (!data.groupName || data.groupName.trim().length === 0) {
        ctx.addIssue({
          code: "custom",
          message: `Company/Organization name is required for ${data.ownershipType}`,
          path: ["groupName"],
        });
      }
    }
  });

/**
 * Type inference from schema
 */
export type BusinessUpdateSchema = z.infer<typeof businessUpdateSchema>;

/**
 * Default values factory function
 * Creates default values from Business data
 */
export const createBusinessUpdateDefaultValues = (business: {
  id: string;
  name: string;
  businessArea?: number;
  propertyIndexNumber?: string;
  dateEstablished?: string;
  registrationDate?: string;
  registrationNumber?: string;
  dateStarted?: string;
  occupancy?: string;
  maleEmployeeCount: number;
  femaleEmployeeCount: number;
  ownershipType: string;
  groupName?: string;
  contactNumber: string;
  email: string;
  address: string;
  buildingName?: string;
  provinceId: string;
  cityId: string;
  barangayId: string;
  categoryId?: string;
  subCategoryId?: string;
  // lineOfBusiness field removed - now using linesOfBusiness array
}): BusinessUpdateSchema => ({
  id: business.id,
  name: business.name,
  businessArea: business.businessArea || 1,
  propertyIndexNumber: business.propertyIndexNumber || "",
  dateEstablished: business.dateEstablished || "",
  registrationDate: business.registrationDate || "",
  registrationNumber: business.registrationNumber || "",
  dateStarted: business.dateStarted || new Date().toISOString().split("T")[0],
  occupancy: business.occupancy?.toLowerCase() || "",
  maleEmployeeCount: business.maleEmployeeCount || 0,
  femaleEmployeeCount: business.femaleEmployeeCount || 0,
  ownershipType: business.ownershipType.toLowerCase().replace(/\s+/g, "-"),
  groupName: business.groupName || "",
  contactNumber: business.contactNumber,
  email: business.email,
  address: business.address,
  buildingName: business.buildingName || "",
  provinceId: business.provinceId,
  cityId: business.cityId,
  barangayId: business.barangayId,
  categoryId: business.categoryId || "",
  subCategoryId: business.subCategoryId || "",
  // lineOfBusiness field removed - now using linesOfBusiness array
  documents: {},
});
