/**
 * Division types for the taxes & fees hierarchy system
 *
 * These types are derived from the Convex schema as the single source of truth.
 * The database schema is defined in convex/schema.ts
 *
 * Hierarchy: Major → Division (contains Fees) → Groups (inherit fees)
 * Example divisions: "DNEC", "ETC"
 */

import type { Doc, Id } from "@repo/backend/convex/_generated/dataModel"
import type { Fee } from "./fees"
import type { MajorId } from "./major"

// Core division type derived from Convex schema
export type Division = Doc<"divisions">

// Extract specific field types
export type DivisionId = Id<"divisions">

/**
 * Division form values for creation/editing
 */
export interface DivisionFormValues {
  name: string
  description: string
  majorId: MajorId
}

/**
 * Division with related data
 * Used for detail views showing associated major and fees
 */
export interface DivisionWithRelations extends Division {
  majorName: string
  fees: Fee[]
  feeCount: number
  appliedGroupCount: number // Count of groups this division is applied to
}

/**
 * Division with fees
 * Used when displaying division fees in UI
 */
export interface DivisionWithFees extends Division {
  fees: Fee[]
}

/**
 * Division summary for dropdowns/selects
 */
export interface DivisionSummary {
  _id: DivisionId
  name: string
  description: string
  majorId: MajorId
  majorName?: string
}

/**
 * Division group association
 * Represents the junction table record
 */
export type DivisionGroup = Doc<"division_groups">

/**
 * Division application to group
 * Used when applying a division to groups
 */
export interface DivisionApplication {
  divisionId: DivisionId
  groupIds: Id<"groups">[]
}
