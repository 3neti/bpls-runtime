/**
 * Line of Business Form Schema
 *
 * Zod validation schema for adding/editing lines of business and fee overrides
 * Hierarchy: Major → Division (contains Fees) → Lines of Business (inherit & override fees)
 */

import { z } from "zod";

/**
 * Line of Business Form Schema
 * Validates all fields when creating or editing a line of business
 */
export const lineOfBusinessFormSchema = z.object({
  name: z
    .string()
    .min(1, "Line of business name is required")
    .min(2, "Line of business name must be at least 2 characters")
    .max(100, "Line of business name cannot exceed 100 characters")
    .regex(
      /^[a-zA-Z0-9\s\-&]+$/,
      "Line of business name can only contain letters, numbers, spaces, hyphens, and ampersands"
    ),

  description: z.string().optional().or(z.literal("")),

  divisionId: z.string().optional(),
});

/**
 * Inferred TypeScript type from the schema
 */
export type LineOfBusinessFormSchema = z.infer<typeof lineOfBusinessFormSchema>;

/**
 * Default values for the form
 */
export const lineOfBusinessFormDefaultValues: Partial<LineOfBusinessFormSchema> = {
  name: "",
  description: "",
  divisionId: undefined,
};

/**
 * Fee Range Schema for overrides
 */
const feeRangeSchema = z.object({
  min: z.number().min(0, "Minimum must be 0 or greater"),
  max: z.number().min(0, "Maximum must be 0 or greater"),
  fee: z.number().min(0, "Fee must be 0 or greater").optional(),
  formula: z.string().optional(),
});

/**
 * Fee Override Schema
 * Validates fee override values for different fee types
 */
export const feeOverrideSchema = z
  .object({
    feeId: z.string().min(1, "Fee ID is required"),
    feeName: z.string().min(1, "Fee name is required"),
    feeType: z.enum(["Constant", "Range", "Formula"], {
      message: "Fee type must be Constant, Range, or Formula",
    }),

    // Original values (for display)
    originalAmount: z.number().optional(),
    originalRanges: z.array(feeRangeSchema).optional(),
    originalFormula: z.string().optional(),

    // Override values
    overrideAmount: z
      .number()
      .min(0, "Amount must be 0 or greater")
      .max(10000000, "Amount cannot exceed 10 million")
      .optional(),
    overrideRanges: z.array(feeRangeSchema).optional(),
    overrideFormula: z
      .string()
      .min(1, "Formula cannot be empty")
      .max(500, "Formula cannot exceed 500 characters")
      .optional(),

    overrideRangeField: z.string().optional(),

    reason: z
      .string()
      .min(1, "Reason for override is required")
      .min(10, "Reason must be at least 10 characters")
      .max(500, "Reason cannot exceed 500 characters"),
  })
  .refine(
    (data) => {
      // Validate that appropriate override field is provided based on fee type
      if (data.feeType === "Constant") {
        return data.overrideAmount !== undefined;
      }
      if (data.feeType === "Range") {
        return data.overrideRanges !== undefined && data.overrideRanges.length > 0;
      }
      if (data.feeType === "Formula") {
        return data.overrideFormula !== undefined && data.overrideFormula.length > 0;
      }
      return false;
    },
    {
      message: "Override value is required for the selected fee type",
      path: ["overrideAmount"], // Error will appear on the form
    }
  )
  .refine(
    (data) => {
      // Validate ranges if provided
      if (data.overrideRanges && data.overrideRanges.length > 0) {
        // Check for overlapping ranges and proper ordering
        const sortedRanges = [...data.overrideRanges].sort((a, b) => a.min - b.min);
        for (let i = 0; i < sortedRanges.length - 1; i++) {
          if (sortedRanges[i].max >= sortedRanges[i + 1].min) {
            return false; // Overlapping ranges
          }
        }
        // Check that each range has either fee or formula (but not both, except last one)
        for (let i = 0; i < sortedRanges.length - 1; i++) {
          if (!sortedRanges[i].fee) {
            return false;
          }
        }
        // Last range must have either fee or formula
        const lastRange = sortedRanges[sortedRanges.length - 1];
        if (!lastRange.fee && !lastRange.formula) {
          return false;
        }
      }
      return true;
    },
    {
      message: "Invalid range configuration. Ranges must not overlap and must have valid fee or formula values",
      path: ["overrideRanges"],
    }
  );

/**
 * Inferred TypeScript type from the schema
 */
export type FeeOverrideSchema = z.infer<typeof feeOverrideSchema>;

/**
 * Default values for fee override form
 */
export const feeOverrideDefaultValues: Partial<FeeOverrideSchema> = {
  feeId: "",
  feeName: "",
  feeType: "Constant",
  overrideAmount: undefined,
  overrideRanges: undefined,
  overrideFormula: undefined,
  overrideRangeField: undefined,
  reason: "",
};
