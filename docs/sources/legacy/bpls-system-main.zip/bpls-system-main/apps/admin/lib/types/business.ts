/**
 * Business-related type definitions
 */

import type { Doc } from "@repo/backend/convex/_generated/dataModel"

/**
 * Document status during review workflow
 */
export type DocumentStatus = "pending" | "approved" | "rejected"

/**
 * Business document with metadata for ownership-specific requirements
 */
export interface BusinessDocument {
  storageId: string // Convex storage ID reference
  documentType: string // e.g., "DTI Certificate", "SEC Certificate", "Articles of Incorporation"
  fileName: string // Original filename
  uploadedAt: string // ISO timestamp
  uploadedBy?: string // User ID who uploaded
  status?: DocumentStatus // Review status
  rejectionReason?: string // Reason if rejected
}

/**
 * Required documents by ownership type
 * Based on Philippine business registration requirements
 */
export const OWNERSHIP_DOCUMENT_REQUIREMENTS: Record<string, string[]> = {
  "Sole Proprietorship": ["DTI Certificate"],
  Partnership: ["SEC Certificate", "Articles of Partnership"],
  Corporation: [
    "SEC Certificate",
    "Articles of Incorporation",
    "By-Laws",
    "General Information Sheet (GIS)",
  ],
  Cooperative: ["CDA Certificate", "Articles of Cooperation", "By-Laws"],
  "Religious/Non-Profit": [
    "SEC Certificate",
    "Articles of Incorporation",
    "By-Laws",
    "General Information Sheet (GIS)",
  ],
}

/**
 * Document validation result
 */
export interface DocumentValidationResult {
  isValid: boolean
  requiredDocuments: string[]
  uploadedDocuments: string[]
  missingDocuments: string[]
}

export interface Business {
  id: string
  name: string
  ownerName: string
  ownerId: string
  businessScale: string
  annualRevenue: string
  establishedDate: string
  dateStarted: string // Date when business operations started (ISO date format)
  registrationDate?: string // Registration date based on ownership type (DTI for Sole Proprietorship, CDA for Partnership, SEC for Corporation) - ISO date format
  registrationNumber?: string // Registration number based on ownership type (DTI/SEC/CDA registration number)
  avatar?: string
  lineOfBusiness: string
  ownershipType: string
  groupName?: string // Company/Organization name for Partnership/Corporation/Cooperative
  occupancy: string
  permitPaymentCadence: string
  numberOfEmployees: string // Legacy field - kept for backward compatibility (range format: "1-9", "10-99", etc.)
  maleEmployeeCount: number // Number of male employees
  femaleEmployeeCount: number // Number of female employees
  businessArea?: number // Business area in square meters (must be positive) - optional for backward compatibility
  propertyIndexNumber?: string // Property index number (optional)
  contactNumber: string
  email: string
  // NEW: Hierarchical location fields
  address: string // Free-form street address (House No., Street, Building)
  buildingName?: string // Building name (optional)
  provinceId: string // Foreign key to provinces table
  cityId: string // Foreign key to cities table
  barangayId: string // Foreign key to barangays table
  // DEPRECATED: Legacy address fields (kept for backward compatibility during migration)
  houseNo?: string
  street?: string
  city?: string
  district?: string
  barangay?: string
  zone?: string
  // Business classification (optional - existing businesses may be unclassified)
  categoryId?: string // Foreign key to business_categories table
  subCategoryId?: string // Foreign key to business_subcategories table
  // Ownership-specific documents (DTI, SEC, etc.)
  documents?: BusinessDocument[]
  isBlacklisted: boolean
  blacklistReason?: string
  blacklistedAt?: string
  blacklistedBy?: string
}

/**
 * Fee override for manual fee adjustments
 */
export interface FeeOverride {
  feeId: string // Foreign key to fees table
  feeName: string // Fee name for reference
  originalAmount: number // Original calculated amount
  overriddenAmount: number // New overridden amount
  overriddenAt?: string // ISO timestamp when override was applied
  overriddenBy?: string // User ID who applied the override
}

export interface LineOfBusiness {
  id: string
  businessCategory: string
  groupId?: string // Foreign key to groups table
  capitalInvestment: string
  grossSales: string
  businessAnnualRevenue?: string // Legacy field - kept for backward compatibility
  permitApplicationType?: string
  numberOfEmployees?: number
  feeOverrides?: FeeOverride[] // Per-LOB fee overrides
  excludedFees?: string[] // Array of fee IDs to exclude from calculation
}

// Derived types
export type BusinessFormInput = Pick<Business, 'name' | 'ownerId'>
export type BusinessSummary = Omit<Business, 'avatar'>

/**
 * Helper function: Calculate total employee count
 * Use this to get the total number of employees from male + female counts
 *
 * @param business - Business object with employee counts
 * @returns Total number of employees (male + female)
 */
export const getTotalEmployeeCount = (business: Business): number => {
  return business.maleEmployeeCount + business.femaleEmployeeCount
}
