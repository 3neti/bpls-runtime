/**
 * Mock Department Fee Library Data
 *
 * Mock data for department-specific fees that can be applied during clearance approval.
 * In production, this would be fetched from Convex database.
 */

import type { DepartmentFee } from "@/lib/types/fees"

/**
 * Sanitary Department Fees
 */
export const sanitaryFees: DepartmentFee[] = [
  {
    id: "san-001",
    name: "Sanitary Permit Fee",
    defaultAmount: 500,
    description: "Basic sanitary permit for food establishments and service businesses",
    departmentId: "dept-sanitary",
    departmentName: "Sanitary Department",
    isActive: true,
  },
  {
    id: "san-002",
    name: "Food Handling Certificate",
    defaultAmount: 300,
    description: "Required certificate for employees handling food products",
    departmentId: "dept-sanitary",
    departmentName: "Sanitary Department",
    isActive: true,
  },
  {
    id: "san-003",
    name: "Health Certificate",
    defaultAmount: 250,
    description: "Health certificate for business owners and employees",
    departmentId: "dept-sanitary",
    departmentName: "Sanitary Department",
    isActive: true,
  },
  {
    id: "san-004",
    name: "Sanitary Inspection Fee",
    defaultAmount: 400,
    description: "On-site sanitary inspection of business premises and facilities",
    departmentId: "dept-sanitary",
    departmentName: "Sanitary Department",
    isActive: true,
  },
  {
    id: "san-005",
    name: "Water Quality Test Fee",
    defaultAmount: 600,
    description: "Laboratory testing of water quality for drinking and food preparation",
    departmentId: "dept-sanitary",
    departmentName: "Sanitary Department",
    isActive: true,
  },
  {
    id: "san-006",
    name: "Waste Disposal Permit",
    defaultAmount: 350,
    description: "Permit for proper waste disposal and management systems",
    departmentId: "dept-sanitary",
    departmentName: "Sanitary Department",
    isActive: true,
  },
  {
    id: "san-007",
    name: "Sanitary Clearance Renewal",
    defaultAmount: 450,
    description: "Annual renewal fee for existing sanitary clearance",
    departmentId: "dept-sanitary",
    departmentName: "Sanitary Department",
    isActive: true,
  },
  {
    id: "san-008",
    name: "Pest Control Certificate (Inactive)",
    defaultAmount: 350,
    description: "Certificate for pest control services - currently inactive",
    departmentId: "dept-sanitary",
    departmentName: "Sanitary Department",
    isActive: false,
  },
]

/**
 * Bureau of Fire Protection (BFP) Fees
 */
export const bfpFees: DepartmentFee[] = [
  {
    id: "bfp-001",
    name: "Fire Safety Inspection Fee",
    defaultAmount: 800,
    description: "Comprehensive fire safety inspection of business premises and facilities",
    departmentId: "dept-bfp",
    departmentName: "Bureau of Fire Protection",
    isActive: true,
  },
  {
    id: "bfp-002",
    name: "Fire Safety Evaluation Clearance (FSEC)",
    defaultAmount: 1500,
    description: "Official fire safety evaluation clearance certificate for business operations",
    departmentId: "dept-bfp",
    departmentName: "Bureau of Fire Protection",
    isActive: true,
  },
  {
    id: "bfp-003",
    name: "Fire Drill Certificate",
    defaultAmount: 500,
    description: "Certificate of completion for required fire drill training and coordination",
    departmentId: "dept-bfp",
    departmentName: "Bureau of Fire Protection",
    isActive: true,
  },
  {
    id: "bfp-004",
    name: "Fire Extinguisher Testing Fee",
    defaultAmount: 300,
    description: "Testing and certification of fire extinguishers for compliance",
    departmentId: "dept-bfp",
    departmentName: "Bureau of Fire Protection",
    isActive: true,
  },
  {
    id: "bfp-005",
    name: "Fire Alarm System Inspection",
    defaultAmount: 1000,
    description: "Inspection and testing of fire alarm detection systems",
    departmentId: "dept-bfp",
    departmentName: "Bureau of Fire Protection",
    isActive: true,
  },
  {
    id: "bfp-006",
    name: "Sprinkler System Inspection",
    defaultAmount: 1200,
    description: "Inspection and testing of automatic sprinkler fire suppression systems",
    departmentId: "dept-bfp",
    departmentName: "Bureau of Fire Protection",
    isActive: true,
  },
  {
    id: "bfp-007",
    name: "Emergency Exit Certification",
    defaultAmount: 600,
    description: "Certification of emergency exit routes and egress compliance",
    departmentId: "dept-bfp",
    departmentName: "Bureau of Fire Protection",
    isActive: true,
  },
  {
    id: "bfp-008",
    name: "Fire Code Compliance Review (Inactive)",
    defaultAmount: 750,
    description: "Comprehensive fire code compliance review - temporarily inactive",
    departmentId: "dept-bfp",
    departmentName: "Bureau of Fire Protection",
    isActive: false,
  },
]

/**
 * Municipal Planning & Development Coordinator (MPDC) Fees
 */
export const mpdcFees: DepartmentFee[] = [
  {
    id: "mpdc-001",
    name: "Zoning Clearance Fee",
    defaultAmount: 1000,
    description: "Verification and clearance of zoning compliance for business location",
    departmentId: "dept-mpdc",
    departmentName: "Municipal Planning & Development Coordinator",
    isActive: true,
  },
  {
    id: "mpdc-002",
    name: "Building Plan Review Fee",
    defaultAmount: 1500,
    description: "Technical review and approval of building construction plans",
    departmentId: "dept-mpdc",
    departmentName: "Municipal Planning & Development Coordinator",
    isActive: true,
  },
  {
    id: "mpdc-003",
    name: "Land Use Permit",
    defaultAmount: 800,
    description: "Permit for specific land use classification and compliance",
    departmentId: "dept-mpdc",
    departmentName: "Municipal Planning & Development Coordinator",
    isActive: true,
  },
  {
    id: "mpdc-004",
    name: "Site Development Plan Review",
    defaultAmount: 1200,
    description: "Review and approval of comprehensive site development plans",
    departmentId: "dept-mpdc",
    departmentName: "Municipal Planning & Development Coordinator",
    isActive: true,
  },
  {
    id: "mpdc-005",
    name: "Occupancy Permit",
    defaultAmount: 600,
    description: "Certificate of occupancy for completed structures and buildings",
    departmentId: "dept-mpdc",
    departmentName: "Municipal Planning & Development Coordinator",
    isActive: true,
  },
  {
    id: "mpdc-006",
    name: "Subdivision Plan Review",
    defaultAmount: 2000,
    description: "Review and approval of subdivision and land development plans",
    departmentId: "dept-mpdc",
    departmentName: "Municipal Planning & Development Coordinator",
    isActive: true,
  },
  {
    id: "mpdc-007",
    name: "Location Clearance Fee",
    defaultAmount: 750,
    description: "Clearance verification for business establishment location",
    departmentId: "dept-mpdc",
    departmentName: "Municipal Planning & Development Coordinator",
    isActive: true,
  },
]

/**
 * Municipal Environment & Natural Resources Office (MENRO) Fees
 */
export const menroFees: DepartmentFee[] = [
  {
    id: "menro-001",
    name: "Environmental Compliance Certificate",
    defaultAmount: 1500,
    description: "Certificate of environmental compliance for business operations",
    departmentId: "dept-menro",
    departmentName: "Municipal Environment & Natural Resources Office",
    isActive: true,
  },
  {
    id: "menro-002",
    name: "Tree Cutting Permit",
    defaultAmount: 500,
    description: "Permit for tree cutting, pruning, or relocation on business premises",
    departmentId: "dept-menro",
    departmentName: "Municipal Environment & Natural Resources Office",
    isActive: true,
  },
  {
    id: "menro-003",
    name: "Solid Waste Management Compliance Fee",
    defaultAmount: 700,
    description: "Compliance certification for solid waste management practices",
    departmentId: "dept-menro",
    departmentName: "Municipal Environment & Natural Resources Office",
    isActive: true,
  },
  {
    id: "menro-004",
    name: "Water Discharge Permit",
    defaultAmount: 900,
    description: "Permit for wastewater discharge and effluent management",
    departmentId: "dept-menro",
    departmentName: "Municipal Environment & Natural Resources Office",
    isActive: true,
  },
  {
    id: "menro-005",
    name: "Air Quality Compliance Fee",
    defaultAmount: 800,
    description: "Air quality monitoring and emission compliance certification",
    departmentId: "dept-menro",
    departmentName: "Municipal Environment & Natural Resources Office",
    isActive: true,
  },
  {
    id: "menro-006",
    name: "Hazardous Waste Disposal Permit",
    defaultAmount: 2000,
    description: "Permit for handling and disposal of hazardous materials and waste",
    departmentId: "dept-menro",
    departmentName: "Municipal Environment & Natural Resources Office",
    isActive: true,
  },
  {
    id: "menro-007",
    name: "Environmental Impact Assessment",
    defaultAmount: 1800,
    description: "Comprehensive environmental impact assessment for new developments",
    departmentId: "dept-menro",
    departmentName: "Municipal Environment & Natural Resources Office",
    isActive: true,
  },
]

/**
 * Engineering Department Fees
 */
export const engineeringFees: DepartmentFee[] = [
  {
    id: "eng-001",
    name: "Structural Plan Review",
    defaultAmount: 2000,
    description: "Review and approval of structural engineering plans and calculations",
    departmentId: "dept-engineering",
    departmentName: "Engineering Department",
    isActive: true,
  },
  {
    id: "eng-002",
    name: "Electrical Plan Review",
    defaultAmount: 1200,
    description: "Review and approval of electrical system design and wiring plans",
    departmentId: "dept-engineering",
    departmentName: "Engineering Department",
    isActive: true,
  },
  {
    id: "eng-003",
    name: "Plumbing Plan Review",
    defaultAmount: 1000,
    description: "Review and approval of plumbing and sanitary system plans",
    departmentId: "dept-engineering",
    departmentName: "Engineering Department",
    isActive: true,
  },
  {
    id: "eng-004",
    name: "Mechanical Plan Review",
    defaultAmount: 1500,
    description: "Review and approval of mechanical systems and HVAC plans",
    departmentId: "dept-engineering",
    departmentName: "Engineering Department",
    isActive: true,
  },
  {
    id: "eng-005",
    name: "Building Permit Processing Fee",
    defaultAmount: 800,
    description: "Processing fee for building permit applications and documentation",
    departmentId: "dept-engineering",
    departmentName: "Engineering Department",
    isActive: true,
  },
  {
    id: "eng-006",
    name: "As-Built Plan Verification",
    defaultAmount: 1800,
    description: "Verification and approval of as-built construction plans",
    departmentId: "dept-engineering",
    departmentName: "Engineering Department",
    isActive: true,
  },
  {
    id: "eng-007",
    name: "Excavation Permit",
    defaultAmount: 900,
    description: "Permit for excavation works and earth-moving activities",
    departmentId: "dept-engineering",
    departmentName: "Engineering Department",
    isActive: true,
  },
]

/**
 * All Department Fees Registry
 * Consolidated list of all fees across departments
 */
export const allDepartmentFees: DepartmentFee[] = [
  ...sanitaryFees,
  ...bfpFees,
  ...mpdcFees,
  ...menroFees,
  ...engineeringFees,
]

/**
 * Get fees by department ID
 *
 * @param departmentId - Department identifier (e.g., "sanitary", "bfp")
 * @returns Array of fees for the specified department
 */
export function getFeesByDepartment(departmentId: string): DepartmentFee[] {
  return allDepartmentFees.filter((fee) => fee.departmentId === departmentId && fee.isActive)
}

/**
 * Get fee by ID
 *
 * @param feeId - Fee identifier
 * @returns Fee object or undefined if not found
 */
export function getFeeById(feeId: string): DepartmentFee | undefined {
  return allDepartmentFees.find((fee) => fee.id === feeId)
}
