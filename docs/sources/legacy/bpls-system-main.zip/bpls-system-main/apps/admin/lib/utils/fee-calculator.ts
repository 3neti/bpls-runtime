/**
 * Fee Calculation Utilities
 *
 * Provides utilities for calculating fees based on business data.
 * Can be used both on the frontend (for preview) and backend (for final calculation).
 *
 * Fee Types:
 * - Constant: Fixed amount
 * - Range: Based on business field value within ranges
 * - Formula: Calculated using business metrics
 */

import type { BusinessData, FeeRange, CalculatedFee } from "@/lib/types/fees"

/**
 * Calculate fee amount based on fee configuration and business data
 */
export function calculateFeeAmount(
  feeType: "Constant" | "Range" | "Formula",
  amount: number,
  businessData: BusinessData,
  rangeField?: string,
  ranges?: FeeRange[],
  formula?: string
): number {
  switch (feeType) {
    case "Constant":
      return amount

    case "Range":
      if (!ranges || !rangeField) {
        return 0
      }

      // Get field value - check standard fields first, then category variables
      let fieldValue: number = 0
      if (rangeField in businessData) {
        fieldValue = (businessData[rangeField as keyof BusinessData] ?? 0) as number
      } else if (businessData.categoryVariables && rangeField in businessData.categoryVariables) {
        fieldValue = businessData.categoryVariables[rangeField] ?? 0
      }

      const matchingRange = ranges.find((range) => fieldValue >= range.min && fieldValue <= range.max)

      if (!matchingRange) {
        return 0
      }

      // If the range has a formula (final range), evaluate it
      if (matchingRange.formula) {
        return calculateFeeAmount("Formula", 0, businessData, undefined, undefined, matchingRange.formula)
      }

      // Otherwise use the fixed fee amount
      return matchingRange.fee ?? 0

    case "Formula":
      if (!formula) {
        return 0
      }

      try {
        // Start with standard business variables
        let expression = formula
          .replace(/numberOfEmployees/g, (businessData.numberOfEmployees ?? 0).toString())
          .replace(/maleEmployeeCount/g, (businessData.maleEmployeeCount ?? 0).toString())
          .replace(/femaleEmployeeCount/g, (businessData.femaleEmployeeCount ?? 0).toString())
          .replace(/businessArea/g, (businessData.businessArea ?? 0).toString())
          .replace(/floorArea/g, (businessData.businessArea ?? 0).toString()) // floorArea is an alias for businessArea
          .replace(/capitalInvestment/g, (businessData.capitalInvestment ?? 0).toString())
          .replace(/grossSales/g, (businessData.grossSales ?? 0).toString())
          .replace(/businessAnnualRevenue/g, (businessData.businessAnnualRevenue ?? 0).toString())

        // Replace category variables if provided
        // Category variables are dynamic and come from the mayorsPermitCategories table
        // They follow the pattern: numberOfHorses, numberOfTables, etc.
        if (businessData.categoryVariables) {
          for (const [variableName, value] of Object.entries(businessData.categoryVariables)) {
            // Use word boundaries to avoid partial replacements
            const regex = new RegExp(`\\b${variableName}\\b`, 'g')
            expression = expression.replace(regex, (value ?? 0).toString())
          }
        }

        // Evaluate the expression
        const result = Function(`"use strict"; return (${expression})`)()

        if (typeof result === "number" && !isNaN(result)) {
          return Math.max(0, result) // Ensure non-negative
        }
      } catch (error) {
        console.error("Formula evaluation error:", error)
      }

      return 0

    default:
      return 0
  }
}

/**
 * Get calculation details/explanation for a fee
 */
export function getFeeCalculationDetails(
  feeType: "Constant" | "Range" | "Formula",
  amount: number,
  businessData: BusinessData,
  rangeField?: string,
  ranges?: FeeRange[],
  formula?: string
): string {
  switch (feeType) {
    case "Constant":
      return `Fixed fee: ${formatCurrency(amount)}`

    case "Range":
      if (!ranges || !rangeField) {
        return "Invalid range configuration"
      }

      // Get field value - check standard fields first, then category variables
      let fieldValue: number = 0
      if (rangeField in businessData) {
        fieldValue = (businessData[rangeField as keyof BusinessData] ?? 0) as number
      } else if (businessData.categoryVariables && rangeField in businessData.categoryVariables) {
        fieldValue = businessData.categoryVariables[rangeField] ?? 0
      }

      const matchingRange = ranges.find((range) => fieldValue >= range.min && fieldValue <= range.max)

      if (matchingRange) {
        // Check if range uses formula (final range)
        if (matchingRange.formula) {
          const calculatedAmount = calculateFeeAmount("Formula", 0, businessData, undefined, undefined, matchingRange.formula)
          return `${getFieldLabel(rangeField, businessData.categoryVariables)}: ${fieldValue} falls in range ${matchingRange.min}-${matchingRange.max} (Formula: ${matchingRange.formula}) = ${formatCurrency(calculatedAmount)}`
        }
        // Standard range with fixed fee
        return `${getFieldLabel(rangeField, businessData.categoryVariables)}: ${fieldValue} falls in range ${matchingRange.min}-${matchingRange.max} = ${formatCurrency(matchingRange.fee ?? 0)}`
      }

      return `${getFieldLabel(rangeField, businessData.categoryVariables)}: ${fieldValue} does not match any configured range`

    case "Formula":
      if (!formula) {
        return "No formula configured"
      }

      const calculatedAmount = calculateFeeAmount(feeType, amount, businessData, rangeField, ranges, formula)
      return `Formula: ${formula} = ${formatCurrency(calculatedAmount)}`

    default:
      return "Unknown fee type"
  }
}

/**
 * Validate formula syntax
 * Accepts categoryVariables to allow validation of dynamic category-based formulas
 */
export function validateFormula(
  formula: string,
  categoryVariables?: Record<string, number>
): { valid: boolean; error?: string } {
  // Standard allowed variables (floorArea is an alias for businessArea)
  const standardVariables = [
    "numberOfEmployees",
    "maleEmployeeCount",
    "femaleEmployeeCount",
    "businessArea",
    "floorArea",
    "capitalInvestment",
    "grossSales",
    "businessAnnualRevenue"
  ]

  // Combine standard and category variables
  const allowedVariables = categoryVariables
    ? [...standardVariables, ...Object.keys(categoryVariables)]
    : standardVariables

  const variablePattern = /[a-zA-Z_][a-zA-Z0-9_]*/g
  const variables = formula.match(variablePattern) || []

  for (const variable of variables) {
    if (!allowedVariables.includes(variable)) {
      return {
        valid: false,
        error: `Unknown variable: ${variable}. Allowed variables: ${allowedVariables.join(", ")}`,
      }
    }
  }

  // Try to evaluate with sample data to check syntax
  try {
    const sampleData: BusinessData = {
      numberOfEmployees: 10,
      maleEmployeeCount: 6,
      femaleEmployeeCount: 4,
      businessArea: 200,
      capitalInvestment: 500000,
      grossSales: 1000000,
      businessAnnualRevenue: 1000000,
      categoryVariables: categoryVariables || {},
    }

    const result = calculateFeeAmount("Formula", 0, sampleData, undefined, undefined, formula)

    if (typeof result !== "number" || isNaN(result)) {
      return { valid: false, error: "Formula must evaluate to a valid number" }
    }

    return { valid: true }
  } catch (error) {
    return {
      valid: false,
      error: `Syntax error: ${error instanceof Error ? error.message : String(error)}`,
    }
  }
}

/**
 * Validate fee ranges
 * Accepts optional categoryVariables to validate formulas that use category-based variables
 */
export function validateRanges(
  ranges: FeeRange[],
  categoryVariables?: Record<string, number>
): { valid: boolean; error?: string } {
  if (ranges.length === 0) {
    return { valid: false, error: "At least one range is required" }
  }

  // Check for overlapping ranges
  for (let i = 0; i < ranges.length; i++) {
    const range = ranges[i]
    const isLastRange = i === ranges.length - 1

    // Validate range structure
    if (range.min < 0 || range.max < 0) {
      return { valid: false, error: `Range ${i + 1}: Min and max values must be non-negative` }
    }

    // Check that range has either fee or formula (but not both)
    const hasFee = range.fee !== undefined && range.fee > 0
    const hasFormula = range.formula !== undefined && range.formula.trim() !== ""

    // Check if range is blank (min=0, max=0, no fee, no formula) - typically a placeholder final range
    const isBlankRange = range.min === 0 && range.max === 0 && !hasFee && !hasFormula

    // Skip validation for blank final ranges (they're placeholders)
    if (isLastRange && isBlankRange) {
      continue // Skip all validation for blank final range
    }

    // Skip min >= max validation for final range with formula (it will use calculated values)
    if (!isLastRange || !hasFormula) {
      if (range.min >= range.max) {
        return { valid: false, error: `Range ${i + 1}: Min value must be less than max value` }
      }
    }

    // All ranges can have EITHER fee OR formula (but not both)
    // Each range must have at least one (fee or formula)
    if (!hasFee && !hasFormula) {
      return { valid: false, error: `Range ${i + 1}: Must have either a fee amount or formula` }
    }

    // If both are present, warn but allow (formula takes precedence)
    if (hasFee && hasFormula) {
      console.warn(`Range ${i + 1}: Both fee and formula present - formula will take precedence`)
    }

    // Validate fee amount if present
    if (hasFee && (range.fee ?? 0) < 0) {
      return { valid: false, error: `Range ${i + 1}: Fee amount must be non-negative` }
    }

    // Validate formula if present
    if (hasFormula && range.formula) {
      // Pass category variables to formula validation if available
      const formulaValidation = validateFormula(range.formula, categoryVariables)
      if (!formulaValidation.valid) {
        return {
          valid: false,
          error: `Range ${i + 1} formula: ${formulaValidation.error}`,
        }
      }
    }

    // Check for overlaps with other ranges
    // Skip overlap checking for blank ranges and only check non-final ranges
    if (!isBlankRange) {
      for (let j = i + 1; j < ranges.length; j++) {
        const otherRange = ranges[j]

        // Check if other range is blank
        const otherHasFee = otherRange.fee !== undefined && otherRange.fee > 0
        const otherHasFormula = otherRange.formula !== undefined && otherRange.formula.trim() !== ""
        const otherIsBlank = otherRange.min === 0 && otherRange.max === 0 && !otherHasFee && !otherHasFormula

        // Skip overlap check if either range is blank
        if (otherIsBlank) {
          continue
        }

        const overlaps =
          (range.min >= otherRange.min && range.min <= otherRange.max) ||
          (range.max >= otherRange.min && range.max <= otherRange.max) ||
          (otherRange.min >= range.min && otherRange.min <= range.max)

        if (overlaps) {
          return {
            valid: false,
            error: `Range ${i + 1} overlaps with Range ${j + 1}`,
          }
        }
      }
    }
  }

  return { valid: true }
}

/**
 * Calculate enterprise size based on Philippine MSME standards
 */
export function calculateEnterpriseSize(
  totalAssets: number,
  numberOfEmployees: number
): "Micro" | "Small" | "Medium" | "Large" {
  // Philippine MSME criteria (DTI standards)
  if (totalAssets <= 3000000 && numberOfEmployees <= 9) {
    return "Micro"
  }

  if (totalAssets <= 15000000 && numberOfEmployees <= 99) {
    return "Small"
  }

  if (totalAssets <= 100000000 && numberOfEmployees <= 199) {
    return "Medium"
  }

  return "Large"
}

// Helper functions

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-PH", {
    style: "currency",
    currency: "PHP",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount)
}

function getFieldLabel(field: string, categoryVariables?: Record<string, number>): string {
  const labels: Record<string, string> = {
    numberOfEmployees: "Number of Employees",
    maleEmployeeCount: "Male Employee Count",
    femaleEmployeeCount: "Female Employee Count",
    businessArea: "Business Area (sq.m)",
    capitalInvestment: "Capital Investment (from LOB)",
    businessAnnualRevenue: "Business Annual Revenue (from LOB)",
  }

  // Check if it's a category variable
  if (categoryVariables && field in categoryVariables) {
    // Convert camelCase to Title Case for display
    // e.g., "numberOfHorses" -> "Number Of Horses"
    return field.replace(/([A-Z])/g, ' $1').replace(/^./, (str) => str.toUpperCase())
  }

  return labels[field] || field
}

/**
 * Format business data for display
 * Includes both standard business fields and dynamic category variables
 */
export function formatBusinessData(businessData: BusinessData): Record<string, string> {
  const formatted: Record<string, string> = {
    "Number of Employees": (businessData.numberOfEmployees ?? 0).toString(),
    "Male Employee Count": (businessData.maleEmployeeCount ?? 0).toString(),
    "Female Employee Count": (businessData.femaleEmployeeCount ?? 0).toString(),
    "Business Area": `${businessData.businessArea ?? 0} sq.m`,
    "Capital Investment (from LOB)": `₱${(businessData.capitalInvestment ?? 0).toLocaleString()}`,
    "Business Annual Revenue (from LOB)": `₱${(businessData.businessAnnualRevenue ?? 0).toLocaleString()}`,
  }

  // Add category variables if present
  if (businessData.categoryVariables) {
    for (const [variableName, value] of Object.entries(businessData.categoryVariables)) {
      const label = getFieldLabel(variableName, businessData.categoryVariables)
      formatted[label] = value.toString()
    }
  }

  return formatted
}

/**
 * Calculate total fees from multiple calculated fees
 */
export function calculateTotalFees(calculatedFees: CalculatedFee[]): number {
  return calculatedFees.reduce((total, fee) => total + fee.amount, 0)
}
