/**
 * Client-side report computation for permit applications.
 *
 * Moves heavy cross-product flattening, fee calculation, filtering,
 * aggregation, sorting, and pagination from the Convex server to the
 * browser, avoiding Convex's 1-second query timeout.
 */

// ===========================================
// TYPES
// ===========================================

type ReportRow = Record<string, unknown>

interface MetricConfig {
  id: string
  name: string
  aggregation: string
  format: string
  field?: string
  filter?: { dimensionId: string; operator: string; value: unknown }
}

interface MetricResult {
  metricId: string
  name: string
  value: number
  format: string
}

interface FilterGroup {
  id: string
  logic: string
  conditions: Array<{ dimensionId: string; operator: string; value: unknown }>
  groups?: Array<{
    logic: string
    conditions: Array<{ dimensionId: string; operator: string; value: unknown }>
  }>
}

interface DateRangeConfig {
  preset: string
  startDate?: string
  endDate?: string
  dimensionId?: string
}

interface SortConfig {
  field: string
  direction: "asc" | "desc"
}

export interface ReportComputationConfig {
  dimensions: string[]
  metrics: MetricConfig[]
  filters?: FilterGroup | null
  dateRange?: DateRangeConfig | null
  sort?: SortConfig | null
  page: number
  pageSize: number
}

export interface ReportResult {
  rows: ReportRow[]
  aggregations: MetricResult[]
  totalCount: number
  page: number
  pageSize: number
  totalPages: number
}

/** Raw data shape returned by the lightweight Convex query */
export interface PermitApplicationReportData {
  applications: any[]
  owners: any[]
  businesses: any[]
  schedules: any[]
  payments: any[]
  clearances: any[]
  provinces: any[]
  cities: any[]
  barangays: any[]
  groups: any[]
  divisionGroups: any[]
  divisions: any[]
  majors: any[]
  users: any[]
  fees: any[]
  feeOverrides: any[]
  unitsOfMeasurement: any[]
}

// ===========================================
// DIMENSION ID SETS
// ===========================================

const LOB_DIMS = new Set(["lobMajor", "lobDivision", "lobGroup", "lobPermitType", "lobCapitalInvestment", "lobGrossSales", "lobEmployees"])
const FEE_DIMS = new Set(["feeName", "feeCategory", "feeOriginalAmount", "feeSectionAmount"])
const SCHEDULE_DIMS = new Set(["scheduleSection", "scheduleDueDate", "scheduleStatus", "scheduleSurcharge", "schedulePenalty", "scheduleTotalAmount", "schedulePaidAmount"])
const PAYMENT_DIMS = new Set(["orNumber", "transactionNumber", "paymentAmount", "paymentMethod", "paymentStatus", "paymentReference", "datePaid", "processedBy"])
const CLEARANCE_DIMS = new Set(["clearanceName", "clearanceStatus", "clearanceCompletedAt", "clearanceCompletedBy"])
const LOB_FEE_DIMS = new Set(["lobFeeName", "lobFeeCategory", "lobFeeAmount"])

// ===========================================
// HELPER FUNCTIONS
// ===========================================

function parseDateRange(preset: string, startDate?: string, endDate?: string): { start: Date; end: Date } | null {
  const now = new Date()
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())

  switch (preset) {
    case "today":
      return { start: today, end: new Date(today.getTime() + 86400000 - 1) }
    case "yesterday": {
      const yesterday = new Date(today.getTime() - 86400000)
      return { start: yesterday, end: new Date(yesterday.getTime() + 86400000 - 1) }
    }
    case "thisWeek": {
      const startOfWeek = new Date(today.getTime() - today.getDay() * 86400000)
      return { start: startOfWeek, end: now }
    }
    case "lastWeek": {
      const lastWeekEnd = new Date(today.getTime() - today.getDay() * 86400000 - 1)
      const lastWeekStart = new Date(lastWeekEnd.getTime() - 6 * 86400000)
      return { start: lastWeekStart, end: lastWeekEnd }
    }
    case "thisMonth":
      return { start: new Date(now.getFullYear(), now.getMonth(), 1), end: now }
    case "lastMonth":
      return { start: new Date(now.getFullYear(), now.getMonth() - 1, 1), end: new Date(now.getFullYear(), now.getMonth(), 0) }
    case "thisQuarter": {
      const quarter = Math.floor(now.getMonth() / 3)
      return { start: new Date(now.getFullYear(), quarter * 3, 1), end: now }
    }
    case "thisYear":
      return { start: new Date(now.getFullYear(), 0, 1), end: now }
    case "last7Days":
      return { start: new Date(today.getTime() - 7 * 86400000), end: now }
    case "last30Days":
      return { start: new Date(today.getTime() - 30 * 86400000), end: now }
    case "last90Days":
      return { start: new Date(today.getTime() - 90 * 86400000), end: now }
    case "custom":
      if (startDate && endDate) return { start: new Date(startDate), end: new Date(endDate) }
      return null
    default:
      return null
  }
}

function matchesCondition(value: unknown, operator: string, filterValue: unknown): boolean {
  if (value === null || value === undefined) {
    if (operator === "isEmpty") return true
    if (operator === "isNotEmpty") return false
    return false
  }
  if (operator === "isEmpty") return false
  if (operator === "isNotEmpty") return true

  if (typeof value === "string") {
    const strValue = value.toLowerCase()
    const strFilter = typeof filterValue === "string" ? filterValue.toLowerCase() : ""
    switch (operator) {
      case "equals": return strValue === strFilter
      case "notEquals": return strValue !== strFilter
      case "contains": return strValue.includes(strFilter)
      case "startsWith": return strValue.startsWith(strFilter)
      case "endsWith": return strValue.endsWith(strFilter)
      case "in": return Array.isArray(filterValue) && filterValue.includes(value)
      case "notIn": return Array.isArray(filterValue) && !filterValue.includes(value)
      case "between":
        if (Array.isArray(filterValue) && filterValue.length === 2) {
          const numValue = Number(value)
          const numFrom = Number(filterValue[0])
          const numTo = Number(filterValue[1])
          if (!isNaN(numValue) && !isNaN(numFrom) && !isNaN(numTo)) {
            return numValue >= numFrom && numValue <= numTo
          }
          const filterFrom = String(filterValue[0]).toLowerCase()
          const filterTo = String(filterValue[1]).toLowerCase()
          return strValue >= filterFrom && strValue <= filterTo
        }
        return false
    }
  }

  if (typeof value === "number") {
    const numFilter = typeof filterValue === "number" ? filterValue : Number(filterValue)
    switch (operator) {
      case "equals": return value === numFilter
      case "notEquals": return value !== numFilter
      case "gt": return value > numFilter
      case "gte": return value >= numFilter
      case "lt": return value < numFilter
      case "lte": return value <= numFilter
      case "between":
        if (Array.isArray(filterValue) && filterValue.length === 2) return value >= filterValue[0] && value <= filterValue[1]
        return false
    }
  }

  if (typeof value === "boolean") {
    if (operator === "equals") return value === filterValue
  }

  if (typeof value === "string" && operator.match(/before|after|between/)) {
    try {
      const dateValue = new Date(value).getTime()
      if (operator === "before") return dateValue < new Date(filterValue as string).getTime()
      if (operator === "after") return dateValue > new Date(filterValue as string).getTime()
      if (operator === "between" && Array.isArray(filterValue)) {
        return dateValue >= new Date(filterValue[0]).getTime() && dateValue <= new Date(filterValue[1]).getTime()
      }
    } catch { return false }
  }

  return true
}

function applyFilters(rows: ReportRow[], filterGroup: FilterGroup | null): ReportRow[] {
  if (!filterGroup || filterGroup.conditions.length === 0) return rows
  return rows.filter((row) => {
    const conditionResults = filterGroup.conditions.map((c) => matchesCondition(row[c.dimensionId], c.operator, c.value))
    const groupResults = filterGroup.groups?.map((group) => {
      const groupConditionResults = group.conditions.map((c) => matchesCondition(row[c.dimensionId], c.operator, c.value))
      return group.logic === "AND" ? groupConditionResults.every(Boolean) : groupConditionResults.some(Boolean)
    }) || []
    const allResults = [...conditionResults, ...groupResults]
    return filterGroup.logic === "AND" ? allResults.every(Boolean) : allResults.some(Boolean)
  })
}

function calculateAggregations(rows: ReportRow[], metrics: MetricConfig[]): MetricResult[] {
  return metrics.map((metric) => {
    let filteredRows = rows
    if (metric.filter) {
      filteredRows = rows.filter((row) => matchesCondition(row[metric.filter!.dimensionId], metric.filter!.operator, metric.filter!.value))
    }
    let value = 0
    switch (metric.aggregation) {
      case "count": value = filteredRows.length; break
      case "sum":
        if (metric.field) value = filteredRows.reduce((s, r) => s + (typeof r[metric.field!] === "number" ? (r[metric.field!] as number) : 0), 0)
        break
      case "average":
        if (metric.field && filteredRows.length > 0) {
          const sum = filteredRows.reduce((s, r) => s + (typeof r[metric.field!] === "number" ? (r[metric.field!] as number) : 0), 0)
          value = sum / filteredRows.length
        }
        break
      case "min":
        if (metric.field && filteredRows.length > 0) {
          const vals = filteredRows.map((r) => r[metric.field!]).filter((v): v is number => typeof v === "number")
          value = vals.length > 0 ? Math.min(...vals) : 0
        }
        break
      case "max":
        if (metric.field && filteredRows.length > 0) {
          const vals = filteredRows.map((r) => r[metric.field!]).filter((v): v is number => typeof v === "number")
          value = vals.length > 0 ? Math.max(...vals) : 0
        }
        break
      case "countDistinct":
        if (metric.field) value = new Set(filteredRows.map((r) => r[metric.field!])).size
        break
    }
    return { metricId: metric.id, name: metric.name, value, format: metric.format }
  })
}

// ===========================================
// PERMIT APPLICATION SPECIFIC HELPERS
// ===========================================

function resolveGroupHierarchy(
  groupName: string,
  groupsByName: Map<string, any>,
  divisionGroupsByGroupId: Map<string, any[]>,
  divisionsMap: Map<string, any>,
  majorsMap: Map<string, any>,
): { majorName: string; divisionName: string } {
  const group = groupsByName.get(groupName)
  let majorName = ""
  let divisionName = ""
  if (group) {
    const dgs = divisionGroupsByGroupId.get(group._id as string) || []
    if (dgs.length > 0) {
      const division = divisionsMap.get(dgs[0].divisionId as string)
      if (division) {
        divisionName = division.name
        const major = majorsMap.get(division.majorId as string)
        if (major) majorName = major.name
      }
    }
  }
  return { majorName, divisionName }
}

function buildLobFields(
  lob: any | null,
  groupsByName: Map<string, any>,
  divisionGroupsByGroupId: Map<string, any[]>,
  divisionsMap: Map<string, any>,
  majorsMap: Map<string, any>,
): Record<string, unknown> {
  if (!lob) return { lobMajor: "", lobDivision: "", lobGroup: "", lobPermitType: "", lobCapitalInvestment: 0, lobGrossSales: 0, lobEmployees: 0 }
  const { majorName, divisionName } = resolveGroupHierarchy(lob.businessCategory, groupsByName, divisionGroupsByGroupId, divisionsMap, majorsMap)
  return {
    lobMajor: majorName,
    lobDivision: divisionName,
    lobGroup: lob.businessCategory || "",
    lobPermitType: lob.permitApplicationType || "",
    lobCapitalInvestment: parseFloat(lob.capitalInvestment) || 0,
    lobGrossSales: parseFloat(lob.grossSales || "0") || 0,
    lobEmployees: lob.numberOfEmployees || 0,
  }
}

function buildScheduleItemFields(
  item: { type: "fee" | "payment" | "schedule"; data: any; schedule: any; payments?: any[] } | null,
  usersMap: Map<string, any>,
): Record<string, unknown> {
  if (!item) {
    return {
      feeName: "", feeCategory: "", feeOriginalAmount: 0, feeSectionAmount: 0,
      scheduleSection: 0, scheduleDueDate: "", scheduleStatus: "", scheduleSurcharge: 0, schedulePenalty: 0, scheduleTotalAmount: 0, schedulePaidAmount: 0,
      orNumber: "", transactionNumber: "", paymentAmount: 0, paymentMethod: "", paymentStatus: "", paymentReference: "", datePaid: "", processedBy: "",
    }
  }
  const sched = item.schedule
  const schedFields = {
    scheduleSection: sched?.sectionNumber || 0, scheduleDueDate: sched?.dueDate || "", scheduleStatus: sched?.status || "",
    scheduleSurcharge: sched?.surcharge || 0, schedulePenalty: sched?.penalty || 0, scheduleTotalAmount: sched?.totalAmount || 0, schedulePaidAmount: sched?.paidAmount || 0,
  }

  if (item.type === "fee") {
    const fee = item.data
    const schedPayments = item.payments || []
    const completedPayments = schedPayments.filter((p: any) => p.status === "completed")
    const firstPayment = completedPayments[0] || schedPayments[0]
    const processor = firstPayment?.processedBy ? usersMap.get(firstPayment.processedBy) : null
    return {
      feeName: fee.feeName || "", feeCategory: fee.feeCategory || "", feeOriginalAmount: fee.originalAmount || 0, feeSectionAmount: fee.sectionAmount || 0,
      ...schedFields,
      orNumber: firstPayment?.receiptNumber || "", transactionNumber: firstPayment?.transactionNumber || "",
      paymentAmount: completedPayments.reduce((s: number, p: any) => s + p.amount, 0),
      paymentMethod: firstPayment?.paymentMethod || "", paymentStatus: firstPayment?.status || "",
      paymentReference: firstPayment?.referenceNumber || "", datePaid: firstPayment?.paidAt || "",
      processedBy: processor ? `${processor.firstName} ${processor.lastName}` : "",
    }
  }
  if (item.type === "payment") {
    const payment = item.data
    const processor = payment.processedBy ? usersMap.get(payment.processedBy) : null
    return {
      feeName: "", feeCategory: "", feeOriginalAmount: 0, feeSectionAmount: 0,
      ...schedFields,
      orNumber: payment.receiptNumber || "", transactionNumber: payment.transactionNumber || "",
      paymentAmount: payment.amount || 0, paymentMethod: payment.paymentMethod || "",
      paymentStatus: payment.status || "", paymentReference: payment.referenceNumber || "",
      datePaid: payment.paidAt || "", processedBy: processor ? `${processor.firstName} ${processor.lastName}` : "",
    }
  }
  return {
    feeName: "", feeCategory: "", feeOriginalAmount: 0, feeSectionAmount: 0, ...schedFields,
    orNumber: "", transactionNumber: "", paymentAmount: 0, paymentMethod: "", paymentStatus: "", paymentReference: "", datePaid: "", processedBy: "",
  }
}

function buildClearanceFields(clearance: any | null, usersMap: Map<string, any>): Record<string, unknown> {
  if (!clearance) return { clearanceName: "", clearanceStatus: false, clearanceCompletedAt: "", clearanceCompletedBy: "" }
  const completedByUser = clearance.completedBy ? usersMap.get(clearance.completedBy) : null
  return {
    clearanceName: clearance.clearanceName || clearance.certificateName || "",
    clearanceStatus: clearance.isCompleted || false,
    clearanceCompletedAt: clearance.completedAt || "",
    clearanceCompletedBy: completedByUser ? `${completedByUser.firstName} ${completedByUser.lastName}` : "",
  }
}

function evaluateFormulaForReport(formula: string, businessData: { capitalInvestment: number; grossSales: number; numberOfEmployees: number; floorArea: number }, dynamicVariables?: Record<string, number>): number {
  const { numberOfEmployees = 0, grossSales = 0, capitalInvestment = 0, floorArea = 0 } = businessData
  try {
    let expr = formula
    expr = expr.replace(/\bnumberOfEmployees\b/g, String(numberOfEmployees))
    expr = expr.replace(/\bgrossSales\b/g, String(grossSales))
    expr = expr.replace(/\bcapitalInvestment\b/g, String(capitalInvestment))
    expr = expr.replace(/\bfloorArea\b/g, String(floorArea))

    // Substitute dynamic UoM variables (sorted by name length desc to avoid partial matches)
    if (dynamicVariables) {
      const sorted = Object.entries(dynamicVariables).sort((a, b) => b[0].length - a[0].length)
      for (const [varName, value] of sorted) {
        expr = expr.replace(new RegExp('\\b' + varName + '\\b', 'g'), String(value))
      }
    }

    const result = Function(`"use strict"; return (${expr})`)()
    if (typeof result !== 'number' || isNaN(result)) return 0
    return result
  } catch { return 0 }
}

function calculateFeeAmountForReport(fee: any, businessData: { capitalInvestment: number; grossSales: number; numberOfEmployees: number; floorArea: number }, dynamicVariables?: Record<string, number>): number {
  switch (fee.feeType) {
    case "Constant": return fee.amount
    case "Range":
      if (fee.ranges && fee.rangeField) {
        const fieldValue = (businessData as any)[fee.rangeField] || 0
        const matchingRange = fee.ranges.find((r: any) => fieldValue >= r.min && fieldValue <= r.max)
        if (matchingRange) {
          if (matchingRange.formula) return evaluateFormulaForReport(matchingRange.formula, businessData, dynamicVariables)
          if (matchingRange.fee !== undefined) return matchingRange.fee
        }
      }
      return 0
    case "Formula":
      if (fee.formula) return evaluateFormulaForReport(fee.formula, businessData, dynamicVariables)
      return 0
    default: return 0
  }
}

function getFeesForGroup(groupId: string, feesByDivisionId: Map<string, any[]>, feesByGroupId: Map<string, any[]>, divisionGroupsByGroupId: Map<string, any[]>): any[] {
  const inherited: any[] = []
  const dgs = divisionGroupsByGroupId.get(groupId) || []
  for (const dg of dgs) {
    inherited.push(...(feesByDivisionId.get(dg.divisionId as string) || []))
  }
  return [...inherited, ...(feesByGroupId.get(groupId) || [])]
}

function buildLobFeeFields(item: { fee: any; calculatedAmount: number } | null): Record<string, unknown> {
  if (!item) return { lobFeeName: "", lobFeeCategory: "", lobFeeAmount: 0 }
  return { lobFeeName: item.fee.name || "", lobFeeCategory: item.fee.feeCategory || "", lobFeeAmount: item.calculatedAmount }
}

// ===========================================
// MAIN COMPUTATION
// ===========================================

export function computePermitApplicationReport(
  rawData: PermitApplicationReportData,
  config: ReportComputationConfig,
): ReportResult {
  const { dimensions, metrics, filters, dateRange, sort, page, pageSize } = config

  // Collect all referenced dimension IDs
  const filterDimIds = (filters?.conditions || []).map((c) => c.dimensionId)
  const filterGroupDimIds = (filters?.groups || []).flatMap((g) => g.conditions.map((c) => c.dimensionId))
  const allReferencedDims = [...dimensions, ...filterDimIds, ...filterGroupDimIds]

  // Needs flags
  const needsOwners = allReferencedDims.some((d) => d.startsWith("owner") || d === "isBlacklisted" || d === "blacklistReason")
  const needsBusinesses = allReferencedDims.some((d) => d.startsWith("business") || d === "annualRevenue" || d === "numberOfEmployees" || d === "maleEmployeeCount" || d === "femaleEmployeeCount" || d === "registrationNumber" || d === "propertyIndexNumber" || d === "dateStarted" || d === "establishedDate" || d === "occupancy" || d === "permitPaymentCadence")
  const needsLocations = allReferencedDims.some((d) => d.includes("Province") || d.includes("City") || d.includes("Barangay"))
  const needsLobFees = allReferencedDims.some((d) => LOB_FEE_DIMS.has(d))
  const needsLobs = needsLobFees || allReferencedDims.some((d) => LOB_DIMS.has(d))
  const needsFees = allReferencedDims.some((d) => FEE_DIMS.has(d))
  const needsScheduleRows = allReferencedDims.some((d) => SCHEDULE_DIMS.has(d))
  const needsPaymentRows = allReferencedDims.some((d) => PAYMENT_DIMS.has(d))
  const needsClearanceRows = allReferencedDims.some((d) => CLEARANCE_DIMS.has(d))
  const needsLobFeeMatching = needsLobs && needsFees

  const metricFields = new Set(metrics.map((m) => m.field).filter(Boolean))
  const metricFilterDims = new Set(metrics.map((m) => m.filter?.dimensionId).filter(Boolean))
  const needsPaymentMetrics = metricFields.has("paidAmount") || metricFields.has("outstanding")
  const needsScheduleMetrics = metricFields.has("surcharge") || metricFields.has("penalty") || needsPaymentMetrics
  const needsClearanceMetrics = metricFields.has("clearanceProgress") || metricFields.has("completedClearances") || metricFields.has("pendingClearances") || metricFilterDims.has("clearanceStatus")
  const needsScheduleData = needsFees || needsScheduleRows || needsPaymentRows || needsScheduleMetrics
  const needsPaymentData = needsPaymentRows || needsPaymentMetrics
  const needsClearanceData = needsClearanceRows || needsClearanceMetrics

  // Build lookup maps
  const ownersMap = new Map(rawData.owners.map((o) => [o._id, o]))
  const businessesMap = new Map(rawData.businesses.map((b) => [b._id, b]))
  const provincesMap = new Map(rawData.provinces.map((p: any) => [p._id, p.name]))
  const citiesMap = new Map(rawData.cities.map((c: any) => [c._id, c.name]))
  const barangaysMap = new Map(rawData.barangays.map((b: any) => [b._id, b.name]))

  const schedulesMap = new Map<string, any[]>()
  rawData.schedules.forEach((s: any) => {
    const appId = s.applicationId.toString()
    if (!schedulesMap.has(appId)) schedulesMap.set(appId, [])
    schedulesMap.get(appId)!.push(s)
  })

  const paymentsByAppMap = new Map<string, any[]>()
  const paymentsByScheduleMap = new Map<string, any[]>()
  rawData.payments.forEach((p: any) => {
    const appId = p.applicationId.toString()
    if (!paymentsByAppMap.has(appId)) paymentsByAppMap.set(appId, [])
    paymentsByAppMap.get(appId)!.push(p)
    const schedId = p.scheduleId.toString()
    if (!paymentsByScheduleMap.has(schedId)) paymentsByScheduleMap.set(schedId, [])
    paymentsByScheduleMap.get(schedId)!.push(p)
  })

  const clearancesMap = new Map<string, any[]>()
  rawData.clearances.forEach((c: any) => {
    const appId = c.applicationId.toString()
    if (!clearancesMap.has(appId)) clearancesMap.set(appId, [])
    clearancesMap.get(appId)!.push(c)
  })

  const groupsByName = new Map(rawData.groups.map((g: any) => [g.name, g]))
  const divisionGroupsByGroupId = new Map<string, any[]>()
  for (const dg of rawData.divisionGroups) {
    const gId = dg.groupId as string
    if (!divisionGroupsByGroupId.has(gId)) divisionGroupsByGroupId.set(gId, [])
    divisionGroupsByGroupId.get(gId)!.push(dg)
  }
  const divisionsMap = new Map(rawData.divisions.map((d: any) => [d._id, d]))
  const majorsMap = new Map(rawData.majors.map((m: any) => [m._id, m]))

  const feesByDivisionId = new Map<string, any[]>()
  const feesByGroupId = new Map<string, any[]>()
  for (const f of rawData.fees) {
    if (f.divisionId) {
      const divId = f.divisionId as string
      if (!feesByDivisionId.has(divId)) feesByDivisionId.set(divId, [])
      feesByDivisionId.get(divId)!.push(f)
    }
    if (f.groupId) {
      const gId = f.groupId as string
      if (!feesByGroupId.has(gId)) feesByGroupId.set(gId, [])
      feesByGroupId.get(gId)!.push(f)
    }
  }

  const feeOverridesByDGId = new Map<string, Map<string, any>>()
  for (const fo of (rawData.feeOverrides || [])) {
    const dgId = fo.divisionGroupId as string
    if (!feeOverridesByDGId.has(dgId)) feeOverridesByDGId.set(dgId, new Map())
    feeOverridesByDGId.get(dgId)!.set(fo.feeId as string, fo)
  }

  const usersMap = new Map(rawData.users.map((u: any) => [u._id, u]))

  // Build UoM lookup: applicationId -> { variableName -> quantity }
  const uomByAppId = new Map<string, Record<string, number>>()
  for (const uom of (rawData.unitsOfMeasurement || [])) {
    const appId = uom.applicationId?.toString()
    if (!appId) continue
    if (!uomByAppId.has(appId)) uomByAppId.set(appId, {})
    uomByAppId.get(appId)![uom.variableName] = uom.quantity
  }

  const needsFlattening = needsLobs || needsLobFees || needsFees || needsScheduleRows || needsPaymentRows || needsClearanceRows

  // Build rows with cross-product flattening
  let rows: ReportRow[] = []

  for (const app of rawData.applications) {
    const owner = ownersMap.get(app.businessOwnerId)
    const business = businessesMap.get(app.businessId)
    const appPayments = needsPaymentData ? (paymentsByAppMap.get(app._id.toString()) || []) : []
    const appSchedules = needsScheduleData ? (schedulesMap.get(app._id.toString()) || []) : []
    const appClearances = needsClearanceData ? (clearancesMap.get(app._id.toString()) || []) : []

    const completedPayments = needsPaymentData ? appPayments.filter((p: any) => p.status === "completed") : []
    const paidAmount = needsPaymentData ? completedPayments.reduce((sum: number, p: any) => sum + p.amount, 0) : 0
    const totalScheduleSurcharge = needsScheduleData ? appSchedules.reduce((sum: number, s: any) => sum + (s.surcharge || 0), 0) : 0
    const totalSchedulePenalty = needsScheduleData ? appSchedules.reduce((sum: number, s: any) => sum + (s.penalty || 0), 0) : 0
    const completedClearancesCount = needsClearanceData ? appClearances.filter((c: any) => c.isCompleted).length : 0
    const totalClearances = needsClearanceData ? appClearances.length : 0
    const clearanceProgress = totalClearances > 0 ? completedClearancesCount / totalClearances : 0

    let processingDays = 0
    if (app.submittedAt && app.releasedAt) {
      const submitted = new Date(app.submittedAt).getTime()
      const released = new Date(app.releasedAt).getTime()
      processingDays = Math.ceil((released - submitted) / 86400000)
    }

    const baseRow: ReportRow = {
      _id: app._id,
      applicationNumber: app.applicationNumber,
      status: app.status,
      permitApplicationType: app.permitApplicationType || "New",
      modeOfPayment: app.modeOfPayment,
      submittedAt: app.submittedAt,
      assessedAt: app.assessedAt,
      releasedAt: app.releasedAt,
      rejectedAt: app.rejectedAt,
      assessmentRemarks: app.assessmentRemarks,
      rejectionReason: app.rejectionReason,
      totalFees: app.totalFees || 0,
      processingDays,
    }

    if (needsOwners) {
      baseRow.ownerFullName = owner ? `${owner.firstName} ${owner.lastName}` : ""
      baseRow.ownerFirstName = owner?.firstName || ""
      baseRow.ownerLastName = owner?.lastName || ""
      baseRow.ownerMiddleName = owner?.middleName || ""
      baseRow.ownerEmail = owner?.email || ""
      baseRow.ownerMobile = owner?.mobile || ""
      baseRow.ownerTIN = owner?.tin || ""
      baseRow.ownerCitizenship = owner?.citizenship || ""
      baseRow.ownerCivilStatus = owner?.civilStatus || ""
      baseRow.ownerGender = owner?.gender || ""
      baseRow.ownerBirthDate = owner?.birthDate || ""
      baseRow.ownerAddress = owner?.address || ""
      baseRow.ownerProvince = needsLocations && owner?.provinceId ? provincesMap.get(owner.provinceId) || "" : ""
      baseRow.ownerCity = needsLocations && owner?.cityId ? citiesMap.get(owner.cityId) || "" : ""
      baseRow.ownerBarangay = needsLocations && owner?.barangayId ? barangaysMap.get(owner.barangayId) || "" : ""
      baseRow.ownerType = owner?.ownerType || ""
      baseRow.isBlacklisted = owner?.isBlacklisted || false
      baseRow.blacklistReason = owner?.blacklistReason || ""
    }

    if (needsBusinesses) {
      baseRow.businessName = business?.name || ""
      baseRow.businessTradeName = business?.name || ""
      baseRow.businessScale = business?.businessScale || ""
      baseRow.businessOwnershipType = business?.ownershipType || ""
      baseRow.annualRevenue = parseFloat(business?.annualRevenue || "0") || 0
      baseRow.numberOfEmployees = business?.numberOfEmployees || 0
      baseRow.maleEmployeeCount = business?.maleEmployeeCount || 0
      baseRow.femaleEmployeeCount = business?.femaleEmployeeCount || 0
      baseRow.businessArea = business?.businessArea || 0
      baseRow.businessAddress = business?.address || ""
      baseRow.businessBuildingName = business?.buildingName || ""
      baseRow.businessProvince = needsLocations && business?.provinceId ? provincesMap.get(business.provinceId) || "" : ""
      baseRow.businessCity = needsLocations && business?.cityId ? citiesMap.get(business.cityId) || "" : ""
      baseRow.businessBarangay = needsLocations && business?.barangayId ? barangaysMap.get(business.barangayId) || "" : ""
      baseRow.registrationNumber = business?.registrationNumber || ""
      baseRow.propertyIndexNumber = business?.propertyIndexNumber || ""
      baseRow.businessContactNumber = business?.contactNumber || ""
      baseRow.businessEmail = business?.email || ""
      baseRow.dateStarted = business?.dateStarted || ""
      baseRow.establishedDate = business?.establishedDate || ""
      baseRow.occupancy = business?.occupancy || ""
      baseRow.permitPaymentCadence = business?.permitPaymentCadence || ""
    }

    if (needsPaymentData) {
      baseRow.paidAmount = paidAmount
      baseRow.outstanding = (app.totalFees || 0) - paidAmount
    }
    if (needsScheduleData) {
      baseRow.surcharge = totalScheduleSurcharge
      baseRow.penalty = totalSchedulePenalty
    }
    if (needsClearanceData) {
      baseRow.clearanceProgress = clearanceProgress
      baseRow.completedClearances = completedClearancesCount
      baseRow.pendingClearances = totalClearances - completedClearancesCount
    }

    if (!needsFlattening) {
      rows.push(baseRow)
      continue
    }

    // Axis 1: LOB items (with optional fee expansion)
    type LobFeeItem = { lob: any; fee: any; calculatedAmount: number }
    let lobFeeItems: LobFeeItem[] = []

    if (needsLobFees) {
      const appUomVars = uomByAppId.get(app._id?.toString()) || {}
      for (const lob of (app.linesOfBusiness || [])) {
        const group = groupsByName.get(lob.businessCategory)
        if (!group) continue
        const groupFees = getFeesForGroup(group._id as string, feesByDivisionId, feesByGroupId, divisionGroupsByGroupId)
        const applicableFees = groupFees.filter((f: any) => f.applicationType && lob.permitApplicationType && f.applicationType.includes(lob.permitApplicationType))
        const businessData = {
          capitalInvestment: parseFloat(lob.capitalInvestment) || 0,
          grossSales: parseFloat(lob.grossSales || "0") || 0,
          numberOfEmployees: lob.numberOfEmployees || 0,
          floorArea: business?.businessArea || 0,
        }
        // Build dynamic variables from UoM + feeVariableMappings
        const dynamicVars: Record<string, number> = { ...appUomVars }
        for (const mapping of (lob.feeVariableMappings || [])) {
          if (mapping.variableName && appUomVars[mapping.variableName] !== undefined) {
            dynamicVars[mapping.variableName] = appUomVars[mapping.variableName]
          }
        }
        for (const fee of applicableFees) {
          const isExcluded = (lob.excludedFees || []).some((id: any) => String(id) === String(fee._id))
          if (isExcluded) continue
          // Apply DG overrides
          let effectiveFee = fee
          const dgs = divisionGroupsByGroupId.get(group._id as string) || []
          for (const dg of dgs) {
            const dgOverrides = feeOverridesByDGId.get(dg._id as string)
            if (dgOverrides) {
              const feeOverride = dgOverrides.get(fee._id as string)
              if (feeOverride) {
                effectiveFee = {
                  ...fee,
                  amount: feeOverride.overrideAmount ?? fee.amount,
                  ranges: feeOverride.overrideRanges ?? fee.ranges,
                  formula: feeOverride.overrideFormula ?? fee.formula,
                  rangeField: feeOverride.overrideRangeField ?? fee.rangeField,
                }
                break
              }
            }
          }
          let amount = calculateFeeAmountForReport(effectiveFee, businessData, dynamicVars)
          const lobOverride = (lob.feeOverrides || []).find((o: any) => String(o.feeId) === String(fee._id))
          const globalOverride = (app.feeOverrides || []).find((o: any) => String(o.feeId) === String(fee._id))
          if (lobOverride) amount = lobOverride.overriddenAmount
          else if (globalOverride) amount = globalOverride.overriddenAmount
          lobFeeItems.push({ lob, fee, calculatedAmount: amount })
        }
      }
    }

    const lobItems: (any | null)[] = needsLobFees
      ? (lobFeeItems.length > 0 ? lobFeeItems : [null])
      : needsLobs
        ? ((app.linesOfBusiness || []).length > 0 ? (app.linesOfBusiness || []) : [null])
        : [null]

    // Axis 2: Schedule-related items
    type ScheduleItem = { type: "fee" | "payment" | "schedule"; data: any; schedule: any; payments?: any[] }
    let scheduleItems: (ScheduleItem | null)[] = [null]

    if (needsFees) {
      const items: ScheduleItem[] = []
      for (const sched of appSchedules) {
        const schedPayments = paymentsByScheduleMap.get(sched._id.toString()) || []
        for (const fee of (sched.fees || [])) {
          items.push({ type: "fee", data: fee, schedule: sched, payments: schedPayments })
        }
      }
      scheduleItems = items.length > 0 ? items : [null]
    } else if (needsPaymentRows) {
      const items: ScheduleItem[] = []
      for (const sched of appSchedules) {
        const schedPayments = paymentsByScheduleMap.get(sched._id.toString()) || []
        for (const payment of schedPayments) {
          items.push({ type: "payment", data: payment, schedule: sched })
        }
      }
      scheduleItems = items.length > 0 ? items : [null]
    } else if (needsScheduleRows) {
      const items: ScheduleItem[] = appSchedules.map((sched: any) => ({ type: "schedule" as const, data: sched, schedule: sched }))
      scheduleItems = items.length > 0 ? items : [null]
    }

    // Axis 3: Clearance items
    const clearanceItems: (any | null)[] = needsClearanceRows
      ? (appClearances.length > 0 ? appClearances : [null])
      : [null]

    // Cross-product
    if (lobItems[0] === null && scheduleItems[0] === null && clearanceItems[0] === null) {
      rows.push({
        ...baseRow,
        ...buildLobFields(null, groupsByName, divisionGroupsByGroupId, divisionsMap, majorsMap),
        ...(needsLobFees ? buildLobFeeFields(null) : {}),
        ...buildScheduleItemFields(null, usersMap),
        ...buildClearanceFields(null, usersMap),
      })
      continue
    }

    if (needsLobFeeMatching) {
      // Matched cross-product: compute per-LOB fees and only pair applicable fees
      const numberOfSections = appSchedules.length > 0
        ? Math.max(...appSchedules.map((s: any) => s.sectionNumber || 1))
        : 1

      // Build per-LOB fee map: lobBusinessCategory -> feeName -> { amount, feeCategory }
      const lobFeeMap = new Map<string, Map<string, { amount: number; feeCategory: string }>>()
      for (const lob of (app.linesOfBusiness || [])) {
        const group = groupsByName.get(lob.businessCategory)
        if (!group) continue
        const groupFees = getFeesForGroup(
          group._id as string, feesByDivisionId, feesByGroupId, divisionGroupsByGroupId,
        )
        const applicableFees = groupFees.filter((f: any) =>
          f.applicationType && lob.permitApplicationType && f.applicationType.includes(lob.permitApplicationType),
        )
        const businessData = {
          capitalInvestment: parseFloat(lob.capitalInvestment) || 0,
          grossSales: parseFloat(lob.grossSales || "0") || 0,
          numberOfEmployees: lob.numberOfEmployees || 0,
          floorArea: business?.businessArea || 0,
        }
        const feeMap = new Map<string, { amount: number; feeCategory: string }>()
        for (const fee of applicableFees) {
          const isExcluded = (lob.excludedFees || []).some((id: any) => String(id) === String(fee._id))
          if (isExcluded) continue
          let amount = calculateFeeAmountForReport(fee, businessData)
          const lobOverride = (lob.feeOverrides || []).find((o: any) => String(o.feeId) === String(fee._id))
          const globalOverride = (app.feeOverrides || []).find((o: any) => String(o.feeId) === String(fee._id))
          if (lobOverride) amount = lobOverride.overriddenAmount
          else if (globalOverride) amount = globalOverride.overriddenAmount
          feeMap.set(fee.name, { amount, feeCategory: fee.feeCategory || "" })
        }
        lobFeeMap.set(lob.businessCategory, feeMap)
      }

      // Count how many LOBs each fee applies to (for fallback apportioning)
      const feeApplicableLobCount = new Map<string, number>()
      for (const [, feeMap] of lobFeeMap) {
        for (const [feeName] of feeMap) {
          feeApplicableLobCount.set(feeName, (feeApplicableLobCount.get(feeName) || 0) + 1)
        }
      }

      const effectiveLobs = lobItems.length > 0 ? lobItems : [null]

      for (const lobItem of effectiveLobs) {
        const rawLob = needsLobFees ? (lobItem as LobFeeItem | null)?.lob : lobItem
        const lobFeeData = needsLobFees ? buildLobFeeFields(lobItem as LobFeeItem | null) : {}

        if (rawLob === null || rawLob === undefined) {
          // No LOBs for this app - push row with empty fields
          for (const schedItem of scheduleItems) {
            for (const clearance of clearanceItems) {
              rows.push({
                ...baseRow,
                ...buildLobFields(null, groupsByName, divisionGroupsByGroupId, divisionsMap, majorsMap),
                ...lobFeeData,
                ...buildScheduleItemFields(schedItem, usersMap),
                ...buildClearanceFields(clearance, usersMap),
              })
            }
          }
          continue
        }

        const lobFees = lobFeeMap.get(rawLob.businessCategory)

        for (const schedItem of scheduleItems) {
          if (schedItem?.type === "fee") {
            const scheduleFee = schedItem.data
            const lobFeeInfo = lobFees?.get(scheduleFee.feeName)

            // Skip: fee doesn't apply to this LOB
            if (!lobFeeInfo) continue

            const isTax = (scheduleFee.feeCategory || "").toLowerCase() === "tax" ||
                          (lobFeeInfo.feeCategory || "").toLowerCase() === "tax"

            // Skip: non-tax fees only appear in section 1
            if (!isTax && schedItem.schedule.sectionNumber > 1) continue

            // Per-LOB amounts: use calculated amount, or fall back to schedule amount apportioned
            let perLobAmount = lobFeeInfo.amount
            if (perLobAmount === 0) {
              // Fallback: apportion schedule amount across applicable LOBs
              const lobCount = feeApplicableLobCount.get(scheduleFee.feeName) || 1
              perLobAmount = (scheduleFee.originalAmount || 0) / lobCount
            }

            // Per-section amount (what's due each installment)
            const perLobSection = isTax
              ? Math.round((perLobAmount / numberOfSections) * 100) / 100
              : perLobAmount

            // Build row - "Fee Amount" column shows per-section amount
            const schedFields = buildScheduleItemFields(schedItem, usersMap)
            schedFields.feeOriginalAmount = perLobSection
            schedFields.feeSectionAmount = perLobSection

            for (const clearance of clearanceItems) {
              rows.push({
                ...baseRow,
                ...buildLobFields(rawLob, groupsByName, divisionGroupsByGroupId, divisionsMap, majorsMap),
                ...lobFeeData,
                ...schedFields,
                ...buildClearanceFields(clearance, usersMap),
              })
            }
          } else {
            // payment/schedule items: standard behavior
            for (const clearance of clearanceItems) {
              rows.push({
                ...baseRow,
                ...buildLobFields(rawLob, groupsByName, divisionGroupsByGroupId, divisionsMap, majorsMap),
                ...lobFeeData,
                ...buildScheduleItemFields(schedItem, usersMap),
                ...buildClearanceFields(clearance, usersMap),
              })
            }
          }
        }
      }
    } else {
      // Original independent cross-product (unchanged for non-matching cases)
      for (const lobItem of lobItems) {
        const rawLob = needsLobFees ? (lobItem as LobFeeItem | null)?.lob : lobItem
        const lobFeeData = needsLobFees ? buildLobFeeFields(lobItem as LobFeeItem | null) : {}
        for (const schedItem of scheduleItems) {
          for (const clearance of clearanceItems) {
            rows.push({
              ...baseRow,
              ...buildLobFields(rawLob || null, groupsByName, divisionGroupsByGroupId, divisionsMap, majorsMap),
              ...lobFeeData,
              ...buildScheduleItemFields(schedItem, usersMap),
              ...buildClearanceFields(clearance, usersMap),
            })
          }
        }
      }
    }
  }

  // Apply date range filter
  if (dateRange) {
    const dateRangeResult = parseDateRange(dateRange.preset, dateRange.startDate, dateRange.endDate)
    if (dateRangeResult) {
      const dimensionId = dateRange.dimensionId || "submittedAt"
      rows = rows.filter((row) => {
        const dateValue = row[dimensionId]
        if (typeof dateValue !== "string") return true
        try {
          const date = new Date(dateValue).getTime()
          return date >= dateRangeResult.start.getTime() && date <= dateRangeResult.end.getTime()
        } catch { return true }
      })
    }
  }

  // Apply filters
  rows = applyFilters(rows, filters || null)

  // Calculate aggregations before pagination
  const aggregations = calculateAggregations(rows, metrics)
  const totalCount = rows.length

  // Apply sorting
  if (sort) {
    rows.sort((a, b) => {
      const aVal = a[sort.field]
      const bVal = b[sort.field]
      if (aVal === bVal) return 0
      if (aVal === null || aVal === undefined) return 1
      if (bVal === null || bVal === undefined) return -1
      const comparison = aVal < bVal ? -1 : 1
      return sort.direction === "asc" ? comparison : -comparison
    })
  }

  // Apply pagination
  const startIndex = (page - 1) * pageSize
  const paginatedRows = rows.slice(startIndex, startIndex + pageSize)

  // Filter to only selected dimensions
  const selectedRows = paginatedRows.map((row) => {
    const selected: ReportRow = { _id: row._id }
    for (const dim of dimensions) {
      selected[dim] = row[dim]
    }
    return selected
  })

  return {
    rows: selectedRows,
    aggregations,
    totalCount,
    page,
    pageSize,
    totalPages: Math.ceil(totalCount / pageSize),
  }
}
