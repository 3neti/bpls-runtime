/**
 * Report Builder Types
 *
 * Core TypeScript interfaces for the dynamic report builder system.
 * Supports configurable dimensions and metrics across all BPLS resources.
 *
 * SOURCE: Used by report builder UI and Convex backend queries
 */

import type { Id } from "@repo/backend/convex/_generated/dataModel"

// ===========================================
// DIMENSION TYPES
// ===========================================

/**
 * Dimension data types for report columns
 */
export type DimensionType = "text" | "categorical" | "date" | "numeric" | "boolean"

/**
 * A single dimension (column) in a report
 */
export interface Dimension {
  id: string
  name: string
  type: DimensionType
  /** Whether this dimension can be filtered */
  filterable: boolean
  /** Source table for the dimension (for joins) */
  source: string
  /** Nested path for joined data (e.g., "owner.firstName") */
  path?: string
  /** Parent group for UI tree structure */
  group?: string
  /** Whether this is auto-selected by default */
  autoSelect?: boolean
  /** Display order within group */
  sortOrder?: number
  /** Available values for categorical dimensions */
  options?: string[]
}

/**
 * Dimension group for tree-view UI
 */
export interface DimensionGroup {
  id: string
  name: string
  dimensions: Dimension[]
  /** Whether the group is expanded by default */
  defaultExpanded?: boolean
}

// ===========================================
// METRIC TYPES
// ===========================================

/**
 * Aggregation types for metrics
 */
export type AggregationType = "count" | "sum" | "average" | "min" | "max" | "countDistinct"

/**
 * Display format for metric values
 */
export type MetricFormat = "number" | "currency" | "percentage"

/**
 * A single metric (aggregation) in a report
 */
export interface Metric {
  id: string
  name: string
  aggregation: AggregationType
  format: MetricFormat
  /** Description for UI tooltip */
  description?: string
  /** Source field to aggregate (if not counting rows) */
  field?: string
  /** Parent group for UI */
  group?: string
  /** Filter condition for this metric (e.g., status = 'completed') */
  filter?: FilterCondition
}

/**
 * Metric group for UI organization
 */
export interface MetricGroup {
  id: string
  name: string
  metrics: Metric[]
}

// ===========================================
// FILTER TYPES
// ===========================================

/**
 * Filter operators by dimension type
 */
export type TextOperator = "equals" | "notEquals" | "contains" | "startsWith" | "endsWith" | "between" | "isEmpty" | "isNotEmpty"
export type NumericOperator = "equals" | "notEquals" | "gt" | "gte" | "lt" | "lte" | "between" | "isEmpty" | "isNotEmpty"
export type DateOperator = "equals" | "notEquals" | "before" | "after" | "between" | "isEmpty" | "isNotEmpty"
export type CategoricalOperator = "equals" | "notEquals" | "in" | "notIn" | "isEmpty" | "isNotEmpty"
export type BooleanOperator = "equals"

export type FilterOperator = TextOperator | NumericOperator | DateOperator | CategoricalOperator | BooleanOperator

/**
 * A single filter condition
 */
export interface FilterCondition {
  dimensionId: string
  operator: FilterOperator
  value: string | number | boolean | string[] | [string, string] | [number, number]
}

/**
 * Logical operator for combining conditions
 */
export type LogicalOperator = "AND" | "OR"

/**
 * A group of filter conditions with a logical operator
 */
export interface FilterGroup {
  id: string
  logic: LogicalOperator
  conditions: FilterCondition[]
  /** Nested groups for complex filtering */
  groups?: FilterGroup[]
}

// ===========================================
// DATE RANGE TYPES
// ===========================================

/**
 * Preset date range options
 */
export type DateRangePreset =
  | "today"
  | "yesterday"
  | "thisWeek"
  | "lastWeek"
  | "thisMonth"
  | "lastMonth"
  | "thisQuarter"
  | "lastQuarter"
  | "thisYear"
  | "lastYear"
  | "last7Days"
  | "last30Days"
  | "last90Days"
  | "custom"

/**
 * Date range configuration
 */
export interface DateRange {
  preset: DateRangePreset
  /** Custom start date (ISO string) - required when preset is "custom" */
  startDate?: string
  /** Custom end date (ISO string) - required when preset is "custom" */
  endDate?: string
  /** Dimension to apply date range to */
  dimensionId?: string
}

// ===========================================
// REPORT CONFIGURATION
// ===========================================

/**
 * Sorting configuration
 */
export interface SortConfig {
  field: string
  direction: "asc" | "desc"
}

/**
 * Pagination configuration
 */
export interface PaginationConfig {
  page: number
  pageSize: number
}

/**
 * Full report configuration (what gets saved)
 */
export interface ReportConfiguration {
  /** Selected resource type */
  resourceType: ResourceType
  /** Selected dimension IDs */
  dimensions: string[]
  /** Selected metric IDs */
  metrics: string[]
  /** Filter configuration */
  filters?: FilterGroup
  /** Date range filter */
  dateRange?: DateRange
  /** Sorting */
  sort?: SortConfig
  /** Pagination */
  pagination?: PaginationConfig
}

// ===========================================
// RESOURCE CONFIGURATION
// ===========================================

/**
 * Supported resource types for reporting
 */
export type ResourceType =
  | "permit_applications"
  | "billing_groups"
  | "payments"
  | "permits"
  | "businesses"
  | "business_owners"
  | "manual_transactions"

/**
 * Display name and icon for each resource type
 */
export interface ResourceMeta {
  type: ResourceType
  name: string
  description: string
  icon: string
}

/**
 * Full resource configuration for reporting
 */
export interface ResourceConfig {
  type: ResourceType
  meta: ResourceMeta
  dimensionGroups: DimensionGroup[]
  metricGroups: MetricGroup[]
  /** Default dimensions to select */
  defaultDimensions: string[]
  /** Default metrics to select */
  defaultMetrics: string[]
  /** Primary date dimension for date range filter */
  primaryDateDimension?: string
}

// ===========================================
// REPORT EXECUTION & RESULTS
// ===========================================

/**
 * Input for report generation query
 */
export interface ReportGenerationInput {
  resourceType: ResourceType
  dimensions: string[]
  metrics: string[]
  filters?: FilterGroup
  dateRange?: DateRange
  sort?: SortConfig
  page?: number
  pageSize?: number
}

/**
 * Single row of report results
 */
export type ReportRow = Record<string, unknown>

/**
 * Aggregated metric result
 */
export interface MetricResult {
  metricId: string
  name: string
  value: number
  format: MetricFormat
}

/**
 * Full report generation result
 */
export interface ReportResult {
  rows: ReportRow[]
  aggregations: MetricResult[]
  totalCount: number
  page: number
  pageSize: number
  totalPages: number
}

// ===========================================
// SAVED REPORTS
// ===========================================

/**
 * Saved report (matches Convex schema)
 */
export interface SavedReport {
  _id: Id<"saved_reports">
  name: string
  description?: string
  resourceType: ResourceType
  configuration: string // JSON-stringified ReportConfiguration
  createdBy: Id<"users">
  isPublic: boolean
  createdAt: string
  updatedAt: string
  isDeleted: boolean
}

/**
 * Input for creating a saved report
 */
export interface CreateSavedReportInput {
  name: string
  description?: string
  resourceType: ResourceType
  configuration: ReportConfiguration
  isPublic?: boolean
}

/**
 * Input for updating a saved report
 */
export interface UpdateSavedReportInput {
  id: Id<"saved_reports">
  name?: string
  description?: string
  configuration?: ReportConfiguration
  isPublic?: boolean
}

// ===========================================
// HELPER TYPES
// ===========================================

/**
 * Get operators available for a dimension type
 */
export function getOperatorsForType(type: DimensionType): FilterOperator[] {
  switch (type) {
    case "text":
      return ["equals", "notEquals", "contains", "startsWith", "endsWith", "between", "isEmpty", "isNotEmpty"]
    case "numeric":
      return ["equals", "notEquals", "gt", "gte", "lt", "lte", "between", "isEmpty", "isNotEmpty"]
    case "date":
      return ["equals", "notEquals", "before", "after", "between", "isEmpty", "isNotEmpty"]
    case "categorical":
      return ["equals", "notEquals", "in", "notIn", "isEmpty", "isNotEmpty"]
    case "boolean":
      return ["equals"]
    default:
      return ["equals"]
  }
}

/**
 * Get human-readable operator label
 */
export function getOperatorLabel(operator: FilterOperator): string {
  const labels: Record<FilterOperator, string> = {
    equals: "equals",
    notEquals: "does not equal",
    contains: "contains",
    startsWith: "starts with",
    endsWith: "ends with",
    isEmpty: "is empty",
    isNotEmpty: "is not empty",
    gt: "greater than",
    gte: "greater than or equal",
    lt: "less than",
    lte: "less than or equal",
    between: "is between",
    before: "is before",
    after: "is after",
    in: "is one of",
    notIn: "is not one of",
  }
  return labels[operator] || operator
}

/**
 * Format metric value based on format type
 */
export function formatMetricValue(value: number, format: MetricFormat): string {
  switch (format) {
    case "currency":
      return new Intl.NumberFormat("en-PH", {
        style: "currency",
        currency: "PHP",
        minimumFractionDigits: 2,
      }).format(value)
    case "percentage":
      return `${(value * 100).toFixed(1)}%`
    case "number":
    default:
      return new Intl.NumberFormat("en-US").format(value)
  }
}
