"use client";

import { useQuery, usePreloadedQuery, type Preloaded } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";

export const DEFAULT_PLATFORM_SETTINGS = {
  platformName: "BPLS Portal",
  platformTitle: "Business Permit & Licensing System",
  tagline: "Streamlining business permit applications for local government",
  currencyFormat: "PHP",
  fiscalYearStart: "january",
};

// Keep internal aliases for backwards compatibility within this file
const DEFAULT_PLATFORM = DEFAULT_PLATFORM_SETTINGS;

const DEFAULT_MUNICIPALITY = {
  municipalityName: "",
  municipalityShortName: "",
  provinceName: "",
  fullAddress: "",
};

const DEFAULT_OFFICIALS = {
  mayorName: "",
  mayorTitle: "Municipal Mayor",
  treasurerName: "",
  treasurerTitle: "Municipal Treasurer",
};

/**
 * Hook for client components that cannot use preloaded queries.
 * Returns platform settings with fallback defaults and a loading state.
 */
export function usePlatformSettings() {
  const settings = useQuery(api.platformSettings.get);
  const logoUrl = useQuery(api.platformSettings.getLogoUrl);

  const isLoading = settings === undefined;

  return {
    isLoading,
    platformName: settings?.platformName ?? DEFAULT_PLATFORM.platformName,
    platformTitle: settings?.platformTitle ?? DEFAULT_PLATFORM.platformTitle,
    tagline: settings?.tagline ?? DEFAULT_PLATFORM.tagline,
    currencyFormat: settings?.currencyFormat ?? DEFAULT_PLATFORM.currencyFormat,
    municipalityName: settings?.municipalityName ?? DEFAULT_MUNICIPALITY.municipalityName,
    municipalityShortName: settings?.municipalityShortName ?? DEFAULT_MUNICIPALITY.municipalityShortName,
    provinceName: settings?.provinceName ?? DEFAULT_MUNICIPALITY.provinceName,
    fullAddress: settings?.fullAddress ?? DEFAULT_MUNICIPALITY.fullAddress,
    mayorName: settings?.mayorName ?? DEFAULT_OFFICIALS.mayorName,
    mayorTitle: settings?.mayorTitle ?? DEFAULT_OFFICIALS.mayorTitle,
    treasurerName: settings?.treasurerName ?? DEFAULT_OFFICIALS.treasurerName,
    treasurerTitle: settings?.treasurerTitle ?? DEFAULT_OFFICIALS.treasurerTitle,
    logoUrl: logoUrl ?? null,
  };
}

export function usePlatformSettingsPreloaded(preloaded: {
  settings: Preloaded<typeof api.platformSettings.get>;
  logoUrl: Preloaded<typeof api.platformSettings.getLogoUrl>;
  landingImageUrl: Preloaded<typeof api.platformSettings.getLandingImageUrl>;
  municipalSealUrl: Preloaded<typeof api.platformSettings.getMunicipalSealUrl>;
}) {
  const settings = usePreloadedQuery(preloaded.settings);
  const logoUrl = usePreloadedQuery(preloaded.logoUrl);
  const landingImageUrl = usePreloadedQuery(preloaded.landingImageUrl);
  const municipalSealUrl = usePreloadedQuery(preloaded.municipalSealUrl);

  return {
    settings,
    logoUrl: logoUrl ?? null,
    landingImageUrl: landingImageUrl ?? null,
    municipalSealUrl: municipalSealUrl ?? null,
    platformName: settings?.platformName ?? DEFAULT_PLATFORM.platformName,
    platformTitle: settings?.platformTitle ?? DEFAULT_PLATFORM.platformTitle,
    tagline: settings?.tagline ?? DEFAULT_PLATFORM.tagline,
    currencyFormat: settings?.currencyFormat ?? DEFAULT_PLATFORM.currencyFormat,
    municipalityName: settings?.municipalityName ?? DEFAULT_MUNICIPALITY.municipalityName,
    municipalityShortName: settings?.municipalityShortName ?? DEFAULT_MUNICIPALITY.municipalityShortName,
    provinceName: settings?.provinceName ?? DEFAULT_MUNICIPALITY.provinceName,
    fullAddress: settings?.fullAddress ?? DEFAULT_MUNICIPALITY.fullAddress,
    mayorName: settings?.mayorName ?? DEFAULT_OFFICIALS.mayorName,
    mayorTitle: settings?.mayorTitle ?? DEFAULT_OFFICIALS.mayorTitle,
    treasurerName: settings?.treasurerName ?? DEFAULT_OFFICIALS.treasurerName,
    treasurerTitle: settings?.treasurerTitle ?? DEFAULT_OFFICIALS.treasurerTitle,
  };
}

export type PlatformSettings = ReturnType<typeof usePlatformSettingsPreloaded>;
