"use client";

import { use, useState } from "react";
import { format } from "date-fns";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { useQuery, useMutation } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import {
  ArrowLeft,
  CheckCircle2,
  CreditCard,
  Loader2,
  Receipt,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";
import { Separator } from "@repo/ui/components/separator";
import { FeeBreakdownList } from "@/components/portal/payment-schedule-card";

type PaymentMethod =
  | "Cash"
  | "Credit Card"
  | "Bank Transfer"
  | "GCash"
  | "PayMaya"
  | "Check";

const paymentMethods: PaymentMethod[] = [
  "Cash",
  "Credit Card",
  "Bank Transfer",
  "GCash",
  "PayMaya",
  "Check",
];

function SuccessView({
  transactionNumber,
  applicationId,
}: {
  transactionNumber: string;
  applicationId: string;
}) {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-6 text-center">
      <div className="flex size-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
        <CheckCircle2 className="size-8 text-green-600 dark:text-green-400" />
      </div>
      <div className="space-y-2">
        <h2 className="text-2xl font-semibold">Payment Submitted</h2>
        <p className="text-muted-foreground">
          Your payment has been submitted for processing.
        </p>
        <p className="font-mono text-sm text-muted-foreground">
          Transaction: {transactionNumber}
        </p>
      </div>
      <p className="max-w-sm text-sm text-muted-foreground">
        This is a mock payment. In a live environment, you would be redirected
        to a payment gateway. Please wait for your application status to be
        updated.
      </p>
      <div className="flex gap-3">
        <Button asChild>
          <Link href={`/portal/applications/${applicationId}`}>
            View Application
          </Link>
        </Button>
        <Button variant="outline" asChild>
          <Link href="/portal">Back to Dashboard</Link>
        </Button>
      </div>
    </div>
  );
}

export default function PaymentPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const searchParams = useSearchParams();
  const applicationId = searchParams.get("applicationId") ?? "";
  const router = useRouter();

  const scheduleData = useQuery(api.citizen.payments.getMyPaymentSchedule, {
    applicationId: applicationId as Id<"business_permit_applications">,
  });

  const submitPayment = useMutation(api.citizen.payments.submitMockPayment);

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("GCash");
  const [referenceNumber, setReferenceNumber] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successTransaction, setSuccessTransaction] = useState<string | null>(null);

  if (successTransaction) {
    return <SuccessView transactionNumber={successTransaction} applicationId={applicationId} />;
  }

  if (scheduleData === undefined) {
    return (
      <div className="flex h-40 items-center justify-center">
        <Loader2 className="size-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!scheduleData) {
    return (
      <div className="flex flex-col items-center gap-4 py-20 text-center">
        <p className="font-medium">Payment schedule not found</p>
        <Button variant="outline" asChild>
          <Link href="/portal">Back to Dashboard</Link>
        </Button>
      </div>
    );
  }

  const { application, schedules } = scheduleData;
  const schedule = schedules.find((s: { _id: string }) => s._id === id);

  if (!schedule) {
    return (
      <div className="flex flex-col items-center gap-4 py-20 text-center">
        <p className="font-medium">Payment schedule section not found</p>
        <Button variant="outline" asChild>
          <Link href={`/portal/applications/${applicationId}`}>
            Back to Application
          </Link>
        </Button>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const result = await submitPayment({
        applicationId: applicationId as Id<"business_permit_applications">,
        scheduleId: id as Id<"payment_schedules">,
        amount: schedule.totalAmount ?? schedule.amount,
        paymentMethod,
        referenceNumber: referenceNumber || undefined,
      });

      setSuccessTransaction(result.transactionNumber);
    } catch {
      toast.error("Payment submission failed. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Back */}
      <Button variant="ghost" size="sm" asChild className="-ml-2">
        <Link href={`/portal/applications/${applicationId}`}>
          <ArrowLeft className="mr-1.5 size-4" />
          Back to Application
        </Link>
      </Button>

      <div>
        <h1 className="text-2xl font-semibold">Payment</h1>
        <p className="mt-1 text-muted-foreground">
          Complete the payment for your permit application.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        {/* Payment Form */}
        <div className="lg:col-span-3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <CreditCard className="size-4" />
                Payment Details
              </CardTitle>
              <CardDescription>
                Select your preferred payment method.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="method">Payment Method</Label>
                  <Select
                    value={paymentMethod}
                    onValueChange={(v) => setPaymentMethod(v as PaymentMethod)}
                  >
                    <SelectTrigger id="method">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {paymentMethods.map((m) => (
                        <SelectItem key={m} value={m}>
                          {m}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reference">
                    Reference Number{" "}
                    <span className="text-muted-foreground">(optional)</span>
                  </Label>
                  <Input
                    id="reference"
                    placeholder="e.g. GCash reference number"
                    value={referenceNumber}
                    onChange={(e) => setReferenceNumber(e.target.value)}
                    disabled={isSubmitting}
                  />
                </div>

                <div className="rounded-lg border bg-muted/40 p-4">
                  <p className="text-xs text-muted-foreground">
                    This is a mock payment environment. No actual transaction
                    will be processed. In production, you would be redirected to
                    a secure payment gateway.
                  </p>
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={isSubmitting}
                >
                  {isSubmitting && (
                    <Loader2 className="mr-2 size-4 animate-spin" />
                  )}
                  Submit Payment of ₱
                  {Number(schedule.totalAmount ?? schedule.amount).toLocaleString("en-PH", {
                    minimumFractionDigits: 2,
                  })}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Summary */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Receipt className="size-4" />
                Payment Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Application</span>
                <span className="font-medium font-mono text-xs">
                  {application.applicationNumber}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Section</span>
                <span className="font-medium">
                  {schedule.sectionLabel ?? `Section ${schedule.sectionNumber}`}
                </span>
              </div>
              {schedule.dueDate && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Due Date</span>
                  <span className="font-medium">
                    {format(new Date(schedule.dueDate), "MMM d, yyyy")}
                  </span>
                </div>
              )}
              <Separator />

              {/* Fee Breakdown */}
              {schedule.fees && schedule.fees.length > 0 ? (
                <FeeBreakdownList
                  fees={schedule.fees}
                  surcharge={schedule.surcharge}
                  penalty={schedule.penalty}
                  totalAmount={schedule.totalAmount ?? schedule.amount}
                />
              ) : (
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Amount Due</span>
                  <span className="text-lg font-semibold">
                    ₱
                    {Number(schedule.totalAmount ?? schedule.amount).toLocaleString("en-PH", {
                      minimumFractionDigits: 2,
                    })}
                  </span>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
