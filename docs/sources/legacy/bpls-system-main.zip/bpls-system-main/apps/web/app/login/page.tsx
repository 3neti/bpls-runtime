"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuthActions } from "@convex-dev/auth/react";
import { Building2, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@repo/ui/components/card";
import { Skeleton } from "@repo/ui/components/skeleton";
import { usePlatformSettings } from "@/hooks/use-platform-settings";

export default function LoginPage() {
  const router = useRouter();
  const { signIn } = useAuthActions();
  const { platformName, tagline, logoUrl, isLoading: settingsLoading } = usePlatformSettings();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      await signIn("password", {
        email,
        password,
        flow: "signIn",
        userType: "citizen",
      });
      router.push("/portal");
    } catch {
      toast.error("Invalid email or password. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex min-h-svh items-center justify-center bg-muted/40 px-4 py-12">
      <div className="w-full max-w-md space-y-6">
        {/* Brand */}
        <div className="flex flex-col items-center gap-2 text-center">
          {settingsLoading ? (
            <Skeleton className="size-10 rounded-lg" />
          ) : logoUrl ? (
            <img
              src={logoUrl}
              alt={platformName}
              className="size-10 rounded-lg object-contain"
            />
          ) : (
            <div className="flex size-10 items-center justify-center rounded-lg bg-primary">
              <Building2 className="size-5 text-primary-foreground" />
            </div>
          )}
          {settingsLoading ? (
            <Skeleton className="h-7 w-40" />
          ) : (
            <h1 className="text-xl font-semibold">{platformName}</h1>
          )}
          {tagline && !settingsLoading && (
            <p className="text-sm text-muted-foreground">{tagline}</p>
          )}
        </div>

        <Card>
          <CardHeader className="text-center">
            <CardTitle>Welcome back</CardTitle>
            <CardDescription>
              Sign in to manage your business permits
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  autoComplete="email"
                  disabled={isLoading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  autoComplete="current-password"
                  disabled={isLoading}
                />
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading && <Loader2 className="mr-2 size-4 animate-spin" />}
                Sign In
              </Button>
            </form>
            <p className="mt-4 text-center text-sm text-muted-foreground">
              Don&apos;t have an account?{" "}
              <Link
                href="/register"
                className="font-medium text-primary underline-offset-4 hover:underline"
              >
                Create one
              </Link>
            </p>
          </CardContent>
        </Card>

        <p className="text-center text-xs text-muted-foreground">
          This portal is for citizens and business owners only.{" "}
          <Link href="/" className="underline underline-offset-4 hover:text-foreground">
            Learn more
          </Link>
        </p>
      </div>
    </div>
  );
}
