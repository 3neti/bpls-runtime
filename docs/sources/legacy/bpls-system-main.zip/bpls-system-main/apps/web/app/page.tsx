import type { Metadata } from "next";
import { preloadQuery, preloadedQueryResult } from "convex/nextjs";
import { api } from "@repo/backend/convex/_generated/api";
import { LandingPageClient } from "@/components/landing/landing-page-client";

export async function generateMetadata(): Promise<Metadata> {
  const preloaded = await preloadQuery(api.platformSettings.get);
  const settings = preloadedQueryResult(preloaded);
  const title = settings?.platformName || "BPLS Citizen Portal";
  const description =
    settings?.tagline ||
    "Business Permit & Licensing System - Apply, track, and renew your business permits online.";
  const municipality = settings?.municipalityName
    ? ` - ${settings.municipalityName}`
    : "";

  return {
    title: `${title}${municipality}`,
    description,
    openGraph: {
      title: `${title}${municipality}`,
      description,
      type: "website",
    },
  };
}

export default async function LandingPage() {
  const [
    preloadedSettings,
    preloadedLogoUrl,
    preloadedLandingImageUrl,
    preloadedMunicipalSealUrl,
  ] = await Promise.all([
    preloadQuery(api.platformSettings.get),
    preloadQuery(api.platformSettings.getLogoUrl),
    preloadQuery(api.platformSettings.getLandingImageUrl),
    preloadQuery(api.platformSettings.getMunicipalSealUrl),
  ]);

  return (
    <LandingPageClient
      preloadedSettings={preloadedSettings}
      preloadedLogoUrl={preloadedLogoUrl}
      preloadedLandingImageUrl={preloadedLandingImageUrl}
      preloadedMunicipalSealUrl={preloadedMunicipalSealUrl}
    />
  );
}
