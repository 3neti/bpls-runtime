"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery, useMutation } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import { ArrowLeft, ArrowRight, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@repo/ui/components/button";
import { Stepper } from "@repo/ui/components/stepper";
import {
  citizenPermitFormSchema,
  citizenPermitFormDefaultValues,
  step1Fields,
  step2Fields,
  type CitizenPermitFormSchema,
} from "@repo/shared/schemas/citizen-permit-form";

import { BusinessSelectionStep } from "@/components/portal/business-selection-step";
import { ApplicationDetailsStep } from "@/components/portal/application-details-step";
import { ReviewSubmitStep } from "@/components/portal/review-submit-step";

const steps = [
  { id: "business", title: "Business", description: "Select or register" },
  { id: "details", title: "Application", description: "Type & LOBs" },
  { id: "review", title: "Review", description: "Confirm & submit" },
];

export default function NewApplicationPage() {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const profile = useQuery(api.citizen.profile.getMyProfile);
  const businesses = useQuery(api.citizen.businesses.listMyBusinesses);
  const submitApplication = useMutation(
    api.citizen.applications.submitApplication
  );
  const registerBusiness = useMutation(
    api.citizen.businesses.registerBusiness
  );

  const form = useForm<CitizenPermitFormSchema>({
    resolver: zodResolver(citizenPermitFormSchema),
    defaultValues: citizenPermitFormDefaultValues,
    mode: "onChange",
  });

  const isLoading = profile === undefined;
  const hasProfile = !!profile?.businessOwner;
  const businessOwnerName = profile?.businessOwner
    ? `${profile.businessOwner.firstName} ${profile.businessOwner.lastName}`
    : "";

  // Get selected business name for review step
  const selectedBusinessId = form.watch("selectedBusinessId");
  const businessMode = form.watch("businessMode");
  const selectedBusinessName =
    businessMode === "existing" && selectedBusinessId
      ? businesses?.find(
          (b: { _id: string; name: string }) => b._id === selectedBusinessId
        )?.name
      : form.watch("businessName");

  // Step navigation with validation
  const goToNextStep = async () => {
    const fieldsToValidate =
      currentStep === 1 ? step1Fields : currentStep === 2 ? step2Fields : [];

    if (fieldsToValidate.length > 0) {
      const isValid = await form.trigger(fieldsToValidate);
      if (!isValid) return;
    }

    // Extra validation: on step 2, require modeOfPayment
    if (currentStep === 2) {
      const mop = form.getValues("modeOfPayment");
      if (!mop) {
        form.setError("modeOfPayment", {
          message: "Mode of payment is required",
        });
        return;
      }
    }

    setCurrentStep((prev) => Math.min(prev + 1, steps.length));
  };

  const goToPrevStep = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1));
  };

  const handleStepClick = (step: number) => {
    if (step < currentStep) {
      setCurrentStep(step);
    }
  };

  // Submit handler (Assessment status)
  const handleSubmit = async () => {
    const isValid = await form.trigger();
    if (!isValid) {
      toast.error("Please fix the validation errors before submitting.");
      return;
    }

    setIsSubmitting(true);
    try {
      let businessId = form.getValues("selectedBusinessId");

      // If registering a new business, create it first
      if (form.getValues("businessMode") === "new") {
        const values = form.getValues();
        businessId = await registerBusiness({
          name: values.businessName!.trim(),
          ownershipType: values.ownershipType!,
          groupName: values.groupName?.trim() || undefined,
          address: values.address!.trim(),
          buildingName: values.buildingName!.trim(),
          provinceId: values.provinceId as Id<"provinces">,
          cityId: values.cityId as Id<"cities">,
          barangayId: values.barangayId as Id<"barangays">,
          dateStarted: values.dateStarted!,
          maleEmployeeCount: values.maleEmployeeCount ?? 1,
          femaleEmployeeCount: values.femaleEmployeeCount ?? 0,
          contactNumber: values.contactNumber!.trim(),
          email: values.businessEmail!.trim(),
          businessArea: values.businessArea || undefined,
          occupancy: values.occupancy || undefined,
          registrationNumber: values.registrationNumber?.trim() || undefined,
          registrationDate: values.registrationDate || undefined,
          propertyIndexNumber: values.propertyIndexNumber?.trim() || undefined,
          establishedDate: values.establishedDate || undefined,
          categoryId: values.categoryId
            ? (values.categoryId as Id<"business_categories">)
            : undefined,
          subCategoryId: values.subCategoryId
            ? (values.subCategoryId as Id<"business_subcategories">)
            : undefined,
        });
      }

      if (!businessId) {
        toast.error("Please select or register a business.");
        return;
      }

      const values = form.getValues();
      const result = await submitApplication({
        businessId: businessId as Id<"businesses">,
        permitApplicationType: values.permitApplicationType,
        modeOfPayment: values.modeOfPayment,
        linesOfBusiness: values.linesOfBusiness.map((lob) => ({
          businessCategory: lob.businessCategory.trim(),
          capitalInvestment: lob.capitalInvestment.trim(),
          grossSales: lob.grossSales?.trim() || undefined,
          permitApplicationType: lob.permitApplicationType,
          numberOfEmployees: lob.numberOfEmployees || undefined,
        })),
        saveAsDraft: false,
      });

      toast.success(
        `Application ${result.applicationNumber} submitted successfully.`
      );
      router.push(`/portal/applications/${result.applicationId}`);
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Failed to submit application.";
      toast.error(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Save as draft handler
  const handleSaveDraft = async () => {
    // Draft requires minimal validation - just a business selection
    const businessModeVal = form.getValues("businessMode");
    if (
      businessModeVal === "existing" &&
      !form.getValues("selectedBusinessId")
    ) {
      toast.error("Please select a business before saving as draft.");
      return;
    }
    if (businessModeVal === "new" && !form.getValues("businessName")?.trim()) {
      toast.error("Please enter a business name before saving as draft.");
      return;
    }

    setIsSubmitting(true);
    try {
      let businessId = form.getValues("selectedBusinessId");

      // If registering a new business, create it first
      if (businessModeVal === "new") {
        const values = form.getValues();
        // For drafts, we still need to register the business with whatever data we have
        businessId = await registerBusiness({
          name: values.businessName!.trim(),
          ownershipType: values.ownershipType || "sole-proprietorship",
          groupName: values.groupName?.trim() || undefined,
          address: values.address?.trim() || "TBD",
          buildingName: values.buildingName?.trim() || "TBD",
          provinceId: values.provinceId as Id<"provinces">,
          cityId: values.cityId as Id<"cities">,
          barangayId: values.barangayId as Id<"barangays">,
          dateStarted: values.dateStarted || new Date().toISOString().split("T")[0],
          maleEmployeeCount: values.maleEmployeeCount ?? 1,
          femaleEmployeeCount: values.femaleEmployeeCount ?? 0,
          contactNumber: values.contactNumber?.trim() || "TBD",
          email: values.businessEmail?.trim() || "tbd@example.com",
          businessArea: values.businessArea || undefined,
          occupancy: values.occupancy || undefined,
          categoryId: values.categoryId
            ? (values.categoryId as Id<"business_categories">)
            : undefined,
          subCategoryId: values.subCategoryId
            ? (values.subCategoryId as Id<"business_subcategories">)
            : undefined,
        });
      }

      if (!businessId) {
        toast.error("Please select or register a business.");
        return;
      }

      const values = form.getValues();
      const validLobs = values.linesOfBusiness.filter(
        (l) => l.businessCategory.trim()
      );

      const result = await submitApplication({
        businessId: businessId as Id<"businesses">,
        permitApplicationType: values.permitApplicationType,
        modeOfPayment: values.modeOfPayment || undefined,
        linesOfBusiness:
          validLobs.length > 0
            ? validLobs.map((lob) => ({
                businessCategory: lob.businessCategory.trim(),
                capitalInvestment: lob.capitalInvestment.trim() || "0",
                grossSales: lob.grossSales?.trim() || undefined,
                permitApplicationType: lob.permitApplicationType,
                numberOfEmployees: lob.numberOfEmployees || undefined,
              }))
            : [
                {
                  businessCategory: "TBD",
                  capitalInvestment: "0",
                  permitApplicationType: "New",
                },
              ],
        saveAsDraft: true,
      });

      toast.success(
        `Draft ${result.applicationNumber} saved. You can continue later.`
      );
      router.push(`/portal/applications/${result.applicationId}`);
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Failed to save draft.";
      toast.error(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-40 items-center justify-center">
        <Loader2 className="size-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!hasProfile) {
    return (
      <div className="mx-auto max-w-lg space-y-4 py-12 text-center">
        <h1 className="text-xl font-semibold">Business Profile Required</h1>
        <p className="text-muted-foreground">
          You need to complete your business owner profile before submitting a
          permit application.
        </p>
        <Button asChild>
          <Link href="/portal/profile">Complete Profile</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="sm" asChild className="-ml-2">
          <Link href="/portal/applications">
            <ArrowLeft className="mr-1.5 size-4" />
            Applications
          </Link>
        </Button>
      </div>
      <div>
        <h1 className="text-2xl font-semibold">New Permit Application</h1>
        <p className="mt-1 text-muted-foreground">
          Fill in the details below to submit a new permit application.
        </p>
      </div>

      {/* Stepper */}
      <Stepper
        steps={steps}
        currentStep={currentStep}
        onStepClick={handleStepClick}
      />

      {/* Step Content */}
      <div className="mt-6">
        {currentStep === 1 && <BusinessSelectionStep form={form} />}
        {currentStep === 2 && <ApplicationDetailsStep form={form} />}
        {currentStep === 3 && (
          <ReviewSubmitStep
            form={form}
            businessOwnerName={businessOwnerName}
            selectedBusinessName={selectedBusinessName}
            isSubmitting={isSubmitting}
            onSubmit={handleSubmit}
            onSaveDraft={handleSaveDraft}
          />
        )}
      </div>

      {/* Navigation Buttons */}
      {currentStep < 3 && (
        <div className="flex justify-between">
          <div>
            {currentStep > 1 && (
              <Button
                type="button"
                variant="outline"
                onClick={goToPrevStep}
                disabled={isSubmitting}
              >
                <ArrowLeft className="mr-2 size-4" />
                Previous
              </Button>
            )}
          </div>
          <Button
            type="button"
            onClick={goToNextStep}
            disabled={isSubmitting}
          >
            Next
            <ArrowRight className="ml-2 size-4" />
          </Button>
        </div>
      )}

      {currentStep === 3 && (
        <div className="flex justify-start">
          <Button
            type="button"
            variant="outline"
            onClick={goToPrevStep}
            disabled={isSubmitting}
          >
            <ArrowLeft className="mr-2 size-4" />
            Previous
          </Button>
        </div>
      )}
    </div>
  );
}
