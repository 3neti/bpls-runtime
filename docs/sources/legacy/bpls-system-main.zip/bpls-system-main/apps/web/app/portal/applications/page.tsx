"use client";

import Link from "next/link";
import { useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import { format } from "date-fns";
import { Plus, FileText, Search } from "lucide-react";
import { useState } from "react";
import { Button } from "@repo/ui/components/button";
import { Badge } from "@repo/ui/components/badge";
import { Input } from "@repo/ui/components/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card";
import { Skeleton } from "@repo/ui/components/skeleton";

type ApplicationStatus =
  | "Draft"
  | "Assessment"
  | "Approval"
  | "Pending Payment"
  | "Released"
  | "Rejected";

const statusConfig: Record<
  ApplicationStatus,
  {
    label: string;
    variant: "default" | "secondary" | "outline" | "destructive";
    className: string;
  }
> = {
  Draft: {
    label: "Draft",
    variant: "secondary",
    className: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",
  },
  Assessment: {
    label: "Under Assessment",
    variant: "outline",
    className:
      "border-blue-300 text-blue-700 dark:border-blue-700 dark:text-blue-300",
  },
  Approval: {
    label: "Under Review",
    variant: "outline",
    className:
      "border-purple-300 text-purple-700 dark:border-purple-700 dark:text-purple-300",
  },
  "Pending Payment": {
    label: "Pending Payment",
    variant: "default",
    className:
      "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
  },
  Released: {
    label: "Released",
    variant: "secondary",
    className:
      "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  },
  Rejected: {
    label: "Rejected",
    variant: "destructive",
    className: "",
  },
};

type Application = {
  _id: string;
  applicationNumber: string;
  businessName: string;
  permitApplicationType: string;
  status: ApplicationStatus;
  submittedAt: string;
};

function ApplicationRow({ app }: { app: Application }) {
  const cfg = statusConfig[app.status] ?? {
    label: app.status,
    variant: "secondary" as const,
    className: "",
  };

  return (
    <Link
      href={`/portal/applications/${app._id}`}
      className="flex flex-col gap-2 px-6 py-4 transition-colors hover:bg-muted/40 sm:flex-row sm:items-center sm:gap-4"
    >
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm">{app.applicationNumber}</p>
        <p className="mt-0.5 truncate text-sm text-muted-foreground">
          {app.businessName}
        </p>
        <p className="mt-0.5 text-xs text-muted-foreground">
          {app.permitApplicationType} &middot;{" "}
          {format(new Date(app.submittedAt), "MMM d, yyyy")}
        </p>
      </div>
      <Badge
        variant={cfg.variant}
        className={`shrink-0 self-start sm:self-center ${cfg.className}`}
      >
        {cfg.label}
      </Badge>
    </Link>
  );
}

export default function ApplicationsPage() {
  const [search, setSearch] = useState("");
  const applications = useQuery(api.citizen.applications.listMyApplications);

  const isLoading = applications === undefined;

  const filtered = applications
    ? applications.filter((app: Application) => {
        const q = search.toLowerCase();
        return (
          app.applicationNumber.toLowerCase().includes(q) ||
          app.businessName.toLowerCase().includes(q) ||
          app.status.toLowerCase().includes(q)
        );
      })
    : [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">My Applications</h1>
          <p className="mt-1 text-muted-foreground">
            View and track all your permit applications.
          </p>
        </div>
        <Button asChild>
          <Link href="/portal/applications/new">
            <Plus className="mr-2 size-4" />
            New Application
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3">
            <CardTitle className="text-base">Applications</CardTitle>
            {!isLoading && (
              <CardDescription className="mt-0">
                {filtered.length}{" "}
                {filtered.length === 1 ? "result" : "results"}
              </CardDescription>
            )}
          </div>
          <div className="relative mt-2">
            <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
            <Input
              placeholder="Search by application number, business, or status..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-8"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="divide-y">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="flex flex-col gap-2 px-6 py-4">
                  <Skeleton className="h-4 w-40" />
                  <Skeleton className="h-3.5 w-56" />
                  <Skeleton className="h-3 w-32" />
                </div>
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center gap-3 py-16 text-center">
              <FileText className="size-12 text-muted-foreground/30" />
              <p className="font-medium text-sm">No applications found</p>
              <p className="text-sm text-muted-foreground">
                {search
                  ? "Try adjusting your search."
                  : "Submit your first permit application to get started."}
              </p>
              {!search && (
                <Button variant="outline" size="sm" asChild>
                  <Link href="/portal/applications/new">
                    Submit Application
                  </Link>
                </Button>
              )}
            </div>
          ) : (
            <div className="divide-y">
              {filtered.map((app: Application) => (
                <ApplicationRow key={app._id} app={app} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
