"use client";

import Link from "next/link";
import { useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import { format } from "date-fns";
import { FileText, Plus, CreditCard, Clock, CheckCircle2 } from "lucide-react";
import { Button } from "@repo/ui/components/button";
import { Card, CardContent, CardHeader, CardTitle } from "@repo/ui/components/card";
import { Badge } from "@repo/ui/components/badge";
import { Skeleton } from "@repo/ui/components/skeleton";

type ApplicationStatus = "Draft" | "Assessment" | "Approval" | "Pending Payment" | "Released" | "Rejected";

const statusConfig: Record<
  ApplicationStatus,
  { label: string; variant: "default" | "secondary" | "outline" | "destructive" }
> = {
  Draft: { label: "Draft", variant: "secondary" },
  Assessment: { label: "Under Assessment", variant: "outline" },
  Approval: { label: "Under Review", variant: "outline" },
  "Pending Payment": { label: "Pending Payment", variant: "default" },
  Released: { label: "Released", variant: "secondary" },
  Rejected: { label: "Rejected", variant: "destructive" },
};

function StatCard({
  label,
  value,
  icon: Icon,
  isLoading,
}: {
  label: string;
  value: number;
  icon: React.ElementType;
  isLoading: boolean;
}) {
  return (
    <Card>
      <CardContent className="flex items-center gap-4 p-6">
        <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
          <Icon className="size-5 text-primary" />
        </div>
        <div>
          {isLoading ? (
            <Skeleton className="mb-1 h-7 w-10" />
          ) : (
            <p className="text-2xl font-semibold">{value}</p>
          )}
          <p className="text-sm text-muted-foreground">{label}</p>
        </div>
      </CardContent>
    </Card>
  );
}

export default function PortalDashboard() {
  const profile = useQuery(api.citizen.profile.getMyProfile);
  const applications = useQuery(api.citizen.applications.listMyApplications);

  const isLoading = profile === undefined || applications === undefined;

  const firstName = profile?.user?.firstName ?? "there";

  const totalApplications = applications?.length ?? 0;
  const pendingPayment =
    applications?.filter(
      (a: { status: string }) => a.status === "Pending Payment"
    ).length ?? 0;

  const recentApplications = applications?.slice(0, 5) ?? [];

  return (
    <div className="space-y-8">
      {/* Welcome */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">
            Welcome back{firstName !== "there" ? `, ${firstName}` : ""}
          </h1>
          <p className="mt-1 text-muted-foreground">
            Here&apos;s an overview of your permit applications.
          </p>
        </div>
        <Button asChild>
          <Link href="/portal/applications/new">
            <Plus className="mr-2 size-4" />
            New Application
          </Link>
        </Button>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard
          label="Total Applications"
          value={totalApplications}
          icon={FileText}
          isLoading={isLoading}
        />
        <StatCard
          label="Pending Payment"
          value={pendingPayment}
          icon={CreditCard}
          isLoading={isLoading}
        />
        <StatCard
          label="Released"
          value={
            applications?.filter(
              (a: { status: string }) => a.status === "Released"
            ).length ?? 0
          }
          icon={CheckCircle2}
          isLoading={isLoading}
        />
      </div>

      {/* Recent Applications */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-3">
          <CardTitle className="text-base font-semibold">
            Recent Applications
          </CardTitle>
          <Button variant="ghost" size="sm" asChild>
            <Link href="/portal/applications">View all</Link>
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="divide-y">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="flex items-center gap-4 px-6 py-4">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="ml-auto h-5 w-20" />
                </div>
              ))}
            </div>
          ) : recentApplications.length === 0 ? (
            <div className="flex flex-col items-center gap-3 py-12 text-center">
              <Clock className="size-10 text-muted-foreground/40" />
              <p className="text-sm text-muted-foreground">
                No applications yet.
              </p>
              <Button variant="outline" size="sm" asChild>
                <Link href="/portal/applications/new">
                  Submit your first application
                </Link>
              </Button>
            </div>
          ) : (
            <div className="divide-y">
              {recentApplications.map(
                (app: {
                  _id: string;
                  applicationNumber: string;
                  businessName: string;
                  status: ApplicationStatus;
                  submittedAt: string;
                }) => {
                  const cfg = statusConfig[app.status] ?? {
                    label: app.status,
                    variant: "secondary" as const,
                  };
                  return (
                    <Link
                      key={app._id}
                      href={`/portal/applications/${app._id}`}
                      className="flex items-center gap-4 px-6 py-4 transition-colors hover:bg-muted/40"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="truncate font-medium text-sm">
                          {app.applicationNumber}
                        </p>
                        <p className="truncate text-xs text-muted-foreground">
                          {app.businessName}
                        </p>
                      </div>
                      <div className="flex shrink-0 items-center gap-3">
                        <span className="hidden text-xs text-muted-foreground sm:block">
                          {format(new Date(app.submittedAt), "MMM d, yyyy")}
                        </span>
                        <Badge variant={cfg.variant}>{cfg.label}</Badge>
                      </div>
                    </Link>
                  );
                }
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
