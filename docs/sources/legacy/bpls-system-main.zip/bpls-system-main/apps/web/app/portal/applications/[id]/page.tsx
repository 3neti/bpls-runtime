"use client";

import { use } from "react";
import Link from "next/link";
import { useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import { format } from "date-fns";
import {
  ArrowLeft,
  Building2,
  CreditCard,
  FileText,
} from "lucide-react";
import { Button } from "@repo/ui/components/button";
import { Badge } from "@repo/ui/components/badge";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card";
import { Separator } from "@repo/ui/components/separator";
import { Skeleton } from "@repo/ui/components/skeleton";
import { PaymentScheduleCard } from "@/components/portal/payment-schedule-card";

type ApplicationStatus =
  | "Draft"
  | "Assessment"
  | "Approval"
  | "Pending Payment"
  | "Released"
  | "Rejected";

const statusConfig: Record<
  ApplicationStatus,
  { label: string; className: string }
> = {
  Draft: {
    label: "Draft",
    className: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",
  },
  Assessment: {
    label: "Under Assessment",
    className:
      "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  },
  Approval: {
    label: "Under Review",
    className:
      "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  },
  "Pending Payment": {
    label: "Pending Payment",
    className:
      "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
  },
  Released: {
    label: "Released",
    className:
      "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  },
  Rejected: {
    label: "Rejected",
    className: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
  },
};

function DetailRow({
  label,
  value,
}: {
  label: string;
  value: string | null | undefined;
}) {
  return (
    <div className="flex flex-col gap-0.5 sm:flex-row sm:items-baseline sm:gap-4">
      <span className="min-w-40 text-sm text-muted-foreground">{label}</span>
      <span className="text-sm font-medium">{value ?? "—"}</span>
    </div>
  );
}

export default function ApplicationDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);

  const data = useQuery(api.citizen.applications.getMyApplication, {
    applicationId: id as Id<"business_permit_applications">,
  });

  if (data === undefined) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (data === null) {
    return (
      <div className="flex flex-col items-center gap-4 py-20 text-center">
        <FileText className="size-12 text-muted-foreground/40" />
        <p className="font-medium">Application not found</p>
        <Button variant="outline" size="sm" asChild>
          <Link href="/portal/applications">
            <ArrowLeft className="mr-2 size-4" />
            Back to Applications
          </Link>
        </Button>
      </div>
    );
  }

  const { application, business, paymentSchedules, payments } = data;
  const status = application.status as ApplicationStatus;
  const cfg = statusConfig[status] ?? { label: status, className: "" };

  const hasPendingPayment = status === "Pending Payment" && paymentSchedules.length > 0;
  const firstUnpaidSchedule = paymentSchedules.find(
    (s: { _id: string; status: string }) => s.status !== "paid"
  );

  return (
    <div className="space-y-6">
      {/* Back + Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" asChild className="-ml-2">
            <Link href="/portal/applications">
              <ArrowLeft className="mr-1.5 size-4" />
              Applications
            </Link>
          </Button>
        </div>
        {hasPendingPayment && firstUnpaidSchedule && (
          <Button asChild>
            <Link href={`/portal/payments/${firstUnpaidSchedule._id}?applicationId=${application._id}`}>
              <CreditCard className="mr-2 size-4" />
              Pay Now
            </Link>
          </Button>
        )}
      </div>

      {/* Title */}
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="text-2xl font-semibold">{application.applicationNumber}</h1>
        <Badge className={cfg.className}>{cfg.label}</Badge>
      </div>

      {/* Application Info */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <FileText className="size-4" />
            Application Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <DetailRow label="Application Number" value={application.applicationNumber} />
          <DetailRow label="Type" value={application.permitApplicationType} />
          <DetailRow label="Status" value={cfg.label} />
          <DetailRow label="Mode of Payment" value={application.modeOfPayment} />
          <DetailRow
            label="Submitted"
            value={
              application.submittedAt
                ? format(new Date(application.submittedAt), "MMMM d, yyyy")
                : undefined
            }
          />
        </CardContent>
      </Card>

      {/* Business Info */}
      {business && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Building2 className="size-4" />
              Business Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <DetailRow label="Business Name" value={business.name} />
            <DetailRow
              label="Registration No."
              value={business.registrationNumber}
            />
            <DetailRow label="Business Scale" value={business.businessScale} />
            <DetailRow label="Address" value={business.address} />
          </CardContent>
        </Card>
      )}

      {/* Lines of Business */}
      {application.linesOfBusiness && application.linesOfBusiness.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Lines of Business</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y">
              {application.linesOfBusiness.map(
                (
                  lob: {
                    businessCategory: string;
                    capitalInvestment: string;
                    permitApplicationType: string;
                  },
                  idx: number
                ) => (
                  <div key={idx} className="grid grid-cols-3 gap-4 px-6 py-3 text-sm">
                    <span className="font-medium">{lob.businessCategory}</span>
                    <span className="text-muted-foreground">
                      Capital: {lob.capitalInvestment}
                    </span>
                    <span className="text-muted-foreground">
                      {lob.permitApplicationType}
                    </span>
                  </div>
                )
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Payment Schedule with Fee Breakdown */}
      {paymentSchedules.length > 0 && (
        <PaymentScheduleCard
          schedules={paymentSchedules}
          applicationId={application._id}
          applicationStatus={status}
        />
      )}

      {/* Fee Summary (shown only when no payment schedules yet but totalFees exists) */}
      {paymentSchedules.length === 0 &&
        application.totalFees !== undefined &&
        application.totalFees !== null && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Fee Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between text-sm font-medium">
                <span>Total Fees</span>
                <span className="text-lg">
                  ₱{Number(application.totalFees).toLocaleString("en-PH", { minimumFractionDigits: 2 })}
                </span>
              </div>
              {application.modeOfPayment && (
                <>
                  <Separator className="my-3" />
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span>Mode of Payment</span>
                    <span>{application.modeOfPayment}</span>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        )}

      {/* Payment History */}
      {payments && payments.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Payment History</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y">
              {payments.map(
                (payment: {
                  _id: string;
                  transactionNumber: string;
                  amount: number;
                  paymentMethod: string;
                  status: string;
                  paidAt: string;
                }) => (
                  <div
                    key={payment._id}
                    className="flex items-center justify-between px-6 py-3"
                  >
                    <div>
                      <p className="text-sm font-medium">
                        {payment.transactionNumber}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {payment.paymentMethod} &middot;{" "}
                        {payment.paidAt
                          ? format(new Date(payment.paidAt), "MMM d, yyyy")
                          : "—"}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-medium">
                        ₱{Number(payment.amount).toLocaleString("en-PH", {
                          minimumFractionDigits: 2,
                        })}
                      </span>
                      <Badge variant="secondary" className="capitalize">
                        {payment.status}
                      </Badge>
                    </div>
                  </div>
                )
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
