"use client";

import { useRouter } from "next/navigation";
import Link from "next/link";
import { useQuery } from "convex/react";
import { useAuthActions } from "@convex-dev/auth/react";
import { api } from "@repo/backend/convex/_generated/api";
import {
  Building2,
  LayoutDashboard,
  FileText,
  User,
  LogOut,
  AlertCircle,
  ChevronDown,
} from "lucide-react";
import { Button } from "@repo/ui/components/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@repo/ui/components/dropdown-menu";
import { Alert, AlertDescription } from "@repo/ui/components/alert";
import { Skeleton } from "@repo/ui/components/skeleton";
import { usePlatformSettings } from "@/hooks/use-platform-settings";

const navItems = [
  { href: "/portal", label: "Dashboard", icon: LayoutDashboard },
  { href: "/portal/applications", label: "Applications", icon: FileText },
  { href: "/portal/profile", label: "Profile", icon: User },
];

function PortalHeader() {
  const router = useRouter();
  const { signOut } = useAuthActions();
  const profile = useQuery(api.citizen.profile.getMyProfile);
  const { platformName, logoUrl } = usePlatformSettings();

  const displayName =
    profile?.user?.firstName && profile?.user?.lastName
      ? `${profile.user.firstName} ${profile.user.lastName}`
      : profile?.user?.email ?? "";

  const handleSignOut = async () => {
    await signOut();
    router.push("/login");
  };

  return (
    <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4 md:px-6">
        {/* Brand + Nav */}
        <div className="flex items-center gap-6">
          <Link href="/portal" className="flex items-center gap-2 font-semibold">
            {logoUrl ? (
              <img
                src={logoUrl}
                alt={platformName}
                className="size-7 rounded object-contain"
              />
            ) : (
              <div className="flex size-7 items-center justify-center rounded bg-primary">
                <Building2 className="size-4 text-primary-foreground" />
              </div>
            )}
            <span className="hidden sm:inline">{platformName}</span>
          </Link>
          <nav className="hidden gap-1 md:flex">
            {navItems.map(({ href, label }) => (
              <Button key={href} variant="ghost" size="sm" asChild>
                <Link href={href}>{label}</Link>
              </Button>
            ))}
          </nav>
        </div>

        {/* User menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="gap-1.5">
              {displayName ? (
                <span className="max-w-32 truncate text-sm">{displayName}</span>
              ) : (
                <Skeleton className="h-4 w-24" />
              )}
              <ChevronDown className="size-3.5 text-muted-foreground" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuItem asChild>
              <Link href="/portal/profile">
                <User className="mr-2 size-4" />
                Profile
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="text-destructive focus:text-destructive"
              onClick={handleSignOut}
            >
              <LogOut className="mr-2 size-4" />
              Sign out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Mobile nav */}
      <div className="border-t px-4 py-1.5 md:hidden">
        <nav className="flex gap-1">
          {navItems.map(({ href, label, icon: Icon }) => (
            <Button key={href} variant="ghost" size="sm" asChild className="flex-1 justify-start gap-1.5">
              <Link href={href}>
                <Icon className="size-4" />
                <span className="text-xs">{label}</span>
              </Link>
            </Button>
          ))}
        </nav>
      </div>

      {/* Incomplete profile banner */}
      {profile && !profile.businessOwner && (
        <div className="border-t bg-amber-50 px-4 py-2 dark:bg-amber-950/20">
          <div className="mx-auto flex max-w-6xl items-center gap-2 text-sm">
            <AlertCircle className="size-4 shrink-0 text-amber-600" />
            <span className="text-amber-800 dark:text-amber-200">
              Complete your business owner profile to submit permit applications.
            </span>
            <Button
              variant="link"
              size="sm"
              className="ml-auto h-auto p-0 text-amber-700 underline dark:text-amber-300"
              asChild
            >
              <Link href="/portal/profile">Complete Profile</Link>
            </Button>
          </div>
        </div>
      )}
    </header>
  );
}

export default function PortalLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-svh flex-col">
      <PortalHeader />
      <main className="flex-1">
        <div className="mx-auto max-w-6xl px-4 py-6 md:px-6 md:py-8">
          {children}
        </div>
      </main>
    </div>
  );
}
