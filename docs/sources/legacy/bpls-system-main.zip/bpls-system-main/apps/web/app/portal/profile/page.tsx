"use client";

import { useEffect } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import { Loader2, User, Building2, Save, Store } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";
import { Separator } from "@repo/ui/components/separator";
import { Badge } from "@repo/ui/components/badge";
import { Skeleton } from "@repo/ui/components/skeleton";

// ─── Schemas ─────────────────────────────────────────────────────────────────

const accountSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  phone: z.string().optional(),
});

const businessOwnerSchema = z
  .object({
    firstName: z.string().min(1, "First name is required"),
    middleName: z.string().optional(),
    lastName: z.string().min(1, "Last name is required"),
    birthDate: z.string().min(1, "Birth date is required"),
    civilStatus: z.string().min(1, "Civil status is required"),
    gender: z.string().min(1, "Gender is required"),
    citizenship: z.string().min(1, "Citizenship is required"),
    tin: z.string().optional(),
    mobile: z.string().min(1, "Mobile number is required"),
    email: z.string().email("Valid email is required"),
    address: z.string().min(1, "Address is required"),
    ownerType: z.enum(["Single", "Group"]),
    groupName: z.string().optional(),
  })
  .refine(
    (data) =>
      data.ownerType !== "Group" ||
      (data.groupName && data.groupName.length > 0),
    {
      message: "Group name is required for group owners",
      path: ["groupName"],
    }
  );

type AccountSchema = z.infer<typeof accountSchema>;
type BusinessOwnerSchema = z.infer<typeof businessOwnerSchema>;

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function ProfilePage() {
  const profile = useQuery(api.citizen.profile.getMyProfile);
  const updateProfile = useMutation(api.citizen.profile.updateMyProfile);
  const linkBusinessOwner = useMutation(api.citizen.profile.linkBusinessOwner);
  const myBusinesses = useQuery(api.citizen.businesses.listMyBusinesses);

  // ── Account form ──────────────────────────────────────────────────────────
  const accountForm = useForm<AccountSchema>({
    resolver: zodResolver(accountSchema),
    defaultValues: { firstName: "", lastName: "", phone: "" },
    mode: "onChange",
  });

  const {
    register: registerAccount,
    handleSubmit: handleSubmitAccount,
    reset: resetAccount,
    formState: { errors: accountErrors, isSubmitting: isSavingAccount },
  } = accountForm;

  // ── Business owner form ───────────────────────────────────────────────────
  const ownerForm = useForm<BusinessOwnerSchema>({
    resolver: zodResolver(businessOwnerSchema),
    defaultValues: {
      firstName: "",
      middleName: "",
      lastName: "",
      birthDate: "",
      civilStatus: "Single",
      gender: "Male",
      citizenship: "Filipino",
      tin: "",
      mobile: "",
      email: "",
      address: "",
      ownerType: "Single",
      groupName: "",
    },
    mode: "onChange",
  });

  const {
    register: registerOwner,
    handleSubmit: handleSubmitOwner,
    control: ownerControl,
    watch: watchOwner,
    reset: resetOwner,
    formState: { errors: ownerErrors, isSubmitting: isSavingOwner },
  } = ownerForm;

  const selectedOwnerType = watchOwner("ownerType");

  // ── Populate forms when profile data loads ────────────────────────────────
  useEffect(() => {
    if (!profile) return;

    const { user, businessOwner } = profile;

    resetAccount({
      firstName: user.firstName ?? "",
      lastName: user.lastName ?? "",
      phone: user.phone ?? "",
    });

    if (businessOwner) {
      resetOwner({
        firstName: businessOwner.firstName ?? "",
        middleName: businessOwner.middleName ?? "",
        lastName: businessOwner.lastName ?? "",
        birthDate: businessOwner.birthDate ?? "",
        civilStatus: businessOwner.civilStatus ?? "Single",
        gender: businessOwner.gender ?? "Male",
        citizenship: businessOwner.citizenship ?? "Filipino",
        tin: businessOwner.tin ?? "",
        mobile: businessOwner.mobile ?? "",
        email: businessOwner.email ?? "",
        address: businessOwner.address ?? "",
        ownerType: (businessOwner.ownerType as "Single" | "Group") ?? "Single",
        groupName: businessOwner.groupName ?? "",
      });
    } else {
      // Pre-fill with user data as defaults
      resetOwner((prev) => ({
        ...prev,
        firstName: user.firstName ?? "",
        lastName: user.lastName ?? "",
        email: user.email ?? "",
        mobile: user.phone ?? "",
      }));
    }
  }, [profile, resetAccount, resetOwner]);

  // ── Submit handlers ───────────────────────────────────────────────────────
  const onSaveAccount = async (values: AccountSchema) => {
    try {
      await updateProfile({
        firstName: values.firstName,
        lastName: values.lastName,
        phone: values.phone,
      });
      toast.success("Account information updated.");
    } catch {
      toast.error("Failed to update account information.");
    }
  };

  const onSaveBusinessOwner = async (values: BusinessOwnerSchema) => {
    try {
      await linkBusinessOwner({
        firstName: values.firstName,
        middleName: values.middleName || undefined,
        lastName: values.lastName,
        birthDate: values.birthDate,
        civilStatus: values.civilStatus,
        gender: values.gender,
        citizenship: values.citizenship,
        tin: values.tin || undefined,
        mobile: values.mobile,
        email: values.email,
        address: values.address || undefined,
        ownerType: values.ownerType,
        groupName: values.ownerType === "Group" ? values.groupName : undefined,
      });
      toast.success("Business owner profile saved.");
    } catch {
      toast.error("Failed to save business owner profile.");
    }
  };

  // ── Loading state ─────────────────────────────────────────────────────────
  if (profile === undefined) {
    return (
      <div className="flex h-40 items-center justify-center">
        <Loader2 className="size-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const isLinked = !!profile.businessOwner;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold">Profile</h1>
        <p className="mt-1 text-muted-foreground">
          Manage your account and business owner information.
        </p>
      </div>

      {/* Account Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <User className="size-4" />
            Account Information
          </CardTitle>
          <CardDescription>
            Update your name and contact phone number.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form
            onSubmit={handleSubmitAccount(onSaveAccount)}
            className="space-y-4"
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="account-firstName">First Name *</Label>
                <Input
                  id="account-firstName"
                  {...registerAccount("firstName")}
                  disabled={isSavingAccount}
                />
                {accountErrors.firstName && (
                  <p className="text-xs text-destructive">
                    {accountErrors.firstName.message}
                  </p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="account-lastName">Last Name *</Label>
                <Input
                  id="account-lastName"
                  {...registerAccount("lastName")}
                  disabled={isSavingAccount}
                />
                {accountErrors.lastName && (
                  <p className="text-xs text-destructive">
                    {accountErrors.lastName.message}
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email-display">Email</Label>
              <Input
                id="email-display"
                value={profile.user.email ?? ""}
                disabled
                className="bg-muted"
              />
              <p className="text-xs text-muted-foreground">
                Email cannot be changed.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="account-phone">Phone</Label>
              <Input
                id="account-phone"
                {...registerAccount("phone")}
                placeholder="+63 9xx xxx xxxx"
                disabled={isSavingAccount}
              />
              {accountErrors.phone && (
                <p className="text-xs text-destructive">
                  {accountErrors.phone.message}
                </p>
              )}
            </div>

            <div className="flex justify-end">
              <Button type="submit" disabled={isSavingAccount} size="sm">
                {isSavingAccount && (
                  <Loader2 className="mr-2 size-4 animate-spin" />
                )}
                <Save className="mr-2 size-4" />
                Save Account
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Business Owner Profile */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-base">
              <Building2 className="size-4" />
              Business Owner Profile
            </CardTitle>
            {isLinked ? (
              <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
                Linked
              </Badge>
            ) : (
              <Badge variant="outline">Not Linked</Badge>
            )}
          </div>
          <CardDescription>
            {isLinked
              ? "Your business owner profile is linked. Update the information below."
              : "Complete your business owner profile to submit permit applications."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form
            onSubmit={handleSubmitOwner(onSaveBusinessOwner)}
            className="space-y-4"
          >
            {/* Personal Information */}
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="owner-firstName">First Name *</Label>
                <Input
                  id="owner-firstName"
                  {...registerOwner("firstName")}
                  disabled={isSavingOwner}
                />
                {ownerErrors.firstName && (
                  <p className="text-xs text-destructive">
                    {ownerErrors.firstName.message}
                  </p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="owner-middleName">Middle Name</Label>
                <Input
                  id="owner-middleName"
                  {...registerOwner("middleName")}
                  disabled={isSavingOwner}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="owner-lastName">Last Name *</Label>
                <Input
                  id="owner-lastName"
                  {...registerOwner("lastName")}
                  disabled={isSavingOwner}
                />
                {ownerErrors.lastName && (
                  <p className="text-xs text-destructive">
                    {ownerErrors.lastName.message}
                  </p>
                )}
              </div>
            </div>

            <Separator />

            {/* Personal Details */}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="owner-birthDate">Birth Date *</Label>
                <Input
                  id="owner-birthDate"
                  type="date"
                  {...registerOwner("birthDate")}
                  disabled={isSavingOwner}
                />
                {ownerErrors.birthDate && (
                  <p className="text-xs text-destructive">
                    {ownerErrors.birthDate.message}
                  </p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="owner-tin">TIN</Label>
                <Input
                  id="owner-tin"
                  {...registerOwner("tin")}
                  placeholder="000-000-000"
                  disabled={isSavingOwner}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="owner-civilStatus">Civil Status *</Label>
                <Controller
                  control={ownerControl}
                  name="civilStatus"
                  render={({ field }) => (
                    <Select
                      value={field.value}
                      onValueChange={field.onChange}
                      disabled={isSavingOwner}
                    >
                      <SelectTrigger id="owner-civilStatus">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {["Single", "Married", "Widowed", "Separated"].map(
                          (s) => (
                            <SelectItem key={s} value={s}>
                              {s}
                            </SelectItem>
                          )
                        )}
                      </SelectContent>
                    </Select>
                  )}
                />
                {ownerErrors.civilStatus && (
                  <p className="text-xs text-destructive">
                    {ownerErrors.civilStatus.message}
                  </p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="owner-gender">Gender *</Label>
                <Controller
                  control={ownerControl}
                  name="gender"
                  render={({ field }) => (
                    <Select
                      value={field.value}
                      onValueChange={field.onChange}
                      disabled={isSavingOwner}
                    >
                      <SelectTrigger id="owner-gender">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {["Male", "Female", "Other"].map((g) => (
                          <SelectItem key={g} value={g}>
                            {g}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                />
                {ownerErrors.gender && (
                  <p className="text-xs text-destructive">
                    {ownerErrors.gender.message}
                  </p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="owner-citizenship">Citizenship *</Label>
                <Input
                  id="owner-citizenship"
                  {...registerOwner("citizenship")}
                  disabled={isSavingOwner}
                />
                {ownerErrors.citizenship && (
                  <p className="text-xs text-destructive">
                    {ownerErrors.citizenship.message}
                  </p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="owner-ownerType">Owner Type *</Label>
                <Controller
                  control={ownerControl}
                  name="ownerType"
                  render={({ field }) => (
                    <Select
                      value={field.value}
                      onValueChange={field.onChange}
                      disabled={isSavingOwner}
                    >
                      <SelectTrigger id="owner-ownerType">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Single">Single</SelectItem>
                        <SelectItem value="Group">Group</SelectItem>
                      </SelectContent>
                    </Select>
                  )}
                />
                {ownerErrors.ownerType && (
                  <p className="text-xs text-destructive">
                    {ownerErrors.ownerType.message}
                  </p>
                )}
              </div>
            </div>

            {selectedOwnerType === "Group" && (
              <div className="space-y-2">
                <Label htmlFor="owner-groupName">Group / Company Name *</Label>
                <Input
                  id="owner-groupName"
                  {...registerOwner("groupName")}
                  disabled={isSavingOwner}
                />
                {ownerErrors.groupName && (
                  <p className="text-xs text-destructive">
                    {ownerErrors.groupName.message}
                  </p>
                )}
              </div>
            )}

            <Separator />

            {/* Contact & Address */}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="owner-mobile">Mobile *</Label>
                <Input
                  id="owner-mobile"
                  {...registerOwner("mobile")}
                  placeholder="+63 9xx xxx xxxx"
                  disabled={isSavingOwner}
                />
                {ownerErrors.mobile && (
                  <p className="text-xs text-destructive">
                    {ownerErrors.mobile.message}
                  </p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="owner-email">Email *</Label>
                <Input
                  id="owner-email"
                  type="email"
                  {...registerOwner("email")}
                  disabled={isSavingOwner}
                />
                {ownerErrors.email && (
                  <p className="text-xs text-destructive">
                    {ownerErrors.email.message}
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="owner-address">Address *</Label>
              <Input
                id="owner-address"
                {...registerOwner("address")}
                placeholder="Street, Barangay, City, Province"
                disabled={isSavingOwner}
              />
              {ownerErrors.address && (
                <p className="text-xs text-destructive">
                  {ownerErrors.address.message}
                </p>
              )}
            </div>

            <div className="flex justify-end">
              <Button type="submit" disabled={isSavingOwner} size="sm">
                {isSavingOwner && (
                  <Loader2 className="mr-2 size-4 animate-spin" />
                )}
                <Save className="mr-2 size-4" />
                {isLinked ? "Update Business Profile" : "Link Business Profile"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* My Businesses */}
      {isLinked && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Store className="size-4" />
              My Businesses
            </CardTitle>
            <CardDescription>
              Businesses linked to your business owner profile.
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            {myBusinesses === undefined ? (
              <div className="divide-y">
                {Array.from({ length: 2 }).map((_, i) => (
                  <div key={i} className="flex flex-col gap-2 px-6 py-4">
                    <Skeleton className="h-4 w-40" />
                    <Skeleton className="h-3.5 w-56" />
                  </div>
                ))}
              </div>
            ) : myBusinesses.length === 0 ? (
              <div className="px-6 py-8 text-center">
                <p className="text-sm text-muted-foreground">
                  No businesses registered yet. You can register one when
                  creating a new permit application.
                </p>
              </div>
            ) : (
              <div className="divide-y">
                {myBusinesses.map(
                  (biz: {
                    _id: string;
                    name: string;
                    registrationNumber?: string;
                    address?: string;
                    ownershipType?: string;
                  }) => (
                    <div
                      key={biz._id}
                      className="flex flex-col gap-0.5 px-6 py-3"
                    >
                      <p className="text-sm font-medium">{biz.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {[
                          biz.registrationNumber,
                          biz.ownershipType,
                          biz.address,
                        ]
                          .filter(Boolean)
                          .join(" · ")}
                      </p>
                    </div>
                  )
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
