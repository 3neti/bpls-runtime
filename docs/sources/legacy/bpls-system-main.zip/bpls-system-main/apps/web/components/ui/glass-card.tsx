"use client";

import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  glow?: boolean;
}

export function GlassCard({
  children,
  className,
  hover = true,
  glow = false,
}: GlassCardProps) {
  return (
    <div
      className={cn(
        "rounded-xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-xl",
        "transition-all duration-300",
        hover && "hover:border-white/[0.15] hover:bg-white/[0.05]",
        glow && "hover:shadow-lg hover:shadow-blue-500/10",
        className
      )}
    >
      {children}
    </div>
  );
}
