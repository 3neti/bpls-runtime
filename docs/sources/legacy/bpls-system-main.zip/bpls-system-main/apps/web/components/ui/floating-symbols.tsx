"use client";

import { useMemo } from "react";
import { cn } from "@/lib/utils";

const SYMBOLS = ["§", "#", "@", "%", "+", "*", "&", "$", "?", "!", "~", "^", "|", "<", ">", "/", "\\", "=", "{", "}"];
const SIZE_CLASSES = ["text-xs", "text-sm", "text-base", "text-lg", "text-xl", "text-2xl"];

interface FloatingSymbol {
  id: number;
  symbol: string;
  top: number;
  left: number;
  sizeClass: string;
  opacity: number;
  duration: number;
  delay: number;
}

interface FloatingSymbolsProps {
  className?: string;
  count?: number;
}

export function FloatingSymbols({ className, count = 18 }: FloatingSymbolsProps) {
  const symbols = useMemo<FloatingSymbol[]>(() => {
    return Array.from({ length: count }, (_, i) => ({
      id: i,
      symbol: SYMBOLS[i % SYMBOLS.length],
      top: Math.floor(Math.random() * 100),
      left: Math.floor(Math.random() * 100),
      sizeClass: SIZE_CLASSES[Math.floor(Math.random() * SIZE_CLASSES.length)],
      opacity: parseFloat((Math.random() * 0.06 + 0.02).toFixed(3)),
      duration: parseFloat((Math.random() * 8 + 6).toFixed(1)),
      delay: parseFloat((Math.random() * -10).toFixed(1)),
    }));
  }, [count]);

  return (
    <div
      className={cn(
        "pointer-events-none absolute inset-0 overflow-hidden",
        className
      )}
      aria-hidden="true"
    >
      <style>{`
        @keyframes floatDrift {
          0%, 100% { transform: translateY(0px) translateX(0px); }
          25% { transform: translateY(-12px) translateX(4px); }
          50% { transform: translateY(-6px) translateX(-4px); }
          75% { transform: translateY(-18px) translateX(2px); }
        }
      `}</style>
      {symbols.map((item) => (
        <span
          key={item.id}
          className={cn("absolute font-mono text-blue-500 select-none", item.sizeClass)}
          style={{
            top: `${item.top}%`,
            left: `${item.left}%`,
            opacity: item.opacity,
            animation: `floatDrift ${item.duration}s ease-in-out ${item.delay}s infinite`,
          }}
        >
          {item.symbol}
        </span>
      ))}
    </div>
  );
}
