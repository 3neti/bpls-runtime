"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

// ---------------------------------------------------------------------------
// Inline SVG icons
// ---------------------------------------------------------------------------

const IconLayoutDashboard = () => (
  <svg viewBox="0 0 14 14" className="h-3.5 w-3.5" fill="currentColor">
    <rect x="1" y="1" width="5" height="5" rx="0.5" />
    <rect x="8" y="1" width="5" height="5" rx="0.5" />
    <rect x="1" y="8" width="5" height="5" rx="0.5" />
    <rect x="8" y="8" width="5" height="5" rx="0.5" />
  </svg>
);

const IconFileText = () => (
  <svg viewBox="0 0 14 14" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="1.2">
    <rect x="2" y="1" width="10" height="12" rx="1" />
    <line x1="4.5" y1="4.5" x2="9.5" y2="4.5" /><line x1="4.5" y1="7" x2="9.5" y2="7" /><line x1="4.5" y1="9.5" x2="7.5" y2="9.5" />
  </svg>
);

const IconCreditCard = () => (
  <svg viewBox="0 0 14 14" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="1.2">
    <rect x="1" y="3" width="12" height="8" rx="1" /><line x1="1" y1="6" x2="13" y2="6" /><line x1="3" y1="9" x2="5" y2="9" strokeWidth="1.5" />
  </svg>
);

const IconUsers = () => (
  <svg viewBox="0 0 14 14" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="1.2">
    <circle cx="5.5" cy="4" r="2" /><path d="M1 11.5 C1 9 2.5 8 5.5 8 C8.5 8 10 9 10 11.5" />
    <circle cx="10.5" cy="4.5" r="1.5" /><path d="M10.5 8 C12 8 13 8.8 13 10.5" />
  </svg>
);

const IconSettings = () => (
  <svg viewBox="0 0 14 14" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="1.2">
    <circle cx="7" cy="7" r="2" />
    <path d="M7 1v1.5M7 11.5V13M1 7h1.5M11.5 7H13M2.8 2.8l1 1M10.2 10.2l1 1M11.2 2.8l-1 1M3.8 10.2l-1 1" strokeLinecap="round" />
  </svg>
);

const IconBell = () => (
  <svg viewBox="0 0 14 14" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth="1.2">
    <path d="M7 1.5 C4.5 1.5 3 3 3 5.5 L3 9 L1.5 10.5 L12.5 10.5 L11 9 L11 5.5 C11 3 9.5 1.5 7 1.5Z" />
    <path d="M5.5 10.5 C5.5 11.3 6.2 12 7 12 C7.8 12 8.5 11.3 8.5 10.5" />
  </svg>
);

const IconSun = () => (
  <svg viewBox="0 0 14 14" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth="1.2">
    <circle cx="7" cy="7" r="2.5" />
    <path d="M7 1v1.5M7 11.5V13M1 7h1.5M11.5 7H13M2.8 2.8l1 1M10.2 10.2l1 1M11.2 2.8l-1 1M3.8 10.2l-1 1" strokeLinecap="round" />
  </svg>
);

// ---------------------------------------------------------------------------
// Sidebar icon wrapper
// ---------------------------------------------------------------------------

const SidebarIcon = ({ children, active = false }: { children: React.ReactNode; active?: boolean }) => (
  <div className={cn("flex h-7 w-7 items-center justify-center rounded-md transition-colors",
    active ? "bg-blue-500/20 text-blue-400" : "bg-white/[0.04] text-zinc-500 hover:text-zinc-300")}>
    {children}
  </div>
);

// ---------------------------------------------------------------------------
// Mini permits area chart (Card 1)
// ---------------------------------------------------------------------------

const MiniPermitsChart = () => (
  <svg viewBox="0 0 100 32" className="h-8 w-full" preserveAspectRatio="none">
    <defs>
      <linearGradient id="permitsGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.25" />
        <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
      </linearGradient>
    </defs>
    <path d="M0 28 L20 20 L40 24 L60 8 L80 13 L100 2 L100 32 L0 32 Z" fill="url(#permitsGrad)" />
    <path d="M0 28 L20 20 L40 24 L60 8 L80 13 L100 2" fill="none" stroke="#60a5fa" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

// ---------------------------------------------------------------------------
// Permits activity dual-series chart (Card 2)
// ---------------------------------------------------------------------------

const PermitsActivityChart = () => {
  // Normalize [30,65,48,92,78,110] and [20,35,28,55,45,68] to viewBox h=64
  const xs = [0, 22, 44, 66, 88, 110];
  const newY  = [30, 65, 48, 92, 78, 110].map((v) => (64 - (v / 110) * 60).toFixed(1));
  const renY  = [20, 35, 28, 55, 45, 68 ].map((v) => (64 - (v / 110) * 60).toFixed(1));
  const line  = (ys: string[]) => ys.map((y, i) => `${i === 0 ? "M" : "L"}${xs[i]} ${y}`).join(" ");
  const area  = (ys: string[]) => `${line(ys)} L110 64 L0 64 Z`;
  return (
    <svg viewBox="0 0 110 68" className="h-20 w-full" preserveAspectRatio="none">
      <defs>
        <linearGradient id="newGrad2" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" /><stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="renewGrad2" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.2" /><stop offset="100%" stopColor="#38bdf8" stopOpacity="0" />
        </linearGradient>
      </defs>
      {[16, 32, 48].map((y) => <line key={y} x1="0" y1={y} x2="110" y2={y} stroke="rgba(255,255,255,0.04)" strokeWidth="0.5" />)}
      <path d={area(renY)} fill="url(#renewGrad2)" />
      <path d={line(renY)} fill="none" stroke="#38bdf8" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
      <path d={area(newY)} fill="url(#newGrad2)" />
      <path d={line(newY)} fill="none" stroke="#3b82f6" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
};

// ---------------------------------------------------------------------------
// Recent transactions data (Card 3)
// ---------------------------------------------------------------------------

const TRANSACTIONS = [
  { id: "TXN-0847", business: "Juan's Bakery",     type: "New"     as const, amount: "₱12,500" },
  { id: "TXN-0846", business: "Metro Hardware",    type: "Renewal" as const, amount: "₱8,200"  },
  { id: "TXN-0845", business: "ABC Trading Corp",  type: "New"     as const, amount: "₱15,750" },
  { id: "TXN-0844", business: "Sunshine Pharmacy", type: "Renewal" as const, amount: "₱6,300"  },
];

const TypeBadge = ({ type }: { type: "New" | "Renewal" }) => (
  <span className={cn("rounded-full border px-1.5 py-0.5 font-mono text-[8px]",
    type === "New"
      ? "border-blue-500/30 bg-blue-500/20 text-blue-400"
      : "border-sky-500/30 bg-sky-500/20 text-sky-400")}>
    {type}
  </span>
);

// ---------------------------------------------------------------------------
// Donut chart (Card 4)
// ---------------------------------------------------------------------------

const DonutChart = () => {
  const r = 28;
  const circ = 2 * Math.PI * r;
  const newDash   = circ * (87 / 156);
  const renewDash = circ * (69 / 156);
  const newOffset   = -circ / 4;
  const renewOffset = newOffset - newDash - 2;
  return (
    <svg viewBox="0 0 72 72" className="h-20 w-20 shrink-0">
      <circle cx="36" cy="36" r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="8" />
      <circle cx="36" cy="36" r={r} fill="none" stroke="#3b82f6" strokeWidth="8"
        strokeDasharray={`${newDash} ${circ - newDash}`} strokeDashoffset={newOffset} />
      <circle cx="36" cy="36" r={r} fill="none" stroke="#38bdf8" strokeWidth="8"
        strokeDasharray={`${renewDash - 2} ${circ - renewDash + 2}`} strokeDashoffset={renewOffset} />
      <text x="36" y="32" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold" fontFamily="sans-serif">156</text>
      <text x="36" y="41" textAnchor="middle" fill="#71717a" fontSize="6" fontFamily="sans-serif">Total</text>
    </svg>
  );
};

// ---------------------------------------------------------------------------
// DashboardPreview
// ---------------------------------------------------------------------------

export function DashboardPreview() {
  const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"];

  return (
    <motion.div
      initial={{ opacity: 0, y: 40, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.8, delay: 1.0, ease: [0.22, 1, 0.36, 1] }}
      className="relative mx-auto mt-16 w-full max-w-5xl"
      style={{ perspective: "1200px" }}
    >
      <div className="overflow-hidden rounded-2xl border border-white/[0.08] bg-white/[0.03] shadow-2xl shadow-black/50 backdrop-blur-xl">

        {/* Browser chrome */}
        <div className="flex items-center gap-3 border-b border-white/[0.06] bg-white/[0.02] px-4 py-2.5">
          <div className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-red-500/70" />
            <span className="h-2.5 w-2.5 rounded-full bg-yellow-500/70" />
            <span className="h-2.5 w-2.5 rounded-full bg-green-500/70" />
          </div>
          <div className="flex flex-1 items-center justify-center">
            <div className="flex w-72 items-center gap-2 rounded-md border border-white/[0.06] bg-white/[0.03] px-3 py-1">
              <span className="flex-1 font-mono text-[10px] text-zinc-500">Search permits, users, or documents...</span>
              <span className="rounded border border-white/[0.1] px-1 font-mono text-[9px] text-zinc-600">⌘K</span>
            </div>
          </div>
          <div className="hidden items-center gap-2 sm:flex">
            <div className="flex h-6 w-6 items-center justify-center rounded-md border border-white/[0.06] bg-white/[0.03] text-zinc-500"><IconSun /></div>
            <div className="flex h-6 w-6 items-center justify-center rounded-md border border-white/[0.06] bg-white/[0.03] text-zinc-500"><IconBell /></div>
            <div className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-500/30 ring-1 ring-blue-500/40">
              <span className="font-mono text-[9px] font-bold text-blue-300">A</span>
            </div>
          </div>
        </div>

        {/* Body */}
        <div className="flex">
          {/* Sidebar */}
          <div className="hidden flex-col items-center gap-3 border-r border-white/[0.06] bg-white/[0.01] px-2 py-4 sm:flex">
            <SidebarIcon active><IconLayoutDashboard /></SidebarIcon>
            <SidebarIcon><IconFileText /></SidebarIcon>
            <SidebarIcon><IconCreditCard /></SidebarIcon>
            <SidebarIcon><IconUsers /></SidebarIcon>
            <SidebarIcon><IconSettings /></SidebarIcon>
          </div>

          {/* 2x2 grid */}
          <div className="grid flex-1 grid-cols-1 gap-px bg-white/[0.04] sm:grid-cols-2">

            {/* Card 1: New Permits */}
            <div className="bg-[#0a0d14] p-3">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-mono text-[9px] uppercase tracking-widest text-zinc-500">New Permits</span>
                <IconFileText />
              </div>
              <p className="font-mono text-3xl font-bold text-white">248</p>
              <p className="mt-0.5 font-mono text-xs text-zinc-500">This month</p>
              <p className="mb-3 mt-1 font-mono text-xs text-blue-400">↗ +18.3% vs last month</p>
              <MiniPermitsChart />
            </div>

            {/* Card 2: Permits Activity */}
            <div className="bg-[#0a0d14] p-3">
              <div className="mb-2 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-blue-400" />
                  <span className="font-mono text-[9px] uppercase tracking-widest text-zinc-300">Permits Activity</span>
                </div>
                <div className="flex items-center gap-1">
                  <button className="rounded bg-blue-500/20 px-1.5 py-0.5 font-mono text-[9px] text-blue-400">7D</button>
                  <button className="rounded px-1.5 py-0.5 font-mono text-[9px] text-zinc-600 hover:text-zinc-400">30D</button>
                </div>
              </div>
              <PermitsActivityChart />
              <div className="mt-1 flex justify-between px-0.5">
                {MONTHS.map((m) => <span key={m} className="font-mono text-[8px] text-zinc-600">{m}</span>)}
              </div>
              <div className="mt-2 flex items-center gap-3">
                <div className="flex items-center gap-1"><span className="h-2 w-2 rounded-sm bg-blue-500" /><span className="font-mono text-[9px] text-zinc-500">New</span></div>
                <div className="flex items-center gap-1"><span className="h-2 w-2 rounded-sm bg-sky-400" /><span className="font-mono text-[9px] text-zinc-500">Renewals</span></div>
              </div>
            </div>

            {/* Card 3: Recent Transactions */}
            <div className="bg-[#0a0d14] p-3">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-mono text-[9px] uppercase tracking-widest text-zinc-300">Recent Transactions</span>
                <div className="flex items-center gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-green-400" />
                  <span className="font-mono text-[9px] text-blue-400">Live</span>
                </div>
              </div>
              <table className="w-full border-collapse">
                <thead>
                  <tr>
                    {(["ID", "Business", "Type", "Amount"] as const).map((h) => (
                      <th key={h} className={cn("pb-1.5 text-[8px] font-normal text-zinc-600", h === "Amount" ? "text-right" : "text-left")}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {TRANSACTIONS.map((tx) => (
                    <tr key={tx.id} className="border-t border-white/[0.04]">
                      <td className="py-1 font-mono text-[10px] text-zinc-400">{tx.id}</td>
                      <td className="max-w-[72px] truncate py-1 font-mono text-[10px] text-zinc-300">{tx.business}</td>
                      <td className="py-1"><TypeBadge type={tx.type} /></td>
                      <td className="py-1 text-right font-mono text-[10px] text-zinc-300">{tx.amount}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Card 4: Permit Distribution */}
            <div className="bg-[#0a0d14] p-3">
              <div className="mb-2">
                <span className="font-mono text-[9px] uppercase tracking-widest text-zinc-300">Permit Distribution</span>
              </div>
              <div className="flex items-center gap-4">
                <DonutChart />
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-1.5">
                    <span className="h-2 w-2 shrink-0 rounded-full bg-blue-500" />
                    <span className="font-mono text-[10px] text-zinc-400">New: 87</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="h-2 w-2 shrink-0 rounded-full bg-sky-400" />
                    <span className="font-mono text-[10px] text-zinc-400">Renewals: 69</span>
                  </div>
                  <div className="mt-1 space-y-0.5">
                    <p className="font-mono text-[9px] text-zinc-600">Avg Amount: ₱10,500</p>
                    <p className="font-mono text-[9px] text-blue-400">Total Revenue: ₱2.4M</p>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

      {/* Glow */}
      <div className="absolute -bottom-20 left-1/2 h-40 w-3/4 -translate-x-1/2 rounded-full bg-blue-500/10 blur-3xl" />
    </motion.div>
  );
}
