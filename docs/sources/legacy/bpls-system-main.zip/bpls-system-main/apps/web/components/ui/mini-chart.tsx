"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface MiniChartProps {
  data: number[];
  variant: "sparkline" | "bar";
  color?: string;
  className?: string;
  height?: number;
  width?: number;
}

const DEFAULT_COLOR = "#60a5fa"; // blue-400

function normalize(data: number[], height: number): number[] {
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  return data.map((v) => height - ((v - min) / range) * (height * 0.8) - height * 0.1);
}

function buildPolylinePoints(data: number[], width: number, height: number): string {
  const step = width / (data.length - 1);
  const ys = normalize(data, height);
  return ys.map((y, i) => `${i * step},${y}`).join(" ");
}

function buildFillPath(data: number[], width: number, height: number): string {
  const step = width / (data.length - 1);
  const ys = normalize(data, height);
  const points = ys.map((y, i) => `${i * step},${y}`).join(" L ");
  const last = (data.length - 1) * step;
  return `M 0,${height} L ${points} L ${last},${height} Z`;
}

export function MiniChart({
  data,
  variant,
  color = DEFAULT_COLOR,
  className,
  height = 40,
  width = 120,
}: MiniChartProps) {
  if (!data || data.length === 0) return null;

  if (variant === "bar") {
    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = max - min || 1;
    const gap = 2;
    const barWidth = (width - gap * (data.length - 1)) / data.length;

    return (
      <svg
        width={width}
        height={height}
        viewBox={`0 0 ${width} ${height}`}
        className={cn("overflow-visible", className)}
        aria-hidden="true"
      >
        {data.map((v, i) => {
          const barHeight = ((v - min) / range) * (height * 0.85) + height * 0.1;
          const x = i * (barWidth + gap);
          const y = height - barHeight;
          return (
            <motion.rect
              key={i}
              x={x}
              y={height}
              width={barWidth}
              height={0}
              rx={1.5}
              fill={color}
              fillOpacity={0.7}
              animate={{ y, height: barHeight }}
              transition={{ duration: 0.6, delay: i * 0.04, ease: "easeOut" }}
            />
          );
        })}
      </svg>
    );
  }

  const gradientId = `sparkline-gradient-${Math.random().toString(36).slice(2, 7)}`;

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      className={cn("overflow-visible", className)}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity={0.25} />
          <stop offset="100%" stopColor={color} stopOpacity={0} />
        </linearGradient>
      </defs>
      <path
        d={buildFillPath(data, width, height)}
        fill={`url(#${gradientId})`}
      />
      <motion.polyline
        points={buildPolylinePoints(data, width, height)}
        fill="none"
        stroke={color}
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
        initial={{ pathLength: 0, opacity: 0 }}
        whileInView={{ pathLength: 1, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1.2, ease: "easeOut" }}
      />
    </svg>
  );
}
