"use client";

import { useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import { Controller } from "react-hook-form";
import { Building2, PlusCircle } from "lucide-react";
import { Button } from "@repo/ui/components/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";
import { LocationSelector } from "./location-selector";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import type { UseFormReturn } from "react-hook-form";
import type { CitizenPermitFormSchema } from "@repo/shared/schemas/citizen-permit-form";

interface BusinessSelectionStepProps {
  form: UseFormReturn<CitizenPermitFormSchema>;
}

interface MyBusiness {
  _id: string;
  businessName: string;
}

interface BusinessCategory {
  _id: string;
  name: string;
}

interface BusinessSubCategory {
  _id: string;
  name: string;
}

export function BusinessSelectionStep({ form }: BusinessSelectionStepProps) {
  const businessMode = form.watch("businessMode");
  const ownershipType = form.watch("ownershipType");
  const categoryId = form.watch("categoryId");

  const myBusinesses = useQuery(api.citizen.businesses.listMyBusinesses);
  const categories = useQuery(api.citizen.businessCategories.listCategories, {});
  const subCategories = useQuery(
    api.citizen.businessCategories.listSubCategoriesByCategory,
    categoryId
      ? { categoryId: categoryId as Id<"business_categories"> }
      : "skip"
  );

  const requiresGroupName =
    ownershipType === "partnership" ||
    ownershipType === "corporation" ||
    ownershipType === "cooperative";

  return (
    <div className="space-y-6">
      {/* Mode toggle */}
      <div className="grid grid-cols-2 gap-3">
        <button
          type="button"
          onClick={() => form.setValue("businessMode", "existing")}
          className={[
            "flex items-center gap-3 rounded-lg border-2 p-4 text-left transition-colors",
            businessMode === "existing"
              ? "border-primary bg-primary/5 text-primary"
              : "border-border bg-card text-muted-foreground hover:border-primary/50 hover:text-foreground",
          ].join(" ")}
        >
          <Building2 className="h-5 w-5 shrink-0" />
          <div>
            <p className="text-sm font-semibold">Select Existing Business</p>
            <p className="text-xs opacity-70">Choose from your registered businesses</p>
          </div>
        </button>

        <button
          type="button"
          onClick={() => form.setValue("businessMode", "new")}
          className={[
            "flex items-center gap-3 rounded-lg border-2 p-4 text-left transition-colors",
            businessMode === "new"
              ? "border-primary bg-primary/5 text-primary"
              : "border-border bg-card text-muted-foreground hover:border-primary/50 hover:text-foreground",
          ].join(" ")}
        >
          <PlusCircle className="h-5 w-5 shrink-0" />
          <div>
            <p className="text-sm font-semibold">Register New Business</p>
            <p className="text-xs opacity-70">Add a new business to your account</p>
          </div>
        </button>
      </div>

      {/* ── Existing business selection ─────────────────────────────── */}
      {businessMode === "existing" && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Select Your Business</CardTitle>
            <CardDescription>
              Choose the business you would like to apply a permit for.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {myBusinesses === undefined ? (
              <div className="text-muted-foreground text-sm">Loading your businesses...</div>
            ) : myBusinesses.length === 0 ? (
              <div className="rounded-md border border-dashed p-4 text-center">
                <p className="text-muted-foreground text-sm">
                  No businesses registered yet. Switch to &ldquo;Register New Business&rdquo; to
                  add one.
                </p>
                <Button
                  type="button"
                  variant="link"
                  size="sm"
                  className="mt-1"
                  onClick={() => form.setValue("businessMode", "new")}
                >
                  Register New Business
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                <Label htmlFor="selectedBusinessId">Business *</Label>
                <Controller
                  control={form.control}
                  name="selectedBusinessId"
                  render={({ field }) => (
                    <Select
                      value={field.value ?? ""}
                      onValueChange={field.onChange}
                    >
                      <SelectTrigger id="selectedBusinessId">
                        <SelectValue placeholder="Select a business..." />
                      </SelectTrigger>
                      <SelectContent>
                        {myBusinesses.map((business: MyBusiness) => (
                          <SelectItem key={business._id} value={business._id}>
                            {business.businessName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                />
                {form.formState.errors.selectedBusinessId && (
                  <p className="text-xs text-destructive">
                    {form.formState.errors.selectedBusinessId.message}
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* ── New business registration form ──────────────────────────── */}
      {businessMode === "new" && (
        <div className="space-y-6">
          {/* Business Identity */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Business Identity</CardTitle>
              <CardDescription>
                Provide the legal name and ownership structure of your business.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                {/* Business Name */}
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="businessName">Business Name *</Label>
                  <Input
                    id="businessName"
                    placeholder="Enter business name"
                    {...form.register("businessName")}
                  />
                  {form.formState.errors.businessName && (
                    <p className="text-xs text-destructive">
                      {form.formState.errors.businessName.message}
                    </p>
                  )}
                </div>

                {/* Ownership Type */}
                <div className="space-y-2">
                  <Label htmlFor="ownershipType">Ownership Type *</Label>
                  <Controller
                    control={form.control}
                    name="ownershipType"
                    render={({ field }) => (
                      <Select
                        value={field.value ?? ""}
                        onValueChange={(val) => {
                          field.onChange(val);
                          // Clear groupName when switching away from multi-owner types
                          if (
                            val !== "partnership" &&
                            val !== "corporation" &&
                            val !== "cooperative"
                          ) {
                            form.setValue("groupName", "");
                          }
                        }}
                      >
                        <SelectTrigger id="ownershipType">
                          <SelectValue placeholder="Select ownership type..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sole-proprietorship">Sole Proprietorship</SelectItem>
                          <SelectItem value="partnership">Partnership</SelectItem>
                          <SelectItem value="corporation">Corporation</SelectItem>
                          <SelectItem value="cooperative">Cooperative</SelectItem>
                          <SelectItem value="religious">Religious Organization</SelectItem>
                          <SelectItem value="non-profit">Non-Profit</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                  />
                  {form.formState.errors.ownershipType && (
                    <p className="text-xs text-destructive">
                      {form.formState.errors.ownershipType.message}
                    </p>
                  )}
                </div>

                {/* Group / Company Name (conditional) */}
                {requiresGroupName && (
                  <div className="space-y-2">
                    <Label htmlFor="groupName">
                      {ownershipType === "partnership"
                        ? "Partnership Name"
                        : ownershipType === "corporation"
                          ? "Corporation Name"
                          : "Cooperative Name"}{" "}
                      *
                    </Label>
                    <Input
                      id="groupName"
                      placeholder="Enter group or company name"
                      {...form.register("groupName")}
                    />
                    {form.formState.errors.groupName && (
                      <p className="text-xs text-destructive">
                        {form.formState.errors.groupName.message}
                      </p>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Business Classification */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Business Classification</CardTitle>
              <CardDescription>
                Classify your business by category and sub-category (optional).
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                {/* Category */}
                <div className="space-y-2">
                  <Label htmlFor="categoryId">Business Category</Label>
                  <Controller
                    control={form.control}
                    name="categoryId"
                    render={({ field }) => (
                      <Select
                        value={field.value ?? ""}
                        onValueChange={(val) => {
                          field.onChange(val);
                          // Clear sub-category whenever the category changes
                          form.setValue("subCategoryId", "");
                        }}
                      >
                        <SelectTrigger id="categoryId">
                          <SelectValue placeholder="Select category..." />
                        </SelectTrigger>
                        <SelectContent>
                          {(categories ?? []).map((cat: BusinessCategory) => (
                            <SelectItem key={cat._id} value={cat._id}>
                              {cat.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  />
                </div>

                {/* Sub-Category */}
                <div className="space-y-2">
                  <Label htmlFor="subCategoryId">Sub-Category</Label>
                  <Controller
                    control={form.control}
                    name="subCategoryId"
                    render={({ field }) => (
                      <Select
                        value={field.value ?? ""}
                        onValueChange={field.onChange}
                        disabled={!categoryId}
                      >
                        <SelectTrigger id="subCategoryId">
                          <SelectValue
                            placeholder={
                              !categoryId
                                ? "Select a category first"
                                : "Select sub-category..."
                            }
                          />
                        </SelectTrigger>
                        <SelectContent>
                          {(subCategories ?? []).map((sub: BusinessSubCategory) => (
                            <SelectItem key={sub._id} value={sub._id}>
                              {sub.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Business Address */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Business Address</CardTitle>
              <CardDescription>
                Provide the complete address where the business operates.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                {/* Street Address */}
                <div className="space-y-2">
                  <Label htmlFor="address">Street Address *</Label>
                  <Input
                    id="address"
                    placeholder="e.g. 123 Rizal Street"
                    {...form.register("address")}
                  />
                  {form.formState.errors.address && (
                    <p className="text-xs text-destructive">
                      {form.formState.errors.address.message}
                    </p>
                  )}
                </div>

                {/* Building Name */}
                <div className="space-y-2">
                  <Label htmlFor="buildingName">Building Name *</Label>
                  <Input
                    id="buildingName"
                    placeholder="e.g. SM City Building"
                    {...form.register("buildingName")}
                  />
                  {form.formState.errors.buildingName && (
                    <p className="text-xs text-destructive">
                      {form.formState.errors.buildingName.message}
                    </p>
                  )}
                </div>
              </div>

              {/* Province / City / Barangay */}
              <LocationSelector
                control={form.control}
                setValue={form.setValue}
                provinceField="provinceId"
                cityField="cityId"
                barangayField="barangayId"
                provinceValue={form.watch("provinceId") ?? ""}
                cityValue={form.watch("cityId") ?? ""}
                errors={{
                  province: form.formState.errors.provinceId,
                  city: form.formState.errors.cityId,
                  barangay: form.formState.errors.barangayId,
                }}
              />
            </CardContent>
          </Card>

          {/* Operations */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Operations</CardTitle>
              <CardDescription>
                Details about when and how the business operates.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                {/* Date Started */}
                <div className="space-y-2">
                  <Label htmlFor="dateStarted">Date Started *</Label>
                  <Input
                    id="dateStarted"
                    type="date"
                    {...form.register("dateStarted")}
                  />
                  {form.formState.errors.dateStarted && (
                    <p className="text-xs text-destructive">
                      {form.formState.errors.dateStarted.message}
                    </p>
                  )}
                </div>

                {/* Date Established */}
                <div className="space-y-2">
                  <Label htmlFor="establishedDate">Date Established</Label>
                  <Input
                    id="establishedDate"
                    type="date"
                    {...form.register("establishedDate")}
                  />
                </div>

                {/* Occupancy */}
                <div className="space-y-2">
                  <Label htmlFor="occupancy">Occupancy</Label>
                  <Controller
                    control={form.control}
                    name="occupancy"
                    render={({ field }) => (
                      <Select
                        value={field.value ?? ""}
                        onValueChange={field.onChange}
                      >
                        <SelectTrigger id="occupancy">
                          <SelectValue placeholder="Select occupancy..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="rented">Rented</SelectItem>
                          <SelectItem value="owned">Owned</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                  />
                </div>

                {/* Business Area */}
                <div className="space-y-2">
                  <Label htmlFor="businessArea">Business Area (sqm)</Label>
                  <Input
                    id="businessArea"
                    type="number"
                    min={0}
                    placeholder="e.g. 50"
                    {...form.register("businessArea", { valueAsNumber: true })}
                  />
                </div>

                {/* Property Index Number */}
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="propertyIndexNumber">Property Index Number</Label>
                  <Input
                    id="propertyIndexNumber"
                    placeholder="Enter property index number"
                    {...form.register("propertyIndexNumber")}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Employees */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Employees</CardTitle>
              <CardDescription>
                Provide the number of employees in your business. At least one employee is
                required.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                {/* Male Employee Count */}
                <div className="space-y-2">
                  <Label htmlFor="maleEmployeeCount">Male Employees *</Label>
                  <Input
                    id="maleEmployeeCount"
                    type="number"
                    min={0}
                    placeholder="0"
                    {...form.register("maleEmployeeCount", { valueAsNumber: true })}
                  />
                  {form.formState.errors.maleEmployeeCount && (
                    <p className="text-xs text-destructive">
                      {form.formState.errors.maleEmployeeCount.message}
                    </p>
                  )}
                </div>

                {/* Female Employee Count */}
                <div className="space-y-2">
                  <Label htmlFor="femaleEmployeeCount">Female Employees *</Label>
                  <Input
                    id="femaleEmployeeCount"
                    type="number"
                    min={0}
                    placeholder="0"
                    {...form.register("femaleEmployeeCount", { valueAsNumber: true })}
                  />
                  {form.formState.errors.femaleEmployeeCount && (
                    <p className="text-xs text-destructive">
                      {form.formState.errors.femaleEmployeeCount.message}
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Contact Information</CardTitle>
              <CardDescription>
                How can this business be reached?
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                {/* Contact Number */}
                <div className="space-y-2">
                  <Label htmlFor="contactNumber">Contact Number *</Label>
                  <Input
                    id="contactNumber"
                    type="tel"
                    placeholder="e.g. 09171234567"
                    {...form.register("contactNumber")}
                  />
                  {form.formState.errors.contactNumber && (
                    <p className="text-xs text-destructive">
                      {form.formState.errors.contactNumber.message}
                    </p>
                  )}
                </div>

                {/* Business Email */}
                <div className="space-y-2">
                  <Label htmlFor="businessEmail">Business Email *</Label>
                  <Input
                    id="businessEmail"
                    type="email"
                    placeholder="business@example.com"
                    {...form.register("businessEmail")}
                  />
                  {form.formState.errors.businessEmail && (
                    <p className="text-xs text-destructive">
                      {form.formState.errors.businessEmail.message}
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Registration (optional) */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Registration</CardTitle>
              <CardDescription>
                Optional government registration details for your business.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                {/* Registration Number */}
                <div className="space-y-2">
                  <Label htmlFor="registrationNumber">Registration Number</Label>
                  <Input
                    id="registrationNumber"
                    placeholder="e.g. DTI-2024-00001"
                    {...form.register("registrationNumber")}
                  />
                </div>

                {/* Registration Date */}
                <div className="space-y-2">
                  <Label htmlFor="registrationDate">Registration Date</Label>
                  <Input
                    id="registrationDate"
                    type="date"
                    {...form.register("registrationDate")}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
