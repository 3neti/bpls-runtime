"use client";

import type { Preloaded } from "convex/react";
import type { api } from "@repo/backend/convex/_generated/api";
import { usePlatformSettingsPreloaded } from "@/hooks/use-platform-settings";
import { FloatingNavbar } from "@/components/ui/floating-navbar";
import { HeroSection } from "@/components/landing/hero-section";
import { CapabilitiesSection } from "@/components/landing/capabilities-section";
import { MetricsSection } from "@/components/landing/metrics-section";
import { ProductInterfaceSection } from "@/components/landing/product-interface-section";
import { DepartmentsSection } from "@/components/landing/departments-section";
import { CtaSection } from "@/components/landing/cta-section";
import { FooterSection } from "@/components/landing/footer-section";

const navItems = [
  { name: "Features", link: "#capabilities" },
  { name: "Metrics", link: "#metrics" },
  { name: "Product", link: "#product" },
  { name: "Departments", link: "#departments" },
];

export function LandingPageClient({
  preloadedSettings,
  preloadedLogoUrl,
  preloadedLandingImageUrl,
  preloadedMunicipalSealUrl,
}: {
  preloadedSettings: Preloaded<typeof api.platformSettings.get>;
  preloadedLogoUrl: Preloaded<typeof api.platformSettings.getLogoUrl>;
  preloadedLandingImageUrl: Preloaded<typeof api.platformSettings.getLandingImageUrl>;
  preloadedMunicipalSealUrl: Preloaded<typeof api.platformSettings.getMunicipalSealUrl>;
}) {
  const settings = usePlatformSettingsPreloaded({
    settings: preloadedSettings,
    logoUrl: preloadedLogoUrl,
    landingImageUrl: preloadedLandingImageUrl,
    municipalSealUrl: preloadedMunicipalSealUrl,
  });

  return (
    <div className="dark">
      <div className="flex min-h-svh flex-col bg-[#0a0d14] text-zinc-100">
        <FloatingNavbar
          navItems={navItems}
          platformName={settings.platformName}
          logoUrl={settings.logoUrl}
        />
        <main>
          <HeroSection settings={settings} />
          <CapabilitiesSection />
          <MetricsSection />
          <ProductInterfaceSection />
          <DepartmentsSection settings={settings} />
          <CtaSection />
        </main>
        <FooterSection settings={settings} />
      </div>
    </div>
  );
}
