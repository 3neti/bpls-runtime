"use client";

import { motion } from "framer-motion";
import { Monitor, Clock, Zap, Lock } from "lucide-react";
import type { PlatformSettings } from "@/hooks/use-platform-settings";

const stats = [
  { icon: Monitor, label: "100% Digital", description: "Fully paperless process" },
  { icon: Clock, label: "24/7 Access", description: "Apply anytime, anywhere" },
  { icon: Zap, label: "Real-time Updates", description: "Instant status tracking" },
  { icon: Lock, label: "Secure Portal", description: "Enterprise-grade security" },
];

export function StatsSection({ settings }: { settings: PlatformSettings }) {
  const showOfficials = settings.mayorName || settings.treasurerName;

  return (
    <section
      id="about"
      className="relative overflow-hidden bg-zinc-900 px-4 py-20 text-zinc-100 dark:bg-zinc-950 md:py-28"
    >
      {/* Radial gradient blurs */}
      <div className="pointer-events-none absolute -top-32 -left-32 h-[500px] w-[500px] rounded-full bg-blue-600/15 blur-[120px]" />
      <div className="pointer-events-none absolute -bottom-32 -right-32 h-[500px] w-[500px] rounded-full bg-violet-600/12 blur-[100px]" />
      <div className="pointer-events-none absolute top-1/2 left-1/2 h-[300px] w-[300px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-emerald-600/8 blur-[80px]" />

      <div className="relative z-10 mx-auto max-w-6xl">
        {/* Stats grid */}
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.1 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="mx-auto mb-3 flex size-12 items-center justify-center rounded-xl bg-white/10 backdrop-blur-sm">
                <stat.icon className="size-6 text-zinc-100" />
              </div>
              <div className="text-lg font-bold text-white">{stat.label}</div>
              <div className="mt-1 text-sm text-zinc-400">{stat.description}</div>
            </motion.div>
          ))}
        </div>

        {/* Officials & Municipality info */}
        {(showOfficials || settings.fullAddress) && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            viewport={{ once: true }}
            className="mt-16 border-t border-white/10 pt-10 text-center"
          >
            {settings.mayorName && (
              <p className="text-sm text-zinc-400">
                Under the administration of{" "}
                <span className="font-semibold text-white">
                  {settings.mayorTitle} {settings.mayorName}
                </span>
              </p>
            )}
            {settings.treasurerName && (
              <p className="mt-1 text-sm text-zinc-400">
                {settings.treasurerTitle}:{" "}
                <span className="font-semibold text-white">
                  {settings.treasurerName}
                </span>
              </p>
            )}
            {settings.fullAddress && (
              <p className="mt-3 text-sm text-zinc-500">{settings.fullAddress}</p>
            )}
          </motion.div>
        )}
      </div>
    </section>
  );
}
