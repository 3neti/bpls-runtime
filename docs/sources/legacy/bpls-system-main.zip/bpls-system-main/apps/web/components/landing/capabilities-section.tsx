"use client";

import { motion } from "framer-motion";
import {
  FileText,
  Calculator,
  Building2,
  CreditCard,
  BarChart3,
  Shield,
} from "lucide-react";

const fadeIn = (index: number) => ({
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0 },
  transition: { duration: 0.6, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] as number[] },
  viewport: { once: true, margin: "-50px" },
});

// --- Mini Visualizations ---

const ApplicationWorkflowViz = () => (
  <div className="flex flex-col gap-3 w-full">
    <div className="flex items-center gap-1">
      {[
        { label: "Draft", bg: "bg-zinc-500/20", text: "text-zinc-400", border: "border-zinc-500/30" },
        { label: "Assessment", bg: "bg-amber-500/20", text: "text-amber-400", border: "border-amber-500/30" },
        { label: "Pending Payment", bg: "bg-orange-500/20", text: "text-orange-400", border: "border-orange-500/30" },
        { label: "Released", bg: "bg-blue-500/20", text: "text-blue-400", border: "border-blue-500/30" },
      ].map((step, i, arr) => (
        <div key={step.label} className="flex items-center gap-1 min-w-0">
          <span
            className={`shrink-0 rounded-full border px-1.5 py-0.5 text-[8px] font-medium ${step.bg} ${step.text} ${step.border}`}
          >
            {step.label}
          </span>
          {i < arr.length - 1 && (
            <span className="text-[9px] text-zinc-600 shrink-0">→</span>
          )}
        </div>
      ))}
    </div>
    <div className="rounded-md bg-black/30 border border-white/[0.06] px-2.5 py-2 flex items-center justify-between gap-2">
      <span className="font-mono text-[9px] text-zinc-500">BP-2025-0847</span>
      <span className="font-mono text-[9px] text-zinc-400 truncate">Juan&apos;s Bakery</span>
      <span className="shrink-0 rounded-full border border-amber-500/30 bg-amber-500/20 px-1.5 py-0.5 text-[8px] text-amber-400">
        Assessment
      </span>
    </div>
  </div>
);

const FeeCalculationViz = () => {
  const fees = [
    { label: "Business Tax", width: "100%", amount: "₱8,500" },
    { label: "Mayor's Permit Fee", width: "49%", amount: "₱4,200" },
    { label: "Fire Safety Fee", width: "24%", amount: "₱2,050" },
    { label: "Sanitary Permit", width: "12%", amount: "₱1,000" },
  ];
  return (
    <div className="flex flex-col gap-1.5 w-full">
      {fees.map((f) => (
        <div key={f.label} className="flex items-center gap-2">
          <span className="w-[100px] shrink-0 text-[9px] text-zinc-500 truncate">{f.label}</span>
          <div className="flex-1 h-1.5 rounded-full bg-white/[0.06]">
            <div className="h-full rounded-full bg-blue-500/70" style={{ width: f.width }} />
          </div>
          <span className="font-mono text-[9px] text-zinc-400 w-12 text-right shrink-0">{f.amount}</span>
        </div>
      ))}
      <div className="mt-1.5 flex items-center justify-between">
        <span className="rounded-full bg-blue-500/20 border border-blue-500/30 px-2 py-0.5 text-[8px] text-blue-400">
          3 LOBs
        </span>
        <span className="font-semibold text-[10px] text-blue-400">₱15,750.00</span>
      </div>
    </div>
  );
};

const ClearanceProgressViz = () => {
  const depts = [
    { name: "BPLO", status: "Approved", dotColor: "bg-green-400", statusColor: "text-green-400", filled: true },
    { name: "Fire Safety", status: "Pending", dotColor: "bg-amber-400", statusColor: "text-amber-400", filled: true },
    { name: "Engineering", status: "Not Started", dotColor: "bg-zinc-600", statusColor: "text-zinc-500", filled: false },
  ];
  return (
    <div className="flex flex-col gap-2.5 w-full">
      <div className="flex items-center gap-2">
        <div className="flex-1 h-1.5 rounded-full bg-white/[0.08]">
          <div className="h-full w-[62%] rounded-full bg-blue-500" />
        </div>
        <span className="shrink-0 text-[10px] text-zinc-400">5/8 Complete</span>
      </div>
      <div className="flex flex-col gap-1">
        {depts.map((d) => (
          <div key={d.name} className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              {d.filled ? (
                <div className={`h-1.5 w-1.5 rounded-full ${d.dotColor}`} />
              ) : (
                <div className="h-1.5 w-1.5 rounded-full border border-zinc-600" />
              )}
              <span className="text-[9px] text-zinc-300">{d.name}</span>
            </div>
            <span className={`text-[9px] ${d.statusColor}`}>{d.status}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const PaymentSummaryViz = () => (
  <div className="flex flex-col gap-1 w-full">
    <div className="flex justify-between items-center">
      <span className="text-[9px] text-zinc-500">Total Collected</span>
      <span className="text-[10px] font-semibold text-blue-400">₱2.4M</span>
    </div>
    <div className="flex justify-between items-center">
      <span className="text-[9px] text-zinc-500">Outstanding</span>
      <span className="text-[10px] font-semibold text-amber-400">₱180K</span>
    </div>
    <div className="flex justify-between items-center gap-2">
      <span className="text-[9px] text-zinc-500">Success Rate</span>
      <div className="flex items-center gap-1.5">
        <div className="h-1 w-16 rounded-full bg-white/[0.06]">
          <div className="h-full rounded-full bg-blue-500" style={{ width: "94%" }} />
        </div>
        <span className="text-[10px] font-semibold text-blue-400">94%</span>
      </div>
    </div>
    <div className="my-1.5 border-t border-white/[0.04]" />
    {[
      { id: "TXN-0847", amount: "₱12,500", label: "Completed", bg: "bg-green-500/20", text: "text-green-400", border: "border-green-500/30" },
      { id: "TXN-0846", amount: "₱8,200", label: "Pending", bg: "bg-amber-500/20", text: "text-amber-400", border: "border-amber-500/30" },
    ].map((txn) => (
      <div key={txn.id} className="flex items-center justify-between">
        <span className="font-mono text-[9px] text-zinc-500">{txn.id}</span>
        <span className="font-mono text-[9px] text-zinc-400">{txn.amount}</span>
        <span className={`rounded-full border px-1.5 py-0.5 text-[8px] font-medium ${txn.bg} ${txn.text} ${txn.border}`}>
          {txn.label}
        </span>
      </div>
    ))}
  </div>
);

const AnalyticsViz = () => {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const heights = [65, 82, 70, 95, 88, 40, 25];
  const max = 95;
  return (
    <div className="flex flex-col gap-2 w-full">
      <div className="flex items-end gap-1 h-16">
        {heights.map((h, i) => {
          const pct = (h / max) * 100;
          const split = 60;
          const bottomPct = Math.min(pct, split);
          const topPct = Math.max(0, pct - split);
          return (
            <div key={days[i]} className="flex-1 flex flex-col items-center gap-0.5">
              <div className="w-full flex flex-col justify-end" style={{ height: "52px" }}>
                <div style={{ height: `${topPct}%` }} className="w-full rounded-t bg-sky-400/40" />
                <div style={{ height: `${bottomPct}%` }} className="w-full bg-blue-500/60" />
              </div>
              <span className="text-[8px] text-zinc-600">{days[i]}</span>
            </div>
          );
        })}
      </div>
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1">
          <div className="h-1.5 w-1.5 rounded-full bg-blue-500" />
          <span className="text-[10px] text-zinc-500">New: 87</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="h-1.5 w-1.5 rounded-full bg-sky-400" />
          <span className="text-[10px] text-zinc-500">Renewals: 69</span>
        </div>
        <span className="ml-auto text-[9px] text-zinc-600">Export CSV ↓</span>
      </div>
    </div>
  );
};

const AuditTerminalViz = () => (
  <div className="rounded-lg bg-black/40 border border-white/[0.06] px-3 py-2.5 w-full font-mono">
    <div className="text-[9px] text-blue-400/60 mb-1">
      {">"} audit_check --target=permits-2025-Q1
    </div>
    <div className="flex flex-col gap-0.5">
      {[
        "248 permits issued this quarter...",
        "Revenue reconciled: ₱2.4M...",
        "8/8 departments active...",
      ].map((line) => (
        <div key={line} className="text-[9px] text-blue-400">
          &nbsp;&nbsp;[OK] {line}
        </div>
      ))}
    </div>
    <div className="text-[9px] text-blue-400 mt-1">
      {">"} <span className="inline-block w-1.5 h-2.5 bg-blue-400 animate-pulse align-middle" />
    </div>
  </div>
);

// --- Card Data ---

const CARDS = [
  {
    viz: <ApplicationWorkflowViz />,
    icon: FileText,
    title: "Permit Applications",
    description:
      "Track applications through the complete lifecycle from draft submission through assessment, payment, and final release.",
  },
  {
    viz: <FeeCalculationViz />,
    icon: Calculator,
    title: "Fee Calculation",
    description:
      "Automatically compute taxes and fees based on business type, capitalization, gross sales, and municipal ordinances.",
  },
  {
    viz: <ClearanceProgressViz />,
    icon: Building2,
    title: "Department Clearances",
    description:
      "Route applications through required departments with automatic clearance tracking and approval workflows.",
  },
  {
    viz: <PaymentSummaryViz />,
    icon: CreditCard,
    title: "Payments & Billing",
    description:
      "Process payments, track collections, and reconcile revenue across all permit categories with real-time billing updates.",
  },
  {
    viz: <AnalyticsViz />,
    icon: BarChart3,
    title: "Reports & Analytics",
    description:
      "Generate comprehensive reports on permit activity, revenue collection, and departmental performance with exportable data.",
  },
  {
    viz: <AuditTerminalViz />,
    icon: Shield,
    title: "Compliance & Audit",
    description:
      "Built-in compliance checking and complete audit trails for every permit transaction and approval decision.",
  },
];

export function CapabilitiesSection() {
  return (
    <section id="capabilities" className="relative overflow-hidden px-4 py-24">
      <div className="pointer-events-none absolute top-0 left-1/2 h-[400px] w-[600px] -translate-x-1/2 rounded-full bg-blue-500/[0.06] blur-[120px]" />

      <div className="relative z-10 mx-auto max-w-7xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] as number[] }}
          viewport={{ once: true }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16"
        >
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/[0.1] bg-white/[0.05] px-4 py-1.5 mb-6">
              <span className="h-2 w-2 rounded-full bg-blue-400" />
              <span className="text-xs font-medium tracking-[0.2em] text-zinc-300 uppercase">
                CAPABILITIES
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight">
              Complete Business Licensing For Every Municipality
            </h2>
          </div>
          <div className="flex items-end">
            <p className="text-lg text-zinc-400">
              From application intake to permit release, our platform covers the entire lifecycle
              with intelligent automation and real-time tracking.
            </p>
          </div>
        </motion.div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {CARDS.map((card, index) => {
            const Icon = card.icon;
            return (
              <motion.div
                key={card.title}
                {...fadeIn(index)}
                className="rounded-xl border border-white/[0.08] bg-white/[0.03] overflow-hidden
                  hover:border-white/[0.15] hover:bg-white/[0.05] transition-all duration-300 group"
              >
                {/* Mini Viz Header */}
                <div className="p-4 h-40 flex items-center border-b border-white/[0.06]">
                  {card.viz}
                </div>

                {/* Text Section */}
                <div className="p-5">
                  <div className="flex items-center gap-2.5 mb-2">
                    <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-blue-500/10 border border-blue-500/20">
                      <Icon className="h-3.5 w-3.5 text-blue-400" />
                    </div>
                    <h3 className="text-sm font-semibold text-zinc-100">{card.title}</h3>
                  </div>
                  <p className="text-xs text-zinc-500 leading-relaxed">{card.description}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
