"use client";

import Link from "next/link";
import Image from "next/image";
import { Building2, Github, Globe, Mail } from "lucide-react";
import type { PlatformSettings } from "@/hooks/use-platform-settings";

const platformLinks = [
  { label: "Features", href: "#features" },
  { label: "Pricing", href: "#pricing" },
  { label: "Documentation", href: "#docs" },
  { label: "API Reference", href: "#api" },
  { label: "Status", href: "#status" },
];

const governmentLinks = [
  { label: "Municipality Info", href: "#municipality" },
  { label: "Officials", href: "#officials" },
  { label: "Ordinances", href: "#ordinances" },
  { label: "Contact", href: "#contact" },
];

const resourceLinks = [
  { label: "Help Center", href: "#help" },
  { label: "Release Notes", href: "#releases" },
  { label: "Tutorials", href: "#tutorials" },
  { label: "Community", href: "#community" },
];

const legalLinks = [
  { label: "Privacy Policy", href: "#privacy" },
  { label: "Terms of Service", href: "#terms" },
  { label: "Data Policy", href: "#data" },
  { label: "Accessibility", href: "#accessibility" },
];

interface FooterColumn {
  title: string;
  links: { label: string; href: string }[];
}

const columns: FooterColumn[] = [
  { title: "Platform", links: platformLinks },
  { title: "Government", links: governmentLinks },
  { title: "Resources", links: resourceLinks },
  { title: "Legal", links: legalLinks },
];

export function FooterSection({ settings }: { settings: PlatformSettings }) {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-white/[0.06] bg-[#080b11]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-16">
        {/* 4-column links grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          {columns.map((col) => (
            <div key={col.title}>
              <h3 className="text-sm font-semibold text-white mb-4">
                {col.title}
              </h3>
              <ul className="space-y-3">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-sm text-zinc-500 hover:text-zinc-300 transition-colors"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Separator + bottom bar */}
        <div className="border-t border-white/[0.06] pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Left: Logo + platform name */}
            <Link href="/" className="flex items-center gap-2.5">
              {settings.logoUrl ? (
                <Image
                  src={settings.logoUrl}
                  alt={settings.platformName}
                  width={32}
                  height={32}
                  className="rounded-lg object-contain"
                />
              ) : (
                <div className="flex w-8 h-8 items-center justify-center rounded-lg bg-blue-500/20 border border-blue-500/30">
                  <Building2 className="w-4 h-4 text-blue-400" />
                </div>
              )}
              <span className="font-semibold text-zinc-200">
                {settings.platformName}
              </span>
            </Link>

            {/* Center: Copyright */}
            <p className="text-sm text-zinc-600 text-center">
              &copy; {year}{" "}
              {settings.municipalityName || "BPLS Portal"}. All rights reserved.
            </p>

            {/* Right: Social icons */}
            <div className="flex items-center gap-4">
              <a
                href="#"
                aria-label="GitHub"
                className="text-zinc-600 hover:text-zinc-400 transition-colors"
              >
                <Github className="w-5 h-5" />
              </a>
              <a
                href="#"
                aria-label="Website"
                className="text-zinc-600 hover:text-zinc-400 transition-colors"
              >
                <Globe className="w-5 h-5" />
              </a>
              <a
                href="#"
                aria-label="Email"
                className="text-zinc-600 hover:text-zinc-400 transition-colors"
              >
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
