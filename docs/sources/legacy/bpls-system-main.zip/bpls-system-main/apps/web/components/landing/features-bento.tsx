"use client";

import { motion } from "framer-motion";
import {
  FileText,
  CreditCard,
  Activity,
  FolderOpen,
  Bell,
  Shield,
} from "lucide-react";
import { BentoGrid, BentoGridItem } from "@/components/ui/bento-grid";

const features = [
  {
    title: "Business Permit Applications",
    description:
      "Submit new applications or renew existing permits entirely online. Track every step from submission through assessment to final approval.",
    icon: <FileText className="size-5 text-blue-600 dark:text-blue-400" />,
    className: "md:col-span-2",
    header: (
      <div className="flex h-full min-h-[6rem] w-full items-center justify-center rounded-lg bg-gradient-to-br from-blue-500/8 via-blue-400/5 to-indigo-500/8 dark:from-blue-500/15 dark:via-blue-400/10 dark:to-indigo-500/15">
        <div className="flex flex-col gap-2 rounded-lg border border-border/40 bg-background/80 p-3 shadow-sm backdrop-blur-sm dark:bg-background/60">
          <div className="flex items-center gap-2">
            <div className="size-2 rounded-full bg-green-500" />
            <span className="text-xs text-muted-foreground">Application #2024-001</span>
          </div>
          <div className="h-2 w-32 rounded-full bg-blue-500/20 dark:bg-blue-400/30" />
          <div className="h-2 w-24 rounded-full bg-blue-500/10 dark:bg-blue-400/20" />
        </div>
      </div>
    ),
  },
  {
    title: "Payment Tracking",
    description:
      "View payment schedules, outstanding balances, and complete transaction history in one place.",
    icon: <CreditCard className="size-5 text-emerald-600 dark:text-emerald-400" />,
    className: "md:col-span-1",
    header: (
      <div className="flex h-full min-h-[6rem] w-full items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500/8 to-teal-500/8 dark:from-emerald-500/15 dark:to-teal-500/15">
        <div className="flex items-center gap-3">
          <div className="flex flex-col items-center">
            <span className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">0.00</span>
            <span className="text-[10px] text-muted-foreground">Balance Due</span>
          </div>
        </div>
      </div>
    ),
  },
  {
    title: "Real-time Status Updates",
    description:
      "Monitor your application progress from submission through assessment to release.",
    icon: <Activity className="size-5 text-indigo-600 dark:text-indigo-400" />,
    className: "md:col-span-1",
    header: (
      <div className="flex h-full min-h-[6rem] w-full items-center justify-center rounded-lg bg-gradient-to-br from-indigo-500/8 to-purple-500/8 dark:from-indigo-500/15 dark:to-purple-500/15">
        <div className="flex items-center gap-1.5">
          {["Submitted", "Assessed", "Released"].map((step, i) => (
            <div key={step} className="flex items-center gap-1.5">
              <div
                className={`flex size-6 items-center justify-center rounded-full text-[10px] font-medium ${
                  i < 2
                    ? "bg-indigo-600 text-white dark:bg-indigo-500"
                    : "border border-border bg-muted text-muted-foreground"
                }`}
              >
                {i + 1}
              </div>
              {i < 2 && (
                <div className={`h-0.5 w-3 ${i < 1 ? "bg-indigo-600 dark:bg-indigo-500" : "bg-border"}`} />
              )}
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    title: "Document Management",
    description:
      "Upload requirements, download permits and receipts, and manage all your business documents digitally.",
    icon: <FolderOpen className="size-5 text-amber-600 dark:text-amber-400" />,
    className: "md:col-span-1",
    header: (
      <div className="flex h-full min-h-[6rem] w-full items-center justify-center rounded-lg bg-gradient-to-br from-amber-500/8 to-orange-500/8 dark:from-amber-500/15 dark:to-orange-500/15">
        <div className="flex flex-col gap-1.5">
          {["Business Permit.pdf", "Receipt.pdf", "Requirements.pdf"].map((doc) => (
            <div
              key={doc}
              className="flex items-center gap-2 rounded border border-border/40 bg-background/80 px-2 py-1 dark:bg-background/60"
            >
              <FileText className="size-3 text-amber-600 dark:text-amber-400" />
              <span className="text-[10px] text-muted-foreground">{doc}</span>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    title: "Instant Notifications",
    description:
      "Get updates when your application status changes or when action is needed.",
    icon: <Bell className="size-5 text-violet-600 dark:text-violet-400" />,
    className: "md:col-span-1",
    header: (
      <div className="flex h-full min-h-[6rem] w-full items-center justify-center rounded-lg bg-gradient-to-br from-violet-500/8 to-pink-500/8 dark:from-violet-500/15 dark:to-pink-500/15">
        <div className="relative">
          <Bell className="size-8 text-violet-500/60 dark:text-violet-400/60" />
          <div className="absolute -top-0.5 -right-0.5 flex size-3.5 items-center justify-center rounded-full bg-red-500 text-[8px] font-bold text-white">
            3
          </div>
        </div>
      </div>
    ),
  },
  {
    title: "Secure & Government Compliant",
    description:
      "Your data is protected with enterprise-grade security. Full compliance with local government regulations and data privacy standards.",
    icon: <Shield className="size-5 text-sky-600 dark:text-sky-400" />,
    className: "md:col-span-1",
    header: (
      <div className="flex h-full min-h-[6rem] w-full items-center justify-center rounded-lg bg-gradient-to-br from-sky-500/8 to-cyan-500/8 dark:from-sky-500/15 dark:to-cyan-500/15">
        <Shield className="size-10 text-sky-500/40 dark:text-sky-400/40" />
      </div>
    ),
  },
];

export function FeaturesBento() {
  return (
    <section id="features" className="relative overflow-hidden px-4 py-20 md:py-28">
      {/* Background radial blurs */}
      <div className="pointer-events-none absolute top-0 -right-40 h-[500px] w-[500px] rounded-full bg-blue-500/8 blur-[120px] dark:bg-blue-500/5" />
      <div className="pointer-events-none absolute -bottom-20 -left-40 h-[400px] w-[400px] rounded-full bg-violet-500/8 blur-[100px] dark:bg-violet-500/5" />

      <div className="relative z-10 mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="mb-14 text-center"
        >
          <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Everything you need in one place
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            A complete digital platform for managing your business permits — from
            application to release.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <BentoGrid>
            {features.map((feature) => (
              <BentoGridItem
                key={feature.title}
                title={feature.title}
                description={feature.description}
                header={feature.header}
                icon={feature.icon}
                className={feature.className}
              />
            ))}
          </BentoGrid>
        </motion.div>
      </div>
    </section>
  );
}
