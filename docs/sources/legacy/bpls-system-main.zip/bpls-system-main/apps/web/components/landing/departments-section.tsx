"use client";

import { useRef } from "react";
import Image from "next/image";
import { motion, useInView } from "framer-motion";
import {
  Building2,
  Wallet,
  Flame,
  HeartPulse,
  Wrench,
  MapPin,
  Leaf,
  Users,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface DepartmentsSectionProps {
  settings: {
    municipalityName?: string;
    municipalSealUrl?: string | null;
  };
}

interface Department {
  code: string;
  name: string;
  description: string;
  statusKey: string;
  badge: string;
  icon: React.ElementType;
}

const leftDepartments: Department[] = [
  {
    code: "BPLO",
    name: "Business Permits & Licensing Office",
    description: "Process all business permit applications and renewals",
    statusKey: "permits: active",
    badge: "SYNCED",
    icon: Building2,
  },
  {
    code: "Treasury",
    name: "Municipal Treasury",
    description: "Handle fee collection, payment processing, and revenue tracking",
    statusKey: "revenue: streaming",
    badge: "SYNCED",
    icon: Wallet,
  },
  {
    code: "Fire Safety",
    name: "Bureau of Fire Protection",
    description: "Fire safety inspections and clearance certification",
    statusKey: "inspections: 24",
    badge: "ACTIVE",
    icon: Flame,
  },
  {
    code: "Sanitary",
    name: "Sanitary Division",
    description: "Health and sanitation compliance verification",
    statusKey: "reviews: pending",
    badge: "SYNCED",
    icon: HeartPulse,
  },
];

const rightDepartments: Department[] = [
  {
    code: "Engineering",
    name: "Engineering Office",
    description: "Structural and electrical compliance certification",
    statusKey: "permits: queue",
    badge: "SYNCED",
    icon: Wrench,
  },
  {
    code: "Zoning",
    name: "Zoning Office",
    description: "Land use and zoning compliance verification",
    statusKey: "zone-check: ok",
    badge: "ACTIVE",
    icon: MapPin,
  },
  {
    code: "Environmental",
    name: "Environmental Office",
    description: "Environmental compliance and waste management",
    statusKey: "eco-scan: active",
    badge: "SYNCED",
    icon: Leaf,
  },
  {
    code: "Barangay",
    name: "Barangay Office",
    description: "Community-level clearance and verification",
    statusKey: "nodes: 142 healthy",
    badge: "ACTIVE",
    icon: Users,
  },
];

function DepartmentCard({
  department,
  index,
  side,
}: {
  department: Department;
  index: number;
  side: "left" | "right";
}) {
  const Icon = department.icon;

  return (
    <motion.div
      initial={{ opacity: 0, x: side === "left" ? -20 : 20 }}
      whileInView={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.2 + index * 0.08 }}
      viewport={{ once: true }}
      className="rounded-xl border border-white/[0.08] bg-white/[0.03] p-4 hover:border-white/[0.15] hover:bg-white/[0.05] transition-all duration-300"
    >
      <div className="flex items-center gap-3 mb-2">
        <div className="w-9 h-9 rounded-lg bg-white/[0.05] flex items-center justify-center shrink-0">
          <Icon className="w-4 h-4 text-zinc-400" />
        </div>
        <div className="min-w-0">
          <h4 className="font-semibold text-white text-sm leading-tight">
            {department.code}
          </h4>
          <span className="text-[11px] text-blue-400">● CONNECTED</span>
        </div>
      </div>
      <p className="text-xs text-zinc-500 mb-2.5 leading-relaxed">
        {department.description}
      </p>
      <div className="flex items-center justify-between text-[11px]">
        <span className="text-zinc-600 font-mono">{department.statusKey}</span>
        <span
          className={cn(
            "font-medium",
            department.badge === "ACTIVE" ? "text-blue-400" : "text-sky-400"
          )}
        >
          {department.badge}
        </span>
      </div>
    </motion.div>
  );
}

function RadialHub({
  municipalityName,
  municipalSealUrl,
  isInView,
}: {
  municipalityName?: string;
  municipalSealUrl?: string | null;
  isInView: boolean;
}) {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      {/* Radial glow background */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-[400px] h-[400px] rounded-full bg-blue-500/[0.06] blur-[80px]" />
      </div>

      {/* Concentric rings SVG */}
      <svg
        viewBox="0 0 400 400"
        className="absolute inset-0 w-full h-full"
        fill="none"
      >
        {/* Concentric circles */}
        {[60, 110, 160].map((r, i) => (
          <motion.circle
            key={r}
            cx={200}
            cy={200}
            r={r}
            stroke="currentColor"
            className="text-white/[0.04]"
            strokeWidth={1}
            initial={{ scale: 0, opacity: 0 }}
            animate={isInView ? { scale: 1, opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.1 + i * 0.15 }}
            style={{ transformOrigin: "200px 200px" }}
          />
        ))}

        {/* Radial connection lines from center to edges (8 directions) */}
        {[
          { x: 40, y: 80 },   // top-left
          { x: 40, y: 200 },  // left
          { x: 40, y: 320 },  // bottom-left
          { x: 120, y: 380 }, // bottom
          { x: 360, y: 80 },  // top-right
          { x: 360, y: 200 }, // right
          { x: 360, y: 320 }, // bottom-right
          { x: 280, y: 380 }, // bottom
        ].map((end, i) => (
          <motion.line
            key={i}
            x1={200}
            y1={200}
            x2={end.x}
            y2={end.y}
            stroke="currentColor"
            className="text-blue-500/20"
            strokeWidth={1}
            initial={{ pathLength: 0, opacity: 0 }}
            animate={isInView ? { pathLength: 1, opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.4 + i * 0.06 }}
          />
        ))}

        {/* Node dots at intersections on rings */}
        {[
          { cx: 145, cy: 115, r: 3, color: "fill-blue-400/60" },
          { cx: 255, cy: 115, r: 3, color: "fill-blue-400/60" },
          { cx: 100, cy: 200, r: 4, color: "fill-blue-400/80" },
          { cx: 300, cy: 200, r: 4, color: "fill-blue-400/80" },
          { cx: 145, cy: 285, r: 3, color: "fill-sky-400/60" },
          { cx: 255, cy: 285, r: 3, color: "fill-sky-400/60" },
          { cx: 200, cy: 340, r: 3, color: "fill-amber-400/50" },
          { cx: 200, cy: 60, r: 3, color: "fill-blue-400/40" },
        ].map((dot, i) => (
          <motion.circle
            key={i}
            cx={dot.cx}
            cy={dot.cy}
            r={dot.r}
            className={dot.color}
            initial={{ scale: 0 }}
            animate={isInView ? { scale: 1 } : {}}
            transition={{ duration: 0.3, delay: 0.8 + i * 0.05 }}
          />
        ))}
      </svg>

      {/* Center seal */}
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={isInView ? { scale: 1, opacity: 1 } : {}}
        transition={{ duration: 0.6, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
        className="relative z-10 flex flex-col items-center gap-2"
      >
        <div className="relative">
          <div className="absolute -inset-3 rounded-full bg-blue-500/15 blur-md" />
          <div className="relative w-16 h-16 rounded-full bg-blue-500/20 border border-blue-500/40 flex items-center justify-center overflow-hidden">
            {municipalSealUrl ? (
              <Image
                src={municipalSealUrl}
                alt={municipalityName ?? "Municipal Seal"}
                width={64}
                height={64}
                className="object-contain w-full h-full"
              />
            ) : (
              <Building2 className="w-7 h-7 text-blue-400" />
            )}
          </div>
        </div>
        <div className="rounded-full border border-white/[0.08] bg-white/[0.04] px-3 py-1">
          <span className="text-[10px] font-mono text-blue-400/80 tracking-widest uppercase">
            {municipalityName ? municipalityName.replace(/^Municipality of /i, "").toUpperCase() : "HUB"}
          </span>
        </div>
      </motion.div>
    </div>
  );
}

export function DepartmentsSection({ settings }: DepartmentsSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-100px" });

  return (
    <section
      ref={sectionRef}
      className="relative py-24 px-4 overflow-hidden"
      id="departments"
    >
      {/* Ambient glow */}
      <div className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full bg-blue-500/[0.03] blur-[100px]" />

      <div className="relative z-10 mx-auto max-w-7xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-20"
        >
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/[0.1] bg-white/[0.05] px-4 py-1.5 mb-6">
              <span className="h-2 w-2 rounded-full bg-blue-400" />
              <span className="text-xs font-medium tracking-[0.2em] text-zinc-300 uppercase">
                DEPARTMENTS
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight">
              Connect Every Government Department
            </h2>
          </div>
          <div className="flex items-end">
            <p className="text-lg text-zinc-400">
              Seamless clearance workflow integration across every required
              municipal department for complete permit processing.
            </p>
          </div>
        </motion.div>

        {/* Desktop: Cards around central hub */}
        <div className="hidden lg:grid grid-cols-[1fr_280px_1fr] gap-x-6 items-center">
          {/* Left cards */}
          <div className="flex flex-col gap-3">
            {leftDepartments.map((dept, i) => (
              <DepartmentCard
                key={dept.code}
                department={dept}
                index={i}
                side="left"
              />
            ))}
          </div>

          {/* Center radial visualization */}
          <div className="relative h-[580px]">
            <RadialHub
              municipalityName={settings.municipalityName}
              municipalSealUrl={settings.municipalSealUrl}
              isInView={isInView}
            />
          </div>

          {/* Right cards */}
          <div className="flex flex-col gap-3">
            {rightDepartments.map((dept, i) => (
              <DepartmentCard
                key={dept.code}
                department={dept}
                index={i}
                side="right"
              />
            ))}
          </div>
        </div>

        {/* Mobile: Stacked layout */}
        <div className="lg:hidden">
          <div className="flex justify-center mb-8">
            <div className="relative w-48 h-48">
              <RadialHub
                municipalityName={settings.municipalityName}
                municipalSealUrl={settings.municipalSealUrl}
                isInView={isInView}
              />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[...leftDepartments, ...rightDepartments].map((dept, i) => (
              <DepartmentCard
                key={dept.code}
                department={dept}
                index={i}
                side={i < 4 ? "left" : "right"}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
