"use client";

import { useFieldArray, Controller } from "react-hook-form";
import type { UseFormReturn } from "react-hook-form";
import type { CitizenPermitFormSchema } from "@repo/shared/schemas/citizen-permit-form";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";
import { Separator } from "@repo/ui/components/separator";

interface ApplicationDetailsStepProps {
  form: UseFormReturn<CitizenPermitFormSchema>;
}

export function ApplicationDetailsStep({ form }: ApplicationDetailsStepProps) {
  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "linesOfBusiness",
  });

  const lobErrors = form.formState.errors.linesOfBusiness;

  const handleAddLine = () => {
    append({
      businessCategory: "",
      capitalInvestment: "",
      grossSales: "",
      permitApplicationType: "New",
      numberOfEmployees: undefined,
    });
  };

  return (
    <div className="space-y-6">
      {/* Application Type */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Application Type</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label htmlFor="permitApplicationType">Application Type *</Label>
            <Controller
              control={form.control}
              name="permitApplicationType"
              render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger id="permitApplicationType">
                    <SelectValue placeholder="Select application type..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="New">New</SelectItem>
                    <SelectItem value="Renewal">Renewal</SelectItem>
                    <SelectItem value="Additional">Additional</SelectItem>
                  </SelectContent>
                </Select>
              )}
            />
            {form.formState.errors.permitApplicationType && (
              <p className="text-xs text-destructive">
                {form.formState.errors.permitApplicationType.message}
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Mode of Payment */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Mode of Payment</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label htmlFor="modeOfPayment">Payment Schedule</Label>
            <Controller
              control={form.control}
              name="modeOfPayment"
              render={({ field }) => (
                <Select
                  value={field.value ?? ""}
                  onValueChange={field.onChange}
                >
                  <SelectTrigger id="modeOfPayment">
                    <SelectValue placeholder="Select payment schedule..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Annually">Annually</SelectItem>
                    <SelectItem value="Semi-Annually">Semi-Annually</SelectItem>
                    <SelectItem value="Quarterly">Quarterly</SelectItem>
                  </SelectContent>
                </Select>
              )}
            />
            {form.formState.errors.modeOfPayment && (
              <p className="text-xs text-destructive">
                {form.formState.errors.modeOfPayment.message}
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Lines of Business */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-base">Lines of Business</CardTitle>
            <CardDescription>
              Add at least one line of business for this application.
            </CardDescription>
          </div>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleAddLine}
          >
            <Plus className="mr-1.5 size-4" />
            Add Line
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {fields.map((field, index) => (
            <div key={field.id} className="space-y-4">
              {index > 0 && <Separator />}

              {/* LOB Entry Header */}
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-muted-foreground">
                  Line of Business {index + 1}
                </p>
                {fields.length > 1 && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="size-8 p-0 text-destructive hover:text-destructive"
                    onClick={() => remove(index)}
                  >
                    <Trash2 className="size-4" />
                    <span className="sr-only">Remove line of business {index + 1}</span>
                  </Button>
                )}
              </div>

              {/* LOB Fields Grid */}
              <div className="grid gap-4 sm:grid-cols-2">
                {/* Business Category */}
                <div className="space-y-2">
                  <Label htmlFor={`lob-category-${index}`}>
                    Business Category *
                  </Label>
                  <Input
                    id={`lob-category-${index}`}
                    placeholder="e.g. Retail Store, Restaurant"
                    {...form.register(`linesOfBusiness.${index}.businessCategory`)}
                  />
                  {lobErrors?.[index]?.businessCategory && (
                    <p className="text-xs text-destructive">
                      {lobErrors[index]?.businessCategory?.message}
                    </p>
                  )}
                </div>

                {/* Capital Investment */}
                <div className="space-y-2">
                  <Label htmlFor={`lob-capital-${index}`}>
                    Capital Investment (PHP) *
                  </Label>
                  <Input
                    id={`lob-capital-${index}`}
                    placeholder="e.g. 500000"
                    {...form.register(`linesOfBusiness.${index}.capitalInvestment`)}
                  />
                  {lobErrors?.[index]?.capitalInvestment && (
                    <p className="text-xs text-destructive">
                      {lobErrors[index]?.capitalInvestment?.message}
                    </p>
                  )}
                </div>

                {/* Gross Sales */}
                <div className="space-y-2">
                  <Label htmlFor={`lob-gross-${index}`}>
                    Gross Sales (PHP) — Optional
                  </Label>
                  <Input
                    id={`lob-gross-${index}`}
                    placeholder="e.g. 1200000"
                    {...form.register(`linesOfBusiness.${index}.grossSales`)}
                  />
                  {lobErrors?.[index]?.grossSales && (
                    <p className="text-xs text-destructive">
                      {lobErrors[index]?.grossSales?.message}
                    </p>
                  )}
                </div>

                {/* Per-LOB Application Type */}
                <div className="space-y-2">
                  <Label htmlFor={`lob-type-${index}`}>Application Type</Label>
                  <Controller
                    control={form.control}
                    name={`linesOfBusiness.${index}.permitApplicationType`}
                    render={({ field }) => (
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                      >
                        <SelectTrigger id={`lob-type-${index}`}>
                          <SelectValue placeholder="Select type..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="New">New</SelectItem>
                          <SelectItem value="Renewal">Renewal</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                  />
                  {lobErrors?.[index]?.permitApplicationType && (
                    <p className="text-xs text-destructive">
                      {lobErrors[index]?.permitApplicationType?.message}
                    </p>
                  )}
                </div>

                {/* Number of Employees */}
                <div className="space-y-2">
                  <Label htmlFor={`lob-employees-${index}`}>
                    Number of Employees — Optional
                  </Label>
                  <Input
                    id={`lob-employees-${index}`}
                    type="number"
                    min="0"
                    placeholder="e.g. 5"
                    {...form.register(
                      `linesOfBusiness.${index}.numberOfEmployees`,
                      { valueAsNumber: true }
                    )}
                  />
                  {lobErrors?.[index]?.numberOfEmployees && (
                    <p className="text-xs text-destructive">
                      {lobErrors[index]?.numberOfEmployees?.message}
                    </p>
                  )}
                </div>
              </div>
            </div>
          ))}

          {/* Array-level validation errors */}
          {form.formState.errors.linesOfBusiness?.message && (
            <p className="text-sm text-destructive">
              {form.formState.errors.linesOfBusiness.message}
            </p>
          )}
          {form.formState.errors.linesOfBusiness?.root?.message && (
            <p className="text-sm text-destructive">
              {form.formState.errors.linesOfBusiness.root.message}
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
