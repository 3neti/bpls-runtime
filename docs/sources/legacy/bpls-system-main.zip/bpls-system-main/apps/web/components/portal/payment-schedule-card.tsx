"use client";

import { useState } from "react";
import Link from "next/link";
import { format } from "date-fns";
import {
  Calendar,
  ChevronDown,
  ChevronRight,
  CreditCard,
  CheckCircle2,
  Clock,
  AlertCircle,
} from "lucide-react";
import { Badge } from "@repo/ui/components/badge";
import { Button } from "@repo/ui/components/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card";
import { Separator } from "@repo/ui/components/separator";

// ── Types ─────────────────────────────────────────────────────────────────────

interface ScheduleFee {
  feeId?: string;
  feeName: string;
  feeCategory: string;
  originalAmount: number;
  sectionAmount: number;
  isEdited?: boolean;
  editedAt?: string;
}

interface PaymentScheduleSection {
  _id: string;
  sectionNumber: number;
  sectionLabel?: string;
  dueDate: string;
  status: string;
  fees: ScheduleFee[];
  surcharge?: number;
  penalty?: number;
  totalAmount: number;
  paidAmount: number;
}

interface PaymentScheduleCardProps {
  schedules: PaymentScheduleSection[];
  applicationId: string;
  applicationStatus: string;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

const CATEGORY_STYLES: Record<string, string> = {
  Tax: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
  "Regulatory Fee":
    "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  "Other Charges":
    "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300",
  "Special Fee":
    "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
};

const STATUS_CONFIG: Record<
  string,
  { label: string; icon: React.ElementType; className: string }
> = {
  pending: {
    label: "Pending",
    icon: Clock,
    className: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",
  },
  partial: {
    label: "Partial",
    icon: AlertCircle,
    className:
      "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
  },
  paid: {
    label: "Paid",
    icon: CheckCircle2,
    className:
      "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  },
};

function formatPeso(amount: number): string {
  return `₱${Number(amount).toLocaleString("en-PH", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

// ── Section Component ─────────────────────────────────────────────────────────

function ScheduleSection({
  section,
  applicationId,
  applicationStatus,
  defaultOpen,
}: {
  section: PaymentScheduleSection;
  applicationId: string;
  applicationStatus: string;
  defaultOpen: boolean;
}) {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  const statusCfg = STATUS_CONFIG[section.status] ?? STATUS_CONFIG.pending;
  const StatusIcon = statusCfg.icon;
  const remaining = section.totalAmount - section.paidAmount;
  const isPendingPayment = applicationStatus === "Pending Payment";
  const canPay = isPendingPayment && section.status !== "paid";

  return (
    <div className="border rounded-lg">
      {/* Section Header */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="flex w-full items-center justify-between gap-4 px-4 py-3 text-left hover:bg-muted/40 transition-colors rounded-lg"
      >
        <div className="flex items-center gap-3">
          {isOpen ? (
            <ChevronDown className="size-4 text-muted-foreground shrink-0" />
          ) : (
            <ChevronRight className="size-4 text-muted-foreground shrink-0" />
          )}
          <div>
            <p className="text-sm font-medium">
              {section.sectionLabel ?? `Section ${section.sectionNumber}`}
            </p>
            <p className="text-xs text-muted-foreground">
              Due:{" "}
              {section.dueDate
                ? format(new Date(section.dueDate), "MMM d, yyyy")
                : "—"}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <span className="text-sm font-semibold">
            {formatPeso(section.totalAmount)}
          </span>
          <Badge className={statusCfg.className}>
            <StatusIcon className="mr-1 size-3" />
            {statusCfg.label}
          </Badge>
          {canPay && (
            <Button
              size="sm"
              variant="outline"
              asChild
              onClick={(e) => e.stopPropagation()}
            >
              <Link
                href={`/portal/payments/${section._id}?applicationId=${applicationId}`}
              >
                <CreditCard className="mr-1.5 size-3" />
                Pay
              </Link>
            </Button>
          )}
        </div>
      </button>

      {/* Expanded Content */}
      {isOpen && (
        <div className="border-t px-4 py-3 space-y-3">
          {/* Fee List */}
          {section.fees.length > 0 && (
            <div className="space-y-1">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">
                Fee Breakdown
              </p>
              <div className="rounded-md border divide-y">
                {section.fees.map((fee, idx) => {
                  const catStyle =
                    CATEGORY_STYLES[fee.feeCategory] ?? CATEGORY_STYLES["Other Charges"];
                  return (
                    <div
                      key={fee.feeId ?? idx}
                      className="flex items-center justify-between gap-3 px-3 py-2 text-sm"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="truncate">{fee.feeName}</span>
                        <Badge
                          variant="secondary"
                          className={`shrink-0 text-[10px] px-1.5 py-0 ${catStyle}`}
                        >
                          {fee.feeCategory}
                        </Badge>
                        {fee.isEdited && (
                          <Badge
                            variant="outline"
                            className="shrink-0 text-[10px] px-1.5 py-0"
                          >
                            Adjusted
                          </Badge>
                        )}
                      </div>
                      <span className="font-medium shrink-0">
                        {formatPeso(fee.sectionAmount)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Surcharge & Penalty */}
          {((section.surcharge ?? 0) > 0 || (section.penalty ?? 0) > 0) && (
            <div className="space-y-1">
              {(section.surcharge ?? 0) > 0 && (
                <div className="flex items-center justify-between px-3 py-2 text-sm rounded-md bg-amber-50 dark:bg-amber-900/10">
                  <span className="text-amber-800 dark:text-amber-300">
                    Surcharge
                  </span>
                  <span className="font-medium text-amber-800 dark:text-amber-300">
                    {formatPeso(section.surcharge!)}
                  </span>
                </div>
              )}
              {(section.penalty ?? 0) > 0 && (
                <div className="flex items-center justify-between px-3 py-2 text-sm rounded-md bg-red-50 dark:bg-red-900/10">
                  <span className="text-red-800 dark:text-red-300">
                    Penalty
                  </span>
                  <span className="font-medium text-red-800 dark:text-red-300">
                    {formatPeso(section.penalty!)}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Section Summary */}
          <Separator />
          <div className="space-y-1.5 text-sm">
            <div className="flex justify-between font-medium">
              <span>Section Total</span>
              <span>{formatPeso(section.totalAmount)}</span>
            </div>
            {section.paidAmount > 0 && (
              <div className="flex justify-between text-green-700 dark:text-green-400">
                <span>Paid</span>
                <span>{formatPeso(section.paidAmount)}</span>
              </div>
            )}
            {remaining > 0 && section.status !== "paid" && (
              <div className="flex justify-between text-amber-700 dark:text-amber-400 font-medium">
                <span>Remaining</span>
                <span>{formatPeso(remaining)}</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────

export function PaymentScheduleCard({
  schedules,
  applicationId,
  applicationStatus,
}: PaymentScheduleCardProps) {
  if (schedules.length === 0) return null;

  const grandTotal = schedules.reduce((sum, s) => sum + s.totalAmount, 0);
  const totalPaid = schedules.reduce((sum, s) => sum + s.paidAmount, 0);
  const totalRemaining = grandTotal - totalPaid;

  // First unpaid section is expanded by default
  const firstUnpaidIdx = schedules.findIndex((s) => s.status !== "paid");

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Calendar className="size-4" />
          Payment Schedule
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Schedule Sections */}
        {schedules.map((section, idx) => (
          <ScheduleSection
            key={section._id}
            section={section}
            applicationId={applicationId}
            applicationStatus={applicationStatus}
            defaultOpen={idx === firstUnpaidIdx || schedules.length === 1}
          />
        ))}

        {/* Grand Total */}
        <Separator className="my-2" />
        <div className="space-y-1.5 px-1">
          <div className="flex justify-between text-sm font-semibold">
            <span>Grand Total</span>
            <span className="text-base">{formatPeso(grandTotal)}</span>
          </div>
          {totalPaid > 0 && (
            <div className="flex justify-between text-sm text-green-700 dark:text-green-400">
              <span>Total Paid</span>
              <span>{formatPeso(totalPaid)}</span>
            </div>
          )}
          {totalRemaining > 0 && (
            <div className="flex justify-between text-sm font-semibold text-amber-700 dark:text-amber-400">
              <span>Remaining Balance</span>
              <span>{formatPeso(totalRemaining)}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// ── Fee Breakdown for Payment Summary ─────────────────────────────────────────

/**
 * Compact fee breakdown list for use in the payment page sidebar.
 */
export function FeeBreakdownList({
  fees,
  surcharge,
  penalty,
  totalAmount,
}: {
  fees: ScheduleFee[];
  surcharge?: number;
  penalty?: number;
  totalAmount: number;
}) {
  if (fees.length === 0) return null;

  return (
    <div className="space-y-2">
      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
        Fee Breakdown
      </p>
      <div className="space-y-1">
        {fees.map((fee, idx) => {
          const catStyle =
            CATEGORY_STYLES[fee.feeCategory] ?? CATEGORY_STYLES["Other Charges"];
          return (
            <div
              key={fee.feeId ?? idx}
              className="flex items-center justify-between gap-2 text-sm"
            >
              <div className="flex items-center gap-1.5 min-w-0">
                <span className="truncate text-muted-foreground">
                  {fee.feeName}
                </span>
                <Badge
                  variant="secondary"
                  className={`shrink-0 text-[9px] px-1 py-0 leading-tight ${catStyle}`}
                >
                  {fee.feeCategory === "Regulatory Fee"
                    ? "Reg"
                    : fee.feeCategory === "Other Charges"
                      ? "Other"
                      : fee.feeCategory === "Special Fee"
                        ? "Special"
                        : fee.feeCategory}
                </Badge>
              </div>
              <span className="font-medium shrink-0 tabular-nums">
                {formatPeso(fee.sectionAmount)}
              </span>
            </div>
          );
        })}
      </div>

      {/* Surcharge & Penalty */}
      {((surcharge ?? 0) > 0 || (penalty ?? 0) > 0) && (
        <>
          <Separator />
          <div className="space-y-1">
            {(surcharge ?? 0) > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-amber-700 dark:text-amber-400">
                  Surcharge
                </span>
                <span className="font-medium text-amber-700 dark:text-amber-400 tabular-nums">
                  {formatPeso(surcharge!)}
                </span>
              </div>
            )}
            {(penalty ?? 0) > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-red-700 dark:text-red-400">Penalty</span>
                <span className="font-medium text-red-700 dark:text-red-400 tabular-nums">
                  {formatPeso(penalty!)}
                </span>
              </div>
            )}
          </div>
        </>
      )}

      {/* Total */}
      <Separator />
      <div className="flex justify-between font-semibold">
        <span className="text-sm">Total Due</span>
        <span>{formatPeso(totalAmount)}</span>
      </div>
    </div>
  );
}
