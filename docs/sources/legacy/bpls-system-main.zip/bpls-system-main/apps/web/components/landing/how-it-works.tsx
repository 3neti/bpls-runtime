"use client";

import { motion } from "framer-motion";
import { UserPlus, FileCheck, Award } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: UserPlus,
    title: "Create Your Account",
    description:
      "Register with your email and complete your business owner profile to get started.",
    color: "text-blue-600 dark:text-blue-400",
    bg: "bg-blue-500/8 dark:bg-blue-500/15",
  },
  {
    number: "02",
    icon: FileCheck,
    title: "Submit Application",
    description:
      "Fill out the digital permit application form, upload requirements, and submit online.",
    color: "text-violet-600 dark:text-violet-400",
    bg: "bg-violet-500/8 dark:bg-violet-500/15",
  },
  {
    number: "03",
    icon: Award,
    title: "Get Your Permit",
    description:
      "Track your application status, complete payments, and receive your approved business permit.",
    color: "text-emerald-600 dark:text-emerald-400",
    bg: "bg-emerald-500/8 dark:bg-emerald-500/15",
  },
];

export function HowItWorks() {
  return (
    <section
      id="how-it-works"
      className="relative overflow-hidden border-t border-border/50 bg-muted/30 px-4 py-20 dark:bg-muted/10 md:py-28"
    >
      {/* Background radial blur */}
      <div className="pointer-events-none absolute top-1/2 left-1/2 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-500/6 blur-[120px] dark:bg-indigo-500/4" />

      <div className="relative z-10 mx-auto max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="mb-16 text-center"
        >
          <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            How it works
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            Get your business permit in three simple steps — no office visits
            required.
          </p>
        </motion.div>

        <div className="relative grid gap-8 md:grid-cols-3 md:gap-12">
          {/* Connecting line (desktop only) */}
          <div className="pointer-events-none absolute top-16 right-[16.67%] left-[16.67%] hidden h-0.5 bg-gradient-to-r from-transparent via-border to-transparent md:block" />

          {steps.map((step, i) => (
            <motion.div
              key={step.number}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: i * 0.15 }}
              viewport={{ once: true }}
              className="relative flex flex-col items-center text-center"
            >
              {/* Icon circle */}
              <div className={`relative z-10 mb-6 flex size-16 items-center justify-center rounded-2xl ${step.bg} shadow-sm ring-1 ring-border/30 backdrop-blur-sm`}>
                <step.icon className={`size-7 ${step.color}`} />
              </div>

              {/* Step number */}
              <span className={`mb-2 text-xs font-semibold uppercase tracking-widest ${step.color}`}>
                Step {step.number}
              </span>

              <h3 className="mb-2 text-lg font-semibold text-foreground">{step.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
