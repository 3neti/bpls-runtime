"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface SectionBadgeProps {
  text: string;
  className?: string;
}

export function SectionBadge({ text, className }: SectionBadgeProps) {
  return (
    <motion.span
      initial={{ opacity: 0, y: -8 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className={cn(
        "inline-flex items-center gap-2 rounded-full border border-white/[0.1] bg-white/[0.05] px-4 py-1.5",
        className
      )}
    >
      <span className="relative flex h-2 w-2">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-blue-400 opacity-75" />
        <span className="relative inline-flex h-2 w-2 rounded-full bg-blue-400" />
      </span>
      <span className="text-xs font-medium tracking-[0.2em] text-zinc-300 uppercase">
        {text}
      </span>
    </motion.span>
  );
}
