"use client";

import { useQuery } from "convex/react";
import { api } from "@repo/backend/convex/_generated/api";
import type { Id } from "@repo/backend/convex/_generated/dataModel";
import { Controller, type Control, type UseFormSetValue } from "react-hook-form";
import { Label } from "@repo/ui/components/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";

interface LocationSelectorProps {
  control: Control<any>;
  setValue: UseFormSetValue<any>;
  provinceField: string;
  cityField: string;
  barangayField: string;
  provinceValue: string;
  cityValue: string;
  disabled?: boolean;
  errors?: {
    province?: { message?: string };
    city?: { message?: string };
    barangay?: { message?: string };
  };
}

/**
 * Cascading Province -> City -> Barangay selector.
 * Uses citizen-scoped location queries for security.
 */
export function LocationSelector({
  control,
  setValue,
  provinceField,
  cityField,
  barangayField,
  provinceValue,
  cityValue,
  disabled,
  errors,
}: LocationSelectorProps) {
  const provinces = useQuery(api.citizen.locations.listProvinces);

  const cities = useQuery(
      api.citizen.locations.listCitiesByProvince,
    provinceValue
      ? { provinceId: provinceValue as Id<"provinces"> }
      : "skip"
  );

  const barangays = useQuery(
      api.citizen.locations.listBarangaysByCity,
    cityValue ? { cityId: cityValue as Id<"cities"> } : "skip"
  );

  return (
    <div className="grid gap-4 sm:grid-cols-3">
      <div className="space-y-2">
        <Label>Province *</Label>
        <Controller
          control={control}
          name={provinceField}
          render={({ field }) => (
            <Select
              value={field.value}
              onValueChange={(val) => {
                field.onChange(val);
                setValue(cityField, "");
                setValue(barangayField, "");
              }}
              disabled={disabled}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select province..." />
              </SelectTrigger>
              <SelectContent>
                {provinces === undefined ? (
                  <SelectItem value="_loading" disabled>
                    Loading...
                  </SelectItem>
                ) : (
                  provinces.map((p: { _id: string; name: string }) => (
                    <SelectItem key={p._id} value={p._id}>
                      {p.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          )}
        />
        {errors?.province && (
          <p className="text-xs text-destructive">{errors.province.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label>City/Municipality *</Label>
        <Controller
          control={control}
          name={cityField}
          render={({ field }) => (
            <Select
              value={field.value}
              onValueChange={(val) => {
                field.onChange(val);
                setValue(barangayField, "");
              }}
              disabled={disabled || !provinceValue}
            >
              <SelectTrigger>
                <SelectValue
                  placeholder={
                    !provinceValue ? "Select province first" : "Select city..."
                  }
                />
              </SelectTrigger>
              <SelectContent>
                {cities === undefined ? (
                  <SelectItem value="_loading" disabled>
                    Loading...
                  </SelectItem>
                ) : cities.length === 0 ? (
                  <SelectItem value="_empty" disabled>
                    No cities found
                  </SelectItem>
                ) : (
                  cities.map((c: { _id: string; name: string }) => (
                    <SelectItem key={c._id} value={c._id}>
                      {c.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          )}
        />
        {errors?.city && (
          <p className="text-xs text-destructive">{errors.city.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label>Barangay *</Label>
        <Controller
          control={control}
          name={barangayField}
          render={({ field }) => (
            <Select
              value={field.value}
              onValueChange={field.onChange}
              disabled={disabled || !cityValue}
            >
              <SelectTrigger>
                <SelectValue
                  placeholder={
                    !cityValue ? "Select city first" : "Select barangay..."
                  }
                />
              </SelectTrigger>
              <SelectContent>
                {barangays === undefined ? (
                  <SelectItem value="_loading" disabled>
                    Loading...
                  </SelectItem>
                ) : barangays.length === 0 ? (
                  <SelectItem value="_empty" disabled>
                    No barangays found
                  </SelectItem>
                ) : (
                  barangays.map((b: { _id: string; name: string }) => (
                    <SelectItem key={b._id} value={b._id}>
                      {b.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          )}
        />
        {errors?.barangay && (
          <p className="text-xs text-destructive">{errors.barangay.message}</p>
        )}
      </div>
    </div>
  );
}
