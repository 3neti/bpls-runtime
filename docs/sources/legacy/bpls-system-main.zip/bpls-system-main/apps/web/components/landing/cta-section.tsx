"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { BackgroundBeams } from "@/components/ui/background-beams";

export function CtaSection() {
  return (
    <section className="py-32 px-4">
      <div className="relative mx-auto max-w-4xl">
        {/* Gradient glow behind card */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 via-sky-500/10 to-blue-500/20 blur-3xl rounded-3xl" />

        {/* Main CTA card */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="relative rounded-2xl border border-white/[0.1] bg-white/[0.03] backdrop-blur-xl p-12 sm:p-16 text-center overflow-hidden"
        >
          <BackgroundBeams />

          <div className="relative z-10">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/[0.1] bg-white/[0.05] px-4 py-1.5 mb-6">
              <span className="h-2 w-2 rounded-full bg-blue-400" />
              <span className="text-xs font-medium tracking-[0.2em] text-zinc-300 uppercase">
                GET STARTED
              </span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
              Ready to Modernize Your{" "}
              <span className="bg-gradient-to-r from-blue-400 to-sky-300 bg-clip-text text-transparent">
                Permit Process
              </span>
              ?
            </h2>

            <p className="text-lg text-zinc-400 max-w-2xl mx-auto mb-8">
              Join municipalities streamlining their business licensing with our
              unified digital platform.
            </p>

            {/* Dual CTAs */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <Link
                href="/register"
                className="inline-flex items-center justify-center gap-2 bg-blue-500 hover:bg-blue-400 text-white font-medium px-8 py-3 rounded-lg transition-colors"
              >
                Create an Account
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                href="/login"
                className="inline-flex items-center justify-center gap-2 border border-white/[0.15] text-zinc-300 hover:bg-white/[0.05] px-8 py-3 rounded-lg transition-colors"
              >
                Sign In to Portal
              </Link>
            </div>

            {/* Trust bullets */}
            <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-zinc-500">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-blue-400" />
                256-bit Encryption
              </span>
              <span className="text-zinc-700">•</span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-blue-400" />
                Government Compliant
              </span>
              <span className="text-zinc-700">•</span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-blue-400" />
                99.9% Uptime
              </span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
