"use client";

import { User, Building2, FileText, Loader2, Save, Send } from "lucide-react";
import { Button } from "@repo/ui/components/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card";
import { Separator } from "@repo/ui/components/separator";
import type { UseFormReturn } from "react-hook-form";
import type { CitizenPermitFormSchema } from "@repo/shared/schemas/citizen-permit-form";

interface ReviewSubmitStepProps {
  form: UseFormReturn<CitizenPermitFormSchema>;
  businessOwnerName: string;
  selectedBusinessName?: string;
  isSubmitting: boolean;
  onSubmit: () => void;
  onSaveDraft: () => void;
}

function DetailRow({
  label,
  value,
}: {
  label: string;
  value: string | number | undefined | null;
}) {
  const displayValue =
    value !== undefined && value !== null && value !== "" ? String(value) : "—";

  return (
    <div className="flex flex-col gap-0.5 sm:flex-row sm:items-baseline sm:gap-4">
      <span className="min-w-40 text-sm text-muted-foreground">{label}</span>
      <span className="text-sm font-medium">{displayValue}</span>
    </div>
  );
}

function formatOwnershipType(value: string | undefined | null): string {
  if (!value) return "—";
  const map: Record<string, string> = {
    "sole-proprietorship": "Sole Proprietorship",
    partnership: "Partnership",
    corporation: "Corporation",
    cooperative: "Cooperative",
    religious: "Religious Organization",
    "non-profit": "Non-Profit Organization",
  };
  return map[value] ?? value;
}

function formatCurrency(value: string | undefined | null): string {
  if (!value) return "—";
  const numeric = parseFloat(value.replace(/,/g, ""));
  if (isNaN(numeric)) return value;
  return `₱${numeric.toLocaleString("en-PH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function ReviewSubmitStep({
  form,
  businessOwnerName,
  selectedBusinessName,
  isSubmitting,
  onSubmit,
  onSaveDraft,
}: ReviewSubmitStepProps) {
  const values = form.watch();
  const {
    businessMode,
    businessName,
    ownershipType,
    address,
    buildingName,
    dateStarted,
    maleEmployeeCount,
    femaleEmployeeCount,
    businessArea,
    contactNumber,
    businessEmail,
    permitApplicationType,
    modeOfPayment,
    linesOfBusiness,
  } = values;

  const totalEmployees =
    (maleEmployeeCount ?? 0) + (femaleEmployeeCount ?? 0);

  return (
    <div className="space-y-6">
      {/* Business Owner */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <User className="size-4 text-muted-foreground" />
            Business Owner
          </CardTitle>
        </CardHeader>
        <CardContent>
          <DetailRow label="Owner Name" value={businessOwnerName} />
          <p className="mt-1.5 text-xs text-muted-foreground">
            From your linked profile
          </p>
        </CardContent>
      </Card>

      {/* Business Details */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Building2 className="size-4 text-muted-foreground" />
            Business Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {businessMode === "existing" ? (
            <DetailRow label="Business" value={selectedBusinessName} />
          ) : (
            <>
              <DetailRow label="Business Name" value={businessName} />
              <DetailRow
                label="Ownership Type"
                value={formatOwnershipType(ownershipType)}
              />
              <DetailRow label="Street Address" value={address} />
              <DetailRow label="Building" value={buildingName} />
              <DetailRow label="Date Started" value={dateStarted} />
              <DetailRow
                label="Employees"
                value={
                  maleEmployeeCount !== undefined ||
                  femaleEmployeeCount !== undefined
                    ? `${totalEmployees} total (${maleEmployeeCount ?? 0} male, ${femaleEmployeeCount ?? 0} female)`
                    : null
                }
              />
              <DetailRow
                label="Business Area"
                value={
                  businessArea !== undefined && businessArea !== null
                    ? `${businessArea} sqm`
                    : null
                }
              />
              <DetailRow label="Contact Number" value={contactNumber} />
              <DetailRow label="Business Email" value={businessEmail} />
            </>
          )}
        </CardContent>
      </Card>

      {/* Application Details */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <FileText className="size-4 text-muted-foreground" />
            Application Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <DetailRow label="Application Type" value={permitApplicationType} />
          <DetailRow label="Mode of Payment" value={modeOfPayment ?? null} />
        </CardContent>
      </Card>

      {/* Lines of Business */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Lines of Business</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {linesOfBusiness && linesOfBusiness.length > 0 ? (
            <ul className="divide-y">
              {linesOfBusiness.map((lob, index) => (
                <li key={index} className="px-6 py-3">
                  <div className="flex flex-col gap-1">
                    <span className="text-sm font-medium">
                      {lob.businessCategory || "—"}
                    </span>
                    <div className="flex flex-wrap gap-x-4 gap-y-0.5 text-xs text-muted-foreground">
                      <span>
                        Capital: {formatCurrency(lob.capitalInvestment)}
                      </span>
                      <span>Type: {lob.permitApplicationType || "—"}</span>
                      {lob.grossSales && lob.grossSales !== "" && (
                        <span>
                          Gross Sales: {formatCurrency(lob.grossSales)}
                        </span>
                      )}
                      {lob.numberOfEmployees !== undefined &&
                        lob.numberOfEmployees !== null && (
                          <span>Employees: {lob.numberOfEmployees}</span>
                        )}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-6 py-4 text-sm text-muted-foreground">
              No lines of business added.
            </p>
          )}
        </CardContent>
      </Card>

      <Separator />

      {/* Action Buttons */}
      <div className="flex justify-end gap-3">
        <Button
          type="button"
          variant="outline"
          onClick={onSaveDraft}
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <Loader2 className="mr-2 size-4 animate-spin" />
          ) : (
            <Save className="mr-2 size-4" />
          )}
          Save as Draft
        </Button>
        <Button type="button" onClick={onSubmit} disabled={isSubmitting}>
          {isSubmitting ? (
            <Loader2 className="mr-2 size-4 animate-spin" />
          ) : (
            <Send className="mr-2 size-4" />
          )}
          Submit Application
        </Button>
      </div>
    </div>
  );
}
