"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { FloatingSymbols } from "@/components/ui/floating-symbols";
import { DashboardPreview } from "@/components/landing/dashboard-preview";
import type { PlatformSettings } from "@/hooks/use-platform-settings";

const FEATURE_BULLETS = [
  "100% Digital Processing",
  "Real-time Tracking",
  "Government Compliant",
];

const fadeUp = (delay: number) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] as number[] },
});

export function HeroSection({ settings }: { settings: PlatformSettings }) {
  const tagline =
    settings.tagline ||
    "Process permits, manage fees, track clearances, and issue licenses from a unified digital platform.";

  return (
    <section className="relative flex min-h-[90vh] flex-col items-center justify-center overflow-hidden px-4 pt-24 pb-0">
      {/* Floating symbols background */}
      <FloatingSymbols />

      {/* Radial gradient blurs */}
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[500px] w-[800px] -translate-x-1/2 rounded-full bg-blue-500/10 blur-[120px]" />
      <div className="pointer-events-none absolute top-1/3 -left-40 h-[400px] w-[400px] rounded-full bg-sky-500/8 blur-[100px]" />

      {/* Grid dot pattern overlay */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.03)_1px,transparent_0)] bg-[size:28px_28px]" />

      <div className="relative z-10 mx-auto max-w-5xl text-center">
        {/* Badge pill */}
        <motion.div {...fadeUp(0)} className="mb-8 flex justify-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/[0.1] bg-white/[0.05] px-4 py-1.5">
            <span className="h-2 w-2 animate-pulse rounded-full bg-blue-400" />
            <span className="text-xs font-medium tracking-[0.2em] text-zinc-300 uppercase">
              BPLS Portal Live
            </span>
          </div>
        </motion.div>

        {/* Headline */}
        <motion.h1
          {...fadeUp(0.2)}
          className="text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-7xl"
        >
          <span className="block">Streamline Your</span>
          <span className="block bg-gradient-to-r from-blue-400 to-sky-300 bg-clip-text text-transparent">
            Business Permits
          </span>
          <span className="block">From One Digital Platform</span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          {...fadeUp(0.4)}
          className="mx-auto mt-6 max-w-2xl text-lg text-zinc-400"
        >
          {tagline}
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          {...fadeUp(0.6)}
          className="mt-10 flex flex-col items-center gap-3 sm:flex-row sm:justify-center"
        >
          <Link
            href="/register"
            className="inline-flex items-center gap-2 rounded-lg bg-blue-500 px-6 py-3 font-medium text-white transition-colors hover:bg-blue-400"
          >
            Create an Account
            <ArrowRight className="size-4" />
          </Link>
          <Link
            href="/login"
            className="inline-flex items-center rounded-lg border border-white/[0.15] px-6 py-3 font-medium text-zinc-300 transition-colors hover:bg-white/[0.05]"
          >
            Sign In to Portal
          </Link>
        </motion.div>

        {/* Feature bullets */}
        <motion.div
          {...fadeUp(0.8)}
          className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2"
        >
          {FEATURE_BULLETS.map((label) => (
            <span
              key={label}
              className="flex items-center gap-1.5 text-sm text-zinc-400"
            >
              <CheckCircle2 className="size-4 text-blue-400" />
              {label}
            </span>
          ))}
        </motion.div>
      </div>

      {/* Dashboard Preview */}
      <DashboardPreview />
    </section>
  );
}
