"use client";

import { motion } from "framer-motion";

const fadeIn = (index: number) => ({
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0 },
  transition: { duration: 0.6, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] as number[] },
  viewport: { once: true, margin: "-50px" },
});

// --- Sparkline (trending down = faster = good) ---
const Sparkline = () => (
  <svg viewBox="0 0 80 24" className="w-16 h-5" fill="none">
    <polyline
      points="0,20 13,16 26,18 39,12 52,8 65,5 80,3"
      stroke="#60a5fa"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill="none"
    />
    <polyline
      points="0,20 13,16 26,18 39,12 52,8 65,5 80,3"
      stroke="url(#spark-fill)"
      strokeWidth="0"
      fill="url(#spark-fill)"
      fillOpacity="0.15"
    />
    <defs>
      <linearGradient id="spark-fill" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#60a5fa" stopOpacity="0.3" />
        <stop offset="100%" stopColor="#60a5fa" stopOpacity="0" />
      </linearGradient>
    </defs>
  </svg>
);

// --- Mini bar chart ---
const MiniBarChart = () => {
  const bars = [60, 85, 70, 95, 80, 98, 90];
  return (
    <div className="flex items-end gap-0.5 h-5">
      {bars.map((h, i) => (
        <div
          key={i}
          className="w-2 rounded-sm bg-blue-500/60"
          style={{ height: `${(h / 100) * 20}px` }}
        />
      ))}
    </div>
  );
};

// --- Progress bar ---
const ProgressBar = ({ value }: { value: number }) => (
  <div className="h-1.5 w-20 rounded-full bg-white/[0.08] overflow-hidden">
    <div
      className="h-full rounded-full bg-gradient-to-r from-blue-500 to-sky-400"
      style={{ width: `${value}%` }}
    />
  </div>
);

// --- Stat Cards ---
const STATS = [
  {
    value: "24",
    suffix: "hr",
    label: "Average Processing",
    sublabel: "Fastest turnaround in the region",
    viz: <Sparkline />,
  },
  {
    value: "98.2",
    suffix: "%",
    label: "Approval Rate",
    sublabel: "Applications approved on first submission",
    viz: <MiniBarChart />,
  },
  {
    value: "12,480",
    suffix: "",
    label: "Permits Processed",
    sublabel: "",
    viz: (
      <span className="font-mono text-[9px] text-blue-400">
        ● ALL SYSTEMS NOMINAL
      </span>
    ),
  },
  {
    value: "< 5",
    suffix: "min",
    label: "Response Time",
    sublabel: "Average digital transaction speed",
    viz: <ProgressBar value={20} />,
  },
];

// --- Area Chart (Monthly Volume) ---
const AreaChart = () => {
  const W = 480;
  const H = 160;
  const pad = { top: 12, right: 8, bottom: 28, left: 36 };

  const blueData = [320, 580, 420, 870, 1200, 1540, 1350, 1850];
  const skyData = [180, 320, 260, 520, 780, 980, 860, 1200];
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug"];
  const yLabels = [0, 500, 1000, 1500, 2000];

  const innerW = W - pad.left - pad.right;
  const innerH = H - pad.top - pad.bottom;
  const maxVal = 2000;

  const toX = (i: number) => pad.left + (i / (blueData.length - 1)) * innerW;
  const toY = (v: number) => pad.top + innerH - (v / maxVal) * innerH;

  const buildPath = (data: number[]) =>
    data.map((v, i) => `${i === 0 ? "M" : "L"} ${toX(i)} ${toY(v)}`).join(" ");

  const buildArea = (data: number[]) =>
    `${buildPath(data)} L ${toX(data.length - 1)} ${toY(0)} L ${toX(0)} ${toY(0)} Z`;

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" preserveAspectRatio="none">
      <defs>
        <linearGradient id="blue-area" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#60a5fa" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#60a5fa" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="sky-area" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.2" />
          <stop offset="100%" stopColor="#38bdf8" stopOpacity="0" />
        </linearGradient>
      </defs>

      {/* Grid lines */}
      {yLabels.map((v) => (
        <g key={v}>
          <line
            x1={pad.left}
            y1={toY(v)}
            x2={W - pad.right}
            y2={toY(v)}
            stroke="rgba(255,255,255,0.05)"
            strokeWidth="1"
          />
          <text x={pad.left - 4} y={toY(v) + 3} textAnchor="end" fontSize="8" fill="#52525b">
            {v}
          </text>
        </g>
      ))}

      {/* X labels */}
      {months.map((m, i) => (
        <text
          key={m}
          x={toX(i)}
          y={H - 6}
          textAnchor="middle"
          fontSize="8"
          fill="#52525b"
        >
          {m}
        </text>
      ))}

      {/* Filled areas */}
      <path d={buildArea(skyData)} fill="url(#sky-area)" />
      <path d={buildArea(blueData)} fill="url(#blue-area)" />

      {/* Lines */}
      <path d={buildPath(skyData)} fill="none" stroke="#38bdf8" strokeWidth="1.5" strokeLinecap="round" />
      <path d={buildPath(blueData)} fill="none" stroke="#60a5fa" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
};

// --- Department Performance Map ---
const DEPARTMENTS = [
  { id: "BPLO", status: "green", x: 0, y: 0 },
  { id: "FIRE", status: "amber", x: 1, y: 0 },
  { id: "SAN", status: "green", x: 2, y: 0 },
  { id: "ZON", status: "green", x: 0, y: 1 },
  { id: "ENG", status: "amber", x: 2, y: 1 },
  { id: "TRES", status: "green", x: 0, y: 2 },
  { id: "ENV", status: "green", x: 1, y: 2 },
  { id: "BRG", status: "amber", x: 2, y: 2 },
] as const;

const DeptMap = () => {
  const cellSize = 80;
  const circleR = 22;
  const W = 3 * cellSize + 20;
  const H = 3 * cellSize + 10;

  const cx = (x: number) => x * cellSize + cellSize / 2 + 10;
  const cy = (y: number) => y * cellSize + cellSize / 2;

  const connections: [number, number][] = [
    [0, 1], [1, 2], [3, 0], [3, 4], [3, 5], [1, 7], [4, 7], [5, 6], [6, 7],
  ];

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full max-w-xs mx-auto">
      {/* Connection lines */}
      {connections.map(([a, b], i) => (
        <line
          key={i}
          x1={cx(DEPARTMENTS[a].x)}
          y1={cy(DEPARTMENTS[a].y)}
          x2={cx(DEPARTMENTS[b].x)}
          y2={cy(DEPARTMENTS[b].y)}
          stroke="rgba(255,255,255,0.06)"
          strokeWidth="1"
        />
      ))}

      {/* Nodes */}
      {DEPARTMENTS.map((dept) => {
        const x = cx(dept.x);
        const y = cy(dept.y);
        const isGreen = dept.status === "green";
        return (
          <g key={dept.id}>
            <circle
              cx={x}
              cy={y}
              r={circleR}
              fill={isGreen ? "rgba(52,211,153,0.1)" : "rgba(251,191,36,0.1)"}
              stroke={isGreen ? "rgba(52,211,153,0.4)" : "rgba(251,191,36,0.4)"}
              strokeWidth="1"
            />
            <text
              x={x}
              y={y + 1}
              textAnchor="middle"
              dominantBaseline="middle"
              fontSize="9"
              fontWeight="600"
              fill={isGreen ? "#60a5fa" : "#fbbf24"}
            >
              {dept.id}
            </text>
          </g>
        );
      })}
    </svg>
  );
};

export function MetricsSection() {
  return (
    <section id="metrics" className="relative overflow-hidden px-4 py-24">
      <div className="pointer-events-none absolute top-1/3 -right-40 h-[500px] w-[500px] rounded-full bg-sky-500/[0.05] blur-[120px]" />

      <div className="relative z-10 mx-auto max-w-7xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] as number[] }}
          viewport={{ once: true }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16"
        >
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/[0.1] bg-white/[0.05] px-4 py-1.5 mb-6">
              <span className="h-2 w-2 rounded-full bg-blue-400" />
              <span className="text-xs font-medium tracking-[0.2em] text-zinc-300 uppercase">
                SYSTEM METRICS
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight">
              Business Licensing At Municipal Scale
            </h2>
          </div>
          <div className="flex items-end">
            <p className="text-lg text-zinc-400">
              Continuously process permit applications, track department clearances, and monitor
              system performance across all departments.
            </p>
          </div>
        </motion.div>

        {/* Stat Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {STATS.map((stat, index) => (
            <motion.div
              key={stat.label}
              {...fadeIn(index)}
              className="rounded-xl border border-white/[0.08] bg-white/[0.03] p-6
                hover:border-white/[0.15] hover:bg-white/[0.05] transition-all duration-300"
            >
              <div className="mb-3">
                <span className="text-4xl font-bold text-white">{stat.value}</span>
                {stat.suffix && (
                  <span className="text-xl text-zinc-500 ml-1">{stat.suffix}</span>
                )}
              </div>
              <p className="text-xs font-medium text-zinc-300 mb-1">{stat.label}</p>
              {stat.sublabel && (
                <p className="text-[10px] text-zinc-600 mb-3">{stat.sublabel}</p>
              )}
              <div className="mt-2">{stat.viz}</div>
            </motion.div>
          ))}
        </div>

        {/* Large Viz Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Card A: Monthly Volume */}
          <motion.div
            {...fadeIn(4)}
            className="rounded-xl border border-white/[0.08] bg-white/[0.03] p-6
              hover:border-white/[0.15] hover:bg-white/[0.05] transition-all duration-300"
          >
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-sm font-semibold text-zinc-100">Monthly Processing Volume</h3>
              <div className="flex items-center gap-1.5 rounded-full border border-blue-500/30 bg-blue-500/10 px-2 py-0.5">
                <span className="h-1.5 w-1.5 rounded-full bg-blue-400 animate-pulse" />
                <span className="text-[9px] font-medium text-blue-400">LIVE</span>
              </div>
            </div>
            <p className="text-xs text-zinc-500 mb-5">
              Permit applications processed across all departments
            </p>
            <AreaChart />
            <div className="flex items-center gap-4 mt-4">
              <div className="flex items-center gap-1.5">
                <div className="h-2 w-4 rounded-sm bg-blue-500/60" />
                <span className="text-[10px] text-zinc-500">New Applications</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="h-2 w-4 rounded-sm bg-sky-500/60" />
                <span className="text-[10px] text-zinc-500">Renewals</span>
              </div>
            </div>
          </motion.div>

          {/* Card B: Department Map */}
          <motion.div
            {...fadeIn(5)}
            className="rounded-xl border border-white/[0.08] bg-white/[0.03] p-6
              hover:border-white/[0.15] hover:bg-white/[0.05] transition-all duration-300"
          >
            <h3 className="text-sm font-semibold text-zinc-100 mb-1">
              Department Performance Map
            </h3>
            <p className="text-xs text-zinc-500 mb-6">
              Real-time clearance completion across departments
            </p>
            <DeptMap />
            <div className="flex items-center gap-4 mt-4 justify-center">
              <div className="flex items-center gap-1.5">
                <div className="h-2 w-2 rounded-full bg-blue-400/60" />
                <span className="text-[10px] text-zinc-500">Healthy</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="h-2 w-2 rounded-full bg-amber-400/60" />
                <span className="text-[10px] text-zinc-500">Busy</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
