"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export function BackgroundBeams({ className }: { className?: string }) {
  const [paths, setPaths] = useState<string[]>([]);
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    const generatePaths = () => {
      const newPaths: string[] = [];
      for (let i = 0; i < 6; i++) {
        const startX = Math.random() * 100;
        const cp1X = Math.random() * 100;
        const cp1Y = 20 + Math.random() * 30;
        const cp2X = Math.random() * 100;
        const cp2Y = 50 + Math.random() * 30;
        const endX = Math.random() * 100;
        newPaths.push(
          `M${startX} 0 C${cp1X} ${cp1Y} ${cp2X} ${cp2Y} ${endX} 100`
        );
      }
      setPaths(newPaths);
    };
    generatePaths();
  }, []);

  return (
    <div
      className={cn(
        "pointer-events-none absolute inset-0 overflow-hidden",
        className
      )}
    >
      <svg
        ref={svgRef}
        className="absolute inset-0 h-full w-full"
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
        fill="none"
      >
        {paths.map((path, i) => (
          <motion.path
            key={i}
            d={path}
            stroke="currentColor"
            strokeWidth="0.15"
            className="text-primary/20"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{
              pathLength: 1,
              opacity: [0, 0.4, 0],
            }}
            transition={{
              duration: 4 + Math.random() * 3,
              repeat: Infinity,
              delay: i * 0.8,
              ease: "easeInOut",
            }}
          />
        ))}
      </svg>
    </div>
  );
}
