"use client";

import { motion } from "framer-motion";
import { GitBranch, Clock, Server, TrendingUp } from "lucide-react";

const fadeIn = (index: number) => ({
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0 },
  transition: { duration: 0.6, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] as number[] },
  viewport: { once: true, margin: "-50px" },
});

// --- Mini Line Chart for Application Tracking ---
const MiniLineChart = () => {
  const points = [30, 55, 40, 70, 50, 85, 60, 95, 75, 88];
  const W = 200;
  const H = 36;
  const xs = points.map((_, i) => (i / (points.length - 1)) * W);
  const ys = points.map((v) => H - (v / 100) * H);
  const path = xs.map((x, i) => `${i === 0 ? "M" : "L"} ${x} ${ys[i]}`).join(" ");
  const area = `${path} L ${W} ${H} L 0 ${H} Z`;

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-9" preserveAspectRatio="none">
      <defs>
        <linearGradient id="line-fill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#60a5fa" stopOpacity="0.2" />
          <stop offset="100%" stopColor="#60a5fa" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill="url(#line-fill)" />
      <path d={path} fill="none" stroke="#60a5fa" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
};

// --- Concentric Circle Viz for Fee Assessment ---
const ConcentricViz = () => {
  const rings = [
    { r: 56, dots: 8, color: "#60a5fa" },
    { r: 38, dots: 5, color: "#38bdf8" },
    { r: 20, dots: 3, color: "#6ee7b7" },
  ];
  const cx = 70;
  const cy = 70;

  return (
    <svg viewBox="0 0 140 140" className="w-28 h-28 shrink-0">
      {rings.map((ring, ri) =>
        Array.from({ length: ring.dots }).map((_, di) => {
          const angle = (di / ring.dots) * 2 * Math.PI - Math.PI / 2;
          const x = cx + ring.r * Math.cos(angle);
          const y = cy + ring.r * Math.sin(angle);
          return (
            <circle
              key={`${ri}-${di}`}
              cx={x}
              cy={y}
              r={3}
              fill={ring.color}
              opacity={0.6}
            />
          );
        })
      )}
      {rings.map((ring, ri) => (
        <circle
          key={ri}
          cx={cx}
          cy={cy}
          r={ring.r}
          fill="none"
          stroke={ring.color}
          strokeWidth="0.5"
          opacity={0.2}
        />
      ))}
      <circle cx={cx} cy={cy} r={10} fill="#60a5fa" opacity={0.2} />
      <circle cx={cx} cy={cy} r={5} fill="#60a5fa" opacity={0.5} />
    </svg>
  );
};

// --- Application Tracking Card ---
const AppTrackingCard = () => {
  const apps = [
    { id: "BizReg-Corp-01", region: "permit-east-1" },
    { id: "BizReg-SME-04", region: "permit-west-2" },
    { id: "BizReg-Solo-12", region: "permit-south-1" },
  ];

  return (
    <div className="flex flex-col h-full">
      <p className="text-xs text-zinc-500 mb-4 leading-relaxed">
        Track every permit from submission to release across all departments.
      </p>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        {[
          { label: "ACTIVE APPLICATIONS", value: "247" },
          { label: "PROCESSING RATE", value: "8.4k /month" },
          { label: "SYSTEM LOAD", value: "42% NORMAL" },
        ].map((s) => (
          <div
            key={s.label}
            className="rounded bg-white/[0.03] border border-white/[0.05] px-2 py-1.5"
          >
            <div className="text-[8px] text-zinc-600 mb-0.5">{s.label}</div>
            <div className="text-[10px] font-semibold text-blue-400">{s.value}</div>
          </div>
        ))}
      </div>

      {/* App list */}
      <div className="flex flex-col gap-1.5 mb-4">
        {apps.map((app) => (
          <div
            key={app.id}
            className="flex items-center justify-between rounded-lg border border-white/[0.05] bg-white/[0.02] px-3 py-1.5"
          >
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-blue-400" />
              <span className="font-mono text-[10px] text-zinc-300">{app.id}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[9px] text-zinc-600">{app.region}</span>
              <TrendingUp className="h-3 w-3 text-blue-500/60" />
            </div>
          </div>
        ))}
      </div>

      {/* Mini chart */}
      <div className="mb-3">
        <MiniLineChart />
      </div>

      {/* Bottom status */}
      <div className="rounded bg-black/30 border border-white/[0.05] px-2.5 py-1.5">
        <span className="font-mono text-[9px] text-blue-400/70">
          BizReg-Corp-01 completed block 0x4A
        </span>
        <span className="font-mono text-[9px] text-zinc-600 ml-2">Just now</span>
      </div>
    </div>
  );
};

// --- Fee Assessment Console Card ---
const FeeConsoleCard = () => {
  const events = [
    { dot: "bg-red-400", text: "Unauthorized fee override detected", time: "1m ago", badge: "REVIEW", badgeColor: "border-red-500/30 text-red-400 bg-red-500/10" },
    { dot: "bg-blue-400", text: "Payment reconciliation complete", time: "4m ago", badge: "VERIFIED", badgeColor: "border-blue-500/30 text-blue-400 bg-blue-500/10" },
    { dot: "bg-amber-400", text: "New assessment queued", time: "12m ago", badge: "PENDING", badgeColor: "border-amber-500/30 text-amber-400 bg-amber-500/10" },
  ];

  return (
    <div className="flex flex-col h-full">
      <p className="text-xs text-zinc-500 mb-4 leading-relaxed">
        Calculate and verify fees, track payments, and reconcile revenue across all permit categories.
      </p>

      {/* Header badges */}
      <div className="flex items-center gap-2 mb-4">
        <div className="flex items-center gap-1.5 rounded border border-blue-500/30 bg-blue-500/10 px-2 py-1">
          <span className="h-1.5 w-1.5 rounded-full bg-blue-400 animate-pulse" />
          <span className="font-mono text-[9px] text-blue-400">NET_SCAN::ACTIVE</span>
        </div>
        <div className="flex items-center gap-1.5 rounded border border-white/[0.1] bg-white/[0.04] px-2 py-1">
          <span className="text-[9px] text-zinc-400">EVENT LOG</span>
          <span className="rounded-full bg-red-500/20 border border-red-500/30 px-1.5 text-[8px] text-red-400">
            2 UNRESOLVED
          </span>
        </div>
      </div>

      {/* Visualization + log side by side */}
      <div className="flex gap-4 items-center mb-4">
        <ConcentricViz />
        <div className="flex-1 flex flex-col gap-2">
          {events.map((ev, i) => (
            <div
              key={i}
              className="flex items-center justify-between gap-2 rounded border border-white/[0.05] bg-white/[0.02] px-2.5 py-1.5"
            >
              <div className="flex items-center gap-1.5 min-w-0">
                <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${ev.dot}`} />
                <span className="text-[9px] text-zinc-400 truncate">{ev.text}</span>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-[9px] text-zinc-600">{ev.time}</span>
                <span className={`rounded border px-1.5 py-0.5 text-[7px] font-semibold ${ev.badgeColor}`}>
                  {ev.badge}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// --- Small Cards ---

const RoutingCard = () => (
  <div className="flex flex-col h-full">
    <div className="flex items-center gap-2 mb-3">
      <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-blue-500/10 border border-blue-500/20">
        <GitBranch className="h-3 w-3 text-blue-400" />
      </div>
      <span className="text-[10px] font-semibold tracking-widest text-zinc-400 uppercase">
        Automated Routing
      </span>
    </div>

    <div className="flex items-center gap-2 mb-3">
      <div className="flex h-8 w-8 items-center justify-center rounded-full border border-blue-500/30 bg-blue-500/10 text-[9px] text-blue-400 font-mono">
        TRG
      </div>
      <div className="flex-1 h-px bg-gradient-to-r from-blue-500/40 to-white/[0.08]" />
      <div className="flex flex-col items-center gap-0.5">
        <div className="flex h-6 w-16 items-center justify-center rounded-full border border-white/[0.1] bg-white/[0.04]">
          <div className="h-1.5 w-1.5 rounded-full bg-blue-400 mr-1" />
          <span className="text-[8px] text-zinc-400">ROUTE</span>
        </div>
      </div>
      <div className="flex-1 h-px bg-gradient-to-r from-white/[0.08] to-sky-500/40" />
      <div className="flex h-8 w-8 items-center justify-center rounded-full border border-sky-500/30 bg-sky-500/10 text-[9px] text-sky-400 font-mono">
        DST
      </div>
    </div>

    <div className="flex items-center justify-between mb-3">
      <span className="text-[9px] text-zinc-600">ON SUBMISSION</span>
      <span className="text-[9px] text-zinc-600">AUTO-ROUTE</span>
    </div>

    <p className="text-xs text-zinc-500 leading-relaxed">
      Automated routing active. 142 applications processed without manual intervention this month.
    </p>
  </div>
);

const ActivityLogCard = () => {
  const events = [
    { dot: "bg-blue-400", text: "Fee assessment completed", time: "10:42 AM" },
    { dot: "bg-sky-400", text: "Engineering clearance issued", time: "09:15 AM" },
    { dot: "bg-zinc-500", text: "Scheduled inspection set", time: "08:00 AM" },
  ];

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-2 mb-4">
        <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-blue-500/10 border border-blue-500/20">
          <Clock className="h-3 w-3 text-blue-400" />
        </div>
        <span className="text-[10px] font-semibold tracking-widest text-zinc-400 uppercase">
          Department Activity Log
        </span>
      </div>

      <div className="flex flex-col gap-2">
        {events.map((ev, i) => (
          <div
            key={i}
            className="flex items-center justify-between rounded-lg border border-white/[0.05] bg-white/[0.02] px-3 py-2"
          >
            <div className="flex items-center gap-2">
              <span className={`h-1.5 w-1.5 rounded-full ${ev.dot}`} />
              <span className="text-xs text-zinc-400">{ev.text}</span>
            </div>
            <span className="text-[10px] text-zinc-600">{ev.time}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const SystemHealthCard = () => (
  <div className="flex flex-col h-full">
    <div className="flex items-center gap-2 mb-4">
      <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-blue-500/10 border border-blue-500/20">
        <Server className="h-3 w-3 text-blue-400" />
      </div>
      <span className="text-[10px] font-semibold tracking-widest text-zinc-400 uppercase">
        System Health
      </span>
    </div>

    <div className="flex items-center gap-4 mb-5">
      <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full border-2 border-blue-500/40 bg-blue-500/10">
        <div className="text-center">
          <div className="text-lg font-bold text-white leading-none">92</div>
          <div className="text-[7px] text-zinc-500 mt-0.5">SCORE</div>
        </div>
      </div>
      <div className="flex-1 flex flex-col gap-2">
        <div>
          <div className="flex items-center justify-between mb-1">
            <span className="text-[9px] text-zinc-500">Processing Queue</span>
            <span className="text-[9px] text-blue-400">Stable</span>
          </div>
          <div className="h-1.5 w-full rounded-full bg-white/[0.06] overflow-hidden">
            <div className="h-full w-1/4 rounded-full bg-blue-500/70" />
          </div>
        </div>
        <div>
          <div className="flex items-center justify-between mb-1">
            <span className="text-[9px] text-zinc-500">Department Load</span>
            <span className="text-[9px] text-sky-400">82%</span>
          </div>
          <div className="h-1.5 w-full rounded-full bg-white/[0.06] overflow-hidden">
            <div className="h-full rounded-full bg-gradient-to-r from-sky-500/70 to-blue-500/50" style={{ width: "82%" }} />
          </div>
        </div>
      </div>
    </div>
  </div>
);

export function ProductInterfaceSection() {
  return (
    <section id="product" className="relative overflow-hidden px-4 py-24">
      <div className="pointer-events-none absolute -bottom-20 left-1/2 h-[500px] w-[700px] -translate-x-1/2 rounded-full bg-blue-500/[0.05] blur-[140px]" />

      <div className="relative z-10 mx-auto max-w-7xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] as number[] }}
          viewport={{ once: true }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16"
        >
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/[0.1] bg-white/[0.05] px-4 py-1.5 mb-6">
              <span className="h-2 w-2 rounded-full bg-blue-400" />
              <span className="text-xs font-medium tracking-[0.2em] text-zinc-300 uppercase">
                PRODUCT INTERFACE
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight">
              Full Visibility Across Every Application
            </h2>
          </div>
          <div className="flex items-end">
            <p className="text-lg text-zinc-400">
              Monitor permit applications, department clearances, and automated workflows from a
              unified digital dashboard.
            </p>
          </div>
        </motion.div>

        {/* 2 Large Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
          {(["Application Tracking", "Fee Assessment Console"] as const).map((title, index) => (
            <motion.div
              key={title}
              {...fadeIn(index)}
              className="rounded-xl border border-white/[0.08] bg-white/[0.03] p-6 hover:border-white/[0.15] hover:bg-white/[0.05] transition-all duration-300"
            >
              <h3 className="text-sm font-semibold text-zinc-100 mb-4">{title}</h3>
              {index === 0 ? <AppTrackingCard /> : <FeeConsoleCard />}
            </motion.div>
          ))}
        </div>

        {/* 3 Small Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { content: <RoutingCard /> },
            { content: <ActivityLogCard /> },
            { content: <SystemHealthCard /> },
          ].map((card, index) => (
            <motion.div
              key={index}
              {...fadeIn(index + 2)}
              className="rounded-xl border border-white/[0.08] bg-white/[0.03] p-5
                hover:border-white/[0.15] hover:bg-white/[0.05] transition-all duration-300"
            >
              {card.content}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
